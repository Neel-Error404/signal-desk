from __future__ import annotations

import json
import uuid
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json


POLICY_FIELDS = {
    "version",
    "id",
    "trace_format",
    "required_start_status",
    "terminal_statuses",
    "maximum_failed_events",
    "require_monotonic_sequence",
    "require_elapsed_ms",
    "secret_name_patterns",
}


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ProtocolError(f"Could not read transcript {path}: {exc}") from exc
    for index, line in enumerate(lines, start=1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ProtocolError(
                f"Transcript {path} line {index} is invalid JSON: {exc}"
            ) from exc
        if not isinstance(event, dict):
            raise ProtocolError(
                f"Transcript {path} line {index} must be a JSON object."
            )
        events.append(event)
    return events


def _validate_policy(policy: dict[str, Any]) -> None:
    if set(policy) != POLICY_FIELDS:
        raise ProtocolError(
            f"Transcript review policy fields must be exactly: {sorted(POLICY_FIELDS)}"
        )
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Transcript review policy version must be '{PROTOCOL_VERSION}'."
        )
    if policy["trace_format"] != "workflow-jsonl-v1":
        raise ProtocolError(
            f"Unsupported transcript format: {policy['trace_format']}"
        )
    if not isinstance(policy["terminal_statuses"], list) or not policy[
        "terminal_statuses"
    ]:
        raise ProtocolError("Transcript review policy needs terminal statuses.")
    if not isinstance(policy["maximum_failed_events"], int) or policy[
        "maximum_failed_events"
    ] < 0:
        raise ProtocolError("maximum_failed_events must be a non-negative integer.")
    if not isinstance(policy["secret_name_patterns"], list):
        raise ProtocolError("secret_name_patterns must be a list.")


def validate_transcript_review_policy(policy_path: Path) -> dict[str, Any]:
    policy_path = policy_path.resolve()
    policy = load_json(policy_path)
    _validate_policy(policy)
    return {
        "policy": str(policy_path),
        "id": policy["id"],
        "trace_format": policy["trace_format"],
        "maximum_failed_events": policy["maximum_failed_events"],
    }


def _finding(
    category: str,
    severity: str,
    message: str,
    evidence: list[str],
) -> dict[str, Any]:
    return {
        "id": f"finding-{category}-{uuid.uuid4().hex[:8]}",
        "category": category,
        "severity": severity,
        "message": message,
        "evidence": evidence,
    }


def _nested_keys(value: Any) -> list[str]:
    keys: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            keys.append(str(key))
            keys.extend(_nested_keys(child))
    elif isinstance(value, list):
        for child in value:
            keys.extend(_nested_keys(child))
    return keys


def review_transcript(
    trace_path: Path,
    policy_path: Path,
    *,
    evaluator_id: str,
    executor_id: str,
) -> dict[str, Any]:
    if not evaluator_id.strip() or not executor_id.strip():
        raise ProtocolError("Evaluator and executor identities must be non-empty.")
    if evaluator_id == executor_id:
        raise ProtocolError(
            "Transcript evaluation must be independent from the executor."
        )
    trace_path = trace_path.resolve()
    policy_path = policy_path.resolve()
    policy = load_json(policy_path)
    _validate_policy(policy)
    events = _read_jsonl(trace_path)
    findings: list[dict[str, Any]] = []

    if not events:
        findings.append(
            _finding(
                "empty-transcript",
                "error",
                "Transcript contains no reviewable events.",
                [str(trace_path)],
            )
        )

    run_ids = {
        event.get("run_id")
        for event in events
        if isinstance(event.get("run_id"), str) and event.get("run_id")
    }
    if len(run_ids) != 1:
        findings.append(
            _finding(
                "run-identity",
                "error",
                "Transcript must contain exactly one non-empty run_id.",
                sorted(str(item) for item in run_ids),
            )
        )
    run_id = next(iter(run_ids), "unknown")

    sequences = [event.get("sequence") for event in events]
    invalid_sequences = [
        str(sequence)
        for sequence in sequences
        if not isinstance(sequence, int) or sequence < 1
    ]
    if invalid_sequences:
        findings.append(
            _finding(
                "sequence",
                "error",
                "Transcript sequence values must be positive integers.",
                invalid_sequences,
            )
        )
    elif policy["require_monotonic_sequence"] and sequences != sorted(sequences):
        findings.append(
            _finding(
                "sequence",
                "error",
                "Transcript sequence order is not monotonic.",
                [str(sequence) for sequence in sequences],
            )
        )

    grouped: dict[tuple[Any, Any], list[dict[str, Any]]] = defaultdict(list)
    for event in events:
        grouped[(event.get("sequence"), event.get("node_id"))].append(event)
    terminal_statuses = set(policy["terminal_statuses"])
    failed_events = 0
    for (sequence, node_id), node_events in sorted(
        grouped.items(), key=lambda item: (str(item[0][0]), str(item[0][1]))
    ):
        statuses = [event.get("status") for event in node_events]
        evidence = [f"sequence={sequence}", f"node={node_id}", f"statuses={statuses}"]
        if not statuses or statuses[0] != policy["required_start_status"]:
            findings.append(
                _finding(
                    "missing-start",
                    "error",
                    "Node trace does not begin with the required start status.",
                    evidence,
                )
            )
        terminal_events = [
            event for event in node_events if event.get("status") in terminal_statuses
        ]
        if len(terminal_events) != 1:
            findings.append(
                _finding(
                    "terminal-event",
                    "error",
                    "Node trace must contain exactly one terminal event.",
                    evidence,
                )
            )
        for event in terminal_events:
            if event.get("status") == "failed":
                failed_events += 1
            if policy["require_elapsed_ms"]:
                elapsed = event.get("elapsed_ms")
                if not isinstance(elapsed, (int, float)) or elapsed < 0:
                    findings.append(
                        _finding(
                            "elapsed-time",
                            "error",
                            "Terminal event needs a non-negative elapsed_ms value.",
                            evidence,
                        )
                    )

    if failed_events > policy["maximum_failed_events"]:
        findings.append(
            _finding(
                "failed-events",
                "error",
                f"Transcript has {failed_events} failed events; maximum is "
                f"{policy['maximum_failed_events']}.",
                [f"run_id={run_id}"],
            )
        )

    patterns = [item.upper() for item in policy["secret_name_patterns"]]
    secret_keys = sorted(
        {
            key
            for event in events
            for key in _nested_keys(event)
            if any(pattern in key.upper() for pattern in patterns)
        }
    )
    if secret_keys:
        findings.append(
            _finding(
                "secret-shaped-field",
                "critical",
                "Transcript contains secret-shaped field names.",
                secret_keys,
            )
        )

    severities = {finding["severity"] for finding in findings}
    if {"critical", "error"} & severities:
        verdict = "fail"
    elif "warning" in severities:
        verdict = "needs-review"
    else:
        verdict = "pass"

    return {
        "version": PROTOCOL_VERSION,
        "review_id": f"review-{uuid.uuid4().hex}",
        "target_run_id": run_id,
        "trace_path": str(trace_path),
        "policy_id": policy["id"],
        "evaluator_id": evaluator_id,
        "executor_id": executor_id,
        "independent": True,
        "authority": "advisory-only",
        "can_approve": False,
        "can_promote": False,
        "verdict": verdict,
        "findings": findings,
        "metrics": {
            "event_count": len(events),
            "node_count": len(grouped),
            "failed_event_count": failed_events,
            "finding_count": len(findings),
        },
        "reviewed_at": datetime.now(UTC).isoformat(),
    }
