from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from elder_protocol.errors import ProtocolError


REQUIRED_ENVIRONMENT = (
    "AZURE_OPENAI_API_KEY",
    "ELDER_AZURE_OPENAI_ENDPOINT",
    "ELDER_AZURE_OPENAI_V1_BASE_URL",
    "ELDER_AZURE_OPENAI_API_VERSION",
    "ELDER_MEMORY_EXTRACTION_DEPLOYMENT",
    "ELDER_EMBEDDING_DEPLOYMENT",
    "ELDER_EMBEDDING_DIMENSIONS",
    "ELDER_DREAMING_ROUTINE_DEPLOYMENT",
    "ELDER_DREAMING_ROUTINE_REASONING",
    "ELDER_DREAMING_ESCALATION_DEPLOYMENT",
    "ELDER_DREAMING_ESCALATION_REASONING",
)
REASONING_LEVELS = {"low", "medium", "high", "xhigh"}
LUNA_DEPLOYMENT = "gpt-5.6-luna"


@dataclass(frozen=True)
class MemoryRuntimeConfig:
    api_key: str
    azure_endpoint: str
    azure_v1_base_url: str
    api_version: str
    extraction_deployment: str
    embedding_deployment: str
    embedding_dimensions: int
    routine_deployment: str
    routine_reasoning: str
    escalation_deployment: str
    escalation_reasoning: str
    runtime_root: Path

    def public_summary(self) -> dict[str, object]:
        return {
            "azure_endpoint": self.azure_endpoint,
            "azure_v1_base_url": self.azure_v1_base_url,
            "api_version": self.api_version,
            "extraction_deployment": self.extraction_deployment,
            "embedding_deployment": self.embedding_deployment,
            "embedding_dimensions": self.embedding_dimensions,
            "routine_deployment": self.routine_deployment,
            "routine_reasoning": self.routine_reasoning,
            "escalation_deployment": self.escalation_deployment,
            "escalation_reasoning": self.escalation_reasoning,
            "runtime_root": str(self.runtime_root),
            "api_key_configured": True,
        }


def _read_environment_file(path: Path) -> dict[str, str]:
    try:
        from dotenv import dotenv_values
    except ImportError as exc:
        raise ProtocolError(
            "Reading an Elder .env file requires the memory extra. "
            "Install with 'pip install .[memory]'."
        ) from exc
    if not path.is_file():
        raise ProtocolError(f"Elder environment file does not exist: {path}")
    return {
        key: value
        for key, value in dotenv_values(path).items()
        if isinstance(key, str) and isinstance(value, str)
    }


def _validated_url(value: str, label: str, *, required_path: str | None = None) -> str:
    normalized = value.strip().rstrip("/")
    parsed = urlparse(normalized)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ProtocolError(f"{label} must be an absolute HTTPS URL.")
    if parsed.query or parsed.fragment:
        raise ProtocolError(f"{label} cannot contain a query string or fragment.")
    if required_path is None and parsed.path not in {"", "/"}:
        raise ProtocolError(f"{label} cannot contain an API path.")
    if required_path is not None and parsed.path.rstrip("/") != required_path:
        raise ProtocolError(f"{label} must end with '{required_path}'.")
    return normalized


def _runtime_root(project_root: Path) -> Path:
    relative = Path(".elder/runtime/memory")
    if not (project_root / ".elder").is_dir():
        relative = Path(".factory/runtime/memory")
    return (project_root / relative).resolve()


def load_memory_runtime_config(
    project_root: Path,
    *,
    env_file: Path | None = None,
) -> MemoryRuntimeConfig:
    project_root = project_root.resolve()
    selected_env_file = env_file.resolve() if env_file else project_root / ".env"
    values: dict[str, str] = {}
    if selected_env_file.is_file():
        values.update(_read_environment_file(selected_env_file))
    for name in REQUIRED_ENVIRONMENT:
        process_value = os.environ.get(name)
        if process_value:
            values[name] = process_value
    missing = sorted(name for name in REQUIRED_ENVIRONMENT if not values.get(name))
    if missing:
        raise ProtocolError(
            "Elder memory configuration is incomplete; missing: "
            + ", ".join(missing)
        )
    try:
        dimensions = int(values["ELDER_EMBEDDING_DIMENSIONS"])
    except ValueError as exc:
        raise ProtocolError("ELDER_EMBEDDING_DIMENSIONS must be an integer.") from exc
    if dimensions < 1:
        raise ProtocolError("ELDER_EMBEDDING_DIMENSIONS must be positive.")
    routine_reasoning = values["ELDER_DREAMING_ROUTINE_REASONING"].strip().lower()
    escalation_reasoning = values[
        "ELDER_DREAMING_ESCALATION_REASONING"
    ].strip().lower()
    if routine_reasoning not in REASONING_LEVELS:
        raise ProtocolError("Routine dreaming reasoning level is invalid.")
    if escalation_reasoning not in REASONING_LEVELS:
        raise ProtocolError("Escalation dreaming reasoning level is invalid.")
    routine_deployment = values["ELDER_DREAMING_ROUTINE_DEPLOYMENT"].strip()
    escalation_deployment = values[
        "ELDER_DREAMING_ESCALATION_DEPLOYMENT"
    ].strip()
    if routine_deployment != LUNA_DEPLOYMENT or escalation_deployment != LUNA_DEPLOYMENT:
        raise ProtocolError(
            "This Elder release requires gpt-5.6-luna for routine and escalation dreaming."
        )
    azure_endpoint = _validated_url(
        values["ELDER_AZURE_OPENAI_ENDPOINT"],
        "ELDER_AZURE_OPENAI_ENDPOINT",
    )
    azure_v1_base_url = _validated_url(
        values["ELDER_AZURE_OPENAI_V1_BASE_URL"],
        "ELDER_AZURE_OPENAI_V1_BASE_URL",
        required_path="/openai/v1",
    )
    if urlparse(azure_endpoint).hostname != urlparse(azure_v1_base_url).hostname:
        raise ProtocolError(
            "Elder Azure endpoint and v1 base URL must use the same host."
        )
    return MemoryRuntimeConfig(
        api_key=values["AZURE_OPENAI_API_KEY"].strip(),
        azure_endpoint=azure_endpoint,
        azure_v1_base_url=azure_v1_base_url,
        api_version=values["ELDER_AZURE_OPENAI_API_VERSION"].strip(),
        extraction_deployment=values[
            "ELDER_MEMORY_EXTRACTION_DEPLOYMENT"
        ].strip(),
        embedding_deployment=values["ELDER_EMBEDDING_DEPLOYMENT"].strip(),
        embedding_dimensions=dimensions,
        routine_deployment=routine_deployment,
        routine_reasoning=routine_reasoning,
        escalation_deployment=escalation_deployment,
        escalation_reasoning=escalation_reasoning,
        runtime_root=_runtime_root(project_root),
    )
