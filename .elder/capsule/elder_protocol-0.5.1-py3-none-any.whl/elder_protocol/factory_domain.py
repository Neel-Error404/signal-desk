from __future__ import annotations

from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import PROTOCOL_DIR, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.schema_validation import (
    validate_against_schema,
    validate_schema_catalog,
)


FACTORY_DOMAIN_VERSION = "0.1.0"
FACTORY_DIR = ROOT / "factory"
FACTORY_DOMAIN_PATH = FACTORY_DIR / "factory-domain.json"
_VALIDATED_DOMAIN_CONTEXTS: set[tuple[str, str, str]] = set()

REQUIRED_PLANES = {
    "product-owner",
    "factory-operations",
    "worker",
    "elder-governance-learning",
}
REQUIRED_ENTITY_IDS = {
    "product-factory",
    "signal",
    "work-item",
    "work-item-revision",
    "stage-transition",
    "run",
    "worker-session",
    "workspace",
    "command",
    "event",
    "checkpoint",
    "artifact",
    "evidence-record",
    "decision-request",
    "decision",
    "schedule",
    "outcome",
    "learning-candidate",
    "learning-evaluation",
    "promotion",
    "incident",
}
REQUIRED_COMMON_FIELDS = {
    "version",
    "id",
    "entity_type",
    "project_id",
    "actor_identity_id",
    "status",
    "record_version",
    "created_at",
    "updated_at",
    "correlation_id",
    "causation_id",
    "content_sha256",
}
REQUIRED_INVARIANT_IDS = {f"FD-{number:03d}" for number in range(1, 11)}
EVALUATOR_WRITE_ENTITIES = {
    "checkpoint",
    "evidence-record",
    "learning-evaluation",
}
LEARNING_PROMOTION_FIELDS = {
    "candidate_id",
    "candidate_sha256",
    "evaluation_id",
    "evaluation_sha256",
    "approval_ids",
    "approval_digests",
    "approver_identity_ids",
    "action",
    "target_ref",
    "artifact_sha256",
    "promoter_identity_id",
    "applies_target_mutation",
}
WORKER_RECOVERY_FIELDS = {
    "external_session_ref",
    "lease_ref",
    "lease_token_sha256",
    "session_generation",
    "recovery_attempt",
    "checkpoint_cursor",
}


def _require_unique(records: list[dict[str, Any]], key: str, label: str) -> None:
    values = [record[key] for record in records]
    duplicates = sorted(
        value for value, count in Counter(values).items() if count > 1
    )
    if duplicates:
        raise ProtocolError(f"Duplicate {label} ids: {', '.join(duplicates)}")


def _require_exact_ids(
    records: list[dict[str, Any]],
    key: str,
    expected: set[str],
    label: str,
) -> None:
    actual = {record[key] for record in records}
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise ProtocolError(
            f"{label} ids do not match the canonical set; "
            f"missing={missing}, extra={extra}."
        )


def validate_factory_domain_data(
    domain: dict[str, Any],
    *,
    repository_root: Path = ROOT,
    factory_root: Path = FACTORY_DIR,
) -> dict[str, int]:
    preflight_unique = [
        ("planes", "id", "factory plane"),
        ("common_record_fields", "name", "factory common field"),
        ("entities", "id", "factory entity"),
        ("elder_reuse_contracts", "entity_id", "Elder reuse contract"),
        ("ownership", "entity_id", "factory ownership"),
        ("transitions", "id", "factory transition"),
        ("invariants", "id", "factory invariant"),
    ]
    for collection, key, label in preflight_unique:
        records = domain.get(collection)
        if isinstance(records, list) and all(
            isinstance(record, dict) and key in record for record in records
        ):
            _require_unique(records, key, label)

    validate_schema_catalog(factory_root)
    validate_against_schema(
        domain,
        "factory-domain.schema.json",
        label="Canonical factory domain",
        schema_root=factory_root,
    )

    if domain["version"] != FACTORY_DOMAIN_VERSION:
        raise ProtocolError(
            f"Factory domain version must be {FACTORY_DOMAIN_VERSION}."
        )

    _require_unique(domain["planes"], "id", "factory plane")
    _require_unique(domain["common_record_fields"], "name", "factory common field")
    _require_unique(domain["entities"], "id", "factory entity")
    _require_unique(
        domain["elder_reuse_contracts"], "entity_id", "Elder reuse contract"
    )
    _require_unique(domain["ownership"], "entity_id", "factory ownership")
    _require_unique(domain["transitions"], "id", "factory transition")
    _require_unique(domain["invariants"], "id", "factory invariant")

    _require_exact_ids(domain["planes"], "id", REQUIRED_PLANES, "Factory plane")
    _require_exact_ids(
        domain["common_record_fields"],
        "name",
        REQUIRED_COMMON_FIELDS,
        "Factory common field",
    )
    _require_exact_ids(
        domain["entities"], "id", REQUIRED_ENTITY_IDS, "Factory entity"
    )
    _require_exact_ids(
        domain["invariants"],
        "id",
        REQUIRED_INVARIANT_IDS,
        "Factory invariant",
    )

    planes = {plane["id"]: plane for plane in domain["planes"]}
    if planes["worker"]["can_hold_canonical_state"]:
        raise ProtocolError("The worker plane cannot hold canonical factory state.")

    role_records = {
        role["id"]: role
        for role in load_json(PROTOCOL_DIR / "role-registry.json")["roles"]
    }
    roles = set(role_records)
    elder_entities = {
        entity["id"]
        for entity in load_json(PROTOCOL_DIR / "ontology.json")["entity_types"]
    }
    common_fields = {
        field["name"] for field in domain["common_record_fields"]
    }
    entities = {entity["id"]: entity for entity in domain["entities"]}
    schema_references = {
        entity["id"]: entity["reuses_elder_schema"]
        for entity in domain["entities"]
        if entity["reuses_elder_schema"] is not None
    }
    reuse_contracts = {
        contract["entity_id"]: contract
        for contract in domain["elder_reuse_contracts"]
    }
    if set(reuse_contracts) != set(schema_references):
        missing = sorted(set(schema_references) - set(reuse_contracts))
        extra = sorted(set(reuse_contracts) - set(schema_references))
        raise ProtocolError(
            "Elder schema references require exactly one semantic reuse contract; "
            f"missing={missing}, extra={extra}."
        )
    for entity_id, contract in reuse_contracts.items():
        if contract["elder_schema"] != schema_references[entity_id]:
            raise ProtocolError(
                f"Elder reuse contract for '{entity_id}' does not match its "
                "declared schema reference."
            )
        if contract["mode"] != "semantic-reference" or contract["direct_validation"]:
            raise ProtocolError(
                f"Elder reuse contract for '{entity_id}' must reject direct "
                "schema compatibility until an adapter is verified."
            )

    for entity in domain["entities"]:
        entity_id = entity["id"]
        if entity["project_binding"] != "required":
            raise ProtocolError(
                f"Factory entity '{entity_id}' must require project binding."
            )
        statuses = set(entity["statuses"])
        initial = set(entity["initial_statuses"])
        terminal = set(entity["terminal_statuses"])
        required_payload = set(entity["required_payload_fields"])
        optional_payload = set(entity.get("optional_payload_fields", []))
        overlap = sorted(required_payload & optional_payload)
        if overlap:
            raise ProtocolError(
                f"Factory entity '{entity_id}' repeats required payload fields as "
                f"optional: {overlap}"
            )
        if not initial <= statuses:
            raise ProtocolError(
                f"Factory entity '{entity_id}' has unknown initial statuses: "
                f"{sorted(initial - statuses)}"
            )
        if not terminal <= statuses:
            raise ProtocolError(
                f"Factory entity '{entity_id}' has unknown terminal statuses: "
                f"{sorted(terminal - statuses)}"
            )
        reused_entity = entity["reuses_elder_entity"]
        if reused_entity is not None and reused_entity not in elder_entities:
            raise ProtocolError(
                f"Factory entity '{entity_id}' reuses unknown Elder entity "
                f"'{reused_entity}'."
            )
        reused_schema = entity["reuses_elder_schema"]
        if reused_schema is not None:
            schema_path = (repository_root / reused_schema).resolve()
            try:
                schema_path.relative_to(repository_root.resolve())
            except ValueError as exc:
                raise ProtocolError(
                    f"Factory entity '{entity_id}' schema reference escapes the "
                    "repository."
                ) from exc
            if not schema_path.is_file():
                raise ProtocolError(
                    f"Factory entity '{entity_id}' reuses missing schema "
                    f"'{reused_schema}'."
                )
        if entity_id == "promotion" and required_payload != LEARNING_PROMOTION_FIELDS:
            raise ProtocolError(
                "Factory Promotion must bind the complete Elder learning "
                "candidate, evaluation, approval, promoter, action, target, and "
                "target-mutation contract."
            )
        if (
            entity_id == "worker-session"
            and not WORKER_RECOVERY_FIELDS <= required_payload
        ):
            raise ProtocolError(
                "Factory WorkerSession must require lease, generation, recovery, "
                "and checkpoint fencing fields."
            )

    ownership_by_entity = {
        ownership["entity_id"]: ownership for ownership in domain["ownership"]
    }
    if set(ownership_by_entity) != set(entities):
        missing = sorted(set(entities) - set(ownership_by_entity))
        extra = sorted(set(ownership_by_entity) - set(entities))
        raise ProtocolError(
            "Factory ownership must assign exactly one authoritative record per "
            f"entity; missing={missing}, extra={extra}."
        )

    for ownership in domain["ownership"]:
        entity_id = ownership["entity_id"]
        plane_id = ownership["authoritative_plane"]
        if not planes[plane_id]["can_hold_canonical_state"]:
            raise ProtocolError(
                f"Factory entity '{entity_id}' assigns canonical authority to "
                f"non-authoritative plane '{plane_id}'."
            )
        declared_roles = {
            ownership["owner_role"], *ownership["allowed_writer_roles"]
        }
        unknown_roles = sorted(declared_roles - roles)
        if unknown_roles:
            raise ProtocolError(
                f"Factory ownership for '{entity_id}' uses unknown roles: "
                f"{unknown_roles}"
            )
        if (
            "evaluator" in ownership["allowed_writer_roles"]
            and entity_id not in EVALUATOR_WRITE_ENTITIES
        ):
            raise ProtocolError(
                f"Evaluator is advisory-only and cannot write canonical "
                f"'{entity_id}' state."
            )
    transition_signatures: set[tuple[str, str, str]] = set()
    outgoing_statuses: dict[str, set[str]] = {
        entity_id: set() for entity_id in entities
    }
    for transition in domain["transitions"]:
        transition_id = transition["id"]
        entity_id = transition["entity_id"]
        if entity_id not in entities:
            raise ProtocolError(
                f"Factory transition '{transition_id}' references unknown entity "
                f"'{entity_id}'."
            )
        entity = entities[entity_id]
        statuses = set(entity["statuses"])
        terminal = set(entity["terminal_statuses"])
        from_statuses = set(transition["from_statuses"])
        unknown_from = sorted(from_statuses - statuses)
        if unknown_from:
            raise ProtocolError(
                f"Factory transition '{transition_id}' uses unknown source "
                f"statuses: {unknown_from}"
            )
        if transition["to_status"] not in statuses:
            raise ProtocolError(
                f"Factory transition '{transition_id}' targets unknown status "
                f"'{transition['to_status']}'."
            )
        terminal_sources = sorted(from_statuses & terminal)
        if terminal_sources:
            raise ProtocolError(
                f"Factory transition '{transition_id}' illegally leaves terminal "
                f"statuses: {terminal_sources}"
            )
        if transition["to_status"] in from_statuses:
            raise ProtocolError(
                f"Factory transition '{transition_id}' must change status."
            )

        ownership = ownership_by_entity[entity_id]
        authorized_roles = set(transition["authorized_roles"])
        unknown_roles = sorted(authorized_roles - roles)
        if unknown_roles:
            raise ProtocolError(
                f"Factory transition '{transition_id}' uses unknown roles: "
                f"{unknown_roles}"
            )
        unauthorized_roles = sorted(
            authorized_roles - set(ownership["allowed_writer_roles"])
        )
        if unauthorized_roles:
            raise ProtocolError(
                f"Factory transition '{transition_id}' grants ambiguous authority "
                f"outside '{entity_id}' ownership: {unauthorized_roles}"
            )
        if transition["authority"] == "human-approval":
            non_approvers = sorted(
                role_id
                for role_id in authorized_roles
                if not role_records[role_id]["can_approve"]
            )
            if non_approvers:
                raise ProtocolError(
                    f"Factory transition '{transition_id}' grants human approval "
                    f"authority to non-approver roles: {non_approvers}"
                )
        if transition["authority"] == "promotion-only":
            non_promoters = sorted(
                role_id
                for role_id in authorized_roles
                if not role_records[role_id]["can_promote"]
            )
            if non_promoters:
                raise ProtocolError(
                    f"Factory transition '{transition_id}' grants promotion "
                    f"authority to non-promoter roles: {non_promoters}"
                )
        if (
            "evaluator" in authorized_roles
            and entity_id not in EVALUATOR_WRITE_ENTITIES
        ):
            raise ProtocolError(
                f"Factory transition '{transition_id}' lets an advisory evaluator "
                f"mutate canonical '{entity_id}' state."
            )
        declared_payload_fields = set(entity["required_payload_fields"]) | set(
            entity.get("optional_payload_fields", [])
        )
        unknown_fields = sorted(
            set(transition["required_fields"])
            - common_fields
            - declared_payload_fields
        )
        if unknown_fields:
            raise ProtocolError(
                f"Factory transition '{transition_id}' requires undeclared fields: "
                f"{unknown_fields}"
            )

        for from_status in transition["from_statuses"]:
            signature = (
                entity_id,
                from_status,
                transition["trigger"],
            )
            if signature in transition_signatures:
                raise ProtocolError(
                    "Ambiguous factory transition trigger: "
                    f"{entity_id}/{from_status}/{transition['trigger']}"
                )
            transition_signatures.add(signature)
            outgoing_statuses[entity_id].add(from_status)

    for entity_id, entity in entities.items():
        nonterminal = set(entity["statuses"]) - set(entity["terminal_statuses"])
        missing_outgoing = sorted(nonterminal - outgoing_statuses[entity_id])
        if missing_outgoing:
            raise ProtocolError(
                f"Factory entity '{entity_id}' has nonterminal statuses without "
                f"declared transitions: {missing_outgoing}"
            )
        entity_transitions = [
            transition
            for transition in domain["transitions"]
            if transition["entity_id"] == entity_id
        ]
        reachable = set(entity["initial_statuses"])
        changed = True
        while changed:
            changed = False
            for transition in entity_transitions:
                if reachable.intersection(transition["from_statuses"]):
                    if transition["to_status"] not in reachable:
                        reachable.add(transition["to_status"])
                        changed = True
        unreachable = sorted(set(entity["statuses"]) - reachable)
        if unreachable:
            raise ProtocolError(
                f"Factory entity '{entity_id}' has unreachable statuses: "
                f"{unreachable}"
            )

    recovery_transition = next(
        transition
        for transition in domain["transitions"]
        if transition["id"] == "worker-session-recover"
    )
    if not WORKER_RECOVERY_FIELDS <= set(recovery_transition["required_fields"]):
        raise ProtocolError(
            "Worker-session recovery must bind the current lease, generation, "
            "attempt, and checkpoint cursor."
        )

    candidate_transitions = {
        transition["id"]: transition
        for transition in domain["transitions"]
        if transition["entity_id"] == "learning-candidate"
    }
    if not {
        "evaluation_id",
        "evaluation_sha256",
        "approval_refs",
    } <= set(candidate_transitions["learning-candidate-approve"]["required_fields"]):
        raise ProtocolError(
            "Learning-candidate approval must bind independent evaluation and "
            "accountable approval records."
        )
    for transition_id in [
        "learning-candidate-promote",
        "learning-candidate-rollback",
    ]:
        if not {"promotion_id", "promotion_sha256"} <= set(
            candidate_transitions[transition_id]["required_fields"]
        ):
            raise ProtocolError(
                f"Factory transition '{transition_id}' must bind the immutable "
                "promotion packet."
            )

    _VALIDATED_DOMAIN_CONTEXTS.add(
        (
            canonical_sha256(domain),
            str(repository_root.resolve()),
            str(factory_root.resolve()),
        )
    )
    return {
        "planes": len(domain["planes"]),
        "entities": len(domain["entities"]),
        "ownership_records": len(domain["ownership"]),
        "transitions": len(domain["transitions"]),
        "invariants": len(domain["invariants"]),
    }


def validate_factory_domain(
    path: Path = FACTORY_DOMAIN_PATH,
) -> dict[str, Any]:
    domain = load_json(path)
    validate_factory_domain_data(
        domain,
        repository_root=path.resolve().parent.parent,
        factory_root=path.resolve().parent,
    )
    return domain


def _parse_datetime(value: str, field_name: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ProtocolError(
            f"Factory entity field '{field_name}' must be an ISO-8601 date-time."
        ) from exc
    if parsed.tzinfo is None:
        raise ProtocolError(
            f"Factory entity field '{field_name}' must include a timezone."
        )
    return parsed


def factory_entity_content_sha256(record: dict[str, Any]) -> str:
    return canonical_sha256(
        {
            key: value
            for key, value in record.items()
            if key != "content_sha256"
        }
    )


def validate_factory_entity_data(
    record: dict[str, Any],
    *,
    domain: dict[str, Any] | None = None,
    repository_root: Path = ROOT,
    factory_root: Path = FACTORY_DIR,
) -> dict[str, Any]:
    if domain is None:
        domain = load_json(factory_root / "factory-domain.json")
    domain_context = (
        canonical_sha256(domain),
        str(repository_root.resolve()),
        str(factory_root.resolve()),
    )
    if domain_context not in _VALIDATED_DOMAIN_CONTEXTS:
        validate_factory_domain_data(
            domain,
            repository_root=repository_root,
            factory_root=factory_root,
        )
    validate_against_schema(
        record,
        "factory-entity.schema.json",
        label="Factory entity record",
        schema_root=factory_root,
    )

    entities = {entity["id"]: entity for entity in domain["entities"]}
    entity_type = record["entity_type"]
    if entity_type not in entities:
        raise ProtocolError(
            f"Factory entity record uses unknown entity_type '{entity_type}'."
        )
    entity = entities[entity_type]
    if record["status"] not in entity["statuses"]:
        raise ProtocolError(
            f"Factory entity '{entity_type}' uses unknown status "
            f"'{record['status']}'."
        )

    payload = record["payload"]
    required_payload = set(entity["required_payload_fields"])
    optional_payload = set(entity.get("optional_payload_fields", []))
    missing_payload = sorted(required_payload - set(payload))
    if missing_payload:
        raise ProtocolError(
            f"Factory entity '{entity_type}' is missing required payload fields: "
            f"{missing_payload}"
        )
    unknown_payload = sorted(set(payload) - required_payload - optional_payload)
    if unknown_payload:
        raise ProtocolError(
            f"Factory entity '{entity_type}' has undeclared payload fields: "
            f"{unknown_payload}"
        )

    created_at = _parse_datetime(record["created_at"], "created_at")
    updated_at = _parse_datetime(record["updated_at"], "updated_at")
    if updated_at < created_at:
        raise ProtocolError(
            "Factory entity updated_at cannot be earlier than created_at."
        )

    immutable_at_creation = (
        set(entity["statuses"]) == set(entity["terminal_statuses"])
    )
    if immutable_at_creation and record["content_sha256"] is None:
        raise ProtocolError(
            f"Immutable factory entity '{entity_type}' requires content_sha256."
        )
    if (
        record["content_sha256"] is not None
        and record["content_sha256"] != factory_entity_content_sha256(record)
    ):
        raise ProtocolError(
            f"Factory entity '{entity_type}' content_sha256 does not bind its "
            "canonical record content."
        )
    if (
        entity_type == "promotion"
        and payload["applies_target_mutation"] is not False
    ):
        raise ProtocolError(
            "Factory Promotion must set applies_target_mutation to false."
        )
    if entity_type == "decision" and payload.get("supersedes_decision_id") == record["id"]:
        raise ProtocolError("Factory Decision cannot supersede itself.")
    if entity_type == "learning-candidate":
        if record["status"] in {"approved", "promoted", "rolled-back"}:
            missing_approval = sorted(
                {"evaluation_id", "evaluation_sha256", "approval_refs"}
                - set(payload)
            )
            if missing_approval:
                raise ProtocolError(
                    "Approved learning candidate is missing evaluation or "
                    f"approval bindings: {missing_approval}"
                )
        if record["status"] in {"promoted", "rolled-back"}:
            missing_promotion = sorted(
                {"promotion_id", "promotion_sha256"} - set(payload)
            )
            if missing_promotion:
                raise ProtocolError(
                    "Promoted learning candidate is missing promotion packet "
                    f"bindings: {missing_promotion}"
                )
    if entity_type == "promotion":
        approval_ids = payload["approval_ids"]
        approval_digests = payload["approval_digests"]
        approver_identity_ids = payload["approver_identity_ids"]
        if (
            not isinstance(approval_ids, list)
            or not isinstance(approval_digests, list)
            or not isinstance(approver_identity_ids, list)
            or not approval_ids
            or len(approval_ids) != len(approval_digests)
            or len(approval_ids) != len(approver_identity_ids)
        ):
            raise ProtocolError(
                "Factory Promotion requires equally sized non-empty approval "
                "identifier, digest, and approver identity lists."
            )
        for label, values in [
            ("approval_ids", approval_ids),
            ("approver_identity_ids", approver_identity_ids),
        ]:
            if (
                any(not isinstance(value, str) or not value for value in values)
                or len(values) != len(set(values))
            ):
                raise ProtocolError(
                    f"Factory Promotion {label} must contain unique non-empty strings."
                )
        for digest in approval_digests:
            if (
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
            ):
                raise ProtocolError(
                    "Factory Promotion approval_digests must contain lowercase "
                    "SHA-256 digests."
                )
        if payload["promoter_identity_id"] in set(approver_identity_ids):
            raise ProtocolError(
                "Factory Promotion promoter identity must be separate from approvers."
            )
        if payload["action"] not in {"promote", "rollback"}:
            raise ProtocolError(
                "Factory Promotion action must be 'promote' or 'rollback'."
            )
    if entity_type == "worker-session":
        if (
            type(payload["session_generation"]) is not int
            or payload["session_generation"] < 1
        ):
            raise ProtocolError(
                "WorkerSession session_generation must be a positive integer."
            )
        if (
            type(payload["recovery_attempt"]) is not int
            or payload["recovery_attempt"] < 0
        ):
            raise ProtocolError(
                "WorkerSession recovery_attempt must be a non-negative integer."
            )
        lease_token_sha256 = payload["lease_token_sha256"]
        if (
            not isinstance(lease_token_sha256, str)
            or len(lease_token_sha256) != 64
            or any(character not in "0123456789abcdef" for character in lease_token_sha256)
        ):
            raise ProtocolError(
                "WorkerSession lease_token_sha256 must be a lowercase SHA-256 digest."
            )
    return record


def validate_learning_chain_data(
    candidate: dict[str, Any],
    evaluation: dict[str, Any],
    promotion: dict[str, Any],
    approvals: list[dict[str, Any]],
    *,
    domain: dict[str, Any] | None = None,
    repository_root: Path = ROOT,
    factory_root: Path = FACTORY_DIR,
) -> None:
    if domain is None:
        domain = load_json(factory_root / "factory-domain.json")
    for expected_type, record in [
        ("learning-candidate", candidate),
        ("learning-evaluation", evaluation),
        ("promotion", promotion),
    ]:
        validate_factory_entity_data(
            record,
            domain=domain,
            repository_root=repository_root,
            factory_root=factory_root,
        )
        if record["entity_type"] != expected_type:
            raise ProtocolError(
                f"Learning chain expected '{expected_type}', received "
                f"'{record['entity_type']}'."
            )
        if record["content_sha256"] is None:
            raise ProtocolError(
                f"Learning chain record '{expected_type}' requires content_sha256."
            )

    candidate_payload = candidate["payload"]
    evaluation_payload = evaluation["payload"]
    promotion_payload = promotion["payload"]
    if evaluation["status"] != "qualified":
        raise ProtocolError(
            "Learning promotion requires a qualified evaluation."
        )
    expected_candidate_status: str
    expected_action: str
    if promotion["status"] == "applied":
        expected_candidate_status = "promoted"
        expected_action = "promote"
    elif promotion["status"] == "rolled-back":
        expected_candidate_status = "rolled-back"
        expected_action = "rollback"
    else:
        raise ProtocolError(
            "Learning chain requires an applied or rolled-back promotion."
        )
    if candidate["status"] != expected_candidate_status:
        raise ProtocolError(
            "Learning candidate status does not match promotion lifecycle."
        )
    if promotion_payload["action"] != expected_action:
        raise ProtocolError(
            "Learning promotion action does not match promotion status."
        )

    candidate_artifact_sha256 = candidate_payload["artifact_sha256"]
    if evaluation_payload["candidate_id"] != candidate["id"]:
        raise ProtocolError("Learning evaluation candidate_id does not match candidate.")
    if evaluation_payload["candidate_sha256"] != candidate_artifact_sha256:
        raise ProtocolError(
            "Learning evaluation candidate_sha256 does not match candidate artifact."
        )
    if promotion_payload["candidate_id"] != candidate["id"]:
        raise ProtocolError("Promotion candidate_id does not match candidate.")
    if promotion_payload["candidate_sha256"] != candidate_artifact_sha256:
        raise ProtocolError(
            "Promotion candidate_sha256 does not match candidate artifact."
        )
    if promotion_payload["artifact_sha256"] != candidate_artifact_sha256:
        raise ProtocolError(
            "Promotion artifact_sha256 does not match candidate artifact."
        )
    if promotion_payload["target_ref"] != candidate_payload["target_ref"]:
        raise ProtocolError(
            "Promotion target_ref does not match candidate target."
        )
    if promotion_payload["evaluation_id"] != evaluation["id"]:
        raise ProtocolError("Promotion evaluation_id does not match evaluation.")
    if promotion_payload["evaluation_sha256"] != evaluation["content_sha256"]:
        raise ProtocolError(
            "Promotion evaluation_sha256 does not match evaluation digest."
        )
    if candidate_payload.get("evaluation_id") != evaluation["id"]:
        raise ProtocolError(
            "Learning candidate does not bind the independent evaluation id."
        )
    if candidate_payload.get("evaluation_sha256") != evaluation["content_sha256"]:
        raise ProtocolError(
            "Learning candidate does not bind the independent evaluation digest."
        )
    if candidate_payload.get("promotion_id") != promotion["id"]:
        raise ProtocolError("Learning candidate does not bind the promotion id.")
    if candidate_payload.get("promotion_sha256") != promotion["content_sha256"]:
        raise ProtocolError("Learning candidate does not bind the promotion digest.")
    if set(candidate_payload["approval_refs"]) != set(
        promotion_payload["approval_ids"]
    ):
        raise ProtocolError(
            "Learning candidate approval_refs do not match promotion approvals."
        )

    approval_ids = promotion_payload["approval_ids"]
    approval_digests = promotion_payload["approval_digests"]
    approver_identity_ids = promotion_payload["approver_identity_ids"]
    if len(approvals) != len(approval_ids):
        raise ProtocolError(
            "Learning chain approval records do not match promotion approvals."
        )
    role_records = {
        role["id"]: role
        for role in load_json(PROTOCOL_DIR / "role-registry.json")["roles"]
    }
    approval_records = {approval["id"]: approval for approval in approvals}
    if set(approval_records) != set(approval_ids):
        raise ProtocolError(
            "Learning chain approval record ids do not match promotion approvals."
        )
    for index, approval_id in enumerate(approval_ids):
        approval = approval_records[approval_id]
        validate_factory_entity_data(
            approval,
            domain=domain,
            repository_root=repository_root,
            factory_root=factory_root,
        )
        if approval["entity_type"] != "decision":
            raise ProtocolError("Learning chain approvals must be Decision records.")
        if approval["content_sha256"] != approval_digests[index]:
            raise ProtocolError(
                "Learning chain approval digest does not match approval content."
            )
        if approval["project_id"] != candidate["project_id"]:
            raise ProtocolError(
                "Learning chain approvals must belong to the candidate project."
            )
        if (
            approval["status"] != "approved"
            or approval["payload"]["decision"] != "approved"
            or approval["payload"]["subject_sha256"] != candidate_artifact_sha256
        ):
            raise ProtocolError(
                "Learning promotion requires approved decisions bound to the "
                "candidate artifact."
            )
        if approval["payload"]["decided_by"] != approver_identity_ids[index]:
            raise ProtocolError(
                "Learning chain approver identity does not match promotion packet."
            )
        approval_role = approval["payload"]["decided_as_role"]
        if (
            approval_role not in role_records
            or not role_records[approval_role]["can_approve"]
        ):
            raise ProtocolError(
                "Learning chain approval role lacks approval authority."
            )

    creator = candidate_payload["created_by"]
    evaluator = evaluation_payload["evaluator_id"]
    promoter = promotion_payload["promoter_identity_id"]
    if len({creator, evaluator, promoter}) != 3:
        raise ProtocolError(
            "Learning creator, evaluator, and promoter identities must be distinct."
        )
    approvers = set(promotion_payload["approver_identity_ids"])
    overlapping_roles = sorted({creator, evaluator, promoter} & approvers)
    if overlapping_roles:
        raise ProtocolError(
            "Learning creator, evaluator, promoter, and approver identities must "
            f"be separate: {overlapping_roles}"
        )


def validate_decision_supersession_data(
    previous: dict[str, Any],
    replacement: dict[str, Any],
    *,
    domain: dict[str, Any] | None = None,
    repository_root: Path = ROOT,
    factory_root: Path = FACTORY_DIR,
) -> None:
    if domain is None:
        domain = load_json(factory_root / "factory-domain.json")
    for label, record in [
        ("Previous decision", previous),
        ("Replacement decision", replacement),
    ]:
        validate_factory_entity_data(
            record,
            domain=domain,
            repository_root=repository_root,
            factory_root=factory_root,
        )
        if record["entity_type"] != "decision":
            raise ProtocolError(f"{label} must be a Decision record.")
        if record["content_sha256"] is None:
            raise ProtocolError(f"{label} requires content_sha256.")

    if replacement["payload"].get("supersedes_decision_id") != previous["id"]:
        raise ProtocolError(
            "Replacement decision must bind supersedes_decision_id to the "
            "previous decision."
        )
    if replacement["project_id"] != previous["project_id"]:
        raise ProtocolError(
            "Superseding decisions must belong to the same project."
        )
    if (
        replacement["payload"]["decision_request_id"]
        != previous["payload"]["decision_request_id"]
        or replacement["payload"]["subject_sha256"]
        != previous["payload"]["subject_sha256"]
    ):
        raise ProtocolError(
            "Superseding decisions must bind the same request and subject digest."
        )
    if _parse_datetime(
        replacement["created_at"], "replacement.created_at"
    ) <= _parse_datetime(previous["created_at"], "previous.created_at"):
        raise ProtocolError(
            "Replacement decision must be later than the previous decision."
        )
