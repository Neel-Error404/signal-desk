from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import PurePosixPath
from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError


REQUIRED_CANONICAL_ROLES = {
    "human-owner",
    "product-owner",
    "architecture-owner",
    "security-owner",
    "release-owner",
    "code-owner",
    "executor",
    "evaluator",
    "promoter",
}
HUMAN_APPROVAL_ROLES = {
    "human-owner",
    "product-owner",
    "architecture-owner",
    "security-owner",
    "release-owner",
    "code-owner",
}


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _require_exact_fields(
    value: Any,
    required: set[str],
    label: str,
) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProtocolError(f"{label} must be an object.")
    if set(value) != required:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(required)}")
    return value


def _require_string_list(
    value: Any,
    label: str,
    *,
    allow_empty: bool = False,
) -> list[str]:
    if (
        not isinstance(value, list)
        or any(not isinstance(item, str) or not item.strip() for item in value)
        or len(value) != len(set(value))
    ):
        raise ProtocolError(f"{label} must be a unique list of non-empty strings.")
    if not allow_empty and not value:
        raise ProtocolError(f"{label} must not be empty.")
    return value


def _parse_datetime(value: Any, label: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ProtocolError(f"{label} must be an ISO-8601 date-time.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO-8601 date-time.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


def _normalized_scope(value: str, label: str) -> str:
    normalized = value.replace("\\", "/").strip("/")
    path = PurePosixPath(normalized)
    if (
        not normalized
        or path.is_absolute()
        or ".." in path.parts
        or "." in path.parts
    ):
        raise ProtocolError(f"{label} must be a relative normalized scope.")
    return path.as_posix()


def _scope_is_within(candidate: str, parent: str) -> bool:
    child_path = PurePosixPath(candidate)
    parent_path = PurePosixPath(parent)
    return child_path == parent_path or parent_path in child_path.parents


def _validate_budget(value: Any, label: str) -> dict[str, Any]:
    budget = _require_exact_fields(
        value,
        {
            "token_limit",
            "cost_limit_usd",
            "tool_call_limit",
            "elapsed_seconds_limit",
        },
        label,
    )
    for field in ["token_limit", "tool_call_limit", "elapsed_seconds_limit"]:
        if not isinstance(budget[field], int) or budget[field] < 0:
            raise ProtocolError(f"{label}.{field} must be a non-negative integer.")
    if (
        not isinstance(budget["cost_limit_usd"], (int, float))
        or budget["cost_limit_usd"] < 0
    ):
        raise ProtocolError(f"{label}.cost_limit_usd must be non-negative.")
    return budget


def validate_role_registry(registry: dict[str, Any]) -> dict[str, Any]:
    _require_exact_fields(registry, {"version", "roles"}, "Role registry")
    if registry["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Role registry version must be '{PROTOCOL_VERSION}'."
        )
    roles = registry["roles"]
    if not isinstance(roles, list) or not roles:
        raise ProtocolError("Role registry must define roles.")
    ids: list[str] = []
    aliases: set[str] = set()
    valid_kinds = {"human", "agent", "function"}
    for role in roles:
        _require_exact_fields(
            role,
            {
                "id",
                "kind",
                "allowed_identity_kinds",
                "aliases",
                "responsibilities",
                "can_delegate",
                "can_approve",
                "can_promote",
            },
            "Role",
        )
        if not isinstance(role["id"], str) or not role["id"]:
            raise ProtocolError("Every role requires a non-empty id.")
        if role["kind"] not in valid_kinds:
            raise ProtocolError(f"Role '{role['id']}' has an invalid kind.")
        allowed_identity_kinds = _require_string_list(
            role["allowed_identity_kinds"],
            f"Role '{role['id']}' allowed_identity_kinds",
        )
        if set(allowed_identity_kinds) - {"human", "agent", "service"}:
            raise ProtocolError(
                f"Role '{role['id']}' has invalid allowed identity kinds."
            )
        role_aliases = _require_string_list(
            role["aliases"],
            f"Role '{role['id']}' aliases",
            allow_empty=True,
        )
        _require_string_list(
            role["responsibilities"],
            f"Role '{role['id']}' responsibilities",
        )
        if any(not isinstance(role[field], bool) for field in [
            "can_delegate",
            "can_approve",
            "can_promote",
        ]):
            raise ProtocolError(f"Role '{role['id']}' capability flags must be booleans.")
        overlap = aliases & set(role_aliases)
        if overlap:
            raise ProtocolError(f"Duplicate role aliases: {sorted(overlap)}")
        aliases.update(role_aliases)
        ids.append(role["id"])
    if len(ids) != len(set(ids)):
        raise ProtocolError("Role ids must be unique.")
    missing = REQUIRED_CANONICAL_ROLES - set(ids)
    if missing:
        raise ProtocolError(f"Role registry is missing canonical roles: {sorted(missing)}")
    collision = set(ids) & aliases
    if collision:
        raise ProtocolError(
            f"Role aliases cannot collide with canonical roles: {sorted(collision)}"
        )
    return registry


def validate_project_identities(
    profile: dict[str, Any],
    role_registry: dict[str, Any],
) -> None:
    validate_role_registry(role_registry)
    roles = {role["id"]: role for role in role_registry["roles"]}
    identities = profile["identities"]
    bindings = profile["role_bindings"]
    if not isinstance(identities, list) or not identities:
        raise ProtocolError("Project profile identities must not be empty.")
    identity_by_id: dict[str, dict[str, Any]] = {}
    for identity in identities:
        _require_exact_fields(identity, {"id", "kind"}, "Project identity")
        if (
            not isinstance(identity["id"], str)
            or not identity["id"].strip()
            or identity["kind"] not in {"human", "agent", "service"}
        ):
            raise ProtocolError("Project identities need a non-empty id and valid kind.")
        if identity["id"] in identity_by_id:
            raise ProtocolError(f"Duplicate project identity: {identity['id']}")
        identity_by_id[identity["id"]] = identity

    if not isinstance(bindings, list) or not bindings:
        raise ProtocolError("Project profile role_bindings must not be empty.")
    binding_by_role: dict[str, str] = {}
    for binding in bindings:
        _require_exact_fields(binding, {"role", "identity"}, "Role binding")
        role_id = binding["role"]
        identity_id = binding["identity"]
        if role_id not in roles:
            raise ProtocolError(f"Role binding uses unknown canonical role '{role_id}'.")
        if identity_id not in identity_by_id:
            raise ProtocolError(
                f"Role '{role_id}' binds unknown identity '{identity_id}'."
            )
        if role_id in binding_by_role:
            raise ProtocolError(f"Role '{role_id}' is bound more than once.")
        identity_kind = identity_by_id[identity_id]["kind"]
        if identity_kind not in roles[role_id]["allowed_identity_kinds"]:
            raise ProtocolError(
                f"Role '{role_id}' cannot bind identity kind '{identity_kind}'."
            )
        binding_by_role[role_id] = identity_id

    required_roles = {role["id"] for role in role_registry["roles"]}
    missing = required_roles - binding_by_role.keys()
    if missing:
        raise ProtocolError(f"Project profile is missing role bindings: {sorted(missing)}")
    if binding_by_role["executor"] == binding_by_role["evaluator"]:
        raise ProtocolError("Executor and evaluator must bind different identities.")
    if binding_by_role["executor"] == binding_by_role["promoter"]:
        raise ProtocolError("Executor and promoter must bind different identities.")
    if binding_by_role["evaluator"] == binding_by_role["promoter"]:
        raise ProtocolError("Evaluator and promoter must bind different identities.")


def identity_for_role(profile: dict[str, Any], role_id: str) -> str:
    for binding in profile["role_bindings"]:
        if binding["role"] == role_id:
            return binding["identity"]
    raise ProtocolError(f"Project profile has no identity bound to role '{role_id}'.")


def resolve_authority_bindings(
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> dict[str, Any]:
    validate_project_identities(profile, role_registry)
    grants: list[dict[str, Any]] = []
    for resource in sorted(authority_matrix["resources"], key=lambda item: item["id"]):
        for role_id, actions in sorted(resource["permissions"].items()):
            grants.append(
                {
                    "id": f"{role_id}:{resource['id']}",
                    "role": role_id,
                    "identity": identity_for_role(profile, role_id),
                    "resource": resource["id"],
                    "actions": sorted(actions),
                }
            )
    resolved = {
        "version": PROTOCOL_VERSION,
        "project_id": profile["slug"],
        "source_profile_sha256": _sha256(profile),
        "source_role_registry_sha256": _sha256(role_registry),
        "source_authority_matrix_sha256": _sha256(authority_matrix),
        "identities": sorted(profile["identities"], key=lambda item: item["id"]),
        "role_bindings": sorted(
            profile["role_bindings"], key=lambda item: item["role"]
        ),
        "grants": grants,
    }
    resolved["content_sha256"] = _sha256(resolved)
    return resolved


def validate_authority_bindings(
    authority_bindings: dict[str, Any],
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> dict[str, Any]:
    expected = resolve_authority_bindings(profile, role_registry, authority_matrix)
    if authority_bindings != expected:
        raise ProtocolError(
            "Resolved project authority bindings do not match their authoritative sources."
        )
    return authority_bindings


def resolve_obligations(
    profile: dict[str, Any],
    packs: list[dict[str, Any]],
    resolved_pack_ids: list[str],
) -> dict[str, Any]:
    selected = set(resolved_pack_ids)
    obligations: list[dict[str, Any]] = []
    for pack in sorted(packs, key=lambda item: item["id"]):
        if pack["id"] not in selected:
            continue
        owner_role = pack["obligation_owner_role"]
        owner_identity = identity_for_role(profile, owner_role)
        for artifact_type in sorted(pack["required_artifacts"]):
            obligations.append(
                {
                    "id": f"{pack['id']}.{artifact_type}",
                    "pack": pack["id"],
                    "owner_role": owner_role,
                    "owner_identity": owner_identity,
                    "artifact_type": artifact_type,
                    "required_evidence": sorted(pack["required_evidence"]),
                    "evidence_refs": [],
                    "status": "declared",
                }
            )
    return {
        "version": PROTOCOL_VERSION,
        "project_id": profile["slug"],
        "source_profile_sha256": _sha256(profile),
        "obligations": obligations,
    }


def validate_resolved_obligations(
    resolved: dict[str, Any],
    profile: dict[str, Any],
    packs: list[dict[str, Any]],
    resolved_pack_ids: list[str],
) -> None:
    expected = resolve_obligations(profile, packs, resolved_pack_ids)
    if resolved != expected:
        raise ProtocolError(
            "Resolved obligations do not match the selected capability-pack contract."
        )


def validate_stack_adapter_registry(
    registry: dict[str, Any],
    packs: list[dict[str, Any]],
) -> dict[str, Any]:
    _require_exact_fields(registry, {"version", "adapters"}, "Stack-adapter registry")
    if registry["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Stack-adapter registry version must be '{PROTOCOL_VERSION}'."
        )
    pack_by_id = {pack["id"]: pack for pack in packs}
    ids: set[str] = set()
    for adapter in registry["adapters"]:
        _require_exact_fields(
            adapter,
            {
                "id",
                "pack",
                "adapter_point",
                "technology",
                "contract",
                "implementation",
                "status",
                "required_evidence",
            },
            "Stack adapter",
        )
        if adapter["id"] in ids:
            raise ProtocolError(f"Duplicate stack adapter: {adapter['id']}")
        ids.add(adapter["id"])
        if adapter["pack"] not in pack_by_id:
            raise ProtocolError(
                f"Stack adapter '{adapter['id']}' uses unknown pack '{adapter['pack']}'."
            )
        if adapter["adapter_point"] not in pack_by_id[adapter["pack"]]["adapter_points"]:
            raise ProtocolError(
                f"Stack adapter '{adapter['id']}' uses an undeclared adapter point."
            )
        if adapter["status"] not in {
            "specified",
            "reference-only",
            "operational-local",
        }:
            raise ProtocolError(
                f"Stack adapter '{adapter['id']}' has an invalid runtime status."
            )
        _require_string_list(
            adapter["required_evidence"],
            f"Stack adapter '{adapter['id']}' required_evidence",
        )
    return registry


def validate_delegation_policy(policy: dict[str, Any]) -> dict[str, Any]:
    _require_exact_fields(
        policy,
        {
            "version",
            "id",
            "authority_ceilings",
            "forbidden_delegated_actions",
            "rules",
            "cancellation",
            "message_effect",
        },
        "Delegation policy",
    )
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Delegation policy version must be '{PROTOCOL_VERSION}'."
        )
    if not isinstance(policy["authority_ceilings"], dict):
        raise ProtocolError("Delegation policy authority_ceilings must be an object.")
    for ceiling, actions in policy["authority_ceilings"].items():
        _require_string_list(actions, f"Authority ceiling '{ceiling}'")
    forbidden = set(
        _require_string_list(
            policy["forbidden_delegated_actions"],
            "Delegation policy forbidden_delegated_actions",
        )
    )
    if not {"approve", "promote"} <= forbidden:
        raise ProtocolError("Delegated authority must forbid approve and promote.")
    _require_string_list(policy["rules"], "Delegation policy rules")
    if policy["cancellation"] != {"propagate_to_active_children": True}:
        raise ProtocolError("Delegation cancellation must propagate to active children.")
    if policy["message_effect"] != "none":
        raise ProtocolError("Messages cannot mutate governed state directly.")
    return policy


def _validate_authority_grants(
    grants: Any,
    label: str,
) -> list[dict[str, Any]]:
    if not isinstance(grants, list) or not grants:
        raise ProtocolError(f"{label} must contain authority grants.")
    seen: set[str] = set()
    normalized: list[dict[str, Any]] = []
    for grant in grants:
        _require_exact_fields(grant, {"resource", "actions"}, "Authority grant")
        if not isinstance(grant["resource"], str) or not grant["resource"]:
            raise ProtocolError("Authority grant resource must be non-empty.")
        actions = sorted(_require_string_list(grant["actions"], "Authority grant actions"))
        if grant["resource"] in seen:
            raise ProtocolError(
                f"{label} repeats authority resource '{grant['resource']}'."
            )
        seen.add(grant["resource"])
        normalized.append({"resource": grant["resource"], "actions": actions})
    return sorted(normalized, key=lambda item: item["resource"])


def _resolved_project_grants(
    authority_bindings: dict[str, Any],
    *,
    project_id: str,
    identity_id: str,
    role: str,
    label: str,
) -> dict[str, set[str]]:
    if authority_bindings.get("project_id") != project_id:
        raise ProtocolError(f"{label} project does not match resolved project authority.")
    role_bindings = authority_bindings.get("role_bindings")
    if not isinstance(role_bindings, list):
        raise ProtocolError("Resolved project authority role_bindings must be a list.")
    matching_bindings = [
        binding
        for binding in role_bindings
        if isinstance(binding, dict) and binding.get("role") == role
    ]
    if len(matching_bindings) != 1 or matching_bindings[0].get("identity") != identity_id:
        raise ProtocolError(
            f"{label} identity and role do not match resolved project authority."
        )

    grants = authority_bindings.get("grants")
    if not isinstance(grants, list):
        raise ProtocolError("Resolved project authority grants must be a list.")
    resolved: dict[str, set[str]] = {}
    for grant in grants:
        if (
            not isinstance(grant, dict)
            or grant.get("role") != role
            or grant.get("identity") != identity_id
        ):
            continue
        resource = grant.get("resource")
        actions = grant.get("actions")
        if (
            not isinstance(resource, str)
            or not resource
            or not isinstance(actions, list)
            or any(not isinstance(action, str) or not action for action in actions)
        ):
            raise ProtocolError("Resolved project authority contains an invalid grant.")
        if resource in resolved:
            raise ProtocolError(
                f"Resolved project authority repeats resource '{resource}' for {label}."
            )
        resolved[resource] = set(actions)
    return resolved


def _validate_run_authority(
    run: dict[str, Any],
    authority_bindings: dict[str, Any],
    *,
    label: str,
) -> dict[str, set[str]]:
    resolved = _resolved_project_grants(
        authority_bindings,
        project_id=run["project_id"],
        identity_id=run["identity_id"],
        role=run["role"],
        label=label,
    )
    claimed = {
        grant["resource"]: set(grant["actions"])
        for grant in _validate_authority_grants(
        run["authority_grants"],
        f"{label} authority_grants",
        )
    }
    for resource, actions in claimed.items():
        if not actions <= resolved.get(resource, set()):
            raise ProtocolError(
                f"{label} authority for '{resource}' exceeds resolved project authority."
            )
    if "delegate" not in claimed.get("delegation", set()):
        raise ProtocolError(
            f"{label} must explicitly claim delegation authority to delegate."
        )
    return resolved


def _validate_run(run: dict[str, Any], label: str) -> None:
    required = {
        "version",
        "id",
        "project_id",
        "work_item_id",
        "identity_id",
        "role",
        "parent_run_id",
        "delegation_id",
        "model",
        "scope",
        "authority_grants",
        "tool_grants",
        "context_packet_id",
        "actions",
        "outputs",
        "budget",
        "deadline",
        "started_at",
        "completed_at",
        "cancellation_status",
        "status",
    }
    _require_exact_fields(run, required, label)
    if run["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"{label} version must be '{PROTOCOL_VERSION}'.")
    for field in [
        "id",
        "project_id",
        "work_item_id",
        "identity_id",
        "role",
        "model",
        "context_packet_id",
    ]:
        if not isinstance(run[field], str) or not run[field]:
            raise ProtocolError(f"{label}.{field} must be non-empty.")
    normalized_scope = [
        _normalized_scope(item, f"{label}.scope")
        for item in _require_string_list(run["scope"], f"{label}.scope")
    ]
    if normalized_scope != run["scope"]:
        raise ProtocolError(f"{label}.scope must already be normalized.")
    _validate_authority_grants(run["authority_grants"], f"{label}.authority_grants")
    _require_string_list(run["tool_grants"], f"{label}.tool_grants", allow_empty=True)
    _validate_budget(run["budget"], f"{label}.budget")
    _parse_datetime(run["deadline"], f"{label}.deadline")
    _parse_datetime(run["started_at"], f"{label}.started_at")
    if run["completed_at"] is not None:
        _parse_datetime(run["completed_at"], f"{label}.completed_at")
    if run["cancellation_status"] not in {"active", "requested", "cancelled"}:
        raise ProtocolError(f"{label} has an invalid cancellation_status.")
    if run["status"] not in {
        "running",
        "complete",
        "failed",
        "blocked",
        "aborted",
        "cancelled",
    }:
        raise ProtocolError(f"{label} has an invalid status.")


def finalize_delegation(delegation: dict[str, Any]) -> dict[str, Any]:
    prepared = dict(delegation)
    prepared.pop("content_sha256", None)
    prepared["content_sha256"] = _sha256(prepared)
    return prepared


def validate_delegation(
    delegation: dict[str, Any],
    parent_run: dict[str, Any],
    authority_bindings: dict[str, Any],
    policy: dict[str, Any],
    *,
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> dict[str, Any]:
    validate_delegation_policy(policy)
    validate_authority_bindings(
        authority_bindings,
        profile,
        role_registry,
        authority_matrix,
    )
    _validate_run(parent_run, "Parent agent run")
    required = {
        "version",
        "delegation_id",
        "project_id",
        "parent_run_id",
        "work_item_id",
        "assigned_identity_id",
        "assigned_role",
        "objective",
        "scope",
        "forbidden_scope",
        "authority_ceiling",
        "authority_grants",
        "tool_grants",
        "budget",
        "checkpoint_policy",
        "required_evidence",
        "deadline",
        "expires_at",
        "termination_conditions",
        "cancellation_policy",
        "escalation_owner_role",
        "status",
        "content_sha256",
    }
    _require_exact_fields(delegation, required, "Delegation")
    if delegation["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Delegation version must be '{PROTOCOL_VERSION}'."
        )
    expected_digest = _sha256(
        {key: value for key, value in delegation.items() if key != "content_sha256"}
    )
    if delegation["content_sha256"] != expected_digest:
        raise ProtocolError("Delegation content_sha256 does not match its content.")
    if delegation["project_id"] != parent_run["project_id"]:
        raise ProtocolError("Delegation cannot cross project boundaries.")
    if delegation["parent_run_id"] != parent_run["id"]:
        raise ProtocolError("Delegation parent_run_id does not match the parent run.")
    if delegation["work_item_id"] != parent_run["work_item_id"]:
        raise ProtocolError("Delegation work_item_id does not match the parent run.")
    if not isinstance(delegation["objective"], str) or len(
        delegation["objective"].strip()
    ) < 10:
        raise ProtocolError("Delegation objective must contain at least 10 characters.")

    parent_project_grants = _validate_run_authority(
        parent_run,
        authority_bindings,
        label="Parent agent run",
    )
    child_project_grants = _resolved_project_grants(
        authority_bindings,
        project_id=delegation["project_id"],
        identity_id=delegation["assigned_identity_id"],
        role=delegation["assigned_role"],
        label="Delegation assigned role",
    )

    scope = [
        _normalized_scope(item, "Delegation scope")
        for item in _require_string_list(delegation["scope"], "Delegation scope")
    ]
    if scope != delegation["scope"] or len(scope) != len(set(scope)):
        raise ProtocolError("Delegation scope must already be normalized and unique.")
    forbidden_scope = [
        _normalized_scope(item, "Delegation forbidden_scope")
        for item in _require_string_list(
            delegation["forbidden_scope"],
            "Delegation forbidden_scope",
            allow_empty=True,
        )
    ]
    if forbidden_scope != delegation["forbidden_scope"] or len(
        forbidden_scope
    ) != len(set(forbidden_scope)):
        raise ProtocolError(
            "Delegation forbidden_scope must already be normalized and unique."
        )
    parent_scope = [_normalized_scope(item, "Parent run scope") for item in parent_run["scope"]]
    for item in scope:
        if not any(_scope_is_within(item, parent) for parent in parent_scope):
            raise ProtocolError(
                f"Delegation scope '{item}' exceeds parent run scope."
            )
        if any(
            _scope_is_within(item, forbidden)
            or _scope_is_within(forbidden, item)
            for forbidden in forbidden_scope
        ):
            raise ProtocolError(
                f"Delegation scope '{item}' intersects forbidden scope."
            )

    ceiling = delegation["authority_ceiling"]
    if ceiling not in policy["authority_ceilings"]:
        raise ProtocolError(f"Delegation uses unknown authority ceiling '{ceiling}'.")
    allowed_by_ceiling = set(policy["authority_ceilings"][ceiling])
    forbidden_actions = set(policy["forbidden_delegated_actions"])
    child_grants = _validate_authority_grants(
        delegation["authority_grants"],
        "Delegation authority_grants",
    )
    parent_grants = {
        grant["resource"]: set(grant["actions"])
        for grant in _validate_authority_grants(
            parent_run["authority_grants"],
            "Parent agent run authority_grants",
        )
    }
    for grant in child_grants:
        actions = set(grant["actions"])
        if actions & forbidden_actions:
            raise ProtocolError("Delegated authority cannot include approve or promote.")
        if not actions <= allowed_by_ceiling:
            raise ProtocolError(
                f"Delegated actions for '{grant['resource']}' exceed authority ceiling."
            )
        if not actions <= parent_grants.get(grant["resource"], set()):
            raise ProtocolError(
                f"Delegated authority for '{grant['resource']}' exceeds parent authority."
            )
        if not actions <= child_project_grants.get(grant["resource"], set()):
            raise ProtocolError(
                f"Delegated authority for '{grant['resource']}' exceeds project role authority."
            )
        if not set(parent_grants.get(grant["resource"], set())) <= parent_project_grants.get(
            grant["resource"],
            set(),
        ):
            raise ProtocolError(
                f"Parent agent run authority for '{grant['resource']}' exceeds resolved project authority."
            )

    child_tools = set(
        _require_string_list(
            delegation["tool_grants"],
            "Delegation tool_grants",
            allow_empty=True,
        )
    )
    if not child_tools <= set(parent_run["tool_grants"]):
        raise ProtocolError("Delegated tool grants exceed parent tool grants.")

    child_budget = _validate_budget(delegation["budget"], "Delegation budget")
    parent_budget = _validate_budget(parent_run["budget"], "Parent run budget")
    for field in child_budget:
        if child_budget[field] > parent_budget[field]:
            raise ProtocolError(f"Delegation budget '{field}' exceeds parent budget.")

    checkpoint_policy = _require_exact_fields(
        delegation["checkpoint_policy"],
        {
            "maximum_actions_between_checkpoints",
            "maximum_seconds_between_checkpoints",
            "required_on_completion",
        },
        "Delegation checkpoint_policy",
    )
    if (
        not isinstance(checkpoint_policy["maximum_actions_between_checkpoints"], int)
        or checkpoint_policy["maximum_actions_between_checkpoints"] < 1
        or not isinstance(checkpoint_policy["maximum_seconds_between_checkpoints"], int)
        or checkpoint_policy["maximum_seconds_between_checkpoints"] < 1
        or checkpoint_policy["required_on_completion"] is not True
    ):
        raise ProtocolError("Delegation checkpoint policy is invalid.")
    _require_string_list(
        delegation["required_evidence"],
        "Delegation required_evidence",
    )
    _require_string_list(
        delegation["termination_conditions"],
        "Delegation termination_conditions",
    )
    if delegation["cancellation_policy"] != {"propagate_to_active_children": True}:
        raise ProtocolError("Delegation cancellation must propagate to active children.")
    if delegation["escalation_owner_role"] not in HUMAN_APPROVAL_ROLES:
        raise ProtocolError("Delegation escalation owner must be a human owner role.")
    deadline = _parse_datetime(delegation["deadline"], "Delegation deadline")
    expires_at = _parse_datetime(delegation["expires_at"], "Delegation expires_at")
    parent_deadline = _parse_datetime(parent_run["deadline"], "Parent run deadline")
    if deadline > parent_deadline or expires_at > parent_deadline:
        raise ProtocolError("Delegation deadline or expiry exceeds the parent deadline.")
    if expires_at < deadline:
        raise ProtocolError("Delegation expires before its deadline.")
    if delegation["status"] not in {
        "draft",
        "active",
        "completed",
        "cancelled",
        "expired",
        "rejected",
    }:
        raise ProtocolError("Delegation has an invalid status.")
    return delegation


def validate_delegation_set(
    delegations: list[dict[str, Any]],
    parent_run: dict[str, Any],
    authority_bindings: dict[str, Any],
    policy: dict[str, Any],
    *,
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> None:
    if not delegations:
        raise ProtocolError("Delegation set must not be empty.")
    totals = {
        "token_limit": 0,
        "cost_limit_usd": 0.0,
        "tool_call_limit": 0,
        "elapsed_seconds_limit": 0,
    }
    ids: set[str] = set()
    for delegation in delegations:
        validate_delegation(
            delegation,
            parent_run,
            authority_bindings,
            policy,
            profile=profile,
            role_registry=role_registry,
            authority_matrix=authority_matrix,
        )
        if delegation["delegation_id"] in ids:
            raise ProtocolError("Delegation ids must be unique.")
        ids.add(delegation["delegation_id"])
        for field, value in delegation["budget"].items():
            totals[field] += value
    for field, total in totals.items():
        if total > parent_run["budget"][field]:
            raise ProtocolError(
                f"Aggregate child delegation budget '{field}' exceeds parent budget."
            )


def validate_agent_run_chain(
    parent_run: dict[str, Any],
    child_run: dict[str, Any],
    delegation: dict[str, Any],
    *,
    authority_bindings: dict[str, Any],
    policy: dict[str, Any],
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> None:
    validate_delegation(
        delegation,
        parent_run,
        authority_bindings,
        policy,
        profile=profile,
        role_registry=role_registry,
        authority_matrix=authority_matrix,
    )
    _validate_run(child_run, "Child agent run")
    if delegation["parent_run_id"] != parent_run["id"]:
        raise ProtocolError("Delegation parent_run_id does not match the parent run.")
    if delegation["project_id"] != parent_run["project_id"]:
        raise ProtocolError("Delegation cannot cross the parent project boundary.")
    if delegation["work_item_id"] != parent_run["work_item_id"]:
        raise ProtocolError("Delegation work item does not match the parent run.")
    if child_run["parent_run_id"] != parent_run["id"]:
        raise ProtocolError("Every child run must trace to exactly one parent run.")
    if child_run["delegation_id"] != delegation["delegation_id"]:
        raise ProtocolError("Child run delegation_id does not match the delegation.")
    if child_run["project_id"] != delegation["project_id"]:
        raise ProtocolError("Child run cannot cross the delegation project boundary.")
    if child_run["work_item_id"] != delegation["work_item_id"]:
        raise ProtocolError("Child run work item does not match the delegation.")
    if child_run["identity_id"] != delegation["assigned_identity_id"]:
        raise ProtocolError("Child run identity does not match the delegation.")
    if child_run["role"] != delegation["assigned_role"]:
        raise ProtocolError("Child run role does not match the delegation.")
    delegated_grants = {
        grant["resource"]: set(grant["actions"])
        for grant in _validate_authority_grants(
            delegation["authority_grants"],
            "Delegation authority_grants",
        )
    }
    child_grants = _validate_authority_grants(
        child_run["authority_grants"],
        "Child agent run authority_grants",
    )
    forbidden_actions = set(policy["forbidden_delegated_actions"])
    for grant in child_grants:
        actions = set(grant["actions"])
        if actions & forbidden_actions:
            raise ProtocolError("Child run authority cannot include approve or promote.")
        if not actions <= delegated_grants.get(grant["resource"], set()):
            raise ProtocolError(
                f"Child run authority for '{grant['resource']}' exceeds delegated authority."
            )
    child_tools = set(child_run["tool_grants"])
    if not child_tools <= set(delegation["tool_grants"]):
        raise ProtocolError("Child run tool grants exceed delegated tool grants.")
    child_budget = _validate_budget(child_run["budget"], "Child agent run budget")
    delegated_budget = _validate_budget(delegation["budget"], "Delegation budget")
    for field, value in child_budget.items():
        if value > delegated_budget[field]:
            raise ProtocolError(f"Child run budget '{field}' exceeds delegated budget.")
    child_deadline = _parse_datetime(child_run["deadline"], "Child agent run deadline")
    delegated_deadline = _parse_datetime(delegation["deadline"], "Delegation deadline")
    delegated_expiry = _parse_datetime(delegation["expires_at"], "Delegation expires_at")
    if child_deadline > delegated_deadline or child_deadline > delegated_expiry:
        raise ProtocolError("Child run deadline exceeds the delegation deadline or expiry.")
    child_started = _parse_datetime(child_run["started_at"], "Child agent run started_at")
    child_completed = (
        _parse_datetime(child_run["completed_at"], "Child agent run completed_at")
        if child_run["completed_at"] is not None
        else None
    )
    if child_started > child_deadline:
        raise ProtocolError("Child run started_at exceeds its delegated deadline.")
    if child_completed is not None:
        if child_completed < child_started:
            raise ProtocolError("Child run completed_at cannot precede started_at.")
        if child_completed > child_deadline:
            raise ProtocolError("Child run completed_at exceeds its delegated deadline.")
    forbidden_scope = [
        _normalized_scope(item, "Delegation forbidden_scope")
        for item in delegation["forbidden_scope"]
    ]
    for item in child_run["scope"]:
        if not any(_scope_is_within(item, scope) for scope in delegation["scope"]):
            raise ProtocolError("Child run scope exceeds delegated scope.")
        if any(
            _scope_is_within(item, forbidden)
            or _scope_is_within(forbidden, item)
            for forbidden in forbidden_scope
        ):
            raise ProtocolError("Child run scope intersects forbidden delegated scope.")


def validate_context_delegation(
    request: dict[str, Any],
    delegation: dict[str, Any],
    parent_run: dict[str, Any],
    authority_bindings: dict[str, Any],
    policy: dict[str, Any],
    *,
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> list[str]:
    validate_delegation(
        delegation,
        parent_run,
        authority_bindings,
        policy,
        profile=profile,
        role_registry=role_registry,
        authority_matrix=authority_matrix,
    )
    if delegation.get("status") != "active":
        raise ProtocolError("Delegated context requires an active delegation.")
    expected = {
        "project_id": delegation.get("project_id"),
        "delegation_id": delegation.get("delegation_id"),
        "agent_identity_id": delegation.get("assigned_identity_id"),
        "work_item_id": delegation.get("work_item_id"),
    }
    labels = {
        "project_id": "project",
        "delegation_id": "delegation",
        "agent_identity_id": "agent identity",
        "work_item_id": "work item",
    }
    for field, value in expected.items():
        if request.get(field) != value:
            raise ProtocolError(
                f"Delegated context {labels[field]} does not match the delegation."
            )
    requested_scope = [
        _normalized_scope(item, "Context delegated_scope")
        for item in _require_string_list(
            request.get("delegated_scope"),
            "Context delegated_scope",
        )
    ]
    if requested_scope != request["delegated_scope"] or len(requested_scope) != len(
        set(requested_scope)
    ):
        raise ProtocolError(
            "Context delegated_scope must already be normalized and unique."
        )
    delegated_scope = [
        _normalized_scope(item, "Delegation scope")
        for item in _require_string_list(delegation.get("scope"), "Delegation scope")
    ]
    forbidden_scope = [
        _normalized_scope(item, "Delegation forbidden_scope")
        for item in _require_string_list(
            delegation.get("forbidden_scope"),
            "Delegation forbidden_scope",
            allow_empty=True,
        )
    ]
    for item in requested_scope:
        if not any(_scope_is_within(item, scope) for scope in delegated_scope):
            raise ProtocolError("Delegated context scope exceeds the delegation.")
        if any(
            _scope_is_within(item, forbidden)
            or _scope_is_within(forbidden, item)
            for forbidden in forbidden_scope
        ):
            raise ProtocolError("Delegated context scope intersects forbidden scope.")
    return requested_scope


def validate_agent_message(message: dict[str, Any]) -> None:
    required = {
        "version",
        "id",
        "project_id",
        "delegation_id",
        "parent_run_id",
        "child_run_id",
        "from_identity",
        "to_identity",
        "kind",
        "content",
        "evidence_refs",
        "sequence",
        "state_effect",
        "created_at",
    }
    _require_exact_fields(message, required, "Agent message")
    if message["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Agent message version must be '{PROTOCOL_VERSION}'.")
    for field in [
        "id",
        "project_id",
        "delegation_id",
        "parent_run_id",
        "child_run_id",
        "from_identity",
        "to_identity",
        "content",
    ]:
        if not isinstance(message[field], str) or not message[field].strip():
            raise ProtocolError(f"Agent message {field} must be non-empty.")
    if message["from_identity"] == message["to_identity"]:
        raise ProtocolError("Agent message sender and recipient must differ.")
    if message["state_effect"] != "none":
        raise ProtocolError("Messages cannot mutate governed state directly.")
    if message["kind"] not in {
        "instruction",
        "status",
        "evidence",
        "question",
        "answer",
        "escalation",
        "cancellation",
    }:
        raise ProtocolError("Agent message has an invalid kind.")
    if not isinstance(message["sequence"], int) or message["sequence"] < 1:
        raise ProtocolError("Agent message sequence must be a positive integer.")
    _require_string_list(
        message["evidence_refs"],
        "Agent message evidence_refs",
        allow_empty=True,
    )
    _parse_datetime(message["created_at"], "Agent message created_at")


def validate_checkpoint(checkpoint: dict[str, Any]) -> None:
    required = {
        "version",
        "id",
        "project_id",
        "delegation_id",
        "run_id",
        "sequence",
        "action_sequence",
        "status",
        "completed_scope",
        "remaining_scope",
        "evidence_refs",
        "budget_consumed",
        "previous_checkpoint_sha256",
        "content_sha256",
        "created_at",
    }
    _require_exact_fields(checkpoint, required, "Checkpoint")
    if checkpoint["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Checkpoint version must be '{PROTOCOL_VERSION}'.")
    expected_digest = _sha256(
        {key: value for key, value in checkpoint.items() if key != "content_sha256"}
    )
    if checkpoint["content_sha256"] != expected_digest:
        raise ProtocolError("Checkpoint content_sha256 does not match its content.")
    if not isinstance(checkpoint["sequence"], int) or checkpoint["sequence"] < 1:
        raise ProtocolError("Checkpoint sequence must be a positive integer.")
    if (
        not isinstance(checkpoint["action_sequence"], int)
        or checkpoint["action_sequence"] < 0
    ):
        raise ProtocolError(
            "Checkpoint action_sequence must be a non-negative integer."
        )
    previous = checkpoint["previous_checkpoint_sha256"]
    if previous is not None and (
        not isinstance(previous, str)
        or len(previous) != 64
        or any(character not in "0123456789abcdef" for character in previous)
    ):
        raise ProtocolError(
            "Checkpoint previous_checkpoint_sha256 must be null or lowercase SHA-256."
        )
    if checkpoint["status"] not in {
        "running",
        "blocked",
        "completed",
        "cancelled",
        "failed",
    }:
        raise ProtocolError("Checkpoint has an invalid status.")
    completed_scope = _require_string_list(
        checkpoint["completed_scope"],
        "Checkpoint completed_scope",
        allow_empty=True,
    )
    remaining_scope = _require_string_list(
        checkpoint["remaining_scope"],
        "Checkpoint remaining_scope",
        allow_empty=True,
    )
    _require_string_list(
        checkpoint["evidence_refs"],
        "Checkpoint evidence_refs",
        allow_empty=True,
    )
    for label, scopes in [
        ("Checkpoint completed_scope", completed_scope),
        ("Checkpoint remaining_scope", remaining_scope),
    ]:
        normalized = [_normalized_scope(item, label) for item in scopes]
        if normalized != scopes:
            raise ProtocolError(f"{label} must already be normalized.")
    _validate_budget(
        checkpoint["budget_consumed"],
        "Checkpoint budget_consumed",
    )
    _parse_datetime(checkpoint["created_at"], "Checkpoint created_at")


def validate_bound_checkpoint(
    checkpoint: dict[str, Any],
    parent_run: dict[str, Any],
    delegation: dict[str, Any],
    run: dict[str, Any],
    *,
    authority_bindings: dict[str, Any],
    policy: dict[str, Any],
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> None:
    validate_agent_run_chain(
        parent_run,
        run,
        delegation,
        authority_bindings=authority_bindings,
        policy=policy,
        profile=profile,
        role_registry=role_registry,
        authority_matrix=authority_matrix,
    )
    validate_checkpoint(checkpoint)
    if checkpoint["project_id"] != delegation["project_id"] or checkpoint[
        "project_id"
    ] != run["project_id"]:
        raise ProtocolError("Checkpoint project_id does not match its delegation and run.")
    if checkpoint["delegation_id"] != delegation["delegation_id"]:
        raise ProtocolError("Checkpoint delegation_id does not match the delegation.")
    if checkpoint["run_id"] != run["id"]:
        raise ProtocolError("Checkpoint run_id does not match the child run.")
    if run["delegation_id"] != delegation["delegation_id"]:
        raise ProtocolError("Checkpoint child run is not bound to the delegation.")
    allowed_scope = run["scope"]
    delegated_scope = delegation["scope"]
    forbidden_scope = delegation["forbidden_scope"]
    for item in checkpoint["completed_scope"] + checkpoint["remaining_scope"]:
        if not any(_scope_is_within(item, scope) for scope in allowed_scope):
            raise ProtocolError("Checkpoint scope exceeds the child run scope.")
        if not any(_scope_is_within(item, scope) for scope in delegated_scope):
            raise ProtocolError("Checkpoint scope exceeds delegated scope.")
        if any(
            _scope_is_within(item, forbidden)
            or _scope_is_within(forbidden, item)
            for forbidden in forbidden_scope
        ):
            raise ProtocolError("Checkpoint scope intersects forbidden scope.")
    consumed = _validate_budget(
        checkpoint["budget_consumed"],
        "Checkpoint budget_consumed",
    )
    run_budget = _validate_budget(run["budget"], "Checkpoint child run budget")
    delegated_budget = _validate_budget(
        delegation["budget"],
        "Checkpoint delegation budget",
    )
    for field, value in consumed.items():
        if value > run_budget[field] or value > delegated_budget[field]:
            raise ProtocolError(
                f"Checkpoint budget '{field}' exceeds its run or delegation."
            )
    deadline = min(
        _parse_datetime(run["deadline"], "Checkpoint child run deadline"),
        _parse_datetime(delegation["deadline"], "Checkpoint delegation deadline"),
        _parse_datetime(delegation["expires_at"], "Checkpoint delegation expiry"),
    )
    if _parse_datetime(checkpoint["created_at"], "Checkpoint created_at") > deadline:
        raise ProtocolError("Checkpoint was created after its delegated deadline.")


def finalize_checkpoint(checkpoint: dict[str, Any]) -> dict[str, Any]:
    prepared = dict(checkpoint)
    prepared.pop("content_sha256", None)
    prepared["content_sha256"] = _sha256(prepared)
    validate_checkpoint(prepared)
    return prepared


def validate_approval_decision(decision: dict[str, Any]) -> None:
    required = {
        "version",
        "id",
        "project_id",
        "subject_type",
        "subject_id",
        "subject_sha256",
        "decision",
        "decided_by",
        "decided_as_role",
        "evidence_refs",
        "decided_at",
    }
    _require_exact_fields(decision, required, "Approval decision")
    if decision["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Approval decision version must be '{PROTOCOL_VERSION}'."
        )
    if decision["decided_as_role"] not in HUMAN_APPROVAL_ROLES:
        raise ProtocolError("Approval decisions require an accountable human owner role.")
    if decision["decision"] not in {
        "approved",
        "rejected",
        "changes-requested",
    }:
        raise ProtocolError("Approval decision has an invalid decision.")
    if (
        not isinstance(decision["subject_sha256"], str)
        or len(decision["subject_sha256"]) != 64
    ):
        raise ProtocolError("Approval decision must bind a SHA-256 subject digest.")
    _require_string_list(
        decision["evidence_refs"],
        "Approval decision evidence_refs",
    )
    _parse_datetime(decision["decided_at"], "Approval decision decided_at")


def build_delegation_fixture_graph(
    parent_run: dict[str, Any],
    delegation: dict[str, Any],
    child_run: dict[str, Any],
    checkpoint: dict[str, Any],
    *,
    authority_bindings: dict[str, Any],
    policy: dict[str, Any],
    profile: dict[str, Any],
    role_registry: dict[str, Any],
    authority_matrix: dict[str, Any],
) -> dict[str, Any]:
    validate_bound_checkpoint(
        checkpoint,
        parent_run,
        delegation,
        child_run,
        authority_bindings=authority_bindings,
        policy=policy,
        profile=profile,
        role_registry=role_registry,
        authority_matrix=authority_matrix,
    )
    nodes = [
        {
            "id": f"agent-run:{parent_run['id']}",
            "type": "agent-run",
            "label": parent_run["id"],
        },
        {
            "id": f"delegation:{delegation['delegation_id']}",
            "type": "delegation",
            "label": delegation["delegation_id"],
        },
        {
            "id": f"agent-run:{child_run['id']}",
            "type": "agent-run",
            "label": child_run["id"],
        },
        {
            "id": f"checkpoint:{checkpoint['id']}",
            "type": "checkpoint",
            "label": checkpoint["id"],
        },
    ]
    edges = [
        {
            "id": f"delegates:agent-run:{parent_run['id']}->delegation:{delegation['delegation_id']}",
            "type": "delegates",
            "from": f"agent-run:{parent_run['id']}",
            "to": f"delegation:{delegation['delegation_id']}",
        },
        {
            "id": f"spawns:delegation:{delegation['delegation_id']}->agent-run:{child_run['id']}",
            "type": "spawns",
            "from": f"delegation:{delegation['delegation_id']}",
            "to": f"agent-run:{child_run['id']}",
        },
        {
            "id": f"child-of:agent-run:{child_run['id']}->agent-run:{parent_run['id']}",
            "type": "child-of",
            "from": f"agent-run:{child_run['id']}",
            "to": f"agent-run:{parent_run['id']}",
        },
        {
            "id": f"checkpoints:checkpoint:{checkpoint['id']}->agent-run:{child_run['id']}",
            "type": "checkpoints",
            "from": f"checkpoint:{checkpoint['id']}",
            "to": f"agent-run:{child_run['id']}",
        },
    ]
    return {
        "version": PROTOCOL_VERSION,
        "kind": "delegation-fixture",
        "nodes": sorted(nodes, key=lambda item: item["id"]),
        "edges": sorted(edges, key=lambda item: item["id"]),
    }
