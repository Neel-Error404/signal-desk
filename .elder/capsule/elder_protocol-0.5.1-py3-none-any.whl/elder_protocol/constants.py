from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parent
SOURCE_ROOT = PACKAGE_ROOT.parent
PACKAGED_ROOT = PACKAGE_ROOT / "_kernel"


def _contains_kernel(root: Path) -> bool:
    return (
        (root / "AGENTS.md").is_file()
        and (root / "protocol" / "invariants.json").is_file()
        and (root / "skills").is_dir()
    )


ROOT = PACKAGED_ROOT if _contains_kernel(PACKAGED_ROOT) else SOURCE_ROOT
PROTOCOL_DIR = ROOT / "protocol"
SKILLS_DIR = ROOT / "skills"
PROTOCOL_VERSION = "0.5.1"
PORTABLE_MEMORY_ENV_PATH = ".elder/runtime/memory.env"
AUTONOMY_LEVELS = {"L0", "L1", "L2", "L3", "L4", "L5"}
PROFILE_ENUMS = {
    "profile_status": {"draft", "ratified"},
    "project_type": {"software", "agentic", "data", "research", "hybrid"},
    "lifecycle": {"prototype", "production", "regulated"},
    "topology": {"single-repo", "monorepo", "multirepo", "federated"},
    "risk_tier": {"low", "moderate", "high", "critical"},
    "data_sensitivity": {"public", "internal", "confidential", "restricted"},
    "autonomy_ceiling": AUTONOMY_LEVELS,
}
PROFILE_REQUIRED = {
    "protocol_version",
    "profile_status",
    "name",
    "slug",
    "mission",
    "outcomes",
    "constraints",
    "project_type",
    "lifecycle",
    "topology",
    "risk_tier",
    "data_sensitivity",
    "autonomy_ceiling",
    "capability_packs",
    "skill_overrides",
    "languages",
    "deployment_targets",
    "knowledge_sources",
    "identities",
    "role_bindings",
}
