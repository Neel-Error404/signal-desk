from __future__ import annotations

import json
import math
import uuid
from datetime import UTC, datetime
from pathlib import Path
from statistics import mean
from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json, sha256_file


GRADER_TYPES = {"exact", "contains", "numeric", "rubric"}
LABELS = {"pass", "fail", "needs-review"}
RISK_TIERS = {"low", "moderate", "high", "critical"}
SPLITS = {"development", "calibration", "holdout"}


def _require_fields(value: Any, expected: set[str], label: str) -> None:
    if not isinstance(value, dict):
        raise ProtocolError(f"{label} must be an object.")
    if set(value) != expected:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(expected)}")


def _is_number(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def _require_identity_separation(evaluator_id: Any, executor_id: Any) -> None:
    if (
        not isinstance(evaluator_id, str)
        or not isinstance(executor_id, str)
        or not evaluator_id.strip()
        or not executor_id.strip()
    ):
        raise ProtocolError("Evaluator and executor identities must be non-empty.")
    if evaluator_id == executor_id:
        raise ProtocolError("Evaluation must be independent from the executor.")


def _validate_grader(grader: dict[str, Any], case_id: str) -> None:
    grader_type = grader.get("type")
    if grader_type not in GRADER_TYPES:
        raise ProtocolError(
            f"Evaluation case '{case_id}' has unsupported grader '{grader_type}'."
        )
    if grader_type in {"exact", "contains"}:
        _require_fields(grader, {"type", "case_sensitive"}, f"Grader '{case_id}'")
        if not isinstance(grader["case_sensitive"], bool):
            raise ProtocolError(f"Grader '{case_id}' case_sensitive must be boolean.")
    elif grader_type == "numeric":
        _require_fields(
            grader,
            {"type", "absolute_tolerance"},
            f"Grader '{case_id}'",
        )
        tolerance = grader["absolute_tolerance"]
        if not _is_number(tolerance) or tolerance < 0:
            raise ProtocolError(
                f"Grader '{case_id}' absolute_tolerance must be non-negative."
            )
    else:
        _require_fields(
            grader,
            {"type", "rubric_id", "minimum_score", "reference_label"},
            f"Grader '{case_id}'",
        )
        if not isinstance(grader["rubric_id"], str) or not grader["rubric_id"]:
            raise ProtocolError(f"Grader '{case_id}' needs a rubric_id.")
        score = grader["minimum_score"]
        if not _is_number(score) or not 0 <= score <= 1:
            raise ProtocolError(
                f"Grader '{case_id}' minimum_score must be between 0 and 1."
            )
        if grader["reference_label"] not in LABELS:
            raise ProtocolError(
                f"Grader '{case_id}' reference_label must be one of {sorted(LABELS)}."
            )


def validate_evaluation_dataset(dataset_path: Path) -> dict[str, Any]:
    dataset_path = dataset_path.resolve()
    dataset = load_json(dataset_path)
    _require_fields(
        dataset,
        {
            "version",
            "id",
            "title",
            "objective",
            "owner",
            "source",
            "license",
            "sensitivity",
            "splits",
            "thresholds",
            "cases",
        },
        "Evaluation dataset",
    )
    if dataset["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Evaluation dataset version must be '{PROTOCOL_VERSION}'."
        )
    for field in ["id", "title", "objective", "owner", "source", "license"]:
        if not isinstance(dataset[field], str) or not dataset[field].strip():
            raise ProtocolError(f"Evaluation dataset {field} must be non-empty.")
    if dataset["sensitivity"] not in {
        "public",
        "internal",
        "confidential",
        "restricted",
    }:
        raise ProtocolError("Evaluation dataset has invalid sensitivity.")

    thresholds = dataset["thresholds"]
    _require_fields(
        thresholds,
        {"minimum_pass_rate", "maximum_failed_cases"},
        "Evaluation thresholds",
    )
    pass_rate = thresholds["minimum_pass_rate"]
    if not _is_number(pass_rate) or not 0 <= pass_rate <= 1:
        raise ProtocolError("minimum_pass_rate must be between 0 and 1.")
    maximum_failed = thresholds["maximum_failed_cases"]
    if (
        not isinstance(maximum_failed, int)
        or isinstance(maximum_failed, bool)
        or maximum_failed < 0
    ):
        raise ProtocolError("maximum_failed_cases must be a non-negative integer.")

    cases = dataset["cases"]
    if not isinstance(cases, list) or not cases:
        raise ProtocolError("Evaluation dataset must define cases.")
    case_ids: list[str] = []
    for case in cases:
        _require_fields(
            case,
            {"id", "input", "expected", "slices", "risk_tier", "grader"},
            "Evaluation case",
        )
        case_id = case["id"]
        if not isinstance(case_id, str) or not case_id.strip():
            raise ProtocolError("Evaluation case id must be non-empty.")
        case_ids.append(case_id)
        if not isinstance(case["input"], str) or not case["input"].strip():
            raise ProtocolError(f"Evaluation case '{case_id}' needs input.")
        if (
            not isinstance(case["slices"], list)
            or not case["slices"]
            or any(not isinstance(item, str) or not item for item in case["slices"])
            or len(case["slices"]) != len(set(case["slices"]))
        ):
            raise ProtocolError(
                f"Evaluation case '{case_id}' slices must be unique and non-empty."
            )
        if case["risk_tier"] not in RISK_TIERS:
            raise ProtocolError(f"Evaluation case '{case_id}' has invalid risk_tier.")
        if not isinstance(case["grader"], dict):
            raise ProtocolError(f"Evaluation case '{case_id}' needs a grader.")
        _validate_grader(case["grader"], case_id)
        if case["grader"]["type"] == "numeric" and not _is_number(case["expected"]):
            raise ProtocolError(
                f"Evaluation case '{case_id}' numeric expected value is invalid."
            )
    if len(case_ids) != len(set(case_ids)):
        raise ProtocolError("Evaluation case ids must be unique.")

    splits = dataset["splits"]
    _require_fields(splits, SPLITS, "Evaluation dataset splits")
    assigned: list[str] = []
    for split_name in sorted(SPLITS):
        split_ids = splits[split_name]
        if not isinstance(split_ids, list) or not split_ids:
            raise ProtocolError(f"Evaluation split '{split_name}' must not be empty.")
        if any(not isinstance(item, str) or not item for item in split_ids):
            raise ProtocolError(f"Evaluation split '{split_name}' has invalid ids.")
        if len(split_ids) != len(set(split_ids)):
            raise ProtocolError(f"Evaluation split '{split_name}' has duplicates.")
        assigned.extend(split_ids)
    unknown = set(assigned) - set(case_ids)
    if unknown:
        raise ProtocolError(f"Evaluation splits use unknown cases: {sorted(unknown)}")
    duplicates = sorted({item for item in assigned if assigned.count(item) > 1})
    if duplicates:
        raise ProtocolError(
            f"Evaluation cases cannot appear in multiple splits: {duplicates}"
        )
    missing = set(case_ids) - set(assigned)
    if missing:
        raise ProtocolError(f"Evaluation cases are not assigned to a split: {sorted(missing)}")
    return dataset


def validate_evaluation_registry(
    registry_path: Path,
    root: Path,
) -> dict[str, Any]:
    registry_path = registry_path.resolve()
    root = root.resolve()
    registry = load_json(registry_path)
    _require_fields(registry, {"version", "datasets"}, "Evaluation registry")
    if registry["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Evaluation registry version must be '{PROTOCOL_VERSION}'."
        )
    datasets = registry["datasets"]
    if not isinstance(datasets, list) or not datasets:
        raise ProtocolError("Evaluation registry must define datasets.")
    ids: list[str] = []
    stale: list[str] = []
    for entry in datasets:
        _require_fields(
            entry,
            {
                "id",
                "path",
                "owner",
                "status",
                "content_sha256",
                "notifies",
            },
            "Evaluation registry entry",
        )
        ids.append(entry["id"])
        for field in ["id", "path", "owner", "content_sha256"]:
            if not isinstance(entry[field], str) or not entry[field].strip():
                raise ProtocolError(
                    f"Evaluation registry entry {field} must be non-empty."
                )
        if (
            not isinstance(entry["notifies"], list)
            or not entry["notifies"]
            or any(
                not isinstance(item, str) or not item for item in entry["notifies"]
            )
            or len(entry["notifies"]) != len(set(entry["notifies"]))
        ):
            raise ProtocolError(
                f"Evaluation dataset '{entry['id']}' notifies must be unique and non-empty."
            )
        if entry["status"] not in {"draft", "active", "retired"}:
            raise ProtocolError(
                f"Evaluation dataset '{entry['id']}' has invalid status."
            )
        target = (root / entry["path"]).resolve()
        if root not in target.parents and target != root:
            raise ProtocolError(
                f"Evaluation dataset '{entry['id']}' escapes registry root."
            )
        if not target.is_file():
            raise ProtocolError(
                f"Evaluation dataset '{entry['id']}' is missing: {target}"
            )
        dataset = validate_evaluation_dataset(target)
        if dataset["id"] != entry["id"]:
            raise ProtocolError(
                f"Evaluation registry id '{entry['id']}' does not match dataset "
                f"id '{dataset['id']}'."
            )
        if sha256_file(target) != entry["content_sha256"]:
            stale.append(entry["id"])
    if len(ids) != len(set(ids)):
        raise ProtocolError("Evaluation registry dataset ids must be unique.")
    if stale:
        raise ProtocolError(
            f"Evaluation registry has stale content hashes: {', '.join(sorted(stale))}"
        )
    return {
        "registry": str(registry_path),
        "dataset_count": len(datasets),
        "active_count": sum(entry["status"] == "active" for entry in datasets),
        "stale": [],
    }


def validate_evaluator_contract(contract_path: Path) -> dict[str, Any]:
    contract_path = contract_path.resolve()
    contract = load_json(contract_path)
    _require_fields(
        contract,
        {
            "version",
            "id",
            "authority",
            "independence",
            "allowed_graders",
            "calibration",
            "comparison",
        },
        "Evaluator contract",
    )
    if contract["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Evaluator contract version must be '{PROTOCOL_VERSION}'."
        )
    allowed_graders = contract["allowed_graders"]
    if (
        not isinstance(allowed_graders, list)
        or any(not isinstance(item, str) for item in allowed_graders)
        or len(allowed_graders) != len(set(allowed_graders))
        or set(allowed_graders) != GRADER_TYPES
    ):
        raise ProtocolError(
            f"Evaluator contract allowed_graders must be {sorted(GRADER_TYPES)}."
        )
    authority = contract["authority"]
    _require_fields(
        authority,
        {"mode", "can_approve", "can_promote", "can_modify_policy"},
        "Evaluator authority",
    )
    if authority != {
        "mode": "advisory-only",
        "can_approve": False,
        "can_promote": False,
        "can_modify_policy": False,
    }:
        raise ProtocolError("Evaluator authority must remain advisory-only.")
    independence = contract["independence"]
    _require_fields(
        independence,
        {"require_distinct_executor", "require_immutable_inputs"},
        "Evaluator independence",
    )
    if independence != {
        "require_distinct_executor": True,
        "require_immutable_inputs": True,
    }:
        raise ProtocolError("Evaluator independence requirements cannot be weakened.")
    calibration = contract["calibration"]
    _require_fields(
        calibration,
        {
            "split",
            "minimum_samples",
            "minimum_accuracy",
            "minimum_f1",
            "maximum_abstention_rate",
        },
        "Evaluator calibration",
    )
    if calibration["split"] != "calibration":
        raise ProtocolError("Evaluator calibration split must be 'calibration'.")
    if (
        not isinstance(calibration["minimum_samples"], int)
        or isinstance(calibration["minimum_samples"], bool)
        or calibration["minimum_samples"] < 1
    ):
        raise ProtocolError("Evaluator calibration minimum_samples must be positive.")
    for field in ["minimum_accuracy", "minimum_f1", "maximum_abstention_rate"]:
        if not _is_number(calibration[field]) or not 0 <= calibration[field] <= 1:
            raise ProtocolError(f"Evaluator calibration {field} must be 0..1.")
    comparison = contract["comparison"]
    _require_fields(
        comparison,
        {"minimum_paired_cases", "fail_on_any_critical_regression"},
        "Evaluator comparison",
    )
    if (
        not isinstance(comparison["minimum_paired_cases"], int)
        or isinstance(comparison["minimum_paired_cases"], bool)
        or comparison["minimum_paired_cases"] < 1
    ):
        raise ProtocolError("Comparison minimum_paired_cases must be positive.")
    if comparison["fail_on_any_critical_regression"] is not True:
        raise ProtocolError("Critical evaluation regressions must fail closed.")
    return contract


def _validate_candidate(
    candidate: dict[str, Any],
    dataset_id: str,
    split_case_ids: set[str],
) -> dict[str, dict[str, Any]]:
    _require_fields(
        candidate,
        {
            "version",
            "dataset_id",
            "candidate_id",
            "executor_id",
            "created_at",
            "outputs",
        },
        "Evaluation candidate",
    )
    if candidate["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Evaluation candidate version must be '{PROTOCOL_VERSION}'."
        )
    if candidate["dataset_id"] != dataset_id:
        raise ProtocolError("Evaluation candidate dataset_id does not match dataset.")
    for field in ["candidate_id", "executor_id", "created_at"]:
        if not isinstance(candidate[field], str) or not candidate[field].strip():
            raise ProtocolError(f"Evaluation candidate {field} must be non-empty.")
    outputs = candidate["outputs"]
    if not isinstance(outputs, list):
        raise ProtocolError("Evaluation candidate outputs must be a list.")
    by_id: dict[str, dict[str, Any]] = {}
    for output in outputs:
        _require_fields(
            output,
            {
                "case_id",
                "output",
                "latency_ms",
                "cost_usd",
                "tool_calls",
                "trace_path",
            },
            "Evaluation candidate output",
        )
        case_id = output["case_id"]
        if not isinstance(case_id, str) or not case_id.strip():
            raise ProtocolError("Evaluation candidate output case_id must be non-empty.")
        if case_id in by_id:
            raise ProtocolError(f"Duplicate candidate output for case '{case_id}'.")
        if not _is_number(output["latency_ms"]) or output["latency_ms"] < 0:
            raise ProtocolError(f"Candidate case '{case_id}' latency_ms is invalid.")
        if not _is_number(output["cost_usd"]) or output["cost_usd"] < 0:
            raise ProtocolError(f"Candidate case '{case_id}' cost_usd is invalid.")
        if (
            not isinstance(output["tool_calls"], int)
            or isinstance(output["tool_calls"], bool)
            or output["tool_calls"] < 0
        ):
            raise ProtocolError(f"Candidate case '{case_id}' tool_calls is invalid.")
        if output["trace_path"] is not None and (
            not isinstance(output["trace_path"], str) or not output["trace_path"]
        ):
            raise ProtocolError(f"Candidate case '{case_id}' trace_path is invalid.")
        by_id[case_id] = output
    missing = split_case_ids - set(by_id)
    extra = set(by_id) - split_case_ids
    if missing or extra:
        raise ProtocolError(
            "Evaluation candidate split coverage mismatch; "
            f"missing={sorted(missing)}, extra={sorted(extra)}."
        )
    return by_id


def _validate_judge_results(
    judge: dict[str, Any],
    *,
    dataset_id: str,
    candidate_id: str,
    executor_id: str,
    evaluator_id: str,
    purpose: str,
    case_ids: set[str],
) -> dict[str, dict[str, Any]]:
    _require_fields(
        judge,
        {
            "version",
            "dataset_id",
            "candidate_id",
            "purpose",
            "judge_id",
            "evaluator_id",
            "executor_id",
            "created_at",
            "results",
        },
        "Judge results",
    )
    if judge["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Judge results version must be '{PROTOCOL_VERSION}'.")
    expected_identity = {
        "dataset_id": dataset_id,
        "candidate_id": candidate_id,
        "executor_id": executor_id,
        "evaluator_id": evaluator_id,
        "purpose": purpose,
    }
    for field, expected in expected_identity.items():
        if judge[field] != expected:
            raise ProtocolError(
                f"Judge results {field} must be '{expected}', got '{judge[field]}'."
            )
    for field in ["judge_id", "created_at"]:
        if not isinstance(judge[field], str) or not judge[field].strip():
            raise ProtocolError(f"Judge results {field} must be non-empty.")
    _require_identity_separation(judge["evaluator_id"], judge["executor_id"])
    results = judge["results"]
    if not isinstance(results, list):
        raise ProtocolError("Judge results must be a list.")
    by_id: dict[str, dict[str, Any]] = {}
    for result in results:
        _require_fields(
            result,
            {"case_id", "label", "score", "reason", "evidence"},
            "Judge result",
        )
        case_id = result["case_id"]
        if not isinstance(case_id, str) or not case_id.strip():
            raise ProtocolError("Judge result case_id must be non-empty.")
        if case_id in by_id:
            raise ProtocolError(f"Duplicate judge result for case '{case_id}'.")
        if result["label"] not in LABELS:
            raise ProtocolError(f"Judge result '{case_id}' has invalid label.")
        if not _is_number(result["score"]) or not 0 <= result["score"] <= 1:
            raise ProtocolError(f"Judge result '{case_id}' score must be 0..1.")
        if not isinstance(result["reason"], str) or not result["reason"].strip():
            raise ProtocolError(f"Judge result '{case_id}' needs a reason.")
        if (
            not isinstance(result["evidence"], list)
            or not result["evidence"]
            or any(not isinstance(item, str) or not item for item in result["evidence"])
        ):
            raise ProtocolError(f"Judge result '{case_id}' needs evidence.")
        by_id[case_id] = result
    missing = case_ids - set(by_id)
    extra = set(by_id) - case_ids
    if missing or extra:
        raise ProtocolError(
            "Judge result coverage mismatch; "
            f"missing={sorted(missing)}, extra={sorted(extra)}."
        )
    return by_id


def _binary(label: str) -> int:
    return 1 if label == "pass" else 0


def calibrate_judge(
    dataset_path: Path,
    judge_results_path: Path,
    contract_path: Path,
) -> dict[str, Any]:
    dataset = validate_evaluation_dataset(dataset_path)
    contract = validate_evaluator_contract(contract_path)
    split = contract["calibration"]["split"]
    cases = {
        case["id"]: case
        for case in dataset["cases"]
        if case["id"] in set(dataset["splits"][split])
    }
    non_rubric = [
        case_id
        for case_id, case in cases.items()
        if case["grader"]["type"] != "rubric"
    ]
    if non_rubric:
        raise ProtocolError(
            f"Calibration split contains non-rubric cases: {sorted(non_rubric)}"
        )
    judge = load_json(judge_results_path.resolve())
    evaluator_id = judge.get("evaluator_id", "")
    executor_id = judge.get("executor_id", "")
    _require_identity_separation(evaluator_id, executor_id)
    results = _validate_judge_results(
        judge,
        dataset_id=dataset["id"],
        candidate_id="calibration-reference",
        executor_id=executor_id,
        evaluator_id=evaluator_id,
        purpose="calibration",
        case_ids=set(cases),
    )
    true_positive = false_positive = true_negative = false_negative = abstentions = 0
    agreements = 0
    for case_id, case in cases.items():
        expected = case["grader"]["reference_label"]
        actual = results[case_id]["label"]
        agreements += actual == expected
        abstentions += actual == "needs-review"
        expected_binary = _binary(expected)
        actual_binary = _binary(actual)
        if expected_binary and actual_binary:
            true_positive += 1
        elif not expected_binary and actual_binary:
            false_positive += 1
        elif not expected_binary and not actual_binary:
            true_negative += 1
        else:
            false_negative += 1
    sample_count = len(cases)
    accuracy = agreements / sample_count if sample_count else 0.0
    precision_denominator = true_positive + false_positive
    recall_denominator = true_positive + false_negative
    precision = (
        true_positive / precision_denominator if precision_denominator else 0.0
    )
    recall = true_positive / recall_denominator if recall_denominator else 0.0
    f1 = (
        2 * precision * recall / (precision + recall)
        if precision + recall
        else 0.0
    )
    abstention_rate = abstentions / sample_count if sample_count else 0.0
    thresholds = contract["calibration"]
    qualified = (
        sample_count >= thresholds["minimum_samples"]
        and accuracy >= thresholds["minimum_accuracy"]
        and f1 >= thresholds["minimum_f1"]
        and abstention_rate <= thresholds["maximum_abstention_rate"]
    )
    return {
        "version": PROTOCOL_VERSION,
        "calibration_id": f"calibration-{uuid.uuid4().hex}",
        "dataset_id": dataset["id"],
        "dataset_sha256": sha256_file(dataset_path.resolve()),
        "contract_id": contract["id"],
        "contract_sha256": sha256_file(contract_path.resolve()),
        "judge_results_sha256": sha256_file(judge_results_path.resolve()),
        "judge_id": judge["judge_id"],
        "evaluator_id": evaluator_id,
        "executor_id": executor_id,
        "independent": True,
        "authority": "advisory-only",
        "can_approve": False,
        "can_promote": False,
        "qualified": qualified,
        "metrics": {
            "sample_count": sample_count,
            "accuracy": accuracy,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "abstention_rate": abstention_rate,
            "confusion_matrix": {
                "true_positive": true_positive,
                "false_positive": false_positive,
                "true_negative": true_negative,
                "false_negative": false_negative,
            },
        },
        "thresholds": thresholds,
        "calibrated_at": datetime.now(UTC).isoformat(),
    }


def _normalize_text(value: Any, case_sensitive: bool) -> str:
    if isinstance(value, str):
        text = value.strip()
    else:
        text = json.dumps(value, sort_keys=True, separators=(",", ":"))
    return text if case_sensitive else text.casefold()


def _score_deterministic(case: dict[str, Any], output: Any) -> tuple[float, str]:
    grader = case["grader"]
    grader_type = grader["type"]
    expected = case["expected"]
    if grader_type == "exact":
        passed = _normalize_text(output, grader["case_sensitive"]) == _normalize_text(
            expected, grader["case_sensitive"]
        )
        return float(passed), "Exact comparison passed." if passed else "Exact comparison failed."
    if grader_type == "contains":
        passed = _normalize_text(expected, grader["case_sensitive"]) in _normalize_text(
            output, grader["case_sensitive"]
        )
        return float(passed), "Required content found." if passed else "Required content missing."
    if grader_type == "numeric":
        if not isinstance(output, (int, float)) or isinstance(output, bool):
            return 0.0, "Output is not numeric."
        passed = math.isclose(
            float(output),
            float(expected),
            rel_tol=0.0,
            abs_tol=float(grader["absolute_tolerance"]),
        )
        return float(passed), "Numeric comparison passed." if passed else "Numeric comparison failed."
    raise ProtocolError(f"Case '{case['id']}' requires rubric judge results.")


def _load_calibration(
    calibration_path: Path,
    *,
    dataset: dict[str, Any],
    judge: dict[str, Any],
    evaluator_id: str,
    contract: dict[str, Any],
    contract_path: Path,
) -> dict[str, Any]:
    calibration = load_json(calibration_path.resolve())
    required = {
        "version",
        "calibration_id",
        "dataset_id",
        "dataset_sha256",
        "contract_id",
        "contract_sha256",
        "judge_results_sha256",
        "judge_id",
        "evaluator_id",
        "executor_id",
        "independent",
        "authority",
        "can_approve",
        "can_promote",
        "qualified",
        "metrics",
        "thresholds",
        "calibrated_at",
    }
    _require_fields(calibration, required, "Calibration report")
    if calibration["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Calibration report version must be '{PROTOCOL_VERSION}'."
        )
    if calibration["dataset_id"] != dataset["id"] or calibration[
        "dataset_sha256"
    ] != sha256_file(Path(dataset["_path"])):
        raise ProtocolError("Calibration report is not bound to this dataset revision.")
    if calibration["judge_id"] != judge["judge_id"]:
        raise ProtocolError("Calibration report judge_id does not match judge results.")
    if calibration["contract_id"] != contract["id"] or calibration[
        "contract_sha256"
    ] != sha256_file(contract_path.resolve()):
        raise ProtocolError(
            "Calibration report is not bound to this evaluator-contract revision."
        )
    if calibration["evaluator_id"] != evaluator_id:
        raise ProtocolError(
            "Calibration report evaluator_id does not match evaluation identity."
        )
    _require_identity_separation(
        calibration["evaluator_id"],
        calibration["executor_id"],
    )
    if (
        calibration["independent"] is not True
        or calibration["authority"] != "advisory-only"
        or calibration["can_approve"] is not False
        or calibration["can_promote"] is not False
    ):
        raise ProtocolError(
            "Calibration report must remain independent and advisory-only."
        )
    if calibration["thresholds"] != contract["calibration"]:
        raise ProtocolError(
            "Calibration report thresholds do not match the evaluator contract."
        )
    metrics = calibration["metrics"]
    _require_fields(
        metrics,
        {
            "sample_count",
            "accuracy",
            "precision",
            "recall",
            "f1",
            "abstention_rate",
            "confusion_matrix",
        },
        "Calibration metrics",
    )
    if (
        not isinstance(metrics["sample_count"], int)
        or isinstance(metrics["sample_count"], bool)
        or metrics["sample_count"] < 0
    ):
        raise ProtocolError("Calibration sample_count must be a non-negative integer.")
    for field in ["accuracy", "precision", "recall", "f1", "abstention_rate"]:
        if (
            not _is_number(metrics[field])
            or not 0 <= metrics[field] <= 1
        ):
            raise ProtocolError(f"Calibration {field} must be between 0 and 1.")
    confusion = metrics["confusion_matrix"]
    _require_fields(
        confusion,
        {
            "true_positive",
            "false_positive",
            "true_negative",
            "false_negative",
        },
        "Calibration confusion matrix",
    )
    if any(
        not isinstance(confusion[field], int)
        or isinstance(confusion[field], bool)
        or confusion[field] < 0
        for field in [
            "true_positive",
            "false_positive",
            "true_negative",
            "false_negative",
        ]
    ):
        raise ProtocolError(
            "Calibration confusion-matrix values must be non-negative integers."
        )
    if sum(
        confusion[field]
        for field in [
            "true_positive",
            "false_positive",
            "true_negative",
            "false_negative",
        ]
    ) != metrics["sample_count"]:
        raise ProtocolError(
            "Calibration confusion matrix must account for every sample."
        )
    thresholds = contract["calibration"]
    qualified = (
        metrics["sample_count"] >= thresholds["minimum_samples"]
        and metrics["accuracy"] >= thresholds["minimum_accuracy"]
        and metrics["f1"] >= thresholds["minimum_f1"]
        and metrics["abstention_rate"] <= thresholds["maximum_abstention_rate"]
    )
    if calibration["qualified"] is not qualified:
        raise ProtocolError(
            "Calibration qualification is inconsistent with its metrics."
        )
    if not qualified:
        raise ProtocolError("Rubric judge is not qualified by calibration.")
    return calibration


def run_evaluation(
    dataset_path: Path,
    candidate_path: Path,
    contract_path: Path,
    *,
    split: str,
    evaluator_id: str,
    judge_results_path: Path | None = None,
    calibration_path: Path | None = None,
) -> dict[str, Any]:
    if split not in SPLITS:
        raise ProtocolError(f"Evaluation split must be one of {sorted(SPLITS)}.")
    dataset = validate_evaluation_dataset(dataset_path)
    dataset["_path"] = str(dataset_path.resolve())
    contract = validate_evaluator_contract(contract_path)
    candidate = load_json(candidate_path.resolve())
    executor_id = candidate.get("executor_id", "")
    _require_identity_separation(evaluator_id, executor_id)
    split_ids = set(dataset["splits"][split])
    outputs = _validate_candidate(candidate, dataset["id"], split_ids)
    cases = {
        case["id"]: case for case in dataset["cases"] if case["id"] in split_ids
    }
    rubric_case_ids = {
        case_id
        for case_id, case in cases.items()
        if case["grader"]["type"] == "rubric"
    }
    judge_results: dict[str, dict[str, Any]] = {}
    judge_id: str | None = None
    calibration_id: str | None = None
    judge_results_sha256: str | None = None
    calibration_sha256: str | None = None
    if rubric_case_ids:
        if judge_results_path is None or calibration_path is None:
            raise ProtocolError(
                "Rubric cases require judge results and a qualified calibration report."
            )
        judge = load_json(judge_results_path.resolve())
        judge_results = _validate_judge_results(
            judge,
            dataset_id=dataset["id"],
            candidate_id=candidate["candidate_id"],
            executor_id=executor_id,
            evaluator_id=evaluator_id,
            purpose="evaluation",
            case_ids=rubric_case_ids,
        )
        calibration = _load_calibration(
            calibration_path,
            dataset=dataset,
            judge=judge,
            evaluator_id=evaluator_id,
            contract=contract,
            contract_path=contract_path,
        )
        judge_id = judge["judge_id"]
        calibration_id = calibration["calibration_id"]
        judge_results_sha256 = sha256_file(judge_results_path.resolve())
        calibration_sha256 = sha256_file(calibration_path.resolve())

    results: list[dict[str, Any]] = []
    for case_id in dataset["splits"][split]:
        case = cases[case_id]
        output_record = outputs[case_id]
        grader_type = case["grader"]["type"]
        if grader_type == "rubric":
            judged = judge_results[case_id]
            score = float(judged["score"])
            passed = (
                judged["label"] == "pass"
                and score >= case["grader"]["minimum_score"]
            )
            reason = judged["reason"]
            evidence = judged["evidence"]
            label = judged["label"]
        else:
            score, reason = _score_deterministic(case, output_record["output"])
            passed = score == 1.0
            evidence = [f"case={case_id}", f"grader={grader_type}"]
            label = "pass" if passed else "fail"
        results.append(
            {
                "case_id": case_id,
                "split": split,
                "slices": case["slices"],
                "risk_tier": case["risk_tier"],
                "grader_type": grader_type,
                "score": score,
                "label": label,
                "passed": passed,
                "reason": reason,
                "evidence": evidence,
                "latency_ms": output_record["latency_ms"],
                "cost_usd": output_record["cost_usd"],
                "tool_calls": output_record["tool_calls"],
                "trace_path": output_record["trace_path"],
            }
        )
    failed = [result for result in results if not result["passed"]]
    needs_review = [result for result in results if result["label"] == "needs-review"]
    pass_rate = (len(results) - len(failed)) / len(results)
    thresholds = dataset["thresholds"]
    if (
        pass_rate < thresholds["minimum_pass_rate"]
        or len(failed) > thresholds["maximum_failed_cases"]
    ):
        verdict = "fail"
    elif needs_review:
        verdict = "needs-review"
    else:
        verdict = "pass"
    return {
        "version": PROTOCOL_VERSION,
        "evaluation_id": f"evaluation-{uuid.uuid4().hex}",
        "dataset_id": dataset["id"],
        "dataset_sha256": sha256_file(dataset_path.resolve()),
        "contract_id": contract["id"],
        "contract_sha256": sha256_file(contract_path.resolve()),
        "split": split,
        "candidate_id": candidate["candidate_id"],
        "candidate_sha256": sha256_file(candidate_path.resolve()),
        "executor_id": executor_id,
        "evaluator_id": evaluator_id,
        "judge_id": judge_id,
        "judge_results_sha256": judge_results_sha256,
        "calibration_id": calibration_id,
        "calibration_sha256": calibration_sha256,
        "independent": True,
        "authority": "advisory-only",
        "can_approve": False,
        "can_promote": False,
        "verdict": verdict,
        "thresholds": thresholds,
        "metrics": {
            "case_count": len(results),
            "passed_case_count": len(results) - len(failed),
            "failed_case_count": len(failed),
            "needs_review_count": len(needs_review),
            "pass_rate": pass_rate,
            "mean_score": mean(result["score"] for result in results),
            "mean_latency_ms": mean(result["latency_ms"] for result in results),
            "total_cost_usd": sum(result["cost_usd"] for result in results),
            "total_tool_calls": sum(result["tool_calls"] for result in results),
        },
        "results": results,
        "evaluated_at": datetime.now(UTC).isoformat(),
    }


def _index_evaluation_results(
    report: dict[str, Any],
    label: str,
) -> dict[str, dict[str, Any]]:
    results = report["results"]
    if not isinstance(results, list) or not results:
        raise ProtocolError(f"{label} evaluation results must be a non-empty list.")
    by_id: dict[str, dict[str, Any]] = {}
    expected_fields = {
        "case_id",
        "split",
        "slices",
        "risk_tier",
        "grader_type",
        "score",
        "label",
        "passed",
        "reason",
        "evidence",
        "latency_ms",
        "cost_usd",
        "tool_calls",
        "trace_path",
    }
    for result in results:
        _require_fields(result, expected_fields, f"{label} evaluation result")
        case_id = result["case_id"]
        if not isinstance(case_id, str) or not case_id.strip():
            raise ProtocolError(f"{label} evaluation result case_id is invalid.")
        if case_id in by_id:
            raise ProtocolError(
                f"{label} evaluation report has duplicate case '{case_id}'."
            )
        if result["risk_tier"] not in RISK_TIERS:
            raise ProtocolError(
                f"{label} evaluation case '{case_id}' has invalid risk tier."
            )
        if (
            not _is_number(result["score"])
            or not 0 <= result["score"] <= 1
            or not isinstance(result["passed"], bool)
        ):
            raise ProtocolError(
                f"{label} evaluation case '{case_id}' has invalid score state."
            )
        by_id[case_id] = result
    return by_id


def compare_evaluations(
    baseline_path: Path,
    candidate_path: Path,
    contract_path: Path,
) -> dict[str, Any]:
    contract = validate_evaluator_contract(contract_path)
    baseline = load_json(baseline_path.resolve())
    candidate = load_json(candidate_path.resolve())
    for report, label in [(baseline, "Baseline"), (candidate, "Candidate")]:
        _require_fields(
            report,
            {
                "version",
                "evaluation_id",
                "dataset_id",
                "dataset_sha256",
                "contract_id",
                "contract_sha256",
                "split",
                "candidate_id",
                "candidate_sha256",
                "executor_id",
                "evaluator_id",
                "judge_id",
                "judge_results_sha256",
                "calibration_id",
                "calibration_sha256",
                "independent",
                "authority",
                "can_approve",
                "can_promote",
                "verdict",
                "thresholds",
                "metrics",
                "results",
                "evaluated_at",
            },
            f"{label} evaluation report",
        )
        if report["version"] != PROTOCOL_VERSION:
            raise ProtocolError(f"{label} evaluation report version is invalid.")
        if (
            report["independent"] is not True
            or report["authority"] != "advisory-only"
            or report["can_approve"] is not False
            or report["can_promote"] is not False
        ):
            raise ProtocolError(
                f"{label} evaluation report must remain independent and advisory-only."
            )
        _require_identity_separation(
            report["evaluator_id"],
            report["executor_id"],
        )
        if report["contract_id"] != contract["id"] or report[
            "contract_sha256"
        ] != sha256_file(contract_path.resolve()):
            raise ProtocolError(
                f"{label} evaluation report uses another evaluator-contract revision."
            )
        if report["verdict"] not in {"pass", "fail", "needs-review"}:
            raise ProtocolError(f"{label} evaluation report verdict is invalid.")
        _require_fields(
            report["metrics"],
            {
                "case_count",
                "passed_case_count",
                "failed_case_count",
                "needs_review_count",
                "pass_rate",
                "mean_score",
                "mean_latency_ms",
                "total_cost_usd",
                "total_tool_calls",
            },
            f"{label} evaluation metrics",
        )
        for field in [
            "pass_rate",
            "mean_score",
            "mean_latency_ms",
            "total_cost_usd",
        ]:
            if not _is_number(report["metrics"][field]):
                raise ProtocolError(
                    f"{label} evaluation metric '{field}' must be numeric."
                )
    for field in ["dataset_id", "dataset_sha256", "split"]:
        if baseline.get(field) != candidate.get(field):
            raise ProtocolError(f"Evaluation reports have mismatched {field}.")
    baseline_results = _index_evaluation_results(baseline, "Baseline")
    candidate_results = _index_evaluation_results(candidate, "Candidate")
    if set(baseline_results) != set(candidate_results):
        raise ProtocolError("Evaluation reports do not contain the same paired cases.")
    minimum = contract["comparison"]["minimum_paired_cases"]
    if len(baseline_results) < minimum:
        raise ProtocolError(
            f"Evaluation comparison requires at least {minimum} paired cases."
        )
    cases: list[dict[str, Any]] = []
    wins = losses = ties = 0
    critical_regressions: list[str] = []
    for case_id in sorted(baseline_results):
        base = baseline_results[case_id]
        current = candidate_results[case_id]
        delta = current["score"] - base["score"]
        if delta > 0:
            outcome = "win"
            wins += 1
        elif delta < 0:
            outcome = "loss"
            losses += 1
        else:
            outcome = "tie"
            ties += 1
        if (
            current["risk_tier"] == "critical"
            and base["passed"]
            and not current["passed"]
        ):
            critical_regressions.append(case_id)
        cases.append(
            {
                "case_id": case_id,
                "risk_tier": current["risk_tier"],
                "baseline_score": base["score"],
                "candidate_score": current["score"],
                "delta": delta,
                "outcome": outcome,
            }
        )
    if critical_regressions:
        verdict = "candidate-worse"
    elif wins > losses:
        verdict = "candidate-better"
    elif losses > wins:
        verdict = "candidate-worse"
    else:
        verdict = "no-material-change"
    return {
        "version": PROTOCOL_VERSION,
        "comparison_id": f"comparison-{uuid.uuid4().hex}",
        "dataset_id": baseline["dataset_id"],
        "dataset_sha256": baseline["dataset_sha256"],
        "contract_id": contract["id"],
        "contract_sha256": sha256_file(contract_path.resolve()),
        "split": baseline["split"],
        "baseline_evaluation_id": baseline["evaluation_id"],
        "baseline_candidate_id": baseline["candidate_id"],
        "baseline_report_sha256": sha256_file(baseline_path.resolve()),
        "candidate_evaluation_id": candidate["evaluation_id"],
        "candidate_id": candidate["candidate_id"],
        "candidate_report_sha256": sha256_file(candidate_path.resolve()),
        "authority": "advisory-only",
        "can_approve": False,
        "can_promote": False,
        "verdict": verdict,
        "metrics": {
            "paired_case_count": len(cases),
            "wins": wins,
            "losses": losses,
            "ties": ties,
            "pass_rate_delta": (
                candidate["metrics"]["pass_rate"] - baseline["metrics"]["pass_rate"]
            ),
            "mean_score_delta": (
                candidate["metrics"]["mean_score"] - baseline["metrics"]["mean_score"]
            ),
            "cost_delta_usd": (
                candidate["metrics"]["total_cost_usd"]
                - baseline["metrics"]["total_cost_usd"]
            ),
            "latency_delta_ms": (
                candidate["metrics"]["mean_latency_ms"]
                - baseline["metrics"]["mean_latency_ms"]
            ),
        },
        "critical_regressions": critical_regressions,
        "cases": cases,
        "compared_at": datetime.now(UTC).isoformat(),
    }
