from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, load_json, write_text
from elder_protocol.profiles import identity_bindings_from_owners, validate_profile


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    if not slug:
        raise ProtocolError("Project name cannot be converted into a valid slug.")
    return slug


def profile_from_answers(
    answers: dict[str, Any], data: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    required = {
        "name",
        "mission",
        "success_outcomes",
        "failure_outcomes",
        "constraints",
        "project_type",
        "lifecycle",
        "topology",
        "risk_tier",
        "data_sensitivity",
        "autonomy_ceiling",
        "capability_packs",
        "languages",
        "deployment_targets",
        "knowledge_sources",
        "human_owners",
    }
    missing = required - answers.keys()
    unknown = answers.keys() - (required | {"slug", "skill_overrides"})
    if missing:
        raise ProtocolError(f"Intake answers are missing: {sorted(missing)}")
    if unknown:
        raise ProtocolError(f"Intake answers have unknown fields: {sorted(unknown)}")
    slug = answers.get("slug") or slugify(answers["name"])
    identities, role_bindings = identity_bindings_from_owners(
        slug,
        answers["human_owners"],
    )
    profile = {
        "protocol_version": PROTOCOL_VERSION,
        "profile_status": "draft",
        "name": answers["name"],
        "slug": slug,
        "mission": answers["mission"],
        "outcomes": {
            "success": answers["success_outcomes"],
            "failure": answers["failure_outcomes"],
        },
        "constraints": answers["constraints"],
        "project_type": answers["project_type"],
        "lifecycle": answers["lifecycle"],
        "topology": answers["topology"],
        "risk_tier": answers["risk_tier"],
        "data_sensitivity": answers["data_sensitivity"],
        "autonomy_ceiling": answers["autonomy_ceiling"],
        "capability_packs": answers["capability_packs"],
        "skill_overrides": answers.get(
            "skill_overrides", {"required": [], "forbidden": []}
        ),
        "languages": answers["languages"],
        "deployment_targets": answers["deployment_targets"],
        "knowledge_sources": answers["knowledge_sources"],
        "identities": identities,
        "role_bindings": role_bindings,
    }
    validate_profile(profile, data)
    return profile


def _split(value: str, separator: str = ",") -> list[str]:
    return [item.strip() for item in value.split(separator) if item.strip()]


def interactive_answers(input_fn: Callable[[str], str] = input) -> dict[str, Any]:
    print("Elder Wayfinder intake. Do not enter secrets.")
    name = input_fn("Project name: ").strip()
    mission = input_fn("Mission: ").strip()
    success = _split(input_fn("Success outcomes (separate with ';'): "), ";")
    failure = _split(input_fn("Failure outcomes (separate with ';'): "), ";")
    constraints = _split(input_fn("Constraints (separate with ';', blank allowed): "), ";")
    project_type = input_fn(
        "Project type [software|agentic|data|research|hybrid]: "
    ).strip()
    lifecycle = input_fn("Lifecycle [prototype|production|regulated]: ").strip()
    topology = input_fn(
        "Topology [single-repo|monorepo|multirepo|federated]: "
    ).strip()
    risk_tier = input_fn("Risk tier [low|moderate|high|critical]: ").strip()
    data_sensitivity = input_fn(
        "Data sensitivity [public|internal|confidential|restricted]: "
    ).strip()
    autonomy_ceiling = input_fn("Autonomy ceiling [L0|L1|L2|L3|L4|L5]: ").strip()
    capability_packs = _split(input_fn("Capability packs (comma separated): "))
    languages = _split(input_fn("Languages (comma separated): "))
    deployment_targets = _split(
        input_fn("Deployment targets (comma separated, blank allowed): ")
    )
    print("Human owners are role names or accountable identities, not credentials.")
    owners = {
        "human": input_fn("Accountable human owner: ").strip(),
        "product": input_fn("Product owner: ").strip(),
        "architecture": input_fn("Architecture owner: ").strip(),
        "security": input_fn("Security owner: ").strip(),
        "release": input_fn("Release owner: ").strip(),
        "code": input_fn("Code owner: ").strip(),
    }
    return {
        "name": name,
        "mission": mission,
        "success_outcomes": success,
        "failure_outcomes": failure,
        "constraints": constraints,
        "project_type": project_type,
        "lifecycle": lifecycle,
        "topology": topology,
        "risk_tier": risk_tier,
        "data_sensitivity": data_sensitivity,
        "autonomy_ceiling": autonomy_ceiling,
        "capability_packs": capability_packs,
        "languages": languages,
        "deployment_targets": deployment_targets,
        "knowledge_sources": [],
        "human_owners": owners,
    }


def run_intake(
    data: dict[str, dict[str, Any]],
    output: Path,
    answers_path: Path | None,
    input_fn: Callable[[str], str] = input,
) -> dict[str, Any]:
    answers = load_json(answers_path) if answers_path else interactive_answers(input_fn)
    profile = profile_from_answers(answers, data)
    write_text(output, json_text(profile))
    return profile
