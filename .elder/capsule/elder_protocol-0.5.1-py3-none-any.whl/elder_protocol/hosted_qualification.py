from __future__ import annotations

import base64
import binascii
import hashlib
import io
import json
import stat
import subprocess
import time
import zipfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
from cryptography.hazmat.primitives.hashes import SHA256

from elder_protocol.autonomy import canonical_sha256, trust_anchor_set_sha256
from elder_protocol.constants import PROTOCOL_DIR, PROTOCOL_VERSION, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, load_json, write_text
from elder_protocol.qualification import (
    CANONICAL_OPERATOR_ANCHOR_ID,
    CANONICAL_REVIEWER_ANCHOR_ID,
    CANONICAL_REVIEWER_PUBLIC_KEY_BASE64,
    CANONICAL_REVIEWER_SUBJECT,
    qualify_hosted_bundle,
    verify_trusted_statement,
)


GITHUB_OIDC_ISSUER = "https://token.actions.githubusercontent.com"
GITHUB_OIDC_CONFIGURATION = (
    f"{GITHUB_OIDC_ISSUER}/.well-known/openid-configuration"
)
ANCHOR_ID = CANONICAL_OPERATOR_ANCHOR_ID
ANCHOR_SUBJECT = (
    "operator:Neel-Error404:elder-protocol:p4.8a-independent-verifier"
)
REVIEWER_ANCHOR_ID = CANONICAL_REVIEWER_ANCHOR_ID
REVIEWER_SUBJECT = CANONICAL_REVIEWER_SUBJECT
PROVIDER = "github-actions"
REPOSITORY = "Neel-Error404/elder-protocol"
WORKFLOW_PATH = ".github/workflows/elder-ci.yml"
EVIDENCE_JOB = "P4.8A / hosted-evidence-input"
REQUIRED_JOBS = {
    "P3 / protocol",
    "P3 / reference-project",
    "P3 / reproducible-artifact",
}
TEST_LADDER = ["Foundation", "Component", "Integration", "Workflow", "Stress"]
L2_LEVELS = {"L0", "L1", "L2"}
MAX_PROVIDER_ARCHIVE_BYTES = 52_428_800
MAX_PROVIDER_ARCHIVE_FILES = 100
MAX_PROVIDER_EVIDENCE_AGE = timedelta(hours=24)


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")


def _content_digest(value: dict[str, Any]) -> str:
    payload = {
        key: item for key, item in value.items() if key != "content_sha256"
    }
    return hashlib.sha256(_canonical_bytes(payload)).hexdigest()


def _base64url_decode(value: str, label: str) -> bytes:
    try:
        return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except (ValueError, binascii.Error) as exc:
        raise ProtocolError(f"{label} is not valid base64url.") from exc


def _jwt_json(value: str, label: str) -> dict[str, Any]:
    try:
        decoded = json.loads(_base64url_decode(value, label))
    except json.JSONDecodeError as exc:
        raise ProtocolError(f"{label} is not valid JSON.") from exc
    if not isinstance(decoded, dict):
        raise ProtocolError(f"{label} must be a JSON object.")
    return decoded


def _fetch_json(url: str) -> dict[str, Any]:
    request = Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "elder-protocol-hosted-qualification",
        },
    )
    try:
        with urlopen(request, timeout=15) as response:
            payload = json.load(response)
    except (OSError, URLError, json.JSONDecodeError) as exc:
        raise ProtocolError(f"Unable to retrieve trusted OIDC metadata: {url}") from exc
    if not isinstance(payload, dict):
        raise ProtocolError(f"Trusted OIDC metadata must be an object: {url}")
    return payload


def load_github_oidc_jwks() -> dict[str, Any]:
    configuration = _fetch_json(GITHUB_OIDC_CONFIGURATION)
    if configuration.get("issuer") != GITHUB_OIDC_ISSUER:
        raise ProtocolError("GitHub OIDC metadata returned an unexpected issuer.")
    jwks_uri = configuration.get("jwks_uri")
    if not isinstance(jwks_uri, str) or not jwks_uri.startswith(
        f"{GITHUB_OIDC_ISSUER}/"
    ):
        raise ProtocolError("GitHub OIDC metadata returned an untrusted JWKS URI.")
    return _fetch_json(jwks_uri)


def verify_github_oidc_token(
    token: str,
    *,
    jwks: dict[str, Any],
    repository: str,
    repository_id: str,
    repository_owner_id: str,
    sha: str,
    ref: str,
    workflow_ref: str,
    audience: str,
    provider_window_start_epoch: int,
    provider_event_epoch: int,
) -> dict[str, Any]:
    parts = token.split(".")
    if len(parts) != 3 or any(not part for part in parts):
        raise ProtocolError("GitHub OIDC token must be a three-part JWT.")
    header = _jwt_json(parts[0], "GitHub OIDC header")
    claims = _jwt_json(parts[1], "GitHub OIDC claims")
    if header.get("alg") != "RS256":
        raise ProtocolError("GitHub OIDC token must use RS256.")
    key_id = header.get("kid")
    keys = jwks.get("keys")
    if not isinstance(key_id, str) or not isinstance(keys, list):
        raise ProtocolError("GitHub OIDC JWKS is incomplete.")
    matches = [
        key
        for key in keys
        if isinstance(key, dict)
        and key.get("kid") == key_id
        and key.get("kty") == "RSA"
        and key.get("use") in {None, "sig"}
        and key.get("alg") in {None, "RS256"}
    ]
    if len(matches) != 1:
        raise ProtocolError("GitHub OIDC signing key is missing or ambiguous.")
    jwk = matches[0]
    try:
        modulus = int.from_bytes(_base64url_decode(jwk["n"], "OIDC modulus"), "big")
        exponent = int.from_bytes(
            _base64url_decode(jwk["e"], "OIDC exponent"),
            "big",
        )
        RSAPublicNumbers(exponent, modulus).public_key().verify(
            _base64url_decode(parts[2], "GitHub OIDC signature"),
            f"{parts[0]}.{parts[1]}".encode("ascii"),
            PKCS1v15(),
            SHA256(),
        )
    except (KeyError, TypeError, ValueError, InvalidSignature) as exc:
        raise ProtocolError("GitHub OIDC signature verification failed.") from exc

    for field in ["iat", "nbf", "exp"]:
        if not isinstance(claims.get(field), int):
            raise ProtocolError(f"GitHub OIDC claim '{field}' must be an integer.")
    if not (claims["nbf"] <= provider_event_epoch < claims["exp"]):
        raise ProtocolError("GitHub OIDC token was not valid at the provider event time.")
    if not (
        provider_window_start_epoch - 60
        <= claims["iat"]
        <= provider_event_epoch + 60
    ):
        raise ProtocolError(
            "GitHub OIDC token was not issued during the trusted provider job."
        )
    if (
        claims["iat"] > provider_event_epoch + 60
        or claims["exp"] - claims["iat"] > 600
    ):
        raise ProtocolError("GitHub OIDC token timing is outside the allowed window.")
    audiences = claims.get("aud")
    audiences = audiences if isinstance(audiences, list) else [audiences]
    if audience not in audiences:
        raise ProtocolError("GitHub OIDC token audience does not match Elder.")
    expected = {
        "iss": GITHUB_OIDC_ISSUER,
        "repository": repository,
        "repository_id": repository_id,
        "repository_owner_id": repository_owner_id,
        "sha": sha,
        "ref": ref,
        "workflow_ref": workflow_ref,
        "runner_environment": "github-hosted",
    }
    for field, value in expected.items():
        if claims.get(field) != value:
            raise ProtocolError(
                f"GitHub OIDC claim '{field}' does not match provider evidence."
            )
    for field in [
        "actor",
        "actor_id",
        "event_name",
        "repository_owner",
        "repository_visibility",
        "run_attempt",
        "run_id",
        "run_number",
        "sub",
    ]:
        value = claims.get(field)
        if not isinstance(value, (str, int)) or str(value).strip() == "":
            raise ProtocolError(f"GitHub OIDC claim '{field}' is required.")
    owner, repository_name = repository.split("/", maxsplit=1)
    allowed_subjects = {
        f"repo:{repository}:ref:{ref}",
        (
            f"repo:{owner}@{repository_owner_id}/"
            f"{repository_name}@{repository_id}:ref:{ref}"
        ),
    }
    if claims["sub"] not in allowed_subjects:
        raise ProtocolError("GitHub OIDC subject does not bind the main branch.")
    if "job_workflow_ref" in claims and claims["job_workflow_ref"] != workflow_ref:
        raise ProtocolError("GitHub OIDC job workflow does not match Elder CI.")
    selected = sorted(
        set(expected)
        | {
            "actor",
            "actor_id",
            "aud",
            "event_name",
            "repository_owner",
            "repository_visibility",
            "run_attempt",
            "run_id",
            "run_number",
            "sub",
            "iat",
            "nbf",
            "exp",
        }
        | ({"job_workflow_ref"} if "job_workflow_ref" in claims else set())
    )
    return {field: claims[field] for field in selected}


def _gh_json(endpoint: str) -> dict[str, Any]:
    result = subprocess.run(
        ["gh", "api", endpoint],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise ProtocolError(
            f"GitHub provider query failed for '{endpoint}': {result.stderr.strip()}"
        )
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise ProtocolError(
            f"GitHub provider returned invalid JSON for '{endpoint}'."
        ) from exc
    if not isinstance(payload, dict):
        raise ProtocolError(f"GitHub provider response must be an object: {endpoint}")
    return payload


def fetch_github_provider_evidence(
    repository: str,
    run_id: str,
    run_attempt: str,
) -> dict[str, Any]:
    run = _gh_json(f"repos/{repository}/actions/runs/{run_id}")
    jobs = _gh_json(
        f"repos/{repository}/actions/runs/{run_id}/attempts/"
        f"{run_attempt}/jobs?per_page=100"
    )
    artifacts = _gh_json(
        f"repos/{repository}/actions/runs/{run_id}/artifacts?per_page=100"
    )
    return {"run": run, "jobs": jobs, "artifacts": artifacts}


def download_github_evidence_input(
    repository: str,
    run_id: str,
    run_attempt: str,
    artifact: dict[str, Any],
    target: Path,
) -> Path:
    target = target.resolve()
    artifact_name = f"elder-hosted-evidence-input-{run_id}-{run_attempt}"
    if artifact.get("name") != artifact_name:
        raise ProtocolError("Hosted evidence artifact name does not match the run.")
    artifact_id = artifact.get("id")
    if (
        not isinstance(artifact_id, int)
        or isinstance(artifact_id, bool)
        or artifact_id < 1
    ):
        raise ProtocolError("Hosted evidence artifact ID is invalid.")
    expected_digest = artifact.get("digest")
    if (
        not isinstance(expected_digest, str)
        or not expected_digest.startswith("sha256:")
        or len(expected_digest) != 71
    ):
        raise ProtocolError("Hosted evidence artifact has no valid SHA-256 digest.")
    try:
        int(expected_digest.removeprefix("sha256:"), 16)
    except ValueError as exc:
        raise ProtocolError("Hosted evidence artifact digest is not hexadecimal.") from exc
    expected_url = (
        f"https://api.github.com/repos/{repository}/actions/artifacts/"
        f"{artifact_id}/zip"
    )
    if artifact.get("archive_download_url") != expected_url:
        raise ProtocolError("Hosted evidence artifact URL does not match its API ID.")
    expected_size = artifact.get("size_in_bytes")
    if (
        not isinstance(expected_size, int)
        or expected_size < 1
        or expected_size > MAX_PROVIDER_ARCHIVE_BYTES
    ):
        raise ProtocolError("Hosted evidence artifact size is outside policy.")
    if target.exists():
        raise ProtocolError(f"Evidence archive target already exists: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [
            "gh",
            "api",
            artifact["archive_download_url"],
        ],
        cwd=ROOT,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise ProtocolError(
            "Unable to download hosted evidence input: "
            f"{result.stderr.decode('utf-8', errors='replace').strip()}"
        )
    archive_sha256 = hashlib.sha256(result.stdout).hexdigest()
    if f"sha256:{archive_sha256}" != expected_digest:
        raise ProtocolError(
            "Downloaded hosted evidence archive does not match GitHub's digest."
        )
    if len(result.stdout) != expected_size:
        raise ProtocolError(
            "Downloaded hosted evidence archive does not match GitHub's size."
        )
    target.write_bytes(result.stdout)
    return target


def _read_evidence_archive(archive_bytes: bytes) -> dict[str, bytes]:
    files: dict[str, bytes] = {}
    try:
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
            members = archive.infolist()
            if len(members) > MAX_PROVIDER_ARCHIVE_FILES:
                raise ProtocolError("Hosted evidence archive contains too many files.")
            if sum(member.file_size for member in members) > MAX_PROVIDER_ARCHIVE_BYTES:
                raise ProtocolError(
                    "Hosted evidence archive expands beyond the byte-size limit."
                )
            for member in members:
                member_path = Path(member.filename)
                if (
                    member_path.is_absolute()
                    or ".." in member_path.parts
                    or member.filename.endswith("\\")
                ):
                    raise ProtocolError(
                        "Hosted evidence archive contains an unsafe path."
                    )
                mode = member.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise ProtocolError(
                        "Hosted evidence archive contains a symbolic link."
                    )
                if member.is_dir():
                    continue
                name = member_path.as_posix()
                if name in files:
                    raise ProtocolError(
                        "Hosted evidence archive contains a duplicate path."
                    )
                files[name] = archive.read(member)
    except (OSError, zipfile.BadZipFile) as exc:
        raise ProtocolError("Hosted evidence artifact is not a valid ZIP archive.") from exc
    return files


def _archive_json(files: dict[str, bytes], name: str) -> dict[str, Any]:
    try:
        value = json.loads(files[name])
    except KeyError as exc:
        raise ProtocolError(f"Hosted evidence archive is missing {name}.") from exc
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError(f"Hosted evidence archive has invalid JSON: {name}.") from exc
    if not isinstance(value, dict):
        raise ProtocolError(f"Hosted evidence archive JSON must be an object: {name}.")
    return value


def _load_private_key(encoded: str) -> Ed25519PrivateKey:
    try:
        return Ed25519PrivateKey.from_private_bytes(
            base64.b64decode(encoded, validate=True)
        )
    except (ValueError, binascii.Error) as exc:
        raise ProtocolError(
            "Operator private key must be a base64-encoded 32-byte Ed25519 key."
        ) from exc


def _qualification_anchor(
    policy: dict[str, Any],
    private_key: Ed25519PrivateKey,
) -> dict[str, Any]:
    anchors = policy.get("trust", {}).get("anchors")
    matches = [
        anchor
        for anchor in anchors
        if isinstance(anchor, dict) and anchor.get("id") == ANCHOR_ID
    ] if isinstance(anchors, list) else []
    if len(matches) != 1:
        raise ProtocolError(
            f"Qualification policy must contain exactly one '{ANCHOR_ID}' anchor."
        )
    anchor = matches[0]
    expected_public_key = base64.b64encode(
        private_key.public_key().public_bytes_raw()
    ).decode("ascii")
    expected_fields = {
        "subject_identity": ANCHOR_SUBJECT,
        "public_key_base64": expected_public_key,
        "roles": ["accountable-operator", "independent-verifier"],
        "providers": ["elder-governance", PROVIDER],
        "source_hosts": ["github.com"],
        "status": "active",
    }
    for field, value in expected_fields.items():
        if anchor.get(field) != value:
            raise ProtocolError(
                f"Canonical trust anchor field '{field}' does not match the operator."
            )
    return anchor


def _validate_canonical_inputs(
    policy: dict[str, Any],
    maturity: dict[str, Any],
) -> None:
    autonomy_policy = load_json(PROTOCOL_DIR / "autonomy-policy.json")
    pinned = autonomy_policy["qualification_consumption"]
    if canonical_sha256(policy) != pinned["approved_policy_sha256"]:
        raise ProtocolError("Canonical qualification policy digest is not approved.")
    if canonical_sha256(maturity) != pinned["approved_maturity_model_sha256"]:
        raise ProtocolError("Canonical maturity model digest is not approved.")
    if (
        trust_anchor_set_sha256(policy)
        != pinned["approved_trust_anchor_set_sha256"]
    ):
        raise ProtocolError("Canonical trust-anchor set digest is not approved.")
    reviewer = {
        anchor["id"]: anchor for anchor in policy["trust"]["anchors"]
    }.get(REVIEWER_ANCHOR_ID)
    if (
        reviewer is None
        or reviewer.get("subject_identity") != REVIEWER_SUBJECT
        or reviewer.get("public_key_base64")
        != CANONICAL_REVIEWER_PUBLIC_KEY_BASE64
    ):
        raise ProtocolError("Canonical independent reviewer key is not pinned.")


def _validate_external_reviewer_pin(
    policy: dict[str, Any],
    reviewer_public_key_base64: str,
) -> None:
    reviewer = {
        anchor["id"]: anchor for anchor in policy["trust"]["anchors"]
    }.get(REVIEWER_ANCHOR_ID)
    if (
        reviewer_public_key_base64 != CANONICAL_REVIEWER_PUBLIC_KEY_BASE64
        or reviewer is None
        or reviewer.get("public_key_base64") != reviewer_public_key_base64
    ):
        raise ProtocolError(
            "Independent reviewer key does not match the out-of-band pin."
        )


def _validate_build_report(
    report: dict[str, Any],
    *,
    label: str,
    artifact_sha256: str,
) -> dict[str, Any]:
    if report.get("artifact_sha256") != artifact_sha256:
        raise ProtocolError(f"Build report artifact digest does not match: {label}")
    tests = report.get("test_results")
    if not isinstance(tests, list) or [
        result.get("level") for result in tests
    ] != TEST_LADDER:
        raise ProtocolError(f"Build report test ladder is incomplete: {label}")
    if any(
        result.get("status") != "passed" or result.get("returncode") != 0
        for result in tests
    ):
        raise ProtocolError(f"Build report contains a failed test level: {label}")
    source_tree = report.get("source_tree_sha256")
    if not isinstance(source_tree, str) or len(source_tree) != 64:
        raise ProtocolError(f"Build report source digest is invalid: {label}")
    return report


def _validate_local_revision(expected_sha: str) -> None:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if head.returncode != 0 or head.stdout.strip() != expected_sha:
        raise ProtocolError("Local verifier checkout does not match the hosted run.")
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if status.returncode != 0 or status.stdout.strip():
        raise ProtocolError("Local verifier checkout must be clean.")


def _validate_provider_evidence(
    provider: dict[str, Any],
    *,
    repository: str,
    run_id: str,
    run_attempt: str,
) -> dict[str, Any]:
    run = provider["run"]
    repository_data = run.get("repository")
    if not isinstance(repository_data, dict):
        raise ProtocolError("GitHub workflow run repository evidence is missing.")
    expected_run = {
        "id": int(run_id),
        "run_attempt": int(run_attempt),
        "event": "push",
        "head_branch": "main",
        "status": "completed",
        "conclusion": "success",
        "path": WORKFLOW_PATH,
    }
    for field, value in expected_run.items():
        if run.get(field) != value:
            raise ProtocolError(
                f"GitHub workflow run field '{field}' is not qualified."
            )
    if repository_data.get("full_name") != repository:
        raise ProtocolError("GitHub workflow run belongs to another repository.")
    expected_run_uri = f"https://github.com/{repository}/actions/runs/{run_id}"
    if run.get("html_url") != expected_run_uri:
        raise ProtocolError("GitHub workflow run URL does not match its repository.")
    head_sha = run.get("head_sha")
    if not isinstance(head_sha, str) or len(head_sha) not in {40, 64}:
        raise ProtocolError("GitHub workflow run head SHA is invalid.")

    jobs = provider["jobs"].get("jobs")
    if not isinstance(jobs, list):
        raise ProtocolError("GitHub workflow job evidence is missing.")
    if provider["jobs"].get("total_count") != len(jobs):
        raise ProtocolError("GitHub workflow job evidence is incomplete.")
    required_names = REQUIRED_JOBS | {EVIDENCE_JOB}
    by_name: dict[str, dict[str, Any]] = {}
    for job in jobs:
        if not isinstance(job, dict) or job.get("name") not in required_names:
            continue
        name = job["name"]
        if name in by_name:
            raise ProtocolError(f"GitHub workflow job name is duplicated: {name}")
        by_name[name] = job
    missing = required_names - set(by_name)
    if missing:
        raise ProtocolError(f"GitHub workflow jobs are missing: {sorted(missing)}")
    accepted_jobs = []
    accepted_job_ids: set[int] = set()
    for name in sorted(REQUIRED_JOBS | {EVIDENCE_JOB}):
        job = by_name[name]
        if job.get("status") != "completed" or job.get("conclusion") != "success":
            raise ProtocolError(f"GitHub workflow job did not pass: {name}")
        if job.get("run_id") != int(run_id) or job.get("head_sha") != head_sha:
            raise ProtocolError(f"GitHub workflow job is not bound to the run: {name}")
        job_id = job.get("id")
        if (
            not isinstance(job_id, int)
            or isinstance(job_id, bool)
            or job_id < 1
            or job_id in accepted_job_ids
        ):
            raise ProtocolError(
                f"GitHub workflow job ID is invalid or duplicated: {name}"
            )
        accepted_job_ids.add(job_id)
        expected_job_url = (
            f"https://github.com/{repository}/actions/runs/{run_id}/job/{job_id}"
        )
        if job.get("html_url") != expected_job_url:
            raise ProtocolError(
                f"GitHub workflow job URL does not match its provider ID: {name}"
            )
        accepted_jobs.append(
            {
                "id": job_id,
                "name": name,
                "status": job["status"],
                "conclusion": job["conclusion"],
                "head_sha": job["head_sha"],
                "html_url": job["html_url"],
                "runner_name": job.get("runner_name"),
                "labels": job.get("labels", []),
                "started_at": job.get("started_at"),
                "completed_at": job.get("completed_at"),
            }
        )

    artifacts = provider["artifacts"].get("artifacts")
    if not isinstance(artifacts, list):
        raise ProtocolError("GitHub artifact evidence is missing.")
    if provider["artifacts"].get("total_count") != len(artifacts):
        raise ProtocolError("GitHub artifact evidence is incomplete.")
    artifact_name = f"elder-hosted-evidence-input-{run_id}-{run_attempt}"
    matches = [
        artifact
        for artifact in artifacts
        if isinstance(artifact, dict) and artifact.get("name") == artifact_name
    ]
    if len(matches) != 1 or matches[0].get("expired") is not False:
        raise ProtocolError("Hosted evidence input artifact is missing or expired.")
    artifact = matches[0]
    artifact_id = artifact.get("id")
    if (
        not isinstance(artifact_id, int)
        or isinstance(artifact_id, bool)
        or artifact_id < 1
    ):
        raise ProtocolError("Hosted evidence artifact ID is invalid.")
    digest = artifact.get("digest")
    if (
        not isinstance(digest, str)
        or not digest.startswith("sha256:")
        or len(digest) != 71
    ):
        raise ProtocolError("Hosted evidence artifact has no valid SHA-256 digest.")
    expected_archive_url = (
        f"https://api.github.com/repos/{repository}/actions/artifacts/"
        f"{artifact_id}/zip"
    )
    if artifact.get("archive_download_url") != expected_archive_url:
        raise ProtocolError("Hosted evidence artifact URL does not match its API ID.")
    size_in_bytes = artifact.get("size_in_bytes")
    if (
        not isinstance(size_in_bytes, int)
        or size_in_bytes < 1
        or size_in_bytes > MAX_PROVIDER_ARCHIVE_BYTES
    ):
        raise ProtocolError("Hosted evidence artifact size is outside policy.")
    workflow_run = artifact.get("workflow_run")
    if (
        not isinstance(workflow_run, dict)
        or workflow_run.get("id") != int(run_id)
        or workflow_run.get("head_sha") != head_sha
    ):
        raise ProtocolError("Hosted evidence artifact is not bound to the run.")
    return {
        "repository_id": str(repository_data["id"]),
        "repository_owner_id": str(repository_data["owner"]["id"]),
        "head_sha": head_sha,
        "run_uri": expected_run_uri,
        "jobs": accepted_jobs,
        "evidence_job_id": by_name[EVIDENCE_JOB]["id"],
        "input_artifact": {
            "id": artifact_id,
            "name": artifact_name,
            "digest": artifact.get("digest"),
            "size_in_bytes": size_in_bytes,
            "archive_download_url": artifact["archive_download_url"],
        },
    }


def _sign_statement(
    statement: dict[str, Any],
    private_key: Ed25519PrivateKey,
) -> dict[str, Any]:
    statement_bytes = _canonical_bytes(statement)
    return {
        "signer_id": ANCHOR_ID,
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement_bytes).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement_bytes)
        ).decode("ascii"),
    }


def _gate_source_paths() -> dict[str, list[str]]:
    return {
        "l0-capability-documented-workflow": ["README.md", "AGENTS.md"],
        "l0-capability-versioned-source": ["ELDER_PROTOCOL.md"],
        "l0-capability-repeatable-verification": [
            WORKFLOW_PATH,
            "factory/factory-contract.json",
        ],
        "l0-evidence-successful-manual-replay": [
            "docs/evidence/2026-08-06-p4-8a-hosted-activation.md"
        ],
        "l1-capability-typed-work-items": [
            "protocol/work-item.schema.json",
            "protocol/autonomy-work-item.schema.json",
        ],
        "l1-capability-tool-scopes": [
            "protocol/authority-matrix.json",
            "protocol/tool-contract.schema.json",
        ],
        "l1-capability-execution-traces": [
            "protocol/agent-run.schema.json",
            "protocol/agent-action.schema.json",
        ],
        "l1-capability-human-approval": [
            "protocol/approval-decision.schema.json",
            "docs/adr/0017-p4-8a-hosted-git-identity-activation.md",
        ],
        "l1-evidence-trace-linkage": [
            "protocol/evidence-bundle.schema.json",
            "protocol/telemetry-event.schema.json",
        ],
        "l1-evidence-human-decision-record": [
            "docs/adr/0017-p4-8a-hosted-git-identity-activation.md"
        ],
        "l2-capability-sandboxing": [WORKFLOW_PATH],
        "l2-capability-reproducible-builds": [
            "elder_protocol/factory.py",
            "factory/factory-contract.json",
        ],
        "l2-capability-ci": [WORKFLOW_PATH],
        "l2-capability-provenance": [
            "elder_protocol/hosted_qualification.py",
            "protocol/hosted-evidence-bundle.schema.json",
        ],
        "l2-capability-independent-review": [
            "docs/evidence/2026-08-06-p4-8a-hosted-activation.md"
        ],
        "l2-evidence-clean-build": ["factory/factory-contract.json"],
        "l2-evidence-required-checks": [
            WORKFLOW_PATH,
        ],
        "l2-evidence-artifact-provenance": [
            "elder_protocol/hosted_qualification.py"
        ],
    }


def _trusted_sources(
    repository: str,
    sha: str,
    paths: list[str],
) -> list[dict[str, str]]:
    sources = []
    for relative in paths:
        relative_path = Path(relative)
        if (
            relative_path.is_absolute()
            or ".." in relative_path.parts
            or relative_path.as_posix() != relative
        ):
            raise ProtocolError(f"Qualification source path is unsafe: {relative}")
        result = subprocess.run(
            ["git", "show", f"{sha}:{relative}"],
            cwd=ROOT,
            capture_output=True,
            check=False,
        )
        if result.returncode != 0:
            raise ProtocolError(
                f"Qualification source does not exist at revision {sha}: {relative}"
            )
        sources.append(
            {
                "path": relative,
                "url": f"https://github.com/{repository}/blob/{sha}/{relative}",
                "sha256": hashlib.sha256(result.stdout).hexdigest(),
            }
        )
    return sources


def _verify_governance_entry(
    entry: Any,
    *,
    policy: dict[str, Any],
    hosted_sha: str,
    artifact_sha256: str,
    source_uri: str,
    created_at: datetime,
    name: str,
    signer_id: str,
    required_role: str,
) -> dict[str, Any]:
    if not isinstance(entry, dict) or set(entry) != {"statement", "attestation"}:
        raise ProtocolError(f"P4.8A {name} evidence must be a signed statement.")
    statement = entry["statement"]
    if not isinstance(statement, dict):
        raise ProtocolError(f"P4.8A {name} statement must be an object.")
    expected_bindings = {
        "project_id": "elder-protocol",
        "environment": "production",
        "artifact_sha256": artifact_sha256,
        "commit_sha": hosted_sha,
        "source_uri": source_uri,
    }
    for field, value in expected_bindings.items():
        if statement.get(field) != value:
            raise ProtocolError(f"P4.8A {name} field '{field}' is not bound.")
    actual_signer = verify_trusted_statement(
        entry["attestation"],
        statement=statement,
        qualification_policy=policy,
        provider="elder-governance",
        source_uri=source_uri,
        producer_identity=(
            f"codex-agent:implementation:{REPOSITORY}:p4.8a"
            if signer_id == ANCHOR_ID
            else ANCHOR_SUBJECT
        ),
        required_roles=[required_role],
        at=created_at.isoformat(),
        label=f"P4.8A {name}",
    )
    if actual_signer != signer_id:
        raise ProtocolError(f"P4.8A {name} was signed by the wrong identity.")
    return statement


def _load_governance_evidence(
    evidence: dict[str, Any],
    *,
    policy: dict[str, Any],
    hosted_sha: str,
    artifact_sha256: str,
    source_uri: str,
    created_at: datetime,
) -> dict[str, Any]:
    if set(evidence) != {
        "version",
        "project_id",
        "environment",
        "human_decision",
        "manual_replay",
        "independent_review",
    }:
        raise ProtocolError("P4.8A governance evidence has unexpected fields.")
    if (
        evidence["version"] != PROTOCOL_VERSION
        or evidence["project_id"] != "elder-protocol"
        or evidence["environment"] != "production"
    ):
        raise ProtocolError("P4.8A governance evidence scope is invalid.")

    decision = evidence["human_decision"]
    decision = _verify_governance_entry(
        decision,
        policy=policy,
        hosted_sha=hosted_sha,
        artifact_sha256=artifact_sha256,
        source_uri=source_uri,
        created_at=created_at,
        name="human decision",
        signer_id=ANCHOR_ID,
        required_role="accountable-operator",
    )
    expected_scope = [
        "remote",
        "protected-branch",
        "ci",
        "signed-provenance",
        "external-identity",
        "trust-anchors",
        "l2-qualification",
    ]
    if (
        decision.get("decision") != "approved"
        or decision.get("decided_by") != "Neel-Error404"
        or decision.get("decided_as_role") != "accountable-operator"
        or decision.get("scope") != expected_scope
    ):
        raise ProtocolError("P4.8A human approval record is not accountable.")

    replay = _verify_governance_entry(
        evidence["manual_replay"],
        policy=policy,
        hosted_sha=hosted_sha,
        artifact_sha256=artifact_sha256,
        source_uri=source_uri,
        created_at=created_at,
        name="manual replay",
        signer_id=ANCHOR_ID,
        required_role="accountable-operator",
    )
    levels = replay.get("levels")
    if (
        not isinstance(levels, list)
        or any(not isinstance(item, dict) for item in levels)
        or [item.get("level") for item in levels] != TEST_LADDER
        or any(
            item.get("status") != "passed"
            or not isinstance(item.get("test_count"), int)
            or item["test_count"] < 1
            for item in levels
        )
    ):
        raise ProtocolError("P4.8A manual replay evidence is incomplete.")

    review = _verify_governance_entry(
        evidence["independent_review"],
        policy=policy,
        hosted_sha=hosted_sha,
        artifact_sha256=artifact_sha256,
        source_uri=source_uri,
        created_at=created_at,
        name="independent review",
        signer_id=REVIEWER_ANCHOR_ID,
        required_role="independent-reviewer",
    )
    reviewed_sha = review.get("commit_sha")
    findings = review.get("remaining_findings")
    if (
        reviewed_sha != hosted_sha
        or review.get("reviewer_id") != REVIEWER_SUBJECT
        or findings != {"critical": 0, "high": 0, "medium": 0}
    ):
        raise ProtocolError("P4.8A independent review evidence is not clean.")
    return {
        "human_decision": decision,
        "manual_replay": replay,
        "independent_review": review,
    }


def _gate_evidence(
    gate_id: str,
    *,
    verified_provider: dict[str, Any],
    verified_identity: dict[str, Any],
    artifact_sha256: str,
    source_tree_sha256: str,
    primary: dict[str, Any],
    replay: dict[str, Any],
) -> dict[str, Any]:
    jobs = {job["name"]: job for job in verified_provider["jobs"]}
    if gate_id == "l0-capability-documented-workflow":
        return {"contract": "repository workflow and agent instructions"}
    if gate_id == "l0-capability-versioned-source":
        return {
            "repository": REPOSITORY,
            "commit_sha": verified_provider["head_sha"],
        }
    if gate_id == "l0-capability-repeatable-verification":
        return {
            "ordered_test_levels": TEST_LADDER,
            "protocol_job_id": jobs["P3 / protocol"]["id"],
            "reference_job_id": jobs["P3 / reference-project"]["id"],
        }
    if gate_id == "l1-capability-typed-work-items":
        return {
            "contracts": [
                "protocol/work-item.schema.json",
                "protocol/autonomy-work-item.schema.json",
            ]
        }
    if gate_id == "l1-capability-tool-scopes":
        return {
            "contracts": [
                "protocol/authority-matrix.json",
                "protocol/tool-contract.schema.json",
            ]
        }
    if gate_id == "l1-capability-execution-traces":
        return {
            "contracts": [
                "protocol/agent-run.schema.json",
                "protocol/agent-action.schema.json",
            ]
        }
    if gate_id == "l1-evidence-trace-linkage":
        return {
            "run_uri": verified_provider["run_uri"],
            "commit_sha": verified_provider["head_sha"],
            "artifact_id": verified_provider["input_artifact"]["id"],
            "evidence_job_id": verified_provider["evidence_job_id"],
            "workload_identity_subject": verified_identity["sub"],
        }
    if gate_id == "l2-capability-sandboxing":
        return {
            "runner_environment": verified_identity["runner_environment"],
            "runner_labels": jobs["P3 / reproducible-artifact"]["labels"],
            "credential_persistence": False,
        }
    if gate_id == "l2-capability-reproducible-builds":
        return {
            "artifact_sha256": artifact_sha256,
            "source_tree_sha256": source_tree_sha256,
            "build_ids": [primary["build_id"], replay["build_id"]],
        }
    if gate_id == "l2-capability-ci":
        return {
            "run_uri": verified_provider["run_uri"],
            "successful_job_ids": [job["id"] for job in verified_provider["jobs"]],
        }
    if gate_id == "l2-evidence-clean-build":
        return {
            "primary_build_id": primary["build_id"],
            "replay_build_id": replay["build_id"],
            "artifact_sha256": artifact_sha256,
        }
    if gate_id == "l2-evidence-required-checks":
        return {
            "required_jobs": [
                {"name": name, "job_id": jobs[name]["id"], "conclusion": "success"}
                for name in sorted(REQUIRED_JOBS)
            ]
        }
    raise ProtocolError(f"No requirement-specific evidence builder exists for {gate_id}.")


def issue_github_l2_bundle(
    *,
    output_dir: Path,
    evidence_archive_path: Path,
    governance_evidence_path: Path,
    provider_evidence: dict[str, Any],
    private_key_base64: str,
    reviewer_public_key_base64: str,
    repository: str,
    run_id: str,
    run_attempt: str,
    jwks: dict[str, Any] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    if repository != REPOSITORY:
        raise ProtocolError(f"Canonical hosted qualification requires {REPOSITORY}.")
    verified_provider = _validate_provider_evidence(
        provider_evidence,
        repository=repository,
        run_id=run_id,
        run_attempt=run_attempt,
    )
    sha = verified_provider["head_sha"]
    _validate_local_revision(sha)
    created_at = (now or datetime.now(UTC)).astimezone(UTC)

    expected_archive_digest = verified_provider["input_artifact"]["digest"]
    archive_bytes = evidence_archive_path.read_bytes()
    archive_sha256 = hashlib.sha256(archive_bytes).hexdigest()
    if f"sha256:{archive_sha256}" != expected_archive_digest:
        raise ProtocolError(
            "Hosted evidence archive does not match provider artifact evidence."
        )
    if len(archive_bytes) != verified_provider["input_artifact"]["size_in_bytes"]:
        raise ProtocolError(
            "Hosted evidence archive size does not match provider evidence."
        )
    evidence_files = _read_evidence_archive(archive_bytes)
    context = _archive_json(evidence_files, "github-context.json")
    expected_context = {
        "repository": repository,
        "repository_id": verified_provider["repository_id"],
        "repository_owner_id": verified_provider["repository_owner_id"],
        "sha": sha,
        "ref": "refs/heads/main",
        "workflow_ref": f"{repository}/{WORKFLOW_PATH}@refs/heads/main",
        "run_id": run_id,
        "run_attempt": run_attempt,
        "event_name": "push",
        "runner_environment": "github-hosted",
        "workflow_job": "hosted-evidence-input",
        "evidence_job_id": str(verified_provider["evidence_job_id"]),
        "prerequisite_results": {
            name: "success" for name in sorted(REQUIRED_JOBS)
        },
    }
    if context != expected_context:
        raise ProtocolError("Hosted context does not match GitHub provider evidence.")
    oidc_bytes = evidence_files.get("github-oidc.jwt")
    if oidc_bytes is None:
        raise ProtocolError("Hosted evidence input is missing its OIDC token.")
    try:
        oidc_token = oidc_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ProtocolError("Hosted evidence OIDC token is not UTF-8.") from exc
    evidence_job = next(
        job for job in verified_provider["jobs"] if job["name"] == EVIDENCE_JOB
    )
    try:
        provider_window_start = datetime.fromisoformat(
            evidence_job["started_at"].replace("Z", "+00:00")
        ).astimezone(UTC)
        provider_event = datetime.fromisoformat(
            evidence_job["completed_at"].replace("Z", "+00:00")
        ).astimezone(UTC)
    except (AttributeError, TypeError, ValueError) as exc:
        raise ProtocolError(
            "GitHub evidence job timestamps are invalid."
        ) from exc
    if provider_event < provider_window_start:
        raise ProtocolError("GitHub evidence job timestamps are reversed.")
    if (
        provider_event > created_at + timedelta(seconds=60)
        or created_at - provider_event > MAX_PROVIDER_EVIDENCE_AGE
    ):
        raise ProtocolError(
            "GitHub provider evidence is outside the qualification freshness window."
        )
    verified_identity = verify_github_oidc_token(
        oidc_token,
        jwks=load_github_oidc_jwks() if jwks is None else jwks,
        repository=repository,
        repository_id=verified_provider["repository_id"],
        repository_owner_id=verified_provider["repository_owner_id"],
        sha=sha,
        ref="refs/heads/main",
        workflow_ref=f"{repository}/{WORKFLOW_PATH}@refs/heads/main",
        audience="elder-protocol",
        provider_window_start_epoch=int(provider_window_start.timestamp()),
        provider_event_epoch=int(provider_event.timestamp()),
    )
    if (
        str(verified_identity["run_id"]) != run_id
        or str(verified_identity["run_attempt"]) != run_attempt
        or verified_identity["event_name"] != "push"
    ):
        raise ProtocolError("GitHub OIDC identity is not bound to the provider run.")

    artifact_bytes = evidence_files.get("elder-workbench.zip")
    if artifact_bytes is None:
        raise ProtocolError("Hosted evidence input is missing the built artifact.")
    artifact_sha256 = hashlib.sha256(artifact_bytes).hexdigest()
    primary = _validate_build_report(
        _archive_json(evidence_files, "primary-build-report.json"),
        label="primary-build-report.json",
        artifact_sha256=artifact_sha256,
    )
    replay = _validate_build_report(
        _archive_json(evidence_files, "replay-build-report.json"),
        label="replay-build-report.json",
        artifact_sha256=artifact_sha256,
    )
    if (
        primary["artifact_sha256"] != replay["artifact_sha256"]
        or primary["source_tree_sha256"] != replay["source_tree_sha256"]
    ):
        raise ProtocolError("Hosted reproducible builds do not match.")

    policy = load_json(PROTOCOL_DIR / "qualification-policy.json")
    maturity = load_json(PROTOCOL_DIR / "operational-maturity.json")
    _validate_canonical_inputs(policy, maturity)
    _validate_external_reviewer_pin(policy, reviewer_public_key_base64)
    private_key = _load_private_key(private_key_base64)
    anchor = _qualification_anchor(policy, private_key)
    governance_bytes = governance_evidence_path.resolve().read_bytes()
    try:
        governance_text = governance_bytes.decode("utf-8")
        governance_document = json.loads(governance_text)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("P4.8A governance evidence is not valid JSON.") from exc
    if not isinstance(governance_document, dict):
        raise ProtocolError("P4.8A governance evidence must be an object.")
    _load_governance_evidence(
        governance_document,
        policy=policy,
        hosted_sha=sha,
        artifact_sha256=artifact_sha256,
        source_uri=verified_provider["run_uri"],
        created_at=created_at,
    )
    valid_from = datetime.fromisoformat(
        anchor["valid_from"].replace("Z", "+00:00")
    ).astimezone(UTC)
    valid_until = datetime.fromisoformat(
        anchor["valid_until"].replace("Z", "+00:00")
    ).astimezone(UTC)
    if created_at < valid_from or created_at >= valid_until:
        raise ProtocolError("Operator trust anchor is outside its validity window.")
    expires_at = min(created_at + timedelta(days=20), valid_until)

    output_dir = output_dir.resolve()
    payload_dir = output_dir / "payloads"
    payload_dir.mkdir(parents=True, exist_ok=True)
    provider_digest = hashlib.sha256(
        _canonical_bytes(provider_evidence)
    ).hexdigest()
    provenance_statement = {
        "type": "https://elder.local/provenance/v1",
        "subject": {
            "name": "elder-workbench.zip",
            "sha256": artifact_sha256,
        },
        "build": {
            "repository": repository,
            "commit_sha": sha,
            "ref": "refs/heads/main",
            "workflow_ref": f"{repository}/{WORKFLOW_PATH}@refs/heads/main",
            "run_id": run_id,
            "run_attempt": run_attempt,
            "run_uri": verified_provider["run_uri"],
            "provider_evidence_sha256": provider_digest,
            "provider_jobs": verified_provider["jobs"],
            "input_artifact": verified_provider["input_artifact"],
            "primary_build_id": primary["build_id"],
            "replay_build_id": replay["build_id"],
            "source_tree_sha256": primary["source_tree_sha256"],
            "ordered_test_levels": TEST_LADDER,
        },
        "workload_identity": {
            "token_sha256": hashlib.sha256(
                oidc_token.encode("utf-8")
            ).hexdigest(),
            "verified_claims": verified_identity,
        },
        "producer_identity": (
            f"github-actions:{repository}:workflow:elder-ci:artifact-producer"
        ),
        "verifier_identity": ANCHOR_SUBJECT,
        "issued_at": created_at.isoformat(),
    }
    signed_provenance = {
        "statement": provenance_statement,
        "attestation": _sign_statement(provenance_statement, private_key),
    }
    signed_provenance["content_sha256"] = _content_digest(signed_provenance)
    signed_provenance_path = payload_dir / "signed-provenance.json"
    write_text(signed_provenance_path, json_text(signed_provenance))
    governance_payload_path = payload_dir / "signed-governance-evidence.json"
    write_text(
        governance_payload_path,
        governance_text,
    )
    write_text(
        output_dir / "github-provider-evidence.json",
        json_text(provider_evidence),
    )

    source_paths = _gate_source_paths()
    required_gates = [
        gate for gate in policy["gates"] if gate["level"] in L2_LEVELS
    ]
    if set(source_paths) != {gate["id"] for gate in required_gates}:
        raise ProtocolError("L2 source map does not match canonical qualification gates.")
    records = []
    producer_identity = (
        f"github-actions:{repository}:run:{run_id}:attempt:{run_attempt}"
    )
    for index, gate in enumerate(required_gates, start=1):
        gate_id = gate["id"]
        if gate_id in {
            "l2-capability-provenance",
            "l2-evidence-artifact-provenance",
        }:
            payload_path = signed_provenance_path
        elif gate_id in {
            "l0-evidence-successful-manual-replay",
            "l1-capability-human-approval",
            "l1-evidence-human-decision-record",
            "l2-capability-independent-review",
        }:
            payload_path = governance_payload_path
        else:
            evidence = _gate_evidence(
                gate_id,
                verified_provider=verified_provider,
                verified_identity=verified_identity,
                artifact_sha256=artifact_sha256,
                source_tree_sha256=primary["source_tree_sha256"],
                primary=primary,
                replay=replay,
            )
            payload = {
                "gate_id": gate_id,
                "level": gate["level"],
                "requirement_kind": gate["requirement_kind"],
                "requirement": gate["requirement"],
                "evidence": evidence,
                "repository": repository,
                "commit_sha": sha,
                "run_uri": verified_provider["run_uri"],
                "artifact_sha256": artifact_sha256,
                "source_tree_sha256": primary["source_tree_sha256"],
                "provider_evidence_sha256": provider_digest,
                "provider_jobs": verified_provider["jobs"],
                "reproducible_build_ids": [
                    primary["build_id"],
                    replay["build_id"],
                ],
                "trusted_sources": _trusted_sources(
                    repository,
                    sha,
                    source_paths[gate_id],
                ),
                "verified_workload_identity": verified_identity,
                "independently_verified_by": ANCHOR_SUBJECT,
                "issued_at": created_at.isoformat(),
            }
            payload_path = payload_dir / f"{gate_id}.json"
            write_text(payload_path, json_text(payload))
        record = {
            "id": f"GHA-L2-{index:03d}",
            "gate_id": gate_id,
            "evidence_type": gate["evidence_types"][0],
            "provider": PROVIDER,
            "project_id": "elder-protocol",
            "environment": "production",
            "artifact_sha256": artifact_sha256,
            "producer_identity": producer_identity,
            "source_uri": verified_provider["run_uri"],
            "payload_path": payload_path.relative_to(output_dir).as_posix(),
            "payload_sha256": hashlib.sha256(payload_path.read_bytes()).hexdigest(),
            "result": "passed",
            "issued_at": created_at.isoformat(),
            "expires_at": expires_at.isoformat(),
        }
        record["attestation"] = _sign_statement(record, private_key)
        record["content_sha256"] = _content_digest(record)
        records.append(record)

    bundle = {
        "version": PROTOCOL_VERSION,
        "bundle_id": f"GHA-{run_id}-{run_attempt}-L2",
        "source_revision": sha,
        "project_id": "elder-protocol",
        "environment": "production",
        "target_level": "L2",
        "artifact_sha256": artifact_sha256,
        "provider": PROVIDER,
        "producer_identity": producer_identity,
        "source_uri": verified_provider["run_uri"],
        "created_at": created_at.isoformat(),
        "expires_at": expires_at.isoformat(),
        "records": records,
    }
    bundle["attestation"] = _sign_statement(bundle, private_key)
    bundle["content_sha256"] = _content_digest(bundle)
    manifest_path = output_dir / "bundle.json"
    write_text(manifest_path, json_text(bundle))
    report = qualify_hosted_bundle(
        manifest_path,
        policy,
        maturity,
        at=created_at.isoformat(),
    )
    if not report["qualified"] or report["achieved_level"] != "L2":
        raise ProtocolError("Provider-bound hosted evidence did not achieve L2.")
    report_path = output_dir / "qualification-report.json"
    write_text(report_path, json_text(report))
    summary = {
        "bundle_path": str(manifest_path),
        "qualification_report_path": str(report_path),
        "signed_provenance_path": str(signed_provenance_path),
        "artifact_sha256": artifact_sha256,
        "source_tree_sha256": primary["source_tree_sha256"],
        "repository": repository,
        "commit_sha": sha,
        "run_id": run_id,
        "run_attempt": run_attempt,
        "provider_job_ids": [
            job["id"] for job in verified_provider["jobs"]
        ],
        "external_identity_subject": verified_identity["sub"],
        "independent_verifier": ANCHOR_SUBJECT,
        "qualified": True,
        "achieved_level": "L2",
        "canonical_current_level": report["canonical_current_level"],
    }
    write_text(output_dir / "summary.json", json_text(summary))
    return summary


def issue_github_l2_bundle_from_provider(
    *,
    output_dir: Path,
    governance_evidence_path: Path,
    private_key_base64: str,
    reviewer_public_key_base64: str,
    repository: str,
    run_id: str,
    run_attempt: str,
) -> dict[str, Any]:
    provider_evidence = fetch_github_provider_evidence(
        repository,
        run_id,
        run_attempt,
    )
    verified_provider = _validate_provider_evidence(
        provider_evidence,
        repository=repository,
        run_id=run_id,
        run_attempt=run_attempt,
    )
    archive_path = output_dir.parent / f"hosted-input-{run_id}-{run_attempt}.zip"
    try:
        download_github_evidence_input(
            repository,
            run_id,
            run_attempt,
            verified_provider["input_artifact"],
            archive_path,
        )
        return issue_github_l2_bundle(
            output_dir=output_dir,
            evidence_archive_path=archive_path,
            governance_evidence_path=governance_evidence_path,
            provider_evidence=provider_evidence,
            private_key_base64=private_key_base64,
            reviewer_public_key_base64=reviewer_public_key_base64,
            repository=repository,
            run_id=run_id,
            run_attempt=run_attempt,
        )
    finally:
        archive_path.unlink(missing_ok=True)
