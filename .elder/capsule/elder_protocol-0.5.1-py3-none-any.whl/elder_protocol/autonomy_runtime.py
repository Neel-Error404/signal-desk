from __future__ import annotations

import copy
import fnmatch
from datetime import UTC, datetime, timedelta
from pathlib import Path, PurePosixPath
from typing import Any, Protocol
from urllib.parse import unquote, urlparse

from elder_protocol.autonomy import (
    calculate_effective_autonomy,
    canonical_sha256,
    consume_qualification,
    reverify_qualification_consumption,
    validate_autonomy_authority_source,
    validate_autonomy_policy,
    validate_certification,
)
from elder_protocol.constants import PROTOCOL_DIR, PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.qualification import LEVELS, verify_trusted_statement


TEST_LEVELS = ["Foundation", "Component", "Integration", "Workflow", "Stress"]
EVENT_TYPES = [
    "issued",
    "activated",
    "incident-recorded",
    "rollback-recorded",
    "suspended",
    "suspension-released",
    "revoked",
    "renewed",
    "expired",
]
class PullRequestSubmitter(Protocol):
    def submit(self, packet: dict[str, Any]) -> dict[str, Any]:
        """Submit one already-authorized supervised pull request."""


def _content_digest(value: dict[str, Any]) -> str:
    return canonical_sha256(
        {key: item for key, item in value.items() if key != "content_sha256"}
    )


def _finalize(value: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(value)
    result["content_sha256"] = _content_digest(result)
    return result


def _require_fields(
    value: Any,
    required: set[str],
    label: str,
) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != required:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(required)}")
    return value


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value


def _require_string_list(
    value: Any,
    label: str,
    *,
    allow_empty: bool = False,
) -> list[str]:
    if (
        not isinstance(value, list)
        or (not allow_empty and not value)
        or any(not isinstance(item, str) or not item.strip() for item in value)
    ):
        qualifier = "" if allow_empty else "non-empty "
        raise ProtocolError(f"{label} must be a {qualifier}list of strings.")
    if len(value) != len(set(value)):
        raise ProtocolError(f"{label} cannot contain duplicates.")
    return value


def _parse_datetime(value: Any, label: str) -> datetime:
    _require_string(value, label)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO-8601 datetime.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


def _require_sha256(value: Any, label: str, *, allow_none: bool = False) -> str | None:
    if allow_none and value is None:
        return None
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ProtocolError(
            f"{label} must be 64 lowercase hexadecimal characters."
        )
    return value


def _require_git_oid(value: Any, object_format: Any, label: str) -> str:
    if object_format not in {"sha1", "sha256"}:
        raise ProtocolError(f"{label} git_object_format must be sha1 or sha256.")
    expected_length = 40 if object_format == "sha1" else 64
    if (
        not isinstance(value, str)
        or len(value) != expected_length
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ProtocolError(
            f"{label} must be a full {object_format} Git object id "
            f"with {expected_length} lowercase hexadecimal characters."
        )
    return value


def _require_pr_url_prefix(value: Any, repository: Any, label: str) -> str:
    prefix = _require_string(value, label)
    repository_path = _require_string(repository, f"{label} repository").strip("/")
    if repository_path.endswith(".git"):
        repository_path = repository_path[:-4]
    parsed = urlparse(prefix)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or not parsed.path.endswith("/")
    ):
        raise ProtocolError(
            f"{label} must be a credential-free HTTPS URI prefix without "
            "a query or fragment."
        )
    if not unquote(parsed.path).startswith(f"/{repository_path}/"):
        raise ProtocolError(f"{label} must be bound to the authorized repository.")
    return prefix


def _verify_digest(value: dict[str, Any], label: str) -> None:
    _require_sha256(value.get("content_sha256"), f"{label} content_sha256")
    if value["content_sha256"] != _content_digest(value):
        raise ProtocolError(f"{label} content digest does not match its fields.")


def _normalize_path(value: Any, label: str) -> str:
    path = _require_string(value, label)
    if "\\" in path:
        raise ProtocolError(f"{label} must use forward slashes.")
    pure = PurePosixPath(path)
    if pure.is_absolute() or ".." in pure.parts or "." in pure.parts:
        raise ProtocolError(f"{label} must be a normalized project-relative path.")
    normalized = pure.as_posix()
    if normalized in {"", "."}:
        raise ProtocolError(f"{label} must identify a project file.")
    return normalized


def _matches(path: str, patterns: list[str]) -> bool:
    return any(
        not pattern.startswith("<") and fnmatch.fnmatchcase(path, pattern)
        for pattern in patterns
    )


def _class_by_id(
    registry: dict[str, Any],
    autonomy_class_id: str,
) -> dict[str, Any]:
    autonomy_class = next(
        (
            item
            for item in registry.get("classes", [])
            if item.get("id") == autonomy_class_id
        ),
        None,
    )
    if autonomy_class is None:
        raise ProtocolError(f"Unknown autonomy class: {autonomy_class_id}")
    return autonomy_class


def validate_autonomy_work_item(work_item: dict[str, Any]) -> dict[str, Any]:
    _require_fields(
        work_item,
        {
            "version",
            "work_item_id",
            "project_id",
            "parent_change_class",
            "autonomy_class_id",
            "objective",
            "changes",
            "tool",
            "checks",
            "observed_effects",
            "generator_inputs_unchanged",
            "semantic_equivalence",
            "evidence_plan",
            "content_sha256",
        },
        "Autonomy work item",
    )
    if work_item["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy work-item version must be '{PROTOCOL_VERSION}'."
        )
    work_item_id = _require_string(
        work_item["work_item_id"], "Autonomy work-item id"
    )
    _require_string(work_item["project_id"], "Autonomy work-item project_id")
    _require_string(
        work_item["parent_change_class"],
        "Autonomy work-item parent_change_class",
    )
    _require_string(
        work_item["autonomy_class_id"],
        "Autonomy work-item autonomy_class_id",
    )
    objective = _require_string(work_item["objective"], "Autonomy objective")
    if len(objective.strip()) < 10:
        raise ProtocolError("Autonomy objective must contain at least 10 characters.")

    changes = work_item["changes"]
    if not isinstance(changes, list) or not changes:
        raise ProtocolError("Autonomy work item requires at least one file change.")
    seen_paths: set[str] = set()
    for index, change in enumerate(changes):
        _require_fields(
            change,
            {
                "path",
                "operation",
                "existed_before",
                "generated",
                "production_code",
                "test_support",
                "generator_input",
                "fixture",
                "snapshot",
                "configuration",
                "before_sha256",
                "after_sha256",
            },
            f"Autonomy change {index}",
        )
        path = _normalize_path(change["path"], f"Autonomy change {index} path")
        if path in seen_paths:
            raise ProtocolError(f"Autonomy work item repeats changed path: {path}")
        seen_paths.add(path)
        if change["operation"] not in {"add", "modify", "delete"}:
            raise ProtocolError(
                f"Autonomy change '{path}' has an unsupported operation."
            )
        for field in [
            "existed_before",
            "generated",
            "production_code",
            "test_support",
            "generator_input",
            "fixture",
            "snapshot",
            "configuration",
        ]:
            if not isinstance(change[field], bool):
                raise ProtocolError(
                    f"Autonomy change '{path}' {field} must be boolean."
                )
        before = _require_sha256(
            change["before_sha256"],
            f"Autonomy change '{path}' before_sha256",
            allow_none=True,
        )
        after = _require_sha256(
            change["after_sha256"],
            f"Autonomy change '{path}' after_sha256",
            allow_none=True,
        )
        if change["operation"] == "add":
            if change["existed_before"] or before is not None or after is None:
                raise ProtocolError(
                    f"Added path '{path}' requires no prior file and an after digest."
                )
        elif change["operation"] == "delete":
            if not change["existed_before"] or before is None or after is not None:
                raise ProtocolError(
                    f"Deleted path '{path}' requires a prior digest and no after digest."
                )
        elif not change["existed_before"] or before is None or after is None:
            raise ProtocolError(
                f"Modified path '{path}' requires prior and after digests."
            )
        if before is not None and before == after:
            raise ProtocolError(f"Autonomy change '{path}' has no content change.")

    tool = _require_fields(
        work_item["tool"],
        {"id", "digest_sha256", "rule_ids"},
        "Autonomy work-item tool",
    )
    _require_string(tool["id"], "Autonomy work-item tool id")
    _require_sha256(
        tool["digest_sha256"],
        "Autonomy work-item tool digest",
        allow_none=True,
    )
    _require_string_list(
        tool["rule_ids"],
        "Autonomy work-item tool rule_ids",
        allow_empty=True,
    )

    checks = work_item["checks"]
    if not isinstance(checks, list):
        raise ProtocolError("Autonomy work-item checks must be a list.")
    check_names: list[str] = []
    for index, check in enumerate(checks):
        _require_fields(
            check,
            {"name", "status", "evidence"},
            f"Autonomy check {index}",
        )
        name = _require_string(check["name"], f"Autonomy check {index} name")
        check_names.append(name)
        if check["status"] not in {"planned", "passed", "failed"}:
            raise ProtocolError(
                f"Autonomy check '{name}' status must be planned, passed, or failed."
            )
        _require_string_list(
            check["evidence"],
            f"Autonomy check '{name}' evidence",
            allow_empty=check["status"] != "passed",
        )
    if len(check_names) != len(set(check_names)):
        raise ProtocolError("Autonomy work-item checks cannot repeat names.")

    _require_string_list(
        work_item["observed_effects"],
        "Autonomy observed_effects",
        allow_empty=True,
    )
    if not isinstance(work_item["generator_inputs_unchanged"], bool):
        raise ProtocolError("generator_inputs_unchanged must be boolean.")
    equivalence = _require_fields(
        work_item["semantic_equivalence"],
        {"mode", "status", "evidence"},
        "Autonomy semantic equivalence",
    )
    if equivalence["mode"] not in {"none", "generated-exact", "language-adapter"}:
        raise ProtocolError("Autonomy semantic-equivalence mode is invalid.")
    if equivalence["status"] not in {"not-required", "planned", "verified", "failed"}:
        raise ProtocolError("Autonomy semantic-equivalence status is invalid.")
    _require_string_list(
        equivalence["evidence"],
        "Autonomy semantic-equivalence evidence",
        allow_empty=equivalence["status"] != "verified",
    )
    _require_string_list(work_item["evidence_plan"], "Autonomy evidence_plan")
    _verify_digest(work_item, f"Autonomy work item '{work_item_id}'")
    return work_item


def match_autonomy_work_item(
    work_item: dict[str, Any],
    registry: dict[str, Any],
    *,
    certification: dict[str, Any],
    policy: dict[str, Any],
) -> dict[str, Any]:
    validate_autonomy_work_item(work_item)
    autonomy_class = _class_by_id(registry, work_item["autonomy_class_id"])
    validate_certification(
        certification,
        policy=policy,
        autonomy_class=autonomy_class,
    )
    blockers: list[str] = []
    if work_item["project_id"] != certification["project_id"]:
        blockers.append("project-mismatch")
    if work_item["autonomy_class_id"] != certification["autonomy_class_id"]:
        blockers.append("certification-class-mismatch")
    if work_item["parent_change_class"] != autonomy_class["parent_change_class"]:
        blockers.append("parent-change-class-mismatch")

    bindings = {
        binding["id"]: binding for binding in certification["tool_bindings"]
    }
    binding = bindings.get(work_item["tool"]["id"])
    if binding is None:
        blockers.append("tool-not-certified")
    else:
        if (
            autonomy_class["controls"]["requires_pinned_tool_digest"]
            and (
                work_item["tool"]["digest_sha256"] is None
                or work_item["tool"]["digest_sha256"]
                != binding["digest_sha256"]
            )
        ):
            blockers.append("tool-digest-mismatch")
        if not set(work_item["tool"]["rule_ids"]) <= set(binding["rule_ids"]):
            blockers.append("rule-not-certified")
    if (
        autonomy_class["controls"]["requires_rule_allowlist"]
        and not work_item["tool"]["rule_ids"]
    ):
        blockers.append("rule-allowlist-required")

    scope = autonomy_class["scope"]
    for change in work_item["changes"]:
        path = change["path"]
        if change["operation"] not in autonomy_class["allowed_operations"]:
            blockers.append(f"operation-not-allowed:{path}")
        if path not in certification["scope_paths"]:
            blockers.append(f"outside-certification-scope:{path}")
        concrete_allowed = [
            pattern
            for pattern in scope["allowed_path_globs"]
            if not pattern.startswith("<")
        ]
        if concrete_allowed and not _matches(path, concrete_allowed):
            blockers.append(f"outside-class-scope:{path}")
        if _matches(path, scope["forbidden_path_globs"]):
            blockers.append(f"forbidden-path:{path}")
        if scope["new_files_only"] and (
            change["operation"] != "add" or change["existed_before"]
        ):
            blockers.append(f"not-new-file:{path}")
        if scope["generated_files_only"] and not change["generated"]:
            blockers.append(f"not-generated:{path}")
        if scope["existing_files_unchanged"] and change["operation"] != "add":
            blockers.append(f"existing-file-change:{path}")
        if scope["production_code_unchanged"] and change["production_code"]:
            blockers.append(f"production-code-change:{path}")
        if scope["test_support_unchanged"] and change["test_support"]:
            blockers.append(f"test-support-change:{path}")
        if change["fixture"]:
            blockers.append(f"fixture-change:{path}")
        if change["snapshot"]:
            blockers.append(f"snapshot-change:{path}")
        if change["configuration"]:
            blockers.append(f"configuration-change:{path}")
        if scope["generator_inputs_unchanged"] and change["generator_input"]:
            blockers.append(f"generator-input-change:{path}")
    if (
        scope["generator_inputs_unchanged"]
        and not work_item["generator_inputs_unchanged"]
    ):
        blockers.append("generator-inputs-not-proven-unchanged")

    report = {
        "version": PROTOCOL_VERSION,
        "work_item_id": work_item["work_item_id"],
        "work_item_sha256": work_item["content_sha256"],
        "project_id": work_item["project_id"],
        "autonomy_class_id": autonomy_class["id"],
        "certification_id": certification["certification_id"],
        "matched": not blockers,
        "blockers": sorted(set(blockers)),
        "matched_paths": sorted(change["path"] for change in work_item["changes"]),
        "tool_binding_id": binding["id"] if binding is not None else None,
        "authority_activated": False,
        "simulation_only": True,
    }
    return _finalize(report)


def simulate_autonomy_work_item(
    work_item: dict[str, Any],
    registry: dict[str, Any],
    *,
    certification: dict[str, Any],
    policy: dict[str, Any],
) -> dict[str, Any]:
    match = match_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=policy,
    )
    autonomy_class = _class_by_id(registry, work_item["autonomy_class_id"])
    blockers = list(match["blockers"])
    checks = {item["name"]: item for item in work_item["checks"]}
    for required in autonomy_class["controls"]["required_checks"]:
        check = checks.get(required)
        if check is None:
            blockers.append(f"missing-check:{required}")
        elif check["status"] != "passed":
            blockers.append(f"check-not-passed:{required}")
    forbidden_effects = set(autonomy_class["controls"]["forbidden_effects"])
    for effect in sorted(set(work_item["observed_effects"]) & forbidden_effects):
        blockers.append(f"forbidden-effect:{effect}")
    required_equivalence = autonomy_class["controls"]["semantic_equivalence"]
    equivalence = work_item["semantic_equivalence"]
    if required_equivalence == "none":
        if equivalence["mode"] != "none":
            blockers.append("unexpected-semantic-equivalence-mode")
    elif (
        equivalence["mode"] != required_equivalence
        or equivalence["status"] != "verified"
    ):
        blockers.append("semantic-equivalence-not-verified")

    report = {
        "version": PROTOCOL_VERSION,
        "simulation_id": f"simulation-{work_item['work_item_id']}",
        "work_item_id": work_item["work_item_id"],
        "work_item_sha256": work_item["content_sha256"],
        "match_report_sha256": match["content_sha256"],
        "autonomy_class_id": autonomy_class["id"],
        "certification_id": certification["certification_id"],
        "status": "passed" if not blockers else "blocked",
        "blockers": sorted(set(blockers)),
        "required_checks": list(autonomy_class["controls"]["required_checks"]),
        "simulated_changes": sorted(
            (
                {
                    "path": change["path"],
                    "operation": change["operation"],
                    "after_sha256": change["after_sha256"],
                }
                for change in work_item["changes"]
            ),
            key=lambda item: item["path"],
        ),
        "side_effects_performed": [],
        "authority_activated": False,
        "can_create_pr": False,
        "can_merge": False,
        "can_deploy": False,
        "can_mutate_maturity": False,
    }
    return _finalize(report)


def validate_certification_event(
    event: dict[str, Any],
    *,
    policy: dict[str, Any],
) -> dict[str, Any]:
    _require_fields(
        event,
        {
            "version",
            "event_id",
            "certification_id",
            "autonomy_class_id",
            "sequence",
            "event_type",
            "occurred_at",
            "actor_id",
            "actor_role",
            "payload",
            "evidence",
            "previous_event_sha256",
            "content_sha256",
        },
        "Autonomy certification event",
    )
    if event["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy certification-event version must be '{PROTOCOL_VERSION}'."
        )
    event_id = _require_string(event["event_id"], "Certification event id")
    _require_string(event["certification_id"], "Certification event certification_id")
    _require_string(
        event["autonomy_class_id"], "Certification event autonomy_class_id"
    )
    if not isinstance(event["sequence"], int) or event["sequence"] <= 0:
        raise ProtocolError("Certification event sequence must be positive.")
    if event["event_type"] not in EVENT_TYPES:
        raise ProtocolError(
            f"Certification event type must be one of: {EVENT_TYPES}"
        )
    _parse_datetime(event["occurred_at"], "Certification event occurred_at")
    _require_string(event["actor_id"], "Certification event actor_id")
    _require_string(event["actor_role"], "Certification event actor_role")
    role_field = {
        "issued": "required_issuer_roles",
        "activated": "required_issuer_roles",
        "suspended": "suspension_roles",
        "suspension-released": "suspension_roles",
        "revoked": "revocation_roles",
        "renewed": "renewal_roles",
    }.get(event["event_type"])
    if (
        role_field is not None
        and event["actor_role"] not in policy["certification"][role_field]
    ):
        raise ProtocolError(
            f"Certification event '{event_id}' actor role is not permitted by policy."
        )
    if not isinstance(event["payload"], dict):
        raise ProtocolError("Certification event payload must be an object.")
    _require_string_list(
        event["evidence"],
        "Certification event evidence",
        allow_empty=event["event_type"] in {"expired"},
    )
    _require_sha256(
        event["previous_event_sha256"],
        "Certification event previous_event_sha256",
        allow_none=True,
    )
    _verify_digest(event, f"Certification event '{event_id}'")
    return event


def replay_certification(
    certification: dict[str, Any],
    autonomy_class: dict[str, Any],
    events: list[dict[str, Any]],
    *,
    policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    if not events:
        raise ProtocolError("Certification replay requires at least one event.")
    evaluated_at = _parse_datetime(at, "Certification replay time")
    ordered = sorted(events, key=lambda item: item.get("sequence", 0))
    status = "candidate"
    incident_count = 0
    rollback_count = 0
    valid_until = _parse_datetime(
        certification["valid_until"], "Certification valid_until"
    )
    previous_digest: str | None = None
    previous_time: datetime | None = None
    seen_ids: set[str] = set()
    for expected_sequence, event in enumerate(ordered, start=1):
        validate_certification_event(event, policy=policy)
        if event["sequence"] != expected_sequence:
            raise ProtocolError("Certification event sequences must be contiguous.")
        if event["event_id"] in seen_ids:
            raise ProtocolError("Certification event ids must be unique.")
        seen_ids.add(event["event_id"])
        if event["certification_id"] != certification["certification_id"]:
            raise ProtocolError("Certification event targets another certification.")
        if event["autonomy_class_id"] != autonomy_class["id"]:
            raise ProtocolError("Certification event targets another autonomy class.")
        if event["previous_event_sha256"] != previous_digest:
            raise ProtocolError("Certification event hash chain is invalid.")
        occurred_at = _parse_datetime(
            event["occurred_at"], "Certification event occurred_at"
        )
        if occurred_at > evaluated_at:
            raise ProtocolError(
                "Certification replay cannot apply events after its evaluation time."
            )
        if previous_time is not None and occurred_at < previous_time:
            raise ProtocolError("Certification event times must be monotonic.")
        previous_time = occurred_at
        event_type = event["event_type"]
        if expected_sequence == 1:
            if event_type != "issued":
                raise ProtocolError("Certification replay must begin with issued.")
            if event["payload"] != {
                "certification_sha256": certification["content_sha256"],
                "initial_status": "candidate",
            }:
                raise ProtocolError("Issued event does not bind the certification.")
        elif event_type == "activated":
            if status != "candidate":
                raise ProtocolError("Only a candidate certification can be activated.")
            status = "active"
        elif event_type == "incident-recorded":
            if status not in {"active", "suspended"}:
                raise ProtocolError("Incidents require an active or suspended certification.")
            incident_count += 1
        elif event_type == "rollback-recorded":
            if status not in {"active", "suspended"}:
                raise ProtocolError("Rollbacks require an active or suspended certification.")
            rollback_count += 1
        elif event_type == "suspended":
            if status != "active":
                raise ProtocolError("Only an active certification can be suspended.")
            status = "suspended"
        elif event_type == "suspension-released":
            if status != "suspended":
                raise ProtocolError("Only a suspended certification can be released.")
            status = "active"
        elif event_type == "revoked":
            if status in {"revoked", "expired"}:
                raise ProtocolError("A terminal certification cannot be revoked again.")
            status = "revoked"
        elif event_type == "renewed":
            if status not in {"active", "suspended"}:
                raise ProtocolError("Only a live certification can be renewed.")
            renewed_until = _parse_datetime(
                event["payload"].get("new_valid_until"),
                "Renewed certification new_valid_until",
            )
            if renewed_until <= valid_until:
                raise ProtocolError("Certification renewal must extend validity.")
            maximum_ttl = timedelta(days=autonomy_class["certification_ttl_days"])
            if renewed_until - occurred_at > maximum_ttl:
                raise ProtocolError("Certification renewal exceeds the class TTL.")
            valid_until = renewed_until
        elif event_type == "expired":
            if occurred_at < valid_until:
                raise ProtocolError("Certification cannot expire before valid_until.")
            status = "expired"
        if status in {"revoked", "expired"} and event is not ordered[-1]:
            raise ProtocolError("Certification events cannot follow a terminal state.")
        previous_digest = event["content_sha256"]

    if evaluated_at >= valid_until and status not in {"revoked", "expired"}:
        status = "expired"
    budget = autonomy_class["incident_budget"]
    exhausted = (
        incident_count > budget["maximum_incidents"]
        or rollback_count > budget["maximum_rollbacks"]
    )
    suspension_required = exhausted and status == "active"
    report = {
        "version": PROTOCOL_VERSION,
        "certification_id": certification["certification_id"],
        "autonomy_class_id": autonomy_class["id"],
        "evaluated_at": evaluated_at.isoformat(),
        "event_count": len(ordered),
        "last_event_sha256": previous_digest,
        "derived_status": status,
        "valid_until": valid_until.isoformat(),
        "incident_count": incident_count,
        "maximum_incidents": budget["maximum_incidents"],
        "rollback_count": rollback_count,
        "maximum_rollbacks": budget["maximum_rollbacks"],
        "incident_budget_exhausted": exhausted,
        "suspension_required": suspension_required,
        "authority_activated": False,
    }
    return _finalize(report)


def _require_exact_derived_record(
    supplied: dict[str, Any],
    recomputed: dict[str, Any],
    label: str,
) -> None:
    _verify_digest(supplied, label)
    if supplied != recomputed:
        raise ProtocolError(f"{label} does not match trusted-source recomputation.")


def _load_canonical_autonomy_authority(
    project_id: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    source = load_json(PROTOCOL_DIR / "autonomy-authority-source.json")
    validate_autonomy_authority_source(source)
    matching = [
        project
        for project in source["projects"]
        if project["project_id"] == project_id and project["status"] == "active"
    ]
    if len(matching) != 1:
        raise ProtocolError(
            f"Project '{project_id}' has no active canonical autonomy authority source."
        )
    return source, matching[0]


def _validate_autonomy_authority_evidence_envelope(
    evidence: dict[str, Any],
    *,
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    maturity_model: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    _require_fields(
        evidence,
        {
            "version",
            "evidence_id",
            "authority_source_id",
            "authority_source_sha256",
            "project_id",
            "autonomy_class_id",
            "certification_id",
            "provider",
            "producer_identity",
            "source_uri",
            "issued_at",
            "expires_at",
            "autonomy_policy_sha256",
            "autonomy_classes_sha256",
            "change_classes_sha256",
            "qualification_policy_sha256",
            "maturity_model_sha256",
            "project_autonomy_ceiling",
            "work_item_sha256",
            "certification_sha256",
            "certification_event_sha256s",
            "certification_replay_sha256",
            "qualification_consumption_sha256",
            "incident_budget_sha256",
            "suspension_sha256s",
            "revocation_sha256s",
            "qualification_state_checks_sha256",
            "artifact_sha256",
            "effective_autonomy_sha256",
            "match_report_sha256",
            "simulation_report_sha256",
            "attestation",
            "content_sha256",
        },
        "Autonomy authority evidence",
    )
    if evidence["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy authority evidence version must be '{PROTOCOL_VERSION}'."
        )
    evidence_id = _require_string(
        evidence["evidence_id"], "Autonomy authority evidence id"
    )
    for field in [
        "project_id",
        "authority_source_id",
        "autonomy_class_id",
        "certification_id",
        "provider",
        "producer_identity",
        "source_uri",
    ]:
        _require_string(evidence[field], f"Autonomy authority evidence {field}")
    _require_sha256(
        evidence["authority_source_sha256"],
        "Autonomy authority evidence authority_source_sha256",
    )
    if evidence["project_autonomy_ceiling"] not in LEVELS:
        raise ProtocolError("Autonomy authority evidence project ceiling is invalid.")
    for field in [
        "autonomy_policy_sha256",
        "autonomy_classes_sha256",
        "change_classes_sha256",
        "qualification_policy_sha256",
        "maturity_model_sha256",
        "work_item_sha256",
        "certification_sha256",
        "certification_replay_sha256",
        "qualification_consumption_sha256",
        "incident_budget_sha256",
        "qualification_state_checks_sha256",
        "artifact_sha256",
        "effective_autonomy_sha256",
        "match_report_sha256",
        "simulation_report_sha256",
    ]:
        _require_sha256(
            evidence[field],
            f"Autonomy authority evidence {field}",
        )
    for field, allow_empty in [
        ("certification_event_sha256s", False),
        ("suspension_sha256s", True),
        ("revocation_sha256s", True),
    ]:
        values = _require_string_list(
            evidence[field],
            f"Autonomy authority evidence {field}",
            allow_empty=allow_empty,
        )
        for index, value in enumerate(values):
            _require_sha256(
                value,
                f"Autonomy authority evidence {field}[{index}]",
            )
    authority_source, canonical_project = _load_canonical_autonomy_authority(
        evidence["project_id"]
    )
    if evidence["authority_source_id"] != authority_source["id"]:
        raise ProtocolError(
            "Autonomy authority evidence source id does not match canonical truth."
        )
    if evidence["authority_source_sha256"] != canonical_sha256(authority_source):
        raise ProtocolError(
            "Autonomy authority evidence source digest does not match canonical truth."
        )
    expected_configuration = {
        "autonomy_policy_sha256": canonical_sha256(policy),
        "autonomy_classes_sha256": canonical_sha256(registry),
        "change_classes_sha256": canonical_sha256(change_classes),
        "qualification_policy_sha256": canonical_sha256(qualification_policy),
        "maturity_model_sha256": canonical_sha256(maturity_model),
    }
    for field, expected in expected_configuration.items():
        if canonical_project[field] != expected:
            raise ProtocolError(
                f"Configured {field} does not match canonical project authority."
            )
        if evidence[field] != canonical_project[field]:
            raise ProtocolError(
                f"Autonomy authority evidence {field} does not match canonical truth."
            )
    if (
        evidence["project_autonomy_ceiling"]
        != canonical_project["project_autonomy_ceiling"]
    ):
        raise ProtocolError(
            "Autonomy authority evidence project ceiling does not match canonical truth."
        )
    issued_at = _parse_datetime(
        evidence["issued_at"], "Autonomy authority evidence issued_at"
    )
    expires_at = _parse_datetime(
        evidence["expires_at"], "Autonomy authority evidence expires_at"
    )
    evaluated_at = _parse_datetime(at, "Autonomy authority evidence evaluation time")
    if issued_at > evaluated_at:
        raise ProtocolError("Autonomy authority evidence cannot be future-dated.")
    if expires_at <= issued_at or evaluated_at >= expires_at:
        raise ProtocolError(
            "Autonomy authority evidence is expired or has an invalid window."
        )
    if evaluated_at - issued_at > timedelta(
        minutes=policy["supervised_pr"][
            "authority_evidence_maximum_age_minutes"
        ]
    ):
        raise ProtocolError("Autonomy authority evidence is stale.")
    _verify_digest(evidence, f"Autonomy authority evidence '{evidence_id}'")
    statement = {
        key: value
        for key, value in evidence.items()
        if key not in {"attestation", "content_sha256"}
    }
    verify_trusted_statement(
        evidence["attestation"],
        statement=statement,
        qualification_policy=qualification_policy,
        provider=evidence["provider"],
        source_uri=evidence["source_uri"],
        producer_identity=evidence["producer_identity"],
        required_roles=policy["supervised_pr"][
            "authority_evidence_required_signer_roles"
        ],
        at=evaluated_at.isoformat(),
        label=f"Autonomy authority evidence '{evidence_id}'",
    )
    return evidence


def validate_autonomy_authority_evidence(
    evidence: dict[str, Any],
    *,
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    maturity_model: dict[str, Any],
    project_autonomy_ceiling: str,
    work_item: dict[str, Any],
    certification: dict[str, Any],
    certification_events: list[dict[str, Any]],
    certification_replay_report: dict[str, Any],
    qualification_consumption: dict[str, Any],
    incident_budget: dict[str, Any],
    suspensions: list[dict[str, Any]],
    revocations: list[dict[str, Any]],
    qualification_state_checks: dict[str, dict[str, Any]],
    artifact_sha256: str,
    effective_autonomy_report: dict[str, Any],
    match_report: dict[str, Any],
    simulation_report: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    _validate_autonomy_authority_evidence_envelope(
        evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        registry=registry,
        change_classes=change_classes,
        maturity_model=maturity_model,
        at=at,
    )
    expected = {
        "project_id": work_item["project_id"],
        "autonomy_class_id": work_item["autonomy_class_id"],
        "certification_id": certification["certification_id"],
        "project_autonomy_ceiling": project_autonomy_ceiling,
        "work_item_sha256": work_item["content_sha256"],
        "certification_sha256": certification["content_sha256"],
        "certification_event_sha256s": [
            event["content_sha256"] for event in certification_events
        ],
        "certification_replay_sha256": certification_replay_report[
            "content_sha256"
        ],
        "qualification_consumption_sha256": qualification_consumption[
            "content_sha256"
        ],
        "incident_budget_sha256": incident_budget["content_sha256"],
        "suspension_sha256s": [
            suspension["content_sha256"] for suspension in suspensions
        ],
        "revocation_sha256s": [
            revocation["content_sha256"] for revocation in revocations
        ],
        "qualification_state_checks_sha256": canonical_sha256(
            qualification_state_checks
        ),
        "artifact_sha256": artifact_sha256,
        "effective_autonomy_sha256": effective_autonomy_report["content_sha256"],
        "match_report_sha256": match_report["content_sha256"],
        "simulation_report_sha256": simulation_report["content_sha256"],
    }
    for field, expected_value in expected.items():
        if evidence[field] != expected_value:
            raise ProtocolError(
                f"Autonomy authority evidence {field} does not match trusted "
                "authority records."
            )
    return evidence


def issue_supervised_pr_lease(
    policy: dict[str, Any],
    *,
    work_item: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    project_autonomy_ceiling: str,
    certification: dict[str, Any],
    certification_events: list[dict[str, Any]],
    certification_replay_report: dict[str, Any],
    qualification_consumption: dict[str, Any],
    incident_budget: dict[str, Any],
    suspensions: list[dict[str, Any]],
    revocations: list[dict[str, Any]],
    authority_evidence: dict[str, Any],
    qualification_manifest_path: Path,
    qualification_policy: dict[str, Any],
    maturity_model: dict[str, Any],
    qualification_state_checks: dict[str, dict[str, Any]],
    artifact_sha256: str,
    effective_autonomy_report: dict[str, Any],
    match_report: dict[str, Any],
    simulation_report: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    evaluated_at = _parse_datetime(at, "Authority-lease issue time")
    validate_autonomy_policy(
        policy,
        registry,
        change_classes,
        qualification_policy=qualification_policy,
        maturity_model=maturity_model,
    )
    validate_autonomy_work_item(work_item)
    _validate_autonomy_authority_evidence_envelope(
        authority_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        registry=registry,
        change_classes=change_classes,
        maturity_model=maturity_model,
        at=evaluated_at.isoformat(),
    )
    autonomy_class = _class_by_id(registry, work_item["autonomy_class_id"])
    validate_certification(
        certification,
        policy=policy,
        autonomy_class=autonomy_class,
    )
    recomputed_replay = replay_certification(
        certification,
        autonomy_class,
        certification_events,
        policy=policy,
        at=evaluated_at.isoformat(),
    )
    _require_exact_derived_record(
        certification_replay_report,
        recomputed_replay,
        "Certification replay report",
    )
    reverified_consumption = consume_qualification(
        qualification_manifest_path,
        qualification_policy,
        maturity_model,
        policy,
        project_id=work_item["project_id"],
        environment=certification["environment"],
        artifact_sha256=artifact_sha256,
        requested_level=policy["supervised_pr"]["required_effective_level"],
        state_checks=qualification_state_checks,
        at=evaluated_at.isoformat(),
    )
    if qualification_consumption != reverified_consumption:
        raise ProtocolError(
            "Qualification consumption does not match signed-bundle re-verification."
        )
    recomputed_effective = calculate_effective_autonomy(
        policy,
        registry,
        change_classes,
        project_id=work_item["project_id"],
        project_autonomy_ceiling=project_autonomy_ceiling,
        autonomy_class_id=work_item["autonomy_class_id"],
        certification=certification,
        qualification_consumption=reverified_consumption,
        incident_budget=incident_budget,
        suspensions=suspensions,
        revocations=revocations,
        at=evaluated_at.isoformat(),
    )
    recomputed_match = match_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=policy,
    )
    recomputed_simulation = simulate_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=policy,
    )
    _require_exact_derived_record(
        effective_autonomy_report,
        recomputed_effective,
        "Effective-autonomy report",
    )
    _require_exact_derived_record(
        match_report,
        recomputed_match,
        "Autonomy match report",
    )
    _require_exact_derived_record(
        simulation_report,
        recomputed_simulation,
        "Autonomy simulation report",
    )
    validate_autonomy_authority_evidence(
        authority_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        registry=registry,
        change_classes=change_classes,
        maturity_model=maturity_model,
        project_autonomy_ceiling=project_autonomy_ceiling,
        work_item=work_item,
        certification=certification,
        certification_events=certification_events,
        certification_replay_report=recomputed_replay,
        qualification_consumption=reverified_consumption,
        incident_budget=incident_budget,
        suspensions=suspensions,
        revocations=revocations,
        qualification_state_checks=qualification_state_checks,
        artifact_sha256=artifact_sha256,
        effective_autonomy_report=recomputed_effective,
        match_report=recomputed_match,
        simulation_report=recomputed_simulation,
        at=evaluated_at.isoformat(),
    )

    blockers: list[str] = []
    if not policy["authority"]["can_issue_runtime_lease"]:
        blockers.append("policy-forbids-runtime-lease")
    if not policy["authority"]["can_create_pr"]:
        blockers.append("policy-forbids-pr-creation")
    effective_level = recomputed_effective.get("effective_level")
    if (
        effective_level is None
        or LEVELS.index(effective_level)
        < LEVELS.index(policy["supervised_pr"]["required_effective_level"])
    ):
        blockers.append("effective-autonomy-below-required-level")
    blockers.extend(recomputed_effective.get("blockers", []))
    if recomputed_match.get("matched") is not True:
        blockers.extend(recomputed_match.get("blockers", []))
    if recomputed_simulation.get("status") != "passed":
        blockers.extend(recomputed_simulation.get("blockers", []))
    if certification["status"] != "active":
        blockers.append("certification-not-active")
    if recomputed_replay["derived_status"] != "active":
        blockers.append("certification-lifecycle-not-active")
    if (
        recomputed_replay["incident_budget_exhausted"]
        or recomputed_replay["suspension_required"]
    ):
        blockers.append("certification-lifecycle-requires-suspension")
    if evaluated_at >= _parse_datetime(
        reverified_consumption["valid_until"],
        "Qualification valid_until",
    ):
        blockers.append("invalid-qualification")
    if evaluated_at >= _parse_datetime(
        certification["valid_until"], "Certification valid_until"
    ):
        blockers.append("expired")
    if blockers:
        raise ProtocolError(
            "Supervised PR authority lease denied: "
            + ", ".join(sorted(set(blockers)))
        )

    maximum_expiry = min(
        evaluated_at
        + timedelta(minutes=policy["supervised_pr"]["lease_ttl_minutes"]),
        _parse_datetime(certification["valid_until"], "Certification valid_until"),
        _parse_datetime(
            reverified_consumption["valid_until"],
            "Qualification valid_until",
        ),
    )
    lease = {
        "version": PROTOCOL_VERSION,
        "lease_id": (
            f"lease-{recomputed_match['work_item_id']}-"
            f"{certification['certification_id']}"
        ),
        "project_id": recomputed_match["project_id"],
        "work_item_id": recomputed_match["work_item_id"],
        "work_item_sha256": recomputed_match["work_item_sha256"],
        "autonomy_class_id": recomputed_match["autonomy_class_id"],
        "certification_id": certification["certification_id"],
        "authority_evidence_sha256": authority_evidence["content_sha256"],
        "certification_sha256": certification["content_sha256"],
        "certification_replay_sha256": recomputed_replay["content_sha256"],
        "qualification_consumption_sha256": reverified_consumption[
            "content_sha256"
        ],
        "effective_autonomy_sha256": recomputed_effective["content_sha256"],
        "match_report_sha256": recomputed_match["content_sha256"],
        "simulation_report_sha256": recomputed_simulation["content_sha256"],
        "issued_at": evaluated_at.isoformat(),
        "expires_at": maximum_expiry.isoformat(),
        "permitted_actions": [
            "isolated-workspace:create",
            "bounded-change:apply",
            "test-ladder:run",
            "evidence-packet:create",
            "pull-request:create",
        ],
        "forbidden_actions": [
            "merge",
            "deploy",
            "maturity-mutation",
            "automatic-renewal",
        ],
        "can_create_pr": True,
        "can_merge": False,
        "can_deploy": False,
        "can_mutate_maturity": False,
        "can_auto_renew": False,
    }
    return _finalize(lease)


def validate_supervised_pr_lease(lease: dict[str, Any]) -> dict[str, Any]:
    _require_fields(
        lease,
        {
            "version",
            "lease_id",
            "project_id",
            "work_item_id",
            "work_item_sha256",
            "autonomy_class_id",
            "certification_id",
            "authority_evidence_sha256",
            "certification_sha256",
            "certification_replay_sha256",
            "qualification_consumption_sha256",
            "effective_autonomy_sha256",
            "match_report_sha256",
            "simulation_report_sha256",
            "issued_at",
            "expires_at",
            "permitted_actions",
            "forbidden_actions",
            "can_create_pr",
            "can_merge",
            "can_deploy",
            "can_mutate_maturity",
            "can_auto_renew",
            "content_sha256",
        },
        "Supervised PR authority lease",
    )
    if lease["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Supervised PR authority-lease version must be '{PROTOCOL_VERSION}'."
        )
    for field in [
        "lease_id",
        "project_id",
        "work_item_id",
        "autonomy_class_id",
        "certification_id",
    ]:
        _require_string(lease[field], f"Supervised PR lease {field}")
    for field in [
        "work_item_sha256",
        "authority_evidence_sha256",
        "certification_sha256",
        "certification_replay_sha256",
        "qualification_consumption_sha256",
        "effective_autonomy_sha256",
        "match_report_sha256",
        "simulation_report_sha256",
    ]:
        _require_sha256(lease[field], f"Supervised PR lease {field}")
    issued_at = _parse_datetime(lease["issued_at"], "Supervised PR lease issued_at")
    expires_at = _parse_datetime(lease["expires_at"], "Supervised PR lease expires_at")
    if expires_at <= issued_at:
        raise ProtocolError("Supervised PR lease must expire after it is issued.")
    if lease["permitted_actions"] != [
        "isolated-workspace:create",
        "bounded-change:apply",
        "test-ladder:run",
        "evidence-packet:create",
        "pull-request:create",
    ]:
        raise ProtocolError("Supervised PR lease permitted actions are invalid.")
    if lease["forbidden_actions"] != [
        "merge",
        "deploy",
        "maturity-mutation",
        "automatic-renewal",
    ]:
        raise ProtocolError("Supervised PR lease forbidden actions are invalid.")
    if (
        lease["can_create_pr"] is not True
        or lease["can_merge"] is not False
        or lease["can_deploy"] is not False
        or lease["can_mutate_maturity"] is not False
        or lease["can_auto_renew"] is not False
    ):
        raise ProtocolError("Supervised PR lease authority flags are invalid.")
    _verify_digest(lease, f"Supervised PR lease '{lease['lease_id']}'")
    return lease


def validate_hosted_git_evidence(
    evidence: dict[str, Any],
    *,
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    _require_fields(
        evidence,
        {
            "version",
            "evidence_id",
            "project_id",
            "provider",
            "repository",
            "pull_request_url_prefix",
            "git_object_format",
            "base_branch",
            "head_branch",
            "base_revision",
            "head_revision",
            "diff_sha256",
            "workspace",
            "changed_paths",
            "changes",
            "test_results",
            "executor_id",
            "evaluator_id",
            "independent_evaluation",
            "controls",
            "producer_identity",
            "source_uri",
            "issued_at",
            "expires_at",
            "attestation",
            "content_sha256",
        },
        "Hosted Git evidence",
    )
    if evidence["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Hosted Git evidence version must be '{PROTOCOL_VERSION}'."
        )
    evidence_id = _require_string(
        evidence["evidence_id"], "Hosted Git evidence id"
    )
    for field in [
        "project_id",
        "provider",
        "repository",
        "pull_request_url_prefix",
        "base_branch",
        "head_branch",
        "workspace",
        "executor_id",
        "evaluator_id",
        "producer_identity",
        "source_uri",
    ]:
        _require_string(evidence[field], f"Hosted Git evidence {field}")
    _require_pr_url_prefix(
        evidence["pull_request_url_prefix"],
        evidence["repository"],
        "Hosted Git pull_request_url_prefix",
    )
    object_format = evidence["git_object_format"]
    _require_git_oid(
        evidence["base_revision"],
        object_format,
        "Hosted Git base_revision",
    )
    _require_git_oid(
        evidence["head_revision"],
        object_format,
        "Hosted Git head_revision",
    )
    if evidence["base_revision"] == evidence["head_revision"]:
        raise ProtocolError("Hosted Git evidence must contain a new head revision.")
    if evidence["base_branch"] == evidence["head_branch"]:
        raise ProtocolError("Hosted Git evidence requires separate base and head branches.")
    _require_sha256(evidence["diff_sha256"], "Hosted Git diff_sha256")
    changed_paths = _require_string_list(
        evidence["changed_paths"], "Hosted Git changed_paths"
    )
    for path in changed_paths:
        _normalize_path(path, "Hosted Git changed path")
    changes = evidence["changes"]
    if not isinstance(changes, list) or not changes:
        raise ProtocolError("Hosted Git evidence requires exact changed-file records.")
    evidence_paths: list[str] = []
    for index, change in enumerate(changes):
        _require_fields(
            change,
            {"path", "operation", "before_sha256", "after_sha256"},
            f"Hosted Git evidence change {index}",
        )
        path = _normalize_path(
            change["path"], f"Hosted Git evidence change {index} path"
        )
        evidence_paths.append(path)
        if change["operation"] not in {"add", "modify", "delete"}:
            raise ProtocolError(
                f"Hosted Git evidence change '{path}' operation is invalid."
            )
        before = _require_sha256(
            change["before_sha256"],
            f"Hosted Git evidence change '{path}' before_sha256",
            allow_none=True,
        )
        after = _require_sha256(
            change["after_sha256"],
            f"Hosted Git evidence change '{path}' after_sha256",
            allow_none=True,
        )
        if change["operation"] == "add" and (before is not None or after is None):
            raise ProtocolError(
                f"Hosted Git added path '{path}' has invalid content digests."
            )
        if change["operation"] == "delete" and (before is None or after is not None):
            raise ProtocolError(
                f"Hosted Git deleted path '{path}' has invalid content digests."
            )
        if change["operation"] == "modify" and (before is None or after is None):
            raise ProtocolError(
                f"Hosted Git modified path '{path}' requires both content digests."
            )
        if before is not None and before == after:
            raise ProtocolError(
                f"Hosted Git evidence change '{path}' has no content change."
            )
    if len(evidence_paths) != len(set(evidence_paths)):
        raise ProtocolError("Hosted Git evidence changes repeat a path.")
    if sorted(evidence_paths) != sorted(changed_paths):
        raise ProtocolError(
            "Hosted Git changed_paths must match its exact change records."
        )
    results = evidence["test_results"]
    if (
        not isinstance(results, list)
        or [item.get("level") for item in results] != TEST_LEVELS
    ):
        raise ProtocolError(
            f"Hosted Git test ladder must be ordered: {TEST_LEVELS}"
        )
    for result in results:
        _require_fields(
            result,
            {"level", "status", "command", "evidence_sha256"},
            f"Hosted Git {result.get('level')} result",
        )
        if result["status"] != "passed":
            raise ProtocolError(
                f"Hosted Git test level {result['level']} did not pass."
            )
        _require_string_list(
            result["command"], f"Hosted Git {result['level']} command"
        )
        _require_sha256(
            result["evidence_sha256"],
            f"Hosted Git {result['level']} evidence_sha256",
        )
    if evidence["executor_id"] == evidence["evaluator_id"]:
        raise ProtocolError("Hosted Git executor and evaluator must be independent.")
    evaluation = _require_fields(
        evidence["independent_evaluation"],
        {"status", "report_sha256"},
        "Hosted Git independent evaluation",
    )
    if evaluation["status"] != "passed":
        raise ProtocolError("Hosted Git independent evaluation must pass.")
    _require_sha256(
        evaluation["report_sha256"],
        "Hosted Git evaluation report_sha256",
    )
    controls = _require_fields(
        evidence["controls"],
        set(policy["supervised_pr"]["provider_evidence_required_controls"]),
        "Hosted Git evidence controls",
    )
    if any(status != "verified" for status in controls.values()):
        raise ProtocolError("Every required hosted Git control must be verified.")
    issued_at = _parse_datetime(
        evidence["issued_at"], "Hosted Git evidence issued_at"
    )
    expires_at = _parse_datetime(
        evidence["expires_at"], "Hosted Git evidence expires_at"
    )
    evaluated_at = _parse_datetime(at, "Hosted Git evidence evaluation time")
    if issued_at > evaluated_at:
        raise ProtocolError("Hosted Git evidence cannot be future-dated.")
    if expires_at <= issued_at or evaluated_at >= expires_at:
        raise ProtocolError("Hosted Git evidence is expired or has an invalid window.")
    if evaluated_at - issued_at > timedelta(
        minutes=policy["supervised_pr"]["provider_evidence_maximum_age_minutes"]
    ):
        raise ProtocolError("Hosted Git evidence is stale.")
    _verify_digest(evidence, f"Hosted Git evidence '{evidence_id}'")
    statement = {
        key: value
        for key, value in evidence.items()
        if key not in {"attestation", "content_sha256"}
    }
    verify_trusted_statement(
        evidence["attestation"],
        statement=statement,
        qualification_policy=qualification_policy,
        provider=evidence["provider"],
        source_uri=evidence["source_uri"],
        producer_identity=evidence["producer_identity"],
        required_roles=policy["supervised_pr"][
            "provider_evidence_required_signer_roles"
        ],
        at=evaluated_at.isoformat(),
        label=f"Hosted Git evidence '{evidence_id}'",
    )
    return evidence


def validate_supervised_pr_execution(
    execution: dict[str, Any],
    *,
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    _require_fields(
        execution,
        {
            "version",
            "execution_id",
            "project_id",
            "work_item_id",
            "lease_sha256",
            "workspace",
            "git_object_format",
            "base_revision",
            "head_revision",
            "base_branch",
            "head_branch",
            "changed_paths",
            "changes",
            "diff_sha256",
            "test_results",
            "executor_id",
            "evaluator_id",
            "independent_evaluation",
            "hosted_git_evidence",
            "evidence",
            "content_sha256",
        },
        "Supervised PR execution",
    )
    if execution["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Supervised PR execution version must be '{PROTOCOL_VERSION}'."
        )
    execution_id = _require_string(
        execution["execution_id"], "Supervised PR execution id"
    )
    for field in [
        "project_id",
        "work_item_id",
        "workspace",
        "base_branch",
        "head_branch",
    ]:
        _require_string(execution[field], f"Supervised PR execution {field}")
    _require_sha256(execution["lease_sha256"], "Supervised PR lease_sha256")
    object_format = execution["git_object_format"]
    _require_git_oid(
        execution["base_revision"],
        object_format,
        "Supervised PR base_revision",
    )
    _require_git_oid(
        execution["head_revision"],
        object_format,
        "Supervised PR head_revision",
    )
    if execution["base_revision"] == execution["head_revision"]:
        raise ProtocolError("Supervised PR execution must contain a new revision.")
    if execution["base_branch"] == execution["head_branch"]:
        raise ProtocolError(
            "Supervised PR execution requires separate base and head branches."
        )
    changed_paths = _require_string_list(
        execution["changed_paths"], "Supervised PR changed_paths"
    )
    for path in changed_paths:
        _normalize_path(path, "Supervised PR changed path")
    changes = execution["changes"]
    if not isinstance(changes, list) or not changes:
        raise ProtocolError("Supervised PR execution requires exact changed-file records.")
    execution_paths: list[str] = []
    for index, change in enumerate(changes):
        _require_fields(
            change,
            {
                "path",
                "operation",
                "before_sha256",
                "after_sha256",
            },
            f"Supervised PR execution change {index}",
        )
        path = _normalize_path(
            change["path"], f"Supervised PR execution change {index} path"
        )
        execution_paths.append(path)
        if change["operation"] not in {"add", "modify", "delete"}:
            raise ProtocolError(
                f"Supervised PR execution change '{path}' operation is invalid."
            )
        before = _require_sha256(
            change["before_sha256"],
            f"Supervised PR execution change '{path}' before_sha256",
            allow_none=True,
        )
        after = _require_sha256(
            change["after_sha256"],
            f"Supervised PR execution change '{path}' after_sha256",
            allow_none=True,
        )
        if change["operation"] == "add" and (before is not None or after is None):
            raise ProtocolError(
                f"Supervised PR added path '{path}' has invalid content digests."
            )
        if change["operation"] == "delete" and (before is None or after is not None):
            raise ProtocolError(
                f"Supervised PR deleted path '{path}' has invalid content digests."
            )
        if change["operation"] == "modify" and (before is None or after is None):
            raise ProtocolError(
                f"Supervised PR modified path '{path}' requires both content digests."
            )
        if before is not None and before == after:
            raise ProtocolError(
                f"Supervised PR execution change '{path}' has no content change."
            )
    if len(execution_paths) != len(set(execution_paths)):
        raise ProtocolError("Supervised PR execution changes repeat a path.")
    if sorted(execution_paths) != sorted(changed_paths):
        raise ProtocolError(
            "Supervised PR changed_paths must match the exact execution changes."
        )
    _require_sha256(execution["diff_sha256"], "Supervised PR diff_sha256")
    results = execution["test_results"]
    if (
        not isinstance(results, list)
        or [item.get("level") for item in results] != TEST_LEVELS
    ):
        raise ProtocolError(
            f"Supervised PR test ladder must be ordered: {TEST_LEVELS}"
        )
    for result in results:
        _require_fields(
            result,
            {"level", "status", "command", "evidence_sha256"},
            f"Supervised PR {result.get('level')} result",
        )
        if result["status"] != "passed":
            raise ProtocolError(
                f"Supervised PR test level {result['level']} did not pass."
            )
        _require_string_list(
            result["command"],
            f"Supervised PR {result['level']} command",
        )
        _require_sha256(
            result["evidence_sha256"],
            f"Supervised PR {result['level']} evidence_sha256",
        )
    executor_id = _require_string(
        execution["executor_id"], "Supervised PR executor_id"
    )
    evaluator_id = _require_string(
        execution["evaluator_id"], "Supervised PR evaluator_id"
    )
    if executor_id == evaluator_id:
        raise ProtocolError("Supervised PR executor and evaluator must be independent.")
    evaluation = _require_fields(
        execution["independent_evaluation"],
        {"status", "report_sha256"},
        "Supervised PR independent evaluation",
    )
    if evaluation["status"] != "passed":
        raise ProtocolError("Supervised PR independent evaluation must pass.")
    _require_sha256(
        evaluation["report_sha256"],
        "Supervised PR evaluation report_sha256",
    )
    hosted_git_evidence = validate_hosted_git_evidence(
        execution["hosted_git_evidence"],
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    for field in [
        "project_id",
        "git_object_format",
        "base_branch",
        "head_branch",
        "base_revision",
        "head_revision",
        "diff_sha256",
        "workspace",
        "changed_paths",
        "changes",
        "test_results",
        "executor_id",
        "evaluator_id",
        "independent_evaluation",
    ]:
        if execution[field] != hosted_git_evidence[field]:
            raise ProtocolError(
                f"Supervised PR execution {field} does not match trusted provider evidence."
            )
    _require_string_list(execution["evidence"], "Supervised PR evidence")
    _verify_digest(execution, f"Supervised PR execution '{execution_id}'")
    return execution


def create_supervised_pr_packet(
    policy: dict[str, Any],
    *,
    work_item: dict[str, Any],
    authority_lease: dict[str, Any],
    authority_evidence: dict[str, Any],
    execution: dict[str, Any],
    qualification_policy: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    maturity_model: dict[str, Any],
    title: str,
    body: str,
    at: str,
) -> dict[str, Any]:
    validate_autonomy_work_item(work_item)
    validate_supervised_pr_lease(authority_lease)
    _validate_autonomy_authority_evidence_envelope(
        authority_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        registry=registry,
        change_classes=change_classes,
        maturity_model=maturity_model,
        at=at,
    )
    validate_supervised_pr_execution(
        execution,
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    _require_string(title, "Supervised PR title")
    _require_string(body, "Supervised PR body")
    blockers: list[str] = []
    evaluated_at = _parse_datetime(at, "Supervised PR packet creation time")
    lease_issued_at = _parse_datetime(
        authority_lease["issued_at"], "Supervised PR lease issued_at"
    )
    lease_expires_at = _parse_datetime(
        authority_lease["expires_at"], "Supervised PR lease expires_at"
    )
    authority_expires_at = _parse_datetime(
        authority_evidence["expires_at"], "Autonomy authority evidence expires_at"
    )
    if evaluated_at < lease_issued_at or evaluated_at >= lease_expires_at:
        blockers.append("lease-not-active")
    if lease_expires_at > authority_expires_at:
        blockers.append("lease-exceeds-authority-evidence")
    if lease_expires_at - lease_issued_at > timedelta(
        minutes=policy["supervised_pr"]["lease_ttl_minutes"]
    ):
        blockers.append("lease-exceeds-policy-ttl")
    if execution["lease_sha256"] != authority_lease["content_sha256"]:
        blockers.append("lease-binding-mismatch")
    if (
        authority_lease["authority_evidence_sha256"]
        != authority_evidence["content_sha256"]
    ):
        blockers.append("authority-evidence-binding-mismatch")
    if execution["project_id"] != authority_lease["project_id"]:
        blockers.append("project-mismatch")
    if execution["work_item_id"] != work_item["work_item_id"]:
        blockers.append("work-item-mismatch")
    if authority_lease["work_item_sha256"] != work_item["content_sha256"]:
        blockers.append("work-item-digest-mismatch")
    authority_bindings = {
        "project_id": authority_lease["project_id"],
        "autonomy_class_id": authority_lease["autonomy_class_id"],
        "certification_id": authority_lease["certification_id"],
        "work_item_sha256": authority_lease["work_item_sha256"],
        "certification_sha256": authority_lease["certification_sha256"],
        "certification_replay_sha256": authority_lease[
            "certification_replay_sha256"
        ],
        "qualification_consumption_sha256": authority_lease[
            "qualification_consumption_sha256"
        ],
        "effective_autonomy_sha256": authority_lease[
            "effective_autonomy_sha256"
        ],
        "match_report_sha256": authority_lease["match_report_sha256"],
        "simulation_report_sha256": authority_lease[
            "simulation_report_sha256"
        ],
    }
    for field, expected in authority_bindings.items():
        if authority_evidence[field] != expected:
            blockers.append(f"authority-evidence-{field}-mismatch")
    declared_paths = sorted(change["path"] for change in work_item["changes"])
    if sorted(execution["changed_paths"]) != declared_paths:
        blockers.append("actual-diff-does-not-match-work-item")
    declared_changes = sorted(
        (
            {
                "path": change["path"],
                "operation": change["operation"],
                "before_sha256": change["before_sha256"],
                "after_sha256": change["after_sha256"],
            }
            for change in work_item["changes"]
        ),
        key=lambda change: change["path"],
    )
    if sorted(execution["changes"], key=lambda change: change["path"]) != declared_changes:
        blockers.append("actual-content-does-not-match-work-item")
    if not policy["supervised_pr"]["require_human_merge"]:
        blockers.append("human-merge-policy-missing")
    if not policy["supervised_pr"]["require_human_release"]:
        blockers.append("human-release-policy-missing")
    if blockers:
        raise ProtocolError(
            "Supervised PR packet denied: " + ", ".join(sorted(set(blockers)))
        )
    packet = {
        "version": PROTOCOL_VERSION,
        "packet_id": f"pr-packet-{execution['execution_id']}",
        "project_id": execution["project_id"],
        "work_item_id": work_item["work_item_id"],
        "autonomy_class_id": authority_lease["autonomy_class_id"],
        "certification_id": authority_lease["certification_id"],
        "authority_lease_sha256": authority_lease["content_sha256"],
        "authority_evidence_sha256": authority_evidence["content_sha256"],
        "execution_sha256": execution["content_sha256"],
        "hosted_git_evidence_sha256": execution["hosted_git_evidence"][
            "content_sha256"
        ],
        "title": title,
        "body": body,
        "provider": execution["hosted_git_evidence"]["provider"],
        "repository": execution["hosted_git_evidence"]["repository"],
        "pull_request_url_prefix": execution["hosted_git_evidence"][
            "pull_request_url_prefix"
        ],
        "git_object_format": execution["git_object_format"],
        "base_branch": execution["base_branch"],
        "head_branch": execution["head_branch"],
        "base_revision": execution["base_revision"],
        "head_revision": execution["head_revision"],
        "diff_sha256": execution["diff_sha256"],
        "evidence": list(execution["evidence"]),
        "status": "ready",
        "can_create_pr": True,
        "requires_human_merge": True,
        "requires_human_release": True,
        "can_merge": False,
        "can_deploy": False,
        "can_mutate_maturity": False,
    }
    return _finalize(packet)


def validate_supervised_pr_packet(packet: dict[str, Any]) -> dict[str, Any]:
    _require_fields(
        packet,
        {
            "version",
            "packet_id",
            "project_id",
            "work_item_id",
            "autonomy_class_id",
            "certification_id",
            "authority_lease_sha256",
            "authority_evidence_sha256",
            "execution_sha256",
            "hosted_git_evidence_sha256",
            "title",
            "body",
            "provider",
            "repository",
            "pull_request_url_prefix",
            "git_object_format",
            "base_branch",
            "head_branch",
            "base_revision",
            "head_revision",
            "diff_sha256",
            "evidence",
            "status",
            "can_create_pr",
            "requires_human_merge",
            "requires_human_release",
            "can_merge",
            "can_deploy",
            "can_mutate_maturity",
            "content_sha256",
        },
        "Supervised PR packet",
    )
    if packet["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Supervised PR packet version must be '{PROTOCOL_VERSION}'."
        )
    for field in [
        "packet_id",
        "project_id",
        "work_item_id",
        "autonomy_class_id",
        "certification_id",
        "title",
        "body",
        "provider",
        "repository",
        "pull_request_url_prefix",
        "base_branch",
        "head_branch",
    ]:
        _require_string(packet[field], f"Supervised PR packet {field}")
    _require_pr_url_prefix(
        packet["pull_request_url_prefix"],
        packet["repository"],
        "Supervised PR packet pull_request_url_prefix",
    )
    for field in [
        "authority_lease_sha256",
        "authority_evidence_sha256",
        "execution_sha256",
        "hosted_git_evidence_sha256",
        "diff_sha256",
    ]:
        _require_sha256(packet[field], f"Supervised PR packet {field}")
    object_format = packet["git_object_format"]
    _require_git_oid(
        packet["base_revision"],
        object_format,
        "Supervised PR packet base_revision",
    )
    _require_git_oid(
        packet["head_revision"],
        object_format,
        "Supervised PR packet head_revision",
    )
    if packet["base_branch"] == packet["head_branch"]:
        raise ProtocolError(
            "Supervised PR packet requires separate base and head branches."
        )
    _require_string_list(packet["evidence"], "Supervised PR packet evidence")
    if (
        packet["status"] != "ready"
        or packet["can_create_pr"] is not True
        or packet["requires_human_merge"] is not True
        or packet["requires_human_release"] is not True
        or packet["can_merge"] is not False
        or packet["can_deploy"] is not False
        or packet["can_mutate_maturity"] is not False
    ):
        raise ProtocolError("Supervised PR packet authority flags are invalid.")
    _verify_digest(packet, f"Supervised PR packet '{packet['packet_id']}'")
    return packet


def submit_supervised_pr(
    packet: dict[str, Any],
    submitter: PullRequestSubmitter,
    *,
    policy: dict[str, Any],
    work_item: dict[str, Any],
    authority_lease: dict[str, Any],
    execution: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    project_autonomy_ceiling: str,
    certification: dict[str, Any],
    certification_events: list[dict[str, Any]],
    certification_replay_report: dict[str, Any],
    qualification_consumption: dict[str, Any],
    incident_budget: dict[str, Any],
    suspensions: list[dict[str, Any]],
    revocations: list[dict[str, Any]],
    qualification_manifest_path: Path,
    qualification_policy: dict[str, Any],
    maturity_model: dict[str, Any],
    lease_qualification_state_checks: dict[str, dict[str, Any]],
    current_qualification_state_checks: dict[str, dict[str, Any]],
    artifact_sha256: str,
    effective_autonomy_report: dict[str, Any],
    match_report: dict[str, Any],
    simulation_report: dict[str, Any],
    authority_evidence: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    validate_supervised_pr_packet(packet)
    validate_autonomy_work_item(work_item)
    validate_supervised_pr_lease(authority_lease)
    evaluated_at = _parse_datetime(at, "Supervised PR submission time")
    issued_at = _parse_datetime(
        authority_lease["issued_at"], "Supervised PR lease issued_at"
    )
    expires_at = _parse_datetime(
        authority_lease["expires_at"], "Supervised PR lease expires_at"
    )
    if evaluated_at < issued_at or evaluated_at >= expires_at:
        raise ProtocolError("Supervised PR authority lease is not active.")
    validate_supervised_pr_execution(
        execution,
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    expected_lease = issue_supervised_pr_lease(
        policy,
        work_item=work_item,
        registry=registry,
        change_classes=change_classes,
        project_autonomy_ceiling=project_autonomy_ceiling,
        certification=certification,
        certification_events=certification_events,
        certification_replay_report=certification_replay_report,
        qualification_consumption=qualification_consumption,
        incident_budget=incident_budget,
        suspensions=suspensions,
        revocations=revocations,
        qualification_manifest_path=qualification_manifest_path,
        qualification_policy=qualification_policy,
        maturity_model=maturity_model,
        qualification_state_checks=lease_qualification_state_checks,
        artifact_sha256=artifact_sha256,
        effective_autonomy_report=effective_autonomy_report,
        match_report=match_report,
        simulation_report=simulation_report,
        authority_evidence=authority_evidence,
        at=issued_at.isoformat(),
    )
    if authority_lease != expected_lease:
        raise ProtocolError(
            "Supervised PR authority lease does not match trusted-source recomputation."
        )
    reverify_qualification_consumption(
        qualification_consumption,
        manifest_path=qualification_manifest_path,
        qualification_policy=qualification_policy,
        maturity_model=maturity_model,
        autonomy_policy=policy,
        state_checks=current_qualification_state_checks,
        at=evaluated_at.isoformat(),
    )
    expected_packet = create_supervised_pr_packet(
        policy,
        work_item=work_item,
        authority_lease=authority_lease,
        authority_evidence=authority_evidence,
        execution=execution,
        qualification_policy=qualification_policy,
        registry=registry,
        change_classes=change_classes,
        maturity_model=maturity_model,
        title=packet["title"],
        body=packet["body"],
        at=evaluated_at.isoformat(),
    )
    if packet != expected_packet:
        raise ProtocolError(
            "Supervised PR packet does not match its lease, execution, and work item."
        )
    response = submitter.submit(copy.deepcopy(packet))
    _require_fields(
        response,
        {
            "authorized_packet_sha256",
            "provider",
            "repository",
            "git_object_format",
            "base_branch",
            "head_branch",
            "base_revision",
            "head_revision",
            "diff_sha256",
            "pull_request_id",
            "url",
            "status",
        },
        "Pull request submission response",
    )
    _require_sha256(
        response["authorized_packet_sha256"],
        "Pull request response authorized_packet_sha256",
    )
    for field in [
        "provider",
        "repository",
        "base_branch",
        "head_branch",
        "pull_request_id",
        "url",
    ]:
        _require_string(response[field], f"Pull request response {field}")
    response_uri = urlparse(response["url"])
    if (
        response_uri.scheme != "https"
        or not response_uri.hostname
        or response_uri.username is not None
        or response_uri.password is not None
        or response_uri.query
        or response_uri.fragment
    ):
        raise ProtocolError(
            "Pull request response url must be a credential-free HTTPS URI "
            "without a query or fragment."
        )
    object_format = response["git_object_format"]
    _require_git_oid(
        response["base_revision"],
        object_format,
        "Pull request response base_revision",
    )
    _require_git_oid(
        response["head_revision"],
        object_format,
        "Pull request response head_revision",
    )
    _require_sha256(response["diff_sha256"], "Pull request response diff_sha256")
    if response["status"] != "open":
        raise ProtocolError("Pull request provider did not return an open PR.")
    pull_request_id = response["pull_request_id"]
    if any(
        character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
        for character in pull_request_id
    ):
        raise ProtocolError(
            "Pull request response pull_request_id must be URL-safe."
        )
    prefix_uri = urlparse(packet["pull_request_url_prefix"])
    if (
        response_uri.scheme != prefix_uri.scheme
        or response_uri.netloc != prefix_uri.netloc
        or unquote(response_uri.path)
        != unquote(prefix_uri.path) + pull_request_id
    ):
        raise ProtocolError(
            "Pull request response url does not match the authorized repository URL."
        )
    if response["authorized_packet_sha256"] != packet["content_sha256"]:
        raise ProtocolError(
            "Pull request response does not match the authorized packet digest."
        )
    for field in [
        "provider",
        "repository",
        "git_object_format",
        "base_branch",
        "head_branch",
        "base_revision",
        "head_revision",
        "diff_sha256",
    ]:
        if response[field] != packet[field]:
            raise ProtocolError(
                f"Pull request response {field} does not match authorized packet."
            )
    return copy.deepcopy(response)


def canonical_p5_2_readiness(
    policy: dict[str, Any],
    *,
    qualification_policy: dict[str, Any],
    factory_status: dict[str, Any],
    active_authority_source_present: bool,
    active_certification_present: bool,
    valid_l2_consumption_present: bool,
) -> dict[str, Any]:
    blockers: list[str] = []
    if not active_authority_source_present:
        blockers.append("no-active-canonical-authority-source")
    if not qualification_policy.get("trust", {}).get("anchors"):
        blockers.append("no-external-trust-anchors")
    if not valid_l2_consumption_present:
        blockers.append("no-valid-l2-qualification-consumption")
    if not active_certification_present:
        blockers.append("no-active-autonomy-certification")
    if not factory_status.get("has_remote"):
        blockers.append("no-hosted-git-remote")
    if factory_status.get("branch_protection") != "verified":
        blockers.append("branch-protection-not-verified")
    if factory_status.get("external_identity") != "verified":
        blockers.append("external-identity-not-verified")
    if not policy["authority"]["can_create_pr"]:
        blockers.append("policy-forbids-pr-creation")
    report = {
        "version": PROTOCOL_VERSION,
        "phase": "P5.2",
        "capability": "supervised-autonomous-pr",
        "ready": not blockers,
        "blockers": sorted(blockers),
        "required_level": policy["supervised_pr"]["required_effective_level"],
        "can_create_pr": not blockers,
        "can_merge": False,
        "can_deploy": False,
        "can_mutate_maturity": False,
    }
    return _finalize(report)
