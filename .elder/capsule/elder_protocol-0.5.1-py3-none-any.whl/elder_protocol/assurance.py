from __future__ import annotations

from collections import Counter
from typing import Any


def build_assurance_report(
    data: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    recommendations = data["recommendation-ledger"]["recommendations"]
    controls = [
        control
        for recommendation in recommendations
        for control in recommendation["controls"]
    ]
    maturity = data["operational-maturity"]["current_assessment"]
    known_gaps = [
        {
            "recommendation": recommendation["id"],
            "gap": gap,
        }
        for recommendation in recommendations
        for gap in recommendation["known_gaps"]
    ]
    required_packs = [
        {
            "id": pack["id"],
            "contract_status": pack["contract_status"],
            "runtime_status": pack["runtime_status"],
        }
        for pack in data["capability-packs"]["packs"]
        if pack["required"]
    ]
    return {
        "current_level": maturity["level"],
        "assessment_scope": maturity["scope"],
        "general_factory_operational": maturity["level"] in {"L3", "L4", "L5"},
        "recommendation_count": len(recommendations),
        "recommendations_by_status": dict(
            sorted(Counter(item["operational_status"] for item in recommendations).items())
        ),
        "control_count": len(controls),
        "controls_by_kind": dict(
            sorted(Counter(control["kind"] for control in controls).items())
        ),
        "required_packs": required_packs,
        "p4_1": {
            "design_registry_operational": bool(
                data["design-registry"]["documents"]
            ),
            "design_document_count": len(
                data["design-registry"]["documents"]
            ),
            "architecture_boundary_adapters": data[
                "architecture-boundary.schema"
            ]["properties"]["adapter"]["enum"],
            "transcript_evaluator": "deterministic-advisory",
            "transcript_policy": data["transcript-review-policy"]["id"],
        },
        "p4_2": {
            "evaluation_dataset_count": len(
                data["evaluation-registry"]["datasets"]
            ),
            "active_evaluation_datasets": sum(
                entry["status"] == "active"
                for entry in data["evaluation-registry"]["datasets"]
            ),
            "evaluation_case_count": len(data["evaluation-dataset"]["cases"]),
            "evaluation_splits": sorted(data["evaluation-dataset"]["splits"]),
            "allowed_graders": data["evaluator-contract"]["allowed_graders"],
            "calibration_thresholds": data["evaluator-contract"]["calibration"],
            "comparison_policy": data["evaluator-contract"]["comparison"],
            "authority": data["evaluator-contract"]["authority"]["mode"],
        },
        "p4_3": {
            "telemetry_contract": data["telemetry-contract"]["id"],
            "scopes": data["telemetry-contract"]["scopes"],
            "trace_context": data["telemetry-contract"]["semantic_conventions"][
                "trace_context"
            ],
            "genai_convention": data["telemetry-contract"][
                "semantic_conventions"
            ]["genai"],
            "metric_cardinality_limit": data["telemetry-contract"][
                "metric_policy"
            ]["maximum_cardinality_per_metric"],
            "authority": data["telemetry-contract"]["authority"]["mode"],
        },
        "p4_4": {
            "context_policy": data["context-policy"]["id"],
            "memory_policy": data["memory-policy"]["id"],
            "allowed_context_authorities": data["context-policy"][
                "allowed_authorities"
            ],
            "default_memory_statuses": data["memory-policy"]["retrieval"][
                "default_statuses"
            ],
            "trusted_memory_promoters": data["memory-policy"][
                "trusted_promoters"
            ],
            "context_budget": data["context-policy"]["budgets"],
            "authority": data["context-policy"]["authority"]["mode"],
        },
        "p4_5a": {
            "canonical_roles": [
                role["id"] for role in data["role-registry"]["roles"]
            ],
            "delegation_policy": data["delegation-policy"]["id"],
            "authority_ceilings": sorted(
                data["delegation-policy"]["authority_ceilings"]
            ),
            "message_effect": data["delegation-policy"]["message_effect"],
            "stack_adapters": [
                adapter["id"]
                for adapter in data["stack-adapter-registry"]["adapters"]
            ],
            "runtime_orchestration": False,
        },
        "p4_5b": {
            "runtime_policy": data["multi-agent-runtime-policy"]["id"],
            "store_adapter": data["multi-agent-runtime-policy"]["store"]["adapter"],
            "claim_mode": data["multi-agent-runtime-policy"]["dispatch"][
                "claim_mode"
            ],
            "replay_mode": data["multi-agent-runtime-policy"]["replay"]["mode"],
            "runtime_orchestration": True,
            "hosted_orchestration": False,
            "can_approve": data["multi-agent-runtime-policy"]["authority"][
                "can_approve"
            ],
            "can_promote": data["multi-agent-runtime-policy"]["authority"][
                "can_promote"
            ],
        },
        "p4_6": {
            "learning_policy": data["learning-policy"]["id"],
            "store_adapter": data["learning-policy"]["store"]["adapter"],
            "observation_modes": data["learning-policy"]["observation_modes"],
            "candidate_kinds": data["learning-policy"]["candidate_kinds"],
            "promotion_packet_only": data["learning-policy"]["authority"][
                "promotion_packet_only"
            ],
            "target_mutation": data["learning-policy"]["authority"][
                "candidate_can_mutate_target"
            ],
            "evaluator_can_approve": data["learning-policy"]["authority"][
                "evaluator_can_approve"
            ],
            "evaluator_can_promote": data["learning-policy"]["authority"][
                "evaluator_can_promote"
            ],
            "hosted_learning": False,
        },
        "p4_7": {
            "qualification_policy": data["qualification-policy"]["id"],
            "gate_count": len(data["qualification-policy"]["gates"]),
            "trust_anchor_count": len(
                data["qualification-policy"]["trust"]["anchors"]
            ),
            "signature_algorithm": data["qualification-policy"]["trust"][
                "algorithms"
            ],
            "cumulative": data["qualification-policy"]["qualification"][
                "cumulative"
            ],
            "advisory_only": data["qualification-policy"]["qualification"][
                "advisory_only"
            ],
            "can_mutate_maturity": data["qualification-policy"][
                "qualification"
            ]["can_mutate_maturity"],
            "can_promote": data["qualification-policy"]["qualification"][
                "can_promote"
            ],
            "can_deploy": data["qualification-policy"]["qualification"][
                "can_deploy"
            ],
            "hosted_qualified": False,
        },
        "p5": {
            "autonomy_policy": data["autonomy-policy"]["id"],
            "mode": data["autonomy-policy"]["mode"],
            "autonomy_class_registry": data["autonomy-classes"]["id"],
            "initial_class_count": len(data["autonomy-classes"]["classes"]),
            "initial_class_ids": [
                item["id"] for item in data["autonomy-classes"]["classes"]
            ],
            "effective_autonomy_calculation": data["autonomy-policy"][
                "effective_autonomy"
            ]["calculation"],
            "hard_stops": data["autonomy-policy"]["effective_autonomy"][
                "hard_stops"
            ],
            "qualification_consumption": data["autonomy-policy"][
                "qualification_consumption"
            ]["mode"],
            "p5_1_simulation_mode": data["autonomy-policy"]["simulation"]["mode"],
            "p5_1_deterministic_replay": data["autonomy-policy"]["simulation"][
                "deterministic_replay"
            ],
            "p5_2_required_level": data["autonomy-policy"]["supervised_pr"][
                "required_effective_level"
            ],
            "p5_2_canonical_ready": False,
            "p5_3_required_level": data["autonomy-policy"]["canary"][
                "required_effective_level"
            ],
            "p5_3_canonical_ready": False,
            "authority_activated": False,
            "can_issue_runtime_lease": False,
            "can_create_pr": False,
            "can_execute_canary": False,
            "can_issue_runtime_lease_when_qualified": data["autonomy-policy"]["authority"][
                "can_issue_runtime_lease"
            ],
            "can_create_pr_when_qualified": data["autonomy-policy"]["authority"][
                "can_create_pr"
            ],
            "can_execute_canary_when_qualified": data["autonomy-policy"]["authority"][
                "can_execute_canary"
            ],
            "can_promote_canary": data["autonomy-policy"]["authority"][
                "can_promote_canary"
            ],
            "can_merge": data["autonomy-policy"]["authority"]["can_merge"],
            "can_deploy": data["autonomy-policy"]["authority"]["can_deploy"],
            "can_mutate_maturity": data["autonomy-policy"]["authority"][
                "can_mutate_maturity"
            ],
            "can_auto_renew": data["autonomy-policy"]["authority"][
                "can_auto_renew"
            ],
        },
        "evidence": maturity["evidence"],
        "maturity_blockers": maturity["blockers"],
        "known_gaps": known_gaps,
    }
