from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from elder_protocol.constants import PORTABLE_MEMORY_ENV_PATH, PROTOCOL_VERSION, ROOT
from elder_protocol.errors import ProtocolError


CAPSULE_FORMAT_VERSION = 1
MANIFEST_PATH = ".elder/capsule/manifest.json"
RUNTIME_IGNORE_PATH = ".elder/runtime/.gitignore"


@dataclass(frozen=True)
class CapsuleReport:
    archive: Path
    sha256: str
    source_commit: str
    protocol_version: str
    files: tuple[str, ...]


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _canonical_sha256(value: dict[str, Any]) -> str:
    return _sha256_bytes(
        json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        ).encode("utf-8")
    )


def _require_commit(value: str) -> str:
    normalized = value.strip().lower()
    if len(normalized) != 40 or any(character not in "0123456789abcdef" for character in normalized):
        raise ProtocolError("Portable capsule source_commit must be a full Git SHA-1.")
    return normalized


def _safe_relative_path(value: str) -> Path:
    path = PurePosixPath(value)
    if (
        not value
        or path.is_absolute()
        or ".." in path.parts
        or "\\" in value
        or ":" in value
        or path.as_posix() != value
    ):
        raise ProtocolError(f"Portable capsule contains an unsafe path: {value}")
    return Path(*path.parts)


def _bootstrap_script(wheel_name: str) -> str:
    return f"""param([switch]$Force)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\\..")).Path
$RuntimeRoot = Join-Path $ProjectRoot ".elder\\runtime\\tooling"
$Python = Join-Path $RuntimeRoot "Scripts\\python.exe"
$Marker = Join-Path $RuntimeRoot ".elder-wheel.sha256"
$Wheel = Join-Path $PSScriptRoot "{wheel_name}"
$WheelDigest = (Get-FileHash -Algorithm SHA256 -LiteralPath $Wheel).Hash.ToLowerInvariant()
$InstalledDigest = if (Test-Path -LiteralPath $Marker) {{
    (Get-Content -LiteralPath $Marker -Raw).Trim()
}} else {{
    ""
}}

if ($Force -or -not (Test-Path -LiteralPath $Python) -or $InstalledDigest -ne $WheelDigest) {{
    $CandidateSpecs = [System.Collections.Generic.List[object]]::new()
    $ExplicitPythonRequested = -not [string]::IsNullOrWhiteSpace(
        $env:ELDER_BOOTSTRAP_PYTHON
    )
    if ($ExplicitPythonRequested) {{
        $CandidateSpecs.Add([pscustomobject]@{{
            Executable = $env:ELDER_BOOTSTRAP_PYTHON
            Arguments = @()
        }})
    }} else {{
        $PyLauncher = Get-Command py -ErrorAction SilentlyContinue
        if ($PyLauncher) {{
            $CandidateSpecs.Add([pscustomobject]@{{
                Executable = $PyLauncher.Source
                Arguments = @("-3")
            }})
        }}

        foreach ($Command in @(Get-Command python -All -ErrorAction SilentlyContinue)) {{
            $CandidateSpecs.Add([pscustomobject]@{{
                Executable = $Command.Source
                Arguments = @()
            }})
        }}
        foreach ($Command in @(Get-Command python3 -All -ErrorAction SilentlyContinue)) {{
            $CandidateSpecs.Add([pscustomobject]@{{
                Executable = $Command.Source
                Arguments = @()
            }})
        }}

        $KnownPythonRoots = @()
        if ($env:LOCALAPPDATA) {{
            $KnownPythonRoots += Join-Path $env:LOCALAPPDATA "Programs\\Python"
        }}
        if ($env:ProgramFiles) {{
            $KnownPythonRoots += $env:ProgramFiles
        }}
        if (${{env:ProgramFiles(x86)}}) {{
            $KnownPythonRoots += ${{env:ProgramFiles(x86)}}
        }}
        foreach ($Root in $KnownPythonRoots) {{
            foreach ($Candidate in @(
                Get-ChildItem -Path (Join-Path $Root "Python*\\python.exe") `
                    -File -ErrorAction SilentlyContinue
            )) {{
                $CandidateSpecs.Add([pscustomobject]@{{
                    Executable = $Candidate.FullName
                    Arguments = @()
                }})
            }}
        }}
    }}

    $BasePython = $null
    $BasePythonArgs = @()
    $SeenCandidates = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    foreach ($Candidate in $CandidateSpecs) {{
        $CandidateKey = "$($Candidate.Executable)|$($Candidate.Arguments -join ' ')"
        if (-not $SeenCandidates.Add($CandidateKey)) {{
            continue
        }}
        if (-not (Test-Path -LiteralPath $Candidate.Executable -PathType Leaf)) {{
            continue
        }}
        try {{
            $ProbeOutput = & $Candidate.Executable @($Candidate.Arguments) `
                -c "import sys, venv; sys.exit(0 if sys.version_info >= (3, 11) else 3)" `
                2>$null
            $ProbeExitCode = $LASTEXITCODE
        }} catch {{
            continue
        }}
        if ($ProbeExitCode -eq 0) {{
            $BasePython = $Candidate.Executable
            $BasePythonArgs = @($Candidate.Arguments)
            break
        }}
    }}
    if (-not $BasePython) {{
        if ($ExplicitPythonRequested) {{
            throw (
                "ELDER_BOOTSTRAP_PYTHON does not identify a usable Python 3.11+ " +
                "interpreter with the venv module: $env:ELDER_BOOTSTRAP_PYTHON"
            )
        }}
        throw (
            "No usable Python with the venv module was found. Install Python 3.11+ " +
            "or set ELDER_BOOTSTRAP_PYTHON to the exact python.exe path."
        )
    }}

    & $BasePython @BasePythonArgs -m venv --clear $RuntimeRoot
    if ($LASTEXITCODE -ne 0) {{ throw "Failed to create the Elder tooling environment." }}
    & $Python -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) {{ throw "Failed to update pip in the Elder tooling environment." }}
    & $Python -m pip install `
        $Wheel `
        "azure-identity>=1.24,<2" `
        "mem0ai==2.0.17" `
        "python-dotenv>=1.1,<2" `
        "qdrant-client==1.19.0"
    if ($LASTEXITCODE -ne 0) {{ throw "Failed to install the portable Elder runtime." }}
    Set-Content -LiteralPath $Marker -Value $WheelDigest -Encoding ascii
}}
"""


def _launcher_script() -> str:
    return """param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ElderArgs
)

$ErrorActionPreference = "Stop"
$ProjectRoot = $PSScriptRoot
$Bootstrap = Join-Path $ProjectRoot ".elder\\capsule\\bootstrap.ps1"
& $Bootstrap
$Python = Join-Path $ProjectRoot ".elder\\runtime\\tooling\\Scripts\\python.exe"
& $Python -m elder_protocol.cli @ElderArgs
exit $LASTEXITCODE
"""


def _capsule_readme() -> str:
    return f"""# Portable Elder Capsule

This repository contains its own pinned Elder Protocol {PROTOCOL_VERSION} runtime.

Run `./elder.ps1 validate` to create or refresh the ignored tooling environment. The product's
own virtual environment and dependencies remain separate.

Initial personalization:

1. Start Codex in the product repository.
2. Ask it to read `.elder/capsule/START_PROJECT_PROMPT.md`.
3. Complete the Wayfinder interview and approve the generated profile.
4. Preview and compile the project-specific Elder overlay.
5. Configure the ignored `{PORTABLE_MEMORY_ENV_PATH}`.
6. Restart Codex and run live memory activation.

The capsule wheel and manifest are versioned. `.elder/runtime/` is derived local state.
"""


def _start_project_prompt() -> str:
    return f"""# Start This Product Under Elder Protocol

You are initializing or adopting this repository under its repository-local Elder capsule.
Do not implement the product yet.

## Phase 1: Verify The Local Elder Capsule

1. Inspect the current repository without modifying product-owned files.
2. Read `.elder/capsule/README.md` and `.elder/capsule/manifest.json`.
3. Run `./elder.ps1 capsule status --project-root .`.
4. Run `./elder.ps1 validate`.
5. Stop and report the exact blocker if capsule verification or protocol validation fails.

## Phase 2: Understand The Product

Interview the human owner. Ask only the unanswered questions required to establish:

- product name and concise mission;
- target users and the job they need completed;
- measurable success outcomes;
- explicit failure outcomes and unacceptable behavior;
- constraints, non-goals, deadlines, and budget limits;
- whether this is a new repository or an existing product;
- repository topology, languages, frameworks, package managers, and deployment targets;
- lifecycle: prototype, production, or regulated;
- risk tier and data sensitivity;
- maximum agent autonomy;
- accountable human, product, architecture, security, release, and code owners;
- authoritative repository, document, data, and external knowledge sources;
- required capability packs and any forbidden skills;
- whether the product itself needs application memory, kept separate from mandatory Elder
  build memory.

Do not invent missing answers. Restate the resulting project model and unresolved questions
before generating files.

## Phase 3: Create And Ratify The Profile

Write the agreed intake answers to:

`.elder/runtime/bootstrap/intake-answers.json`

Use `.elder/capsule/intake-answers.example.json` only as the field-shape example. Then run:

```powershell
./elder.ps1 intake `
  --answers .elder/runtime/bootstrap/intake-answers.json `
  --output .elder/runtime/bootstrap/draft-profile.json
```

Present the complete draft profile to the human owner. Do not ratify it without explicit
approval. After approval, run:

```powershell
./elder.ps1 ratify-profile `
  --profile .elder/runtime/bootstrap/draft-profile.json `
  --approved-by <human-owner-identity> `
  --output .elder/runtime/bootstrap/ratified-profile.json
```

## Phase 4: Safely Personalize The Repository

If this repository already contains work, inspect Git status and preserve the current state.
Run:

```powershell
./elder.ps1 compile `
  --profile .elder/runtime/bootstrap/ratified-profile.json `
  --output . `
  --dry-run `
  --diff
```

Review every proposed path. Do not use `--force` to replace an existing project-owned
`AGENTS.md`, `ARCHITECTURE.md`, or governed document. Stop and propose an explicit
reconciliation when paths conflict.

After human approval of the dry-run:

```powershell
./elder.ps1 compile `
  --profile .elder/runtime/bootstrap/ratified-profile.json `
  --output .
```

Verify that the repository now contains `AGENTS.md`, `.codex/`, the compiled `.elder/`
contracts, and `.elder/memory/trusted.json`.

## Phase 5: Configure Mandatory Build Memory

Create `{PORTABLE_MEMORY_ENV_PATH}` from `.env.example`. The `.elder/runtime/` boundary is
ignored by the compiled repository contract, so this does not overwrite or depend on a
product-owned root `.env`. The Elder Azure values are development-governance credentials, not
product runtime credentials.

Run:

```powershell
./elder.ps1 dreaming readiness `
  --project-root . `
  --env-file {PORTABLE_MEMORY_ENV_PATH} `
  --live
```

Stop if Mem0, embeddings, Qdrant, or Luna readiness fails.

## Phase 6: Restart And Activate

Tell the human owner to restart Codex in this repository so the compiled `AGENTS.md`,
`.codex/config.toml`, and native Elder skills are loaded. In the new session, read
`AGENTS.md` and run:

```powershell
./elder.ps1 session activate `
  --project-root . `
  --task "<current product request>" `
  --env-file {PORTABLE_MEMORY_ENV_PATH} `
  --memory-live `
  --output .elder/runtime/activation.json
```

Confirm that activation returned `status: ready` and `build_memory.status: ready`. Summarize
the recalled build memory, routed skills, boundaries, risks, and verification ladder.

Only then propose the smallest evidence-bearing implementation plan. During work, follow the
project's generated Elder contracts. Before declaring completion, run the required tests and
`./elder.ps1 session close` with immutable evidence so Mem0 can propose new build-memory
candidates. Never self-promote those candidates.
"""


def _payload(wheel_path: Path) -> dict[str, bytes]:
    wheel_name = wheel_path.name
    return {
        f".elder/capsule/{wheel_name}": wheel_path.read_bytes(),
        ".elder/capsule/bootstrap.ps1": _bootstrap_script(wheel_name).encode("utf-8"),
        ".elder/capsule/intake-answers.example.json": (
            ROOT / "examples" / "intake-answers.json"
        ).read_bytes(),
        ".elder/capsule/README.md": _capsule_readme().encode("utf-8"),
        ".elder/capsule/START_PROJECT_PROMPT.md": _start_project_prompt().encode(
            "utf-8"
        ),
        RUNTIME_IGNORE_PATH: b"*\n!.gitignore\n",
        "elder.ps1": _launcher_script().encode("utf-8"),
    }


def _manifest(payload: dict[str, bytes], source_commit: str, wheel_name: str) -> dict[str, Any]:
    unsigned = {
        "format_version": CAPSULE_FORMAT_VERSION,
        "protocol_version": PROTOCOL_VERSION,
        "source_commit": _require_commit(source_commit),
        "wheel": f".elder/capsule/{wheel_name}",
        "files": {
            path: {
                "sha256": _sha256_bytes(content),
                "size": len(content),
            }
            for path, content in sorted(payload.items())
        },
    }
    return {
        **unsigned,
        "content_sha256": _canonical_sha256(unsigned),
    }


def _zip_info(path: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(path, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    return info


def build_capsule_from_wheel(
    wheel_path: Path,
    output: Path,
    *,
    source_commit: str,
) -> CapsuleReport:
    wheel_path = wheel_path.resolve()
    if not wheel_path.is_file() or wheel_path.suffix != ".whl":
        raise ProtocolError(f"Portable capsule wheel does not exist: {wheel_path}")
    payload = _payload(wheel_path)
    manifest = _manifest(payload, source_commit, wheel_path.name)
    archive_files = {
        **payload,
        MANIFEST_PATH: (
            json.dumps(manifest, indent=2, sort_keys=True) + "\n"
        ).encode("utf-8"),
    }
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        output,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path, content in sorted(archive_files.items()):
            archive.writestr(_zip_info(path), content)
    verified = verify_capsule(output)
    return CapsuleReport(
        archive=output,
        sha256=_sha256_bytes(output.read_bytes()),
        source_commit=verified["source_commit"],
        protocol_version=verified["protocol_version"],
        files=tuple(sorted(verified["files"])),
    )


def _git_source_commit(source_root: Path) -> str:
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=source_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if status.returncode != 0:
        raise ProtocolError("Portable capsule build could not inspect Git status.")
    if status.stdout.strip():
        raise ProtocolError(
            "Portable capsule build requires a clean source tree for commit binding."
        )
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=source_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise ProtocolError("Portable capsule build requires a Git-bound source commit.")
    return _require_commit(result.stdout)


def _build_portable_capsule_from_source(
    output: Path,
    *,
    source_root: Path,
    source_commit: str,
) -> CapsuleReport:
    source_root = source_root.resolve()
    with tempfile.TemporaryDirectory(prefix="elder-capsule-wheel-") as raw:
        wheelhouse = Path(raw)
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "wheel",
                "--no-deps",
                "--wheel-dir",
                str(wheelhouse),
                str(source_root),
            ],
            cwd=source_root,
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            output_text = "\n".join(
                part for part in [result.stdout, result.stderr] if part.strip()
            )
            raise ProtocolError(f"Portable capsule wheel build failed:\n{output_text}")
        wheels = sorted(wheelhouse.glob("elder_protocol-*.whl"))
        if len(wheels) != 1:
            raise ProtocolError(
                f"Portable capsule expected one Elder wheel, found {len(wheels)}."
            )
        return build_capsule_from_wheel(
            wheels[0],
            output,
            source_commit=source_commit,
        )


def build_portable_capsule(
    output: Path,
    *,
    source_root: Path = ROOT,
) -> CapsuleReport:
    source_root = source_root.resolve()
    return _build_portable_capsule_from_source(
        output,
        source_root=source_root,
        source_commit=_git_source_commit(source_root),
    )


def _validated_archive_files(archive_path: Path) -> tuple[dict[str, bytes], dict[str, Any]]:
    archive_path = archive_path.resolve()
    if not archive_path.is_file():
        raise ProtocolError(f"Portable capsule does not exist: {archive_path}")
    try:
        with zipfile.ZipFile(archive_path) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)):
                raise ProtocolError("Portable capsule contains duplicate paths.")
            files: dict[str, bytes] = {}
            for name in names:
                _safe_relative_path(name)
                if name.endswith("/"):
                    continue
                files[name] = archive.read(name)
    except zipfile.BadZipFile as exc:
        raise ProtocolError("Portable capsule is not a valid ZIP archive.") from exc
    if MANIFEST_PATH not in files:
        raise ProtocolError("Portable capsule manifest is missing.")
    try:
        manifest = json.loads(files.pop(MANIFEST_PATH).decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("Portable capsule manifest is invalid JSON.") from exc
    if not isinstance(manifest, dict):
        raise ProtocolError("Portable capsule manifest must be an object.")
    return files, manifest


def verify_capsule(archive_path: Path) -> dict[str, Any]:
    files, manifest = _validated_archive_files(archive_path)
    required = {
        "format_version",
        "protocol_version",
        "source_commit",
        "wheel",
        "files",
        "content_sha256",
    }
    if set(manifest) != required:
        raise ProtocolError("Portable capsule manifest fields are invalid.")
    if manifest["format_version"] != CAPSULE_FORMAT_VERSION:
        raise ProtocolError("Portable capsule format version is unsupported.")
    if manifest["protocol_version"] != PROTOCOL_VERSION:
        raise ProtocolError("Portable capsule protocol version is incompatible.")
    _require_commit(manifest["source_commit"])
    unsigned = {key: value for key, value in manifest.items() if key != "content_sha256"}
    if manifest["content_sha256"] != _canonical_sha256(unsigned):
        raise ProtocolError("Portable capsule manifest digest is invalid.")
    declared = manifest["files"]
    if not isinstance(declared, dict) or set(declared) != set(files):
        raise ProtocolError("Portable capsule payload does not match its manifest.")
    for path, content in files.items():
        record = declared[path]
        if (
            not isinstance(record, dict)
            or set(record) != {"sha256", "size"}
            or record["sha256"] != _sha256_bytes(content)
            or record["size"] != len(content)
        ):
            raise ProtocolError(f"Portable capsule payload digest is invalid: {path}")
    wheel = manifest["wheel"]
    if wheel not in files or not wheel.endswith(".whl"):
        raise ProtocolError("Portable capsule wheel binding is invalid.")
    return manifest


def _installed_manifest(project_root: Path) -> dict[str, Any] | None:
    path = project_root / MANIFEST_PATH
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ProtocolError("Installed portable capsule manifest is invalid.") from exc
    if not isinstance(value, dict):
        raise ProtocolError("Installed portable capsule manifest must be an object.")
    return value


def verify_installed_capsule(project_root: Path) -> dict[str, Any]:
    project_root = project_root.resolve()
    manifest = _installed_manifest(project_root)
    if manifest is None:
        raise ProtocolError("This repository has no installed portable Elder capsule.")
    declared = manifest.get("files")
    if not isinstance(declared, dict):
        raise ProtocolError("Installed portable capsule has no file manifest.")
    for relative, record in declared.items():
        path = project_root / _safe_relative_path(relative)
        if not path.is_file():
            raise ProtocolError(f"Installed portable capsule file is missing: {relative}")
        content = path.read_bytes()
        if (
            not isinstance(record, dict)
            or record.get("sha256") != _sha256_bytes(content)
            or record.get("size") != len(content)
        ):
            raise ProtocolError(f"Installed portable capsule file changed: {relative}")
    unsigned = {key: value for key, value in manifest.items() if key != "content_sha256"}
    if manifest.get("content_sha256") != _canonical_sha256(unsigned):
        raise ProtocolError("Installed portable capsule manifest digest is invalid.")
    return manifest


def install_capsule(
    archive_path: Path,
    project_root: Path,
    *,
    force: bool = False,
) -> dict[str, Any]:
    project_root = project_root.resolve()
    files, manifest = _validated_archive_files(archive_path)
    verify_capsule(archive_path)

    prior = _installed_manifest(project_root)
    prior_verified = False
    if prior is not None:
        if force:
            try:
                verify_installed_capsule(project_root)
            except ProtocolError:
                prior_verified = False
            else:
                prior_verified = True
        else:
            verify_installed_capsule(project_root)
            prior_verified = True

    for relative, content in files.items():
        target = project_root / _safe_relative_path(relative)
        if target.exists() and prior is None and target.read_bytes() != content and not force:
            raise ProtocolError(
                f"Refusing to overwrite a project-owned capsule path: {target}"
            )
    project_root.mkdir(parents=True, exist_ok=True)
    if prior is not None and prior_verified:
        prior_files = prior.get("files", {})
        if not isinstance(prior_files, dict):
            raise ProtocolError("Installed portable capsule has no file manifest.")
        for relative in sorted(set(prior_files) - set(files)):
            stale = project_root / _safe_relative_path(relative)
            if stale.is_file():
                stale.unlink()
    for relative, content in files.items():
        target = project_root / _safe_relative_path(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    manifest_path = project_root / MANIFEST_PATH
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return verify_installed_capsule(project_root)
