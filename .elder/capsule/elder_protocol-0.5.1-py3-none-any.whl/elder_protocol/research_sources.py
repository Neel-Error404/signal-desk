from __future__ import annotations

import hashlib
import json
import subprocess
import tomllib
from collections import Counter
from pathlib import Path
from typing import Any

from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.schema_validation import validate_against_schema


def _repository_path(root: Path, relative_path: str, label: str) -> Path:
    path = Path(relative_path)
    if path.is_absolute():
        raise ProtocolError(f"{label} must be repository-relative.")
    resolved = (root / path).resolve()
    if not resolved.is_relative_to(root):
        raise ProtocolError(f"{label} escapes the repository root.")
    return resolved


def _verify_bound_file(
    root: Path,
    record: dict[str, Any],
    label: str,
) -> None:
    target = _repository_path(root, record["path"], f"{label} path")
    if not target.is_file():
        raise ProtocolError(f"{label} does not exist: {target}")
    actual = hashlib.sha256(target.read_bytes()).hexdigest()
    if actual != record["sha256"]:
        raise ProtocolError(
            f"{label} digest is stale. Expected {record['sha256']}, found {actual}."
        )


def _run_git(repository: Path, *arguments: str) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            ["git", "-C", str(repository), *arguments],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as exc:
        raise ProtocolError("Git is required to verify research-source checkouts.") from exc


def _verify_elder_source_state(
    manifest: dict[str, Any],
    root: Path,
) -> None:
    head = _run_git(root, "rev-parse", "--verify", "HEAD")
    if head.returncode != 0 or head.stdout.strip() != manifest["source_revision"]:
        raise ProtocolError(
            "Elder source revision does not match the research-source manifest."
        )

    status = _run_git(root, "status", "--porcelain")
    if status.returncode != 0:
        raise ProtocolError("Unable to inspect the Elder worktree state.")
    observed = "clean" if not status.stdout.strip() else "uncommitted"
    if observed != manifest["source_worktree_state"]:
        raise ProtocolError(
            "Elder worktree state does not match the research-source manifest."
        )


def _verify_package_metadata(
    checkout: Path,
    package: dict[str, Any],
    source_id: str,
) -> None:
    mode = package["metadata_verification"]
    if mode == "digest-only":
        return

    package_path = _repository_path(
        checkout,
        package["path"],
        f"Research source '{source_id}' package manifest path",
    )
    if mode == "parsed-json":
        try:
            data = json.loads(package_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ProtocolError(
                f"Research source '{source_id}' package manifest is invalid JSON: "
                f"{package_path}"
            ) from exc
        observed_name = data.get("name")
        observed_version = data.get("version")
    elif mode == "parsed-pyproject":
        data = tomllib.loads(package_path.read_text(encoding="utf-8"))
        project = data.get("project", {})
        observed_name = project.get("name")
        observed_version = project.get("version")
    elif mode == "parsed-go-mod":
        lines = [
            line.strip()
            for line in package_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        module_line = next(
            (line for line in lines if line.startswith("module ")),
            None,
        )
        observed_name = (
            module_line.removeprefix("module ").strip()
            if module_line is not None
            else None
        )
        observed_version = None
    else:
        raise ProtocolError(
            f"Research source '{source_id}' package metadata mode is unsupported: {mode}"
        )

    if (
        package["package_name"] is not None
        and observed_name != package["package_name"]
    ):
        raise ProtocolError(
            f"Research source '{source_id}' package name does not match "
            f"{package['path']}."
        )
    if package["version"] is not None and observed_version != package["version"]:
        raise ProtocolError(
            f"Research source '{source_id}' package version does not match "
            f"{package['path']}."
        )


def _verify_checkout(
    source: dict[str, Any],
    root: Path,
) -> None:
    source_id = source["id"]
    checkout = _repository_path(
        root,
        source["local_path"],
        f"Research source '{source_id}' local_path",
    )
    if not checkout.is_dir():
        raise ProtocolError(
            f"Research source '{source_id}' checkout does not exist: {checkout}"
        )

    inside = _run_git(checkout, "rev-parse", "--is-inside-work-tree")
    if inside.returncode != 0 or inside.stdout.strip() != "true":
        raise ProtocolError(
            f"Research source '{source_id}' local_path is not a Git work tree."
        )

    status = _run_git(checkout, "status", "--porcelain")
    if status.returncode != 0 or status.stdout.strip():
        raise ProtocolError(
            f"Research source '{source_id}' checkout must be clean."
        )

    remote = _run_git(checkout, "config", "--get", "remote.origin.url")
    if remote.returncode != 0 or remote.stdout.strip() != source["upstream_url"]:
        raise ProtocolError(
            f"Research source '{source_id}' origin does not match the manifest."
        )

    head = _run_git(checkout, "rev-parse", "--verify", "HEAD")
    if source["source_availability"] == "available":
        if head.returncode != 0:
            raise ProtocolError(
                f"Research source '{source_id}' has no resolvable HEAD."
            )
        if head.stdout.strip() != source["revision"]["commit"]:
            raise ProtocolError(
                f"Research source '{source_id}' checkout is not at its pinned commit."
            )
    elif head.returncode == 0:
        raise ProtocolError(
            f"Unavailable research source '{source_id}' unexpectedly has a commit."
        )

    license_record = source["license"]
    if license_record["status"] == "identified":
        _verify_bound_file(
            checkout,
            {
                "path": license_record["path"],
                "sha256": license_record["sha256"],
            },
            f"Research source '{source_id}' license",
        )

    for package in source["package_manifests"]:
        _verify_bound_file(
            checkout,
            package,
            f"Research source '{source_id}' package manifest",
        )
        _verify_package_metadata(checkout, package, source_id)

    for inspected_path in source["inspected_paths"]:
        _verify_bound_file(
            checkout,
            inspected_path,
            f"Research source '{source_id}' inspected path",
        )

    for evidence_file in source["evidence_files"]:
        _verify_bound_file(
            root,
            evidence_file,
            f"Research source '{source_id}' supplemental evidence",
        )


def validate_research_sources(
    manifest_path: Path,
    root: Path,
    *,
    verify_checkouts: bool = False,
) -> dict[str, Any]:
    manifest_path = manifest_path.resolve()
    root = root.resolve()
    manifest = load_json(manifest_path)
    schema_path = manifest_path.with_name("research-sources.schema.json")
    if not schema_path.is_file():
        raise ProtocolError(f"Research-source schema does not exist: {schema_path}")
    validate_against_schema(
        manifest,
        schema_path.name,
        label="Research-source manifest",
        schema_root=schema_path.parent,
    )

    source_ids = [source["id"] for source in manifest["sources"]]
    duplicates = sorted(
        source_id
        for source_id, count in Counter(source_ids).items()
        if count > 1
    )
    if duplicates:
        raise ProtocolError(
            f"Duplicate research-source ids: {', '.join(duplicates)}"
        )

    for artifact_name, artifact in manifest["artifacts"].items():
        _verify_bound_file(
            root,
            artifact,
            f"Research-source {artifact_name.replace('_', ' ')}",
        )

    policy = manifest["reuse_policy"]
    if policy["status"] != "approved":
        approved_sources = [
            source["id"]
            for source in manifest["sources"]
            if source["reuse"]["approval_state"] == "human-approved"
        ]
        if approved_sources:
            raise ProtocolError(
                "Research sources cannot be human-approved while the reuse policy "
                f"is not approved: {approved_sources}"
            )
    elif policy["approval_evidence"] != manifest["artifacts"][
        "decision_record"
    ]["path"]:
        raise ProtocolError(
            "Approved reuse policy must bind the decision-record artifact."
        )

    if manifest["elder_repository_license"]["status"] == "not-declared":
        compatible = [
            source["id"]
            for source in manifest["sources"]
            if source["reuse"]["repository_license_compatibility"] == "compatible"
        ]
        if compatible:
            raise ProtocolError(
                "Research sources cannot be marked license-compatible while Elder's "
                f"repository license is not declared: {compatible}"
            )

    if policy["code_copy"] == "prohibited":
        copied = [
            source["id"]
            for source in manifest["sources"]
            if source["reuse"]["code_reuse"]
            in {"copied", "selectively-extracted"}
        ]
        if copied:
            raise ProtocolError(
                f"Research sources conflict with the code-copy policy: {copied}"
            )

    if policy["forking"] == "prohibited":
        forked = [
            source["id"]
            for source in manifest["sources"]
            if source["reuse"]["code_reuse"] == "forked"
            or source["reuse"]["package_integration"] == "fork"
        ]
        if forked:
            raise ProtocolError(
                f"Research sources conflict with the forking policy: {forked}"
            )

    if policy["direct_dependency"] == "prohibited":
        dependencies = [
            source["id"]
            for source in manifest["sources"]
            if source["reuse"]["package_integration"]
            in {"direct-dependency", "optional-dependency"}
        ]
        if dependencies:
            raise ProtocolError(
                "Research sources conflict with the direct-dependency policy: "
                f"{dependencies}"
            )

    if verify_checkouts:
        _verify_elder_source_state(manifest, root)
        for source in manifest["sources"]:
            _verify_checkout(source, root)

    availability = Counter(
        source["source_availability"] for source in manifest["sources"]
    )
    return {
        "manifest": str(manifest_path),
        "source_count": len(manifest["sources"]),
        "sources_by_availability": dict(sorted(availability.items())),
        "reuse_policy_status": policy["status"],
        "checkouts_verified": verify_checkouts,
        "status": "passed",
    }
