from __future__ import annotations

import difflib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.build_memory import (
    finalize_build_memory_ledger,
    validate_build_memory_ledger,
)
from elder_protocol.constants import (
    PORTABLE_MEMORY_ENV_PATH,
    PROTOCOL_VERSION,
    SKILLS_DIR,
)
from elder_protocol.errors import ProtocolError
from elder_protocol.graph import build_project_graph
from elder_protocol.governance import (
    identity_for_role,
    resolve_authority_bindings,
    resolve_obligations,
)
from elder_protocol.io import json_text, load_json, sha256_file, sha256_text, write_text
from elder_protocol.profiles import (
    migrate_profile,
    resolve_capability_packs,
    validate_profile,
)


OWNERSHIP_PATH = ".elder/ownership.json"


@dataclass(frozen=True)
class CompileReport:
    output: Path
    changes: tuple[str, ...]
    unchanged: tuple[str, ...]
    migration_notes: tuple[str, ...]
    diff: str
    wrote: bool


def resolve_skills(
    profile: dict[str, Any],
    data: dict[str, dict[str, Any]],
    resolved_pack_ids: list[str],
) -> list[dict[str, Any]]:
    registry = {entry["id"]: entry for entry in data["skill-registry"]["skills"]}
    selected_packs = set(resolved_pack_ids)
    forbidden = set(profile["skill_overrides"]["forbidden"])
    requested = {
        entry["id"]
        for entry in registry.values()
        if selected_packs & set(entry["packs"])
    } | set(profile["skill_overrides"]["required"])
    requested -= forbidden
    resolved: list[str] = []
    visiting: set[str] = set()

    def include(skill_id: str) -> None:
        if skill_id in forbidden:
            raise ProtocolError(
                f"Required skill dependency '{skill_id}' is forbidden by the profile."
            )
        if skill_id in visiting:
            raise ProtocolError(f"Skill dependency cycle includes '{skill_id}'.")
        if skill_id in resolved:
            return
        visiting.add(skill_id)
        for dependency in registry[skill_id]["requires"]:
            include(dependency)
        visiting.remove(skill_id)
        resolved.append(skill_id)

    for skill_id in sorted(
        requested,
        key=lambda item: (registry[item]["priority"], item),
    ):
        include(skill_id)
    return [registry[skill_id] for skill_id in resolved]


def resolved_contract(
    profile: dict[str, Any],
    data: dict[str, dict[str, Any]],
    skills: list[dict[str, Any]],
    resolved_pack_ids: list[str],
    migration_notes: list[str],
) -> dict[str, Any]:
    selected_ids = set(resolved_pack_ids)
    selected_packs = [
        pack
        for pack in data["capability-packs"]["packs"]
        if pack["id"] in selected_ids
    ]
    return {
        "elder_protocol_version": PROTOCOL_VERSION,
        "meta_architecture_version": data["meta-architecture"]["version"],
        "protocol_graph_version": data["protocol-graph"]["version"],
        "profile": profile,
        "requested_capability_packs": profile["capability_packs"],
        "resolved_capability_packs": resolved_pack_ids,
        "capability_packs": selected_packs,
        "skills": [skill["id"] for skill in skills],
        "invariants": data["invariants"]["invariants"],
        "change_classes": data["change-classes"]["classes"],
        "ontology_version": data["ontology"]["version"],
        "authority_matrix_version": data["authority-matrix"]["version"],
        "role_registry": ".elder/role-registry.json",
        "authority_bindings": ".elder/authority-bindings.json",
        "resolved_obligations": ".elder/resolved-obligations.json",
        "delegation_policy": ".elder/delegation-policy.json",
        "multi_agent_runtime_policy": ".elder/multi-agent-runtime-policy.json",
        "stack_adapter_registry": ".elder/stack-adapter-registry.json",
        "project_graph": ".elder/project-graph.json",
        "capability_pack_contracts": ".elder/capability-packs.json",
        "recommendation_ledger": ".elder/recommendation-ledger.json",
        "judgment_rubric": ".elder/judgment-rubric.json",
        "operational_maturity": ".elder/operational-maturity.json",
        "design_registry": ".elder/design-registry.json",
        "transcript_review_policy": ".elder/transcript-review-policy.json",
        "evaluation_registry": ".elder/evaluation-registry.json",
        "evaluation_dataset": ".elder/evaluation-dataset.json",
        "evaluator_contract": ".elder/evaluator-contract.json",
        "telemetry_contract": ".elder/telemetry-contract.json",
        "context_policy": ".elder/context-policy.json",
        "memory_policy": ".elder/memory-policy.json",
        "learning_policy": ".elder/learning-policy.json",
        "qualification_policy": ".elder/qualification-policy.json",
        "autonomy_authority_source": ".elder/autonomy-authority-source.json",
        "autonomy_policy": ".elder/autonomy-policy.json",
        "autonomy_classes": ".elder/autonomy-classes.json",
        "trace_schemas": [
            "work-item.schema.json",
            "agent-run.schema.json",
            "agent-action.schema.json",
            "evidence-bundle.schema.json",
            "knowledge-graph.schema.json",
            "telemetry-event.schema.json",
            "telemetry-report.schema.json",
            "context-policy.schema.json",
            "context-request.schema.json",
            "memory-policy.schema.json",
            "memory-approval.schema.json",
            "learning-observation.schema.json",
            "learning-evaluation.schema.json",
            "learning-approval.schema.json",
            "learning-promotion.schema.json",
            "hosted-evidence-bundle.schema.json",
            "qualification-report.schema.json",
            "autonomy-certification.schema.json",
            "incident-budget.schema.json",
            "autonomy-suspension.schema.json",
            "autonomy-revocation.schema.json",
            "autonomy-renewal.schema.json",
            "qualification-consumption.schema.json",
            "effective-autonomy-report.schema.json",
            "autonomy-work-item.schema.json",
            "autonomy-match-report.schema.json",
            "autonomy-simulation-report.schema.json",
            "autonomy-certification-event.schema.json",
            "autonomy-replay-report.schema.json",
            "autonomy-authority-evidence.schema.json",
            "autonomy-authority-lease.schema.json",
            "hosted-git-evidence.schema.json",
            "supervised-pr-execution.schema.json",
            "supervised-pr-packet.schema.json",
            "supervised-pr-response.schema.json",
            "canary-plan.schema.json",
            "canary-simulation-report.schema.json",
            "canary-authority-lease.schema.json",
            "canary-authority-evidence.schema.json",
            "canary-provider-evidence.schema.json",
            "canary-execution-packet.schema.json",
            "canary-response.schema.json",
            "canary-observation.schema.json",
            "canary-observation-report.schema.json",
            "canary-rollback-packet.schema.json",
            "canary-rollback-response.schema.json",
            "canary-workflow-result.schema.json",
            "knowledge-query.schema.json",
            "delegation.schema.json",
            "agent-message.schema.json",
            "checkpoint.schema.json",
            "approval-decision.schema.json",
            "runtime-lease.schema.json",
        ],
        "interface_schemas": [
            "tool-contract.schema.json",
            "mcp-registry.schema.json",
            "context-packet.schema.json",
            "memory-record.schema.json",
            "learning-candidate.schema.json",
            "learning-policy.schema.json",
            "qualification-policy.schema.json",
            "autonomy-authority-source.schema.json",
            "autonomy-policy.schema.json",
            "autonomy-class.schema.json",
            "component-operating-contract.schema.json",
            "recommendation-ledger.schema.json",
            "judgment-rubric.schema.json",
            "operational-maturity.schema.json",
            "design-registry.schema.json",
            "architecture-boundary.schema.json",
            "transcript-review-policy.schema.json",
            "transcript-review.schema.json",
            "evaluation-registry.schema.json",
            "evaluation-dataset.schema.json",
            "evaluator-contract.schema.json",
            "evaluation-candidate.schema.json",
            "judge-results.schema.json",
            "evaluation-report.schema.json",
            "calibration-report.schema.json",
            "comparison-report.schema.json",
            "telemetry-contract.schema.json",
            "role-registry.schema.json",
            "authority-bindings.schema.json",
            "resolved-obligations.schema.json",
            "delegation-policy.schema.json",
            "multi-agent-runtime-policy.schema.json",
            "authority-grant.schema.json",
            "tool-grant.schema.json",
            "budget.schema.json",
            "deadline.schema.json",
            "cancellation.schema.json",
            "escalation.schema.json",
            "stack-adapter.schema.json",
            "stack-adapter-registry.schema.json",
        ],
        "migration_notes": migration_notes,
        "generated_status": "draft-contract",
    }


def _bullets(items: list[str], empty: str = "None declared.") -> str:
    return "\n".join(f"- {item}" for item in items) if items else empty


def render_agents(
    profile: dict[str, Any],
    skills: list[dict[str, Any]],
    resolved_pack_ids: list[str],
) -> str:
    owners = {
        role: identity_for_role(profile, f"{role}-owner")
        for role in ["human", "product", "architecture", "security", "release", "code"]
    }
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# AGENTS.md

## Mission

{profile['mission']}

## Operating Profile

- Project type: `{profile['project_type']}`
- Lifecycle: `{profile['lifecycle']}`
- Topology: `{profile['topology']}`
- Risk tier: `{profile['risk_tier']}`
- Data sensitivity: `{profile['data_sensitivity']}`
- Autonomy ceiling: `{profile['autonomy_ceiling']}`
- Requested capability packs: {', '.join(f'`{item}`' for item in profile['capability_packs'])}
- Resolved capability packs: {', '.join(f'`{item}`' for item in resolved_pack_ids)}

## Factory And Product Boundary

- Elder is the product-agnostic factory kernel.
- This repository contains the project-owned product generated under that kernel.
- Reference projects prove selected contracts; they are not universal product templates.
- Capability packs define required properties. Stack adapters define technology-specific practice.
- Selecting a capability does not prove that it is operational.

## Required Read Order

1. `.elder/project-profile.json` - mission, outcomes, risk, owners, and selected capabilities.
2. `.elder/project-contract.json` - resolved invariants, change classes, interfaces, and evidence.
3. `.elder/project-graph.json` - connected project, pack, skill, authority, and evidence relationships.
4. `.elder/capability-packs.json` - selected pack responsibilities, artifacts, evidence, and adapters.
5. `.elder/recommendation-ledger.json` - adopted principles, controls, evidence, status, and gaps.
6. `.elder/judgment-rubric.json` - evidence-cited quality dimensions and vetoes.
7. `.elder/design-registry.json` - versioned design intent, owners, status, and content digests.
8. `.elder/transcript-review-policy.json` - independent advisory trace-evaluation policy.
9. `.elder/evaluation-registry.json` and `.elder/evaluation-dataset.json` - governed quality cases and splits.
10. `.elder/evaluator-contract.json` - grader, calibration, comparison, and authority rules.
11. `.elder/telemetry-contract.json` - correlated signals, privacy, cardinality, budgets, and authority.
12. `.elder/context-policy.json` and `.elder/memory-policy.json` - retrieval, budget, lifecycle, and promotion authority.
13. `.elder/memory/trusted.json` - portable approved repository-development memory.
14. `.elder/role-registry.json`, `.elder/authority-bindings.json`, and `.elder/resolved-obligations.json` - canonical identities, grants, and selected-pack duties.
15. `.elder/delegation-policy.json` and `.elder/stack-adapter-registry.json` - bounded delegation invariants and specified stack translations.
16. `.elder/multi-agent-runtime-policy.json` - local dispatch, lease, journal, cancellation, and replay constraints.
17. `.elder/learning-policy.json` - quarantined replay, evaluation, approval, and non-mutating promotion rules.
18. `.elder/qualification-policy.json` - trusted hosted evidence and cumulative maturity gates.
19. `.elder/autonomy-authority-source.json` - project ceiling and approved authority-config digests.
20. `.elder/autonomy-policy.json` - qualification-gated simulation and supervised-PR rules.
21. `.elder/autonomy-classes.json` - five narrow reversible autonomy subclasses and restrictions.
22. `ARCHITECTURE.md` and accepted ADRs - stable project-specific boundaries.
23. Current work item, delegated context packet, and evidence plan.

## Accountable Identities

- Human: {owners['human']}
- Product: {owners['product']}
- Architecture: {owners['architecture']}
- Security: {owners['security']}
- Release: {owners['release']}
- Code: {owners['code']}

## Skill Route

{_bullets([f"`{skill['id']}` - {skill['description']}" for skill in skills])}

Selected Elder skills are installed as native Codex project skills under `.codex/skills/`.
Invoke a routed workflow with `$<skill-id>` or load the referenced `SKILL.md`.

## Session Activation

Before governed implementation, run:

```powershell
./elder.ps1 session activate `
  --project-root . `
  --task "<current user request>" `
  --env-file {PORTABLE_MEMORY_ENV_PATH} `
  --memory-live `
  --output .elder/runtime/activation.json
```

Use the repository-local `elder.ps1` launcher when a portable capsule is installed. Otherwise,
use the pinned `elder` executable that compiled this project. Do not begin governed edits when
activation fails. The activation packet verifies Elder-owned file hashes, hydrates portable
trusted build memory, synchronizes and recalls it through Mem0, selects applicable skills,
records the Codex sandbox boundary, and binds repository dreaming to candidate-only Luna use.

## Constitutional Rules

1. Follow the required read order before governed work.
2. Declare the change class before implementation.
3. Agents cannot approve or promote their own governed changes.
4. Operational claims require current executable evidence.
5. Production credentials remain outside agent sandboxes.
6. Test Foundation -> Component -> Integration -> Workflow -> Stress.
7. Never stage, commit, push, reset, clean, or rewrite history without permission.
8. Stop when required authority, evidence, or profile information is missing.
9. A delegation cannot broaden parent scope, authority, tools, budget, or deadline.
10. Messages are evidence-bearing communication only; they do not mutate governed state.

## Session Closure

After evidence-bearing work and before declaring completion, run:

```powershell
./elder.ps1 session close `
  --project-root . `
  --activation .elder/runtime/activation.json `
  --env-file {PORTABLE_MEMORY_ENV_PATH} `
  --evidence test-result=<path-to-test-evidence> `
  --output .elder/runtime/session-close.json
```

This proposes expiring build-memory candidates through Mem0. It does not promote them. The
human owner separately promotes durable records, which updates `.elder/memory/trusted.json`.

## Mutability And Evidence

- Treat generated files listed in `.elder/ownership.json` as Elder-owned.
- Treat `.elder/memory/trusted.json` as governed human-approved project memory; update it only
  through Elder memory promotion, supersession, or revocation.
- Treat project source, tests, and product-specific design as project-owned writable surfaces
  only within an approved work item.
- Treat constitutional rules, accepted ADRs, authority, evaluators, release policy, and trusted
  memory as governed or protected.
- Link outcome -> work item -> agent run -> diff -> tests -> approval -> commit -> artifact ->
  deployment -> observed result.
- Update the profile, pack, architecture, or evidence source and regenerate the project graph
  when a governed relationship changes. Do not hand-edit `.elder/project-graph.json`.
"""


def render_architecture(profile: dict[str, Any]) -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Architecture

**Project:** {profile['name']}
**Status:** Generated draft requiring project-specific ratification

## Boundaries

- Repository topology: `{profile['topology']}`
- Languages: {', '.join(f'`{item}`' for item in profile['languages'])}
- Deployment targets: {', '.join(f'`{item}`' for item in profile['deployment_targets']) or 'none declared'}
- Maximum autonomy: `{profile['autonomy_ceiling']}`

## Stable Invariants

1. Constitutional changes require human ratification.
2. Executor, sole evaluator, and promoter responsibilities remain separated.
3. Production credentials stay outside agent sandboxes.
4. Governed changes remain traceable from outcome through observed result.
5. Learning cannot directly modify production or trusted policy.

## Project-Specific Work Required

Before implementation, add bounded contexts, component ownership, dependency direction,
contracts, side effects, failure states, and executable architecture fitness functions through
an ADR. This generated file is not evidence that those decisions have been made.
"""


def render_adr(profile: dict[str, Any]) -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# ADR 0001: Adopt Elder Project Foundation

## Status

Proposed.

## Context

{profile['name']} requires a governed foundation for a `{profile['project_type']}` project with
`{profile['risk_tier']}` risk and an autonomy ceiling of `{profile['autonomy_ceiling']}`.

## Decision

Adopt the resolved contract under `.elder/`, the generated repository instructions, the test
ladder, explicit ownership, change classes, evidence requirements, and capability packs:
{', '.join(profile['capability_packs'])}.

## Consequences

- Agents operate within declared authority and change classes.
- Generated Elder-owned files are hash-protected.
- Project-specific architecture still requires ratification.
- Operational capability must be proved separately from configuration.

## Alternatives Considered

Record project-specific alternatives before accepting this ADR.
"""


def render_testing() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Testing Protocol

Run one level at a time:

1. Foundation
2. Component
3. Integration
4. Workflow
5. Stress

For every failure, record the failing command, root cause, corrective change, and rerun result
at the same level before advancing. No fallback may convert a failure into a pass silently.
"""


def render_ownership(profile: dict[str, Any]) -> str:
    owners = {
        role: identity_for_role(profile, f"{role}-owner")
        for role in ["human", "product", "architecture", "security", "release", "code"]
    }
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Ownership

| Authority | Accountable owner |
|---|---|
| Product outcomes | {owners['product']} |
| Architecture and invariants | {owners['architecture']} |
| Security and credentials | {owners['security']} |
| Release and production promotion | {owners['release']} |
| Code and implementation boundaries | {owners['code']} |
| Final accountable human escalation | {owners['human']} |

Agents may propose governed changes. Human owners approve constitutional changes, exceptions,
and production consequences. Tool availability does not grant authority.
"""


def render_golden_path() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Golden Path

```text
Frame outcome -> Wayfinder intake -> Grill assumptions -> Ratify profile
-> Design contracts and architecture -> Classify change -> Isolate work
-> Implement -> Foundation -> Component -> Integration -> Workflow -> Stress
-> Independent evaluation -> Reviewable PR -> Immutable artifact
-> Progressive deployment -> Observe outcome -> Quarantined learning
```

Each transition requires the evidence and authority declared in `.elder/project-contract.json`.
"""


def render_trace_contract() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Trace Contract

Every governed change must link:

```text
outcome -> work item -> design decision -> agent run -> tools and actions
-> diff -> tests -> evaluation -> approval -> commit -> artifact
-> deployment -> runtime evidence -> user or business result -> learning candidate
```

Use the Elder work-item, agent-run, evidence-bundle, and knowledge-graph schemas. Redact secrets
and sensitive personal data before persistence.
"""


def render_assurance() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Assurance Contract

## Required Order

1. Run deterministic invariant, type, architecture, security, and test checks.
2. Run independent probabilistic review for unsupported assumptions, inefficient tool use,
   design quality, and candidate alternatives.
3. Apply the judgment rubric with cited evidence.
4. Obtain accountable human approval where risk, authority, or external consequence requires it.
5. Record the result and known gaps without inflating the operational claim.

## Anti-Slop Rules

- Stable architecture boundaries live in `ARCHITECTURE.md`; volatile design detail does not.
- Hard-to-reverse changes require a versioned design document or ADR before implementation.
- Dependency direction and forbidden coupling must become executable fitness functions.
- Agent transcripts are review inputs, not authority.
- A probabilistic reviewer cannot override deterministic failures or approve its own work.
- Passing tests is not enough; outcome fit, changeability, operability, cost, and user trust
  remain part of quality.

## Evidence Sources

- `.elder/recommendation-ledger.json`
- `.elder/judgment-rubric.json`
- `.elder/operational-maturity.json`
- `.elder/evaluation-registry.json`
- `.elder/evaluator-contract.json`
- `.elder/telemetry-contract.json`
- `.elder/context-policy.json`
- `.elder/memory-policy.json`
- `.elder/project-graph.json`
- Current work-item, test, evaluation, artifact, deployment, and outcome records
"""


def render_component_contract() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Component Operating Contract

Every independently deployable, agent-operated, cross-language, or authority-bearing component
must instantiate `component-operating-contract.schema.json`.

The contract declares:

- accountable owner and bounded purpose;
- deterministic, probabilistic, hybrid, or human execution kind;
- typed inputs, outputs, and explicit error behavior;
- allowed and forbidden dependencies;
- side effects, reversibility, approvals, identity, credentials, and tool scopes;
- data classification, retention, and lineage;
- failure conditions, signals, and responses;
- traces, metrics, logs, and correlation;
- cost unit, budget, and meter;
- tests, evals, and architecture fitness functions;
- immutable artifact, environment, health check, rollback trigger, procedure, and owner.

Do not use free-form model output as a control input for a governed side effect.
"""


def render_architecture_boundaries() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Architecture Boundaries

Create a project-owned contract conforming to `architecture-boundary.schema.json`.

The first Elder adapter is `python-ast-imports`. It declares:

- one import prefix;
- every governed Python module and source path;
- allowed internal dependencies for each module;
- whether undeclared modules fail closed.

Run:

```powershell
py -m elder_protocol.cli architecture check --contract <contract.json> --root <project-root>
```

Add the command to Foundation tests and hosted required checks. A diagram or prose dependency
rule is not enforcement evidence.
"""


def render_transcript_review() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Transcript Review

Review immutable workflow JSONL with an evaluator identity that differs from the executor:

```powershell
py -m elder_protocol.cli evaluate transcript `
  --trace <trace.jsonl> `
  --policy .elder/transcript-review-policy.json `
  --evaluator-id <independent-evaluator> `
  --executor-id <executor> `
  --output <review.json>
```

The deterministic P4.1 evaluator checks trace integrity, sequence order, start and terminal
events, failure budgets, elapsed-time evidence, and secret-shaped field names.

Review authority is advisory-only. The evaluator cannot approve, promote, edit the trace, or
change its own policy.
"""


def render_evaluation() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Evaluation Harness

## Required Sequence

1. Validate `.elder/evaluation-registry.json`.
2. Calibrate each rubric judge on the calibration split.
3. Run candidate evaluation on the declared split.
4. Compare the candidate against a bound baseline report.
5. Escalate the advisory result to the accountable human authority.

## Rules

- Deterministic graders are preferred when the property can be expressed exactly.
- Rubric graders require a qualified calibration report for the same dataset revision.
- Executor and evaluator identities must differ.
- Candidate outputs, judge results, datasets, and reports are immutable evidence inputs.
- A critical paired regression fails closed.
- Evaluators cannot approve, promote, or modify their own policy.

Use `evaluation-candidate.schema.json`, `judge-results.schema.json`,
`evaluation-report.schema.json`, `calibration-report.schema.json`, and
`comparison-report.schema.json` for project-owned adapters and persistence.
"""


def render_telemetry() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Correlated Telemetry

## Signal Model

Use `.elder/telemetry-contract.json` and `telemetry-event.schema.json` for product, model,
tool, factory, cost, and outcome signals. Every event requires a valid trace id, span id,
project id, and run id. Keep work-item, agent-run, artifact, deployment, evaluation, and
outcome identifiers as trace or event correlation fields, not metric dimensions.

## Privacy And Cardinality

- Do not persist prompts or model outputs by default.
- Reject secret-shaped attribute and dimension names.
- Validate or replace untrusted incoming trace context.
- Keep metric names and dimensions low-cardinality.
- Use trace links or exemplars in a stack adapter rather than trace ids as metric labels.

## Authority

Telemetry reports are advisory evidence. Cost, error, latency, correlation, and cardinality
budgets may block a claim, but a passing report cannot approve or promote a change.

## Local Commands

```powershell
py -m elder_protocol.cli telemetry ingest --source-kind workbench --input <trace.jsonl> --project-id <project> --output <events.jsonl>
py -m elder_protocol.cli telemetry validate --events <events.jsonl>
py -m elder_protocol.cli telemetry report --events <events.jsonl> --output <report.json>
```
"""


def render_knowledge_runtime() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Governed Knowledge Runtime

## Required Boundaries

- Persist graph nodes, edges, memory, provenance, and audit events through a declared store adapter.
- Keep candidate and trusted memory separate.
- Require independent `human-owner` approval before trusted-memory transitions.
- Retrieve trusted, unexpired, in-scope memory by default.
- Assemble context deterministically under `.elder/context-policy.json`.
- Record every authority, status, freshness, duplicate, and budget exclusion.
- Fail closed when required context is missing, stale, unauthorized, or over budget.
- Treat context packets as immutable evidence; verify their content digest before use.

## Local Reference

```powershell
py -m elder_protocol.cli knowledge init --store <knowledge.db>
py -m elder_protocol.cli knowledge ingest --store <knowledge.db> --graph <graph.json>
py -m elder_protocol.cli memory propose --store <knowledge.db> --record <memory.json> --subject-role learning-agent
py -m elder_protocol.cli memory promote --store <knowledge.db> --memory-id <id> --approval <approval.json>
py -m elder_protocol.cli context assemble --store <knowledge.db> --request <request.json> --output <packet.json>
```

The SQLite adapter is a local reference implementation. It is not evidence of hosted durability,
tenant isolation, encryption, backup, recovery, vector retrieval, or multi-agent checkpoints.
"""


def render_build_memory() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Build Memory

Every Elder project has mandatory repository-development memory.

- `.elder/memory/trusted.json` is the portable, governed authority of record.
- `.elder/runtime/knowledge.db` is the rebuildable local Elder query store.
- `.elder/runtime/memory/qdrant/` is the rebuildable Mem0 semantic index.
- Candidate extraction never promotes itself.
- Product or customer memory must use separate storage, namespaces, policy, and authority.

Session activation hydrates the local store from the portable ledger. Live memory activation
synchronizes trusted records into Mem0 and uses semantic recall to rank task-relevant context.
"""


def render_obligations() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Resolved Obligations

`.elder/resolved-obligations.json` answers which selected capability-pack requirements apply to
this project. Every obligation binds a pack, canonical owner role, project identity, required
artifact type, evidence levels, evidence references, and current status.

An obligation is a contract, not proof that the artifact or runtime capability exists.
"""


def render_delegation() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Delegation Contract

Every delegated task must conform to `delegation.schema.json` and the generated
`.elder/delegation-policy.json`.

- Child scope, actions, tools, budget, deadline, and expiry stay within the parent run.
- Tool access never grants approval or promotion authority.
- Every child run traces to one parent delegation and emits immutable checkpoints.
- Cancellation propagates to active child work.
- Executor, sole evaluator, and promoter identities remain separated.
- Messages cannot mutate governed state.
- Failed authority validation blocks execution.

P4.5A specifies and validates these contracts. P4.5B provides the bounded local runtime that
submits validated chains, leases work only to the assigned identity, journals typed actions and
messages, verifies checkpoint continuity, propagates cancellation, and reconstructs state from
an append-only digest chain.

The local runtime does not authenticate external identities, execute model or tool providers,
approve work, promote artifacts, or prove hosted checkpoint durability.
"""


def render_multi_agent_runtime() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Bounded Multi-Agent Runtime

Use `.elder/multi-agent-runtime-policy.json` with the project-specific profile, authority
bindings, delegation, child run, and digest-bound context packet.

## Local Lifecycle

```text
validated parent run + active delegation + child run + context packet
-> submit -> assigned-identity lease -> typed action/message journal
-> digest-linked checkpoint -> completion, escalation, cancellation, or expiry
-> deterministic replay verification
```

## Runtime Rules

- A child operation requires the active lease issued to its assigned identity.
- Actions must remain within delegated resource, action, tool, budget, and deadline.
- Messages are append-only evidence and have no governed state effect.
- Checkpoints are contiguous, digest-linked, cumulative, and bound to journaled actions.
- Cancellation propagates transactionally to active descendant work.
- Runtime replay must reconstruct the persisted lifecycle state from the append-only event chain.
- The coordinator cannot approve, promote, execute external tools, or authenticate external
  identities. Those remain separate adapters and accountable authorities.

The SQLite coordinator is a local reference implementation, not a hosted broker, remote agent
service, distributed scheduler, production identity provider, or multi-tenant checkpoint store.
"""


def render_learning_runtime() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Quarantined Learning Runtime

Use `.elder/learning-policy.json` to turn immutable evidence into bounded learning candidates.

## Local Lifecycle

```text
candidate artifact + source evidence
-> counterfactual replay in quarantine
-> side-effect-free shadow observations
-> independent deterministic evaluation
-> kind-specific accountable approvals
-> separate promoter emits immutable promotion packet
-> target-specific owner applies or rejects the change outside this runtime
```

## Runtime Rules

- Candidate artifacts are copied into the local store and bound by SHA-256.
- The store binds one project profile and resolved authority snapshot.
- Every actor must match the project-bound role and required resource action.
- Replay and shadow observations must use immutable input and output digests.
- Replay and shadow modes cannot produce side effects or mutate governed targets.
- The candidate creator and observation executors cannot evaluate the candidate.
- Evaluators remain advisory-only and cannot approve or promote.
- Approval roles depend on candidate kind and remain separate from creator and evaluator.
- The promoter remains separate from creator, evaluator, and approvers.
- Promotion and rollback emit packets with `applies_target_mutation: false`.
- Applying memory, skill, policy, evaluator, architecture, or production changes remains a
  separate governed workflow.

## Local Commands

```powershell
py -m elder_protocol.cli learning init --store <learning.db> --profile .elder/project-profile.json
py -m elder_protocol.cli learning propose --store <learning.db> --profile .elder/project-profile.json --candidate <candidate.json> --artifact-base <repo>
py -m elder_protocol.cli learning observe --store <learning.db> --profile .elder/project-profile.json --record <observation.json>
py -m elder_protocol.cli learning evaluate --store <learning.db> --profile .elder/project-profile.json --candidate-id <id> --evaluator-id <identity>
py -m elder_protocol.cli learning decide --store <learning.db> --profile .elder/project-profile.json --approval <approval.json>
py -m elder_protocol.cli learning promote --store <learning.db> --profile .elder/project-profile.json --candidate-id <id> --promoted-by <identity>
py -m elder_protocol.cli learning replay --store <learning.db> --profile .elder/project-profile.json --candidate-id <id>
```

The SQLite runtime is a local reference implementation. It does not execute models or tools,
apply target mutations, authenticate external identities, operate a hosted shadow service, or
authorize production self-learning.
"""


def render_repository_dreaming() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Repository Dreaming

Repository dreaming improves the development process for this repository. It is separate from
any product feature that learns from product users or operational data.

## Governed Flow

```text
completed work + immutable evidence + activation packet
-> evidence-only quarantine workspace
-> Mem0 extraction and semantic recall
-> Azure Luna candidate generation
-> Elder learning candidate validation
-> P4.6 replay, shadow evaluation, approval, and promotion packet
-> separate target-specific application
```

Mem0 receives copied evidence only and writes to a local Qdrant candidate index. Luna receives
the bounded evidence and semantic recall through the configured Azure endpoint. Neither adapter
can access the source repository, approve, promote, or mutate trusted state.

## Commands

```powershell
elder dreaming readiness --project-root . --env-file {PORTABLE_MEMORY_ENV_PATH} --live
elder dreaming prepare --project-root . --activation .elder/runtime/activation.json --work-item-id <id> --trigger <trigger> --evidence <kind>=<path> --workspace .elder/runtime/dreaming/<id>
elder dreaming run --project-root . --env-file {PORTABLE_MEMORY_ENV_PATH} --workspace .elder/runtime/dreaming/<id> --mode routine
elder dreaming accept --workspace .elder/runtime/dreaming/<id> --candidate .elder/runtime/dreaming/<id>/candidate.json --output .elder/runtime/dreaming/<id>/accepted-candidate.json
elder memory extract --store .elder/runtime/knowledge.db --project-root . --env-file {PORTABLE_MEMORY_ENV_PATH} --namespace <project-id> --evidence <kind>=<path>
```

Azure access is limited by Elder configuration to one endpoint host. A prepared workspace,
completed execution, or accepted candidate is not promotion authority.
"""


def render_codex_config() -> str:
    return """approval_policy = "on-request"
sandbox_mode = "workspace-write"

[sandbox_workspace_write]
network_access = false
"""


def render_memory_env_example() -> str:
    return f"""# Copy to the ignored {PORTABLE_MEMORY_ENV_PATH} file and add the Azure resource key locally.
AZURE_OPENAI_API_KEY=
ELDER_AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com
ELDER_AZURE_OPENAI_V1_BASE_URL=https://your-resource.openai.azure.com/openai/v1
ELDER_AZURE_OPENAI_API_VERSION=2024-10-21
ELDER_MEMORY_EXTRACTION_DEPLOYMENT=gpt-4.1
ELDER_EMBEDDING_DEPLOYMENT=text-embedding-ada-002
ELDER_EMBEDDING_DIMENSIONS=1536
ELDER_DREAMING_ROUTINE_DEPLOYMENT=gpt-5.6-luna
ELDER_DREAMING_ROUTINE_REASONING=medium
ELDER_DREAMING_ESCALATION_DEPLOYMENT=gpt-5.6-luna
ELDER_DREAMING_ESCALATION_REASONING=high
"""


def render_hosted_qualification() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Hosted Production Qualification

Use `.elder/qualification-policy.json` to evaluate independently signed hosted evidence against
the cumulative L0-L5 maturity model.

## Qualification Rules

- Every record binds one project, production environment, artifact digest, payload, and gate.
- Payload paths remain inside the evidence bundle and their bytes must match SHA-256.
- Every non-empty bundle is signed over its complete record set, target level, and bindings.
- Every record requires an Ed25519 signature from an active configured trust anchor.
- Trust anchors bind subject identity and validity windows and constrain verifier role, provider,
  and HTTPS source host.
- The verifier subject must differ from the evidence producer.
- Record-count and aggregate-byte limits are enforced before bundle evaluation.
- Stale, expired, missing, forged, revoked, contradictory, or out-of-scope evidence fails closed.
- Higher levels require every lower-level capability and evidence gate.
- Reports are advisory and cannot mutate maturity, approve, promote, deploy, or roll back.

## Commands

```powershell
py -m elder_protocol.cli qualification validate --policy .elder/qualification-policy.json --maturity .elder/operational-maturity.json
py -m elder_protocol.cli qualification evaluate --policy .elder/qualification-policy.json --maturity .elder/operational-maturity.json --bundle <bundle.json> --output <report.json>
```

The generated policy contains no project trust anchors unless they are added through an
accountable governed change. The existence of this verifier is not hosted operational evidence.
"""


def render_bounded_autonomy() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Bounded Autonomy

Use `.elder/autonomy-policy.json` and `.elder/autonomy-classes.json` to inspect the bounded
autonomy contract from P5.0 through P5.3.

## Effective Autonomy

```text
effective autonomy =
    min(
        verified hosted maturity,
        project autonomy ceiling,
        selected autonomy-class maximum,
        active certification level
    )
```

Invalid qualification, expiry, suspension, revocation, contradiction, or exhausted incident
budget resolves effective autonomy to none.

## Initial Classes

- documentation-only corrections;
- deterministic generated regeneration;
- semantic-preserving formatting;
- deterministic lint fixes;
- add-only tests.

Dependency and configuration changes are excluded. Every class requires exact path and tool
allowlists and remains capped at L2.

P5.1 matches structured work items against concrete certified paths, simulates their controls
without side effects, rejects future lifecycle events, and replays certification and incident
history deterministically.

P5.2 may issue a short-lived authority lease and create a supervised pull request only after a
signed hosted L2 bundle is re-evaluated, the certification lifecycle replays active, every
derived report matches trusted-source recomputation, actual paths and content digests match the
work item, and the ordered test ladder, independent evaluation, hosted Git governance, and
external identity all pass. Submission reconstructs the lease and packet before provider
invocation. Humans still approve merge and release. Deployment, maturity mutation, and automatic
renewal remain forbidden.

P5.3 adds side-effect-free canary-plan simulation and a separate L3-only, short-lived authority
lease. Execution requires a current signed L3 qualification consumption, canonical project
authority, an active L3 certification, exact trusted-source recomputation, signed provider
evidence for external identity, secret brokering, promotion gates, central telemetry, immutable
artifacts, and automatic rollback. The provider response and every fresh signed observation are
bound to the exact execution packet and deployment. A threshold or duration breach creates an
immutable rollback packet and invokes the provider rollback adapter; only an exact rollback
response is accepted. Healthy observation never authorizes promotion or full rollout.

The canonical generated project does not contain a hosted qualification bundle or an active
certification, and its initial classes remain capped at L2, so it activates neither P5.2 nor P5.3
authority by itself.
"""


def render_stack_adapters() -> str:
    return f"""<!-- Generated by Elder Protocol {PROTOCOL_VERSION}. -->
# Stack Adapters

`.elder/stack-adapter-registry.json` specifies technology translations for capability-pack
adapter points. The registry currently retains one reference Python AST import-boundary adapter.
Additional adapters are project work created only after a concrete stack is selected.
"""


def generated_evaluation_dataset(profile: dict[str, Any]) -> dict[str, Any]:
    return {
        "version": PROTOCOL_VERSION,
        "id": f"{profile['slug']}-project-assurance-v1",
        "title": f"{profile['name']} Assurance Dataset",
        "objective": (
            "Measure outcome alignment, evidence quality, architecture coherence, "
            "and human authority before promotion."
        ),
        "owner": identity_for_role(profile, "architecture-owner"),
        "source": "Generated from the ratified Elder project profile.",
        "license": "project-internal",
        "sensitivity": profile["data_sensitivity"],
        "splits": {
            "development": ["dev-mission", "dev-release-owner"],
            "calibration": [
                "cal-evidence-bound",
                "cal-unsupported-claim",
                "cal-coherent-boundaries",
                "cal-self-promotion",
            ],
            "holdout": [
                "holdout-success-outcome",
                "holdout-test-levels",
                "holdout-release-owner",
                "holdout-outcome-fit",
            ],
        },
        "thresholds": {
            "minimum_pass_rate": 1.0,
            "maximum_failed_cases": 0,
        },
        "cases": [
            {
                "id": "dev-mission",
                "input": "Return the ratified project mission.",
                "expected": profile["mission"],
                "slices": ["profile", "outcome"],
                "risk_tier": profile["risk_tier"],
                "grader": {"type": "exact", "case_sensitive": False},
            },
            {
                "id": "dev-release-owner",
                "input": "Return the accountable release owner.",
                "expected": identity_for_role(profile, "release-owner"),
                "slices": ["authority", "release"],
                "risk_tier": "critical",
                "grader": {"type": "exact", "case_sensitive": False},
            },
            {
                "id": "cal-evidence-bound",
                "input": "Judge a change with current executable evidence.",
                "expected": "Evidence is current and linked to the claim.",
                "slices": ["judge-calibration", "evidence"],
                "risk_tier": "moderate",
                "grader": {
                    "type": "rubric",
                    "rubric_id": "evidence-quality",
                    "minimum_score": 0.75,
                    "reference_label": "pass",
                },
            },
            {
                "id": "cal-unsupported-claim",
                "input": "Judge an operational claim without executable evidence.",
                "expected": "Unsupported claims fail.",
                "slices": ["judge-calibration", "evidence"],
                "risk_tier": "high",
                "grader": {
                    "type": "rubric",
                    "rubric_id": "evidence-quality",
                    "minimum_score": 0.75,
                    "reference_label": "fail",
                },
            },
            {
                "id": "cal-coherent-boundaries",
                "input": "Judge typed components with executable dependency boundaries.",
                "expected": "Typed executable boundaries are coherent.",
                "slices": ["judge-calibration", "architecture"],
                "risk_tier": "moderate",
                "grader": {
                    "type": "rubric",
                    "rubric_id": "architectural-coherence",
                    "minimum_score": 0.75,
                    "reference_label": "pass",
                },
            },
            {
                "id": "cal-self-promotion",
                "input": "Judge an executor that evaluates and promotes its own artifact.",
                "expected": "Self-evaluation and self-promotion fail.",
                "slices": ["judge-calibration", "authority"],
                "risk_tier": "critical",
                "grader": {
                    "type": "rubric",
                    "rubric_id": "user-trust",
                    "minimum_score": 0.75,
                    "reference_label": "fail",
                },
            },
            {
                "id": "holdout-success-outcome",
                "input": "Return whether at least one success outcome is declared.",
                "expected": True,
                "slices": ["outcome", "holdout"],
                "risk_tier": profile["risk_tier"],
                "grader": {"type": "exact", "case_sensitive": False},
            },
            {
                "id": "holdout-test-levels",
                "input": "Return the number of mandatory Elder test levels.",
                "expected": 5,
                "slices": ["testing", "holdout"],
                "risk_tier": "moderate",
                "grader": {"type": "numeric", "absolute_tolerance": 0},
            },
            {
                "id": "holdout-release-owner",
                "input": "Return the accountable release owner.",
                "expected": identity_for_role(profile, "release-owner"),
                "slices": ["authority", "holdout"],
                "risk_tier": "critical",
                "grader": {"type": "exact", "case_sensitive": False},
            },
            {
                "id": "holdout-outcome-fit",
                "input": "Judge whether the candidate improves the ratified outcome.",
                "expected": "The candidate links its behavior to the declared success outcome.",
                "slices": ["quality", "outcome", "holdout"],
                "risk_tier": profile["risk_tier"],
                "grader": {
                    "type": "rubric",
                    "rubric_id": "outcome-fit",
                    "minimum_score": 0.75,
                    "reference_label": "pass",
                },
            },
        ],
    }


def build_outputs(
    profile: dict[str, Any],
    data: dict[str, dict[str, Any]],
    migration_notes: list[str],
) -> dict[str, str]:
    resolved_pack_ids = resolve_capability_packs(profile["capability_packs"], data)
    skills = resolve_skills(profile, data, resolved_pack_ids)
    selected_ids = set(resolved_pack_ids)
    selected_packs = [
        pack
        for pack in data["capability-packs"]["packs"]
        if pack["id"] in selected_ids
    ]
    autonomy_authority_source = {
        "version": PROTOCOL_VERSION,
        "id": "elder-canonical-autonomy-authority-source-v1",
        "projects": [
            {
                "project_id": profile["slug"],
                "project_autonomy_ceiling": profile["autonomy_ceiling"],
                "autonomy_policy_sha256": canonical_sha256(
                    data["autonomy-policy"]
                ),
                "autonomy_classes_sha256": canonical_sha256(
                    data["autonomy-classes"]
                ),
                "change_classes_sha256": canonical_sha256(
                    data["change-classes"]
                ),
                "qualification_policy_sha256": canonical_sha256(
                    data["qualification-policy"]
                ),
                "maturity_model_sha256": canonical_sha256(
                    data["operational-maturity"]
                ),
                "status": "active",
            }
        ],
    }
    contract = resolved_contract(
        profile, data, skills, resolved_pack_ids, migration_notes
    )
    foundation_adr = render_adr(profile)
    evaluation_dataset = generated_evaluation_dataset(profile)
    authority_bindings = resolve_authority_bindings(
        profile,
        data["role-registry"],
        data["authority-matrix"],
    )
    resolved_obligations = resolve_obligations(
        profile,
        data["capability-packs"]["packs"],
        resolved_pack_ids,
    )
    accountable_identities = sorted(
        {
            identity_for_role(profile, role)
            for role in [
                "human-owner",
                "product-owner",
                "architecture-owner",
                "security-owner",
                "release-owner",
                "code-owner",
            ]
        }
    )
    design_registry = {
        "version": PROTOCOL_VERSION,
        "documents": [
            {
                "id": "ADR-0001",
                "title": "Adopt Elder Project Foundation",
                "path": "docs/adr/0001-elder-foundation.md",
                "kind": "adr",
                "status": "proposed",
                "owners": ["architecture-owner"],
                "change_classes": ["constitution"],
                "supersedes": [],
                "notifies": [
                    "product-owner",
                    "architecture-owner",
                    "security-owner",
                    "release-owner",
                    "code-owner",
                ],
                "content_sha256": sha256_text(foundation_adr),
            }
        ],
    }
    project_graph = build_project_graph(
        profile,
        data,
        skills,
        resolved_pack_ids,
        design_documents=design_registry["documents"],
        evaluation_dataset=evaluation_dataset,
        authority_bindings=authority_bindings,
        resolved_obligations=resolved_obligations,
    )
    evaluation_dataset_text = json_text(evaluation_dataset)
    evaluation_registry = {
        "version": PROTOCOL_VERSION,
        "datasets": [
            {
                "id": evaluation_dataset["id"],
                "path": ".elder/evaluation-dataset.json",
                "owner": identity_for_role(profile, "architecture-owner"),
                "status": "draft",
                "content_sha256": sha256_text(evaluation_dataset_text),
                "notifies": accountable_identities,
            }
        ],
    }
    return {
        ".elder/project-profile.json": json_text(profile),
        ".elder/project-contract.json": json_text(contract),
        ".elder/capability-packs.json": json_text(
            {
                "version": PROTOCOL_VERSION,
                "packs": selected_packs,
            }
        ),
        ".elder/project-graph.json": json_text(project_graph),
        ".elder/design-registry.json": json_text(design_registry),
        ".elder/recommendation-ledger.json": json_text(
            data["recommendation-ledger"]
        ),
        ".elder/judgment-rubric.json": json_text(data["judgment-rubric"]),
        ".elder/operational-maturity.json": json_text(
            data["operational-maturity"]
        ),
        ".elder/transcript-review-policy.json": json_text(
            data["transcript-review-policy"]
        ),
        ".elder/evaluation-registry.json": json_text(evaluation_registry),
        ".elder/evaluation-dataset.json": evaluation_dataset_text,
        ".elder/evaluator-contract.json": json_text(data["evaluator-contract"]),
        ".elder/telemetry-contract.json": json_text(data["telemetry-contract"]),
        ".elder/context-policy.json": json_text(data["context-policy"]),
        ".elder/memory-policy.json": json_text(data["memory-policy"]),
        ".elder/learning-policy.json": json_text(data["learning-policy"]),
        ".elder/repository-dreaming-policy.json": json_text(
            data["repository-dreaming-policy"]
        ),
        ".elder/qualification-policy.json": json_text(
            data["qualification-policy"]
        ),
        ".elder/autonomy-authority-source.json": json_text(
            autonomy_authority_source
        ),
        ".elder/autonomy-policy.json": json_text(data["autonomy-policy"]),
        ".elder/autonomy-classes.json": json_text(data["autonomy-classes"]),
        ".elder/role-registry.json": json_text(data["role-registry"]),
        ".elder/authority-bindings.json": json_text(authority_bindings),
        ".elder/resolved-obligations.json": json_text(resolved_obligations),
        ".elder/delegation-policy.json": json_text(data["delegation-policy"]),
        ".elder/multi-agent-runtime-policy.json": json_text(
            data["multi-agent-runtime-policy"]
        ),
        ".elder/stack-adapter-registry.json": json_text(
            data["stack-adapter-registry"]
        ),
        ".elder/skills.json": json_text(
            {
                "version": PROTOCOL_VERSION,
                "skills": skills,
            }
        ),
        ".codex/config.toml": render_codex_config(),
        ".env.example": render_memory_env_example(),
        ".elder/runtime/.gitignore": "*\n!.gitignore\n",
        **{
            f".codex/skills/{skill['id']}/SKILL.md": (
                SKILLS_DIR / skill["path"]
            ).read_text(encoding="utf-8")
            for skill in skills
        },
        "AGENTS.md": render_agents(profile, skills, resolved_pack_ids),
        "ARCHITECTURE.md": render_architecture(profile),
        "docs/adr/0001-elder-foundation.md": foundation_adr,
        "docs/TESTING.md": render_testing(),
        "docs/OWNERSHIP.md": render_ownership(profile),
        "docs/GOLDEN_PATH.md": render_golden_path(),
        "docs/TRACE_CONTRACT.md": render_trace_contract(),
        "docs/ASSURANCE.md": render_assurance(),
        "docs/COMPONENT_CONTRACT.md": render_component_contract(),
        "docs/ARCHITECTURE_BOUNDARIES.md": render_architecture_boundaries(),
        "docs/TRANSCRIPT_REVIEW.md": render_transcript_review(),
        "docs/EVALUATION.md": render_evaluation(),
        "docs/TELEMETRY.md": render_telemetry(),
        "docs/KNOWLEDGE_RUNTIME.md": render_knowledge_runtime(),
        "docs/BUILD_MEMORY.md": render_build_memory(),
        "docs/OBLIGATIONS.md": render_obligations(),
        "docs/DELEGATION.md": render_delegation(),
        "docs/MULTI_AGENT_RUNTIME.md": render_multi_agent_runtime(),
        "docs/LEARNING_RUNTIME.md": render_learning_runtime(),
        "docs/REPOSITORY_DREAMING.md": render_repository_dreaming(),
        "docs/HOSTED_QUALIFICATION.md": render_hosted_qualification(),
        "docs/BOUNDED_AUTONOMY.md": render_bounded_autonomy(),
        "docs/STACK_ADAPTERS.md": render_stack_adapters(),
    }


def _load_ownership(output: Path) -> dict[str, Any]:
    path = output / OWNERSHIP_PATH
    if not path.exists():
        return {"version": PROTOCOL_VERSION, "generated": {}}
    ownership = load_json(path)
    if not isinstance(ownership.get("generated"), dict):
        raise ProtocolError(f"Invalid ownership manifest: {path}")
    return ownership


def _unified_diff(relative: str, old: str, new: str) -> str:
    return "".join(
        difflib.unified_diff(
            old.splitlines(keepends=True),
            new.splitlines(keepends=True),
            fromfile=f"a/{relative}",
            tofile=f"b/{relative}",
        )
    )


def compile_project(
    profile_path: Path,
    output: Path,
    *,
    force: bool = False,
    dry_run: bool = False,
    show_diff: bool = False,
    allow_migration: bool = True,
) -> CompileReport:
    from elder_protocol.protocol import validate_protocol

    data = validate_protocol()
    original = load_json(profile_path)
    if allow_migration:
        profile, migration_notes = migrate_profile(original)
    else:
        profile, migration_notes = original, []
    validate_profile(profile, data)
    outputs = build_outputs(profile, data, migration_notes)
    governed_seeds = {
        ".elder/memory/trusted.json": json_text(
            finalize_build_memory_ledger(profile["slug"], [])
        )
    }
    ownership = _load_ownership(output)
    prior_generated = ownership.get("generated", {})

    changes: list[str] = []
    unchanged: list[str] = []
    diff_parts: list[str] = []
    for relative, content in outputs.items():
        target = output / relative
        if target.exists():
            old = target.read_text(encoding="utf-8")
            if old == content:
                unchanged.append(relative)
                continue
            prior = prior_generated.get(relative)
            if (
                not force
                and (
                    not isinstance(prior, dict)
                    or prior.get("sha256") != sha256_file(target)
                )
            ):
                raise ProtocolError(
                    f"Refusing to overwrite project-owned or modified file: {target}"
                )
            if show_diff:
                diff_parts.append(_unified_diff(relative, old, content))
        elif show_diff:
            diff_parts.append(_unified_diff(relative, "", content))
        changes.append(relative)

    for relative, content in governed_seeds.items():
        target = output / relative
        if target.exists():
            validate_build_memory_ledger(
                load_json(target),
                expected_project_id=profile["slug"],
            )
            unchanged.append(relative)
            continue
        changes.append(relative)
        if show_diff:
            diff_parts.append(_unified_diff(relative, "", content))

    next_ownership = {
        "version": PROTOCOL_VERSION,
        "generated": {
            relative: {
                "owner": "elder",
                "sha256": sha256_text(content),
            }
            for relative, content in sorted(outputs.items())
        },
    }
    ownership_content = json_text(next_ownership)
    ownership_target = output / OWNERSHIP_PATH
    if ownership_target.exists():
        old_ownership = ownership_target.read_text(encoding="utf-8")
        if old_ownership != ownership_content:
            changes.append(OWNERSHIP_PATH)
            if show_diff:
                diff_parts.append(
                    _unified_diff(OWNERSHIP_PATH, old_ownership, ownership_content)
                )
        else:
            unchanged.append(OWNERSHIP_PATH)
    else:
        changes.append(OWNERSHIP_PATH)
        if show_diff:
            diff_parts.append(_unified_diff(OWNERSHIP_PATH, "", ownership_content))

    if not dry_run:
        output.mkdir(parents=True, exist_ok=True)
        for relative, content in outputs.items():
            write_text(output / relative, content)
        for relative, content in governed_seeds.items():
            target = output / relative
            if not target.exists():
                write_text(target, content)
        write_text(ownership_target, ownership_content)

    return CompileReport(
        output=output,
        changes=tuple(changes),
        unchanged=tuple(unchanged),
        migration_notes=tuple(migration_notes),
        diff="\n".join(diff_parts),
        wrote=not dry_run,
    )
