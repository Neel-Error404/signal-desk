from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

from elder_protocol.constants import PROTOCOL_DIR, PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.governance import validate_context_delegation
from elder_protocol.io import load_json


STORE_SCHEMA_VERSION = 1
AUTHORITY_ORDER = {
    "primary": 0,
    "secondary": 1,
    "historical": 2,
    "candidate": 3,
}
CONFIDENCE_ORDER = {"high": 0, "medium": 1, "low": 2}
MEMORY_ACTION_TARGETS = {
    "promote": "trusted",
    "reject": "rejected",
    "supersede": "superseded",
    "revoke": "revoked",
}
TOKEN_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:/-]*")


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _parse_datetime(value: Any, label: str, *, allow_none: bool = False) -> datetime | None:
    if value is None and allow_none:
        return None
    if not isinstance(value, str) or not value:
        raise ProtocolError(f"{label} must be an ISO 8601 date-time.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO 8601 date-time.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


def _canonical_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=True, separators=(",", ":"), sort_keys=True)


def _sha256_text(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _content_digest(data: dict[str, Any], digest_field: str) -> str:
    unsigned = {key: value for key, value in data.items() if key != digest_field}
    return _sha256_text(_canonical_json(unsigned))


def _require_exact_fields(
    data: dict[str, Any],
    required: set[str],
    optional: set[str],
    label: str,
) -> None:
    missing = required - set(data)
    unknown = set(data) - required - optional
    if missing:
        raise ProtocolError(f"{label} is missing fields: {sorted(missing)}")
    if unknown:
        raise ProtocolError(f"{label} has unknown fields: {sorted(unknown)}")


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value.strip()


def _require_string_list(value: Any, label: str, *, non_empty: bool = False) -> list[str]:
    if not isinstance(value, list):
        raise ProtocolError(f"{label} must be a list.")
    if non_empty and not value:
        raise ProtocolError(f"{label} must not be empty.")
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise ProtocolError(f"{label} must contain non-empty strings.")
    return [item.strip() for item in value]


def validate_context_policy(
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    policy = policy or load_json(PROTOCOL_DIR / "context-policy.json")
    expected = {
        "version",
        "id",
        "authority_order",
        "allowed_authorities",
        "allowed_memory_statuses",
        "allowed_graph_statuses",
        "budgets",
        "freshness",
        "assembly",
        "authority",
    }
    if set(policy) != expected:
        raise ProtocolError(f"Context policy fields must be exactly: {sorted(expected)}")
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Context policy version must be {PROTOCOL_VERSION}.")
    if policy["authority_order"] != [
        "primary",
        "secondary",
        "historical",
        "candidate",
    ]:
        raise ProtocolError("Context authority order must be primary through candidate.")
    if set(policy["allowed_authorities"]) - set(AUTHORITY_ORDER):
        raise ProtocolError("Context policy contains an unknown authority.")
    if policy["allowed_memory_statuses"] != ["trusted"]:
        raise ProtocolError("Context assembly must default to trusted memory only.")
    if policy["allowed_graph_statuses"] != ["active"]:
        raise ProtocolError("Context assembly must default to active graph nodes only.")
    budgets = policy["budgets"]
    if set(budgets) != {
        "default_token_budget",
        "maximum_sources",
        "maximum_source_characters",
    }:
        raise ProtocolError("Context policy budgets are incomplete.")
    if any(not isinstance(budgets[key], int) or budgets[key] < 1 for key in budgets):
        raise ProtocolError("Context policy budgets must be positive integers.")
    assembly = policy["assembly"]
    if assembly != {
        "deterministic_order": "authority-kind-id",
        "deduplicate_by": "content_sha256",
        "budget_behavior": "exclude-optional-fail-required",
        "token_estimate": "ceil-utf8-characters-divided-by-four",
        "graph_selection": "query-matched-only",
        "maximum_graph_sources": 20,
        "allow_wholesale_graph_context": False,
    }:
        raise ProtocolError(
            "Context assembly must use bounded query-matched graph selection."
        )
    if policy["authority"] != {
        "mode": "read-only-assembly",
        "can_expand_authority": False,
        "can_promote_memory": False,
    }:
        raise ProtocolError("Context policy cannot grant mutation or promotion authority.")
    return policy


def validate_memory_policy(
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    policy = policy or load_json(PROTOCOL_DIR / "memory-policy.json")
    expected = {
        "version",
        "id",
        "kinds",
        "states",
        "transitions",
        "candidate_writers",
        "trusted_promoters",
        "retrieval",
        "retention",
        "authority",
    }
    if set(policy) != expected:
        raise ProtocolError(f"Memory policy fields must be exactly: {sorted(expected)}")
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Memory policy version must be {PROTOCOL_VERSION}.")
    if set(policy["kinds"]) != {"episodic", "semantic", "procedural"}:
        raise ProtocolError("Memory policy must define episodic, semantic, and procedural kinds.")
    if set(policy["states"]) != {
        "candidate",
        "trusted",
        "superseded",
        "rejected",
        "revoked",
    }:
        raise ProtocolError("Memory policy states are incomplete.")
    if policy["trusted_promoters"] != ["human-owner"]:
        raise ProtocolError("Only a human-owner may promote trusted memory.")
    if policy["retrieval"]["default_statuses"] != ["trusted"]:
        raise ProtocolError("Default memory retrieval must return trusted records only.")
    if policy["authority"] != {
        "agent_can_self_promote": False,
        "approval_must_be_independent": True,
        "learning_can_modify_trusted": False,
    }:
        raise ProtocolError("Memory authority cannot permit self-promotion or trusted mutation.")
    transitions = {
        (entry.get("from"), entry.get("to"))
        for entry in policy["transitions"]
        if entry.get("requires_approval") is True
    }
    expected_transitions = {
        ("candidate", "trusted"),
        ("candidate", "rejected"),
        ("trusted", "superseded"),
        ("trusted", "revoked"),
    }
    if transitions != expected_transitions:
        raise ProtocolError("Memory policy transitions must match the governed lifecycle.")
    return policy


class KnowledgeStore:
    def __init__(
        self,
        path: Path,
        *,
        context_policy: dict[str, Any] | None = None,
        memory_policy: dict[str, Any] | None = None,
    ):
        self.path = path.resolve()
        self.context_policy = validate_context_policy(context_policy)
        self.memory_policy = validate_memory_policy(memory_policy)

    @contextmanager
    def _connection(self, *, initialize: bool = False) -> Iterator[sqlite3.Connection]:
        if not initialize and not self.path.is_file():
            raise ProtocolError(f"Knowledge store does not exist: {self.path}")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            connection = sqlite3.connect(self.path, timeout=5.0)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA busy_timeout = 5000")
            connection.execute("PRAGMA synchronous = FULL")
            mode = connection.execute("PRAGMA journal_mode = WAL").fetchone()[0]
            if str(mode).lower() != "wal":
                raise ProtocolError("Knowledge store could not enable SQLite WAL mode.")
            if connection.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
                raise ProtocolError("Knowledge store could not enable foreign-key enforcement.")
            yield connection
        except sqlite3.Error as exc:
            raise ProtocolError(f"Knowledge store operation failed at {self.path}: {exc}") from exc
        finally:
            if "connection" in locals():
                connection.close()

    def initialize(self) -> dict[str, Any]:
        with self._connection(initialize=True) as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS nodes (
                    id TEXT PRIMARY KEY,
                    type TEXT NOT NULL,
                    label TEXT NOT NULL,
                    source TEXT NOT NULL,
                    authority TEXT NOT NULL CHECK(authority IN ('primary','secondary','historical','candidate')),
                    status TEXT NOT NULL CHECK(status IN ('active','superseded','revoked')),
                    content TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    attributes_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_nodes_authority_status
                    ON nodes(authority, status);
                CREATE TABLE IF NOT EXISTS edges (
                    id TEXT PRIMARY KEY,
                    type TEXT NOT NULL,
                    from_id TEXT NOT NULL REFERENCES nodes(id),
                    to_id TEXT NOT NULL REFERENCES nodes(id),
                    source TEXT NOT NULL,
                    authority TEXT NOT NULL CHECK(authority IN ('primary','secondary','historical','candidate')),
                    status TEXT NOT NULL CHECK(status IN ('active','superseded','revoked')),
                    evidence_json TEXT NOT NULL,
                    attributes_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_edges_from_status ON edges(from_id, status);
                CREATE INDEX IF NOT EXISTS idx_edges_to_status ON edges(to_id, status);
                CREATE TABLE IF NOT EXISTS memories (
                    id TEXT PRIMARY KEY,
                    namespace TEXT NOT NULL,
                    kind TEXT NOT NULL CHECK(kind IN ('episodic','semantic','procedural')),
                    content TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    source_evidence_json TEXT NOT NULL,
                    confidence TEXT NOT NULL CHECK(confidence IN ('low','medium','high')),
                    owner TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('candidate','trusted','superseded','rejected','revoked')),
                    created_at TEXT NOT NULL,
                    review_at TEXT,
                    expires_at TEXT,
                    supersedes TEXT,
                    approval_id TEXT,
                    approved_by TEXT,
                    approved_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_memories_namespace_status
                    ON memories(namespace, status);
                CREATE TABLE IF NOT EXISTS audit_events (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    id TEXT NOT NULL UNIQUE,
                    event TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    resource TEXT NOT NULL,
                    record_id TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    details_json TEXT NOT NULL
                );
                """
            )
            connection.execute(
                "INSERT OR REPLACE INTO metadata(key, value) VALUES('protocol_version', ?)",
                (PROTOCOL_VERSION,),
            )
            connection.execute(
                "INSERT OR REPLACE INTO metadata(key, value) VALUES('store_schema_version', ?)",
                (str(STORE_SCHEMA_VERSION),),
            )
            connection.execute(f"PRAGMA user_version = {STORE_SCHEMA_VERSION}")
            connection.commit()
            integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
            if integrity != "ok":
                raise ProtocolError(f"Knowledge store integrity check failed: {integrity}")
        return self.status()

    def _require_initialized(self, connection: sqlite3.Connection) -> None:
        try:
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            protocol = connection.execute(
                "SELECT value FROM metadata WHERE key = 'protocol_version'"
            ).fetchone()
        except sqlite3.OperationalError as exc:
            raise ProtocolError(
                f"Knowledge store is not initialized: {self.path}"
            ) from exc
        if version != STORE_SCHEMA_VERSION:
            raise ProtocolError(
                f"Knowledge store schema version is {version}; expected {STORE_SCHEMA_VERSION}."
            )
        if protocol is None or protocol[0] != PROTOCOL_VERSION:
            raise ProtocolError(
                f"Knowledge store protocol version is not {PROTOCOL_VERSION}."
            )

    def status(self) -> dict[str, Any]:
        with self._connection() as connection:
            self._require_initialized(connection)
            integrity = connection.execute("PRAGMA quick_check").fetchone()[0]
            if integrity != "ok":
                raise ProtocolError(f"Knowledge store quick check failed: {integrity}")
            counts = {
                table: connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                for table in ["nodes", "edges", "memories", "audit_events"]
            }
            memory_statuses = {
                row["status"]: row["count"]
                for row in connection.execute(
                    "SELECT status, COUNT(*) AS count FROM memories GROUP BY status"
                )
            }
            return {
                "path": str(self.path),
                "protocol_version": PROTOCOL_VERSION,
                "store_schema_version": STORE_SCHEMA_VERSION,
                "journal_mode": str(
                    connection.execute("PRAGMA journal_mode").fetchone()[0]
                ).lower(),
                "foreign_keys": bool(
                    connection.execute("PRAGMA foreign_keys").fetchone()[0]
                ),
                "integrity": integrity,
                "counts": counts,
                "memory_statuses": dict(sorted(memory_statuses.items())),
                "authority": "local-reference-only",
            }

    def _audit(
        self,
        connection: sqlite3.Connection,
        *,
        event: str,
        subject: str,
        resource: str,
        record_id: str,
        details: dict[str, Any],
        occurred_at: str | None = None,
    ) -> None:
        timestamp = occurred_at or utc_now()
        audit_id = _sha256_text(
            _canonical_json(
                {
                    "event": event,
                    "subject": subject,
                    "resource": resource,
                    "record_id": record_id,
                    "occurred_at": timestamp,
                    "details": details,
                }
            )
        )
        connection.execute(
            """
            INSERT INTO audit_events(
                id, event, subject, resource, record_id, occurred_at, details_json
            ) VALUES(?, ?, ?, ?, ?, ?, ?)
            """,
            (
                audit_id,
                event,
                subject,
                resource,
                record_id,
                timestamp,
                _canonical_json(details),
            ),
        )

    def ingest_graph(
        self,
        graph: dict[str, Any],
        *,
        subject: str = "executor",
    ) -> dict[str, Any]:
        validate_knowledge_graph(graph)
        now = utc_now()
        inserted_nodes = updated_nodes = unchanged_nodes = 0
        inserted_edges = updated_edges = unchanged_edges = 0
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                for node in graph["nodes"]:
                    row = connection.execute(
                        "SELECT * FROM nodes WHERE id = ?", (node["id"],)
                    ).fetchone()
                    values = (
                        node["type"],
                        node["label"],
                        node["source"],
                        node["authority"],
                        node["status"],
                        node["content"],
                        node["content_sha256"],
                        _canonical_json(node["attributes"]),
                    )
                    comparable = values
                    if row is None:
                        connection.execute(
                            """
                            INSERT INTO nodes(
                                id, type, label, source, authority, status, content,
                                content_sha256, attributes_json, created_at, updated_at
                            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (node["id"], *values, now, now),
                        )
                        inserted_nodes += 1
                    else:
                        current = tuple(
                            row[key]
                            for key in [
                                "type",
                                "label",
                                "source",
                                "authority",
                                "status",
                                "content",
                                "content_sha256",
                                "attributes_json",
                            ]
                        )
                        if current == comparable:
                            unchanged_nodes += 1
                        else:
                            connection.execute(
                                """
                                UPDATE nodes SET
                                    type = ?, label = ?, source = ?, authority = ?,
                                    status = ?, content = ?, content_sha256 = ?,
                                    attributes_json = ?, updated_at = ?
                                WHERE id = ?
                                """,
                                (*values, now, node["id"]),
                            )
                            updated_nodes += 1

                for edge in graph["edges"]:
                    row = connection.execute(
                        "SELECT * FROM edges WHERE id = ?", (edge["id"],)
                    ).fetchone()
                    values = (
                        edge["type"],
                        edge["from"],
                        edge["to"],
                        edge["source"],
                        edge["authority"],
                        edge["status"],
                        _canonical_json(edge["evidence"]),
                        _canonical_json(edge["attributes"]),
                    )
                    if row is None:
                        connection.execute(
                            """
                            INSERT INTO edges(
                                id, type, from_id, to_id, source, authority, status,
                                evidence_json, attributes_json, created_at, updated_at
                            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (edge["id"], *values, now, now),
                        )
                        inserted_edges += 1
                    else:
                        current = tuple(
                            row[key]
                            for key in [
                                "type",
                                "from_id",
                                "to_id",
                                "source",
                                "authority",
                                "status",
                                "evidence_json",
                                "attributes_json",
                            ]
                        )
                        if current == values:
                            unchanged_edges += 1
                        else:
                            connection.execute(
                                """
                                UPDATE edges SET
                                    type = ?, from_id = ?, to_id = ?, source = ?,
                                    authority = ?, status = ?, evidence_json = ?,
                                    attributes_json = ?, updated_at = ?
                                WHERE id = ?
                                """,
                                (*values, now, edge["id"]),
                            )
                            updated_edges += 1

                changed = inserted_nodes + updated_nodes + inserted_edges + updated_edges
                if changed:
                    self._audit(
                        connection,
                        event="knowledge-graph-ingested",
                        subject=subject,
                        resource="knowledge-graph",
                        record_id=graph["graph_id"],
                        details={
                            "source_sha256": graph["source_sha256"],
                            "inserted_nodes": inserted_nodes,
                            "updated_nodes": updated_nodes,
                            "inserted_edges": inserted_edges,
                            "updated_edges": updated_edges,
                        },
                    )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return {
            "graph_id": graph["graph_id"],
            "source_sha256": graph["source_sha256"],
            "nodes": {
                "inserted": inserted_nodes,
                "updated": updated_nodes,
                "unchanged": unchanged_nodes,
            },
            "edges": {
                "inserted": inserted_edges,
                "updated": updated_edges,
                "unchanged": unchanged_edges,
            },
        }

    def query_graph(
        self,
        query: str,
        *,
        node_id: str | None = None,
        authorities: list[str] | None = None,
        statuses: list[str] | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        if not isinstance(query, str):
            raise ProtocolError("Knowledge query must be a string.")
        maximum_graph_sources = self.context_policy["assembly"][
            "maximum_graph_sources"
        ]
        if not isinstance(limit, int) or not 1 <= limit <= maximum_graph_sources:
            raise ProtocolError(
                "Knowledge query limit exceeds the context-policy graph maximum."
            )
        authorities = authorities or list(self.context_policy["allowed_authorities"])
        statuses = statuses or list(self.context_policy["allowed_graph_statuses"])
        unknown_authorities = set(authorities) - set(AUTHORITY_ORDER)
        if unknown_authorities:
            raise ProtocolError(
                f"Knowledge query uses unknown authorities: {sorted(unknown_authorities)}"
            )
        unknown_statuses = set(statuses) - {"active", "superseded", "revoked"}
        if unknown_statuses:
            raise ProtocolError(
                f"Knowledge query uses unknown statuses: {sorted(unknown_statuses)}"
            )
        terms = [term.lower() for term in TOKEN_PATTERN.findall(query)]
        if not terms and node_id is None:
            raise ProtocolError(
                "Wholesale graph queries are forbidden; provide query terms or "
                "an exact node_id."
            )
        with self._connection() as connection:
            self._require_initialized(connection)
            placeholders_authority = ",".join("?" for _ in authorities)
            placeholders_status = ",".join("?" for _ in statuses)
            rows = connection.execute(
                f"""
                SELECT * FROM nodes
                WHERE authority IN ({placeholders_authority})
                  AND status IN ({placeholders_status})
                """,
                (*authorities, *statuses),
            ).fetchall()
            edge_rows: list[sqlite3.Row] = []
            if node_id is not None:
                node_id = _require_string(node_id, "node_id")
                edge_rows = connection.execute(
                    f"""
                    SELECT * FROM edges
                    WHERE (from_id = ? OR to_id = ?)
                      AND authority IN ({placeholders_authority})
                      AND status IN ({placeholders_status})
                    ORDER BY type, id
                    LIMIT ?
                    """,
                    (node_id, node_id, *authorities, *statuses, limit),
                ).fetchall()
                neighbor_ids = {
                    value
                    for row in edge_rows
                    for value in (row["from_id"], row["to_id"])
                }
                rows = [row for row in rows if row["id"] in neighbor_ids]

        def score(row: sqlite3.Row) -> tuple[int, int, str]:
            haystack = " ".join(
                [
                    row["id"],
                    row["type"],
                    row["label"],
                    row["content"],
                    row["attributes_json"],
                ]
            ).lower()
            match_score = sum(
                4 if term == row["id"].lower() else 2 if term in row["label"].lower() else 1
                for term in terms
                if term in haystack
            )
            return (-match_score, AUTHORITY_ORDER[row["authority"]], row["id"])

        filtered = rows
        if terms:
            filtered = [row for row in rows if score(row)[0] < 0]
        filtered = sorted(filtered, key=score)[:limit]
        nodes = [self._node_payload(row) for row in filtered]
        edges = [self._edge_payload(row) for row in edge_rows]
        return {
            "query": query,
            "node_id": node_id,
            "authorities": authorities,
            "statuses": statuses,
            "nodes": nodes,
            "edges": edges,
            "count": len(nodes),
        }

    @staticmethod
    def _node_payload(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "type": row["type"],
            "label": row["label"],
            "source": row["source"],
            "authority": row["authority"],
            "status": row["status"],
            "content": row["content"],
            "content_sha256": row["content_sha256"],
            "attributes": json.loads(row["attributes_json"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    @staticmethod
    def _edge_payload(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "type": row["type"],
            "from": row["from_id"],
            "to": row["to_id"],
            "source": row["source"],
            "authority": row["authority"],
            "status": row["status"],
            "evidence": json.loads(row["evidence_json"]),
            "attributes": json.loads(row["attributes_json"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def propose_memory(
        self,
        record: dict[str, Any],
        *,
        subject_role: str,
    ) -> dict[str, Any]:
        prepared = prepare_memory_record(record)
        if subject_role not in self.memory_policy["candidate_writers"]:
            raise ProtocolError(
                f"Subject role '{subject_role}' cannot propose candidate memory."
            )
        if prepared["status"] != "candidate":
            raise ProtocolError("New memory records must start as candidate.")
        if prepared["expires_at"] is None:
            raise ProtocolError("Candidate memory requires expires_at.")
        expires_at = _parse_datetime(prepared["expires_at"], "expires_at")
        created_at = _parse_datetime(prepared["created_at"], "created_at")
        if expires_at <= created_at:
            raise ProtocolError("Candidate memory expires_at must be after created_at.")
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                if connection.execute(
                    "SELECT 1 FROM memories WHERE id = ?", (prepared["id"],)
                ).fetchone():
                    raise ProtocolError(f"Memory record already exists: {prepared['id']}")
                connection.execute(
                    """
                    INSERT INTO memories(
                        id, namespace, kind, content, content_sha256,
                        source_evidence_json, confidence, owner, status, created_at,
                        review_at, expires_at, supersedes, approval_id, approved_by,
                        approved_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        prepared["id"],
                        prepared["namespace"],
                        prepared["kind"],
                        prepared["content"],
                        prepared["content_sha256"],
                        _canonical_json(prepared["source_evidence"]),
                        prepared["confidence"],
                        prepared["owner"],
                        prepared["status"],
                        prepared["created_at"],
                        prepared["review_at"],
                        prepared["expires_at"],
                        prepared["supersedes"],
                        prepared["approval_id"],
                        prepared["approved_by"],
                        prepared["approved_at"],
                    ),
                )
                self._audit(
                    connection,
                    event="memory-proposed",
                    subject=subject_role,
                    resource="candidate-memory",
                    record_id=prepared["id"],
                    occurred_at=prepared["created_at"],
                    details={
                        "namespace": prepared["namespace"],
                        "kind": prepared["kind"],
                        "content_sha256": prepared["content_sha256"],
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return prepared

    def transition_memory(
        self,
        memory_id: str,
        approval: dict[str, Any],
    ) -> dict[str, Any]:
        memory_id = _require_string(memory_id, "memory_id")
        prepared_approval = validate_memory_approval(approval)
        if prepared_approval["memory_id"] != memory_id:
            raise ProtocolError("Memory approval does not match the requested memory id.")
        target = MEMORY_ACTION_TARGETS[prepared_approval["action"]]
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                row = connection.execute(
                    "SELECT * FROM memories WHERE id = ?", (memory_id,)
                ).fetchone()
                if row is None:
                    raise ProtocolError(f"Memory record does not exist: {memory_id}")
                if prepared_approval["approved_by"] == row["owner"]:
                    raise ProtocolError(
                        "Memory approval must be independent from the memory owner."
                    )
                allowed = {
                    ("candidate", "trusted"),
                    ("candidate", "rejected"),
                    ("trusted", "superseded"),
                    ("trusted", "revoked"),
                }
                if (row["status"], target) not in allowed:
                    raise ProtocolError(
                        f"Memory transition {row['status']} -> {target} is not allowed."
                    )
                if target == "trusted":
                    if row["review_at"] is None:
                        raise ProtocolError("Trusted memory promotion requires review_at.")
                    review_at = _parse_datetime(row["review_at"], "review_at")
                    approved_at = _parse_datetime(
                        prepared_approval["approved_at"], "approved_at"
                    )
                    if review_at <= approved_at:
                        raise ProtocolError(
                            "Trusted memory review_at must be after approved_at."
                        )
                connection.execute(
                    """
                    UPDATE memories SET
                        status = ?, approval_id = ?, approved_by = ?, approved_at = ?
                    WHERE id = ?
                    """,
                    (
                        target,
                        prepared_approval["id"],
                        prepared_approval["approved_by"],
                        prepared_approval["approved_at"],
                        memory_id,
                    ),
                )
                self._audit(
                    connection,
                    event=f"memory-{prepared_approval['action']}",
                    subject=prepared_approval["approved_by"],
                    resource="trusted-memory" if target == "trusted" else "candidate-memory",
                    record_id=memory_id,
                    occurred_at=prepared_approval["approved_at"],
                    details={
                        "from": row["status"],
                        "to": target,
                        "approval_id": prepared_approval["id"],
                        "evidence": prepared_approval["evidence"],
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self.get_memory(memory_id)

    def get_memory(self, memory_id: str) -> dict[str, Any]:
        with self._connection() as connection:
            self._require_initialized(connection)
            row = connection.execute(
                "SELECT * FROM memories WHERE id = ?", (memory_id,)
            ).fetchone()
            if row is None:
                raise ProtocolError(f"Memory record does not exist: {memory_id}")
            return self._memory_payload(row)

    def memory_exists(self, memory_id: str) -> bool:
        memory_id = _require_string(memory_id, "memory_id")
        with self._connection() as connection:
            self._require_initialized(connection)
            return (
                connection.execute(
                    "SELECT 1 FROM memories WHERE id = ?",
                    (memory_id,),
                ).fetchone()
                is not None
            )

    def import_governed_memory(self, record: dict[str, Any]) -> dict[str, Any]:
        prepared = prepare_memory_record(record)
        if prepared["status"] not in {"trusted", "superseded", "revoked"}:
            raise ProtocolError(
                "Governed memory import accepts only trusted lifecycle records."
            )
        if (
            prepared["approval_id"] is None
            or prepared["approved_by"] is None
            or prepared["approved_at"] is None
        ):
            raise ProtocolError("Governed memory import requires approval provenance.")
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                connection.execute(
                    """
                    INSERT INTO memories(
                        id, namespace, kind, content, content_sha256,
                        source_evidence_json, confidence, owner, status, created_at,
                        review_at, expires_at, supersedes, approval_id, approved_by,
                        approved_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(id) DO UPDATE SET
                        namespace = excluded.namespace,
                        kind = excluded.kind,
                        content = excluded.content,
                        content_sha256 = excluded.content_sha256,
                        source_evidence_json = excluded.source_evidence_json,
                        confidence = excluded.confidence,
                        owner = excluded.owner,
                        status = excluded.status,
                        created_at = excluded.created_at,
                        review_at = excluded.review_at,
                        expires_at = excluded.expires_at,
                        supersedes = excluded.supersedes,
                        approval_id = excluded.approval_id,
                        approved_by = excluded.approved_by,
                        approved_at = excluded.approved_at
                    """,
                    (
                        prepared["id"],
                        prepared["namespace"],
                        prepared["kind"],
                        prepared["content"],
                        prepared["content_sha256"],
                        _canonical_json(prepared["source_evidence"]),
                        prepared["confidence"],
                        prepared["owner"],
                        prepared["status"],
                        prepared["created_at"],
                        prepared["review_at"],
                        prepared["expires_at"],
                        prepared["supersedes"],
                        prepared["approval_id"],
                        prepared["approved_by"],
                        prepared["approved_at"],
                    ),
                )
                self._audit(
                    connection,
                    event="memory-imported",
                    subject="elder-portable-ledger",
                    resource="trusted-memory",
                    record_id=prepared["id"],
                    occurred_at=utc_now(),
                    details={
                        "namespace": prepared["namespace"],
                        "status": prepared["status"],
                        "content_sha256": prepared["content_sha256"],
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return prepared

    def query_memory(
        self,
        namespace: str,
        query: str,
        *,
        statuses: list[str] | None = None,
        limit: int = 20,
        at: datetime | None = None,
    ) -> dict[str, Any]:
        namespace = _require_string(namespace, "namespace")
        if not isinstance(query, str):
            raise ProtocolError("Memory query must be a string.")
        if not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ProtocolError("Memory query limit must be between 1 and 100.")
        statuses = statuses or list(self.memory_policy["retrieval"]["default_statuses"])
        unknown = set(statuses) - set(self.memory_policy["states"])
        if unknown:
            raise ProtocolError(f"Memory query uses unknown statuses: {sorted(unknown)}")
        now = (at or datetime.now(UTC)).astimezone(UTC)
        placeholders = ",".join("?" for _ in statuses)
        with self._connection() as connection:
            self._require_initialized(connection)
            rows = connection.execute(
                f"""
                SELECT * FROM memories
                WHERE namespace = ? AND status IN ({placeholders})
                """,
                (namespace, *statuses),
            ).fetchall()
        terms = [term.lower() for term in TOKEN_PATTERN.findall(query)]

        def valid(row: sqlite3.Row) -> bool:
            expires = _parse_datetime(row["expires_at"], "expires_at", allow_none=True)
            review = _parse_datetime(row["review_at"], "review_at", allow_none=True)
            if expires is not None and expires <= now:
                return False
            if row["status"] == "trusted" and review is not None and review <= now:
                return False
            haystack = f"{row['id']} {row['kind']} {row['content']}".lower()
            return not terms or any(term in haystack for term in terms)

        def sort_key(row: sqlite3.Row) -> tuple[int, int, str, str]:
            haystack = f"{row['id']} {row['kind']} {row['content']}".lower()
            score = sum(1 for term in terms if term in haystack)
            return (
                -score,
                CONFIDENCE_ORDER[row["confidence"]],
                row["created_at"],
                row["id"],
            )

        selected = sorted((row for row in rows if valid(row)), key=sort_key)[:limit]
        return {
            "namespace": namespace,
            "query": query,
            "statuses": statuses,
            "records": [self._memory_payload(row) for row in selected],
            "count": len(selected),
        }

    @staticmethod
    def _memory_payload(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "version": PROTOCOL_VERSION,
            "id": row["id"],
            "namespace": row["namespace"],
            "kind": row["kind"],
            "content": row["content"],
            "content_sha256": row["content_sha256"],
            "source_evidence": json.loads(row["source_evidence_json"]),
            "confidence": row["confidence"],
            "owner": row["owner"],
            "status": row["status"],
            "created_at": row["created_at"],
            "review_at": row["review_at"],
            "expires_at": row["expires_at"],
            "supersedes": row["supersedes"],
            "approval_id": row["approval_id"],
            "approved_by": row["approved_by"],
            "approved_at": row["approved_at"],
        }

    def assemble_context(
        self,
        request: dict[str, Any],
        *,
        base_dir: Path,
        delegation: dict[str, Any] | None = None,
        parent_run: dict[str, Any] | None = None,
        authority_bindings: dict[str, Any] | None = None,
        delegation_policy: dict[str, Any] | None = None,
        profile: dict[str, Any] | None = None,
        role_registry: dict[str, Any] | None = None,
        authority_matrix: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        prepared = validate_context_request(request)
        delegated_request = prepared.get("delegation_id") is not None
        delegation_inputs = {
            "delegation": delegation,
            "parent_run": parent_run,
            "authority_bindings": authority_bindings,
            "delegation_policy": delegation_policy,
            "profile": profile,
            "role_registry": role_registry,
            "authority_matrix": authority_matrix,
        }
        if delegated_request:
            missing = [
                name for name, value in delegation_inputs.items() if value is None
            ]
            if missing:
                raise ProtocolError(
                    "Delegated context assembly requires validated delegation inputs: "
                    + ", ".join(missing)
                    + "."
                )
        elif any(value is not None for value in delegation_inputs.values()):
            raise ProtocolError(
                "Delegation validation inputs cannot be attached to non-delegated context."
            )
        delegated_scope = (
            validate_context_delegation(
                prepared,
                delegation,
                parent_run,
                authority_bindings,
                delegation_policy,
                profile=profile,
                role_registry=role_registry,
                authority_matrix=authority_matrix,
            )
            if delegated_request
            else []
        )
        if delegated_request and (
            prepared.get("graph_limit", 20) != 0
            or prepared.get("memory_limit", 20) != 0
        ):
            raise ProtocolError(
                "Delegated context requires graph_limit and memory_limit to be zero "
                "until scoped graph and memory provenance is implemented."
            )
        base_root = base_dir.resolve()
        delegated_roots = [
            (base_root / scope).resolve()
            for scope in delegated_scope
        ]
        budget = prepared.get("token_budget") or self.context_policy["budgets"][
            "default_token_budget"
        ]
        maximum_characters = budget * 4
        maximum_source_characters = self.context_policy["budgets"][
            "maximum_source_characters"
        ]
        maximum_sources = self.context_policy["budgets"]["maximum_sources"]
        retrieved_at = utc_now()
        candidates: list[dict[str, Any]] = []
        exclusions: list[dict[str, str]] = []

        for source in prepared["repository_sources"]:
            source_path = Path(source["location"])
            if not source_path.is_absolute():
                source_path = (base_root / source_path).resolve()
            else:
                source_path = source_path.resolve()
            if delegated_roots and not any(
                source_path == root or root in source_path.parents
                for root in delegated_roots
            ):
                raise ProtocolError(
                    f"Context source '{source['id']}' is outside delegated scope."
                )
            if source["authority"] not in self.context_policy["allowed_authorities"]:
                if source["required"]:
                    raise ProtocolError(
                        f"Required source '{source['id']}' has disallowed authority."
                    )
                exclusions.append({"source_id": source["id"], "reason": "authority"})
                continue
            if not source_path.is_file():
                if source["required"]:
                    raise ProtocolError(
                        f"Required context source does not exist: {source_path}"
                    )
                exclusions.append({"source_id": source["id"], "reason": "stale"})
                continue
            max_age = source.get("maximum_age_days")
            if max_age is None:
                max_age = self.context_policy["freshness"]["default_maximum_age_days"]
            if max_age is not None:
                age_seconds = datetime.now(UTC).timestamp() - source_path.stat().st_mtime
                if age_seconds > max_age * 86400:
                    if source["required"]:
                        raise ProtocolError(
                            f"Required context source is stale: {source_path}"
                        )
                    exclusions.append({"source_id": source["id"], "reason": "stale"})
                    continue
            try:
                content = source_path.read_bytes().decode("utf-8")
            except UnicodeDecodeError as exc:
                raise ProtocolError(
                    f"Context source is not valid UTF-8: {source_path}"
                ) from exc
            if not content.strip():
                if source["required"]:
                    raise ProtocolError(f"Required context source is empty: {source_path}")
                exclusions.append({"source_id": source["id"], "reason": "status"})
                continue
            candidates.append(
                {
                    "id": source["id"],
                    "kind": "repository",
                    "location": str(source_path),
                    "authority": source["authority"],
                    "status": "active",
                    "content_sha256": _sha256_text(content),
                    "character_count": len(content),
                    "content": content,
                    "provenance": {
                        "source": str(source_path),
                        "retrieved_at": retrieved_at,
                        "record_id": None,
                    },
                    "_required": source["required"],
                }
            )

        graph_limit = prepared.get("graph_limit", 20)
        if graph_limit:
            if not TOKEN_PATTERN.findall(prepared["query"]):
                raise ProtocolError(
                    "Wholesale graph context is forbidden; graph retrieval requires "
                    "query terms."
                )
            maximum_graph_sources = self.context_policy["assembly"][
                "maximum_graph_sources"
            ]
            if graph_limit > maximum_graph_sources:
                raise ProtocolError(
                    "Wholesale graph context is forbidden; graph_limit exceeds "
                    "the policy maximum."
                )
            graph_results = self.query_graph(
                prepared["query"],
                authorities=list(self.context_policy["allowed_authorities"]),
                statuses=list(self.context_policy["allowed_graph_statuses"]),
                limit=graph_limit,
            )
            for node in graph_results["nodes"]:
                candidates.append(
                    {
                        "id": node["id"],
                        "kind": "knowledge-node",
                        "location": node["source"],
                        "authority": node["authority"],
                        "status": node["status"],
                        "content_sha256": node["content_sha256"],
                        "character_count": len(node["content"]),
                        "content": node["content"],
                        "provenance": {
                            "source": node["source"],
                            "retrieved_at": retrieved_at,
                            "record_id": node["id"],
                        },
                        "_required": False,
                    }
                )

        memory_limit = prepared.get("memory_limit", 20)
        if memory_limit:
            for namespace in prepared["memory_namespaces"]:
                memory_results = self.query_memory(
                    namespace,
                    prepared["query"],
                    statuses=list(self.context_policy["allowed_memory_statuses"]),
                    limit=memory_limit,
                )
                for record in memory_results["records"]:
                    candidates.append(
                        {
                            "id": record["id"],
                            "kind": "memory",
                            "location": f"memory:{record['namespace']}/{record['id']}",
                            "authority": "primary",
                            "status": record["status"],
                            "content_sha256": record["content_sha256"],
                            "character_count": len(record["content"]),
                            "content": record["content"],
                            "provenance": {
                                "source": ",".join(record["source_evidence"]),
                                "retrieved_at": retrieved_at,
                                "record_id": record["id"],
                            },
                            "_required": False,
                        }
                    )

        seen_digests: set[str] = set()
        deduplicated: list[dict[str, Any]] = []
        for candidate in sorted(
            candidates,
            key=lambda item: (
                not item["_required"],
                AUTHORITY_ORDER[item["authority"]],
                item["kind"],
                item["id"],
            ),
        ):
            if candidate["content_sha256"] in seen_digests:
                exclusions.append({"source_id": candidate["id"], "reason": "duplicate"})
                continue
            seen_digests.add(candidate["content_sha256"])
            if candidate["character_count"] > maximum_source_characters:
                if candidate["_required"]:
                    raise ProtocolError(
                        f"Required source '{candidate['id']}' exceeds the per-source context budget."
                    )
                exclusions.append({"source_id": candidate["id"], "reason": "budget"})
                continue
            deduplicated.append(candidate)

        required = [item for item in deduplicated if item["_required"]]
        required_characters = sum(item["character_count"] for item in required)
        if len(required) > maximum_sources or required_characters > maximum_characters:
            raise ProtocolError("Required context sources exceed the declared context budget.")

        selected = list(required)
        selected_ids = {item["id"] for item in selected}
        used_characters = required_characters
        for candidate in deduplicated:
            if candidate["id"] in selected_ids:
                continue
            if (
                len(selected) >= maximum_sources
                or used_characters + candidate["character_count"] > maximum_characters
            ):
                exclusions.append({"source_id": candidate["id"], "reason": "budget"})
                continue
            selected.append(candidate)
            selected_ids.add(candidate["id"])
            used_characters += candidate["character_count"]

        if not selected:
            raise ProtocolError("Context assembly selected no authorized sources.")
        selected.sort(
            key=lambda item: (
                AUTHORITY_ORDER[item["authority"]],
                item["kind"],
                item["id"],
            )
        )
        sources = [
            {key: value for key, value in source.items() if key != "_required"}
            for source in selected
        ]
        packet: dict[str, Any] = {
            "version": PROTOCOL_VERSION,
            "id": prepared["id"],
            "work_item_id": prepared["work_item_id"],
            "project_id": prepared.get("project_id"),
            "delegation_id": prepared.get("delegation_id"),
            "delegation_sha256": (
                delegation["content_sha256"] if delegation is not None else None
            ),
            "agent_identity_id": prepared.get("agent_identity_id"),
            "delegated_scope": delegated_scope,
            "query": prepared["query"],
            "sources": sources,
            "assumptions": prepared.get("assumptions", []),
            "exclusions": sorted(
                exclusions, key=lambda item: (item["source_id"], item["reason"])
            ),
            "token_budget": budget,
            "estimated_tokens": max(1, math.ceil(used_characters / 4)),
            "character_count": used_characters,
            "assembled_by": prepared["assembled_by"],
            "assembled_at": retrieved_at,
            "status": "assembled",
        }
        packet["content_sha256"] = _content_digest(packet, "content_sha256")
        validate_context_packet(
            packet,
            delegation=delegation,
            parent_run=parent_run,
            authority_bindings=authority_bindings,
            delegation_policy=delegation_policy,
            profile=profile,
            role_registry=role_registry,
            authority_matrix=authority_matrix,
            base_dir=base_root,
        )
        return packet


def validate_knowledge_graph(graph: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(graph, dict):
        raise ProtocolError("Knowledge graph must be a JSON object.")
    required = {
        "version",
        "ontology_version",
        "graph_id",
        "generated_at",
        "source_sha256",
        "nodes",
        "edges",
    }
    if set(graph) != required:
        raise ProtocolError(f"Knowledge graph fields must be exactly: {sorted(required)}")
    if graph["version"] != PROTOCOL_VERSION or graph["ontology_version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Knowledge graph versions must be {PROTOCOL_VERSION}.")
    _require_string(graph["graph_id"], "graph_id")
    _parse_datetime(graph["generated_at"], "generated_at")
    expected_digest = _content_digest(graph, "source_sha256")
    if graph["source_sha256"] != expected_digest:
        raise ProtocolError("Knowledge graph source_sha256 does not match its content.")
    if not isinstance(graph["nodes"], list) or not isinstance(graph["edges"], list):
        raise ProtocolError("Knowledge graph nodes and edges must be lists.")
    node_ids: set[str] = set()
    for node in graph["nodes"]:
        if not isinstance(node, dict):
            raise ProtocolError("Knowledge graph node must be an object.")
        _require_exact_fields(
            node,
            {
                "id",
                "type",
                "label",
                "source",
                "authority",
                "status",
                "content",
                "content_sha256",
                "attributes",
            },
            set(),
            "Knowledge graph node",
        )
        node_id = _require_string(node["id"], "Knowledge graph node id")
        if node_id in node_ids:
            raise ProtocolError(f"Duplicate knowledge graph node id: {node_id}")
        node_ids.add(node_id)
        for field in ["type", "label", "source", "content"]:
            _require_string(node[field], f"Knowledge graph node {field}")
        if node["authority"] not in AUTHORITY_ORDER:
            raise ProtocolError(f"Knowledge graph node '{node_id}' has invalid authority.")
        if node["status"] not in {"active", "superseded", "revoked"}:
            raise ProtocolError(f"Knowledge graph node '{node_id}' has invalid status.")
        if node["content_sha256"] != _sha256_text(node["content"]):
            raise ProtocolError(
                f"Knowledge graph node '{node_id}' content digest does not match."
            )
        if not isinstance(node["attributes"], dict):
            raise ProtocolError(f"Knowledge graph node '{node_id}' attributes must be an object.")
    edge_ids: set[str] = set()
    for edge in graph["edges"]:
        if not isinstance(edge, dict):
            raise ProtocolError("Knowledge graph edge must be an object.")
        _require_exact_fields(
            edge,
            {
                "id",
                "type",
                "from",
                "to",
                "source",
                "authority",
                "status",
                "evidence",
                "attributes",
            },
            set(),
            "Knowledge graph edge",
        )
        edge_id = _require_string(edge["id"], "Knowledge graph edge id")
        if edge_id in edge_ids:
            raise ProtocolError(f"Duplicate knowledge graph edge id: {edge_id}")
        edge_ids.add(edge_id)
        if edge["from"] not in node_ids or edge["to"] not in node_ids:
            raise ProtocolError(f"Knowledge graph edge '{edge_id}' has an unknown endpoint.")
        for field in ["type", "source"]:
            _require_string(edge[field], f"Knowledge graph edge {field}")
        if edge["authority"] not in AUTHORITY_ORDER:
            raise ProtocolError(f"Knowledge graph edge '{edge_id}' has invalid authority.")
        if edge["status"] not in {"active", "superseded", "revoked"}:
            raise ProtocolError(f"Knowledge graph edge '{edge_id}' has invalid status.")
        _require_string_list(edge["evidence"], "Knowledge graph edge evidence", non_empty=True)
        if not isinstance(edge["attributes"], dict):
            raise ProtocolError(f"Knowledge graph edge '{edge_id}' attributes must be an object.")
    return graph


def finalize_knowledge_graph(graph: dict[str, Any]) -> dict[str, Any]:
    prepared = dict(graph)
    prepared["version"] = PROTOCOL_VERSION
    prepared["ontology_version"] = PROTOCOL_VERSION
    prepared["source_sha256"] = _content_digest(prepared, "source_sha256")
    return validate_knowledge_graph(prepared)


def prepare_memory_record(record: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(record, dict):
        raise ProtocolError("Memory record must be a JSON object.")
    required = {
        "id",
        "namespace",
        "kind",
        "content",
        "source_evidence",
        "confidence",
        "owner",
        "status",
        "created_at",
        "expires_at",
    }
    optional = {
        "version",
        "content_sha256",
        "review_at",
        "supersedes",
        "approval_id",
        "approved_by",
        "approved_at",
    }
    _require_exact_fields(record, required, optional, "Memory record")
    prepared = dict(record)
    prepared["version"] = PROTOCOL_VERSION
    for field in ["id", "namespace", "content", "owner"]:
        prepared[field] = _require_string(prepared[field], f"Memory {field}")
    if prepared["kind"] not in {"episodic", "semantic", "procedural"}:
        raise ProtocolError("Memory kind must be episodic, semantic, or procedural.")
    if prepared["confidence"] not in {"low", "medium", "high"}:
        raise ProtocolError("Memory confidence must be low, medium, or high.")
    if prepared["status"] not in {
        "candidate",
        "trusted",
        "superseded",
        "rejected",
        "revoked",
    }:
        raise ProtocolError("Memory status is invalid.")
    prepared["source_evidence"] = _require_string_list(
        prepared["source_evidence"], "Memory source_evidence", non_empty=True
    )
    prepared["content_sha256"] = _sha256_text(prepared["content"])
    _parse_datetime(prepared["created_at"], "created_at")
    for field in ["review_at", "expires_at", "approved_at"]:
        prepared.setdefault(field, None)
        _parse_datetime(prepared[field], field, allow_none=True)
    for field in ["supersedes", "approval_id", "approved_by"]:
        prepared.setdefault(field, None)
        if prepared[field] is not None:
            prepared[field] = _require_string(prepared[field], field)
    return prepared


def validate_memory_approval(approval: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(approval, dict):
        raise ProtocolError("Memory approval must be a JSON object.")
    required = {
        "version",
        "id",
        "memory_id",
        "action",
        "approved_by",
        "subject_role",
        "evidence",
        "approved_at",
    }
    _require_exact_fields(approval, required, set(), "Memory approval")
    if approval["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Memory approval version must be {PROTOCOL_VERSION}.")
    prepared = dict(approval)
    for field in ["id", "memory_id", "approved_by"]:
        prepared[field] = _require_string(prepared[field], f"Memory approval {field}")
    if prepared["action"] not in MEMORY_ACTION_TARGETS:
        raise ProtocolError("Memory approval action is invalid.")
    if prepared["subject_role"] != "human-owner":
        raise ProtocolError("Memory approval requires the human-owner subject role.")
    prepared["evidence"] = _require_string_list(
        prepared["evidence"], "Memory approval evidence", non_empty=True
    )
    _parse_datetime(prepared["approved_at"], "approved_at")
    return prepared


def validate_context_request(request: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(request, dict):
        raise ProtocolError("Context request must be a JSON object.")
    required = {
        "id",
        "work_item_id",
        "query",
        "assembled_by",
        "repository_sources",
        "memory_namespaces",
    }
    optional = {
        "token_budget",
        "graph_limit",
        "memory_limit",
        "assumptions",
        "project_id",
        "delegation_id",
        "agent_identity_id",
        "delegated_scope",
    }
    _require_exact_fields(request, required, optional, "Context request")
    prepared = dict(request)
    for field in ["id", "work_item_id", "query", "assembled_by"]:
        prepared[field] = _require_string(prepared[field], f"Context request {field}")
    if not isinstance(prepared["repository_sources"], list):
        raise ProtocolError("Context request repository_sources must be a list.")
    source_ids: set[str] = set()
    sources: list[dict[str, Any]] = []
    for source in prepared["repository_sources"]:
        if not isinstance(source, dict):
            raise ProtocolError("Context repository source must be an object.")
        _require_exact_fields(
            source,
            {"id", "location", "authority", "required"},
            {"maximum_age_days"},
            "Context repository source",
        )
        normalized = dict(source)
        normalized["id"] = _require_string(normalized["id"], "Context source id")
        if normalized["id"] in source_ids:
            raise ProtocolError(f"Duplicate context source id: {normalized['id']}")
        source_ids.add(normalized["id"])
        normalized["location"] = _require_string(
            normalized["location"], "Context source location"
        )
        if normalized["authority"] not in AUTHORITY_ORDER:
            raise ProtocolError(
                f"Context source '{normalized['id']}' has invalid authority."
            )
        if not isinstance(normalized["required"], bool):
            raise ProtocolError("Context source required must be boolean.")
        max_age = normalized.get("maximum_age_days")
        if max_age is not None and (not isinstance(max_age, int) or max_age < 1):
            raise ProtocolError("Context source maximum_age_days must be a positive integer.")
        sources.append(normalized)
    prepared["repository_sources"] = sources
    namespaces = _require_string_list(
        prepared["memory_namespaces"], "Context memory_namespaces"
    )
    if len(namespaces) != len(set(namespaces)):
        raise ProtocolError("Context memory_namespaces must be unique.")
    prepared["memory_namespaces"] = namespaces
    for field, default in [("graph_limit", 20), ("memory_limit", 20)]:
        prepared.setdefault(field, default)
        if not isinstance(prepared[field], int) or not 0 <= prepared[field] <= 100:
            raise ProtocolError(f"Context request {field} must be between 0 and 100.")
    if "token_budget" in prepared and (
        not isinstance(prepared["token_budget"], int) or prepared["token_budget"] < 1
    ):
        raise ProtocolError("Context request token_budget must be a positive integer.")
    prepared.setdefault("assumptions", [])
    prepared["assumptions"] = _require_string_list(
        prepared["assumptions"], "Context assumptions"
    )
    delegated_fields = [
        prepared.get("project_id"),
        prepared.get("delegation_id"),
        prepared.get("agent_identity_id"),
    ]
    if any(value is not None for value in delegated_fields):
        if not all(value is not None for value in delegated_fields):
            raise ProtocolError(
                "Delegated context requires project_id, delegation_id, and agent_identity_id."
            )
        for field in ["project_id", "delegation_id", "agent_identity_id"]:
            prepared[field] = _require_string(
                prepared[field], f"Context request {field}"
            )
        prepared["delegated_scope"] = _require_string_list(
            prepared.get("delegated_scope"),
            "Context delegated_scope",
            non_empty=True,
        )
    elif "delegated_scope" in prepared:
        raise ProtocolError(
            "Context delegated_scope requires delegated task identity fields."
        )
    return prepared


def validate_context_packet(
    packet: dict[str, Any],
    *,
    delegation: dict[str, Any] | None = None,
    parent_run: dict[str, Any] | None = None,
    authority_bindings: dict[str, Any] | None = None,
    delegation_policy: dict[str, Any] | None = None,
    profile: dict[str, Any] | None = None,
    role_registry: dict[str, Any] | None = None,
    authority_matrix: dict[str, Any] | None = None,
    base_dir: Path | None = None,
) -> dict[str, Any]:
    required = {
        "version",
        "id",
        "work_item_id",
        "project_id",
        "delegation_id",
        "delegation_sha256",
        "agent_identity_id",
        "delegated_scope",
        "query",
        "sources",
        "assumptions",
        "exclusions",
        "token_budget",
        "estimated_tokens",
        "character_count",
        "assembled_by",
        "assembled_at",
        "status",
        "content_sha256",
    }
    if set(packet) != required:
        raise ProtocolError(f"Context packet fields must be exactly: {sorted(required)}")
    if packet["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Context packet version must be {PROTOCOL_VERSION}.")
    if packet["status"] != "assembled":
        raise ProtocolError("Context packet status must be assembled.")
    if not packet["sources"]:
        raise ProtocolError("Context packet must contain at least one source.")
    source_fields = {
        "id",
        "kind",
        "location",
        "authority",
        "status",
        "content_sha256",
        "character_count",
        "content",
        "provenance",
    }
    for source in packet["sources"]:
        if not isinstance(source, dict):
            raise ProtocolError("Context packet source must be an object.")
        _require_exact_fields(
            source,
            source_fields,
            set(),
            "Context packet source",
        )
        for field in ["id", "kind", "location"]:
            _require_string(source[field], f"Context packet source {field}")
        if not isinstance(source["content"], str) or not source["content"]:
            raise ProtocolError("Context packet source content must be non-empty.")
        if (
            not isinstance(source["character_count"], int)
            or source["character_count"] != len(source["content"])
        ):
            raise ProtocolError(
                f"Context source '{source['id']}' character_count does not match its content."
            )
        if source["content_sha256"] != _sha256_text(source["content"]):
            raise ProtocolError(
                f"Context source '{source['id']}' content_sha256 does not match its content."
            )
        provenance = source["provenance"]
        _require_exact_fields(
            provenance,
            {"source", "retrieved_at", "record_id"},
            set(),
            "Context packet source provenance",
        )
        _require_string(
            provenance["source"],
            "Context packet source provenance source",
        )
        _parse_datetime(
            provenance["retrieved_at"],
            "Context packet source provenance retrieved_at",
        )
        if provenance["record_id"] is not None:
            _require_string(
                provenance["record_id"],
                "Context packet source provenance record_id",
            )
    if packet["estimated_tokens"] > packet["token_budget"]:
        raise ProtocolError("Context packet exceeds its declared token budget.")
    if packet["content_sha256"] != _content_digest(packet, "content_sha256"):
        raise ProtocolError("Context packet content_sha256 does not match its content.")
    delegated_fields = [
        packet["project_id"],
        packet["delegation_id"],
        packet["agent_identity_id"],
    ]
    delegation_inputs = {
        "delegation": delegation,
        "parent_run": parent_run,
        "authority_bindings": authority_bindings,
        "delegation_policy": delegation_policy,
        "profile": profile,
        "role_registry": role_registry,
        "authority_matrix": authority_matrix,
    }
    if any(value is not None for value in delegated_fields):
        if not all(isinstance(value, str) and value for value in delegated_fields):
            raise ProtocolError(
                "Delegated context packet identity fields must be non-empty strings."
            )
        _require_string_list(
            packet["delegated_scope"],
            "Context packet delegated_scope",
            non_empty=True,
        )
        if (
            not isinstance(packet["delegation_sha256"], str)
            or not re.fullmatch(r"[a-f0-9]{64}", packet["delegation_sha256"])
        ):
            raise ProtocolError(
                "Delegated context packet must bind the delegation SHA-256 digest."
            )
        missing = [
            name for name, value in delegation_inputs.items() if value is None
        ]
        if base_dir is None:
            missing.append("base_dir")
        if missing:
            raise ProtocolError(
                "Delegated context packet validation requires: "
                + ", ".join(missing)
                + "."
            )
        if (
            packet["delegation_id"] != delegation.get("delegation_id")
            or packet["project_id"] != delegation.get("project_id")
            or packet["agent_identity_id"] != delegation.get("assigned_identity_id")
            or packet["work_item_id"] != delegation.get("work_item_id")
            or packet["delegation_sha256"] != delegation.get("content_sha256")
        ):
            raise ProtocolError(
                "Delegated context packet does not match the actual delegation."
            )
        delegated_scope = validate_context_delegation(
            packet,
            delegation,
            parent_run,
            authority_bindings,
            delegation_policy,
            profile=profile,
            role_registry=role_registry,
            authority_matrix=authority_matrix,
        )
        delegated_roots = [
            (base_dir.resolve() / scope).resolve()
            for scope in delegated_scope
        ]
        for source in packet["sources"]:
            if source["kind"] != "repository":
                raise ProtocolError(
                    "Delegated context packets cannot contain unscoped graph or memory sources."
                )
            source_path = Path(source["location"])
            if not source_path.is_absolute():
                source_path = (base_dir.resolve() / source_path).resolve()
            else:
                source_path = source_path.resolve()
            if not any(
                source_path == root or root in source_path.parents
                for root in delegated_roots
            ):
                raise ProtocolError(
                    f"Context source '{source['id']}' is outside delegated scope."
                )
            provenance_path = Path(source["provenance"]["source"])
            if not provenance_path.is_absolute():
                provenance_path = (base_dir.resolve() / provenance_path).resolve()
            else:
                provenance_path = provenance_path.resolve()
            if (
                provenance_path != source_path
                or source["provenance"]["record_id"] is not None
            ):
                raise ProtocolError(
                    f"Context source '{source['id']}' provenance does not match its repository location."
                )
            if not source_path.is_file():
                raise ProtocolError(
                    f"Delegated context source does not exist: {source_path}"
                )
            try:
                current_content = source_path.read_bytes().decode("utf-8")
            except UnicodeDecodeError as exc:
                raise ProtocolError(
                    f"Delegated context source is not valid UTF-8: {source_path}"
                ) from exc
            if current_content != source["content"]:
                raise ProtocolError(
                    f"Context source '{source['id']}' content does not match the repository."
                )
    elif packet["delegated_scope"]:
        raise ProtocolError(
            "Context packet delegated_scope requires delegated identity fields."
        )
    elif packet["delegation_sha256"] is not None:
        raise ProtocolError(
            "Context packet delegation_sha256 requires delegated identity fields."
        )
    elif any(value is not None for value in delegation_inputs.values()):
        raise ProtocolError(
            "Delegation validation inputs cannot be used with a non-delegated context packet."
        )
    _parse_datetime(packet["assembled_at"], "assembled_at")
    return packet


def workbench_run_graph(
    run: dict[str, Any],
    *,
    source: str,
) -> dict[str, Any]:
    if not isinstance(run, dict) or not isinstance(run.get("blueprint"), dict):
        raise ProtocolError("Workbench run must contain a blueprint object.")
    run_id = _require_string(run.get("run_id"), "Workbench run_id")
    blueprint = run["blueprint"]
    objective = _require_string(blueprint.get("objective"), "Workbench objective")
    generated_at = _require_string(run.get("completed_at"), "Workbench completed_at")
    _parse_datetime(generated_at, "Workbench completed_at")

    def node(
        node_id: str,
        node_type: str,
        label: str,
        content: str,
        *,
        attributes: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "id": node_id,
            "type": node_type,
            "label": label,
            "source": source,
            "authority": "primary",
            "status": "active",
            "content": content,
            "content_sha256": _sha256_text(content),
            "attributes": attributes or {},
        }

    nodes = [
        node(
            f"workbench-run:{run_id}",
            "agent-run",
            f"Workbench run {run_id}",
            _canonical_json(
                {
                    "status": run.get("status"),
                    "provider": run.get("provider"),
                    "request": run.get("request"),
                }
            ),
            attributes={
                "trace_id": run.get("trace", {}).get("trace_id"),
                "status": run.get("status"),
            },
        ),
        node(
            f"outcome:{run_id}",
            "outcome",
            objective,
            objective,
            attributes={"run_id": run_id},
        ),
    ]
    edges: list[dict[str, Any]] = []
    run_node_id = f"workbench-run:{run_id}"
    outcome_node_id = f"outcome:{run_id}"
    edges.append(
        {
            "id": f"produces:{run_node_id}->{outcome_node_id}",
            "type": "produces",
            "from": run_node_id,
            "to": outcome_node_id,
            "source": source,
            "authority": "primary",
            "status": "active",
            "evidence": [source],
            "attributes": {"run_id": run_id},
        }
    )
    components = blueprint.get("architecture", {}).get("components", [])
    if not isinstance(components, list):
        raise ProtocolError("Workbench architecture components must be a list.")
    for component in components:
        if not isinstance(component, dict):
            raise ProtocolError("Workbench architecture component must be an object.")
        component_id = _require_string(component.get("id"), "Workbench component id")
        responsibility = _require_string(
            component.get("responsibility"), "Workbench component responsibility"
        )
        graph_component_id = f"component:{run_id}:{component_id}"
        nodes.append(
            node(
                graph_component_id,
                "component",
                component_id,
                responsibility,
                attributes={"run_id": run_id},
            )
        )
        edges.append(
            {
                "id": f"documents:{run_node_id}->{graph_component_id}",
                "type": "documents",
                "from": run_node_id,
                "to": graph_component_id,
                "source": source,
                "authority": "primary",
                "status": "active",
                "evidence": [source],
                "attributes": {"run_id": run_id},
            }
        )
    graph = {
        "version": PROTOCOL_VERSION,
        "ontology_version": PROTOCOL_VERSION,
        "graph_id": f"workbench-run-{run_id}",
        "generated_at": generated_at,
        "source_sha256": "",
        "nodes": nodes,
        "edges": edges,
    }
    return finalize_knowledge_graph(graph)
