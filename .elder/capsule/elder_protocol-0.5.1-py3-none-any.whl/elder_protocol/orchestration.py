from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterator

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.governance import (
    validate_agent_message,
    validate_agent_run_chain,
    validate_bound_checkpoint,
    validate_checkpoint,
    validate_delegation_set,
)
from elder_protocol.knowledge import validate_context_packet
from elder_protocol.orchestration_contracts import (
    _add_budget,
    _budget_leq,
    _canonical_json,
    _parse_datetime,
    _require_string,
    _sha256,
    _zero_budget,
    utc_now,
    validate_agent_action,
    validate_cancellation,
    validate_escalation,
    validate_runtime_lease,
    validate_runtime_policy,
)


RUNTIME_STORE_SCHEMA_VERSION = 2
TERMINAL_RUN_STATUSES = {"complete", "failed", "aborted", "cancelled"}
TERMINAL_DELEGATION_STATUSES = {"completed", "cancelled", "expired", "rejected"}


class MultiAgentRuntime:
    def __init__(self, path: Path, policy: dict[str, Any]):
        self.path = path.resolve()
        self.policy = validate_runtime_policy(policy)

    @contextmanager
    def _connection(self, *, initialize: bool = False) -> Iterator[sqlite3.Connection]:
        if not initialize and not self.path.is_file():
            raise ProtocolError(f"Multi-agent runtime store does not exist: {self.path}")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            connection = sqlite3.connect(self.path, timeout=5.0)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA busy_timeout = 5000")
            connection.execute("PRAGMA synchronous = FULL")
            mode = connection.execute("PRAGMA journal_mode = WAL").fetchone()[0]
            if str(mode).lower() != "wal":
                raise ProtocolError("Multi-agent runtime could not enable SQLite WAL mode.")
            if connection.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
                raise ProtocolError(
                    "Multi-agent runtime could not enable foreign-key enforcement."
                )
            yield connection
        except sqlite3.Error as exc:
            raise ProtocolError(
                f"Multi-agent runtime operation failed at {self.path}: {exc}"
            ) from exc
        finally:
            if "connection" in locals():
                connection.close()

    def initialize(self) -> dict[str, Any]:
        with self._connection(initialize=True) as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS projects (
                    project_id TEXT PRIMARY KEY,
                    profile_json TEXT NOT NULL,
                    authority_bindings_json TEXT NOT NULL,
                    source_profile_sha256 TEXT NOT NULL,
                    source_authority_sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS agent_runs (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(project_id),
                    work_item_id TEXT NOT NULL,
                    identity_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    parent_run_id TEXT REFERENCES agent_runs(id),
                    delegation_id TEXT,
                    artifact_json TEXT NOT NULL,
                    runtime_status TEXT NOT NULL,
                    cancellation_status TEXT NOT NULL,
                    completed_at TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_agent_runs_parent
                    ON agent_runs(parent_run_id);
                CREATE TABLE IF NOT EXISTS delegations (
                    delegation_id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(project_id),
                    parent_run_id TEXT NOT NULL REFERENCES agent_runs(id),
                    child_run_id TEXT NOT NULL UNIQUE REFERENCES agent_runs(id),
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    runtime_status TEXT NOT NULL,
                    submitted_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_delegations_parent
                    ON delegations(parent_run_id);
                CREATE TABLE IF NOT EXISTS context_packets (
                    id TEXT PRIMARY KEY,
                    delegation_id TEXT NOT NULL UNIQUE REFERENCES delegations(delegation_id),
                    content_sha256 TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS leases (
                    id TEXT PRIMARY KEY,
                    delegation_id TEXT NOT NULL REFERENCES delegations(delegation_id),
                    run_id TEXT NOT NULL REFERENCES agent_runs(id),
                    identity_id TEXT NOT NULL,
                    token_sha256 TEXT NOT NULL,
                    claimed_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    released_at TEXT,
                    status TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS idx_active_lease_run
                    ON leases(run_id) WHERE status = 'active';
                CREATE TABLE IF NOT EXISTS actions (
                    id TEXT PRIMARY KEY,
                    delegation_id TEXT NOT NULL REFERENCES delegations(delegation_id),
                    run_id TEXT NOT NULL REFERENCES agent_runs(id),
                    sequence INTEGER NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(run_id, sequence)
                );
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    delegation_id TEXT NOT NULL REFERENCES delegations(delegation_id),
                    child_run_id TEXT NOT NULL REFERENCES agent_runs(id),
                    sequence INTEGER NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(child_run_id, sequence)
                );
                CREATE TABLE IF NOT EXISTS checkpoints (
                    id TEXT PRIMARY KEY,
                    delegation_id TEXT NOT NULL REFERENCES delegations(delegation_id),
                    run_id TEXT NOT NULL REFERENCES agent_runs(id),
                    sequence INTEGER NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    previous_checkpoint_sha256 TEXT,
                    artifact_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(run_id, sequence)
                );
                CREATE TABLE IF NOT EXISTS cancellations (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(project_id),
                    subject_type TEXT NOT NULL,
                    subject_id TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    requested_at TEXT NOT NULL,
                    completed_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS escalations (
                    id TEXT PRIMARY KEY,
                    delegation_id TEXT NOT NULL REFERENCES delegations(delegation_id),
                    run_id TEXT NOT NULL REFERENCES agent_runs(id),
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    raised_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS runtime_events (
                    sequence INTEGER PRIMARY KEY,
                    id TEXT NOT NULL UNIQUE,
                    event_type TEXT NOT NULL,
                    project_id TEXT NOT NULL,
                    delegation_id TEXT,
                    run_id TEXT,
                    occurred_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    previous_event_sha256 TEXT,
                    content_sha256 TEXT NOT NULL
                );
                """
            )
            metadata_count = connection.execute(
                "SELECT COUNT(*) FROM metadata"
            ).fetchone()[0]
            if metadata_count:
                self._require_initialized(connection)
            else:
                connection.execute(
                    "INSERT INTO metadata(key, value) VALUES('protocol_version', ?)",
                    (PROTOCOL_VERSION,),
                )
                connection.execute(
                    "INSERT INTO metadata(key, value) VALUES('store_schema_version', ?)",
                    (str(RUNTIME_STORE_SCHEMA_VERSION),),
                )
                connection.execute(
                    "INSERT INTO metadata(key, value) VALUES('policy_sha256', ?)",
                    (_sha256(self.policy),),
                )
                connection.execute(
                    f"PRAGMA user_version = {RUNTIME_STORE_SCHEMA_VERSION}"
                )
            connection.commit()
            integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
            if integrity != "ok":
                raise ProtocolError(
                    f"Multi-agent runtime integrity check failed: {integrity}"
                )
        return self.status()

    def _require_initialized(self, connection: sqlite3.Connection) -> None:
        try:
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            metadata = {
                row["key"]: row["value"]
                for row in connection.execute("SELECT key, value FROM metadata")
            }
        except sqlite3.OperationalError as exc:
            raise ProtocolError(
                f"Multi-agent runtime store is not initialized: {self.path}"
            ) from exc
        if version != RUNTIME_STORE_SCHEMA_VERSION:
            raise ProtocolError(
                "Multi-agent runtime store schema version is "
                f"{version}; expected {RUNTIME_STORE_SCHEMA_VERSION}."
            )
        if metadata.get("protocol_version") != PROTOCOL_VERSION:
            raise ProtocolError(
                f"Multi-agent runtime protocol version is not {PROTOCOL_VERSION}."
            )
        if metadata.get("policy_sha256") != _sha256(self.policy):
            raise ProtocolError(
                "Multi-agent runtime policy does not match the initialized store."
            )

    def status(self) -> dict[str, Any]:
        with self._connection() as connection:
            self._require_initialized(connection)
            integrity = connection.execute("PRAGMA quick_check").fetchone()[0]
            if integrity != "ok":
                raise ProtocolError(
                    f"Multi-agent runtime quick check failed: {integrity}"
                )
            tables = [
                "projects",
                "agent_runs",
                "delegations",
                "context_packets",
                "leases",
                "actions",
                "messages",
                "checkpoints",
                "cancellations",
                "escalations",
                "runtime_events",
            ]
            counts = {
                table: connection.execute(
                    f"SELECT COUNT(*) FROM {table}"
                ).fetchone()[0]
                for table in tables
            }
            return {
                "path": str(self.path),
                "protocol_version": PROTOCOL_VERSION,
                "store_schema_version": RUNTIME_STORE_SCHEMA_VERSION,
                "policy_id": self.policy["id"],
                "journal_mode": str(
                    connection.execute("PRAGMA journal_mode").fetchone()[0]
                ).lower(),
                "foreign_keys": bool(
                    connection.execute("PRAGMA foreign_keys").fetchone()[0]
                ),
                "integrity": integrity,
                "counts": counts,
                "authority": "local-reference-only",
            }

    def _append_event(
        self,
        connection: sqlite3.Connection,
        *,
        event_type: str,
        project_id: str,
        delegation_id: str | None,
        run_id: str | None,
        occurred_at: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        _parse_datetime(occurred_at, "Runtime event occurred_at")
        prior = connection.execute(
            """
            SELECT sequence, content_sha256
            FROM runtime_events
            ORDER BY sequence DESC
            LIMIT 1
            """
        ).fetchone()
        sequence = 1 if prior is None else int(prior["sequence"]) + 1
        previous = None if prior is None else prior["content_sha256"]
        unsigned = {
            "version": PROTOCOL_VERSION,
            "sequence": sequence,
            "event_type": event_type,
            "project_id": project_id,
            "delegation_id": delegation_id,
            "run_id": run_id,
            "occurred_at": occurred_at,
            "payload": payload,
            "previous_event_sha256": previous,
        }
        digest = _sha256(unsigned)
        event = {
            **unsigned,
            "id": f"runtime-event-{digest[:24]}",
            "content_sha256": digest,
        }
        connection.execute(
            """
            INSERT INTO runtime_events(
                sequence, id, event_type, project_id, delegation_id, run_id,
                occurred_at, payload_json, previous_event_sha256, content_sha256
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                sequence,
                event["id"],
                event_type,
                project_id,
                delegation_id,
                run_id,
                occurred_at,
                _canonical_json(payload),
                previous,
                digest,
            ),
        )
        return event

    @staticmethod
    def _row_artifact(row: sqlite3.Row) -> dict[str, Any]:
        try:
            artifact = json.loads(row["artifact_json"])
        except (json.JSONDecodeError, TypeError) as exc:
            raise ProtocolError("Runtime artifact JSON is invalid.") from exc
        if not isinstance(artifact, dict):
            raise ProtocolError("Runtime artifact JSON must contain an object.")
        return artifact

    def _persisted_lease(self, row: sqlite3.Row) -> dict[str, Any]:
        lease = self._row_artifact(row)
        validate_runtime_lease(lease)
        if (
            lease["id"] != row["id"]
            or lease["delegation_id"] != row["delegation_id"]
            or lease["run_id"] != row["run_id"]
            or lease["identity_id"] != row["identity_id"]
            or lease["token_sha256"] != row["token_sha256"]
            or lease["claimed_at"] != row["claimed_at"]
            or lease["expires_at"] != row["expires_at"]
            or lease["released_at"] != row["released_at"]
            or lease["status"] != row["status"]
            or lease["content_sha256"] != row["content_sha256"]
        ):
            raise ProtocolError("Runtime lease journal row binding is invalid.")
        return lease

    def _transition_lease(
        self,
        connection: sqlite3.Connection,
        row: sqlite3.Row,
        *,
        status: str,
        at: str,
        event_type: str,
    ) -> dict[str, Any]:
        current = self._persisted_lease(row)
        if current["status"] != "active":
            raise ProtocolError("Only an active runtime lease can transition.")
        transitioned = {
            **current,
            "released_at": at,
            "status": status,
        }
        transitioned.pop("content_sha256")
        transitioned["content_sha256"] = _sha256(transitioned)
        validate_runtime_lease(transitioned)
        connection.execute(
            """
            UPDATE leases
            SET released_at = ?, status = ?, artifact_json = ?, content_sha256 = ?
            WHERE id = ? AND status = 'active'
            """,
            (
                at,
                status,
                _canonical_json(transitioned),
                transitioned["content_sha256"],
                transitioned["id"],
            ),
        )
        self._append_event(
            connection,
            event_type=event_type,
            project_id=transitioned["project_id"],
            delegation_id=transitioned["delegation_id"],
            run_id=transitioned["run_id"],
            occurred_at=at,
            payload={"lease": transitioned},
        )
        return transitioned

    def _current_run(self, row: sqlite3.Row) -> dict[str, Any]:
        run = self._row_artifact(row)
        run["status"] = row["runtime_status"]
        run["cancellation_status"] = row["cancellation_status"]
        run["completed_at"] = row["completed_at"]
        return run

    def _current_delegation(self, row: sqlite3.Row) -> dict[str, Any]:
        delegation = self._row_artifact(row)
        delegation["status"] = row["runtime_status"]
        return delegation

    def _project_payloads(
        self,
        connection: sqlite3.Connection,
        project_id: str,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        row = connection.execute(
            "SELECT * FROM projects WHERE project_id = ?",
            (project_id,),
        ).fetchone()
        if row is None:
            raise ProtocolError(f"Runtime project does not exist: {project_id}")
        return json.loads(row["profile_json"]), json.loads(
            row["authority_bindings_json"]
        )

    def submit(
        self,
        *,
        parent_run: dict[str, Any],
        delegation: dict[str, Any],
        child_run: dict[str, Any],
        context_packet: dict[str, Any],
        context_base_dir: Path,
        profile: dict[str, Any],
        authority_bindings: dict[str, Any],
        delegation_policy: dict[str, Any],
        role_registry: dict[str, Any],
        authority_matrix: dict[str, Any],
        submitted_at: str | None = None,
    ) -> dict[str, Any]:
        submitted_at = submitted_at or utc_now()
        submitted_time = _parse_datetime(submitted_at, "Runtime submitted_at")
        validate_agent_run_chain(
            parent_run,
            child_run,
            delegation,
            authority_bindings=authority_bindings,
            policy=delegation_policy,
            profile=profile,
            role_registry=role_registry,
            authority_matrix=authority_matrix,
        )
        validate_context_packet(
            context_packet,
            delegation=delegation,
            parent_run=parent_run,
            authority_bindings=authority_bindings,
            delegation_policy=delegation_policy,
            profile=profile,
            role_registry=role_registry,
            authority_matrix=authority_matrix,
            base_dir=context_base_dir.resolve(),
        )
        if child_run["context_packet_id"] != context_packet["id"]:
            raise ProtocolError(
                "Child run context_packet_id does not match the submitted context packet."
            )
        if delegation["status"] != "active":
            raise ProtocolError("Runtime submission requires an active delegation.")
        if parent_run["status"] != "running" or child_run["status"] != "running":
            raise ProtocolError("Runtime submission requires running parent and child runs.")
        if parent_run["cancellation_status"] != "active" or child_run[
            "cancellation_status"
        ] != "active":
            raise ProtocolError("Runtime submission cannot use cancelled agent runs.")
        if child_run["actions"] or child_run["outputs"]:
            raise ProtocolError(
                "A newly submitted child run cannot contain unjournaled actions or outputs."
            )
        deadline = min(
            _parse_datetime(delegation["deadline"], "Delegation deadline"),
            _parse_datetime(delegation["expires_at"], "Delegation expires_at"),
            _parse_datetime(child_run["deadline"], "Child run deadline"),
        )
        if submitted_time > deadline:
            raise ProtocolError("Runtime submission occurred after the delegated deadline.")
        if submitted_time < _parse_datetime(
            parent_run["started_at"], "Parent run started_at"
        ) or submitted_time < _parse_datetime(
            child_run["started_at"], "Child run started_at"
        ):
            raise ProtocolError(
                "Runtime submission cannot precede the parent or child start time."
            )

        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                project_row = connection.execute(
                    "SELECT * FROM projects WHERE project_id = ?",
                    (delegation["project_id"],),
                ).fetchone()
                profile_digest = _sha256(profile)
                authority_digest = _sha256(authority_bindings)
                if project_row is None:
                    connection.execute(
                        """
                        INSERT INTO projects(
                            project_id, profile_json, authority_bindings_json,
                            source_profile_sha256, source_authority_sha256, created_at
                        ) VALUES(?, ?, ?, ?, ?, ?)
                        """,
                        (
                            delegation["project_id"],
                            _canonical_json(profile),
                            _canonical_json(authority_bindings),
                            profile_digest,
                            authority_digest,
                            submitted_at,
                        ),
                    )
                elif (
                    project_row["source_profile_sha256"] != profile_digest
                    or project_row["source_authority_sha256"] != authority_digest
                ):
                    raise ProtocolError(
                        "Runtime project profile or authority bindings changed after initialization."
                    )

                existing_parent = connection.execute(
                    "SELECT * FROM agent_runs WHERE id = ?",
                    (parent_run["id"],),
                ).fetchone()
                if existing_parent is None:
                    connection.execute(
                        """
                        INSERT INTO agent_runs(
                            id, project_id, work_item_id, identity_id, role,
                            parent_run_id, delegation_id, artifact_json, runtime_status,
                            cancellation_status, completed_at, created_at, updated_at
                        ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            parent_run["id"],
                            parent_run["project_id"],
                            parent_run["work_item_id"],
                            parent_run["identity_id"],
                            parent_run["role"],
                            parent_run["parent_run_id"],
                            parent_run["delegation_id"],
                            _canonical_json(parent_run),
                            parent_run["status"],
                            parent_run["cancellation_status"],
                            parent_run["completed_at"],
                            submitted_at,
                            submitted_at,
                        ),
                    )
                else:
                    current_parent = self._current_run(existing_parent)
                    immutable_parent = dict(parent_run)
                    for field in ("status", "cancellation_status", "completed_at"):
                        immutable_parent[field] = current_parent[field]
                    if immutable_parent != current_parent:
                        raise ProtocolError(
                            "Submitted parent run does not match its persisted runtime identity."
                        )
                    if current_parent["status"] != "running":
                        raise ProtocolError("A non-running parent cannot create delegation.")
                    if current_parent["cancellation_status"] != "active":
                        raise ProtocolError("A cancelled parent cannot create delegation.")

                existing_delegations = [
                    self._current_delegation(row)
                    for row in connection.execute(
                        """
                        SELECT * FROM delegations
                        WHERE parent_run_id = ?
                          AND runtime_status NOT IN ('cancelled','expired','rejected')
                        ORDER BY delegation_id
                        """,
                        (parent_run["id"],),
                    )
                ]
                validate_delegation_set(
                    [*existing_delegations, delegation],
                    parent_run,
                    authority_bindings,
                    delegation_policy,
                    profile=profile,
                    role_registry=role_registry,
                    authority_matrix=authority_matrix,
                )
                if connection.execute(
                    "SELECT 1 FROM delegations WHERE delegation_id = ?",
                    (delegation["delegation_id"],),
                ).fetchone():
                    raise ProtocolError(
                        f"Runtime delegation already exists: {delegation['delegation_id']}"
                    )
                if connection.execute(
                    "SELECT 1 FROM agent_runs WHERE id = ?",
                    (child_run["id"],),
                ).fetchone():
                    raise ProtocolError(
                        f"Runtime child run already exists: {child_run['id']}"
                    )

                connection.execute(
                    """
                    INSERT INTO agent_runs(
                        id, project_id, work_item_id, identity_id, role,
                        parent_run_id, delegation_id, artifact_json, runtime_status,
                        cancellation_status, completed_at, created_at, updated_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        child_run["id"],
                        child_run["project_id"],
                        child_run["work_item_id"],
                        child_run["identity_id"],
                        child_run["role"],
                        child_run["parent_run_id"],
                        child_run["delegation_id"],
                        _canonical_json(child_run),
                        child_run["status"],
                        child_run["cancellation_status"],
                        child_run["completed_at"],
                        submitted_at,
                        submitted_at,
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO delegations(
                        delegation_id, project_id, parent_run_id, child_run_id,
                        artifact_json, content_sha256, runtime_status,
                        submitted_at, updated_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        delegation["delegation_id"],
                        delegation["project_id"],
                        delegation["parent_run_id"],
                        child_run["id"],
                        _canonical_json(delegation),
                        delegation["content_sha256"],
                        delegation["status"],
                        submitted_at,
                        submitted_at,
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO context_packets(
                        id, delegation_id, content_sha256, artifact_json, created_at
                    ) VALUES(?, ?, ?, ?, ?)
                    """,
                    (
                        context_packet["id"],
                        delegation["delegation_id"],
                        context_packet["content_sha256"],
                        _canonical_json(context_packet),
                        submitted_at,
                    ),
                )
                self._append_event(
                    connection,
                    event_type="delegation-submitted",
                    project_id=delegation["project_id"],
                    delegation_id=delegation["delegation_id"],
                    run_id=child_run["id"],
                    occurred_at=submitted_at,
                    payload={
                        "parent_run": parent_run,
                        "delegation": delegation,
                        "child_run": child_run,
                        "context_packet_id": context_packet["id"],
                        "context_packet_sha256": context_packet["content_sha256"],
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self.snapshot(delegation["delegation_id"])

    def _expire_leases(
        self,
        connection: sqlite3.Connection,
        at: datetime,
    ) -> int:
        rows = connection.execute(
            "SELECT * FROM leases WHERE status = 'active' ORDER BY claimed_at, id"
        ).fetchall()
        expired = 0
        for row in rows:
            if _parse_datetime(row["expires_at"], "Lease expires_at") > at:
                continue
            occurred_at = at.isoformat()
            self._transition_lease(
                connection,
                row,
                status="expired",
                at=occurred_at,
                event_type="lease-expired",
            )
            expired += 1
        return expired

    @staticmethod
    def _delegation_project(
        connection: sqlite3.Connection,
        delegation_id: str,
    ) -> str:
        row = connection.execute(
            "SELECT project_id FROM delegations WHERE delegation_id = ?",
            (delegation_id,),
        ).fetchone()
        if row is None:
            raise ProtocolError(f"Runtime delegation does not exist: {delegation_id}")
        return row["project_id"]

    def claim(
        self,
        *,
        project_id: str,
        identity_id: str,
        lease_seconds: int,
        at: str | None = None,
        lease_token: str | None = None,
    ) -> dict[str, Any]:
        project_id = _require_string(project_id, "Claim project_id")
        identity_id = _require_string(identity_id, "Claim identity_id")
        maximum = self.policy["dispatch"]["maximum_lease_seconds"]
        if not isinstance(lease_seconds, int) or not 1 <= lease_seconds <= maximum:
            raise ProtocolError(
                f"Lease seconds must be between 1 and {maximum}."
            )
        claimed_at = at or utc_now()
        claimed_time = _parse_datetime(claimed_at, "Lease claimed_at")
        token = lease_token or f"elder_lease_{secrets.token_urlsafe(32)}"
        if len(token) < 24:
            raise ProtocolError("Lease token must contain at least 24 characters.")

        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                self._expire_leases(connection, claimed_time)
                rows = connection.execute(
                    """
                    SELECT d.*, r.artifact_json AS child_artifact,
                           r.runtime_status AS child_status,
                           r.cancellation_status AS child_cancellation
                    FROM delegations d
                    JOIN agent_runs r ON r.id = d.child_run_id
                    JOIN agent_runs p ON p.id = d.parent_run_id
                    WHERE d.project_id = ?
                      AND d.runtime_status = 'active'
                      AND r.identity_id = ?
                      AND r.runtime_status = 'running'
                      AND r.cancellation_status = 'active'
                      AND p.runtime_status = 'running'
                      AND p.cancellation_status = 'active'
                      AND NOT EXISTS (
                        SELECT 1 FROM leases l
                        WHERE l.run_id = r.id AND l.status = 'active'
                      )
                    ORDER BY d.submitted_at, d.delegation_id
                    """,
                    (project_id, identity_id),
                ).fetchall()
                selected: sqlite3.Row | None = None
                for row in rows:
                    delegation = self._current_delegation(row)
                    child_run = json.loads(row["child_artifact"])
                    eligible_at = max(
                        _parse_datetime(
                            row["submitted_at"], "Delegation submitted_at"
                        ),
                        _parse_datetime(
                            child_run["started_at"], "Child run started_at"
                        ),
                    )
                    if claimed_time < eligible_at:
                        continue
                    deadline = min(
                        _parse_datetime(delegation["deadline"], "Delegation deadline"),
                        _parse_datetime(
                            delegation["expires_at"], "Delegation expires_at"
                        ),
                        _parse_datetime(child_run["deadline"], "Child run deadline"),
                    )
                    if claimed_time <= deadline:
                        selected = row
                        break
                    self._expire_delegation(
                        connection,
                        delegation_id=delegation["delegation_id"],
                        at=claimed_at,
                    )
                if selected is None:
                    raise ProtocolError(
                        f"No claimable delegation exists for identity '{identity_id}'."
                    )
                delegation = self._current_delegation(selected)
                child_run = json.loads(selected["child_artifact"])
                expires = claimed_time + timedelta(seconds=lease_seconds)
                delegated_limit = min(
                    _parse_datetime(delegation["deadline"], "Delegation deadline"),
                    _parse_datetime(delegation["expires_at"], "Delegation expires_at"),
                    _parse_datetime(child_run["deadline"], "Child run deadline"),
                )
                if expires > delegated_limit:
                    expires = delegated_limit
                lease_id = f"lease-{_sha256([delegation['delegation_id'], claimed_at, token])[:24]}"
                lease = {
                    "version": PROTOCOL_VERSION,
                    "id": lease_id,
                    "project_id": project_id,
                    "delegation_id": delegation["delegation_id"],
                    "run_id": child_run["id"],
                    "identity_id": identity_id,
                    "claimed_at": claimed_at,
                    "expires_at": expires.isoformat(),
                    "released_at": None,
                    "status": "active",
                    "token_sha256": hashlib.sha256(token.encode("utf-8")).hexdigest(),
                }
                lease["content_sha256"] = _sha256(lease)
                validate_runtime_lease(lease)
                connection.execute(
                    """
                    INSERT INTO leases(
                        id, delegation_id, run_id, identity_id, token_sha256,
                        claimed_at, expires_at, released_at, status,
                        artifact_json, content_sha256
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, NULL, 'active', ?, ?)
                    """,
                    (
                        lease["id"],
                        lease["delegation_id"],
                        lease["run_id"],
                        lease["identity_id"],
                        lease["token_sha256"],
                        lease["claimed_at"],
                        lease["expires_at"],
                        _canonical_json(lease),
                        lease["content_sha256"],
                    ),
                )
                self._append_event(
                    connection,
                    event_type="lease-claimed",
                    project_id=project_id,
                    delegation_id=delegation["delegation_id"],
                    run_id=child_run["id"],
                    occurred_at=claimed_at,
                    payload={"lease": lease},
                )
                context_row = connection.execute(
                    "SELECT artifact_json FROM context_packets WHERE delegation_id = ?",
                    (delegation["delegation_id"],),
                ).fetchone()
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return {
            "lease": lease,
            "lease_token": token,
            "delegation": delegation,
            "child_run": child_run,
            "context_packet": json.loads(context_row["artifact_json"]),
        }

    def _validate_lease(
        self,
        connection: sqlite3.Connection,
        *,
        run_id: str,
        token: str,
        at: datetime,
    ) -> sqlite3.Row:
        row = connection.execute(
            """
            SELECT * FROM leases
            WHERE run_id = ? AND status = 'active'
            ORDER BY claimed_at DESC
            LIMIT 1
            """,
            (run_id,),
        ).fetchone()
        if row is None:
            raise ProtocolError(f"Child run '{run_id}' has no active lease.")
        if _parse_datetime(row["expires_at"], "Lease expires_at") <= at:
            self._expire_leases(connection, at)
            raise ProtocolError(f"Child run '{run_id}' lease has expired.")
        if at < _parse_datetime(row["claimed_at"], "Lease claimed_at"):
            raise ProtocolError(
                f"Child run '{run_id}' operation predates the active lease."
            )
        token_digest = hashlib.sha256(token.encode("utf-8")).hexdigest()
        if not secrets.compare_digest(token_digest, row["token_sha256"]):
            raise ProtocolError("Lease token does not match the active child-run lease.")
        return row

    def release(
        self,
        *,
        run_id: str,
        lease_token: str,
        at: str | None = None,
    ) -> dict[str, Any]:
        released_at = at or utc_now()
        released_time = _parse_datetime(released_at, "Lease released_at")
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                lease = self._validate_lease(
                    connection,
                    run_id=run_id,
                    token=lease_token,
                    at=released_time,
                )
                self._transition_lease(
                    connection,
                    lease,
                    status="released",
                    at=released_at,
                    event_type="lease-released",
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self.snapshot(lease["delegation_id"])

    def _chain_rows(
        self,
        connection: sqlite3.Connection,
        delegation_id: str,
    ) -> tuple[sqlite3.Row, sqlite3.Row, sqlite3.Row]:
        delegation_row = connection.execute(
            "SELECT * FROM delegations WHERE delegation_id = ?",
            (delegation_id,),
        ).fetchone()
        if delegation_row is None:
            raise ProtocolError(f"Runtime delegation does not exist: {delegation_id}")
        parent_row = connection.execute(
            "SELECT * FROM agent_runs WHERE id = ?",
            (delegation_row["parent_run_id"],),
        ).fetchone()
        child_row = connection.execute(
            "SELECT * FROM agent_runs WHERE id = ?",
            (delegation_row["child_run_id"],),
        ).fetchone()
        if parent_row is None or child_row is None:
            raise ProtocolError("Runtime delegation chain is incomplete.")
        return parent_row, delegation_row, child_row

    def _canonical_chain(
        self,
        connection: sqlite3.Connection,
        delegation_id: str,
        *,
        delegation_policy: dict[str, Any],
        role_registry: dict[str, Any],
        authority_matrix: dict[str, Any],
    ) -> tuple[
        dict[str, Any],
        dict[str, Any],
        dict[str, Any],
        dict[str, Any],
        dict[str, Any],
    ]:
        parent_row, delegation_row, child_row = self._chain_rows(
            connection, delegation_id
        )
        profile, authority_bindings = self._project_payloads(
            connection, delegation_row["project_id"]
        )
        parent = self._current_run(parent_row)
        delegation = self._current_delegation(delegation_row)
        child = self._current_run(child_row)
        # Lifecycle state can become terminal after the immutable contract was validated.
        validation_parent = self._row_artifact(parent_row)
        validation_delegation = self._row_artifact(delegation_row)
        validation_child = self._row_artifact(child_row)
        validate_agent_run_chain(
            validation_parent,
            validation_child,
            validation_delegation,
            authority_bindings=authority_bindings,
            policy=delegation_policy,
            profile=profile,
            role_registry=role_registry,
            authority_matrix=authority_matrix,
        )
        return parent, delegation, child, profile, authority_bindings

    def _require_active_chain(
        self,
        parent: dict[str, Any],
        delegation: dict[str, Any],
        child: dict[str, Any],
        at: datetime,
    ) -> None:
        if parent["status"] != "running":
            raise ProtocolError(f"Parent run '{parent['id']}' is not running.")
        if parent["cancellation_status"] != "active":
            raise ProtocolError(f"Parent run '{parent['id']}' is cancelled.")
        if delegation["status"] != "active":
            raise ProtocolError(
                f"Delegation '{delegation['delegation_id']}' is not active."
            )
        if child["status"] != "running":
            raise ProtocolError(f"Child run '{child['id']}' is not running.")
        if child["cancellation_status"] != "active":
            raise ProtocolError(f"Child run '{child['id']}' is cancelled.")
        deadline = min(
            _parse_datetime(delegation["deadline"], "Delegation deadline"),
            _parse_datetime(delegation["expires_at"], "Delegation expires_at"),
            _parse_datetime(child["deadline"], "Child run deadline"),
        )
        if at > deadline:
            raise ProtocolError("Delegated runtime operation occurred after expiry.")

    @staticmethod
    def _grants(run: dict[str, Any]) -> dict[str, set[str]]:
        return {
            grant["resource"]: set(grant["actions"])
            for grant in run["authority_grants"]
        }

    @classmethod
    def _require_run_authority(
        cls,
        run: dict[str, Any],
        *,
        resource: str,
        action: str,
        label: str,
    ) -> None:
        if action not in cls._grants(run).get(resource, set()):
            raise ProtocolError(
                f"{label} lacks explicit '{action}' authority for '{resource}'."
            )

    def _action_budget_total(
        self,
        connection: sqlite3.Connection,
        run_id: str,
    ) -> dict[str, int | float]:
        total = _zero_budget()
        rows = connection.execute(
            "SELECT artifact_json FROM actions WHERE run_id = ? ORDER BY sequence",
            (run_id,),
        ).fetchall()
        for row in rows:
            action = json.loads(row["artifact_json"])
            total = _add_budget(total, action["budget_consumed"])
        return total

    def record_action(
        self,
        action: dict[str, Any],
        *,
        lease_token: str,
        delegation_policy: dict[str, Any],
        role_registry: dict[str, Any],
        authority_matrix: dict[str, Any],
    ) -> dict[str, Any]:
        validate_agent_action(action)
        started_at = _parse_datetime(
            action["started_at"], "Agent action started_at"
        )
        completed_at = _parse_datetime(
            action["completed_at"], "Agent action completed_at"
        )
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                parent, delegation, child, _, _ = self._canonical_chain(
                    connection,
                    action["delegation_id"],
                    delegation_policy=delegation_policy,
                    role_registry=role_registry,
                    authority_matrix=authority_matrix,
                )
                if (
                    action["project_id"] != delegation["project_id"]
                    or action["run_id"] != child["id"]
                ):
                    raise ProtocolError(
                        "Agent action does not bind to the delegated child run."
                    )
                self._require_active_chain(parent, delegation, child, started_at)
                self._require_active_chain(parent, delegation, child, completed_at)
                self._validate_lease(
                    connection,
                    run_id=child["id"],
                    token=lease_token,
                    at=started_at,
                )
                self._validate_lease(
                    connection,
                    run_id=child["id"],
                    token=lease_token,
                    at=completed_at,
                )
                expected_sequence = (
                    connection.execute(
                        "SELECT COALESCE(MAX(sequence), 0) + 1 FROM actions WHERE run_id = ?",
                        (child["id"],),
                    ).fetchone()[0]
                )
                if action["sequence"] != expected_sequence:
                    raise ProtocolError(
                        f"Agent action sequence must be {expected_sequence}."
                    )
                grants = self._grants(child)
                if action["action"] not in grants.get(action["resource"], set()):
                    raise ProtocolError(
                        "Agent action exceeds the child run authority grants."
                    )
                if action["action"] in {"approve", "promote"}:
                    raise ProtocolError(
                        "Agent actions cannot exercise approval or promotion authority."
                    )
                if action["tool"] is not None and action["tool"] not in child["tool_grants"]:
                    raise ProtocolError("Agent action uses an undelegated tool.")
                checkpoint_row = connection.execute(
                    """
                    SELECT * FROM checkpoints
                    WHERE run_id = ?
                    ORDER BY sequence DESC
                    LIMIT 1
                    """,
                    (child["id"],),
                ).fetchone()
                checkpoint_policy = delegation["checkpoint_policy"]
                last_sequence = (
                    0
                    if checkpoint_row is None
                    else json.loads(checkpoint_row["artifact_json"])[
                        "action_sequence"
                    ]
                )
                uncheckpointed = expected_sequence - 1 - last_sequence
                if (
                    uncheckpointed
                    >= checkpoint_policy["maximum_actions_between_checkpoints"]
                ):
                    raise ProtocolError(
                        "Agent action blocked until the required checkpoint is recorded."
                    )
                reference_time = (
                    _parse_datetime(child["started_at"], "Child run started_at")
                    if checkpoint_row is None
                    else _parse_datetime(
                        checkpoint_row["created_at"], "Checkpoint created_at"
                    )
                )
                if (
                    completed_at - reference_time
                ).total_seconds() > checkpoint_policy[
                    "maximum_seconds_between_checkpoints"
                ]:
                    raise ProtocolError(
                        "Agent action exceeds the maximum seconds between checkpoints."
                    )
                prior_budget = self._action_budget_total(connection, child["id"])
                total_budget = _add_budget(prior_budget, action["budget_consumed"])
                if not _budget_leq(total_budget, child["budget"]):
                    raise ProtocolError("Agent action exceeds the child run budget.")
                if not _budget_leq(total_budget, delegation["budget"]):
                    raise ProtocolError("Agent action exceeds the delegation budget.")
                parent_total = self._parent_consumed_budget(
                    connection,
                    delegation["parent_run_id"],
                    override_run_id=child["id"],
                    override_budget=total_budget,
                )
                parent_row = connection.execute(
                    "SELECT * FROM agent_runs WHERE id = ?",
                    (delegation["parent_run_id"],),
                ).fetchone()
                parent_budget = self._current_run(parent_row)["budget"]
                if not _budget_leq(parent_total, parent_budget):
                    raise ProtocolError(
                        "Aggregate child consumption exceeds the parent run budget."
                    )
                digest = _sha256(action)
                connection.execute(
                    """
                    INSERT INTO actions(
                        id, delegation_id, run_id, sequence, artifact_json,
                        content_sha256, created_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        action["id"],
                        action["delegation_id"],
                        action["run_id"],
                        action["sequence"],
                        _canonical_json(action),
                        digest,
                        action["completed_at"],
                    ),
                )
                self._append_event(
                    connection,
                    event_type="action-recorded",
                    project_id=action["project_id"],
                    delegation_id=action["delegation_id"],
                    run_id=action["run_id"],
                    occurred_at=action["completed_at"],
                    payload={"action": action, "content_sha256": digest},
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self.snapshot(action["delegation_id"])

    def record_message(
        self,
        message: dict[str, Any],
        *,
        lease_token: str | None,
        delegation_policy: dict[str, Any],
        role_registry: dict[str, Any],
        authority_matrix: dict[str, Any],
    ) -> dict[str, Any]:
        validate_agent_message(message)
        created_at = _parse_datetime(message["created_at"], "Agent message created_at")
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                parent, delegation, child, _, _ = self._canonical_chain(
                    connection,
                    message["delegation_id"],
                    delegation_policy=delegation_policy,
                    role_registry=role_registry,
                    authority_matrix=authority_matrix,
                )
                self._require_active_chain(parent, delegation, child, created_at)
                expected_binding = {
                    "project_id": delegation["project_id"],
                    "parent_run_id": parent["id"],
                    "child_run_id": child["id"],
                }
                for field, expected in expected_binding.items():
                    if message[field] != expected:
                        raise ProtocolError(
                            f"Agent message {field} does not match its runtime chain."
                        )
                endpoints = {parent["identity_id"], child["identity_id"]}
                if (
                    {message["from_identity"], message["to_identity"]} != endpoints
                    or message["from_identity"] == message["to_identity"]
                ):
                    raise ProtocolError(
                        "Agent message must travel between the bound parent and child identities."
                    )
                sender_run = (
                    child
                    if message["from_identity"] == child["identity_id"]
                    else parent
                )
                self._require_run_authority(
                    sender_run,
                    resource="message",
                    action="message",
                    label="Message sender run",
                )
                if sender_run["id"] == child["id"]:
                    if lease_token is None:
                        raise ProtocolError(
                            "Child-originated messages require the active lease token."
                        )
                    self._validate_lease(
                        connection,
                        run_id=child["id"],
                        token=lease_token,
                        at=created_at,
                    )
                expected_sequence = connection.execute(
                    """
                    SELECT COALESCE(MAX(sequence), 0) + 1
                    FROM messages WHERE child_run_id = ?
                    """,
                    (child["id"],),
                ).fetchone()[0]
                if message["sequence"] != expected_sequence:
                    raise ProtocolError(
                        f"Agent message sequence must be {expected_sequence}."
                    )
                digest = _sha256(message)
                connection.execute(
                    """
                    INSERT INTO messages(
                        id, delegation_id, child_run_id, sequence, artifact_json,
                        content_sha256, created_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        message["id"],
                        message["delegation_id"],
                        message["child_run_id"],
                        message["sequence"],
                        _canonical_json(message),
                        digest,
                        message["created_at"],
                    ),
                )
                self._append_event(
                    connection,
                    event_type="message-recorded",
                    project_id=message["project_id"],
                    delegation_id=message["delegation_id"],
                    run_id=message["child_run_id"],
                    occurred_at=message["created_at"],
                    payload={"message": message, "content_sha256": digest},
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self.snapshot(message["delegation_id"])

    def _parent_consumed_budget(
        self,
        connection: sqlite3.Connection,
        parent_run_id: str,
        *,
        override_run_id: str | None = None,
        override_budget: dict[str, int | float] | None = None,
    ) -> dict[str, int | float]:
        total = _zero_budget()
        rows = connection.execute(
            """
            SELECT child_run_id
            FROM delegations
            WHERE parent_run_id = ?
              AND runtime_status NOT IN ('rejected')
            """,
            (parent_run_id,),
        ).fetchall()
        for row in rows:
            run_id = row["child_run_id"]
            budget = (
                override_budget
                if run_id == override_run_id and override_budget is not None
                else self._action_budget_total(connection, run_id)
            )
            total = _add_budget(total, budget)
        return total

    def record_checkpoint(
        self,
        checkpoint: dict[str, Any],
        *,
        lease_token: str,
        delegation_policy: dict[str, Any],
        role_registry: dict[str, Any],
        authority_matrix: dict[str, Any],
    ) -> dict[str, Any]:
        created_at = _parse_datetime(checkpoint.get("created_at"), "Checkpoint created_at")
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                parent, delegation, child, profile, authority_bindings = (
                    self._canonical_chain(
                        connection,
                        checkpoint.get("delegation_id", ""),
                        delegation_policy=delegation_policy,
                        role_registry=role_registry,
                        authority_matrix=authority_matrix,
                    )
                )
                self._require_active_chain(parent, delegation, child, created_at)
                self._validate_lease(
                    connection,
                    run_id=child["id"],
                    token=lease_token,
                    at=created_at,
                )
                self._require_run_authority(
                    child,
                    resource="checkpoint",
                    action="checkpoint",
                    label="Child run",
                )
                immutable_parent_row, immutable_delegation_row, immutable_child_row = (
                    self._chain_rows(connection, delegation["delegation_id"])
                )
                validate_bound_checkpoint(
                    checkpoint,
                    self._row_artifact(immutable_parent_row),
                    self._row_artifact(immutable_delegation_row),
                    self._row_artifact(immutable_child_row),
                    authority_bindings=authority_bindings,
                    policy=delegation_policy,
                    profile=profile,
                    role_registry=role_registry,
                    authority_matrix=authority_matrix,
                )
                prior = connection.execute(
                    """
                    SELECT * FROM checkpoints
                    WHERE run_id = ?
                    ORDER BY sequence DESC
                    LIMIT 1
                    """,
                    (child["id"],),
                ).fetchone()
                expected_sequence = 1 if prior is None else int(prior["sequence"]) + 1
                expected_previous = None if prior is None else prior["content_sha256"]
                if checkpoint["sequence"] != expected_sequence:
                    raise ProtocolError(
                        f"Checkpoint sequence must be {expected_sequence}."
                    )
                if checkpoint["previous_checkpoint_sha256"] != expected_previous:
                    raise ProtocolError(
                        "Checkpoint previous_checkpoint_sha256 does not match the chain tip."
                    )
                if prior is not None and created_at <= _parse_datetime(
                    prior["created_at"], "Prior checkpoint created_at"
                ):
                    raise ProtocolError(
                        "Checkpoint created_at must increase monotonically."
                    )
                action_rows = connection.execute(
                    "SELECT artifact_json FROM actions WHERE run_id = ? ORDER BY sequence",
                    (child["id"],),
                ).fetchall()
                action_count = len(action_rows)
                if checkpoint["action_sequence"] != action_count:
                    raise ProtocolError(
                        "Checkpoint action_sequence must equal the journaled action count."
                    )
                action_budget = self._action_budget_total(connection, child["id"])
                if checkpoint["budget_consumed"] != action_budget:
                    raise ProtocolError(
                        "Checkpoint budget_consumed must equal the journaled action budget."
                    )
                prior_action_count = 0
                if prior is not None:
                    prior_action_count = json.loads(prior["artifact_json"])[
                        "action_sequence"
                    ]
                if (
                    action_count - prior_action_count
                    > delegation["checkpoint_policy"][
                        "maximum_actions_between_checkpoints"
                    ]
                ):
                    raise ProtocolError(
                        "Checkpoint exceeds the maximum actions between checkpoints."
                    )
                reference_time = (
                    _parse_datetime(child["started_at"], "Child run started_at")
                    if prior is None
                    else _parse_datetime(prior["created_at"], "Prior checkpoint created_at")
                )
                if (
                    created_at - reference_time
                ).total_seconds() > delegation["checkpoint_policy"][
                    "maximum_seconds_between_checkpoints"
                ]:
                    raise ProtocolError(
                        "Checkpoint exceeds the maximum seconds between checkpoints."
                    )
                if checkpoint["status"] == "completed":
                    if checkpoint["remaining_scope"]:
                        raise ProtocolError(
                            "A completed checkpoint cannot retain remaining scope."
                        )
                    for scope in child["scope"]:
                        if not any(
                            completed == scope or completed.startswith(f"{scope}/")
                            or scope.startswith(f"{completed}/")
                            for completed in checkpoint["completed_scope"]
                        ):
                            raise ProtocolError(
                                "Completed checkpoint does not cover the child run scope."
                            )
                    if not checkpoint["evidence_refs"]:
                        raise ProtocolError(
                            "A completed checkpoint requires evidence references."
                        )
                if checkpoint["status"] in {"completed", "cancelled", "failed"}:
                    active_descendant = connection.execute(
                        """
                        SELECT delegation_id
                        FROM delegations
                        WHERE parent_run_id = ?
                          AND runtime_status NOT IN (
                            'completed','cancelled','expired','rejected'
                          )
                        ORDER BY delegation_id
                        LIMIT 1
                        """,
                        (child["id"],),
                    ).fetchone()
                    if active_descendant is not None:
                        raise ProtocolError(
                            "A terminal checkpoint cannot close a run with active descendants."
                        )
                connection.execute(
                    """
                    INSERT INTO checkpoints(
                        id, delegation_id, run_id, sequence, content_sha256,
                        previous_checkpoint_sha256, artifact_json, created_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        checkpoint["id"],
                        checkpoint["delegation_id"],
                        checkpoint["run_id"],
                        checkpoint["sequence"],
                        checkpoint["content_sha256"],
                        checkpoint["previous_checkpoint_sha256"],
                        _canonical_json(checkpoint),
                        checkpoint["created_at"],
                    ),
                )
                run_status = {
                    "running": "running",
                    "blocked": "blocked",
                    "completed": "complete",
                    "cancelled": "cancelled",
                    "failed": "failed",
                }[checkpoint["status"]]
                cancellation_status = (
                    "cancelled"
                    if checkpoint["status"] == "cancelled"
                    else child["cancellation_status"]
                )
                completed_at = (
                    checkpoint["created_at"]
                    if run_status in TERMINAL_RUN_STATUSES
                    else None
                )
                connection.execute(
                    """
                    UPDATE agent_runs
                    SET runtime_status = ?, cancellation_status = ?,
                        completed_at = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (
                        run_status,
                        cancellation_status,
                        completed_at,
                        checkpoint["created_at"],
                        child["id"],
                    ),
                )
                terminal_delegation_status = {
                    "completed": "completed",
                    "cancelled": "cancelled",
                    "failed": "cancelled",
                }.get(checkpoint["status"])
                if terminal_delegation_status is not None:
                    connection.execute(
                        """
                        UPDATE delegations
                        SET runtime_status = ?, updated_at = ?
                        WHERE delegation_id = ?
                        """,
                        (
                            terminal_delegation_status,
                            checkpoint["created_at"],
                            delegation["delegation_id"],
                        ),
                    )
                self._append_event(
                    connection,
                    event_type="checkpoint-recorded",
                    project_id=checkpoint["project_id"],
                    delegation_id=checkpoint["delegation_id"],
                    run_id=checkpoint["run_id"],
                    occurred_at=checkpoint["created_at"],
                    payload={
                        "checkpoint": checkpoint,
                        "action_sequence": action_count,
                        "derived_run_status": run_status,
                        "derived_delegation_status": (
                            terminal_delegation_status or delegation["status"]
                        ),
                    },
                )
                if run_status in TERMINAL_RUN_STATUSES:
                    active_lease = connection.execute(
                        """
                        SELECT * FROM leases
                        WHERE run_id = ? AND status = 'active'
                        ORDER BY claimed_at DESC
                        LIMIT 1
                        """,
                        (child["id"],),
                    ).fetchone()
                    if active_lease is not None:
                        self._transition_lease(
                            connection,
                            active_lease,
                            status="released",
                            at=checkpoint["created_at"],
                            event_type="lease-released",
                        )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self.snapshot(checkpoint["delegation_id"])

    def _identity_can_cancel(
        self,
        authority_bindings: dict[str, Any],
        identity_id: str,
    ) -> bool:
        return any(
            grant.get("identity") == identity_id
            and grant.get("resource") == "delegation"
            and "cancel" in grant.get("actions", [])
            for grant in authority_bindings["grants"]
        )

    @staticmethod
    def _identity_kind(profile: dict[str, Any], identity_id: str) -> str:
        matches = [
            identity["kind"]
            for identity in profile["identities"]
            if identity["id"] == identity_id
        ]
        if len(matches) != 1:
            raise ProtocolError(
                "Cancellation requester identity is not uniquely declared in the project profile."
            )
        return matches[0]

    def _requester_agent_run(
        self,
        connection: sqlite3.Connection,
        *,
        project_id: str,
        identity_id: str,
    ) -> sqlite3.Row:
        rows = connection.execute(
            """
            SELECT * FROM agent_runs
            WHERE project_id = ?
              AND identity_id = ?
              AND runtime_status IN ('running', 'blocked')
              AND cancellation_status = 'active'
            ORDER BY created_at, id
            """,
            (project_id, identity_id),
        ).fetchall()
        if len(rows) != 1:
            raise ProtocolError(
                "Agent cancellation requester must resolve to exactly one active runtime run."
            )
        if rows[0]["delegation_id"] is None:
            raise ProtocolError(
                "Agent cancellation requester must be a leased delegated run."
            )
        return rows[0]

    @staticmethod
    def _run_is_descendant_or_self(
        connection: sqlite3.Connection,
        *,
        run_id: str,
        ancestor_run_id: str,
    ) -> bool:
        current_id: str | None = run_id
        visited: set[str] = set()
        while current_id is not None:
            if current_id == ancestor_run_id:
                return True
            if current_id in visited:
                raise ProtocolError("Runtime run ancestry contains a cycle.")
            visited.add(current_id)
            row = connection.execute(
                "SELECT parent_run_id FROM agent_runs WHERE id = ?",
                (current_id,),
            ).fetchone()
            if row is None:
                raise ProtocolError(
                    f"Cancellation target run does not exist: {current_id}"
                )
            current_id = row["parent_run_id"]
        return False

    def cancel(
        self,
        cancellation: dict[str, Any],
        *,
        lease_token: str | None = None,
    ) -> dict[str, Any]:
        validate_cancellation(cancellation)
        requested_at = _parse_datetime(
            cancellation["requested_at"], "Cancellation requested_at"
        )
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                if cancellation["subject_type"] == "delegation":
                    delegation_id = cancellation["subject_id"]
                    parent_row, delegation_row, child_row = self._chain_rows(
                        connection, delegation_id
                    )
                    subject_project = delegation_row["project_id"]
                    if (
                        delegation_row["runtime_status"]
                        in TERMINAL_DELEGATION_STATUSES
                        or child_row["runtime_status"] in TERMINAL_RUN_STATUSES
                    ):
                        raise ProtocolError(
                            "Cancellation cannot target terminal delegated work."
                        )
                else:
                    run_row = connection.execute(
                        "SELECT * FROM agent_runs WHERE id = ?",
                        (cancellation["subject_id"],),
                    ).fetchone()
                    if run_row is None:
                        raise ProtocolError(
                            f"Cancellation run does not exist: {cancellation['subject_id']}"
                        )
                    subject_project = run_row["project_id"]
                    parent_row = run_row
                    delegation_row = None
                    child_row = run_row
                    delegation_id = run_row["delegation_id"]
                    if (
                        run_row["runtime_status"] in TERMINAL_RUN_STATUSES
                        or run_row["cancellation_status"] != "active"
                    ):
                        raise ProtocolError(
                            "Cancellation cannot target a terminal or cancelled run."
                        )
                    if delegation_id is not None:
                        owning_delegation = connection.execute(
                            """
                            SELECT runtime_status
                            FROM delegations
                            WHERE delegation_id = ?
                            """,
                            (delegation_id,),
                        ).fetchone()
                        if (
                            owning_delegation is None
                            or owning_delegation["runtime_status"]
                            in TERMINAL_DELEGATION_STATUSES
                        ):
                            raise ProtocolError(
                                "Cancellation cannot target a run with terminal delegated work."
                            )
                if cancellation["project_id"] != subject_project:
                    raise ProtocolError(
                        "Cancellation project does not match the runtime subject."
                    )
                profile, authority_bindings = self._project_payloads(
                    connection, subject_project
                )
                if not self._identity_can_cancel(
                    authority_bindings, cancellation["requested_by"]
                ):
                    raise ProtocolError(
                        "Cancellation requester lacks project delegation cancellation authority."
                    )
                requester_kind = self._identity_kind(
                    profile, cancellation["requested_by"]
                )
                if requester_kind != "human":
                    requester_run = self._requester_agent_run(
                        connection,
                        project_id=subject_project,
                        identity_id=cancellation["requested_by"],
                    )
                    if lease_token is None:
                        raise ProtocolError(
                            "Agent-requested cancellation requires the active lease token."
                        )
                    self._validate_lease(
                        connection,
                        run_id=requester_run["id"],
                        token=lease_token,
                        at=requested_at,
                    )
                    self._require_run_authority(
                        self._current_run(requester_run),
                        resource="delegation",
                        action="cancel",
                        label="Agent requester run",
                    )
                    if not self._run_is_descendant_or_self(
                        connection,
                        run_id=child_row["id"],
                        ancestor_run_id=requester_run["id"],
                    ):
                        raise ProtocolError(
                            "Agent cancellation cannot target an ancestor or sibling run."
                        )
                if connection.execute(
                    "SELECT 1 FROM cancellations WHERE id = ?",
                    (cancellation["id"],),
                ).fetchone():
                    raise ProtocolError(
                        f"Cancellation already exists: {cancellation['id']}"
                    )
                affected = self._propagate_cancellation(
                    connection,
                    subject_type=cancellation["subject_type"],
                    subject_id=cancellation["subject_id"],
                    at=cancellation["requested_at"],
                )
                completed = dict(cancellation)
                completed["status"] = "completed"
                cancellation_digest = _sha256(completed)
                connection.execute(
                    """
                    INSERT INTO cancellations(
                        id, project_id, subject_type, subject_id, artifact_json,
                        content_sha256, requested_at, completed_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        cancellation["id"],
                        cancellation["project_id"],
                        cancellation["subject_type"],
                        cancellation["subject_id"],
                        _canonical_json(completed),
                        cancellation_digest,
                        cancellation["requested_at"],
                        cancellation["requested_at"],
                    ),
                )
                self._append_event(
                    connection,
                    event_type="cancellation-recorded",
                    project_id=subject_project,
                    delegation_id=delegation_id,
                    run_id=child_row["id"],
                    occurred_at=cancellation["requested_at"],
                    payload={
                        "cancellation": completed,
                        "content_sha256": cancellation_digest,
                        "affected": affected,
                    },
                )
                for affected_delegation_id in affected["delegation_ids"]:
                    affected_row = connection.execute(
                        """
                        SELECT parent_run_id, child_run_id
                        FROM delegations
                        WHERE delegation_id = ?
                        """,
                        (affected_delegation_id,),
                    ).fetchone()
                    self._append_event(
                        connection,
                        event_type="cancellation-propagated",
                        project_id=subject_project,
                        delegation_id=affected_delegation_id,
                        run_id=affected_row["child_run_id"],
                        occurred_at=cancellation["requested_at"],
                        payload={
                            "cancellation_id": cancellation["id"],
                            "content_sha256": cancellation_digest,
                            "affected": affected,
                            "parent_cancelled": (
                                affected_row["parent_run_id"]
                                in affected["run_ids"]
                            ),
                        },
                    )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return {
            "cancellation": completed,
            "affected": affected,
            "snapshot": (
                self.snapshot(delegation_id)
                if delegation_id is not None
                else {"run_id": cancellation["subject_id"]}
            ),
        }

    def _propagate_cancellation(
        self,
        connection: sqlite3.Connection,
        *,
        subject_type: str,
        subject_id: str,
        at: str,
    ) -> dict[str, list[str]]:
        delegation_ids: list[str] = []
        run_ids: list[str] = []
        queue: list[str] = []
        if subject_type == "delegation":
            row = connection.execute(
                "SELECT child_run_id FROM delegations WHERE delegation_id = ?",
                (subject_id,),
            ).fetchone()
            if row is None:
                raise ProtocolError(f"Cancellation delegation does not exist: {subject_id}")
            delegation_ids.append(subject_id)
            queue.append(row["child_run_id"])
        else:
            owning = connection.execute(
                """
                SELECT delegation_id
                FROM agent_runs
                WHERE id = ?
                """,
                (subject_id,),
            ).fetchone()
            if owning is None:
                raise ProtocolError(f"Cancellation run does not exist: {subject_id}")
            if owning["delegation_id"] is not None:
                delegation_ids.append(owning["delegation_id"])
            queue.append(subject_id)
        while queue:
            run_id = queue.pop(0)
            if run_id in run_ids:
                continue
            run_ids.append(run_id)
            children = connection.execute(
                """
                SELECT delegation_id, child_run_id
                FROM delegations
                WHERE parent_run_id = ?
                  AND runtime_status NOT IN ('completed','cancelled','expired','rejected')
                ORDER BY delegation_id
                """,
                (run_id,),
            ).fetchall()
            for child in children:
                delegation_ids.append(child["delegation_id"])
                queue.append(child["child_run_id"])

        for delegation_id in sorted(set(delegation_ids)):
            connection.execute(
                """
                UPDATE delegations
                SET runtime_status = 'cancelled', updated_at = ?
                WHERE delegation_id = ?
                  AND runtime_status NOT IN ('completed','cancelled','expired','rejected')
                """,
                (at, delegation_id),
            )
        for run_id in sorted(set(run_ids)):
            connection.execute(
                """
                UPDATE agent_runs
                SET runtime_status = CASE
                        WHEN runtime_status IN ('complete','failed','aborted','cancelled')
                        THEN runtime_status ELSE 'cancelled' END,
                    cancellation_status = 'cancelled',
                    completed_at = CASE
                        WHEN completed_at IS NULL THEN ? ELSE completed_at END,
                    updated_at = ?
                WHERE id = ?
                """,
                (at, at, run_id),
            )
            active_leases = connection.execute(
                """
                SELECT * FROM leases
                WHERE run_id = ? AND status = 'active'
                ORDER BY claimed_at, id
                """,
                (run_id,),
            ).fetchall()
            for lease_row in active_leases:
                self._transition_lease(
                    connection,
                    lease_row,
                    status="cancelled",
                    at=at,
                    event_type="lease-cancelled",
                )
        return {
            "delegation_ids": sorted(set(delegation_ids)),
            "run_ids": sorted(set(run_ids)),
        }

    def escalate(
        self,
        escalation: dict[str, Any],
        *,
        lease_token: str,
    ) -> dict[str, Any]:
        validate_escalation(escalation)
        raised_at = _parse_datetime(escalation["raised_at"], "Escalation raised_at")
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                parent_row, delegation_row, child_row = self._chain_rows(
                    connection, escalation["delegation_id"]
                )
                parent = self._current_run(parent_row)
                delegation = self._current_delegation(delegation_row)
                child = self._current_run(child_row)
                self._require_active_chain(parent, delegation, child, raised_at)
                self._validate_lease(
                    connection,
                    run_id=child["id"],
                    token=lease_token,
                    at=raised_at,
                )
                self._require_run_authority(
                    child,
                    resource="delegation",
                    action="escalate",
                    label="Child run",
                )
                if (
                    escalation["project_id"] != delegation["project_id"]
                    or escalation["run_id"] != child["id"]
                    or escalation["raised_by"] != child["identity_id"]
                ):
                    raise ProtocolError(
                        "Escalation does not bind to the delegated child identity."
                    )
                if escalation["owner_role"] != delegation["escalation_owner_role"]:
                    raise ProtocolError(
                        "Escalation owner_role does not match the delegation."
                    )
                escalation_digest = _sha256(escalation)
                connection.execute(
                    """
                    INSERT INTO escalations(
                        id, delegation_id, run_id, artifact_json,
                        content_sha256, raised_at
                    ) VALUES(?, ?, ?, ?, ?, ?)
                    """,
                    (
                        escalation["id"],
                        escalation["delegation_id"],
                        escalation["run_id"],
                        _canonical_json(escalation),
                        escalation_digest,
                        escalation["raised_at"],
                    ),
                )
                connection.execute(
                    """
                    UPDATE agent_runs
                    SET runtime_status = 'blocked', updated_at = ?
                    WHERE id = ? AND runtime_status = 'running'
                    """,
                    (escalation["raised_at"], child["id"]),
                )
                self._append_event(
                    connection,
                    event_type="escalation-recorded",
                    project_id=escalation["project_id"],
                    delegation_id=escalation["delegation_id"],
                    run_id=escalation["run_id"],
                    occurred_at=escalation["raised_at"],
                    payload={
                        "escalation": escalation,
                        "content_sha256": escalation_digest,
                        "derived_run_status": "blocked",
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return self.snapshot(escalation["delegation_id"])

    def _expire_delegation(
        self,
        connection: sqlite3.Connection,
        *,
        delegation_id: str,
        at: str,
    ) -> None:
        _, delegation_row, child_row = self._chain_rows(connection, delegation_id)
        if delegation_row["runtime_status"] in TERMINAL_DELEGATION_STATUSES:
            return
        connection.execute(
            """
            UPDATE delegations
            SET runtime_status = 'expired', updated_at = ?
            WHERE delegation_id = ?
            """,
            (at, delegation_id),
        )
        connection.execute(
            """
            UPDATE agent_runs
            SET runtime_status = CASE
                    WHEN runtime_status IN ('complete','failed','aborted','cancelled')
                    THEN runtime_status ELSE 'aborted' END,
                completed_at = CASE WHEN completed_at IS NULL THEN ? ELSE completed_at END,
                updated_at = ?
            WHERE id = ?
            """,
            (at, at, child_row["id"]),
        )
        active_lease = connection.execute(
            """
            SELECT * FROM leases
            WHERE run_id = ? AND status = 'active'
            ORDER BY claimed_at DESC
            LIMIT 1
            """,
            (child_row["id"],),
        ).fetchone()
        if active_lease is not None:
            self._transition_lease(
                connection,
                active_lease,
                status="expired",
                at=at,
                event_type="lease-expired",
            )
        self._append_event(
            connection,
            event_type="delegation-expired",
            project_id=delegation_row["project_id"],
            delegation_id=delegation_id,
            run_id=child_row["id"],
            occurred_at=at,
            payload={"derived_run_status": "aborted"},
        )

    def sweep(self, *, at: str | None = None) -> dict[str, Any]:
        swept_at = at or utc_now()
        swept_time = _parse_datetime(swept_at, "Runtime sweep time")
        expired_delegations: list[str] = []
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                expired_leases = self._expire_leases(connection, swept_time)
                rows = connection.execute(
                    """
                    SELECT d.delegation_id, d.artifact_json,
                           r.artifact_json AS child_artifact
                    FROM delegations d
                    JOIN agent_runs r ON r.id = d.child_run_id
                    WHERE d.runtime_status = 'active'
                    ORDER BY d.delegation_id
                    """
                ).fetchall()
                for row in rows:
                    delegation = json.loads(row["artifact_json"])
                    child = json.loads(row["child_artifact"])
                    deadline = min(
                        _parse_datetime(delegation["deadline"], "Delegation deadline"),
                        _parse_datetime(
                            delegation["expires_at"], "Delegation expires_at"
                        ),
                        _parse_datetime(child["deadline"], "Child run deadline"),
                    )
                    if swept_time > deadline:
                        self._expire_delegation(
                            connection,
                            delegation_id=row["delegation_id"],
                            at=swept_at,
                        )
                        expired_delegations.append(row["delegation_id"])
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return {
            "swept_at": swept_at,
            "expired_leases": expired_leases,
            "expired_delegations": expired_delegations,
        }

    def _verified_journal_artifacts(
        self,
        connection: sqlite3.Connection,
        delegation_id: str,
    ) -> dict[str, dict[str, dict[str, Any]]]:
        verified: dict[str, dict[str, dict[str, Any]]] = {
            "leases": {},
            "actions": {},
            "messages": {},
            "checkpoints": {},
            "cancellations": {},
            "escalations": {},
        }
        lease_rows = connection.execute(
            """
            SELECT * FROM leases
            WHERE delegation_id = ?
            ORDER BY claimed_at, id
            """,
            (delegation_id,),
        ).fetchall()
        for row in lease_rows:
            lease = self._persisted_lease(row)
            verified["leases"][lease["id"]] = {
                "artifact": lease,
                "content_sha256": lease["content_sha256"],
            }

        table_contracts = [
            ("actions", "run_id", "completed_at"),
            ("messages", "child_run_id", "created_at"),
        ]
        for table, run_field, time_field in table_contracts:
            rows = connection.execute(
                f"""
                SELECT * FROM {table}
                WHERE delegation_id = ?
                ORDER BY sequence
                """,
                (delegation_id,),
            ).fetchall()
            for expected_sequence, row in enumerate(rows, start=1):
                artifact = self._row_artifact(row)
                if table == "actions":
                    validate_agent_action(artifact)
                else:
                    validate_agent_message(artifact)
                singular = table.removesuffix("s")
                artifact_run_field = (
                    "run_id" if table == "actions" else "child_run_id"
                )
                if (
                    row["sequence"] != expected_sequence
                    or artifact["sequence"] != expected_sequence
                    or artifact["id"] != row["id"]
                    or artifact["delegation_id"] != delegation_id
                    or artifact[artifact_run_field] != row[run_field]
                    or artifact[time_field] != row["created_at"]
                ):
                    raise ProtocolError(
                        f"Runtime {singular} journal row binding is invalid."
                    )
                digest = _sha256(artifact)
                if row["content_sha256"] != digest:
                    raise ProtocolError(
                        f"Runtime {singular} journal content digest is invalid."
                    )
                verified[table][artifact["id"]] = {
                    "artifact": artifact,
                    "content_sha256": digest,
                }

        checkpoint_rows = connection.execute(
            """
            SELECT * FROM checkpoints
            WHERE delegation_id = ?
            ORDER BY sequence
            """,
            (delegation_id,),
        ).fetchall()
        previous: str | None = None
        for expected_sequence, row in enumerate(checkpoint_rows, start=1):
            checkpoint = self._row_artifact(row)
            validate_checkpoint(checkpoint)
            digest = _sha256(
                {
                    key: value
                    for key, value in checkpoint.items()
                    if key != "content_sha256"
                }
            )
            if (
                row["sequence"] != expected_sequence
                or checkpoint["sequence"] != expected_sequence
                or checkpoint["id"] != row["id"]
                or checkpoint["delegation_id"] != delegation_id
                or checkpoint["run_id"] != row["run_id"]
                or checkpoint["created_at"] != row["created_at"]
                or checkpoint["previous_checkpoint_sha256"] != previous
                or row["previous_checkpoint_sha256"] != previous
            ):
                raise ProtocolError(
                    "Runtime checkpoint journal row binding is invalid."
                )
            if (
                checkpoint["content_sha256"] != digest
                or row["content_sha256"] != digest
            ):
                raise ProtocolError(
                    "Runtime checkpoint journal content digest is invalid."
                )
            verified["checkpoints"][checkpoint["id"]] = {
                "artifact": checkpoint,
                "content_sha256": digest,
            }
            previous = digest

        cancellation_rows = connection.execute(
            "SELECT * FROM cancellations ORDER BY requested_at, id"
        ).fetchall()
        for row in cancellation_rows:
            cancellation = self._row_artifact(row)
            if cancellation.get("status") != "completed":
                raise ProtocolError(
                    "Runtime cancellation journal must contain completed records."
                )
            requested = dict(cancellation)
            requested["status"] = "requested"
            validate_cancellation(requested)
            digest = _sha256(cancellation)
            if (
                cancellation["id"] != row["id"]
                or cancellation["project_id"] != row["project_id"]
                or cancellation["subject_type"] != row["subject_type"]
                or cancellation["subject_id"] != row["subject_id"]
                or cancellation["requested_at"] != row["requested_at"]
                or row["completed_at"] != cancellation["requested_at"]
            ):
                raise ProtocolError(
                    "Runtime cancellation journal row binding is invalid."
                )
            if row["content_sha256"] != digest:
                raise ProtocolError(
                    "Runtime cancellation journal content digest is invalid."
                )
            verified["cancellations"][cancellation["id"]] = {
                "artifact": cancellation,
                "content_sha256": digest,
            }

        escalation_rows = connection.execute(
            """
            SELECT * FROM escalations
            WHERE delegation_id = ?
            ORDER BY raised_at, id
            """,
            (delegation_id,),
        ).fetchall()
        for row in escalation_rows:
            escalation = self._row_artifact(row)
            validate_escalation(escalation)
            digest = _sha256(escalation)
            if (
                escalation["id"] != row["id"]
                or escalation["delegation_id"] != delegation_id
                or escalation["run_id"] != row["run_id"]
                or escalation["raised_at"] != row["raised_at"]
            ):
                raise ProtocolError(
                    "Runtime escalation journal row binding is invalid."
                )
            if row["content_sha256"] != digest:
                raise ProtocolError(
                    "Runtime escalation journal content digest is invalid."
                )
            verified["escalations"][escalation["id"]] = {
                "artifact": escalation,
                "content_sha256": digest,
            }
        return verified

    def snapshot(self, delegation_id: str) -> dict[str, Any]:
        delegation_id = _require_string(delegation_id, "delegation_id")
        with self._connection() as connection:
            self._require_initialized(connection)
            connection.execute("BEGIN")
            parent_row, delegation_row, child_row = self._chain_rows(
                connection, delegation_id
            )
            context_row = connection.execute(
                "SELECT * FROM context_packets WHERE delegation_id = ?",
                (delegation_id,),
            ).fetchone()
            lease_rows = connection.execute(
                """
                SELECT * FROM leases
                WHERE delegation_id = ?
                ORDER BY claimed_at, id
                """,
                (delegation_id,),
            ).fetchall()
            action_rows = connection.execute(
                "SELECT * FROM actions WHERE delegation_id = ? ORDER BY sequence",
                (delegation_id,),
            ).fetchall()
            message_rows = connection.execute(
                "SELECT * FROM messages WHERE delegation_id = ? ORDER BY sequence",
                (delegation_id,),
            ).fetchall()
            checkpoint_rows = connection.execute(
                "SELECT * FROM checkpoints WHERE delegation_id = ? ORDER BY sequence",
                (delegation_id,),
            ).fetchall()
            event_rows = connection.execute(
                """
                SELECT * FROM runtime_events
                WHERE delegation_id = ?
                ORDER BY sequence
                """,
                (delegation_id,),
            ).fetchall()
            cancellation_ids: set[str] = set()
            for event_row in event_rows:
                try:
                    event_payload = json.loads(event_row["payload_json"])
                except (json.JSONDecodeError, TypeError) as exc:
                    raise ProtocolError("Runtime event payload JSON is invalid.") from exc
                cancellation_id = event_payload.get("cancellation_id")
                if isinstance(cancellation_id, str):
                    cancellation_ids.add(cancellation_id)
                cancellation = event_payload.get("cancellation")
                if isinstance(cancellation, dict) and isinstance(
                    cancellation.get("id"), str
                ):
                    cancellation_ids.add(cancellation["id"])
            all_cancellation_rows = connection.execute(
                "SELECT * FROM cancellations ORDER BY requested_at, id"
            ).fetchall()
            cancellation_rows = [
                row
                for row in all_cancellation_rows
                if row["id"] in cancellation_ids
                or row["subject_id"]
                in {delegation_id, parent_row["id"], child_row["id"]}
            ]
            escalation_rows = connection.execute(
                "SELECT * FROM escalations WHERE delegation_id = ? ORDER BY raised_at, id",
                (delegation_id,),
            ).fetchall()
            event_count = len(event_rows)
            consumed = self._action_budget_total(connection, child_row["id"])
            connection.commit()

        leases = [self._persisted_lease(row) for row in lease_rows]
        lease = None if not leases else leases[-1]
        graph_nodes = [
            {"id": f"agent-run:{parent_row['id']}", "type": "agent-run"},
            {"id": f"delegation:{delegation_id}", "type": "delegation"},
            {"id": f"agent-run:{child_row['id']}", "type": "agent-run"},
            {
                "id": f"agent-identity:{parent_row['identity_id']}",
                "type": "agent-identity",
            },
            {
                "id": f"agent-identity:{child_row['identity_id']}",
                "type": "agent-identity",
            },
            {"id": f"context-packet:{context_row['id']}", "type": "context-packet"},
        ]
        graph_edges = [
            {
                "type": "delegates",
                "from": f"agent-run:{parent_row['id']}",
                "to": f"delegation:{delegation_id}",
            },
            {
                "type": "spawns",
                "from": f"delegation:{delegation_id}",
                "to": f"agent-run:{child_row['id']}",
            },
            {
                "type": "child-of",
                "from": f"agent-run:{child_row['id']}",
                "to": f"agent-run:{parent_row['id']}",
            },
            {
                "type": "uses-context",
                "from": f"agent-run:{child_row['id']}",
                "to": f"context-packet:{context_row['id']}",
            },
        ]
        for lease_row in lease_rows:
            lease_node = f"runtime-lease:{lease_row['id']}"
            graph_nodes.append({"id": lease_node, "type": "runtime-lease"})
            graph_edges.extend(
                [
                    {
                        "type": "claims",
                        "from": f"agent-identity:{lease_row['identity_id']}",
                        "to": lease_node,
                    },
                    {
                        "type": "leases",
                        "from": lease_node,
                        "to": f"delegation:{delegation_id}",
                    },
                    {
                        "type": "leases",
                        "from": lease_node,
                        "to": f"agent-run:{child_row['id']}",
                    },
                ]
            )
        for row in action_rows:
            node_id = f"agent-action:{row['id']}"
            graph_nodes.append({"id": node_id, "type": "agent-action"})
            graph_edges.append(
                {
                    "type": "performs",
                    "from": f"agent-run:{child_row['id']}",
                    "to": node_id,
                }
            )
        for row in message_rows:
            node_id = f"message:{row['id']}"
            graph_nodes.append({"id": node_id, "type": "message"})
            graph_edges.append(
                {
                    "type": "sends",
                    "from": f"agent-identity:{json.loads(row['artifact_json'])['from_identity']}",
                    "to": node_id,
                }
            )
        for row in checkpoint_rows:
            node_id = f"checkpoint:{row['id']}"
            graph_nodes.append({"id": node_id, "type": "checkpoint"})
            graph_edges.append(
                {
                    "type": "checkpoints",
                    "from": node_id,
                    "to": f"agent-run:{child_row['id']}",
                }
            )
        return {
            "version": PROTOCOL_VERSION,
            "delegation_id": delegation_id,
            "parent_run": self._current_run(parent_row),
            "delegation": self._current_delegation(delegation_row),
            "child_run": self._current_run(child_row),
            "context_packet": {
                "id": context_row["id"],
                "content_sha256": context_row["content_sha256"],
            },
            "lease": lease,
            "leases": leases,
            "cancellations": [
                {
                    "artifact": self._row_artifact(row),
                    "content_sha256": row["content_sha256"],
                }
                for row in cancellation_rows
            ],
            "escalations": [
                {
                    "artifact": self._row_artifact(row),
                    "content_sha256": row["content_sha256"],
                }
                for row in escalation_rows
            ],
            "counts": {
                "leases": len(lease_rows),
                "actions": len(action_rows),
                "messages": len(message_rows),
                "checkpoints": len(checkpoint_rows),
                "cancellations": len(cancellation_rows),
                "escalations": len(escalation_rows),
                "runtime_events": event_count,
            },
            "budget_consumed": consumed,
            "checkpoint_tip": (
                None
                if not checkpoint_rows
                else {
                    "id": checkpoint_rows[-1]["id"],
                    "sequence": checkpoint_rows[-1]["sequence"],
                    "content_sha256": checkpoint_rows[-1]["content_sha256"],
                }
            ),
            "graph": {
                "nodes": sorted(graph_nodes, key=lambda item: item["id"]),
                "edges": sorted(
                    graph_edges,
                    key=lambda item: (item["type"], item["from"], item["to"]),
                ),
            },
            "authority": "runtime-state-only-no-approval-or-promotion",
        }

    def verify_replay(self, delegation_id: str) -> dict[str, Any]:
        with self._connection() as connection:
            self._require_initialized(connection)
            connection.execute("BEGIN IMMEDIATE")
            expected = self.snapshot(delegation_id)
            parent_row, delegation_row, child_row = self._chain_rows(
                connection, delegation_id
            )
            context_row = connection.execute(
                "SELECT * FROM context_packets WHERE delegation_id = ?",
                (delegation_id,),
            ).fetchone()
            persisted_submission = {
                "parent_run": self._row_artifact(parent_row),
                "delegation": self._row_artifact(delegation_row),
                "child_run": self._row_artifact(child_row),
                "context_packet": self._row_artifact(context_row),
            }
            delegation = persisted_submission["delegation"]
            delegation_digest = _sha256(
                {
                    key: value
                    for key, value in delegation.items()
                    if key != "content_sha256"
                }
            )
            if (
                delegation["content_sha256"] != delegation_digest
                or delegation_row["content_sha256"] != delegation_digest
            ):
                raise ProtocolError(
                    "Runtime delegation journal content digest is invalid."
                )
            packet = persisted_submission["context_packet"]
            packet_digest = _sha256(
                {
                    key: value
                    for key, value in packet.items()
                    if key != "content_sha256"
                }
            )
            if (
                packet["content_sha256"] != packet_digest
                or context_row["content_sha256"] != packet_digest
            ):
                raise ProtocolError(
                    "Runtime context packet journal content digest is invalid."
                )
            journal = self._verified_journal_artifacts(connection, delegation_id)
            event_rows = connection.execute(
                "SELECT * FROM runtime_events ORDER BY sequence"
            ).fetchall()
            previous: str | None = None
            replay: dict[str, Any] | None = None
            action_sequence = message_sequence = checkpoint_sequence = 0
            checkpoint_tip: str | None = None
            replayed_leases: dict[str, dict[str, Any]] = {}
            replayed_cancellations: set[str] = set()
            replayed_escalations: set[str] = set()
            for index, row in enumerate(event_rows, start=1):
                payload = json.loads(row["payload_json"])
                unsigned = {
                    "version": PROTOCOL_VERSION,
                    "sequence": row["sequence"],
                    "event_type": row["event_type"],
                    "project_id": row["project_id"],
                    "delegation_id": row["delegation_id"],
                    "run_id": row["run_id"],
                    "occurred_at": row["occurred_at"],
                    "payload": payload,
                    "previous_event_sha256": row["previous_event_sha256"],
                }
                if row["sequence"] != index:
                    raise ProtocolError("Runtime event sequence is not contiguous.")
                if row["previous_event_sha256"] != previous:
                    raise ProtocolError("Runtime event previous digest is invalid.")
                digest = _sha256(unsigned)
                if row["content_sha256"] != digest:
                    raise ProtocolError("Runtime event content digest is invalid.")
                previous = digest
                if row["delegation_id"] != delegation_id:
                    continue
                if row["event_type"] == "delegation-submitted":
                    if (
                        payload["parent_run"] != persisted_submission["parent_run"]
                        or payload["delegation"]
                        != persisted_submission["delegation"]
                        or payload["child_run"] != persisted_submission["child_run"]
                        or payload["context_packet_id"] != packet["id"]
                        or payload["context_packet_sha256"] != packet_digest
                    ):
                        raise ProtocolError(
                            "Runtime submission event does not match persisted artifacts."
                        )
                    replay = {
                        "parent_status": payload["parent_run"]["status"],
                        "delegation_status": payload["delegation"]["status"],
                        "child_status": payload["child_run"]["status"],
                        "cancellation_status": payload["child_run"][
                            "cancellation_status"
                        ],
                        "context_packet_sha256": payload["context_packet_sha256"],
                        "lease_status": None,
                        "budget_consumed": _zero_budget(),
                    }
                elif replay is None:
                    raise ProtocolError(
                        "Runtime replay encountered an event before delegation submission."
                    )
                elif row["event_type"] in {
                    "lease-claimed",
                    "lease-released",
                    "lease-expired",
                    "lease-cancelled",
                }:
                    lease = payload.get("lease")
                    validate_runtime_lease(lease)
                    persisted = journal["leases"].get(lease["id"])
                    immutable_fields = {
                        "version",
                        "id",
                        "project_id",
                        "delegation_id",
                        "run_id",
                        "identity_id",
                        "claimed_at",
                        "expires_at",
                        "token_sha256",
                    }
                    if (
                        persisted is None
                        or lease["project_id"] != row["project_id"]
                        or lease["delegation_id"] != delegation_id
                        or lease["run_id"] != row["run_id"]
                        or any(
                            lease[field] != persisted["artifact"][field]
                            for field in immutable_fields
                        )
                    ):
                        raise ProtocolError(
                            "Runtime lease event does not match its journal row."
                        )
                    expected_status = row["event_type"].removeprefix("lease-")
                    if expected_status == "claimed":
                        expected_status = "active"
                    if (
                        lease["status"] != expected_status
                        or (
                            expected_status == "active"
                            and lease["released_at"] is not None
                        )
                        or (
                            expected_status != "active"
                            and lease["released_at"] != row["occurred_at"]
                        )
                    ):
                        raise ProtocolError(
                            "Runtime lease event transition is invalid."
                        )
                    prior_lease = replayed_leases.get(lease["id"])
                    if expected_status == "active":
                        if prior_lease is not None:
                            raise ProtocolError(
                                "Runtime lease replay contains a duplicate claim."
                            )
                    elif prior_lease is None or prior_lease["status"] != "active":
                        raise ProtocolError(
                            "Runtime lease replay transition has no active claim."
                        )
                    replayed_leases[lease["id"]] = lease
                    replay["lease_status"] = lease["status"]
                elif row["event_type"] == "action-recorded":
                    action_sequence += 1
                    if payload["action"]["sequence"] != action_sequence:
                        raise ProtocolError("Runtime action replay sequence is invalid.")
                    persisted = journal["actions"].get(payload["action"]["id"])
                    if (
                        persisted is None
                        or persisted["artifact"] != payload["action"]
                        or persisted["content_sha256"]
                        != payload["content_sha256"]
                    ):
                        raise ProtocolError(
                            "Runtime action event does not match its journal row."
                        )
                    replay["budget_consumed"] = _add_budget(
                        replay["budget_consumed"],
                        payload["action"]["budget_consumed"],
                    )
                elif row["event_type"] == "message-recorded":
                    message_sequence += 1
                    if payload["message"]["sequence"] != message_sequence:
                        raise ProtocolError("Runtime message replay sequence is invalid.")
                    persisted = journal["messages"].get(payload["message"]["id"])
                    if (
                        persisted is None
                        or persisted["artifact"] != payload["message"]
                        or persisted["content_sha256"]
                        != payload["content_sha256"]
                    ):
                        raise ProtocolError(
                            "Runtime message event does not match its journal row."
                        )
                elif row["event_type"] == "checkpoint-recorded":
                    checkpoint = payload["checkpoint"]
                    checkpoint_sequence += 1
                    if checkpoint["sequence"] != checkpoint_sequence:
                        raise ProtocolError("Runtime checkpoint replay sequence is invalid.")
                    if checkpoint["previous_checkpoint_sha256"] != checkpoint_tip:
                        raise ProtocolError("Runtime checkpoint replay digest chain is invalid.")
                    if (
                        checkpoint["action_sequence"] != action_sequence
                        or payload.get("action_sequence") != checkpoint["action_sequence"]
                    ):
                        raise ProtocolError(
                            "Runtime checkpoint replay action coverage is invalid."
                        )
                    persisted = journal["checkpoints"].get(checkpoint["id"])
                    if persisted is None or persisted["artifact"] != checkpoint:
                        raise ProtocolError(
                            "Runtime checkpoint event does not match its journal row."
                        )
                    checkpoint_tip = checkpoint["content_sha256"]
                    replay["child_status"] = payload["derived_run_status"]
                    replay["delegation_status"] = payload[
                        "derived_delegation_status"
                    ]
                    if checkpoint["status"] == "cancelled":
                        replay["cancellation_status"] = "cancelled"
                elif row["event_type"] == "escalation-recorded":
                    escalation = payload.get("escalation")
                    persisted = journal["escalations"].get(
                        escalation.get("id") if isinstance(escalation, dict) else None
                    )
                    if (
                        persisted is None
                        or persisted["artifact"] != escalation
                        or persisted["content_sha256"]
                        != payload.get("content_sha256")
                        or escalation["delegation_id"] != delegation_id
                        or escalation["run_id"] != row["run_id"]
                    ):
                        raise ProtocolError(
                            "Runtime escalation event does not match its journal row."
                        )
                    replayed_escalations.add(escalation["id"])
                    replay["child_status"] = "blocked"
                elif row["event_type"] == "cancellation-recorded":
                    cancellation = payload.get("cancellation")
                    persisted = journal["cancellations"].get(
                        cancellation.get("id")
                        if isinstance(cancellation, dict)
                        else None
                    )
                    if (
                        persisted is None
                        or persisted["artifact"] != cancellation
                        or persisted["content_sha256"]
                        != payload.get("content_sha256")
                    ):
                        raise ProtocolError(
                            "Runtime cancellation event does not match its journal row."
                        )
                    replayed_cancellations.add(cancellation["id"])
                elif row["event_type"] == "cancellation-propagated":
                    cancellation_id = payload.get("cancellation_id")
                    persisted = journal["cancellations"].get(cancellation_id)
                    affected = payload.get("affected")
                    if (
                        persisted is None
                        or persisted["content_sha256"]
                        != payload.get("content_sha256")
                        or not isinstance(affected, dict)
                        or delegation_id not in affected.get("delegation_ids", [])
                        or row["run_id"]
                        not in affected.get("run_ids", [])
                    ):
                        raise ProtocolError(
                            "Runtime cancellation propagation does not match its journal row."
                        )
                    replayed_cancellations.add(cancellation_id)
                    replay["delegation_status"] = "cancelled"
                    replay["child_status"] = "cancelled"
                    replay["cancellation_status"] = "cancelled"
                    if payload.get("parent_cancelled") is True:
                        replay["parent_status"] = "cancelled"
                elif row["event_type"] == "delegation-expired":
                    replay["delegation_status"] = "expired"
                    replay["child_status"] = "aborted"
            if replay is None:
                raise ProtocolError(
                    f"Runtime replay has no submission for delegation '{delegation_id}'."
                )
            connection.commit()

        observed = {
            "parent_status": expected["parent_run"]["status"],
            "delegation_status": expected["delegation"]["status"],
            "child_status": expected["child_run"]["status"],
            "cancellation_status": expected["child_run"]["cancellation_status"],
            "context_packet_sha256": expected["context_packet"]["content_sha256"],
            "lease_status": (
                None if expected["lease"] is None else expected["lease"]["status"]
            ),
            "budget_consumed": expected["budget_consumed"],
        }
        if replay != observed:
            raise ProtocolError(
                "Runtime replay state does not match the persisted runtime snapshot: "
                f"replayed={_canonical_json(replay)} observed={_canonical_json(observed)}"
            )
        if expected["counts"]["actions"] != action_sequence:
            raise ProtocolError("Runtime replay action count does not match persistence.")
        if expected["counts"]["messages"] != message_sequence:
            raise ProtocolError("Runtime replay message count does not match persistence.")
        if expected["counts"]["checkpoints"] != checkpoint_sequence:
            raise ProtocolError(
                "Runtime replay checkpoint count does not match persistence."
            )
        persisted_leases = {
            lease_id: item["artifact"]
            for lease_id, item in journal["leases"].items()
        }
        if (
            expected["counts"]["leases"] != len(replayed_leases)
            or replayed_leases != persisted_leases
        ):
            raise ProtocolError(
                "Runtime replay lease records do not match persistence."
            )
        expected_cancellation_ids = {
            item["artifact"]["id"] for item in expected["cancellations"]
        }
        if (
            expected["counts"]["cancellations"] != len(replayed_cancellations)
            or replayed_cancellations != expected_cancellation_ids
        ):
            raise ProtocolError(
                "Runtime replay cancellation records do not match persistence."
            )
        expected_escalation_ids = {
            item["artifact"]["id"] for item in expected["escalations"]
        }
        if (
            expected["counts"]["escalations"] != len(replayed_escalations)
            or replayed_escalations != expected_escalation_ids
        ):
            raise ProtocolError(
                "Runtime replay escalation records do not match persistence."
            )
        if (
            None
            if expected["checkpoint_tip"] is None
            else expected["checkpoint_tip"]["content_sha256"]
        ) != checkpoint_tip:
            raise ProtocolError("Runtime replay checkpoint tip does not match persistence.")
        return {
            "delegation_id": delegation_id,
            "status": "passed",
            "event_count": len(event_rows),
            "action_count": action_sequence,
            "message_count": message_sequence,
            "checkpoint_count": checkpoint_sequence,
            "lease_count": len(replayed_leases),
            "cancellation_count": len(replayed_cancellations),
            "escalation_count": len(replayed_escalations),
            "event_chain_tip": previous,
            "checkpoint_chain_tip": checkpoint_tip,
            "replayed_state": replay,
        }
