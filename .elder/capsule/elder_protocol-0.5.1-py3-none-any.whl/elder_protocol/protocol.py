from __future__ import annotations

from typing import Any

from elder_protocol.constants import (
    AUTONOMY_LEVELS,
    PROTOCOL_DIR,
    PROTOCOL_VERSION,
    ROOT,
    SKILLS_DIR,
)
from elder_protocol.autonomy import (
    canonical_sha256,
    validate_autonomy_authority_source,
    validate_autonomy_policy,
)
from elder_protocol.design import validate_design_registry
from elder_protocol.eval_harness import (
    validate_evaluation_dataset,
    validate_evaluation_registry,
    validate_evaluator_contract,
)
from elder_protocol.errors import ProtocolError
from elder_protocol.evaluation import validate_transcript_review_policy
from elder_protocol.factory_contracts import validate_factory_contracts
from elder_protocol.factory_domain import validate_factory_domain
from elder_protocol.graph import build_protocol_graph, validate_graph
from elder_protocol.governance import (
    HUMAN_APPROVAL_ROLES,
    validate_delegation_policy,
    validate_role_registry,
    validate_stack_adapter_registry,
)
from elder_protocol.io import load_json
from elder_protocol.knowledge import validate_context_policy, validate_memory_policy
from elder_protocol.learning import validate_learning_policy
from elder_protocol.orchestration import validate_runtime_policy
from elder_protocol.qualification import validate_qualification_policy
from elder_protocol.research_sources import validate_research_sources
from elder_protocol.schema_validation import (
    validate_against_schema,
    validate_schema_catalog,
)
from elder_protocol.skills import validate_skill_registry
from elder_protocol.telemetry import validate_telemetry_contract


INSTITUTIONAL_MATURITY_STANDARD_DIGESTS = {
    "1.0.0": "b7a07645ad1d8ba8f8e71f39f8394f3247cd71a92768eef915f2149a7d400c77",
}


def require_unique_ids(items: list[dict[str, Any]], label: str) -> None:
    ids = [item.get("id") for item in items]
    if any(not isinstance(item_id, str) or not item_id for item_id in ids):
        raise ProtocolError(f"Every {label} must have a non-empty string id.")
    duplicates = sorted({item_id for item_id in ids if ids.count(item_id) > 1})
    if duplicates:
        raise ProtocolError(f"Duplicate {label} ids: {', '.join(duplicates)}")


def protocol_data() -> dict[str, dict[str, Any]]:
    names = [
        "ontology",
        "authority-matrix",
        "role-registry",
        "delegation-policy",
        "multi-agent-runtime-policy",
        "stack-adapter-registry",
        "invariants",
        "change-classes",
        "meta-architecture",
        "capability-packs",
        "recommendation-ledger",
        "judgment-rubric",
        "operational-maturity",
        "design-registry",
        "transcript-review-policy",
        "evaluation-registry",
        "evaluation-dataset",
        "evaluator-contract",
        "telemetry-contract",
        "context-policy",
        "memory-policy",
        "learning-policy",
        "repository-dreaming-policy",
        "qualification-policy",
        "autonomy-authority-source",
        "autonomy-policy",
        "autonomy-classes",
        "skill-registry",
        "capability-pack.schema",
        "recommendation-ledger.schema",
        "component-operating-contract.schema",
        "judgment-rubric.schema",
        "operational-maturity.schema",
        "design-registry.schema",
        "architecture-boundary.schema",
        "transcript-review-policy.schema",
        "transcript-review.schema",
        "evaluation-registry.schema",
        "evaluation-dataset.schema",
        "evaluator-contract.schema",
        "evaluation-candidate.schema",
        "judge-results.schema",
        "evaluation-report.schema",
        "calibration-report.schema",
        "comparison-report.schema",
        "telemetry-contract.schema",
        "telemetry-event.schema",
        "telemetry-report.schema",
        "context-policy.schema",
        "context-request.schema",
        "memory-policy.schema",
        "build-memory-ledger.schema",
        "memory-approval.schema",
        "learning-policy.schema",
        "learning-observation.schema",
        "learning-evaluation.schema",
        "learning-approval.schema",
        "learning-promotion.schema",
        "repository-dreaming-policy.schema",
        "session-activation.schema",
        "dreaming-request.schema",
        "dreaming-execution.schema",
        "qualification-policy.schema",
        "hosted-evidence-bundle.schema",
        "qualification-report.schema",
        "autonomy-authority-source.schema",
        "autonomy-policy.schema",
        "autonomy-class.schema",
        "autonomy-certification.schema",
        "incident-budget.schema",
        "autonomy-suspension.schema",
        "autonomy-revocation.schema",
        "autonomy-renewal.schema",
        "qualification-consumption.schema",
        "effective-autonomy-report.schema",
        "autonomy-work-item.schema",
        "autonomy-match-report.schema",
        "autonomy-simulation-report.schema",
        "autonomy-certification-event.schema",
        "autonomy-replay-report.schema",
        "autonomy-authority-evidence.schema",
        "autonomy-authority-lease.schema",
        "hosted-git-evidence.schema",
        "supervised-pr-execution.schema",
        "supervised-pr-packet.schema",
        "supervised-pr-response.schema",
        "canary-plan.schema",
        "canary-simulation-report.schema",
        "canary-authority-lease.schema",
        "canary-authority-evidence.schema",
        "canary-provider-evidence.schema",
        "canary-execution-packet.schema",
        "canary-response.schema",
        "canary-observation.schema",
        "canary-observation-report.schema",
        "canary-rollback-packet.schema",
        "canary-rollback-response.schema",
        "canary-workflow-result.schema",
        "knowledge-query.schema",
        "protocol-graph.schema",
        "protocol-graph",
        "project-profile.schema",
        "work-item.schema",
        "agent-run.schema",
        "agent-action.schema",
        "evidence-bundle.schema",
        "knowledge-graph.schema",
        "tool-contract.schema",
        "mcp-registry.schema",
        "context-packet.schema",
        "memory-record.schema",
        "learning-candidate.schema",
        "factory-substrate.schema",
        "role-registry.schema",
        "authority-bindings.schema",
        "resolved-obligations.schema",
        "delegation-policy.schema",
        "multi-agent-runtime-policy.schema",
        "delegation.schema",
        "agent-message.schema",
        "checkpoint.schema",
        "approval-decision.schema",
        "authority-grant.schema",
        "tool-grant.schema",
        "budget.schema",
        "deadline.schema",
        "cancellation.schema",
        "escalation.schema",
        "stack-adapter.schema",
        "stack-adapter-registry.schema",
        "runtime-lease.schema",
    ]
    return {name: load_json(PROTOCOL_DIR / f"{name}.json") for name in names}


def _validate_pack_graph(packs: list[dict[str, Any]]) -> None:
    by_id = {pack["id"]: pack for pack in packs}
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(pack_id: str) -> None:
        if pack_id in visiting:
            raise ProtocolError(f"Capability-pack dependency cycle includes '{pack_id}'.")
        if pack_id in visited:
            return
        visiting.add(pack_id)
        for dependency in by_id[pack_id].get("requires", []):
            if dependency not in by_id:
                raise ProtocolError(
                    f"Capability pack '{pack_id}' requires unknown pack '{dependency}'."
                )
            visit(dependency)
        visiting.remove(pack_id)
        visited.add(pack_id)

    for pack_id in by_id:
        visit(pack_id)


def _validate_meta_architecture(meta: dict[str, Any]) -> None:
    if set(meta) != {
        "version",
        "identity",
        "layers",
        "boundaries",
        "extension_points",
    }:
        raise ProtocolError("Meta-architecture fields are incomplete or unknown.")
    identity = meta["identity"]
    if identity.get("kind") != "project-foundation-compiler-and-software-factory-protocol":
        raise ProtocolError("Meta-architecture must identify Elder as the factory protocol.")
    if identity.get("product_agnostic") is not True:
        raise ProtocolError("Meta-architecture must remain product agnostic.")
    layers = meta["layers"]
    require_unique_ids(layers, "meta-architecture layer")
    expected = [
        "kernel",
        "capability",
        "adapter",
        "project",
        "factory",
        "assurance-learning",
    ]
    if [layer["id"] for layer in layers] != expected:
        raise ProtocolError(f"Meta-architecture layers must be ordered as: {expected}")
    if [layer["order"] for layer in layers] != list(range(1, len(layers) + 1)):
        raise ProtocolError("Meta-architecture layer order must be contiguous.")
    require_unique_ids(meta["boundaries"], "meta-architecture boundary")
    require_unique_ids(meta["extension_points"], "meta-architecture extension point")


def _validate_capability_pack_contract(
    packs: list[dict[str, Any]],
    data: dict[str, dict[str, Any]],
) -> None:
    required = {
        "id",
        "layer",
        "required",
        "requires",
        "provides",
        "responsibilities",
        "obligation_owner_role",
        "required_artifacts",
        "required_evidence",
        "required_skills",
        "interfaces",
        "adapter_points",
        "contract_status",
        "runtime_status",
    }
    valid_layers = {"kernel", "capability", "factory", "assurance-learning"}
    valid_contract_statuses = {"verified", "implemented", "specified", "planned"}
    valid_runtime_statuses = {"verified", "reference-only", "specified", "planned"}
    valid_evidence = {
        "Foundation",
        "Component",
        "Integration",
        "Workflow",
        "Stress",
        "Outcome",
    }
    skill_ids = {skill["id"] for skill in data["skill-registry"]["skills"]}
    role_ids = {role["id"] for role in data["role-registry"]["roles"]}
    schema_ids = {
        f"{name.removesuffix('.schema')}.schema.json"
        for name in data
        if name.endswith(".schema")
    }
    for pack in packs:
        if set(pack) != required:
            raise ProtocolError(
                f"Capability pack '{pack.get('id')}' fields must be exactly: "
                f"{sorted(required)}"
            )
        if pack["layer"] not in valid_layers:
            raise ProtocolError(f"Capability pack '{pack['id']}' has an invalid layer.")
        if pack["contract_status"] not in valid_contract_statuses:
            raise ProtocolError(
                f"Capability pack '{pack['id']}' has an invalid contract status."
            )
        if pack["runtime_status"] not in valid_runtime_statuses:
            raise ProtocolError(
                f"Capability pack '{pack['id']}' has an invalid runtime status."
            )
        if pack["obligation_owner_role"] not in role_ids:
            raise ProtocolError(
                f"Capability pack '{pack['id']}' uses unknown obligation owner role "
                f"'{pack['obligation_owner_role']}'."
            )
        for field in [
            "provides",
            "responsibilities",
            "required_artifacts",
            "required_evidence",
            "adapter_points",
        ]:
            values = pack[field]
            if not isinstance(values, list) or not values or len(values) != len(set(values)):
                raise ProtocolError(
                    f"Capability pack '{pack['id']}' {field} must be unique and non-empty."
                )
        unknown_evidence = set(pack["required_evidence"]) - valid_evidence
        if unknown_evidence:
            raise ProtocolError(
                f"Capability pack '{pack['id']}' uses unknown evidence levels: "
                f"{sorted(unknown_evidence)}"
            )
        unknown_skills = set(pack["required_skills"]) - skill_ids
        if unknown_skills:
            raise ProtocolError(
                f"Capability pack '{pack['id']}' requires unknown skills: "
                f"{sorted(unknown_skills)}"
            )
        unknown_interfaces = set(pack["interfaces"]) - schema_ids
        if unknown_interfaces:
            raise ProtocolError(
                f"Capability pack '{pack['id']}' uses unknown interfaces: "
                f"{sorted(unknown_interfaces)}"
            )


def _validate_recommendation_ledger(
    ledger: dict[str, Any],
    data: dict[str, dict[str, Any]],
) -> None:
    recommendations = ledger.get("recommendations")
    if not isinstance(recommendations, list) or not recommendations:
        raise ProtocolError("Recommendation ledger must define recommendations.")
    require_unique_ids(recommendations, "recommendation")
    layer_ids = {layer["id"] for layer in data["meta-architecture"]["layers"]}
    valid_evidence = {
        "Foundation",
        "Component",
        "Integration",
        "Workflow",
        "Stress",
        "Outcome",
    }
    valid_statuses = {"verified", "implemented", "specified", "planned"}
    control_ids: set[str] = set()
    for recommendation in recommendations:
        required = {
            "id",
            "title",
            "source",
            "principle",
            "architecture_layers",
            "controls",
            "required_artifacts",
            "required_evidence",
            "operational_status",
            "known_gaps",
        }
        if set(recommendation) != required:
            raise ProtocolError(
                f"Recommendation '{recommendation.get('id')}' fields must be exactly: "
                f"{sorted(required)}"
            )
        unknown_layers = set(recommendation["architecture_layers"]) - layer_ids
        if unknown_layers:
            raise ProtocolError(
                f"Recommendation '{recommendation['id']}' uses unknown layers: "
                f"{sorted(unknown_layers)}"
            )
        if recommendation["operational_status"] not in valid_statuses:
            raise ProtocolError(
                f"Recommendation '{recommendation['id']}' has an invalid status."
            )
        unknown_evidence = set(recommendation["required_evidence"]) - valid_evidence
        if unknown_evidence:
            raise ProtocolError(
                f"Recommendation '{recommendation['id']}' uses unknown evidence: "
                f"{sorted(unknown_evidence)}"
            )
        if not recommendation["required_artifacts"]:
            raise ProtocolError(
                f"Recommendation '{recommendation['id']}' needs required artifacts."
            )
        controls = recommendation["controls"]
        if not isinstance(controls, list) or not controls:
            raise ProtocolError(
                f"Recommendation '{recommendation['id']}' needs controls."
            )
        kinds: set[str] = set()
        for control in controls:
            if set(control) != {"id", "kind", "enforcement", "status"}:
                raise ProtocolError(
                    f"Recommendation '{recommendation['id']}' has an invalid control."
                )
            if control["id"] in control_ids:
                raise ProtocolError(
                    f"Duplicate recommendation control id: {control['id']}"
                )
            control_ids.add(control["id"])
            kinds.add(control["kind"])
            if control["kind"] not in {"deterministic", "probabilistic", "human"}:
                raise ProtocolError(
                    f"Control '{control['id']}' has an invalid kind."
                )
            if control["status"] not in valid_statuses:
                raise ProtocolError(
                    f"Control '{control['id']}' has an invalid status."
                )
        if "probabilistic" in kinds and not ({"deterministic", "human"} & kinds):
            raise ProtocolError(
                f"Recommendation '{recommendation['id']}' cannot rely only on "
                "probabilistic control."
            )


def _validate_judgment_rubric(rubric: dict[str, Any]) -> None:
    dimensions = rubric.get("dimensions")
    if not isinstance(dimensions, list) or not dimensions:
        raise ProtocolError("Judgment rubric must define dimensions.")
    require_unique_ids(dimensions, "judgment dimension")
    if rubric.get("scale", {}).get("minimum") != 0:
        raise ProtocolError("Judgment rubric minimum must be 0.")
    if rubric.get("scale", {}).get("maximum") != 4:
        raise ProtocolError("Judgment rubric maximum must be 4.")
    if not rubric.get("vetoes") or not rubric.get("decision_rules"):
        raise ProtocolError("Judgment rubric must define vetoes and decision rules.")
    for dimension in dimensions:
        if dimension.get("weight", 0) <= 0:
            raise ProtocolError(
                f"Judgment dimension '{dimension['id']}' needs a positive weight."
            )
        if not dimension.get("evidence"):
            raise ProtocolError(
                f"Judgment dimension '{dimension['id']}' needs evidence."
            )


def _validate_operational_maturity(model: dict[str, Any]) -> None:
    standard = model.get("institutional_standard")
    if not isinstance(standard, dict):
        raise ProtocolError(
            "Operational maturity needs an institutional standard."
        )
    if standard.get("id") != "elder-factory-maturity-standard":
        raise ProtocolError(
            "Operational maturity uses an unknown institutional standard."
        )
    if standard.get("version") != "1.0.0":
        raise ProtocolError(
            "Institutional factory maturity standard must be version '1.0.0'."
        )
    if standard.get("ratifying_adr") != "ADR-0022":
        raise ProtocolError(
            "Institutional factory maturity standard must be ratified by ADR-0022."
        )
    if standard.get("overall_level_rule") != "minimum-mandatory-dimension":
        raise ProtocolError(
            "Factory maturity must resolve to the minimum mandatory dimension."
        )
    expected_dimensions = [
        "product-intake-planning",
        "worker-execution-isolation",
        "security-supply-chain",
        "test-evidence-evaluation",
        "delivery-production-authority",
        "reliability-recovery-incidents",
        "owner-outcome-economics",
        "learning-long-term-quality",
    ]
    dimensions = standard.get("dimensions")
    if not isinstance(dimensions, list) or [
        dimension.get("id") for dimension in dimensions
    ] != expected_dimensions:
        raise ProtocolError(
            "Institutional maturity dimensions must use the ratified order: "
            f"{expected_dimensions}"
        )
    evidence_rules = standard.get("evidence_rules")
    if not isinstance(evidence_rules, dict) or not all(
        evidence_rules.values()
    ):
        raise ProtocolError(
            "Every institutional maturity evidence rule must remain enabled."
        )
    benchmarks = standard.get("benchmarks")
    if not isinstance(benchmarks, dict) or list(benchmarks) != ["L2", "L3"]:
        raise ProtocolError(
            "Institutional maturity must define exactly L2 and L3 benchmarks."
        )
    expected_metrics = {
        "L2": {
            "observation-window": ("at-least", 30, "days"),
            "real-hosted-work-items": ("at-least", 20, "count"),
            "reviewable-pr-without-internal-inspection": (
                "at-least",
                9000,
                "basis-points",
            ),
            "identity-trace-test-provenance-coverage": (
                "exactly",
                10000,
                "basis-points",
            ),
            "authority-escapes": ("exactly", 0, "count"),
            "secret-exposures": ("exactly", 0, "count"),
        },
        "L3": {
            "observation-window": ("at-least", 30, "days"),
            "real-bounded-canaries": ("at-least", 20, "count"),
            "injected-rollback-exercises": ("at-least", 3, "count"),
            "threshold-breach-rollback-conformance": (
                "exactly",
                10000,
                "basis-points",
            ),
            "automatic-full-rollouts": ("exactly", 0, "count"),
            "authority-escapes": ("exactly", 0, "count"),
        },
    }
    required_prohibitions = {
        "L2": {
            "merge",
            "release",
            "deployment",
            "maturity-mutation",
            "automatic-certification-renewal",
        },
        "L3": {
            "automatic-full-rollout",
            "uncertified-class-expansion",
            "merge",
            "maturity-mutation",
            "automatic-certification-renewal",
        },
    }
    for level_id, benchmark in benchmarks.items():
        if benchmark.get("level") != level_id:
            raise ProtocolError(
                f"Institutional benchmark '{level_id}' has the wrong level."
            )
        prohibited = set(benchmark.get("prohibited_consequences", []))
        if not required_prohibitions[level_id] <= prohibited:
            raise ProtocolError(
                f"Institutional benchmark '{level_id}' weakens its authority boundary."
            )
        metrics = benchmark.get("metrics")
        if not isinstance(metrics, list):
            raise ProtocolError(
                f"Institutional benchmark '{level_id}' needs metrics."
            )
        metric_map = {
            metric.get("id"): (
                metric.get("comparison"),
                metric.get("value"),
                metric.get("unit"),
            )
            for metric in metrics
        }
        if metric_map != expected_metrics[level_id]:
            raise ProtocolError(
                f"Institutional benchmark '{level_id}' metrics differ from "
                "the ratified standard."
            )
    version = standard["version"]
    expected_digest = INSTITUTIONAL_MATURITY_STANDARD_DIGESTS.get(version)
    actual_digest = canonical_sha256(
        {
            key: value
            for key, value in standard.items()
            if key != "content_sha256"
        }
    )
    if (
        not expected_digest
        or standard.get("content_sha256") != actual_digest
        or actual_digest != expected_digest
    ):
        raise ProtocolError(
            "Institutional factory maturity standard payload differs from "
            f"ratified version '{version}'."
        )
    levels = model.get("levels")
    if not isinstance(levels, list):
        raise ProtocolError("Operational maturity must define levels.")
    expected = ["L0", "L1", "L2", "L3", "L4", "L5"]
    if [level.get("id") for level in levels] != expected:
        raise ProtocolError(f"Operational maturity levels must be ordered as: {expected}")
    for level in levels:
        if not level.get("required_capabilities") or not level.get("required_evidence"):
            raise ProtocolError(
                f"Operational maturity level '{level['id']}' needs capabilities and evidence."
            )
    assessment = model.get("current_assessment")
    if not isinstance(assessment, dict):
        raise ProtocolError("Operational maturity needs a current assessment.")
    if assessment.get("level") not in expected:
        raise ProtocolError("Operational maturity assessment has an invalid level.")
    if not assessment.get("evidence") or not assessment.get("blockers"):
        raise ProtocolError(
            "Operational maturity assessment needs evidence and blockers."
        )


def _validate_ontology(ontology: dict[str, Any]) -> None:
    entity_types = ontology.get("entity_types")
    relation_types = ontology.get("relation_types")
    if not isinstance(entity_types, list) or not entity_types:
        raise ProtocolError("Ontology must define entity_types.")
    if not isinstance(relation_types, list) or not relation_types:
        raise ProtocolError("Ontology must define relation_types.")
    require_unique_ids(entity_types, "ontology entity type")
    require_unique_ids(relation_types, "ontology relation type")
    entity_ids = {entity["id"] for entity in entity_types}
    for relation in relation_types:
        if not isinstance(relation.get("from"), list) or not relation["from"]:
            raise ProtocolError(f"Ontology relation '{relation['id']}' needs from types.")
        if not isinstance(relation.get("to"), list) or not relation["to"]:
            raise ProtocolError(f"Ontology relation '{relation['id']}' needs to types.")
        unknown = (set(relation["from"]) | set(relation["to"])) - entity_ids
        if unknown:
            raise ProtocolError(
                f"Ontology relation '{relation['id']}' uses unknown entities: {sorted(unknown)}"
            )


def _validate_authority_matrix(
    matrix: dict[str, Any],
    role_registry: dict[str, Any],
) -> None:
    actions = set(matrix.get("actions", []))
    subjects = set(matrix.get("subjects", []))
    canonical_roles = {role["id"] for role in role_registry["roles"]}
    if subjects != canonical_roles:
        raise ProtocolError(
            "Authority matrix subjects must exactly match the canonical role registry."
        )
    resources = matrix.get("resources", [])
    require_unique_ids(resources, "authority resource")
    for resource in resources:
        permissions = resource.get("permissions")
        if not isinstance(permissions, dict):
            raise ProtocolError(
                f"Authority resource '{resource['id']}' needs permissions."
            )
        for subject, allowed_actions in permissions.items():
            if subject not in subjects:
                raise ProtocolError(
                    f"Authority resource '{resource['id']}' uses unknown subject '{subject}'."
                )
            unknown_actions = set(allowed_actions) - actions
            if unknown_actions:
                raise ProtocolError(
                    f"Authority resource '{resource['id']}' uses unknown actions: "
                    f"{sorted(unknown_actions)}"
                )
    constitution = next(
        (resource for resource in resources if resource["id"] == "constitution"), None
    )
    if constitution is None:
        raise ProtocolError("Authority matrix must define the constitution resource.")
    for subject, allowed_actions in constitution["permissions"].items():
        if subject not in HUMAN_APPROVAL_ROLES and (
            {"modify", "approve", "promote"} & set(allowed_actions)
        ):
            raise ProtocolError(
                f"Non-human subject '{subject}' has constitutional mutation authority."
            )


def validate_protocol() -> dict[str, dict[str, Any]]:
    required_paths = [
        ROOT / "AGENTS.md",
        ROOT / "CONTEXT.md",
        ROOT / "ELDER_PROTOCOL.md",
        ROOT / "ROADMAP.md",
        ROOT / "docs" / "golden-path.md",
        ROOT / "docs" / "git-change-protocol.md",
        ROOT / "docs" / "operational-readiness.md",
        ROOT / "docs" / "adr" / "0001-protocol-kernel.md",
        ROOT / "docs" / "adr" / "0004-hierarchical-meta-architecture.md",
        ROOT / "docs" / "adr" / "0005-p4-assurance-constitution.md",
        ROOT / "docs" / "adr" / "0006-p4-1-operational-assurance.md",
        ROOT / "docs" / "adr" / "0007-p4-2-evaluation-harness.md",
        ROOT / "docs" / "adr" / "0008-p4-3-correlated-telemetry.md",
        ROOT / "docs" / "adr" / "0009-p4-4-governed-knowledge-runtime.md",
        ROOT / "docs" / "adr" / "0010-p4-5a-multi-agent-entry-gate.md",
        ROOT / "docs" / "adr" / "0011-p4-5b-bounded-multi-agent-runtime.md",
        ROOT / "docs" / "adr" / "0012-p4-6-quarantined-learning-runtime.md",
        ROOT / "docs" / "adr" / "0013-p4-7-hosted-production-qualification.md",
        ROOT / "docs" / "adr" / "0014-p5-0-autonomy-class-contracts.md",
        ROOT / "docs" / "adr" / "0015-p5-1-certification-simulation.md",
        ROOT / "docs" / "adr" / "0016-p5-2-supervised-autonomous-prs.md",
        ROOT / "docs" / "adr" / "0019-mem0-luna-memory-dreaming.md",
        ROOT / "docs" / "meta-architecture.md",
        ROOT / "docs" / "p4-assurance-architecture.md",
        ROOT / "docs" / "p4-1-operational-assurance.md",
        ROOT / "docs" / "p4-2-evaluation-harness.md",
        ROOT / "docs" / "p4-3-correlated-telemetry.md",
        ROOT / "docs" / "p4-4-governed-knowledge-runtime.md",
        ROOT / "docs" / "p4-5a-multi-agent-entry-gate.md",
        ROOT / "docs" / "p4-5b-bounded-multi-agent-runtime.md",
        ROOT / "docs" / "p4-6-quarantined-learning-runtime.md",
        ROOT / "docs" / "p4-7-hosted-production-qualification.md",
        ROOT / "docs" / "p5-0-autonomy-class-contracts.md",
        ROOT / "docs" / "p5-1-certification-simulation.md",
        ROOT / "docs" / "p5-2-supervised-autonomous-prs.md",
        ROOT / "docs" / "design-governance.md",
        ROOT / "docs" / "software-factory" / "09-source-licensing-and-provenance.md",
        ROOT / "docs" / "software-factory" / "11-canonical-factory-domain.md",
        ROOT / "docs" / "software-factory" / "12-stable-contracts-and-events.md",
        ROOT / "docs" / "software-factory" / "research-sources.json",
        ROOT / "docs" / "software-factory" / "research-sources.schema.json",
        ROOT / "docs" / "software-factory" / "source-update-procedure.md",
        ROOT
        / "docs"
        / "software-factory"
        / "templates"
        / "third-party-attribution.md",
        ROOT / "factory" / "factory-domain.json",
        ROOT / "factory" / "factory-domain.schema.json",
        ROOT / "factory" / "factory-entity.schema.json",
        ROOT / "factory" / "factory-contracts.json",
        ROOT / "factory" / "factory-contracts.schema.json",
        ROOT / "factory" / "factory-command.schema.json",
        ROOT / "factory" / "factory-event.schema.json",
        ROOT / "factory" / "factory-adapter-request.schema.json",
        ROOT / "factory" / "factory-adapter-response.schema.json",
        ROOT / "factory" / "factory-cursor.schema.json",
    ]
    missing = [str(path.relative_to(ROOT)) for path in required_paths if not path.is_file()]
    if missing:
        raise ProtocolError(f"Missing kernel files: {', '.join(missing)}")

    data = protocol_data()
    validate_schema_catalog(PROTOCOL_DIR)
    for name, document in data.items():
        if name.endswith(".schema"):
            if document.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
                raise ProtocolError(f"Schema '{name}' must use JSON Schema draft 2020-12.")
        elif document.get("version") != PROTOCOL_VERSION:
            raise ProtocolError(
                f"Protocol document '{name}' must use version {PROTOCOL_VERSION}."
            )
    schema_bindings = {
        "autonomy-authority-source": "autonomy-authority-source.schema.json",
        "autonomy-classes": "autonomy-class.schema.json",
        "autonomy-policy": "autonomy-policy.schema.json",
        "capability-packs": "capability-pack.schema.json",
        "context-policy": "context-policy.schema.json",
        "delegation-policy": "delegation-policy.schema.json",
        "design-registry": "design-registry.schema.json",
        "evaluation-dataset": "evaluation-dataset.schema.json",
        "evaluation-registry": "evaluation-registry.schema.json",
        "evaluator-contract": "evaluator-contract.schema.json",
        "judgment-rubric": "judgment-rubric.schema.json",
        "learning-policy": "learning-policy.schema.json",
        "repository-dreaming-policy": "repository-dreaming-policy.schema.json",
        "memory-policy": "memory-policy.schema.json",
        "multi-agent-runtime-policy": "multi-agent-runtime-policy.schema.json",
        "operational-maturity": "operational-maturity.schema.json",
        "protocol-graph": "protocol-graph.schema.json",
        "qualification-policy": "qualification-policy.schema.json",
        "recommendation-ledger": "recommendation-ledger.schema.json",
        "role-registry": "role-registry.schema.json",
        "stack-adapter-registry": "stack-adapter-registry.schema.json",
        "telemetry-contract": "telemetry-contract.schema.json",
        "transcript-review-policy": "transcript-review-policy.schema.json",
    }
    for document_name, schema_name in schema_bindings.items():
        validate_against_schema(
            data[document_name],
            schema_name,
            label=f"Protocol document '{document_name}'",
        )

    invariants = data["invariants"].get("invariants", [])
    change_classes = data["change-classes"].get("classes", [])
    packs = data["capability-packs"].get("packs", [])
    for items, label in [
        (invariants, "invariant"),
        (change_classes, "change class"),
        (packs, "capability pack"),
    ]:
        if not isinstance(items, list) or not items:
            raise ProtocolError(f"Protocol must define at least one {label}.")
        require_unique_ids(items, label)

    _validate_pack_graph(packs)
    validate_role_registry(data["role-registry"])
    validate_delegation_policy(data["delegation-policy"])
    validate_runtime_policy(data["multi-agent-runtime-policy"])
    validate_stack_adapter_registry(
        data["stack-adapter-registry"],
        data["capability-packs"]["packs"],
    )
    _validate_meta_architecture(data["meta-architecture"])
    _validate_capability_pack_contract(packs, data)
    required_pack_ids = {pack["id"] for pack in packs if pack["required"]}
    mandatory = {"core", "factory-operations", "assurance"}
    if not mandatory <= required_pack_ids:
        raise ProtocolError(
            f"Capability packs must define mandatory packs: {sorted(mandatory)}"
        )
    _validate_recommendation_ledger(data["recommendation-ledger"], data)
    _validate_judgment_rubric(data["judgment-rubric"])
    _validate_operational_maturity(data["operational-maturity"])
    validate_design_registry(PROTOCOL_DIR / "design-registry.json", ROOT)
    canonical_roles = {
        role["id"] for role in data["role-registry"]["roles"]
    }
    known_change_classes = {
        item["id"] for item in data["change-classes"]["classes"]
    }
    for document in data["design-registry"]["documents"]:
        unknown_roles = (
            set(document["owners"]) | set(document["notifies"])
        ) - canonical_roles
        if unknown_roles:
            raise ProtocolError(
                f"Design document '{document['id']}' uses non-canonical roles: "
                f"{sorted(unknown_roles)}"
            )
        unknown_change_classes = (
            set(document["change_classes"]) - known_change_classes
        )
        if unknown_change_classes:
            raise ProtocolError(
                f"Design document '{document['id']}' uses unknown change classes: "
                f"{sorted(unknown_change_classes)}"
            )
    validate_transcript_review_policy(
        PROTOCOL_DIR / "transcript-review-policy.json"
    )
    validate_evaluation_registry(
        PROTOCOL_DIR / "evaluation-registry.json",
        ROOT,
    )
    validate_evaluation_dataset(PROTOCOL_DIR / "evaluation-dataset.json")
    validate_evaluator_contract(PROTOCOL_DIR / "evaluator-contract.json")
    validate_telemetry_contract(data["telemetry-contract"])
    validate_context_policy(data["context-policy"])
    validate_memory_policy(data["memory-policy"])
    validate_learning_policy(data["learning-policy"])
    validate_qualification_policy(
        data["qualification-policy"],
        data["operational-maturity"],
    )
    validate_autonomy_authority_source(data["autonomy-authority-source"])
    validate_autonomy_policy(
        data["autonomy-policy"],
        data["autonomy-classes"],
        data["change-classes"],
        qualification_policy=data["qualification-policy"],
        maturity_model=data["operational-maturity"],
    )
    validate_research_sources(
        ROOT / "docs" / "software-factory" / "research-sources.json",
        ROOT,
    )
    validate_factory_domain()
    validate_factory_contracts()
    for change_class in change_classes:
        if change_class.get("maximum_autonomy") not in AUTONOMY_LEVELS:
            raise ProtocolError(
                f"Change class '{change_class['id']}' has an invalid autonomy level."
            )
        unknown_approvals = (
            set(change_class.get("required_approvals", [])) - canonical_roles
        )
        if unknown_approvals:
            raise ProtocolError(
                f"Change class '{change_class['id']}' uses non-canonical approvals: "
                f"{sorted(unknown_approvals)}"
            )

    valid_statuses = {"implemented", "specified", "planned", "blocked"}
    for invariant in invariants:
        required = {
            "id",
            "statement",
            "scope",
            "owner",
            "enforcement",
            "verification",
            "exception_authority",
            "status",
        }
        if set(invariant) != required:
            raise ProtocolError(
                f"Invariant '{invariant.get('id')}' fields must be exactly: {sorted(required)}"
            )
        if invariant["status"] not in valid_statuses:
            raise ProtocolError(f"Invariant '{invariant['id']}' has an invalid status.")
        if invariant["owner"] not in canonical_roles:
            raise ProtocolError(
                f"Invariant '{invariant['id']}' uses non-canonical owner "
                f"'{invariant['owner']}'."
            )
        if (
            invariant["exception_authority"] != "none"
            and invariant["exception_authority"] not in canonical_roles
        ):
            raise ProtocolError(
                f"Invariant '{invariant['id']}' uses non-canonical exception authority."
            )

    _validate_ontology(data["ontology"])
    _validate_authority_matrix(data["authority-matrix"], data["role-registry"])
    validate_skill_registry(PROTOCOL_DIR / "skill-registry.json", SKILLS_DIR)
    validate_graph(data["protocol-graph"])
    expected_graph = build_protocol_graph(data)
    if data["protocol-graph"] != expected_graph:
        raise ProtocolError(
            "protocol/protocol-graph.json is stale; regenerate it from protocol truth."
        )
    return data
