from __future__ import annotations

import copy
import hashlib
import json
import re
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.qualification import LEVELS, qualify_hosted_bundle


SHA256_PATTERN = re.compile(r"^[a-f0-9]{64}$")
INITIAL_AUTONOMY_CLASSES = [
    "documentation-only-correction",
    "deterministic-generated-regeneration",
    "semantic-preserving-formatting",
    "deterministic-lint-fix",
    "add-only-tests",
]
HARD_STOPS = [
    "invalid-qualification",
    "expired",
    "suspended",
    "revoked",
    "contradicted",
    "incident-budget-exhausted",
]


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _content_digest(value: dict[str, Any]) -> str:
    return canonical_sha256(
        {key: item for key, item in value.items() if key != "content_sha256"}
    )


def _require_fields(
    value: Any,
    required: set[str],
    label: str,
) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != required:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(required)}")
    return value


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value


def _require_concrete_project_path(value: Any, label: str) -> str:
    path = _require_string(value, label)
    if "\\" in path or any(character in path for character in "*?["):
        raise ProtocolError(
            f"{label} must be a concrete normalized path without wildcard characters."
        )
    pure = PurePosixPath(path)
    if pure.is_absolute() or ".." in pure.parts or "." in pure.parts:
        raise ProtocolError(f"{label} must be a normalized project-relative path.")
    normalized = pure.as_posix()
    if normalized in {"", "."} or normalized != path:
        raise ProtocolError(f"{label} must be a normalized project-relative path.")
    return normalized


def _require_string_list(
    value: Any,
    label: str,
    *,
    allow_empty: bool = False,
) -> list[str]:
    if (
        not isinstance(value, list)
        or (not allow_empty and not value)
        or any(not isinstance(item, str) or not item.strip() for item in value)
    ):
        qualifier = "" if allow_empty else "non-empty "
        raise ProtocolError(f"{label} must be a {qualifier}list of strings.")
    if len(value) != len(set(value)):
        raise ProtocolError(f"{label} cannot contain duplicates.")
    return value


def _require_sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None:
        raise ProtocolError(
            f"{label} must be 64 lowercase hexadecimal characters."
        )
    return value


def _require_level(value: Any, label: str) -> str:
    if value not in LEVELS:
        raise ProtocolError(f"{label} must be one of: {LEVELS}")
    return value


def _parse_datetime(value: Any, label: str) -> datetime:
    _require_string(value, label)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO-8601 datetime.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


def _verify_content_digest(value: dict[str, Any], label: str) -> None:
    _require_sha256(value.get("content_sha256"), f"{label} content_sha256")
    if value["content_sha256"] != _content_digest(value):
        raise ProtocolError(f"{label} content digest does not match its fields.")


def trust_anchor_set_sha256(qualification_policy: dict[str, Any]) -> str:
    anchors = qualification_policy.get("trust", {}).get("anchors")
    if not isinstance(anchors, list):
        raise ProtocolError("Qualification policy trust anchors must be a list.")
    if any(not isinstance(anchor, dict) or not anchor.get("id") for anchor in anchors):
        raise ProtocolError("Every qualification trust anchor requires an id.")
    normalized = sorted(anchors, key=lambda anchor: anchor["id"])
    return canonical_sha256(normalized)


def validate_autonomy_policy(
    policy: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    *,
    qualification_policy: dict[str, Any] | None = None,
    maturity_model: dict[str, Any] | None = None,
) -> dict[str, Any]:
    _require_fields(
        policy,
        {
            "version",
            "id",
            "mode",
            "levels",
            "effective_autonomy",
            "qualification_consumption",
            "certification",
            "incident_budget",
            "simulation",
            "supervised_pr",
            "canary",
            "authority",
        },
        "Autonomy policy",
    )
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy policy version must be '{PROTOCOL_VERSION}'."
        )
    if policy["id"] != "elder-bounded-autonomy-v1":
        raise ProtocolError("Autonomy policy id is invalid.")
    if policy["mode"] != "qualification-gated-supervised-pr":
        raise ProtocolError(
            "P5.2 autonomy policy must remain qualification-gated."
        )
    if policy["levels"] != LEVELS:
        raise ProtocolError(f"Autonomy levels must be ordered as: {LEVELS}")

    calculation = _require_fields(
        policy["effective_autonomy"],
        {"calculation", "operands", "hard_stops", "no_authority_result"},
        "Effective autonomy policy",
    )
    if calculation["calculation"] != "minimum":
        raise ProtocolError("Effective autonomy must use a minimum calculation.")
    if calculation["operands"] != [
        "verified_hosted_maturity",
        "project_autonomy_ceiling",
        "change_class_maximum",
        "active_certification_level",
    ]:
        raise ProtocolError("Effective autonomy operands are incomplete or reordered.")
    if calculation["hard_stops"] != HARD_STOPS:
        raise ProtocolError("Effective autonomy hard stops are incomplete or reordered.")
    if calculation["no_authority_result"] != "none":
        raise ProtocolError("A hard stop must resolve effective autonomy to none.")

    consumption = _require_fields(
        policy["qualification_consumption"],
        {
            "mode",
            "require_qualified",
            "require_project_match",
            "require_environment_match",
            "require_artifact_match",
            "require_current_evidence",
            "require_no_newer_contradiction",
            "require_no_suspension",
            "require_no_revocation",
            "approved_policy_sha256",
            "approved_maturity_model_sha256",
            "approved_trust_anchor_set_sha256",
        },
        "Qualification consumption policy",
    )
    required_consumption = {
        "mode": "reverify-pinned-inputs",
        "require_qualified": True,
        "require_project_match": True,
        "require_environment_match": True,
        "require_artifact_match": True,
        "require_current_evidence": True,
        "require_no_newer_contradiction": True,
        "require_no_suspension": True,
        "require_no_revocation": True,
    }
    for key, expected in required_consumption.items():
        if consumption[key] != expected:
            raise ProtocolError(
                f"Qualification consumption field '{key}' must be {expected!r}."
            )
    for field in [
        "approved_policy_sha256",
        "approved_maturity_model_sha256",
        "approved_trust_anchor_set_sha256",
    ]:
        _require_sha256(consumption[field], f"Qualification consumption {field}")
    if qualification_policy is not None:
        if consumption["approved_policy_sha256"] != canonical_sha256(
            qualification_policy
        ):
            raise ProtocolError(
                "Autonomy policy does not pin the canonical qualification policy."
            )
        if (
            consumption["approved_trust_anchor_set_sha256"]
            != trust_anchor_set_sha256(qualification_policy)
        ):
            raise ProtocolError(
                "Autonomy policy does not pin the canonical trust-anchor set."
            )
    if maturity_model is not None and consumption[
        "approved_maturity_model_sha256"
    ] != canonical_sha256(maturity_model):
        raise ProtocolError(
            "Autonomy policy does not pin the canonical maturity model."
        )

    certification = _require_fields(
        policy["certification"],
        {
            "allowed_statuses",
            "required_issuer_roles",
            "renewal_roles",
            "revocation_roles",
            "suspension_roles",
            "require_independent_evaluator",
            "require_expiry",
        },
        "Autonomy certification policy",
    )
    if certification["allowed_statuses"] != [
        "candidate",
        "active",
        "suspended",
        "revoked",
        "expired",
    ]:
        raise ProtocolError("Autonomy certification statuses are invalid.")
    expected_human_roles = {
        "human-owner",
        "architecture-owner",
        "security-owner",
        "release-owner",
    }
    for field in [
        "required_issuer_roles",
        "renewal_roles",
        "revocation_roles",
        "suspension_roles",
    ]:
        roles = set(_require_string_list(certification[field], field))
        if not roles <= expected_human_roles:
            raise ProtocolError(f"Autonomy policy {field} uses non-accountable roles.")
    if certification["require_independent_evaluator"] is not True:
        raise ProtocolError("Autonomy certification requires an independent evaluator.")
    if certification["require_expiry"] is not True:
        raise ProtocolError("Autonomy certification requires expiry.")

    incident_budget = _require_fields(
        policy["incident_budget"],
        {"require_window", "suspend_when_exhausted", "allow_negative_remaining"},
        "Autonomy incident-budget policy",
    )
    if incident_budget != {
        "require_window": True,
        "suspend_when_exhausted": True,
        "allow_negative_remaining": False,
    }:
        raise ProtocolError(
            "Incident budgets must be windowed, fail closed, and suspend on exhaustion."
        )

    simulation = _require_fields(
        policy["simulation"],
        {
            "mode",
            "require_exact_class_match",
            "require_certified_scope",
            "require_certified_tool",
            "require_all_checks_pass",
            "deterministic_replay",
            "can_mutate_workspace",
            "can_create_pr",
        },
        "P5.1 autonomy simulation",
    )
    if simulation != {
        "mode": "side-effect-free",
        "require_exact_class_match": True,
        "require_certified_scope": True,
        "require_certified_tool": True,
        "require_all_checks_pass": True,
        "deterministic_replay": True,
        "can_mutate_workspace": False,
        "can_create_pr": False,
    }:
        raise ProtocolError(
            "P5.1 simulation must remain deterministic and side-effect-free."
        )

    supervised_pr = _require_fields(
        policy["supervised_pr"],
        {
            "required_effective_level",
            "lease_ttl_minutes",
            "require_isolated_workspace",
            "require_ordered_test_ladder",
            "require_independent_evaluation",
            "require_hosted_git_governance",
            "require_external_identity",
            "require_evidence_packet",
            "require_human_merge",
            "require_human_release",
            "authority_evidence_maximum_age_minutes",
            "authority_evidence_required_signer_roles",
            "provider_evidence_maximum_age_minutes",
            "provider_evidence_required_signer_roles",
            "provider_evidence_required_controls",
            "require_response_binding",
        },
        "P5.2 supervised PR policy",
    )
    if supervised_pr["required_effective_level"] != "L2":
        raise ProtocolError("P5.2 supervised PRs require effective autonomy L2.")
    if (
        not isinstance(supervised_pr["lease_ttl_minutes"], int)
        or not 1 <= supervised_pr["lease_ttl_minutes"] <= 60
    ):
        raise ProtocolError("P5.2 authority leases must expire within 1-60 minutes.")
    for field in [
        "require_isolated_workspace",
        "require_ordered_test_ladder",
        "require_independent_evaluation",
        "require_hosted_git_governance",
        "require_external_identity",
        "require_evidence_packet",
        "require_human_merge",
        "require_human_release",
        "require_response_binding",
    ]:
        if supervised_pr[field] is not True:
            raise ProtocolError(f"P5.2 supervised PR field '{field}' must be true.")
    for prefix in ["authority", "provider"]:
        field = f"{prefix}_evidence_maximum_age_minutes"
        if (
            not isinstance(supervised_pr[field], int)
            or not 1 <= supervised_pr[field] <= 60
        ):
            raise ProtocolError(
                f"P5.2 {prefix} evidence must expire within 1-60 minutes."
            )
    if supervised_pr["authority_evidence_required_signer_roles"] != [
        "independent-verifier"
    ]:
        raise ProtocolError(
            "P5.2 authority evidence requires an independent verifier."
        )
    if supervised_pr["provider_evidence_required_signer_roles"] != [
        "independent-verifier"
    ]:
        raise ProtocolError(
            "P5.2 provider evidence requires an independent verifier."
        )
    if supervised_pr["provider_evidence_required_controls"] != [
        "remote-present",
        "protected-base-branch",
        "required-checks",
        "signed-provenance",
        "external-identity",
        "isolated-workspace",
        "ordered-tests",
        "independent-evaluation",
    ]:
        raise ProtocolError(
            "P5.2 provider evidence controls are incomplete or reordered."
        )

    canary = _require_fields(
        policy["canary"],
        {
            "required_effective_level",
            "lease_ttl_minutes",
            "maximum_traffic_percent",
            "maximum_duration_minutes",
            "start_response_timeout_minutes",
            "rollback_claim_timeout_minutes",
            "minimum_observation_window_minutes",
            "maximum_rollback_minutes",
            "observation_maximum_age_minutes",
            "governance_evidence_maximum_age_minutes",
            "require_external_identity",
            "require_secret_broker",
            "require_promotion_gate",
            "require_central_telemetry",
            "require_automatic_rollback",
            "require_immutable_predecessor",
            "provider_evidence_maximum_age_minutes",
            "provider_evidence_required_signer_roles",
            "provider_evidence_required_controls",
            "require_response_binding",
        },
        "P5.3 canary policy",
    )
    if canary["required_effective_level"] != "L3":
        raise ProtocolError("P5.3 canary execution requires effective autonomy L3.")
    bounded_integers = {
        "lease_ttl_minutes": (1, 30),
        "maximum_traffic_percent": (1, 25),
        "maximum_duration_minutes": (5, 120),
        "start_response_timeout_minutes": (1, 10),
        "rollback_claim_timeout_minutes": (1, 10),
        "minimum_observation_window_minutes": (1, 30),
        "maximum_rollback_minutes": (1, 30),
        "observation_maximum_age_minutes": (1, 30),
        "governance_evidence_maximum_age_minutes": (1, 10),
        "provider_evidence_maximum_age_minutes": (1, 30),
    }
    for field, (minimum, maximum) in bounded_integers.items():
        value = canary[field]
        if (
            not isinstance(value, int)
            or isinstance(value, bool)
            or not minimum <= value <= maximum
        ):
            raise ProtocolError(
                f"P5.3 canary {field} must be within {minimum}-{maximum}."
            )
    if (
        canary["rollback_claim_timeout_minutes"]
        >= canary["maximum_rollback_minutes"]
    ):
        raise ProtocolError(
            "P5.3 rollback claim timeout must be shorter than the rollback "
            "authorization window."
        )
    for field in [
        "require_external_identity",
        "require_secret_broker",
        "require_promotion_gate",
        "require_central_telemetry",
        "require_automatic_rollback",
        "require_immutable_predecessor",
        "require_response_binding",
    ]:
        if canary[field] is not True:
            raise ProtocolError(f"P5.3 canary field '{field}' must be true.")
    if canary["provider_evidence_required_signer_roles"] != [
        "independent-verifier"
    ]:
        raise ProtocolError(
            "P5.3 provider evidence requires an independent verifier."
        )
    if canary["provider_evidence_required_controls"] != [
        "external-identity",
        "secret-broker",
        "promotion-gate",
        "central-telemetry",
        "rollback-ready",
        "immutable-artifact",
    ]:
        raise ProtocolError(
            "P5.3 provider evidence controls are incomplete or reordered."
        )

    authority = _require_fields(
        policy["authority"],
        {
            "can_activate_certification",
            "can_issue_runtime_lease",
            "can_create_pr",
            "can_execute_canary",
            "can_promote_canary",
            "can_merge",
            "can_deploy",
            "can_mutate_maturity",
            "can_auto_renew",
        },
        "P5.2 autonomy authority",
    )
    if authority != {
        "can_activate_certification": True,
        "can_issue_runtime_lease": True,
        "can_create_pr": True,
        "can_execute_canary": True,
        "can_promote_canary": False,
        "can_merge": False,
        "can_deploy": False,
        "can_mutate_maturity": False,
        "can_auto_renew": False,
    }:
        raise ProtocolError(
            "P5 may activate qualified certifications, issue bounded leases, create "
            "supervised PRs, and execute qualified canaries only; canary promotion, "
            "merge, general deployment, maturity mutation, and automatic renewal "
            "remain forbidden."
        )

    validate_autonomy_class_registry(registry, change_classes)
    return policy


def validate_autonomy_authority_source(
    source: dict[str, Any],
) -> dict[str, Any]:
    _require_fields(
        source,
        {"version", "id", "projects"},
        "Autonomy authority source",
    )
    if source["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy authority-source version must be '{PROTOCOL_VERSION}'."
        )
    if source["id"] != "elder-canonical-autonomy-authority-source-v1":
        raise ProtocolError("Autonomy authority-source id is invalid.")
    projects = source["projects"]
    if not isinstance(projects, list):
        raise ProtocolError("Autonomy authority-source projects must be a list.")
    project_ids: list[str] = []
    for project in projects:
        _require_fields(
            project,
            {
                "project_id",
                "project_autonomy_ceiling",
                "autonomy_policy_sha256",
                "autonomy_classes_sha256",
                "change_classes_sha256",
                "qualification_policy_sha256",
                "maturity_model_sha256",
                "status",
            },
            "Autonomy authority-source project",
        )
        project_id = _require_string(
            project["project_id"], "Autonomy authority-source project_id"
        )
        project_ids.append(project_id)
        _require_level(
            project["project_autonomy_ceiling"],
            f"Autonomy authority-source project '{project_id}' ceiling",
        )
        for field in [
            "autonomy_policy_sha256",
            "autonomy_classes_sha256",
            "change_classes_sha256",
            "qualification_policy_sha256",
            "maturity_model_sha256",
        ]:
            _require_sha256(
                project[field],
                f"Autonomy authority-source project '{project_id}' {field}",
            )
        if project["status"] not in {"active", "revoked"}:
            raise ProtocolError(
                f"Autonomy authority-source project '{project_id}' status is invalid."
            )
    if len(project_ids) != len(set(project_ids)):
        raise ProtocolError("Autonomy authority-source project ids must be unique.")
    return source


def validate_autonomy_class_registry(
    registry: dict[str, Any],
    change_classes: dict[str, Any],
) -> dict[str, Any]:
    _require_fields(
        registry,
        {"version", "id", "classes"},
        "Autonomy class registry",
    )
    if registry["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy class registry version must be '{PROTOCOL_VERSION}'."
        )
    if registry["id"] not in {
        "elder-initial-autonomy-classes-v1",
        "elder-project-autonomy-classes-v1",
    }:
        raise ProtocolError("Autonomy class registry id is invalid.")
    classes = registry["classes"]
    if not isinstance(classes, list) or not classes:
        raise ProtocolError("Autonomy class registry must define classes.")
    canonical_initial_registry = (
        registry["id"] == "elder-initial-autonomy-classes-v1"
    )
    if canonical_initial_registry and [
        item.get("id") for item in classes
    ] != INITIAL_AUTONOMY_CLASSES:
        raise ProtocolError(
            "P5.0 autonomy classes must be the five approved initial classes in order."
        )
    class_ids = [item.get("id") for item in classes]
    if any(not isinstance(class_id, str) or not class_id for class_id in class_ids):
        raise ProtocolError("Every autonomy class must have a non-empty id.")
    if len(class_ids) != len(set(class_ids)):
        raise ProtocolError("Autonomy class ids must be unique.")
    parent_by_id = {
        item["id"]: item for item in change_classes.get("classes", [])
    }
    for autonomy_class in classes:
        _require_fields(
            autonomy_class,
            {
                "id",
                "parent_change_class",
                "risk",
                "maximum_autonomy",
                "allowed_consequences",
                "description",
                "allowed_operations",
                "scope",
                "controls",
                "incident_budget",
                "certification_ttl_days",
            },
            f"Autonomy class '{autonomy_class.get('id')}'",
        )
        class_id = autonomy_class["id"]
        parent = parent_by_id.get(autonomy_class["parent_change_class"])
        if parent is None:
            raise ProtocolError(
                f"Autonomy class '{class_id}' uses an unknown parent change class."
            )
        if autonomy_class["risk"] not in {"low", "moderate"}:
            raise ProtocolError(
                f"Autonomy class '{class_id}' exceeds the initial risk boundary."
            )
        maximum = _require_level(
            autonomy_class["maximum_autonomy"],
            f"Autonomy class '{class_id}' maximum_autonomy",
        )
        if LEVELS.index(maximum) > LEVELS.index(parent["maximum_autonomy"]):
            raise ProtocolError(
                f"Autonomy class '{class_id}' exceeds its parent change class."
            )
        maximum_supported_level = "L2" if canonical_initial_registry else "L3"
        if LEVELS.index(maximum) > LEVELS.index(maximum_supported_level):
            raise ProtocolError(
                f"Autonomy class '{class_id}' cannot exceed "
                f"{maximum_supported_level} in registry '{registry['id']}'."
            )
        allowed_consequences = _require_string_list(
            autonomy_class["allowed_consequences"],
            f"{class_id} allowed_consequences",
        )
        if not set(allowed_consequences) <= {"pull-request", "canary"}:
            raise ProtocolError(
                f"Autonomy class '{class_id}' has an unsupported consequence."
            )
        if canonical_initial_registry and allowed_consequences != ["pull-request"]:
            raise ProtocolError(
                f"Initial autonomy class '{class_id}' permits only pull requests."
            )
        if (
            "canary" in allowed_consequences
            and maximum != "L3"
        ):
            raise ProtocolError(
                f"Canary-capable autonomy class '{class_id}' must be capped at L3."
            )
        _require_string(autonomy_class["description"], f"{class_id} description")
        operations = _require_string_list(
            autonomy_class["allowed_operations"],
            f"{class_id} allowed_operations",
        )
        if not set(operations) <= {"add", "modify", "delete"}:
            raise ProtocolError(
                f"Autonomy class '{class_id}' has an unsupported operation."
            )
        scope = _require_fields(
            autonomy_class["scope"],
            {
                "requires_path_allowlist",
                "allowed_path_globs",
                "forbidden_path_globs",
                "new_files_only",
                "generated_files_only",
                "existing_files_unchanged",
                "generator_inputs_unchanged",
                "production_code_unchanged",
                "test_support_unchanged",
            },
            f"Autonomy class '{class_id}' scope",
        )
        if scope["requires_path_allowlist"] is not True:
            raise ProtocolError(
                f"Autonomy class '{class_id}' requires an exact path allowlist."
            )
        _require_string_list(
            scope["allowed_path_globs"],
            f"{class_id} allowed_path_globs",
        )
        _require_string_list(
            scope["forbidden_path_globs"],
            f"{class_id} forbidden_path_globs",
            allow_empty=True,
        )
        for field in [
            "new_files_only",
            "generated_files_only",
            "existing_files_unchanged",
            "generator_inputs_unchanged",
            "production_code_unchanged",
            "test_support_unchanged",
        ]:
            if not isinstance(scope[field], bool):
                raise ProtocolError(f"Autonomy class '{class_id}' {field} must be boolean.")
        controls = _require_fields(
            autonomy_class["controls"],
            {
                "requires_tool_allowlist",
                "requires_pinned_tool_digest",
                "requires_rule_allowlist",
                "semantic_equivalence",
                "required_checks",
                "forbidden_effects",
            },
            f"Autonomy class '{class_id}' controls",
        )
        if controls["requires_tool_allowlist"] is not True:
            raise ProtocolError(
                f"Autonomy class '{class_id}' requires a tool allowlist."
            )
        for field in ["requires_pinned_tool_digest", "requires_rule_allowlist"]:
            if not isinstance(controls[field], bool):
                raise ProtocolError(f"Autonomy class '{class_id}' {field} must be boolean.")
        if controls["semantic_equivalence"] not in {
            "none",
            "generated-exact",
            "language-adapter",
        }:
            raise ProtocolError(
                f"Autonomy class '{class_id}' has an invalid equivalence control."
            )
        _require_string_list(
            controls["required_checks"],
            f"{class_id} required_checks",
        )
        forbidden_effects = _require_string_list(
            controls["forbidden_effects"],
            f"{class_id} forbidden_effects",
        )
        if {"merge", "deployment", "maturity-mutation"} - set(forbidden_effects):
            raise ProtocolError(
                f"Autonomy class '{class_id}' must forbid merge, deployment, "
                "and maturity mutation."
            )
        budget = _require_fields(
            autonomy_class["incident_budget"],
            {"maximum_incidents", "maximum_rollbacks", "window_days"},
            f"Autonomy class '{class_id}' incident_budget",
        )
        for field in ["maximum_incidents", "maximum_rollbacks"]:
            if not isinstance(budget[field], int) or budget[field] < 0:
                raise ProtocolError(
                    f"Autonomy class '{class_id}' {field} must be non-negative."
                )
        if not isinstance(budget["window_days"], int) or budget["window_days"] <= 0:
            raise ProtocolError(
                f"Autonomy class '{class_id}' window_days must be positive."
            )
        if (
            not isinstance(autonomy_class["certification_ttl_days"], int)
            or autonomy_class["certification_ttl_days"] <= 0
        ):
            raise ProtocolError(
                f"Autonomy class '{class_id}' certification_ttl_days must be positive."
            )

    if canonical_initial_registry:
        by_id = {item["id"]: item for item in classes}
        documentation = by_id["documentation-only-correction"]
        if not documentation["scope"]["production_code_unchanged"]:
            raise ProtocolError(
                "Documentation-only autonomy cannot modify production code."
            )
        required_documentation_exclusions = {
            "AGENTS.md",
            "**/AGENTS.md",
            "**/ARCHITECTURE.md",
            "protocol/**",
            ".elder/**",
            "**/adr/**",
            "**/architecture/**",
            "**/generated/**",
            "**/*policy*.md",
            "**/prompts/**",
            "**/runbooks/**",
        }
        if required_documentation_exclusions - set(
            documentation["scope"]["forbidden_path_globs"]
        ):
            raise ProtocolError(
                "Documentation-only autonomy must exclude governed, architecture, "
                "generated, prompt, policy, and runbook files."
            )
        regeneration = by_id["deterministic-generated-regeneration"]
        if not (
            regeneration["scope"]["generated_files_only"]
            and regeneration["scope"]["generator_inputs_unchanged"]
        ):
            raise ProtocolError(
                "Generated regeneration requires generated-only output and unchanged inputs."
            )
        formatting = by_id["semantic-preserving-formatting"]
        if formatting["controls"]["semantic_equivalence"] != "language-adapter":
            raise ProtocolError(
                "Formatting autonomy requires a semantic-equivalence adapter."
            )
        lint = by_id["deterministic-lint-fix"]
        if not (
            lint["controls"]["requires_rule_allowlist"]
            and lint["controls"]["requires_pinned_tool_digest"]
        ):
            raise ProtocolError(
                "Lint autonomy requires pinned tools and approved rules."
            )
        tests = by_id["add-only-tests"]
        if not (
            tests["scope"]["new_files_only"]
            and tests["scope"]["existing_files_unchanged"]
            and tests["scope"]["production_code_unchanged"]
            and tests["scope"]["test_support_unchanged"]
        ):
            raise ProtocolError(
                "Test autonomy must be add-only and preserve existing code and test support."
            )
    return registry


def validate_certification(
    certification: dict[str, Any],
    *,
    policy: dict[str, Any],
    autonomy_class: dict[str, Any],
) -> dict[str, Any]:
    _require_fields(
        certification,
        {
            "version",
            "certification_id",
            "project_id",
            "environment",
            "autonomy_class_id",
            "certification_level",
            "status",
            "scope_paths",
            "tool_bindings",
            "issued_by",
            "issuer_role",
            "evaluator_id",
            "issued_at",
            "valid_from",
            "valid_until",
            "qualification_consumption_sha256",
            "incident_budget_id",
            "evidence",
            "content_sha256",
        },
        "Autonomy certification",
    )
    if certification["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy certification version must be '{PROTOCOL_VERSION}'."
        )
    certification_id = _require_string(
        certification["certification_id"], "Autonomy certification id"
    )
    _require_string(certification["project_id"], "Certification project_id")
    _require_string(certification["environment"], "Certification environment")
    if certification["autonomy_class_id"] != autonomy_class["id"]:
        raise ProtocolError(
            f"Certification '{certification_id}' does not match its autonomy class."
        )
    level = _require_level(
        certification["certification_level"], "Certification level"
    )
    if LEVELS.index(level) > LEVELS.index(autonomy_class["maximum_autonomy"]):
        raise ProtocolError(
            f"Certification '{certification_id}' exceeds its class maximum."
        )
    if certification["status"] not in policy["certification"]["allowed_statuses"]:
        raise ProtocolError(f"Certification '{certification_id}' status is invalid.")
    scope_paths = _require_string_list(
        certification["scope_paths"], "Certification scope_paths"
    )
    normalized_scope_paths = [
        _require_concrete_project_path(path, "Certification scope path")
        for path in scope_paths
    ]
    if normalized_scope_paths != scope_paths:
        raise ProtocolError("Certification scope paths must already be normalized.")
    tool_bindings = certification["tool_bindings"]
    if not isinstance(tool_bindings, list) or not tool_bindings:
        raise ProtocolError("Certification tool_bindings must be a non-empty list.")
    tool_ids: list[str] = []
    for index, binding in enumerate(tool_bindings):
        _require_fields(
            binding,
            {"id", "digest_sha256", "rule_ids"},
            f"Certification tool binding {index}",
        )
        tool_id = _require_string(
            binding["id"], f"Certification tool binding {index} id"
        )
        tool_ids.append(tool_id)
        if binding["digest_sha256"] is not None:
            _require_sha256(
                binding["digest_sha256"],
                f"Certification tool binding '{tool_id}' digest_sha256",
            )
        _require_string_list(
            binding["rule_ids"],
            f"Certification tool binding '{tool_id}' rule_ids",
            allow_empty=True,
        )
    if len(tool_ids) != len(set(tool_ids)):
        raise ProtocolError("Certification tool bindings cannot repeat tool ids.")
    if autonomy_class["controls"]["requires_pinned_tool_digest"] and any(
        binding["digest_sha256"] is None for binding in tool_bindings
    ):
        raise ProtocolError(
            f"Certification '{certification_id}' requires pinned tool digests."
        )
    if autonomy_class["controls"]["requires_rule_allowlist"] and any(
        not binding["rule_ids"] for binding in tool_bindings
    ):
        raise ProtocolError(
            f"Certification '{certification_id}' requires tool rule allowlists."
        )
    issued_by = _require_string(certification["issued_by"], "Certification issued_by")
    if certification["issuer_role"] not in policy["certification"][
        "required_issuer_roles"
    ]:
        raise ProtocolError(
            f"Certification '{certification_id}' issuer role is not permitted."
        )
    evaluator_id = _require_string(
        certification["evaluator_id"], "Certification evaluator_id"
    )
    if issued_by == evaluator_id:
        raise ProtocolError("Certification issuer and evaluator must be independent.")
    issued_at = _parse_datetime(certification["issued_at"], "Certification issued_at")
    valid_from = _parse_datetime(certification["valid_from"], "Certification valid_from")
    valid_until = _parse_datetime(
        certification["valid_until"], "Certification valid_until"
    )
    if valid_from < issued_at or valid_until <= valid_from:
        raise ProtocolError(
            "Certification validity must begin at or after issue and end later."
        )
    maximum_ttl_seconds = autonomy_class["certification_ttl_days"] * 24 * 60 * 60
    if (valid_until - valid_from).total_seconds() > maximum_ttl_seconds:
        raise ProtocolError(
            f"Certification '{certification_id}' exceeds its class TTL."
        )
    _require_sha256(
        certification["qualification_consumption_sha256"],
        "Certification qualification_consumption_sha256",
    )
    _require_string(certification["incident_budget_id"], "Certification budget id")
    _require_string_list(certification["evidence"], "Certification evidence")
    _verify_content_digest(certification, f"Certification '{certification_id}'")
    return certification


def validate_incident_budget(record: dict[str, Any]) -> dict[str, Any]:
    _require_fields(
        record,
        {
            "version",
            "budget_id",
            "certification_id",
            "autonomy_class_id",
            "window_started_at",
            "window_ends_at",
            "maximum_incidents",
            "incident_count",
            "maximum_rollbacks",
            "rollback_count",
            "exhausted",
            "evidence",
            "content_sha256",
        },
        "Incident budget",
    )
    if record["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Incident budget version must be '{PROTOCOL_VERSION}'."
        )
    budget_id = _require_string(record["budget_id"], "Incident budget id")
    _require_string(record["certification_id"], "Incident budget certification_id")
    _require_string(record["autonomy_class_id"], "Incident budget autonomy_class_id")
    started = _parse_datetime(record["window_started_at"], "Incident budget start")
    ends = _parse_datetime(record["window_ends_at"], "Incident budget end")
    if ends <= started:
        raise ProtocolError("Incident budget window must end after it starts.")
    for field in [
        "maximum_incidents",
        "incident_count",
        "maximum_rollbacks",
        "rollback_count",
    ]:
        if not isinstance(record[field], int) or record[field] < 0:
            raise ProtocolError(f"Incident budget {field} must be non-negative.")
    exhausted = (
        record["incident_count"] > record["maximum_incidents"]
        or record["rollback_count"] > record["maximum_rollbacks"]
    )
    if record["exhausted"] is not exhausted:
        raise ProtocolError(
            f"Incident budget '{budget_id}' exhausted flag is inconsistent."
        )
    _require_string_list(record["evidence"], "Incident budget evidence", allow_empty=True)
    _verify_content_digest(record, f"Incident budget '{budget_id}'")
    return record


def validate_qualification_consumption(
    record: dict[str, Any],
    *,
    policy: dict[str, Any],
) -> dict[str, Any]:
    _require_fields(
        record,
        {
            "version",
            "consumption_id",
            "report_id",
            "bundle_id",
            "project_id",
            "environment",
            "artifact_sha256",
            "requested_level",
            "achieved_level",
            "qualified",
            "evaluated_at",
            "valid_until",
            "policy_sha256",
            "maturity_model_sha256",
            "trust_anchor_set_sha256",
            "bundle_sha256",
            "contradiction_check",
            "suspension_check",
            "revocation_check",
            "reverified",
            "content_sha256",
        },
        "Qualification consumption",
    )
    if record["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Qualification consumption version must be '{PROTOCOL_VERSION}'."
        )
    consumption_id = _require_string(
        record["consumption_id"], "Qualification consumption id"
    )
    for field in ["report_id", "bundle_id", "project_id", "environment"]:
        _require_string(record[field], f"Qualification consumption {field}")
    _require_sha256(record["artifact_sha256"], "Qualification artifact_sha256")
    requested = _require_level(record["requested_level"], "Requested autonomy level")
    achieved = _require_level(record["achieved_level"], "Achieved maturity level")
    if LEVELS.index(achieved) < LEVELS.index(requested):
        raise ProtocolError(
            f"Qualification consumption '{consumption_id}' does not reach its request."
        )
    if record["qualified"] is not True or record["reverified"] is not True:
        raise ProtocolError(
            "Qualification consumption must be qualified and deterministically reverified."
        )
    evaluated_at = _parse_datetime(
        record["evaluated_at"], "Qualification evaluated_at"
    )
    valid_until = _parse_datetime(record["valid_until"], "Qualification valid_until")
    if valid_until <= evaluated_at:
        raise ProtocolError("Qualification consumption must remain valid after evaluation.")
    pinned = policy["qualification_consumption"]
    for field, policy_field in [
        ("policy_sha256", "approved_policy_sha256"),
        ("maturity_model_sha256", "approved_maturity_model_sha256"),
        ("trust_anchor_set_sha256", "approved_trust_anchor_set_sha256"),
    ]:
        _require_sha256(record[field], f"Qualification consumption {field}")
        if record[field] != pinned[policy_field]:
            raise ProtocolError(
                f"Qualification consumption '{consumption_id}' uses an unapproved {field}."
            )
    _require_sha256(record["bundle_sha256"], "Qualification bundle_sha256")
    for field in [
        "contradiction_check",
        "suspension_check",
        "revocation_check",
    ]:
        check = _require_fields(
            record[field],
            {"checked_at", "present"},
            f"Qualification {field}",
        )
        checked_at = _parse_datetime(check["checked_at"], f"Qualification {field} time")
        if checked_at < evaluated_at:
            raise ProtocolError(
                f"Qualification {field} must be at least as current as evaluation."
            )
        if checked_at > evaluated_at:
            raise ProtocolError(
                f"Qualification {field} cannot be future-dated."
            )
        if check["present"] is not False:
            raise ProtocolError(f"Qualification {field} found a blocking record.")
    _verify_content_digest(
        record, f"Qualification consumption '{consumption_id}'"
    )
    return record


def reverify_qualification_consumption(
    record: dict[str, Any],
    *,
    manifest_path: Path,
    qualification_policy: dict[str, Any],
    maturity_model: dict[str, Any],
    autonomy_policy: dict[str, Any],
    state_checks: dict[str, dict[str, Any]],
    at: str,
) -> dict[str, Any]:
    validate_qualification_consumption(record, policy=autonomy_policy)
    evaluated_at = _parse_datetime(at, "Qualification re-verification time")
    report = qualify_hosted_bundle(
        manifest_path,
        qualification_policy,
        maturity_model,
        at=evaluated_at.isoformat(),
    )
    expected = {
        "report_id": report["report_id"],
        "bundle_id": report["bundle_id"],
        "project_id": report["project_id"],
        "environment": report["environment"],
        "artifact_sha256": report["artifact_sha256"],
        "achieved_level": report["achieved_level"],
        "policy_sha256": report["policy_sha256"],
        "maturity_model_sha256": report["maturity_model_sha256"],
        "trust_anchor_set_sha256": trust_anchor_set_sha256(qualification_policy),
        "bundle_sha256": report["bundle_sha256"],
    }
    for field, expected_value in expected.items():
        if record[field] != expected_value:
            raise ProtocolError(
                f"Qualification consumption does not match reverified {field}."
            )
    if report["qualified"] is not True:
        raise ProtocolError("Hosted qualification is no longer qualified for autonomy.")
    if LEVELS.index(report["achieved_level"]) < LEVELS.index(record["requested_level"]):
        raise ProtocolError(
            "Hosted qualification no longer satisfies the consumed autonomy level."
        )
    if evaluated_at >= _parse_datetime(
        record["valid_until"], "Qualification valid_until"
    ):
        raise ProtocolError("Qualification consumption is expired.")
    if set(state_checks) != {"contradiction", "suspension", "revocation"}:
        raise ProtocolError(
            "Qualification re-verification requires contradiction, suspension, "
            "and revocation checks."
        )
    for name, check in state_checks.items():
        _require_fields(
            check,
            {"checked_at", "present"},
            f"Autonomy {name} check",
        )
        checked_at = _parse_datetime(
            check["checked_at"], f"Autonomy {name} checked_at"
        )
        if checked_at < evaluated_at:
            raise ProtocolError(
                f"Autonomy {name} check predates authority evaluation."
            )
        if checked_at > evaluated_at:
            raise ProtocolError(
                f"Autonomy {name} check cannot be future-dated."
            )
        if check["present"] is not False:
            raise ProtocolError(f"Autonomy {name} check found a blocking record.")
    return record


def _validate_governance_record(
    record: dict[str, Any],
    *,
    kind: str,
    policy: dict[str, Any],
) -> dict[str, Any]:
    identifiers = {
        "suspension": "suspension_id",
        "revocation": "revocation_id",
    }
    id_field = identifiers[kind]
    required = {
        "version",
        id_field,
        "certification_id",
        "autonomy_class_id",
        "reason",
        "effective_at",
        "recorded_by",
        "recorded_by_role",
        "evidence",
        "content_sha256",
    }
    if kind == "suspension":
        required |= {"trigger", "released_at"}
    _require_fields(record, required, f"Autonomy {kind}")
    if record["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy {kind} version must be '{PROTOCOL_VERSION}'."
        )
    record_id = _require_string(record[id_field], f"Autonomy {kind} id")
    _require_string(record["certification_id"], f"{kind} certification_id")
    _require_string(record["autonomy_class_id"], f"{kind} autonomy_class_id")
    _require_string(record["reason"], f"{kind} reason")
    effective_at = _parse_datetime(record["effective_at"], f"{kind} effective_at")
    _require_string(record["recorded_by"], f"{kind} recorded_by")
    role_field = f"{kind}_roles"
    if record["recorded_by_role"] not in policy["certification"][role_field]:
        raise ProtocolError(
            f"Autonomy {kind} role is not permitted by the autonomy policy."
        )
    _require_string_list(record["evidence"], f"{kind} evidence")
    if kind == "suspension":
        _require_string(record["trigger"], "Suspension trigger")
        if record["released_at"] is not None:
            released = _parse_datetime(record["released_at"], "Suspension released_at")
            if released <= effective_at:
                raise ProtocolError("Suspension release must follow its effective time.")
    _verify_content_digest(record, f"Autonomy {kind} '{record_id}'")
    return record


def validate_suspension(
    record: dict[str, Any],
    *,
    policy: dict[str, Any],
) -> dict[str, Any]:
    return _validate_governance_record(record, kind="suspension", policy=policy)


def validate_revocation(
    record: dict[str, Any],
    *,
    policy: dict[str, Any],
) -> dict[str, Any]:
    return _validate_governance_record(record, kind="revocation", policy=policy)


def validate_renewal(
    record: dict[str, Any],
    *,
    policy: dict[str, Any],
    autonomy_class: dict[str, Any],
) -> dict[str, Any]:
    _require_fields(
        record,
        {
            "version",
            "renewal_id",
            "certification_id",
            "autonomy_class_id",
            "decision",
            "previous_valid_until",
            "new_valid_until",
            "decided_at",
            "decided_by",
            "decided_by_role",
            "independent_evaluation_sha256",
            "incident_budget_sha256",
            "evidence",
            "content_sha256",
        },
        "Autonomy renewal",
    )
    if record["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Autonomy renewal version must be '{PROTOCOL_VERSION}'."
        )
    renewal_id = _require_string(record["renewal_id"], "Autonomy renewal id")
    _require_string(record["certification_id"], "Renewal certification_id")
    if record["autonomy_class_id"] != autonomy_class["id"]:
        raise ProtocolError("Autonomy renewal targets another autonomy class.")
    if record["decision"] not in {"renew", "deny"}:
        raise ProtocolError("Autonomy renewal decision must be renew or deny.")
    previous_valid_until = _parse_datetime(
        record["previous_valid_until"], "Renewal previous_valid_until"
    )
    decided_at = _parse_datetime(record["decided_at"], "Renewal decided_at")
    if decided_at >= previous_valid_until:
        raise ProtocolError("Autonomy renewal must be decided before certification expiry.")
    if record["decision"] == "renew":
        if record["new_valid_until"] is None:
            raise ProtocolError("A renewal decision requires new_valid_until.")
        new_valid_until = _parse_datetime(
            record["new_valid_until"], "Renewal new_valid_until"
        )
        if new_valid_until <= previous_valid_until:
            raise ProtocolError("A renewal must extend the prior validity window.")
        maximum_ttl = autonomy_class["certification_ttl_days"] * 24 * 60 * 60
        if (new_valid_until - decided_at).total_seconds() > maximum_ttl:
            raise ProtocolError("Autonomy renewal exceeds the class TTL.")
    elif record["new_valid_until"] is not None:
        raise ProtocolError("A denied renewal cannot set new_valid_until.")
    _require_string(record["decided_by"], "Renewal decided_by")
    if record["decided_by_role"] not in policy["certification"]["renewal_roles"]:
        raise ProtocolError("Autonomy renewal role is not permitted by policy.")
    _require_sha256(
        record["independent_evaluation_sha256"],
        "Renewal independent_evaluation_sha256",
    )
    _require_sha256(
        record["incident_budget_sha256"], "Renewal incident_budget_sha256"
    )
    _require_string_list(record["evidence"], "Renewal evidence")
    _verify_content_digest(record, f"Autonomy renewal '{renewal_id}'")
    return record


def consume_qualification(
    manifest_path: Path,
    qualification_policy: dict[str, Any],
    maturity_model: dict[str, Any],
    autonomy_policy: dict[str, Any],
    *,
    project_id: str,
    environment: str,
    artifact_sha256: str,
    requested_level: str,
    state_checks: dict[str, dict[str, Any]],
    at: str | None = None,
) -> dict[str, Any]:
    pinned = autonomy_policy["qualification_consumption"]
    if canonical_sha256(qualification_policy) != pinned["approved_policy_sha256"]:
        raise ProtocolError("Qualification policy digest is not approved for autonomy.")
    if canonical_sha256(maturity_model) != pinned["approved_maturity_model_sha256"]:
        raise ProtocolError("Maturity model digest is not approved for autonomy.")
    if (
        trust_anchor_set_sha256(qualification_policy)
        != pinned["approved_trust_anchor_set_sha256"]
    ):
        raise ProtocolError("Qualification trust-anchor set is not approved for autonomy.")
    requested_level = _require_level(requested_level, "Requested autonomy level")
    _require_sha256(artifact_sha256, "Requested artifact_sha256")
    if set(state_checks) != {"contradiction", "suspension", "revocation"}:
        raise ProtocolError(
            "Autonomy qualification requires contradiction, suspension, and revocation checks."
        )

    report = qualify_hosted_bundle(
        manifest_path,
        qualification_policy,
        maturity_model,
        at=at,
    )
    if not report["qualified"]:
        raise ProtocolError("Hosted qualification is not qualified for autonomy.")
    if report["project_id"] != project_id:
        raise ProtocolError("Qualification project does not match autonomy request.")
    if report["environment"] != environment:
        raise ProtocolError("Qualification environment does not match autonomy request.")
    if report["artifact_sha256"] != artifact_sha256:
        raise ProtocolError("Qualification artifact does not match autonomy request.")
    achieved_level = report["achieved_level"]
    if achieved_level is None or LEVELS.index(achieved_level) < LEVELS.index(
        requested_level
    ):
        raise ProtocolError("Qualification does not satisfy the requested autonomy level.")

    manifest = load_json(manifest_path.resolve())
    expiry_values = [manifest["expires_at"]] + [
        record["expires_at"] for record in manifest["records"]
    ]
    valid_until = min(
        _parse_datetime(value, "Qualification evidence expiry")
        for value in expiry_values
    )
    evaluated_at = _parse_datetime(report["evaluated_at"], "Qualification evaluated_at")
    if valid_until <= evaluated_at:
        raise ProtocolError("Qualification evidence is not current for autonomy.")

    normalized_checks: dict[str, dict[str, Any]] = {}
    for name, check in state_checks.items():
        _require_fields(
            check,
            {"checked_at", "present"},
            f"Autonomy {name} check",
        )
        checked_at = _parse_datetime(
            check["checked_at"], f"Autonomy {name} checked_at"
        )
        if checked_at < evaluated_at:
            raise ProtocolError(
                f"Autonomy {name} check predates qualification evaluation."
            )
        if checked_at > evaluated_at:
            raise ProtocolError(
                f"Autonomy {name} check cannot be future-dated."
            )
        if check["present"] is not False:
            raise ProtocolError(f"Autonomy {name} check found a blocking record.")
        normalized_checks[name] = {
            "checked_at": checked_at.isoformat(),
            "present": False,
        }

    consumption = {
        "version": PROTOCOL_VERSION,
        "consumption_id": f"autonomy-{report['report_id']}-{requested_level.lower()}",
        "report_id": report["report_id"],
        "bundle_id": report["bundle_id"],
        "project_id": project_id,
        "environment": environment,
        "artifact_sha256": artifact_sha256,
        "requested_level": requested_level,
        "achieved_level": achieved_level,
        "qualified": True,
        "evaluated_at": evaluated_at.isoformat(),
        "valid_until": valid_until.isoformat(),
        "policy_sha256": report["policy_sha256"],
        "maturity_model_sha256": report["maturity_model_sha256"],
        "trust_anchor_set_sha256": trust_anchor_set_sha256(qualification_policy),
        "bundle_sha256": report["bundle_sha256"],
        "contradiction_check": normalized_checks["contradiction"],
        "suspension_check": normalized_checks["suspension"],
        "revocation_check": normalized_checks["revocation"],
        "reverified": True,
    }
    consumption["content_sha256"] = _content_digest(consumption)
    validate_qualification_consumption(consumption, policy=autonomy_policy)
    return copy.deepcopy(consumption)


def calculate_effective_autonomy(
    autonomy_policy: dict[str, Any],
    autonomy_registry: dict[str, Any],
    change_classes: dict[str, Any],
    *,
    project_id: str,
    project_autonomy_ceiling: str,
    autonomy_class_id: str,
    certification: dict[str, Any],
    qualification_consumption: dict[str, Any],
    incident_budget: dict[str, Any],
    suspensions: list[dict[str, Any]],
    revocations: list[dict[str, Any]],
    at: str,
) -> dict[str, Any]:
    validate_autonomy_policy(autonomy_policy, autonomy_registry, change_classes)
    project_autonomy_ceiling = _require_level(
        project_autonomy_ceiling, "Project autonomy ceiling"
    )
    classes = {item["id"]: item for item in autonomy_registry["classes"]}
    autonomy_class = classes.get(autonomy_class_id)
    if autonomy_class is None:
        raise ProtocolError(f"Unknown autonomy class: {autonomy_class_id}")
    validate_certification(
        certification,
        policy=autonomy_policy,
        autonomy_class=autonomy_class,
    )
    validate_qualification_consumption(
        qualification_consumption,
        policy=autonomy_policy,
    )
    validate_incident_budget(incident_budget)
    class_budget = autonomy_class["incident_budget"]
    if (
        incident_budget["maximum_incidents"]
        != class_budget["maximum_incidents"]
        or incident_budget["maximum_rollbacks"]
        != class_budget["maximum_rollbacks"]
    ):
        raise ProtocolError(
            "Incident budget limits must exactly match the autonomy class."
        )
    budget_started = _parse_datetime(
        incident_budget["window_started_at"],
        "Incident budget start",
    )
    budget_ends = _parse_datetime(
        incident_budget["window_ends_at"],
        "Incident budget end",
    )
    maximum_window_seconds = class_budget["window_days"] * 24 * 60 * 60
    if (budget_ends - budget_started).total_seconds() > maximum_window_seconds:
        raise ProtocolError(
            "Incident budget window exceeds the autonomy class."
        )
    evaluated_at = _parse_datetime(at, "Effective autonomy evaluation time")
    for record in suspensions:
        validate_suspension(record, policy=autonomy_policy)
    for record in revocations:
        validate_revocation(record, policy=autonomy_policy)

    blockers: list[str] = []
    certification_id = certification["certification_id"]
    if certification["project_id"] != project_id:
        blockers.append("certification-project-mismatch")
    if qualification_consumption["project_id"] != project_id:
        blockers.append("qualification-project-mismatch")
    if certification["environment"] != qualification_consumption["environment"]:
        blockers.append("qualification-environment-mismatch")
    if (
        certification["qualification_consumption_sha256"]
        != qualification_consumption["content_sha256"]
    ):
        blockers.append("qualification-binding-mismatch")
    if incident_budget["certification_id"] != certification_id:
        blockers.append("incident-budget-certification-mismatch")
    if incident_budget["budget_id"] != certification["incident_budget_id"]:
        blockers.append("incident-budget-id-mismatch")
    if incident_budget["autonomy_class_id"] != autonomy_class_id:
        blockers.append("incident-budget-class-mismatch")
    if certification["status"] != "active":
        blockers.append("certification-not-active")
    valid_from = _parse_datetime(certification["valid_from"], "Certification valid_from")
    valid_until = _parse_datetime(
        certification["valid_until"], "Certification valid_until"
    )
    if evaluated_at < valid_from or evaluated_at >= valid_until:
        blockers.append("expired")
    qualification_until = _parse_datetime(
        qualification_consumption["valid_until"],
        "Qualification valid_until",
    )
    if evaluated_at >= qualification_until:
        blockers.append("invalid-qualification")
    if incident_budget["exhausted"]:
        blockers.append("incident-budget-exhausted")
    if evaluated_at < budget_started or evaluated_at >= budget_ends:
        blockers.append("incident-budget-window-inactive")
    qualification_evaluated_at = _parse_datetime(
        qualification_consumption["evaluated_at"],
        "Qualification evaluated_at",
    )
    if evaluated_at < qualification_evaluated_at:
        blockers.append("invalid-qualification")

    for record in suspensions:
        if (
            record["certification_id"] == certification_id
            and record["autonomy_class_id"] == autonomy_class_id
            and _parse_datetime(record["effective_at"], "Suspension effective_at")
            <= evaluated_at
            and (
                record["released_at"] is None
                or _parse_datetime(record["released_at"], "Suspension released_at")
                > evaluated_at
            )
        ):
            blockers.append("suspended")
    for record in revocations:
        if (
            record["certification_id"] == certification_id
            and record["autonomy_class_id"] == autonomy_class_id
            and _parse_datetime(record["effective_at"], "Revocation effective_at")
            <= evaluated_at
        ):
            blockers.append("revoked")

    unique_blockers = sorted(set(blockers))
    operands = {
        "verified_hosted_maturity": qualification_consumption["achieved_level"],
        "project_autonomy_ceiling": project_autonomy_ceiling,
        "change_class_maximum": autonomy_class["maximum_autonomy"],
        "active_certification_level": certification["certification_level"],
    }
    effective_level = None
    if not unique_blockers:
        effective_level = min(
            operands.values(),
            key=LEVELS.index,
        )
    report = {
        "version": PROTOCOL_VERSION,
        "project_id": project_id,
        "autonomy_class_id": autonomy_class_id,
        "certification_id": certification_id,
        "evaluated_at": evaluated_at.isoformat(),
        "operands": operands,
        "blockers": unique_blockers,
        "effective_level": effective_level,
        "authority_eligible": (
            effective_level is not None
            and LEVELS.index(effective_level) >= LEVELS.index("L2")
        ),
        "authority_activated": False,
        "contracts_only": False,
        "can_issue_runtime_lease": (
            effective_level is not None
            and LEVELS.index(effective_level) >= LEVELS.index("L2")
            and autonomy_policy["authority"]["can_issue_runtime_lease"]
        ),
        "can_create_pr": (
            effective_level is not None
            and LEVELS.index(effective_level) >= LEVELS.index("L2")
            and autonomy_policy["authority"]["can_create_pr"]
        ),
        "can_merge": False,
        "can_deploy": False,
        "can_mutate_maturity": False,
        "can_auto_renew": False,
    }
    report["content_sha256"] = _content_digest(report)
    return copy.deepcopy(report)
