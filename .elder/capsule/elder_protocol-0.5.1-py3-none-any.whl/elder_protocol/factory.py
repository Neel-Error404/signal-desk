from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
import zipfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping

from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, load_json, write_text


FACTORY_VERSION = "0.1.0"
LEVELS = ["Foundation", "Component", "Integration", "Workflow", "Stress"]
APPROVAL_FIELDS = {
    "type",
    "action",
    "artifact_sha256",
    "environment",
    "approved_by",
    "approved_at",
    "decision",
}


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value


def _require_string_list(value: Any, label: str, *, non_empty: bool = True) -> list[str]:
    if (
        not isinstance(value, list)
        or (non_empty and not value)
        or any(not isinstance(item, str) or not item.strip() for item in value)
    ):
        qualifier = "non-empty " if non_empty else ""
        raise ProtocolError(f"{label} must be a {qualifier}list of strings.")
    if len(value) != len(set(value)):
        raise ProtocolError(f"{label} cannot contain duplicates.")
    return value


def _resolve_within(root: Path, relative: str, label: str) -> Path:
    candidate = (root / relative).resolve()
    resolved_root = root.resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise ProtocolError(f"{label} escapes its allowed root: {relative}")
    return candidate


def validate_factory_contract(path: Path) -> dict[str, Any]:
    contract = load_json(path.resolve())
    required = {
        "version",
        "project",
        "git",
        "workspace",
        "identity",
        "promotion",
    }
    if set(contract) != required:
        raise ProtocolError(
            f"Factory contract fields must be exactly: {sorted(required)}"
        )
    if contract["version"] != FACTORY_VERSION:
        raise ProtocolError(
            f"Factory contract version must be {FACTORY_VERSION}."
        )

    project = contract["project"]
    project_required = {
        "id",
        "path",
        "source_paths",
        "artifact_paths",
        "exclude_globs",
        "test_ladder",
        "smoke_command",
    }
    if not isinstance(project, dict) or set(project) != project_required:
        raise ProtocolError(
            f"Factory project fields must be exactly: {sorted(project_required)}"
        )
    _require_string(project["id"], "Factory project id")
    _require_string(project["path"], "Factory project path")
    source_paths = _require_string_list(
        project["source_paths"], "Factory project source_paths"
    )
    artifact_paths = _require_string_list(
        project["artifact_paths"], "Factory project artifact_paths"
    )
    unknown_artifacts = set(artifact_paths) - set(source_paths)
    if unknown_artifacts:
        raise ProtocolError(
            f"Artifact paths must also be source paths: {sorted(unknown_artifacts)}"
        )
    _require_string_list(
        project["exclude_globs"],
        "Factory project exclude_globs",
        non_empty=False,
    )
    smoke = _require_string_list(
        project["smoke_command"], "Factory project smoke_command"
    )
    if smoke[0] != "{python}":
        raise ProtocolError("Smoke command must use the {python} executable placeholder.")

    ladder = project["test_ladder"]
    if not isinstance(ladder, list) or [item.get("level") for item in ladder] != LEVELS:
        raise ProtocolError(f"Factory test ladder must be ordered: {LEVELS}")
    for item in ladder:
        if not isinstance(item, dict) or set(item) != {"level", "command"}:
            raise ProtocolError("Every factory test level needs level and command.")
        command = _require_string_list(
            item["command"], f"{item.get('level')} command"
        )
        if command[0] != "{python}":
            raise ProtocolError(
                f"{item['level']} command must use the {{python}} placeholder."
            )

    git = contract["git"]
    git_required = {
        "default_branch",
        "work_branch_prefix",
        "branch_pattern",
        "protected_branches",
        "required_checks",
    }
    if not isinstance(git, dict) or set(git) != git_required:
        raise ProtocolError(f"Factory git fields must be exactly: {sorted(git_required)}")
    for field in ["default_branch", "work_branch_prefix", "branch_pattern"]:
        _require_string(git[field], f"Factory git {field}")
    try:
        re.compile(git["branch_pattern"])
    except re.error as exc:
        raise ProtocolError(f"Invalid factory branch_pattern: {exc}") from exc
    _require_string_list(git["protected_branches"], "Protected branches")
    _require_string_list(git["required_checks"], "Required checks")

    workspace = contract["workspace"]
    workspace_required = {
        "state_root",
        "worktrees",
        "builds",
        "artifacts",
        "releases",
        "traces",
        "environments",
        "verifications",
    }
    if not isinstance(workspace, dict) or set(workspace) != workspace_required:
        raise ProtocolError(
            f"Factory workspace fields must be exactly: {sorted(workspace_required)}"
        )
    for field in workspace_required:
        value = _require_string(workspace[field], f"Factory workspace {field}")
        if Path(value).is_absolute():
            raise ProtocolError(f"Factory workspace {field} must be relative.")

    identity = contract["identity"]
    identity_required = {
        "local_mode",
        "ci_mode",
        "allowed_environment",
        "forbidden_name_patterns",
        "external_broker",
    }
    if not isinstance(identity, dict) or set(identity) != identity_required:
        raise ProtocolError(
            f"Factory identity fields must be exactly: {sorted(identity_required)}"
        )
    if identity["local_mode"] != "secretless":
        raise ProtocolError("Local factory mode must be secretless.")
    if identity["ci_mode"] != "github-oidc":
        raise ProtocolError("CI factory mode must use github-oidc.")
    if identity["external_broker"] != "required-for-remote":
        raise ProtocolError("Remote operations must require an external broker.")
    _require_string_list(identity["allowed_environment"], "Allowed environment")
    _require_string_list(
        identity["forbidden_name_patterns"], "Forbidden environment patterns"
    )

    promotion = contract["promotion"]
    promotion_required = {
        "environments",
        "transitions",
        "approval_required",
        "health_evidence_required",
    }
    if not isinstance(promotion, dict) or set(promotion) != promotion_required:
        raise ProtocolError(
            f"Factory promotion fields must be exactly: {sorted(promotion_required)}"
        )
    environments = _require_string_list(
        promotion["environments"], "Promotion environments"
    )
    if environments[0] != "candidate":
        raise ProtocolError("The first promotion environment must be candidate.")
    transitions = promotion["transitions"]
    if not isinstance(transitions, dict) or set(transitions) != set(environments):
        raise ProtocolError("Promotion transitions must define every environment.")
    for source, targets in transitions.items():
        _require_string_list(
            targets,
            f"Promotion targets for {source}",
            non_empty=False,
        )
        unknown = set(targets) - set(environments)
        if unknown:
            raise ProtocolError(
                f"Promotion transition '{source}' has unknown targets: {sorted(unknown)}"
            )
    for field in ["approval_required", "health_evidence_required"]:
        values = _require_string_list(
            promotion[field],
            f"Promotion {field}",
            non_empty=False,
        )
        unknown = set(values) - set(environments)
        if unknown:
            raise ProtocolError(
                f"Promotion {field} has unknown environments: {sorted(unknown)}"
            )

    repository_root = path.resolve().parent.parent
    project_root = _resolve_within(
        repository_root, project["path"], "Factory project path"
    )
    if not project_root.is_dir():
        raise ProtocolError(f"Factory project path does not exist: {project_root}")
    for relative in source_paths:
        if not _resolve_within(project_root, relative, "Source path").exists():
            raise ProtocolError(f"Factory source path does not exist: {relative}")
    return contract


def sanitized_environment(
    source: Mapping[str, str],
    allowed_names: list[str],
    forbidden_patterns: list[str],
) -> dict[str, str]:
    forbidden = [pattern.upper() for pattern in forbidden_patterns]
    result: dict[str, str] = {}
    for name in allowed_names:
        upper = name.upper()
        if any(pattern in upper for pattern in forbidden):
            continue
        if name in source:
            result[name] = source[name]
    result["PYTHONNOUSERSITE"] = "1"
    result["PYTHONDONTWRITEBYTECODE"] = "1"
    return result


def _tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def _is_excluded(relative: Path, patterns: list[str]) -> bool:
    value = relative.as_posix()
    return any(
        fnmatch.fnmatch(value, pattern)
        or fnmatch.fnmatch(relative.name, pattern)
        for pattern in patterns
    )


def _copy_declared(
    source_root: Path,
    target_root: Path,
    declared_paths: list[str],
    exclude_globs: list[str],
) -> None:
    for declared in declared_paths:
        source = _resolve_within(source_root, declared, "Declared source")
        target = _resolve_within(target_root, declared, "Declared target")
        if source.is_symlink():
            raise ProtocolError(f"Factory source cannot be a symlink: {source}")
        if source.is_file():
            if not _is_excluded(Path(declared), exclude_globs):
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
            continue
        if not source.is_dir():
            raise ProtocolError(f"Factory source does not exist: {source}")
        for child in sorted(source.rglob("*")):
            relative_to_source = child.relative_to(source)
            project_relative = Path(declared) / relative_to_source
            if _is_excluded(project_relative, exclude_globs):
                continue
            if child.is_symlink():
                raise ProtocolError(f"Factory source cannot be a symlink: {child}")
            destination = _resolve_within(
                target_root,
                project_relative.as_posix(),
                "Copied source",
            )
            if child.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
            elif child.is_file():
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(child, destination)


def _deterministic_zip(
    source_root: Path,
    artifact_paths: list[str],
    target: Path,
) -> str:
    target.parent.mkdir(parents=True, exist_ok=True)
    files: list[Path] = []
    for declared in artifact_paths:
        source = _resolve_within(source_root, declared, "Artifact path")
        if source.is_file():
            files.append(source)
        elif source.is_dir():
            files.extend(sorted(item for item in source.rglob("*") if item.is_file()))
        else:
            raise ProtocolError(f"Artifact path does not exist after build: {declared}")
    unique_files = sorted(set(files), key=lambda path: path.relative_to(source_root).as_posix())
    with zipfile.ZipFile(
        target,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path in unique_files:
            relative = path.relative_to(source_root).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)
    return hashlib.sha256(target.read_bytes()).hexdigest()


def _extract_zip(archive_path: Path, target_root: Path) -> None:
    target_root.mkdir(parents=True, exist_ok=True)
    resolved_root = target_root.resolve()
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            target = (target_root / info.filename).resolve()
            if target != resolved_root and resolved_root not in target.parents:
                raise ProtocolError(
                    f"Artifact contains an unsafe path: {info.filename}"
                )
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(info))


@dataclass(frozen=True)
class BuildResult:
    build_id: str
    artifact_sha256: str
    artifact_path: Path
    provenance_path: Path
    report_path: Path
    source_tree_sha256: str
    test_results: tuple[dict[str, Any], ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "build_id": self.build_id,
            "artifact_sha256": self.artifact_sha256,
            "artifact_path": str(self.artifact_path),
            "provenance_path": str(self.provenance_path),
            "report_path": str(self.report_path),
            "source_tree_sha256": self.source_tree_sha256,
            "test_results": list(self.test_results),
        }


class Factory:
    def __init__(
        self,
        contract_path: Path,
        *,
        state_root_override: Path | None = None,
    ):
        self.contract_path = contract_path.resolve()
        self.contract = validate_factory_contract(self.contract_path)
        self.repository_root = self.contract_path.parent.parent.resolve()
        self.project_root = _resolve_within(
            self.repository_root,
            self.contract["project"]["path"],
            "Factory project path",
        )
        configured_state = _resolve_within(
            self.repository_root,
            self.contract["workspace"]["state_root"],
            "Factory state root",
        )
        self.state_root = (
            state_root_override.resolve()
            if state_root_override is not None
            else configured_state
        )
        self.paths = {
            key: self.state_root / value
            for key, value in self.contract["workspace"].items()
            if key != "state_root"
        }
        for path in self.paths.values():
            path.mkdir(parents=True, exist_ok=True)

    def _trace(self, event: dict[str, Any]) -> None:
        path = self.paths["traces"] / "factory.jsonl"
        payload = {"recorded_at": utc_now(), **event}
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, sort_keys=True) + "\n")

    def _run(
        self,
        command: list[str],
        *,
        cwd: Path,
        timeout: int = 300,
    ) -> subprocess.CompletedProcess[str]:
        resolved = [
            sys.executable if item == "{python}" else item
            for item in command
        ]
        environment = sanitized_environment(
            os.environ,
            self.contract["identity"]["allowed_environment"],
            self.contract["identity"]["forbidden_name_patterns"],
        )
        try:
            return subprocess.run(
                resolved,
                cwd=cwd,
                env=environment,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
        except OSError as exc:
            raise ProtocolError(
                f"Could not execute factory command {resolved}: {exc}"
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise ProtocolError(
                f"Factory command timed out after {timeout}s: {resolved}"
            ) from exc

    def status(self) -> dict[str, Any]:
        git_dir = self.repository_root / ".git"
        if not git_dir.exists():
            repository_state = "not-initialized"
            head = None
            clean = None
            has_remote = False
        else:
            repository_state = "initialized"
            head_result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.repository_root,
                capture_output=True,
                text=True,
                check=False,
            )
            head = head_result.stdout.strip() if head_result.returncode == 0 else None
            status_result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.repository_root,
                capture_output=True,
                text=True,
                check=False,
            )
            clean = status_result.returncode == 0 and not status_result.stdout.strip()
            remote_result = subprocess.run(
                ["git", "remote"],
                cwd=self.repository_root,
                capture_output=True,
                text=True,
                check=False,
            )
            has_remote = bool(remote_result.stdout.strip())
        return {
            "repository": repository_state,
            "head": head,
            "clean": clean,
            "has_remote": has_remote,
            "branch_protection": "unverified" if has_remote else "not-configured",
            "external_identity": "not-configured",
            "local_mode": self.contract["identity"]["local_mode"],
        }

    def _require_git_baseline(self) -> None:
        status = self.status()
        if status["repository"] != "initialized":
            raise ProtocolError(
                "Git worktrees require an initialized repository and baseline commit."
            )
        if status["head"] is None:
            raise ProtocolError("Git worktrees require a baseline commit.")

    def create_worktree(self, work_item: str) -> Path:
        self._require_git_baseline()
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]{2,63}", work_item):
            raise ProtocolError(
                "Work item must be 3-64 lowercase letters, numbers, or hyphens."
            )
        branch = f"{self.contract['git']['work_branch_prefix']}{work_item}"
        if not re.fullmatch(self.contract["git"]["branch_pattern"], branch):
            raise ProtocolError(f"Work branch violates branch policy: {branch}")
        target = (self.paths["worktrees"] / work_item).resolve()
        worktree_root = self.paths["worktrees"].resolve()
        if worktree_root not in target.parents:
            raise ProtocolError(f"Worktree target escapes factory state: {target}")
        if target.exists():
            raise ProtocolError(f"Worktree already exists: {target}")
        result = subprocess.run(
            ["git", "worktree", "add", "-b", branch, str(target), "HEAD"],
            cwd=self.repository_root,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            raise ProtocolError(
                f"Could not create worktree for {work_item}: {result.stderr.strip()}"
            )
        self._trace(
            {
                "event": "worktree-created",
                "work_item": work_item,
                "branch": branch,
                "path": str(target),
            }
        )
        return target

    def remove_worktree(self, work_item: str) -> None:
        self._require_git_baseline()
        target = (self.paths["worktrees"] / work_item).resolve()
        worktree_root = self.paths["worktrees"].resolve()
        if worktree_root not in target.parents:
            raise ProtocolError(f"Worktree target escapes factory state: {target}")
        if not target.exists():
            raise ProtocolError(f"Worktree does not exist: {target}")
        result = subprocess.run(
            ["git", "worktree", "remove", str(target)],
            cwd=self.repository_root,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            raise ProtocolError(
                "Could not remove worktree. Commit, move, or discard its changes "
                f"through an approved Git action first: {result.stderr.strip()}"
            )
        self._trace(
            {
                "event": "worktree-removed",
                "work_item": work_item,
                "path": str(target),
            }
        )

    def _git_revision(self) -> str | None:
        if not (self.repository_root / ".git").exists():
            return None
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=self.repository_root,
            capture_output=True,
            text=True,
            check=False,
        )
        return result.stdout.strip() if result.returncode == 0 else None

    def _environment_path(self, environment: str) -> Path:
        return self.paths["environments"] / f"{environment}.json"

    def _read_environment(self, environment: str) -> dict[str, Any] | None:
        path = self._environment_path(environment)
        return load_json(path) if path.is_file() else None

    def _write_environment_event(
        self,
        environment: str,
        digest: str,
        action: str,
        authority: str,
    ) -> dict[str, Any]:
        current = self._read_environment(environment)
        history = list(current.get("history", [])) if current else []
        event = {
            "action": action,
            "artifact_sha256": digest,
            "authority": authority,
            "recorded_at": utc_now(),
        }
        history.append(event)
        record = {
            "environment": environment,
            "artifact_sha256": digest,
            "history": history,
        }
        write_text(self._environment_path(environment), json_text(record))
        return record

    def build(self) -> BuildResult:
        build_id = uuid.uuid4().hex[:12]
        build_root = self.paths["builds"] / build_id
        staging_parent = self.repository_root / ".tmp" / "factory-builds"
        staging_root = staging_parent / build_id
        source_root = staging_root / "src"
        build_root.mkdir(parents=True, exist_ok=True)
        source_root.mkdir(parents=True)
        project = self.contract["project"]
        _copy_declared(
            self.project_root,
            source_root,
            project["source_paths"],
            project["exclude_globs"],
        )
        source_tree_sha256 = _tree_digest(source_root)
        test_results: list[dict[str, Any]] = []
        self._trace(
            {
                "event": "build-started",
                "build_id": build_id,
                "source_tree_sha256": source_tree_sha256,
            }
        )
        for item in project["test_ladder"]:
            result = self._run(item["command"], cwd=source_root)
            test_result = {
                "level": item["level"],
                "status": "passed" if result.returncode == 0 else "failed",
                "returncode": result.returncode,
                "command": item["command"],
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
            test_results.append(test_result)
            self._trace(
                {
                    "event": "build-test",
                    "build_id": build_id,
                    "level": item["level"],
                    "status": test_result["status"],
                    "returncode": result.returncode,
                }
            )
            if result.returncode != 0:
                report_path = build_root / "build-report.json"
                write_text(
                    report_path,
                    json_text(
                        {
                            "build_id": build_id,
                            "status": "failed",
                            "source_tree_sha256": source_tree_sha256,
                            "test_results": test_results,
                        }
                    ),
                )
                raise ProtocolError(
                    f"Factory build failed at {item['level']}. "
                    f"See {report_path}."
                )

        temporary_artifact = staging_root / f"{project['id']}.zip"
        artifact_sha256 = _deterministic_zip(
            source_root,
            project["artifact_paths"],
            temporary_artifact,
        )
        artifact_dir = self.paths["artifacts"] / artifact_sha256
        artifact_dir.mkdir(parents=True, exist_ok=True)
        artifact_path = artifact_dir / f"{project['id']}.zip"
        if artifact_path.exists():
            if hashlib.sha256(artifact_path.read_bytes()).hexdigest() != artifact_sha256:
                raise ProtocolError(
                    f"Artifact registry digest mismatch at {artifact_path}"
                )
            temporary_artifact.unlink()
        else:
            os.replace(temporary_artifact, artifact_path)

        contract_sha256 = hashlib.sha256(
            self.contract_path.read_bytes()
        ).hexdigest()
        provenance = {
            "version": FACTORY_VERSION,
            "build_id": build_id,
            "subject": {
                "name": artifact_path.name,
                "sha256": artifact_sha256,
            },
            "source": {
                "repository_revision": self._git_revision(),
                "source_tree_sha256": source_tree_sha256,
                "project_path": self.contract["project"]["path"],
            },
            "builder": {
                "kind": "elder-local-factory",
                "python": sys.version.split()[0],
                "secret_mode": self.contract["identity"]["local_mode"],
            },
            "contract_sha256": contract_sha256,
            "test_results": [
                {
                    "level": item["level"],
                    "status": item["status"],
                    "returncode": item["returncode"],
                }
                for item in test_results
            ],
            "created_at": utc_now(),
        }
        provenance_path = artifact_dir / "provenance" / f"{build_id}.json"
        write_text(provenance_path, json_text(provenance))
        report_path = build_root / "build-report.json"
        result = BuildResult(
            build_id=build_id,
            artifact_sha256=artifact_sha256,
            artifact_path=artifact_path,
            provenance_path=provenance_path,
            report_path=report_path,
            source_tree_sha256=source_tree_sha256,
            test_results=tuple(test_results),
        )
        write_text(report_path, json_text(result.to_dict()))
        self._write_environment_event(
            "candidate",
            artifact_sha256,
            "build",
            "factory",
        )
        self._trace(
            {
                "event": "build-completed",
                "build_id": build_id,
                "artifact_sha256": artifact_sha256,
                "artifact_path": str(artifact_path),
            }
        )
        resolved_staging_parent = staging_parent.resolve()
        resolved_staging_root = staging_root.resolve()
        if resolved_staging_parent not in resolved_staging_root.parents:
            raise ProtocolError(
                f"Refusing to clean factory staging outside .tmp: {resolved_staging_root}"
            )
        shutil.rmtree(resolved_staging_root)
        return result

    def _artifact_path(self, digest: str) -> Path:
        if not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ProtocolError("Artifact digest must be 64 lowercase hexadecimal characters.")
        path = self.paths["artifacts"] / digest / f"{self.contract['project']['id']}.zip"
        if not path.is_file():
            raise ProtocolError(f"Artifact does not exist: {digest}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            raise ProtocolError(
                f"Artifact content does not match registry digest: {digest}"
            )
        provenance_paths = sorted((path.parent / "provenance").glob("*.json"))
        if not provenance_paths:
            raise ProtocolError(f"Artifact provenance does not exist: {digest}")
        matching_provenance = False
        for provenance_path in provenance_paths:
            provenance = load_json(provenance_path)
            subject = provenance.get("subject", {})
            if subject.get("sha256") == digest and subject.get("name") == path.name:
                matching_provenance = True
                break
        if not matching_provenance:
            raise ProtocolError(
                f"Artifact provenance does not match registry subject: {digest}"
            )
        return path

    def verify(self, digest: str) -> dict[str, Any]:
        artifact_path = self._artifact_path(digest)
        verification_root = self.paths["verifications"] / f".tmp-{uuid.uuid4().hex}"
        try:
            _extract_zip(artifact_path, verification_root)
            result = self._run(
                self.contract["project"]["smoke_command"],
                cwd=verification_root,
            )
            verification = {
                "artifact_sha256": digest,
                "status": "passed" if result.returncode == 0 else "failed",
                "returncode": result.returncode,
                "command": self.contract["project"]["smoke_command"],
                "stdout": result.stdout,
                "stderr": result.stderr,
                "verified_at": utc_now(),
            }
            write_text(
                self.paths["verifications"] / f"{digest}.json",
                json_text(verification),
            )
            self._trace(
                {
                    "event": "artifact-verified",
                    "artifact_sha256": digest,
                    "status": verification["status"],
                }
            )
            if result.returncode != 0:
                raise ProtocolError(
                    f"Artifact smoke verification failed for {digest}."
                )
            return verification
        finally:
            if verification_root.exists():
                resolved_verifications = self.paths["verifications"].resolve()
                resolved_target = verification_root.resolve()
                if resolved_verifications not in resolved_target.parents:
                    raise ProtocolError(
                        "Refusing to remove verification path outside factory state: "
                        f"{resolved_target}"
                    )
                shutil.rmtree(resolved_target)

    def _validate_approval(
        self,
        approval_path: Path | None,
        *,
        digest: str,
        environment: str,
        action: str,
    ) -> dict[str, Any]:
        if approval_path is None:
            raise ProtocolError(
                f"A separate release approval is required for {action} to {environment}."
            )
        approval = load_json(approval_path.resolve())
        if set(approval) != APPROVAL_FIELDS:
            raise ProtocolError(
                f"Release approval fields must be exactly: {sorted(APPROVAL_FIELDS)}"
            )
        expected = {
            "type": "release-approval",
            "action": action,
            "artifact_sha256": digest,
            "environment": environment,
            "decision": "approved",
        }
        for field, value in expected.items():
            if approval.get(field) != value:
                raise ProtocolError(
                    f"Release approval {field} must be '{value}'."
                )
        _require_string(approval["approved_by"], "Release approval approved_by")
        _require_string(approval["approved_at"], "Release approval approved_at")
        return approval

    def _require_health_evidence(self, digest: str) -> dict[str, Any]:
        path = self.paths["verifications"] / f"{digest}.json"
        if not path.is_file():
            raise ProtocolError(
                f"Current smoke evidence is required before promotion: {digest}"
            )
        evidence = load_json(path)
        if evidence.get("artifact_sha256") != digest or evidence.get("status") != "passed":
            raise ProtocolError(f"Smoke evidence is not passing for artifact: {digest}")
        return evidence

    def _materialize_release(self, digest: str, environment: str) -> Path:
        release_root = self.paths["releases"] / environment / digest
        if release_root.exists():
            return release_root
        temporary = release_root.parent / f".tmp-{digest}-{uuid.uuid4().hex}"
        _extract_zip(self._artifact_path(digest), temporary)
        release_root.parent.mkdir(parents=True, exist_ok=True)
        os.replace(temporary, release_root)
        return release_root

    def promote(
        self,
        digest: str,
        environment: str,
        *,
        approval_path: Path | None,
    ) -> dict[str, Any]:
        promotion = self.contract["promotion"]
        if environment not in promotion["environments"] or environment == "candidate":
            raise ProtocolError(f"Invalid promotion target: {environment}")
        sources = [
            source
            for source, targets in promotion["transitions"].items()
            if environment in targets
        ]
        if len(sources) != 1:
            raise ProtocolError(
                f"Promotion target must have one declared predecessor: {environment}"
            )
        source_state = self._read_environment(sources[0])
        if source_state is None or source_state.get("artifact_sha256") != digest:
            raise ProtocolError(
                f"Artifact {digest} is not current in predecessor {sources[0]}."
            )
        approval = self._validate_approval(
            approval_path,
            digest=digest,
            environment=environment,
            action="promote",
        )
        if environment in promotion["health_evidence_required"]:
            self._require_health_evidence(digest)
        release_path = self._materialize_release(digest, environment)
        record = self._write_environment_event(
            environment,
            digest,
            "promote",
            approval["approved_by"],
        )
        record["release_path"] = str(release_path)
        write_text(self._environment_path(environment), json_text(record))
        self._trace(
            {
                "event": "artifact-promoted",
                "artifact_sha256": digest,
                "environment": environment,
                "authority": approval["approved_by"],
            }
        )
        return record

    def rollback(
        self,
        environment: str,
        *,
        approval_path: Path | None,
    ) -> dict[str, Any]:
        if environment == "candidate":
            raise ProtocolError("Candidate state cannot be rolled back as a deployment.")
        state = self._read_environment(environment)
        if state is None:
            raise ProtocolError(f"Environment has no release history: {environment}")
        current = state["artifact_sha256"]
        prior = next(
            (
                event["artifact_sha256"]
                for event in reversed(state["history"][:-1])
                if event["artifact_sha256"] != current
            ),
            None,
        )
        if prior is None:
            raise ProtocolError(
                f"Environment has no previous artifact to roll back to: {environment}"
            )
        approval = self._validate_approval(
            approval_path,
            digest=prior,
            environment=environment,
            action="rollback",
        )
        if environment in self.contract["promotion"]["health_evidence_required"]:
            self._require_health_evidence(prior)
        release_path = self._materialize_release(prior, environment)
        record = self._write_environment_event(
            environment,
            prior,
            "rollback",
            approval["approved_by"],
        )
        record["release_path"] = str(release_path)
        write_text(self._environment_path(environment), json_text(record))
        self._trace(
            {
                "event": "artifact-rolled-back",
                "artifact_sha256": prior,
                "environment": environment,
                "authority": approval["approved_by"],
            }
        )
        return record
