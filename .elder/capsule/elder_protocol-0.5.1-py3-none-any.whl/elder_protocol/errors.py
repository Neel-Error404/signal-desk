class ProtocolError(RuntimeError):
    """Raised when an Elder contract is invalid or unsafe to execute."""


class InvalidProjectionTokenError(ProtocolError):
    """Raised when a projection continuation token is malformed or misbound."""

    code = "invalid-projection-token"


class StaleProjectionTokenError(ProtocolError):
    """Raised when a projection continuation token no longer names active data."""

    code = "stale-projection-token"
    restart_required = True

    def __init__(
        self,
        message: str,
        *,
        projection_id: str,
        expected_generation: int,
        actual_generation: int,
        expected_projection_sha256: str,
        actual_projection_sha256: str,
        expected_journal_generation: int,
        actual_journal_generation: int,
        expected_journal_sequence: int,
        actual_journal_sequence: int,
    ) -> None:
        super().__init__(message)
        self.projection_id = projection_id
        self.expected_generation = expected_generation
        self.actual_generation = actual_generation
        self.expected_projection_sha256 = expected_projection_sha256
        self.actual_projection_sha256 = actual_projection_sha256
        self.expected_journal_generation = expected_journal_generation
        self.actual_journal_generation = actual_journal_generation
        self.expected_journal_sequence = expected_journal_sequence
        self.actual_journal_sequence = actual_journal_sequence


class CapabilityUnavailableError(ProtocolError):
    """Raised when a requested factory capability has no canonical source."""

    code = "capability-unavailable"
    retryable = False


class OperationsApiUnavailableError(ProtocolError):
    """Raised when an in-flight API read loses an operational dependency."""


class OperationsReadUnavailableError(ProtocolError):
    """Raised when a factory read loses its store or journal dependency."""


class InvalidEventCursorError(ProtocolError):
    """Raised when an event cursor is malformed, future, or misbound."""


class DeterministicMutationRejectionError(ProtocolError):
    """Raised for a permanent, proven non-applied domain rejection."""

    def __init__(
        self,
        message: str,
        *,
        status: int,
        code: str,
        reason_code: str,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.reason_code = reason_code


class MutationNotFoundError(DeterministicMutationRejectionError):
    """Raised when a canonical mutation target is provably absent."""

    def __init__(self, message: str) -> None:
        super().__init__(
            message,
            status=404,
            code="not-found",
            reason_code="canonical-mutation-not-found",
        )


class MutationForbiddenError(DeterministicMutationRejectionError):
    """Raised when canonical authority provably rejects a mutation."""

    def __init__(self, message: str) -> None:
        super().__init__(
            message,
            status=403,
            code="forbidden",
            reason_code="canonical-mutation-forbidden",
        )


class MutationConflictError(DeterministicMutationRejectionError):
    """Raised when current canonical state permanently conflicts."""

    def __init__(self, message: str) -> None:
        super().__init__(
            message,
            status=409,
            code="conflict",
            reason_code="canonical-mutation-conflict",
        )


class StaleEventCursorError(ProtocolError):
    """Raised when a retained event cursor must refresh from current truth."""

    def __init__(
        self,
        message: str,
        *,
        current_cursor: dict,
    ) -> None:
        super().__init__(message)
        self.current_cursor = current_cursor
