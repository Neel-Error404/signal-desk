from __future__ import annotations

import copy
import json
import os
import threading
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import unquote, urlparse

from elder_protocol.autonomy import (
    calculate_effective_autonomy,
    canonical_sha256,
    consume_qualification,
    reverify_qualification_consumption,
    validate_autonomy_policy,
    validate_certification,
)
from elder_protocol.autonomy_runtime import (
    match_autonomy_work_item,
    replay_certification,
    simulate_autonomy_work_item,
    validate_autonomy_authority_evidence,
    validate_autonomy_work_item,
)
from elder_protocol.canary_store import SQLiteCanaryExecutionStore
from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.qualification import LEVELS, verify_trusted_statement
from elder_protocol.schema_validation import validate_against_schema


class CanaryProvider(Protocol):
    def start_canary(self, packet: dict[str, Any]) -> dict[str, Any]:
        """Start one already-authorized bounded canary."""

    def rollback_canary(self, packet: dict[str, Any]) -> dict[str, Any]:
        """Roll back one already-authorized canary deployment."""


_CANONICAL_CANARY_EXECUTION_STORE_PATH = (
    (
        Path(os.environ["LOCALAPPDATA"])
        if "LOCALAPPDATA" in os.environ
        else Path.home() / ".local" / "share"
    )
    / "ElderProtocol"
    / f"v{PROTOCOL_VERSION}"
    / "canary-executions.db"
)


def _canonical_canary_execution_store() -> SQLiteCanaryExecutionStore:
    return SQLiteCanaryExecutionStore(
        _CANONICAL_CANARY_EXECUTION_STORE_PATH
    )


def _utc_now() -> datetime:
    return datetime.now(tz=UTC)


def _content_digest(value: dict[str, Any]) -> str:
    return canonical_sha256(
        {key: item for key, item in value.items() if key != "content_sha256"}
    )


def _finalize(value: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(value)
    result["content_sha256"] = _content_digest(result)
    return result


def _require_fields(
    value: Any,
    required: set[str],
    label: str,
) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != required:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(required)}")
    return value


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value


def _require_sha256(
    value: Any,
    label: str,
    *,
    allow_none: bool = False,
) -> str | None:
    if value is None and allow_none:
        return None
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise ProtocolError(f"{label} must be a lowercase SHA-256 digest.")
    return value


def _require_number(
    value: Any,
    label: str,
    *,
    minimum: float,
    maximum: float,
) -> float:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not minimum <= float(value) <= maximum
    ):
        raise ProtocolError(f"{label} must be within {minimum}-{maximum}.")
    return float(value)


def _require_integer(
    value: Any,
    label: str,
    *,
    minimum: int,
    maximum: int,
) -> int:
    if (
        not isinstance(value, int)
        or isinstance(value, bool)
        or not minimum <= value <= maximum
    ):
        raise ProtocolError(f"{label} must be within {minimum}-{maximum}.")
    return value


def _parse_datetime(value: Any, label: str) -> datetime:
    if not isinstance(value, str):
        raise ProtocolError(f"{label} must be an ISO-8601 timestamp.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO-8601 timestamp.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed


def _verify_digest(value: dict[str, Any], label: str) -> None:
    if value.get("content_sha256") != _content_digest(value):
        raise ProtocolError(f"{label} content digest is invalid.")


def _require_string_list(value: Any, label: str) -> list[str]:
    if (
        not isinstance(value, list)
        or not value
        or any(not isinstance(item, str) or not item.strip() for item in value)
        or len(value) != len(set(value))
    ):
        raise ProtocolError(f"{label} must be a non-empty unique string list.")
    return value


def _autonomy_class(
    registry: dict[str, Any],
    autonomy_class_id: str,
) -> dict[str, Any]:
    matches = [
        item
        for item in registry.get("classes", [])
        if item.get("id") == autonomy_class_id
    ]
    if len(matches) != 1:
        raise ProtocolError(
            f"Unknown or duplicated autonomy class: {autonomy_class_id}"
        )
    return matches[0]


def _require_canary_url_prefix(
    value: Any,
    target: Any,
    label: str,
) -> str:
    prefix = _require_string(value, label)
    target_value = _require_string(target, f"{label} target").strip("/")
    parsed = urlparse(prefix)
    expected_path = f"/{target_value}/canaries/"
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or unquote(parsed.path) != expected_path
    ):
        raise ProtocolError(
            f"{label} must be a credential-free HTTPS prefix for "
            f"'{expected_path}'."
        )
    return prefix


def validate_canary_plan(
    plan: dict[str, Any],
    policy: dict[str, Any],
) -> dict[str, Any]:
    validate_against_schema(
        plan,
        "canary-plan.schema.json",
        label="Canary plan",
    )
    _require_fields(
        plan,
        {
            "version",
            "plan_id",
            "project_id",
            "work_item_id",
            "autonomy_class_id",
            "certification_id",
            "qualification_consumption_sha256",
            "artifact_sha256",
            "rollback_artifact_sha256",
            "environment",
            "target",
            "traffic",
            "timing",
            "health",
            "rollback",
            "evidence",
            "content_sha256",
        },
        "Canary plan",
    )
    if plan["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Canary plan version must be '{PROTOCOL_VERSION}'."
        )
    for field in [
        "plan_id",
        "project_id",
        "work_item_id",
        "autonomy_class_id",
        "certification_id",
        "environment",
        "target",
    ]:
        _require_string(plan[field], f"Canary plan {field}")
    if plan["environment"] != "production":
        raise ProtocolError("P5.3 canary plans must target production.")
    for field in [
        "qualification_consumption_sha256",
        "artifact_sha256",
        "rollback_artifact_sha256",
    ]:
        _require_sha256(plan[field], f"Canary plan {field}")
    if plan["artifact_sha256"] == plan["rollback_artifact_sha256"]:
        raise ProtocolError(
            "Canary artifact and rollback artifact must be different."
        )
    traffic = _require_fields(
        plan["traffic"],
        {"initial_percent", "maximum_percent", "step_percent"},
        "Canary traffic",
    )
    for field in traffic:
        _require_integer(
            traffic[field],
            f"Canary traffic {field}",
            minimum=1,
            maximum=100,
        )
    if (
        traffic["initial_percent"] > traffic["maximum_percent"]
        or traffic["step_percent"] > traffic["maximum_percent"]
    ):
        raise ProtocolError("Canary traffic percentages are inconsistent.")
    timing = _require_fields(
        plan["timing"],
        {"observation_window_minutes", "maximum_duration_minutes"},
        "Canary timing",
    )
    for field in timing:
        _require_integer(
            timing[field],
            f"Canary timing {field}",
            minimum=1,
            maximum=1440,
        )
    if (
        timing["maximum_duration_minutes"]
        < timing["observation_window_minutes"]
    ):
        raise ProtocolError(
            "Canary duration must include at least one observation window."
        )
    health = _require_fields(
        plan["health"],
        {
            "minimum_sample_count",
            "maximum_error_rate",
            "maximum_p95_latency_ms",
            "minimum_success_rate",
        },
        "Canary health thresholds",
    )
    _require_integer(
        health["minimum_sample_count"],
        "Canary minimum_sample_count",
        minimum=1,
        maximum=10_000_000,
    )
    _require_number(
        health["maximum_error_rate"],
        "Canary maximum_error_rate",
        minimum=0,
        maximum=1,
    )
    _require_number(
        health["maximum_p95_latency_ms"],
        "Canary maximum_p95_latency_ms",
        minimum=1,
        maximum=3_600_000,
    )
    _require_number(
        health["minimum_success_rate"],
        "Canary minimum_success_rate",
        minimum=0,
        maximum=1,
    )
    rollback = _require_fields(
        plan["rollback"],
        {"automatic", "maximum_minutes", "require_immutable_predecessor"},
        "Canary rollback",
    )
    if rollback["automatic"] is not True:
        raise ProtocolError("P5.3 canary rollback must be automatic.")
    if rollback["require_immutable_predecessor"] is not True:
        raise ProtocolError(
            "P5.3 canary rollback requires an immutable predecessor."
        )
    _require_integer(
        rollback["maximum_minutes"],
        "Canary rollback maximum_minutes",
        minimum=1,
        maximum=120,
    )
    _require_string_list(plan["evidence"], "Canary plan evidence")
    _verify_digest(plan, f"Canary plan '{plan['plan_id']}'")
    return plan


def simulate_canary_plan(
    plan: dict[str, Any],
    policy: dict[str, Any],
) -> dict[str, Any]:
    validate_canary_plan(plan, policy)
    canary = policy["canary"]
    blockers: list[str] = []
    if plan["traffic"]["maximum_percent"] > canary["maximum_traffic_percent"]:
        blockers.append("traffic-exceeds-policy")
    if (
        plan["timing"]["maximum_duration_minutes"]
        > canary["maximum_duration_minutes"]
    ):
        blockers.append("duration-exceeds-policy")
    if (
        plan["timing"]["observation_window_minutes"]
        < canary["minimum_observation_window_minutes"]
    ):
        blockers.append("observation-window-below-policy")
    if plan["rollback"]["maximum_minutes"] > canary["maximum_rollback_minutes"]:
        blockers.append("rollback-window-exceeds-policy")
    if canary["require_automatic_rollback"] and not plan["rollback"]["automatic"]:
        blockers.append("automatic-rollback-missing")
    if (
        canary["require_immutable_predecessor"]
        and not plan["rollback"]["require_immutable_predecessor"]
    ):
        blockers.append("immutable-predecessor-missing")
    report = {
        "version": PROTOCOL_VERSION,
        "report_id": f"canary-simulation-{plan['plan_id']}",
        "plan_id": plan["plan_id"],
        "plan_sha256": plan["content_sha256"],
        "status": "passed" if not blockers else "blocked",
        "blockers": sorted(set(blockers)),
        "side_effects_performed": [],
        "authority_activated": False,
        "can_execute_canary": False,
        "can_promote": False,
        "can_full_rollout": False,
    }
    return _finalize(report)


def validate_canary_provider_evidence(
    evidence: dict[str, Any],
    *,
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    validate_against_schema(
        evidence,
        "canary-provider-evidence.schema.json",
        label="Canary provider evidence",
    )
    _require_fields(
        evidence,
        {
            "version",
            "evidence_id",
            "plan_sha256",
            "project_id",
            "provider",
            "target",
            "deployment_id",
            "canary_url_prefix",
            "environment",
            "artifact_sha256",
            "rollback_artifact_sha256",
            "traffic",
            "timing",
            "health",
            "rollback",
            "controls",
            "producer_identity",
            "source_uri",
            "issued_at",
            "expires_at",
            "attestation",
            "content_sha256",
        },
        "Canary provider evidence",
    )
    if evidence["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Canary provider evidence version must be '{PROTOCOL_VERSION}'."
        )
    evidence_id = _require_string(
        evidence["evidence_id"], "Canary provider evidence id"
    )
    for field in [
        "project_id",
        "provider",
        "target",
        "deployment_id",
        "environment",
        "producer_identity",
        "source_uri",
    ]:
        _require_string(evidence[field], f"Canary provider evidence {field}")
    if evidence["environment"] != "production":
        raise ProtocolError("Canary provider evidence must target production.")
    _require_canary_url_prefix(
        evidence["canary_url_prefix"],
        evidence["target"],
        "Canary provider evidence url prefix",
    )
    if any(
        character
        not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
        for character in evidence["deployment_id"]
    ):
        raise ProtocolError(
            "Canary provider evidence deployment_id must be URL-safe."
        )
    for field in [
        "plan_sha256",
        "artifact_sha256",
        "rollback_artifact_sha256",
    ]:
        _require_sha256(evidence[field], f"Canary provider evidence {field}")
    for field in ["traffic", "timing", "health", "rollback"]:
        if not isinstance(evidence[field], dict):
            raise ProtocolError(
                f"Canary provider evidence {field} must be an object."
            )
    controls = _require_fields(
        evidence["controls"],
        set(policy["canary"]["provider_evidence_required_controls"]),
        "Canary provider evidence controls",
    )
    if any(status != "verified" for status in controls.values()):
        raise ProtocolError(
            "Every required canary provider control must be verified."
        )
    issued_at = _parse_datetime(
        evidence["issued_at"], "Canary provider evidence issued_at"
    )
    expires_at = _parse_datetime(
        evidence["expires_at"], "Canary provider evidence expires_at"
    )
    evaluated_at = _parse_datetime(at, "Canary provider evidence evaluation time")
    if issued_at > evaluated_at:
        raise ProtocolError("Canary provider evidence cannot be future-dated.")
    if expires_at <= issued_at or evaluated_at >= expires_at:
        raise ProtocolError(
            "Canary provider evidence is expired or has an invalid window."
        )
    if evaluated_at - issued_at > timedelta(
        minutes=policy["canary"]["provider_evidence_maximum_age_minutes"]
    ):
        raise ProtocolError("Canary provider evidence is stale.")
    _verify_digest(evidence, f"Canary provider evidence '{evidence_id}'")
    statement = {
        key: value
        for key, value in evidence.items()
        if key not in {"attestation", "content_sha256"}
    }
    verify_trusted_statement(
        evidence["attestation"],
        statement=statement,
        qualification_policy=qualification_policy,
        provider=evidence["provider"],
        source_uri=evidence["source_uri"],
        producer_identity=evidence["producer_identity"],
        required_roles=policy["canary"][
            "provider_evidence_required_signer_roles"
        ],
        at=evaluated_at.isoformat(),
        label=f"Canary provider evidence '{evidence_id}'",
    )
    return evidence


def validate_canary_authority_evidence(
    evidence: dict[str, Any],
    *,
    plan: dict[str, Any],
    authority_evidence: dict[str, Any],
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    validate_against_schema(
        evidence,
        "canary-authority-evidence.schema.json",
        label="Canary authority evidence",
    )
    _require_fields(
        evidence,
        {
            "version",
            "evidence_id",
            "authority_evidence_sha256",
            "plan_sha256",
            "project_id",
            "autonomy_class_id",
            "certification_id",
            "target",
            "rollback_artifact_sha256",
            "traffic",
            "timing",
            "health",
            "rollback",
            "provider",
            "producer_identity",
            "source_uri",
            "issued_at",
            "expires_at",
            "attestation",
            "content_sha256",
        },
        "Canary authority evidence",
    )
    if evidence["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Canary authority evidence version must be '{PROTOCOL_VERSION}'."
        )
    evidence_id = _require_string(
        evidence["evidence_id"], "Canary authority evidence id"
    )
    for field in [
        "project_id",
        "autonomy_class_id",
        "certification_id",
        "target",
        "provider",
        "producer_identity",
        "source_uri",
    ]:
        _require_string(evidence[field], f"Canary authority evidence {field}")
    for field in [
        "authority_evidence_sha256",
        "plan_sha256",
        "rollback_artifact_sha256",
    ]:
        _require_sha256(evidence[field], f"Canary authority evidence {field}")
    expected = {
        "authority_evidence_sha256": authority_evidence["content_sha256"],
        "plan_sha256": plan["content_sha256"],
        "project_id": plan["project_id"],
        "autonomy_class_id": plan["autonomy_class_id"],
        "certification_id": plan["certification_id"],
        "target": plan["target"],
        "rollback_artifact_sha256": plan["rollback_artifact_sha256"],
        "traffic": plan["traffic"],
        "timing": plan["timing"],
        "health": plan["health"],
        "rollback": plan["rollback"],
    }
    for field, value in expected.items():
        if evidence[field] != value:
            raise ProtocolError(
                f"Canary authority evidence {field} does not match trusted authority."
            )
    issued_at = _parse_datetime(
        evidence["issued_at"], "Canary authority evidence issued_at"
    )
    expires_at = _parse_datetime(
        evidence["expires_at"], "Canary authority evidence expires_at"
    )
    evaluated_at = _parse_datetime(at, "Canary authority evidence evaluation time")
    if issued_at > evaluated_at:
        raise ProtocolError("Canary authority evidence cannot be future-dated.")
    if expires_at <= issued_at or evaluated_at >= expires_at:
        raise ProtocolError(
            "Canary authority evidence is expired or has an invalid window."
        )
    if evaluated_at - issued_at > timedelta(
        minutes=policy["canary"]["governance_evidence_maximum_age_minutes"]
    ):
        raise ProtocolError("Canary authority evidence is stale.")
    _verify_digest(evidence, f"Canary authority evidence '{evidence_id}'")
    statement = {
        key: value
        for key, value in evidence.items()
        if key not in {"attestation", "content_sha256"}
    }
    verify_trusted_statement(
        evidence["attestation"],
        statement=statement,
        qualification_policy=qualification_policy,
        provider=evidence["provider"],
        source_uri=evidence["source_uri"],
        producer_identity=evidence["producer_identity"],
        required_roles=policy["canary"][
            "provider_evidence_required_signer_roles"
        ],
        at=evaluated_at.isoformat(),
        label=f"Canary authority evidence '{evidence_id}'",
    )
    return evidence


def issue_canary_lease(
    policy: dict[str, Any],
    *,
    plan: dict[str, Any],
    canary_simulation_report: dict[str, Any],
    work_item: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    project_autonomy_ceiling: str,
    certification: dict[str, Any],
    certification_events: list[dict[str, Any]],
    certification_replay_report: dict[str, Any],
    qualification_consumption: dict[str, Any],
    incident_budget: dict[str, Any],
    suspensions: list[dict[str, Any]],
    revocations: list[dict[str, Any]],
    authority_evidence: dict[str, Any],
    canary_authority_evidence: dict[str, Any],
    qualification_manifest_path: Path,
    qualification_policy: dict[str, Any],
    maturity_model: dict[str, Any],
    qualification_state_checks: dict[str, dict[str, Any]],
    artifact_sha256: str,
    effective_autonomy_report: dict[str, Any],
    match_report: dict[str, Any],
    simulation_report: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    evaluated_at = _parse_datetime(at, "Canary lease issue time")
    validate_autonomy_policy(
        policy,
        registry,
        change_classes,
        qualification_policy=qualification_policy,
        maturity_model=maturity_model,
    )
    validate_autonomy_work_item(work_item)
    validate_canary_plan(plan, policy)
    autonomy_class = _autonomy_class(registry, work_item["autonomy_class_id"])
    if "canary" not in autonomy_class["allowed_consequences"]:
        raise ProtocolError(
            "The selected autonomy class is not certified for canary consequences."
        )
    validate_certification(
        certification,
        policy=policy,
        autonomy_class=autonomy_class,
    )
    recomputed_replay = replay_certification(
        certification,
        autonomy_class,
        certification_events,
        policy=policy,
        at=evaluated_at.isoformat(),
    )
    if certification_replay_report != recomputed_replay:
        raise ProtocolError(
            "Canary certification replay does not match trusted recomputation."
        )
    reverified_consumption = consume_qualification(
        qualification_manifest_path,
        qualification_policy,
        maturity_model,
        policy,
        project_id=work_item["project_id"],
        environment=certification["environment"],
        artifact_sha256=artifact_sha256,
        requested_level=policy["canary"]["required_effective_level"],
        state_checks=qualification_state_checks,
        at=evaluated_at.isoformat(),
    )
    if qualification_consumption != reverified_consumption:
        raise ProtocolError(
            "Canary qualification consumption does not match L3 re-verification."
        )
    recomputed_effective = calculate_effective_autonomy(
        policy,
        registry,
        change_classes,
        project_id=work_item["project_id"],
        project_autonomy_ceiling=project_autonomy_ceiling,
        autonomy_class_id=work_item["autonomy_class_id"],
        certification=certification,
        qualification_consumption=reverified_consumption,
        incident_budget=incident_budget,
        suspensions=suspensions,
        revocations=revocations,
        at=evaluated_at.isoformat(),
    )
    recomputed_match = match_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=policy,
    )
    recomputed_simulation = simulate_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=policy,
    )
    recomputed_canary_simulation = simulate_canary_plan(plan, policy)
    for provided, expected, label in [
        (
            effective_autonomy_report,
            recomputed_effective,
            "Effective-autonomy report",
        ),
        (match_report, recomputed_match, "Autonomy match report"),
        (
            simulation_report,
            recomputed_simulation,
            "Autonomy simulation report",
        ),
        (
            canary_simulation_report,
            recomputed_canary_simulation,
            "Canary simulation report",
        ),
    ]:
        if provided != expected:
            raise ProtocolError(
                f"{label} does not match trusted recomputation."
            )
    validate_autonomy_authority_evidence(
        authority_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        registry=registry,
        change_classes=change_classes,
        maturity_model=maturity_model,
        project_autonomy_ceiling=project_autonomy_ceiling,
        work_item=work_item,
        certification=certification,
        certification_events=certification_events,
        certification_replay_report=recomputed_replay,
        qualification_consumption=reverified_consumption,
        incident_budget=incident_budget,
        suspensions=suspensions,
        revocations=revocations,
        qualification_state_checks=qualification_state_checks,
        artifact_sha256=artifact_sha256,
        effective_autonomy_report=recomputed_effective,
        match_report=recomputed_match,
        simulation_report=recomputed_simulation,
        at=evaluated_at.isoformat(),
    )
    validate_canary_authority_evidence(
        canary_authority_evidence,
        plan=plan,
        authority_evidence=authority_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        at=evaluated_at.isoformat(),
    )
    bindings = {
        "project_id": work_item["project_id"],
        "work_item_id": work_item["work_item_id"],
        "autonomy_class_id": work_item["autonomy_class_id"],
        "certification_id": certification["certification_id"],
        "qualification_consumption_sha256": reverified_consumption[
            "content_sha256"
        ],
        "artifact_sha256": artifact_sha256,
    }
    for field, expected in bindings.items():
        if plan[field] != expected:
            raise ProtocolError(
                f"Canary plan {field} does not match trusted authority."
            )
    blockers: list[str] = []
    if not policy["authority"]["can_issue_runtime_lease"]:
        blockers.append("policy-forbids-runtime-lease")
    if not policy["authority"]["can_execute_canary"]:
        blockers.append("policy-forbids-canary")
    effective_level = recomputed_effective.get("effective_level")
    if (
        effective_level is None
        or LEVELS.index(effective_level)
        < LEVELS.index(policy["canary"]["required_effective_level"])
    ):
        blockers.append("effective-autonomy-below-l3")
    blockers.extend(recomputed_effective.get("blockers", []))
    if recomputed_match.get("matched") is not True:
        blockers.extend(recomputed_match.get("blockers", []))
    if recomputed_simulation.get("status") != "passed":
        blockers.extend(recomputed_simulation.get("blockers", []))
    if recomputed_canary_simulation.get("status") != "passed":
        blockers.extend(recomputed_canary_simulation.get("blockers", []))
    if certification["status"] != "active":
        blockers.append("certification-not-active")
    if recomputed_replay["derived_status"] != "active":
        blockers.append("certification-lifecycle-not-active")
    if (
        recomputed_replay["incident_budget_exhausted"]
        or recomputed_replay["suspension_required"]
    ):
        blockers.append("certification-lifecycle-requires-suspension")
    if blockers:
        raise ProtocolError(
            "Canary authority lease denied: "
            + ", ".join(sorted(set(blockers)))
        )
    maximum_expiry = min(
        evaluated_at
        + timedelta(minutes=policy["canary"]["lease_ttl_minutes"]),
        _parse_datetime(certification["valid_until"], "Certification valid_until"),
        _parse_datetime(
            reverified_consumption["valid_until"],
            "Qualification valid_until",
        ),
        _parse_datetime(
            authority_evidence["expires_at"],
            "Authority evidence expires_at",
        ),
        _parse_datetime(
            canary_authority_evidence["expires_at"],
            "Canary authority evidence expires_at",
        ),
        _parse_datetime(
            incident_budget["window_ends_at"],
            "Incident budget window_ends_at",
        ),
    )
    lease = {
        "version": PROTOCOL_VERSION,
        "lease_id": f"canary-lease-{plan['plan_id']}",
        "plan_id": plan["plan_id"],
        "plan_sha256": plan["content_sha256"],
        "project_id": plan["project_id"],
        "work_item_id": plan["work_item_id"],
        "autonomy_class_id": plan["autonomy_class_id"],
        "certification_id": plan["certification_id"],
        "authority_evidence_sha256": authority_evidence["content_sha256"],
        "canary_authority_evidence_sha256": canary_authority_evidence[
            "content_sha256"
        ],
        "certification_sha256": certification["content_sha256"],
        "certification_replay_sha256": recomputed_replay["content_sha256"],
        "qualification_consumption_sha256": reverified_consumption[
            "content_sha256"
        ],
        "effective_autonomy_sha256": recomputed_effective["content_sha256"],
        "match_report_sha256": recomputed_match["content_sha256"],
        "simulation_report_sha256": recomputed_simulation["content_sha256"],
        "canary_simulation_sha256": recomputed_canary_simulation[
            "content_sha256"
        ],
        "artifact_sha256": artifact_sha256,
        "rollback_artifact_sha256": plan["rollback_artifact_sha256"],
        "issued_at": evaluated_at.isoformat(),
        "expires_at": maximum_expiry.isoformat(),
        "permitted_actions": [
            "canary:start",
            "canary:observe",
            "canary:rollback",
        ],
        "forbidden_actions": [
            "full-rollout",
            "canary:promote",
            "merge",
            "maturity-mutation",
            "automatic-renewal",
        ],
        "can_execute_canary": True,
        "can_rollback": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_merge": False,
        "can_mutate_maturity": False,
        "can_auto_renew": False,
    }
    return _finalize(lease)


def validate_canary_lease(lease: dict[str, Any]) -> dict[str, Any]:
    validate_against_schema(
        lease,
        "canary-authority-lease.schema.json",
        label="Canary authority lease",
    )
    _require_fields(
        lease,
        {
            "version",
            "lease_id",
            "plan_id",
            "plan_sha256",
            "project_id",
            "work_item_id",
            "autonomy_class_id",
            "certification_id",
            "authority_evidence_sha256",
            "canary_authority_evidence_sha256",
            "certification_sha256",
            "certification_replay_sha256",
            "qualification_consumption_sha256",
            "effective_autonomy_sha256",
            "match_report_sha256",
            "simulation_report_sha256",
            "canary_simulation_sha256",
            "artifact_sha256",
            "rollback_artifact_sha256",
            "issued_at",
            "expires_at",
            "permitted_actions",
            "forbidden_actions",
            "can_execute_canary",
            "can_rollback",
            "can_promote",
            "can_full_rollout",
            "can_merge",
            "can_mutate_maturity",
            "can_auto_renew",
            "content_sha256",
        },
        "Canary authority lease",
    )
    if lease["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Canary lease version must be '{PROTOCOL_VERSION}'."
        )
    for field in [
        "lease_id",
        "plan_id",
        "project_id",
        "work_item_id",
        "autonomy_class_id",
        "certification_id",
    ]:
        _require_string(lease[field], f"Canary lease {field}")
    for field in [
        "plan_sha256",
        "authority_evidence_sha256",
        "canary_authority_evidence_sha256",
        "certification_sha256",
        "certification_replay_sha256",
        "qualification_consumption_sha256",
        "effective_autonomy_sha256",
        "match_report_sha256",
        "simulation_report_sha256",
        "canary_simulation_sha256",
        "artifact_sha256",
        "rollback_artifact_sha256",
    ]:
        _require_sha256(lease[field], f"Canary lease {field}")
    issued_at = _parse_datetime(lease["issued_at"], "Canary lease issued_at")
    expires_at = _parse_datetime(lease["expires_at"], "Canary lease expires_at")
    if expires_at <= issued_at:
        raise ProtocolError("Canary lease must expire after it is issued.")
    if lease["permitted_actions"] != [
        "canary:start",
        "canary:observe",
        "canary:rollback",
    ]:
        raise ProtocolError("Canary lease permitted actions are invalid.")
    if lease["forbidden_actions"] != [
        "full-rollout",
        "canary:promote",
        "merge",
        "maturity-mutation",
        "automatic-renewal",
    ]:
        raise ProtocolError("Canary lease forbidden actions are invalid.")
    if (
        lease["can_execute_canary"] is not True
        or lease["can_rollback"] is not True
        or lease["can_promote"] is not False
        or lease["can_full_rollout"] is not False
        or lease["can_merge"] is not False
        or lease["can_mutate_maturity"] is not False
        or lease["can_auto_renew"] is not False
    ):
        raise ProtocolError("Canary lease authority flags are invalid.")
    _verify_digest(lease, f"Canary lease '{lease['lease_id']}'")
    return lease


def create_canary_execution_packet(
    policy: dict[str, Any],
    *,
    plan: dict[str, Any],
    lease: dict[str, Any],
    provider_evidence: dict[str, Any],
    qualification_policy: dict[str, Any],
    execution_id: str,
    at: str,
) -> dict[str, Any]:
    validate_canary_plan(plan, policy)
    validate_canary_lease(lease)
    validate_canary_provider_evidence(
        provider_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    evaluated_at = _parse_datetime(at, "Canary packet creation time")
    execution_id = _require_string(execution_id, "Canary execution_id")
    if any(
        character
        not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
        for character in execution_id
    ):
        raise ProtocolError("Canary execution_id must be URL-safe.")
    if not (
        _parse_datetime(lease["issued_at"], "Canary lease issued_at")
        <= evaluated_at
        < _parse_datetime(lease["expires_at"], "Canary lease expires_at")
    ):
        raise ProtocolError("Canary lease is not active.")
    bindings = {
        "plan_id": (plan["plan_id"], lease["plan_id"]),
        "plan_sha256": (
            plan["content_sha256"],
            lease["plan_sha256"],
        ),
        "project_id": (plan["project_id"], lease["project_id"]),
        "artifact_sha256": (
            plan["artifact_sha256"],
            lease["artifact_sha256"],
        ),
        "rollback_artifact_sha256": (
            plan["rollback_artifact_sha256"],
            lease["rollback_artifact_sha256"],
        ),
    }
    for field, (actual, expected) in bindings.items():
        if actual != expected:
            raise ProtocolError(f"Canary plan {field} does not match its lease.")
    provider_bindings = {
        "plan_sha256": plan["content_sha256"],
        "project_id": plan["project_id"],
        "target": plan["target"],
        "environment": plan["environment"],
        "artifact_sha256": plan["artifact_sha256"],
        "rollback_artifact_sha256": plan["rollback_artifact_sha256"],
        "traffic": plan["traffic"],
        "timing": plan["timing"],
        "health": plan["health"],
        "rollback": plan["rollback"],
    }
    for field, expected in provider_bindings.items():
        if provider_evidence[field] != expected:
            raise ProtocolError(
                f"Canary provider evidence {field} does not match the plan."
            )
    packet = {
        "version": PROTOCOL_VERSION,
        "packet_id": f"canary-packet-{execution_id}",
        "execution_id": execution_id,
        "plan_id": plan["plan_id"],
        "plan_sha256": plan["content_sha256"],
        "lease_sha256": lease["content_sha256"],
        "provider_evidence_sha256": provider_evidence["content_sha256"],
        "canary_authority_evidence_sha256": lease[
            "canary_authority_evidence_sha256"
        ],
        "project_id": plan["project_id"],
        "provider": provider_evidence["provider"],
        "target": plan["target"],
        "deployment_id": provider_evidence["deployment_id"],
        "canary_url_prefix": provider_evidence["canary_url_prefix"],
        "start_response_timeout_minutes": policy["canary"][
            "start_response_timeout_minutes"
        ],
        "rollback_claim_timeout_minutes": policy["canary"][
            "rollback_claim_timeout_minutes"
        ],
        "environment": plan["environment"],
        "artifact_sha256": plan["artifact_sha256"],
        "rollback_artifact_sha256": plan["rollback_artifact_sha256"],
        "traffic": copy.deepcopy(plan["traffic"]),
        "timing": copy.deepcopy(plan["timing"]),
        "health": copy.deepcopy(plan["health"]),
        "rollback": copy.deepcopy(plan["rollback"]),
        "status": "ready",
        "requires_observation": True,
        "requires_automatic_rollback": True,
        "can_execute_canary": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_merge": False,
        "can_mutate_maturity": False,
    }
    return _finalize(packet)


def validate_canary_execution_packet(
    packet: dict[str, Any],
) -> dict[str, Any]:
    validate_against_schema(
        packet,
        "canary-execution-packet.schema.json",
        label="Canary execution packet",
    )
    _require_fields(
        packet,
        {
            "version",
            "packet_id",
            "execution_id",
            "plan_id",
            "plan_sha256",
            "lease_sha256",
            "provider_evidence_sha256",
            "canary_authority_evidence_sha256",
            "project_id",
            "provider",
            "target",
            "deployment_id",
            "canary_url_prefix",
            "start_response_timeout_minutes",
            "rollback_claim_timeout_minutes",
            "environment",
            "artifact_sha256",
            "rollback_artifact_sha256",
            "traffic",
            "timing",
            "health",
            "rollback",
            "status",
            "requires_observation",
            "requires_automatic_rollback",
            "can_execute_canary",
            "can_promote",
            "can_full_rollout",
            "can_merge",
            "can_mutate_maturity",
            "content_sha256",
        },
        "Canary execution packet",
    )
    if packet["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Canary packet version must be '{PROTOCOL_VERSION}'."
        )
    for field in [
        "packet_id",
        "execution_id",
        "plan_id",
        "project_id",
        "provider",
        "target",
        "deployment_id",
        "environment",
    ]:
        _require_string(packet[field], f"Canary packet {field}")
    _require_canary_url_prefix(
        packet["canary_url_prefix"],
        packet["target"],
        "Canary packet url prefix",
    )
    for field in [
        "plan_sha256",
        "lease_sha256",
        "provider_evidence_sha256",
        "canary_authority_evidence_sha256",
        "artifact_sha256",
        "rollback_artifact_sha256",
    ]:
        _require_sha256(packet[field], f"Canary packet {field}")
    if any(
        character
        not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
        for character in packet["execution_id"]
    ):
        raise ProtocolError("Canary packet execution_id must be URL-safe.")
    if any(
        character
        not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
        for character in packet["deployment_id"]
    ):
        raise ProtocolError("Canary packet deployment_id must be URL-safe.")
    _require_integer(
        packet["start_response_timeout_minutes"],
        "Canary packet start_response_timeout_minutes",
        minimum=1,
        maximum=10,
    )
    _require_integer(
        packet["rollback_claim_timeout_minutes"],
        "Canary packet rollback_claim_timeout_minutes",
        minimum=1,
        maximum=10,
    )
    for field in ["traffic", "timing", "health", "rollback"]:
        if not isinstance(packet[field], dict):
            raise ProtocolError(f"Canary packet {field} must be an object.")
    _require_integer(
        packet["rollback"].get("maximum_minutes"),
        "Canary packet rollback maximum_minutes",
        minimum=1,
        maximum=30,
    )
    if (
        packet["rollback_claim_timeout_minutes"]
        >= packet["rollback"]["maximum_minutes"]
    ):
        raise ProtocolError(
            "Canary rollback claim timeout must be shorter than its "
            "authorization window."
        )
    if (
        packet["status"] != "ready"
        or packet["requires_observation"] is not True
        or packet["requires_automatic_rollback"] is not True
        or packet["can_execute_canary"] is not True
        or packet["can_promote"] is not False
        or packet["can_full_rollout"] is not False
        or packet["can_merge"] is not False
        or packet["can_mutate_maturity"] is not False
    ):
        raise ProtocolError("Canary packet authority flags are invalid.")
    _verify_digest(packet, f"Canary packet '{packet['packet_id']}'")
    return packet


def validate_canary_response(
    response: dict[str, Any],
    *,
    packet: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    validate_against_schema(
        response,
        "canary-response.schema.json",
        label="Canary response",
    )
    validate_canary_execution_packet(packet)
    _require_fields(
        response,
        {
            "authorized_packet_sha256",
            "provider",
            "target",
            "environment",
            "artifact_sha256",
            "rollback_artifact_sha256",
            "traffic_percent",
            "deployment_id",
            "url",
            "started_at",
            "status",
            "content_sha256",
        },
        "Canary provider response",
    )
    for field in [
        "provider",
        "target",
        "environment",
        "deployment_id",
        "url",
        "status",
    ]:
        _require_string(response[field], f"Canary response {field}")
    for field in [
        "authorized_packet_sha256",
        "artifact_sha256",
        "rollback_artifact_sha256",
    ]:
        _require_sha256(response[field], f"Canary response {field}")
    _require_integer(
        response["traffic_percent"],
        "Canary response traffic_percent",
        minimum=1,
        maximum=100,
    )
    if response["status"] != "observing":
        raise ProtocolError(
            "Canary provider must return an observing deployment."
        )
    evaluated_at = _parse_datetime(at, "Canary response evaluation time")
    started_at = _parse_datetime(
        response["started_at"], "Canary response started_at"
    )
    if started_at != evaluated_at:
        raise ProtocolError(
            "Canary response started_at must match the authorized execution time."
        )
    deployment_id = response["deployment_id"]
    if any(
        character
        not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
        for character in deployment_id
    ):
        raise ProtocolError("Canary deployment_id must be URL-safe.")
    prefix = urlparse(packet["canary_url_prefix"])
    response_uri = urlparse(response["url"])
    if (
        response_uri.scheme != "https"
        or response_uri.username is not None
        or response_uri.password is not None
        or response_uri.query
        or response_uri.fragment
        or response_uri.netloc != prefix.netloc
        or unquote(response_uri.path)
        != unquote(prefix.path) + deployment_id
    ):
        raise ProtocolError(
            "Canary response URL does not match the authorized target."
        )
    expected = {
        "authorized_packet_sha256": packet["content_sha256"],
        "provider": packet["provider"],
        "target": packet["target"],
        "environment": packet["environment"],
        "artifact_sha256": packet["artifact_sha256"],
        "rollback_artifact_sha256": packet["rollback_artifact_sha256"],
        "traffic_percent": packet["traffic"]["initial_percent"],
        "deployment_id": packet["deployment_id"],
    }
    for field, value in expected.items():
        if response[field] != value:
            raise ProtocolError(
                f"Canary response {field} does not match the authorized packet."
            )
    _verify_digest(
        response,
        f"Canary provider response '{response['deployment_id']}'",
    )
    return response


def execute_canary(
    packet: dict[str, Any],
    provider: CanaryProvider,
    *,
    policy: dict[str, Any],
    plan: dict[str, Any],
    lease: dict[str, Any],
    provider_evidence: dict[str, Any],
    canary_simulation_report: dict[str, Any],
    work_item: dict[str, Any],
    registry: dict[str, Any],
    change_classes: dict[str, Any],
    project_autonomy_ceiling: str,
    certification: dict[str, Any],
    certification_events: list[dict[str, Any]],
    certification_replay_report: dict[str, Any],
    qualification_consumption: dict[str, Any],
    incident_budget: dict[str, Any],
    suspensions: list[dict[str, Any]],
    revocations: list[dict[str, Any]],
    authority_evidence: dict[str, Any],
    canary_authority_evidence: dict[str, Any],
    qualification_manifest_path: Path,
    qualification_policy: dict[str, Any],
    maturity_model: dict[str, Any],
    lease_qualification_state_checks: dict[str, dict[str, Any]],
    current_qualification_state_checks: dict[str, dict[str, Any]],
    current_certification_events: list[dict[str, Any]],
    current_incident_budget: dict[str, Any],
    current_suspensions: list[dict[str, Any]],
    current_revocations: list[dict[str, Any]],
    current_authority_evidence: dict[str, Any],
    current_canary_authority_evidence: dict[str, Any],
    artifact_sha256: str,
    effective_autonomy_report: dict[str, Any],
    match_report: dict[str, Any],
    simulation_report: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    validate_canary_execution_packet(packet)
    validate_canary_plan(plan, policy)
    validate_canary_lease(lease)
    validate_canary_provider_evidence(
        provider_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    evaluated_at = _parse_datetime(at, "Canary execution time")
    issued_at = _parse_datetime(lease["issued_at"], "Canary lease issued_at")
    expires_at = _parse_datetime(lease["expires_at"], "Canary lease expires_at")
    if evaluated_at < issued_at or evaluated_at >= expires_at:
        raise ProtocolError("Canary authority lease is not active.")
    expected_lease = issue_canary_lease(
        policy,
        plan=plan,
        canary_simulation_report=canary_simulation_report,
        work_item=work_item,
        registry=registry,
        change_classes=change_classes,
        project_autonomy_ceiling=project_autonomy_ceiling,
        certification=certification,
        certification_events=certification_events,
        certification_replay_report=certification_replay_report,
        qualification_consumption=qualification_consumption,
        incident_budget=incident_budget,
        suspensions=suspensions,
        revocations=revocations,
        authority_evidence=authority_evidence,
        canary_authority_evidence=canary_authority_evidence,
        qualification_manifest_path=qualification_manifest_path,
        qualification_policy=qualification_policy,
        maturity_model=maturity_model,
        qualification_state_checks=lease_qualification_state_checks,
        artifact_sha256=artifact_sha256,
        effective_autonomy_report=effective_autonomy_report,
        match_report=match_report,
        simulation_report=simulation_report,
        at=issued_at.isoformat(),
    )
    if lease != expected_lease:
        raise ProtocolError(
            "Canary lease does not match trusted-source recomputation."
        )
    current_consumption = reverify_qualification_consumption(
        qualification_consumption,
        manifest_path=qualification_manifest_path,
        qualification_policy=qualification_policy,
        maturity_model=maturity_model,
        autonomy_policy=policy,
        state_checks=current_qualification_state_checks,
        at=evaluated_at.isoformat(),
    )
    autonomy_class = _autonomy_class(registry, work_item["autonomy_class_id"])
    current_replay = replay_certification(
        certification,
        autonomy_class,
        current_certification_events,
        policy=policy,
        at=evaluated_at.isoformat(),
    )
    current_effective = calculate_effective_autonomy(
        policy,
        registry,
        change_classes,
        project_id=work_item["project_id"],
        project_autonomy_ceiling=project_autonomy_ceiling,
        autonomy_class_id=work_item["autonomy_class_id"],
        certification=certification,
        qualification_consumption=current_consumption,
        incident_budget=current_incident_budget,
        suspensions=current_suspensions,
        revocations=current_revocations,
        at=evaluated_at.isoformat(),
    )
    current_match = match_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=policy,
    )
    current_simulation = simulate_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=policy,
    )
    validate_autonomy_authority_evidence(
        current_authority_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        registry=registry,
        change_classes=change_classes,
        maturity_model=maturity_model,
        project_autonomy_ceiling=project_autonomy_ceiling,
        work_item=work_item,
        certification=certification,
        certification_events=current_certification_events,
        certification_replay_report=current_replay,
        qualification_consumption=current_consumption,
        incident_budget=current_incident_budget,
        suspensions=current_suspensions,
        revocations=current_revocations,
        qualification_state_checks=current_qualification_state_checks,
        artifact_sha256=artifact_sha256,
        effective_autonomy_report=current_effective,
        match_report=current_match,
        simulation_report=current_simulation,
        at=evaluated_at.isoformat(),
    )
    validate_canary_authority_evidence(
        current_canary_authority_evidence,
        plan=plan,
        authority_evidence=current_authority_evidence,
        policy=policy,
        qualification_policy=qualification_policy,
        at=evaluated_at.isoformat(),
    )
    current_blockers = list(current_effective.get("blockers", []))
    current_level = current_effective.get("effective_level")
    if (
        current_level is None
        or LEVELS.index(current_level)
        < LEVELS.index(policy["canary"]["required_effective_level"])
    ):
        current_blockers.append("effective-autonomy-below-l3")
    if current_replay["derived_status"] != "active":
        current_blockers.append("certification-lifecycle-not-active")
    if (
        current_replay["incident_budget_exhausted"]
        or current_replay["suspension_required"]
    ):
        current_blockers.append("certification-lifecycle-requires-suspension")
    if current_match["matched"] is not True:
        current_blockers.extend(current_match["blockers"])
    if current_simulation["status"] != "passed":
        current_blockers.extend(current_simulation["blockers"])
    if current_blockers:
        raise ProtocolError(
            "Canary execution denied by current governance: "
            + ", ".join(sorted(set(current_blockers)))
        )
    expected_packet = create_canary_execution_packet(
        policy,
        plan=plan,
        lease=lease,
        provider_evidence=provider_evidence,
        qualification_policy=qualification_policy,
        execution_id=packet["execution_id"],
        at=evaluated_at.isoformat(),
    )
    if packet != expected_packet:
        raise ProtocolError(
            "Canary packet does not match its plan, lease, and provider evidence."
        )
    execution_store = _canonical_canary_execution_store()
    execution_store.claim(packet, at=evaluated_at.isoformat())
    _schedule_canary_deadline(packet, provider)
    try:
        response = provider.start_canary(copy.deepcopy(packet))
        _require_fields(
            response,
            {
                "authorized_packet_sha256",
                "provider",
                "target",
                "environment",
                "artifact_sha256",
                "rollback_artifact_sha256",
                "traffic_percent",
                "deployment_id",
                "url",
                "started_at",
                "status",
            },
            "Raw canary provider response",
        )
        accepted_response = _finalize(response)
        validate_canary_response(
            accepted_response,
            packet=packet,
            at=evaluated_at.isoformat(),
        )
    except Exception as start_error:
        try:
            _recover_uncertain_canary_start(
                packet,
                provider,
            )
        except Exception as rollback_error:
            raise ProtocolError(
                "Canary start failed and uncertain-start rollback also failed: "
                f"{rollback_error}"
            ) from start_error
        raise
    execution_store.complete(packet, accepted_response)
    try:
        _schedule_canary_deadline(packet, provider)
    except Exception as schedule_error:
        rollback_packet = create_canary_watchdog_recovery_packet(
            packet,
            accepted_response,
        )
        rollback_requested_at = rollback_packet["requested_at"]
        if not execution_store.claim_rollback(
            packet,
            rollback_packet,
            at=rollback_requested_at,
            require_deadline=False,
        ):
            raise ProtocolError(
                "Canary deadline watchdog failed and rollback could not be "
                "claimed."
            ) from schedule_error
        try:
            _complete_registered_rollback(
                packet,
                rollback_packet,
                provider,
            )
        except Exception as rollback_error:
            raise ProtocolError(
                "Canary deadline watchdog failed and compensating rollback "
                f"also failed: {rollback_error}"
            ) from schedule_error
        raise ProtocolError(
            "Canary deadline watchdog failed; the canary was rolled back."
        ) from schedule_error
    return accepted_response


def validate_canary_observation(
    observation: dict[str, Any],
    *,
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    validate_against_schema(
        observation,
        "canary-observation.schema.json",
        label="Canary observation",
    )
    _require_fields(
        observation,
        {
            "version",
            "observation_id",
            "authorized_packet_sha256",
            "provider",
            "target",
            "deployment_id",
            "artifact_sha256",
            "observed_at",
            "sample_count",
            "metrics",
            "producer_identity",
            "source_uri",
            "attestation",
            "content_sha256",
        },
        "Canary observation",
    )
    if observation["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Canary observation version must be '{PROTOCOL_VERSION}'."
        )
    observation_id = _require_string(
        observation["observation_id"], "Canary observation id"
    )
    for field in [
        "provider",
        "target",
        "deployment_id",
        "producer_identity",
        "source_uri",
    ]:
        _require_string(observation[field], f"Canary observation {field}")
    for field in ["authorized_packet_sha256", "artifact_sha256"]:
        _require_sha256(observation[field], f"Canary observation {field}")
    _require_integer(
        observation["sample_count"],
        "Canary observation sample_count",
        minimum=0,
        maximum=10_000_000,
    )
    metrics = _require_fields(
        observation["metrics"],
        {"error_rate", "p95_latency_ms", "success_rate"},
        "Canary observation metrics",
    )
    _require_number(
        metrics["error_rate"],
        "Canary observation error_rate",
        minimum=0,
        maximum=1,
    )
    _require_number(
        metrics["p95_latency_ms"],
        "Canary observation p95_latency_ms",
        minimum=0,
        maximum=3_600_000,
    )
    _require_number(
        metrics["success_rate"],
        "Canary observation success_rate",
        minimum=0,
        maximum=1,
    )
    observed_at = _parse_datetime(
        observation["observed_at"], "Canary observation observed_at"
    )
    evaluated_at = _parse_datetime(at, "Canary observation evaluation time")
    if observed_at > evaluated_at:
        raise ProtocolError("Canary observation cannot be future-dated.")
    if evaluated_at - observed_at > timedelta(
        minutes=policy["canary"]["observation_maximum_age_minutes"]
    ):
        raise ProtocolError("Canary observation is stale.")
    _verify_digest(observation, f"Canary observation '{observation_id}'")
    statement = {
        key: value
        for key, value in observation.items()
        if key not in {"attestation", "content_sha256"}
    }
    verify_trusted_statement(
        observation["attestation"],
        statement=statement,
        qualification_policy=qualification_policy,
        provider=observation["provider"],
        source_uri=observation["source_uri"],
        producer_identity=observation["producer_identity"],
        required_roles=policy["canary"][
            "provider_evidence_required_signer_roles"
        ],
        at=evaluated_at.isoformat(),
        label=f"Canary observation '{observation_id}'",
    )
    return observation


def evaluate_canary_observation(
    observation: dict[str, Any],
    *,
    packet: dict[str, Any],
    response: dict[str, Any],
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    validate_canary_execution_packet(packet)
    validate_canary_response(response, packet=packet, at=response["started_at"])
    validate_canary_observation(
        observation,
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    bindings = {
        "authorized_packet_sha256": packet["content_sha256"],
        "provider": packet["provider"],
        "target": packet["target"],
        "artifact_sha256": packet["artifact_sha256"],
        "deployment_id": response["deployment_id"],
    }
    for field, expected in bindings.items():
        if observation[field] != expected:
            raise ProtocolError(
                f"Canary observation {field} does not match the packet."
            )
    metrics = observation["metrics"]
    thresholds = packet["health"]
    observed_at = _parse_datetime(
        observation["observed_at"], "Canary observation observed_at"
    )
    started_at = _parse_datetime(
        response["started_at"], "Canary response started_at"
    )
    if observed_at < started_at:
        raise ProtocolError(
            "Canary observation cannot predate its provider deployment."
        )
    evaluated_at = _parse_datetime(at, "Canary observation evaluation time")
    observation_elapsed_minutes = (
        observed_at - started_at
    ).total_seconds() / 60
    elapsed_minutes = (evaluated_at - started_at).total_seconds() / 60
    if elapsed_minutes < 0:
        raise ProtocolError(
            "Canary observation evaluation cannot predate deployment."
        )
    observation_window_complete = (
        observation_elapsed_minutes
        >= packet["timing"]["observation_window_minutes"]
    )
    breaches: list[str] = []
    if elapsed_minutes >= packet["timing"]["maximum_duration_minutes"]:
        breaches.append("maximum-duration")
    if observation["sample_count"] < thresholds["minimum_sample_count"]:
        breaches.append("insufficient-samples")
    if metrics["error_rate"] > thresholds["maximum_error_rate"]:
        breaches.append("error-rate")
    if metrics["p95_latency_ms"] > thresholds["maximum_p95_latency_ms"]:
        breaches.append("p95-latency")
    if metrics["success_rate"] < thresholds["minimum_success_rate"]:
        breaches.append("success-rate")
    report = {
        "version": PROTOCOL_VERSION,
        "report_id": f"canary-observation-{observation['observation_id']}",
        "authorized_packet_sha256": packet["content_sha256"],
        "response_sha256": response["content_sha256"],
        "observation_sha256": observation["content_sha256"],
        "elapsed_minutes": elapsed_minutes,
        "observation_elapsed_minutes": observation_elapsed_minutes,
        "observation_window_complete": observation_window_complete,
        "status": "rollback-required" if breaches else "continue-observing",
        "threshold_breaches": breaches,
        "rollback_required": bool(breaches),
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(report)


def create_canary_rollback_packet(
    observation: dict[str, Any],
    *,
    packet: dict[str, Any],
    response: dict[str, Any],
    observation_report: dict[str, Any],
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    evaluated_at = _parse_datetime(at, "Canary rollback request time")
    expected_report = evaluate_canary_observation(
        observation,
        packet=packet,
        response=response,
        policy=policy,
        qualification_policy=qualification_policy,
        at=evaluated_at.isoformat(),
    )
    if observation_report != expected_report:
        raise ProtocolError(
            "Canary observation report does not match trusted recomputation."
        )
    if observation_report["rollback_required"] is not True:
        raise ProtocolError(
            "A healthy canary observation cannot create rollback authority."
        )
    rollback_packet = {
        "version": PROTOCOL_VERSION,
        "rollback_id": f"rollback-{response['deployment_id']}",
        "trigger": "observation-breach",
        "authorized_packet_sha256": packet["content_sha256"],
        "response_sha256": response["content_sha256"],
        "observation_sha256": observation["content_sha256"],
        "observation_report_sha256": observation_report["content_sha256"],
        "provider": packet["provider"],
        "target": packet["target"],
        "deployment_id": response["deployment_id"],
        "failed_artifact_sha256": packet["artifact_sha256"],
        "rollback_artifact_sha256": packet["rollback_artifact_sha256"],
        "threshold_breaches": copy.deepcopy(
            observation_report["threshold_breaches"]
        ),
        "requested_at": evaluated_at.isoformat(),
        "required_by": (
            evaluated_at
            + timedelta(minutes=packet["rollback"]["maximum_minutes"])
        ).isoformat(),
        "status": "ready",
        "can_rollback": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(rollback_packet)


def validate_canary_rollback_packet(
    rollback_packet: dict[str, Any],
) -> dict[str, Any]:
    validate_against_schema(
        rollback_packet,
        "canary-rollback-packet.schema.json",
        label="Canary rollback packet",
    )
    _require_fields(
        rollback_packet,
        {
            "version",
            "rollback_id",
            "trigger",
            "authorized_packet_sha256",
            "response_sha256",
            "observation_sha256",
            "observation_report_sha256",
            "provider",
            "target",
            "deployment_id",
            "failed_artifact_sha256",
            "rollback_artifact_sha256",
            "threshold_breaches",
            "requested_at",
            "required_by",
            "status",
            "can_rollback",
            "can_promote",
            "can_full_rollout",
            "can_mutate_maturity",
            "content_sha256",
        },
        "Canary rollback packet",
    )
    if rollback_packet["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Canary rollback packet version must be '{PROTOCOL_VERSION}'."
        )
    for field in [
        "rollback_id",
        "trigger",
        "provider",
        "target",
        "deployment_id",
    ]:
        _require_string(
            rollback_packet[field], f"Canary rollback packet {field}"
        )
    if rollback_packet["trigger"] not in {
        "observation-breach",
        "telemetry-deadline",
        "start-uncertain",
        "watchdog-unavailable",
    }:
        raise ProtocolError("Canary rollback trigger is invalid.")
    for field in [
        "authorized_packet_sha256",
        "failed_artifact_sha256",
        "rollback_artifact_sha256",
    ]:
        _require_sha256(
            rollback_packet[field], f"Canary rollback packet {field}"
        )
    _require_sha256(
        rollback_packet["response_sha256"],
        "Canary rollback packet response_sha256",
        allow_none=True,
    )
    for field in ["observation_sha256", "observation_report_sha256"]:
        _require_sha256(
            rollback_packet[field],
            f"Canary rollback packet {field}",
            allow_none=True,
        )
    if rollback_packet["trigger"] == "observation-breach":
        if (
            rollback_packet["response_sha256"] is None
            or
            rollback_packet["observation_sha256"] is None
            or rollback_packet["observation_report_sha256"] is None
        ):
            raise ProtocolError(
                "Observation-triggered rollback requires observation evidence."
            )
    elif rollback_packet["trigger"] == "telemetry-deadline" and (
        rollback_packet["response_sha256"] is None
        or
        rollback_packet["observation_sha256"] is not None
        or rollback_packet["observation_report_sha256"] is not None
        or rollback_packet["threshold_breaches"] != ["telemetry-deadline"]
    ):
        raise ProtocolError(
            "Telemetry-deadline rollback cannot claim observation evidence."
        )
    elif rollback_packet["trigger"] == "start-uncertain" and (
        rollback_packet["response_sha256"] is not None
        or rollback_packet["observation_sha256"] is not None
        or rollback_packet["observation_report_sha256"] is not None
        or rollback_packet["threshold_breaches"] != ["start-uncertain"]
    ):
        raise ProtocolError(
            "Uncertain-start rollback cannot claim accepted response or "
            "observation evidence."
        )
    elif rollback_packet["trigger"] == "watchdog-unavailable" and (
        rollback_packet["response_sha256"] is None
        or rollback_packet["observation_sha256"] is not None
        or rollback_packet["observation_report_sha256"] is not None
        or rollback_packet["threshold_breaches"] != ["watchdog-unavailable"]
    ):
        raise ProtocolError(
            "Watchdog-unavailable rollback requires the accepted response "
            "without observation evidence."
        )
    _require_string_list(
        rollback_packet["threshold_breaches"],
        "Canary rollback threshold_breaches",
    )
    requested_at = _parse_datetime(
        rollback_packet["requested_at"], "Canary rollback requested_at"
    )
    required_by = _parse_datetime(
        rollback_packet["required_by"], "Canary rollback required_by"
    )
    if required_by <= requested_at:
        raise ProtocolError(
            "Canary rollback deadline must follow its request time."
        )
    if (
        rollback_packet["status"] != "ready"
        or rollback_packet["can_rollback"] is not True
        or rollback_packet["can_promote"] is not False
        or rollback_packet["can_full_rollout"] is not False
        or rollback_packet["can_mutate_maturity"] is not False
    ):
        raise ProtocolError("Canary rollback packet authority flags are invalid.")
    _verify_digest(
        rollback_packet,
        f"Canary rollback packet '{rollback_packet['rollback_id']}'",
    )
    return rollback_packet


def execute_canary_rollback(
    rollback_packet: dict[str, Any],
    provider: CanaryProvider,
    *,
    observation: dict[str, Any],
    packet: dict[str, Any],
    response: dict[str, Any],
    observation_report: dict[str, Any],
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    store = _canonical_canary_execution_store()
    stored_response = store.accepted_response(packet)
    if response != stored_response:
        raise ProtocolError(
            "Canary rollback response context does not match canonical "
            "runtime state."
        )
    validate_canary_rollback_packet(rollback_packet)
    expected_packet = create_canary_rollback_packet(
        observation,
        packet=packet,
        response=response,
        observation_report=observation_report,
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    if rollback_packet != expected_packet:
        raise ProtocolError(
            "Canary rollback packet does not match trusted recomputation."
        )
    runtime_at = _active_rollback_runtime_time(rollback_packet)
    if not store.claim_rollback(
        packet,
        rollback_packet,
        at=runtime_at,
        require_deadline=False,
    ):
        raise ProtocolError(
            "Canary rollback has already been claimed or completed."
        )
    return _invoke_claimed_canary_rollback(
        packet,
        rollback_packet,
        provider,
    )


def create_canary_start_recovery_packet(
    packet: dict[str, Any],
) -> dict[str, Any]:
    validate_canary_execution_packet(packet)
    evaluated_at = _utc_now()
    rollback_packet = {
        "version": PROTOCOL_VERSION,
        "rollback_id": f"rollback-{packet['deployment_id']}",
        "trigger": "start-uncertain",
        "authorized_packet_sha256": packet["content_sha256"],
        "response_sha256": None,
        "observation_sha256": None,
        "observation_report_sha256": None,
        "provider": packet["provider"],
        "target": packet["target"],
        "deployment_id": packet["deployment_id"],
        "failed_artifact_sha256": packet["artifact_sha256"],
        "rollback_artifact_sha256": packet["rollback_artifact_sha256"],
        "threshold_breaches": ["start-uncertain"],
        "requested_at": evaluated_at.isoformat(),
        "required_by": (
            evaluated_at
            + timedelta(minutes=packet["rollback"]["maximum_minutes"])
        ).isoformat(),
        "status": "ready",
        "can_rollback": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(rollback_packet)


def create_canary_deadline_rollback_packet(
    packet: dict[str, Any],
    response: dict[str, Any],
    *,
    at: str,
) -> dict[str, Any]:
    validate_canary_execution_packet(packet)
    validate_canary_response(response, packet=packet, at=response["started_at"])
    evaluated_at = _parse_datetime(at, "Canary deadline evaluation time")
    started_at = _parse_datetime(
        response["started_at"], "Canary response started_at"
    )
    deadline = started_at + timedelta(
        minutes=packet["timing"]["maximum_duration_minutes"]
    )
    if evaluated_at < deadline:
        raise ProtocolError(
            "Canary telemetry deadline has not been reached."
        )
    rollback_packet = {
        "version": PROTOCOL_VERSION,
        "rollback_id": f"rollback-{response['deployment_id']}",
        "trigger": "telemetry-deadline",
        "authorized_packet_sha256": packet["content_sha256"],
        "response_sha256": response["content_sha256"],
        "observation_sha256": None,
        "observation_report_sha256": None,
        "provider": packet["provider"],
        "target": packet["target"],
        "deployment_id": response["deployment_id"],
        "failed_artifact_sha256": packet["artifact_sha256"],
        "rollback_artifact_sha256": packet["rollback_artifact_sha256"],
        "threshold_breaches": ["telemetry-deadline"],
        "requested_at": evaluated_at.isoformat(),
        "required_by": (
            evaluated_at
            + timedelta(minutes=packet["rollback"]["maximum_minutes"])
        ).isoformat(),
        "status": "ready",
        "can_rollback": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(rollback_packet)


def create_canary_watchdog_recovery_packet(
    packet: dict[str, Any],
    response: dict[str, Any],
) -> dict[str, Any]:
    validate_canary_execution_packet(packet)
    validate_canary_response(response, packet=packet, at=response["started_at"])
    evaluated_at = _utc_now()
    rollback_packet = {
        "version": PROTOCOL_VERSION,
        "rollback_id": f"rollback-{response['deployment_id']}",
        "trigger": "watchdog-unavailable",
        "authorized_packet_sha256": packet["content_sha256"],
        "response_sha256": response["content_sha256"],
        "observation_sha256": None,
        "observation_report_sha256": None,
        "provider": packet["provider"],
        "target": packet["target"],
        "deployment_id": response["deployment_id"],
        "failed_artifact_sha256": packet["artifact_sha256"],
        "rollback_artifact_sha256": packet["rollback_artifact_sha256"],
        "threshold_breaches": ["watchdog-unavailable"],
        "requested_at": evaluated_at.isoformat(),
        "required_by": (
            evaluated_at
            + timedelta(minutes=packet["rollback"]["maximum_minutes"])
        ).isoformat(),
        "status": "ready",
        "can_rollback": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(rollback_packet)


def execute_canary_deadline_rollback(
    rollback_packet: dict[str, Any],
    provider: CanaryProvider,
    *,
    packet: dict[str, Any],
    response: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    store = _canonical_canary_execution_store()
    stored_response = store.accepted_response(packet)
    if response != stored_response:
        raise ProtocolError(
            "Canary deadline response context does not match canonical "
            "runtime state."
        )
    validate_canary_rollback_packet(rollback_packet)
    expected_packet = create_canary_deadline_rollback_packet(
        packet,
        response,
        at=at,
    )
    if rollback_packet != expected_packet:
        raise ProtocolError(
            "Canary deadline rollback packet does not match trusted recomputation."
        )
    runtime_at = _active_rollback_runtime_time(rollback_packet)
    if not store.claim_rollback(
        packet,
        rollback_packet,
        at=runtime_at,
        require_deadline=True,
    ):
        raise ProtocolError(
            "Canary deadline rollback has already been claimed or completed."
        )
    return _invoke_claimed_canary_rollback(
        packet,
        rollback_packet,
        provider,
    )


def _invoke_canary_rollback(
    rollback_packet: dict[str, Any],
    provider: CanaryProvider,
) -> dict[str, Any]:
    _active_rollback_runtime_time(rollback_packet)
    raw_response = provider.rollback_canary(copy.deepcopy(rollback_packet))
    _require_fields(
        raw_response,
        {
            "authorized_rollback_sha256",
            "provider",
            "target",
            "deployment_id",
            "artifact_sha256",
            "completed_at",
            "status",
        },
        "Raw canary rollback response",
    )
    accepted_response = _finalize(raw_response)
    _require_fields(
        accepted_response,
        {
            "authorized_rollback_sha256",
            "provider",
            "target",
            "deployment_id",
            "artifact_sha256",
            "completed_at",
            "status",
            "content_sha256",
        },
        "Canary rollback response",
    )
    for field in ["provider", "target", "deployment_id", "status"]:
        _require_string(
            accepted_response[field], f"Canary rollback response {field}"
        )
    for field in ["authorized_rollback_sha256", "artifact_sha256"]:
        _require_sha256(
            accepted_response[field], f"Canary rollback response {field}"
        )
    completed_at = _parse_datetime(
        accepted_response["completed_at"],
        "Canary rollback response completed_at",
    )
    requested_at = _parse_datetime(
        rollback_packet["requested_at"], "Canary rollback requested_at"
    )
    required_by = _parse_datetime(
        rollback_packet["required_by"], "Canary rollback required_by"
    )
    if not requested_at <= completed_at <= required_by:
        raise ProtocolError(
            "Canary rollback did not complete inside the authorized window."
        )
    expected = {
        "authorized_rollback_sha256": rollback_packet["content_sha256"],
        "provider": rollback_packet["provider"],
        "target": rollback_packet["target"],
        "deployment_id": rollback_packet["deployment_id"],
        "artifact_sha256": rollback_packet["rollback_artifact_sha256"],
        "status": "rolled-back",
    }
    for field, value in expected.items():
        if accepted_response[field] != value:
            raise ProtocolError(
                f"Canary rollback response {field} does not match the packet."
            )
    _verify_digest(
        accepted_response,
        f"Canary rollback response '{rollback_packet['rollback_id']}'",
    )
    return accepted_response


def _active_rollback_runtime_time(
    rollback_packet: dict[str, Any],
) -> str:
    requested_at = _parse_datetime(
        rollback_packet["requested_at"], "Canary rollback requested_at"
    )
    required_by = _parse_datetime(
        rollback_packet["required_by"], "Canary rollback required_by"
    )
    runtime_at = _utc_now()
    if runtime_at < requested_at:
        raise ProtocolError(
            "Canary rollback authority is not active on the runtime clock."
        )
    if runtime_at > required_by:
        raise ProtocolError(
            "Canary rollback authority expired before provider invocation."
        )
    return runtime_at.isoformat()


def _invoke_claimed_canary_rollback(
    packet: dict[str, Any],
    rollback_packet: dict[str, Any],
    provider: CanaryProvider,
) -> dict[str, Any]:
    store = _canonical_canary_execution_store()
    try:
        rollback_response = _invoke_canary_rollback(
            rollback_packet,
            provider,
        )
    except Exception as exc:
        store.mark_rollback_failed(packet, exc)
        raise
    store.mark_rolled_back(packet, rollback_response)
    return rollback_response


def enforce_canary_deadline(
    packet: dict[str, Any],
    response: dict[str, Any],
    provider: CanaryProvider,
    *,
    at: str,
) -> dict[str, Any]:
    rollback_packet = create_canary_deadline_rollback_packet(
        packet,
        response,
        at=at,
    )
    rollback_response = execute_canary_deadline_rollback(
        rollback_packet,
        provider,
        packet=packet,
        response=response,
        at=at,
    )
    result = {
        "version": PROTOCOL_VERSION,
        "status": "rolled-back",
        "observation_report_sha256": None,
        "rollback_packet_sha256": rollback_packet["content_sha256"],
        "rollback_response_sha256": rollback_response["content_sha256"],
        "rollback_performed": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(result)


def _complete_registered_rollback(
    packet: dict[str, Any],
    rollback_packet: dict[str, Any],
    provider: CanaryProvider,
) -> dict[str, Any]:
    rollback_response = _invoke_claimed_canary_rollback(
        packet,
        rollback_packet,
        provider,
    )
    result = {
        "version": PROTOCOL_VERSION,
        "status": "rolled-back",
        "observation_report_sha256": rollback_packet[
            "observation_report_sha256"
        ],
        "rollback_packet_sha256": rollback_packet["content_sha256"],
        "rollback_response_sha256": rollback_response["content_sha256"],
        "rollback_performed": True,
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(result)


def _recover_uncertain_canary_start(
    packet: dict[str, Any],
    provider: CanaryProvider,
) -> dict[str, Any] | None:
    store = _canonical_canary_execution_store()
    rollback_packet = create_canary_start_recovery_packet(packet)
    if not store.claim_rollback(
        packet,
        rollback_packet,
        at=rollback_packet["requested_at"],
        require_deadline=False,
    ):
        return None
    return _complete_registered_rollback(
        packet,
        rollback_packet,
        provider,
    )


def _recover_registered_canary(
    packet: dict[str, Any],
    provider: CanaryProvider,
    *,
    at: str,
) -> dict[str, Any] | None:
    store = _canonical_canary_execution_store()
    record = store.get_record(packet)
    status = record["status"]
    if status == "claimed":
        return _recover_uncertain_canary_start(
            packet,
            provider,
        )
    if status == "observing":
        response = record["response"]
        if response is None:
            raise ProtocolError(
                "Observed canary runtime state is missing its response."
            )
        rollback_packet = create_canary_deadline_rollback_packet(
            packet,
            response,
            at=at,
        )
        if not store.claim_rollback(
            packet,
            rollback_packet,
            at=at,
            require_deadline=True,
        ):
            return None
        return _complete_registered_rollback(
            packet,
            rollback_packet,
            provider,
        )
    if status in {"rollback-failed", "rolling-back"}:
        prior_rollback = record["rollback_packet"]
        if prior_rollback is None:
            raise ProtocolError(
                "Recoverable rollback state is missing its rollback packet."
            )
        validate_canary_rollback_packet(prior_rollback)
        evaluated_at = _parse_datetime(at, "Canary rollback recovery time")
        required_by = _parse_datetime(
            prior_rollback["required_by"],
            "Canary rollback required_by",
        )
        if evaluated_at > required_by:
            store.mark_rollback_expired(
                packet,
                at=evaluated_at.isoformat(),
            )
            raise ProtocolError(
                "Persisted canary rollback authority expired before recovery."
            )
        if not store.reclaim_rollback(
            packet,
            at=at,
        ):
            return None
        return _complete_registered_rollback(
            packet,
            prior_rollback,
            provider,
        )
    return None


def _schedule_canary_deadline(
    packet: dict[str, Any],
    provider: CanaryProvider,
) -> None:
    record = _canonical_canary_execution_store().get_record(packet)
    if record["status"] == "claimed":
        due_at = _parse_datetime(
            record["claimed_at"], "Canary runtime claimed_at"
        ) + timedelta(minutes=packet["start_response_timeout_minutes"])
    elif record["status"] == "observing":
        due_at = _parse_datetime(
            record["deadline_at"], "Canary runtime deadline_at"
        )
    else:
        raise ProtocolError(
            "Canary recovery can only be scheduled for claimed or "
            "observing runtime state."
        )
    now = _utc_now().astimezone(due_at.tzinfo)
    delay_seconds = max(0.0, (due_at - now).total_seconds())
    timer = threading.Timer(
        delay_seconds,
        sweep_due_canary_deadlines,
        args=(provider,),
    )
    timer.daemon = True
    timer.start()


def sweep_due_canary_deadlines(
    provider: CanaryProvider,
) -> list[dict[str, Any]]:
    evaluated_at = _utc_now().isoformat()
    store = _canonical_canary_execution_store()
    results: list[dict[str, Any]] = []
    failures: list[str] = []
    for record in store.due(at=evaluated_at):
        try:
            result = _recover_registered_canary(
                record["packet"],
                provider,
                at=evaluated_at,
            )
            if result is not None:
                results.append(result)
        except Exception as exc:
            failures.append(
                f"{record['packet']['content_sha256']}: "
                f"{type(exc).__name__}: {exc}"
            )
    if failures:
        raise ProtocolError(
            "Canary recovery sweep completed with failures: "
            + "; ".join(failures)
        )
    return results


def process_canary_observation(
    observation: dict[str, Any],
    provider: CanaryProvider,
    *,
    packet: dict[str, Any],
    response: dict[str, Any],
    policy: dict[str, Any],
    qualification_policy: dict[str, Any],
    at: str,
) -> dict[str, Any]:
    store = _canonical_canary_execution_store()
    stored_response = store.accepted_response(packet)
    if response != stored_response:
        raise ProtocolError(
            "Canary observation response does not match canonical runtime state."
        )
    observation_report = evaluate_canary_observation(
        observation,
        packet=packet,
        response=response,
        policy=policy,
        qualification_policy=qualification_policy,
        at=at,
    )
    rollback_packet: dict[str, Any] | None = None
    rollback_response: dict[str, Any] | None = None
    if observation_report["rollback_required"]:
        rollback_packet = create_canary_rollback_packet(
            observation,
            packet=packet,
            response=response,
            observation_report=observation_report,
            policy=policy,
            qualification_policy=qualification_policy,
            at=at,
        )
        if not store.claim_rollback(
            packet,
            rollback_packet,
            at=_active_rollback_runtime_time(rollback_packet),
            require_deadline=False,
        ):
            raise ProtocolError(
                "Canary rollback has already been claimed or completed."
            )
        rollback_response = _invoke_claimed_canary_rollback(
            packet,
            rollback_packet,
            provider,
        )
    result = {
        "version": PROTOCOL_VERSION,
        "status": (
            "rolled-back" if rollback_response else "continue-observing"
        ),
        "observation_report_sha256": observation_report["content_sha256"],
        "rollback_packet_sha256": (
            rollback_packet["content_sha256"] if rollback_packet else None
        ),
        "rollback_response_sha256": (
            rollback_response["content_sha256"] if rollback_response else None
        ),
        "rollback_performed": rollback_response is not None,
        "can_promote": False,
        "can_full_rollout": False,
        "can_mutate_maturity": False,
    }
    return _finalize(result)


def canonical_p5_3_readiness(
    policy: dict[str, Any],
    *,
    qualification_policy: dict[str, Any],
    factory_status: dict[str, Any],
    active_authority_source_present: bool,
    active_certification_present: bool,
    valid_l3_consumption_present: bool,
    l3_capable_class_present: bool,
    secret_broker_verified: bool,
    central_telemetry_verified: bool,
    rollback_verified: bool,
) -> dict[str, Any]:
    blockers: list[str] = []
    if not active_authority_source_present:
        blockers.append("no-active-canonical-authority-source")
    if not qualification_policy.get("trust", {}).get("anchors"):
        blockers.append("no-external-trust-anchors")
    if not valid_l3_consumption_present:
        blockers.append("no-valid-l3-qualification-consumption")
    if not active_certification_present:
        blockers.append("no-active-autonomy-certification")
    if not l3_capable_class_present:
        blockers.append("no-l3-capable-autonomy-class")
    if not factory_status.get("has_remote"):
        blockers.append("no-hosted-git-remote")
    if factory_status.get("branch_protection") != "verified":
        blockers.append("branch-protection-not-verified")
    if factory_status.get("external_identity") != "verified":
        blockers.append("external-identity-not-verified")
    if not secret_broker_verified:
        blockers.append("secret-broker-not-verified")
    if not central_telemetry_verified:
        blockers.append("central-telemetry-not-verified")
    if not rollback_verified:
        blockers.append("automatic-rollback-not-verified")
    if not policy["authority"]["can_execute_canary"]:
        blockers.append("policy-forbids-canary")
    report = {
        "version": PROTOCOL_VERSION,
        "phase": "P5.3",
        "capability": "fail-closed-canary",
        "ready": not blockers,
        "blockers": sorted(blockers),
        "required_level": policy["canary"]["required_effective_level"],
        "can_execute_canary": not blockers,
        "can_rollback": not blockers,
        "can_promote": False,
        "can_full_rollout": False,
        "can_merge": False,
        "can_mutate_maturity": False,
    }
    return _finalize(report)
