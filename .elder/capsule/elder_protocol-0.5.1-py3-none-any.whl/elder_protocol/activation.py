from __future__ import annotations

import tomllib
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.build_memory import prepare_build_memory_context
from elder_protocol.constants import PROTOCOL_DIR, PROTOCOL_VERSION, ROOT, SKILLS_DIR
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json, sha256_file
from elder_protocol.profiles import validate_profile
from elder_protocol.schema_validation import validate_against_schema
from elder_protocol.skills import route_skills, validate_skill_registry


TEST_LADDER = ["Foundation", "Component", "Integration", "Workflow", "Stress"]
PROJECT_INSTRUCTION_SOURCES = (
    ("AGENTS.md", "Codex bootstrap and constitutional instructions"),
    (".elder/project-profile.json", "Ratified project mission and risk profile"),
    (".elder/project-contract.json", "Resolved project operating contract"),
    (".elder/project-graph.json", "Selected protocol and authority graph"),
    (".elder/skills.json", "Project-selected Elder skill registry"),
    (".elder/memory-policy.json", "Governed build-memory lifecycle"),
    (".elder/memory/trusted.json", "Portable trusted build-memory ledger"),
    (".elder/repository-dreaming-policy.json", "Repository dreaming boundary"),
)
KERNEL_INSTRUCTION_SOURCES = (
    ("AGENTS.md", "Codex bootstrap and repository operating contract"),
    ("ELDER_PROTOCOL.md", "Elder constitution"),
    ("CONTEXT.md", "Canonical Elder domain language"),
    ("docs/golden-path.md", "Governed delivery lifecycle"),
    ("protocol/repository-dreaming-policy.json", "Repository dreaming boundary"),
)


def _relative_source(root: Path, relative: str, purpose: str) -> dict[str, str]:
    path = root / relative
    if not path.is_file():
        raise ProtocolError(f"Required activation source does not exist: {path}")
    return {
        "path": relative.replace("\\", "/"),
        "purpose": purpose,
        "sha256": sha256_file(path),
    }


def _validate_codex_config(project_root: Path) -> str:
    relative = ".codex/config.toml"
    path = project_root / relative
    try:
        with path.open("rb") as handle:
            config = tomllib.load(handle)
    except FileNotFoundError as exc:
        raise ProtocolError(
            "Codex project configuration is missing. Regenerate the Elder project "
            "before activating a coding session."
        ) from exc
    except tomllib.TOMLDecodeError as exc:
        raise ProtocolError(f"Invalid Codex project configuration: {exc}") from exc
    if config.get("sandbox_mode") != "workspace-write":
        raise ProtocolError("Codex project sandbox_mode must be 'workspace-write'.")
    if config.get("approval_policy") != "on-request":
        raise ProtocolError("Codex project approval_policy must be 'on-request'.")
    workspace = config.get("sandbox_workspace_write")
    if not isinstance(workspace, dict) or workspace.get("network_access") is not False:
        raise ProtocolError("Codex project network access must default to false.")
    return relative


def _verify_generated_ownership(project_root: Path) -> None:
    manifest = load_json(project_root / ".elder" / "ownership.json")
    generated = manifest.get("generated")
    if not isinstance(generated, dict) or not generated:
        raise ProtocolError("Elder ownership manifest has no generated-file records.")
    for relative, record in generated.items():
        if not isinstance(record, dict) or record.get("owner") != "elder":
            raise ProtocolError(f"Invalid Elder ownership record: {relative}")
        path = project_root / relative
        if not path.is_file():
            raise ProtocolError(f"Elder-owned file is missing: {relative}")
        if sha256_file(path) != record.get("sha256"):
            raise ProtocolError(
                f"Elder-owned file changed outside regeneration: {relative}"
            )


def _route(
    task: str,
    registry: dict[str, Any],
    selected_packs: set[str],
    skill_root: str,
) -> list[dict[str, str]]:
    routed = route_skills(task, registry, selected_packs, limit=8)
    by_id = {entry["id"]: entry for entry in registry["skills"]}
    if "wayfinder" in by_id and not any(item["id"] == "wayfinder" for item in routed):
        routed.insert(0, by_id["wayfinder"])
    return [
        {
            "id": entry["id"],
            "path": f"{skill_root}/{entry['id']}/SKILL.md",
            "description": entry["description"],
        }
        for entry in routed
    ]


def _base_boundaries(project_root: Path) -> dict[str, Any]:
    codex_config = _validate_codex_config(project_root)
    return {
        "codex_project_config": codex_config,
        "sandbox_mode": "workspace-write",
        "approval_policy": "on-request",
        "network_access": False,
        "elder_runtime_required_for_delegated_actions": True,
        "direct_tool_interception": False,
        "statement": (
            "Codex is project-sandboxed, but Elder enforces delegated identity, lease, "
            "journal, and promotion rules only for actions submitted through Elder runtimes."
        ),
    }


def _dreaming(policy: dict[str, Any]) -> dict[str, Any]:
    return {
        "scope": policy["scope"],
        "policy_id": policy["id"],
        "provider_adapter": policy["provider_adapter"],
        "candidate_only": policy["execution"]["candidate_only"],
        "direct_mutation": policy["authority"]["provider_can_mutate_target"],
        "source_repository_access": policy["execution"]["source_repository_access"],
        "global_refinement": policy["execution"]["global_refinement"],
        "sandbox_required": policy["execution"]["requires_external_sandbox"],
        "memory_provider": policy["execution"]["memory_provider"],
        "dreaming_model": policy["execution"]["dreaming_model"],
        "network_access": policy["execution"]["allowed_network_services"],
        "status": "configured-candidate-only",
    }


def _finalize(packet: dict[str, Any]) -> dict[str, Any]:
    packet["content_sha256"] = canonical_sha256(packet)
    validate_against_schema(
        packet,
        "session-activation.schema.json",
        label="Session activation",
    )
    return packet


def _activate_generated_project(
    project_root: Path,
    task: str,
    data: dict[str, dict[str, Any]],
    *,
    env_file: Path | None,
    memory_live: bool,
    semantic_memory: Any | None,
) -> dict[str, Any]:
    _verify_generated_ownership(project_root)
    profile = load_json(project_root / ".elder" / "project-profile.json")
    validate_profile(profile, data)
    if profile["profile_status"] != "ratified":
        raise ProtocolError("Project profile must be ratified before session activation.")
    contract = load_json(project_root / ".elder" / "project-contract.json")
    registry = load_json(project_root / ".elder" / "skills.json")
    policy = load_json(project_root / ".elder" / "repository-dreaming-policy.json")
    validate_against_schema(
        policy,
        "repository-dreaming-policy.schema.json",
        label="Repository dreaming policy",
    )
    selected_packs = {
        entry["id"]
        for entry in contract.get("capability_packs", [])
        if isinstance(entry, dict) and isinstance(entry.get("id"), str)
    }
    if not selected_packs:
        raise ProtocolError("Project contract has no resolved capability packs.")
    activated_at = datetime.now(UTC).isoformat()
    packet = {
        "version": PROTOCOL_VERSION,
        "id": f"activation-{profile['slug']}-{canonical_sha256([task, activated_at])[:16]}",
        "mode": "generated-project",
        "project_id": profile["slug"],
        "task": task,
        "mission": profile["mission"],
        "risk_tier": profile["risk_tier"],
        "autonomy_ceiling": profile["autonomy_ceiling"],
        "selected_capability_packs": sorted(selected_packs),
        "routed_skills": _route(
            task,
            registry,
            selected_packs,
            skill_root=".codex/skills",
        ),
        "instruction_sources": [
            _relative_source(project_root, relative, purpose)
            for relative, purpose in PROJECT_INSTRUCTION_SOURCES
        ],
        "boundaries": _base_boundaries(project_root),
        "verification": {
            "ordered_levels": TEST_LADDER,
            "failure_behavior": "fix-root-cause-and-rerun-same-level",
        },
        "build_memory": prepare_build_memory_context(
            project_root=project_root,
            project_id=profile["slug"],
            task=task,
            env_file=env_file,
            live=memory_live,
            semantic_memory=semantic_memory,
        ),
        "dreaming": _dreaming(policy),
        "activated_at": activated_at,
        "status": "ready",
    }
    return _finalize(packet)


def _activate_kernel(
    project_root: Path,
    task: str,
    data: dict[str, dict[str, Any]],
    *,
    env_file: Path | None,
    memory_live: bool,
    semantic_memory: Any | None,
) -> dict[str, Any]:
    registry = validate_skill_registry(
        project_root / "protocol" / "skill-registry.json",
        project_root / "skills",
    )
    selected_packs = {entry["id"] for entry in data["capability-packs"]["packs"]}
    policy = data["repository-dreaming-policy"]
    activated_at = datetime.now(UTC).isoformat()
    packet = {
        "version": PROTOCOL_VERSION,
        "id": f"activation-elder-protocol-{canonical_sha256([task, activated_at])[:16]}",
        "mode": "factory-kernel",
        "project_id": "elder-protocol",
        "task": task,
        "mission": (
            "Build and maintain a product-agnostic protocol compiler with explicit "
            "authority, evidence, bounded autonomy, and governed learning."
        ),
        "risk_tier": "high",
        "autonomy_ceiling": "L1",
        "selected_capability_packs": sorted(selected_packs),
        "routed_skills": _route(
            task,
            registry,
            selected_packs,
            skill_root="skills",
        ),
        "instruction_sources": [
            _relative_source(project_root, relative, purpose)
            for relative, purpose in KERNEL_INSTRUCTION_SOURCES
        ],
        "boundaries": _base_boundaries(project_root),
        "verification": {
            "ordered_levels": TEST_LADDER,
            "failure_behavior": "fix-root-cause-and-rerun-same-level",
        },
        "build_memory": prepare_build_memory_context(
            project_root=project_root,
            project_id="elder-protocol",
            task=task,
            env_file=env_file,
            live=memory_live,
            semantic_memory=semantic_memory,
        ),
        "dreaming": _dreaming(policy),
        "activated_at": activated_at,
        "status": "ready",
    }
    return _finalize(packet)


def activate_session(
    project_root: Path,
    task: str,
    *,
    env_file: Path | None = None,
    memory_live: bool = False,
    semantic_memory: Any | None = None,
) -> dict[str, Any]:
    normalized_task = task.strip()
    if len(normalized_task) < 3:
        raise ProtocolError("Session activation task must contain at least three characters.")
    project_root = project_root.resolve()
    from elder_protocol.protocol import validate_protocol

    data = validate_protocol()
    if (project_root / ".elder" / "project-profile.json").is_file():
        return _activate_generated_project(
            project_root,
            normalized_task,
            data,
            env_file=env_file,
            memory_live=memory_live,
            semantic_memory=semantic_memory,
        )
    if (
        project_root == ROOT.resolve()
        and (project_root / "ELDER_PROTOCOL.md").is_file()
        and (project_root / "protocol").is_dir()
    ):
        return _activate_kernel(
            project_root,
            normalized_task,
            data,
            env_file=env_file,
            memory_live=memory_live,
            semantic_memory=semantic_memory,
        )
    raise ProtocolError(
        "The target is neither an Elder generated project nor the Elder factory kernel."
    )
