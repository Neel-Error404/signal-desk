from __future__ import annotations

import copy
import re
from typing import Any

from elder_protocol.constants import (
    PROFILE_ENUMS,
    PROFILE_REQUIRED,
    PROTOCOL_VERSION,
)
from elder_protocol.errors import ProtocolError
from elder_protocol.governance import validate_project_identities
from elder_protocol.schema_validation import validate_against_schema


INTAKE_OWNER_ROLES = {
    "human",
    "product",
    "architecture",
    "security",
    "release",
    "code",
}


def identity_bindings_from_owners(
    slug: str,
    owners: dict[str, str],
) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    unknown = set(owners) - INTAKE_OWNER_ROLES
    if unknown:
        raise ProtocolError(f"Unknown owner roles: {sorted(unknown)}")
    normalized = dict(owners)
    if "product" not in normalized or "architecture" not in normalized:
        raise ProtocolError("Owner input requires product and architecture identities.")
    normalized.setdefault("human", normalized["product"])
    normalized.setdefault("security", normalized["human"])
    normalized.setdefault("release", normalized["human"])
    normalized.setdefault("code", normalized["architecture"])
    if set(normalized) != INTAKE_OWNER_ROLES:
        raise ProtocolError(
            f"Owner input must resolve roles: {sorted(INTAKE_OWNER_ROLES)}"
        )
    if any(not isinstance(value, str) or not value.strip() for value in normalized.values()):
        raise ProtocolError("Every owner identity must be a non-empty string.")

    agent_identities = {
        "intake-agent": f"{slug}-intake-agent",
        "planning-agent": f"{slug}-planning-agent",
        "executor": f"{slug}-executor",
        "evaluator": f"{slug}-evaluator",
        "learning-agent": f"{slug}-learning-agent",
    }
    identities = {
        identity_id: "human" for identity_id in normalized.values()
    }
    identities.update({identity_id: "agent" for identity_id in agent_identities.values()})
    role_to_identity = {
        "human-owner": normalized["human"],
        "product-owner": normalized["product"],
        "architecture-owner": normalized["architecture"],
        "security-owner": normalized["security"],
        "release-owner": normalized["release"],
        "code-owner": normalized["code"],
        **agent_identities,
        "promoter": normalized["release"],
    }
    return (
        [
            {"id": identity_id, "kind": kind}
            for identity_id, kind in sorted(identities.items())
        ],
        [
            {"role": role_id, "identity": identity_id}
            for role_id, identity_id in sorted(role_to_identity.items())
        ],
    )


def resolve_capability_packs(
    requested: list[str], data: dict[str, dict[str, Any]]
) -> list[str]:
    available = {pack["id"]: pack for pack in data["capability-packs"]["packs"]}
    unknown = set(requested) - available.keys()
    if unknown:
        raise ProtocolError(f"Unknown capability packs: {sorted(unknown)}")
    resolved: list[str] = []
    visiting: set[str] = set()

    def include(pack_id: str) -> None:
        if pack_id in visiting:
            raise ProtocolError(
                f"Capability-pack dependency cycle includes '{pack_id}'."
            )
        if pack_id in resolved:
            return
        visiting.add(pack_id)
        for dependency in available[pack_id].get("requires", []):
            include(dependency)
        visiting.remove(pack_id)
        resolved.append(pack_id)

    for pack in available.values():
        if pack["required"]:
            include(pack["id"])
    for pack_id in requested:
        include(pack_id)
    return resolved


def migrate_profile(profile: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    migrated = copy.deepcopy(profile)
    notes: list[str] = []
    version = migrated.get("protocol_version")

    if version == PROTOCOL_VERSION:
        return migrated, notes
    if version not in {
        "0.1.0",
        "0.2.0",
        "0.3.0",
        "0.4.0",
        "0.4.1",
        "0.4.2",
        "0.4.3",
        "0.4.4",
        "0.4.5",
        "0.4.6",
        "0.4.7",
    }:
        raise ProtocolError(
            f"Unsupported profile version '{version}'. Supported: "
            f"0.1.0, 0.2.0, 0.3.0, 0.4.0, 0.4.1, 0.4.2, 0.4.3, 0.4.4, "
            f"0.4.5, 0.4.6, 0.4.7, "
            f"{PROTOCOL_VERSION}."
        )

    if version == "0.1.0":
        migrated["outcomes"] = {
            "success": ["Define a measurable user or business outcome before ratification."],
            "failure": ["The project cannot demonstrate its intended outcome."],
        }
        migrated["constraints"] = []
        migrated["data_sensitivity"] = (
            "confidential"
            if migrated.get("risk_tier") in {"high", "critical"}
            else "internal"
        )
        migrated["skill_overrides"] = {"required": [], "forbidden": []}
        migrated["knowledge_sources"] = []
        notes.append(
            "Migrated 0.1.0 profile fields; outcomes and data sensitivity require review."
        )
    if "human_owners" in migrated:
        owners = migrated.pop("human_owners")
        identities, bindings = identity_bindings_from_owners(
            migrated["slug"],
            owners,
        )
        migrated["identities"] = identities
        migrated["role_bindings"] = bindings
        notes.append(
            "Migrated human_owners into canonical identities and role bindings; "
            "human-owner, code-owner, executor, evaluator, and promoter bindings require review."
        )
    migrated["protocol_version"] = PROTOCOL_VERSION
    migrated["profile_status"] = "draft"
    notes.append(
        f"Migrated profile to {PROTOCOL_VERSION} as draft; design registry, executable architecture "
        "boundaries, transcript evaluation, evaluation datasets, evaluator calibration, "
        "candidate comparison, correlated telemetry, governed context, memory, persistent "
        "knowledge, the project graph, multi-agent runtime, quarantined learning, "
        "and hosted production qualification "
        "require owner review."
    )
    return migrated, notes


def _validate_string_list(value: Any, field: str, allow_empty: bool = True) -> None:
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        raise ProtocolError(f"Project profile {field} must be a list of non-empty strings.")
    if not allow_empty and not value:
        raise ProtocolError(f"Project profile {field} must not be empty.")
    if len(value) != len(set(value)):
        raise ProtocolError(f"Project profile {field} cannot contain duplicates.")


def validate_profile(
    profile: dict[str, Any], data: dict[str, dict[str, Any]]
) -> None:
    validate_against_schema(
        profile,
        "project-profile.schema.json",
        label="Project profile",
    )
    missing = PROFILE_REQUIRED - profile.keys()
    unknown = profile.keys() - PROFILE_REQUIRED
    if missing:
        raise ProtocolError(f"Project profile is missing: {sorted(missing)}")
    if unknown:
        raise ProtocolError(f"Project profile has unknown fields: {sorted(unknown)}")
    if profile["protocol_version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Project profile protocol_version must be '{PROTOCOL_VERSION}'."
        )
    if not isinstance(profile["name"], str) or not profile["name"].strip():
        raise ProtocolError("Project profile name must be a non-empty string.")
    if not isinstance(profile["mission"], str) or len(profile["mission"].strip()) < 10:
        raise ProtocolError("Project profile mission must contain at least 10 characters.")
    if not isinstance(profile["slug"], str) or not re.fullmatch(
        r"[a-z0-9]+(?:-[a-z0-9]+)*", profile["slug"]
    ):
        raise ProtocolError("Project profile slug must use lowercase kebab-case.")
    for field, allowed in PROFILE_ENUMS.items():
        if profile[field] not in allowed:
            raise ProtocolError(f"Project profile {field} must be one of {sorted(allowed)}.")

    outcomes = profile["outcomes"]
    if not isinstance(outcomes, dict) or set(outcomes) != {"success", "failure"}:
        raise ProtocolError("Project profile outcomes must contain success and failure.")
    _validate_string_list(outcomes["success"], "outcomes.success", allow_empty=False)
    _validate_string_list(outcomes["failure"], "outcomes.failure", allow_empty=False)
    _validate_string_list(profile["constraints"], "constraints")
    _validate_string_list(
        profile["capability_packs"], "capability_packs", allow_empty=False
    )
    _validate_string_list(profile["languages"], "languages", allow_empty=False)
    _validate_string_list(profile["deployment_targets"], "deployment_targets")

    overrides = profile["skill_overrides"]
    if not isinstance(overrides, dict) or set(overrides) != {"required", "forbidden"}:
        raise ProtocolError(
            "Project profile skill_overrides must contain required and forbidden."
        )
    _validate_string_list(overrides["required"], "skill_overrides.required")
    _validate_string_list(overrides["forbidden"], "skill_overrides.forbidden")
    overlap = set(overrides["required"]) & set(overrides["forbidden"])
    if overlap:
        raise ProtocolError(
            f"Skills cannot be both required and forbidden: {sorted(overlap)}"
        )

    validate_project_identities(profile, data["role-registry"])

    sources = profile["knowledge_sources"]
    if not isinstance(sources, list):
        raise ProtocolError("knowledge_sources must be a list.")
    source_ids: list[str] = []
    for source in sources:
        if not isinstance(source, dict):
            raise ProtocolError("Every knowledge source must be an object.")
        required = {"id", "type", "location", "authority"}
        if set(source) != required:
            raise ProtocolError(
                f"Knowledge source fields must be exactly: {sorted(required)}"
            )
        if any(not isinstance(source[key], str) or not source[key].strip() for key in required):
            raise ProtocolError("Knowledge source values must be non-empty strings.")
        if source["authority"] not in {"primary", "secondary", "historical"}:
            raise ProtocolError(
                "Knowledge source authority must be primary, secondary, or historical."
            )
        source_ids.append(source["id"])
    if len(source_ids) != len(set(source_ids)):
        raise ProtocolError("Knowledge source ids must be unique.")

    resolve_capability_packs(profile["capability_packs"], data)

    skill_ids = {skill["id"] for skill in data["skill-registry"]["skills"]}
    unknown_skills = (
        set(overrides["required"]) | set(overrides["forbidden"])
    ) - skill_ids
    if unknown_skills:
        raise ProtocolError(f"Unknown skill overrides: {sorted(unknown_skills)}")


def ratify_profile(
    profile: dict[str, Any],
    data: dict[str, dict[str, Any]],
    approved_by: str,
) -> dict[str, Any]:
    validate_profile(profile, data)
    human_owners = {
        binding["identity"]
        for binding in profile["role_bindings"]
        if binding["role"] == "human-owner"
    }
    if approved_by not in human_owners:
        raise ProtocolError(
            "Project profile ratification requires the bound human-owner identity."
        )
    ratified = copy.deepcopy(profile)
    ratified["profile_status"] = "ratified"
    validate_profile(ratified, data)
    return ratified
