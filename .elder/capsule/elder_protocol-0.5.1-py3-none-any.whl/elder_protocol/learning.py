from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Any, Iterator

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.governance import resolve_authority_bindings


LEARNING_STORE_SCHEMA_VERSION = 1
TERMINAL_CANDIDATE_STATUSES = {"promoted", "rejected", "rolled-back"}
SHA256_HEX = set("0123456789abcdef")


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True)


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _parse_datetime(value: Any, label: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ProtocolError(f"{label} must be an ISO-8601 date-time.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO-8601 date-time.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


def _require_object(value: Any, fields: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProtocolError(f"{label} must be a JSON object.")
    if set(value) != fields:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(fields)}")
    return value


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value.strip()


def _require_string_list(
    value: Any,
    label: str,
    *,
    non_empty: bool = False,
) -> list[str]:
    if not isinstance(value, list):
        raise ProtocolError(f"{label} must be a list.")
    prepared = [_require_string(item, label) for item in value]
    if len(prepared) != len(set(prepared)):
        raise ProtocolError(f"{label} must not contain duplicates.")
    if non_empty and not prepared:
        raise ProtocolError(f"{label} must not be empty.")
    return prepared


def _require_sha256(value: Any, label: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in SHA256_HEX for character in value)
    ):
        raise ProtocolError(f"{label} must be lowercase SHA-256.")
    return value


def _require_number(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ProtocolError(f"{label} must be numeric.")
    number = float(value)
    if not math.isfinite(number):
        raise ProtocolError(f"{label} must be finite.")
    return number


def _content_bound(value: dict[str, Any], label: str) -> None:
    expected = _sha256(
        {key: item for key, item in value.items() if key != "content_sha256"}
    )
    if value["content_sha256"] != expected:
        raise ProtocolError(f"{label} content_sha256 does not match its content.")


def finalize_learning_artifact(value: dict[str, Any]) -> dict[str, Any]:
    prepared = dict(value)
    prepared["version"] = PROTOCOL_VERSION
    prepared.pop("content_sha256", None)
    prepared["content_sha256"] = _sha256(prepared)
    return prepared


def validate_learning_policy(policy: dict[str, Any]) -> dict[str, Any]:
    _require_object(
        policy,
        {
            "version",
            "id",
            "store",
            "candidate_kinds",
            "observation_modes",
            "outcomes",
            "minimum_cases_by_mode",
            "promotion_requirements",
            "authority",
            "retention",
        },
        "Learning policy",
    )
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Learning policy version must be '{PROTOCOL_VERSION}'."
        )
    if policy["id"] != "elder-quarantined-learning-v1":
        raise ProtocolError("Learning policy id is invalid.")
    if policy["store"] != {
        "adapter": "sqlite",
        "journal_mode": "WAL",
        "synchronous": "FULL",
        "authority": "local-reference-only",
    }:
        raise ProtocolError("Learning policy store boundary is invalid.")
    if policy["candidate_kinds"] != [
        "memory",
        "skill",
        "policy",
        "evaluator",
        "architecture",
    ]:
        raise ProtocolError("Learning candidate kinds are incomplete.")
    if policy["observation_modes"] != ["counterfactual-replay", "shadow"]:
        raise ProtocolError("Learning observation modes are incomplete.")
    if policy["outcomes"] != ["better", "equivalent", "worse"]:
        raise ProtocolError("Learning outcomes are incomplete.")
    minimums = policy["minimum_cases_by_mode"]
    _require_object(
        minimums,
        {"counterfactual-replay", "shadow"},
        "Learning minimum cases",
    )
    if any(
        not isinstance(value, int) or isinstance(value, bool) or value < 1
        for value in minimums.values()
    ):
        raise ProtocolError("Learning minimum cases must be positive integers.")
    requirements = policy["promotion_requirements"]
    _require_object(
        requirements,
        {
            "required_modes",
            "minimum_better_cases",
            "maximum_worse_cases",
            "maximum_critical_regressions",
            "require_independent_evaluator",
            "required_approval_roles",
        },
        "Learning promotion requirements",
    )
    if requirements["required_modes"] != policy["observation_modes"]:
        raise ProtocolError("Learning promotion must require replay and shadow modes.")
    for field in (
        "minimum_better_cases",
        "maximum_worse_cases",
        "maximum_critical_regressions",
    ):
        value = requirements[field]
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise ProtocolError(f"Learning {field} must be a non-negative integer.")
    if requirements["minimum_better_cases"] < 1:
        raise ProtocolError("Learning promotion needs at least one better case.")
    if requirements["require_independent_evaluator"] is not True:
        raise ProtocolError("Learning evaluation must remain independent.")
    required_roles = requirements["required_approval_roles"]
    if set(required_roles) != set(policy["candidate_kinds"]):
        raise ProtocolError("Learning approval roles must cover every candidate kind.")
    for kind, roles in required_roles.items():
        _require_string_list(roles, f"Learning approval roles for {kind}", non_empty=True)
        if set(roles) - {"human-owner", "architecture-owner"}:
            raise ProtocolError("Learning approvals use non-canonical roles.")
    if policy["authority"] != {
        "candidate_can_mutate_target": False,
        "observations_allow_side_effects": False,
        "evaluator_can_approve": False,
        "evaluator_can_promote": False,
        "learning_agent_can_approve": False,
        "promoter_requires_approvals": True,
        "promotion_packet_only": True,
    }:
        raise ProtocolError("Learning authority boundary is incomplete.")
    if policy["retention"] != {"candidate_requires_expiry": True}:
        raise ProtocolError("Learning candidate expiry must be required.")
    return policy


def validate_learning_candidate(candidate: dict[str, Any]) -> dict[str, Any]:
    _require_object(
        candidate,
        {
            "version",
            "id",
            "project_id",
            "kind",
            "target_ref",
            "artifact_path",
            "artifact_sha256",
            "hypothesis",
            "source_evidence",
            "counterexamples",
            "created_by",
            "created_role",
            "status",
            "created_at",
            "expires_at",
            "content_sha256",
        },
        "Learning candidate",
    )
    if candidate["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Learning candidate version must be '{PROTOCOL_VERSION}'."
        )
    for field in (
        "id",
        "project_id",
        "target_ref",
        "artifact_path",
        "hypothesis",
        "created_by",
    ):
        _require_string(candidate[field], f"Learning candidate {field}")
    if candidate["kind"] not in {
        "memory",
        "skill",
        "policy",
        "evaluator",
        "architecture",
    }:
        raise ProtocolError("Learning candidate kind is invalid.")
    artifact_path = PurePosixPath(candidate["artifact_path"].replace("\\", "/"))
    if (
        artifact_path.is_absolute()
        or ".." in artifact_path.parts
        or any(":" in part for part in artifact_path.parts)
    ):
        raise ProtocolError(
            "Learning candidate artifact_path must be repository-relative."
        )
    _require_sha256(candidate["artifact_sha256"], "Learning candidate artifact_sha256")
    if len(candidate["hypothesis"].strip()) < 10:
        raise ProtocolError("Learning candidate hypothesis is too short.")
    _require_string_list(
        candidate["source_evidence"],
        "Learning candidate source_evidence",
        non_empty=True,
    )
    _require_string_list(
        candidate["counterexamples"],
        "Learning candidate counterexamples",
    )
    if candidate["created_role"] not in {
        "human-owner",
        "architecture-owner",
        "learning-agent",
    }:
        raise ProtocolError("Learning candidate created_role is invalid.")
    if candidate["status"] not in {
        "candidate",
        "replay",
        "shadow",
        "approved",
        "promoted",
        "rejected",
        "rolled-back",
    }:
        raise ProtocolError("Learning candidate status is invalid.")
    created_at = _parse_datetime(candidate["created_at"], "Learning candidate created_at")
    expires_at = _parse_datetime(candidate["expires_at"], "Learning candidate expires_at")
    if expires_at <= created_at:
        raise ProtocolError("Learning candidate expires_at must follow created_at.")
    _require_sha256(candidate["content_sha256"], "Learning candidate content_sha256")
    _content_bound(candidate, "Learning candidate")
    return candidate


def validate_learning_observation(
    observation: dict[str, Any],
) -> dict[str, Any]:
    _require_object(
        observation,
        {
            "version",
            "id",
            "candidate_id",
            "mode",
            "executor_id",
            "environment",
            "side_effects",
            "cases",
            "started_at",
            "completed_at",
            "content_sha256",
        },
        "Learning observation",
    )
    if observation["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Learning observation version must be '{PROTOCOL_VERSION}'."
        )
    for field in ("id", "candidate_id", "executor_id"):
        _require_string(observation[field], f"Learning observation {field}")
    if observation["mode"] not in {"counterfactual-replay", "shadow"}:
        raise ProtocolError("Learning observation mode is invalid.")
    expected_environment = (
        "quarantine"
        if observation["mode"] == "counterfactual-replay"
        else "shadow"
    )
    if observation["environment"] != expected_environment:
        raise ProtocolError(
            "Learning observation environment does not match its mode."
        )
    if observation["side_effects"] is not False:
        raise ProtocolError("Learning observations cannot have side effects.")
    if not isinstance(observation["cases"], list) or not observation["cases"]:
        raise ProtocolError("Learning observation cases must not be empty.")
    case_ids: list[str] = []
    for case in observation["cases"]:
        _require_object(
            case,
            {
                "id",
                "input_sha256",
                "baseline_output_sha256",
                "candidate_output_sha256",
                "outcome",
                "critical_regression",
                "metrics",
                "evidence",
            },
            "Learning observation case",
        )
        case_ids.append(_require_string(case["id"], "Learning observation case id"))
        for field in (
            "input_sha256",
            "baseline_output_sha256",
            "candidate_output_sha256",
        ):
            _require_sha256(case[field], f"Learning observation case {field}")
        if case["outcome"] not in {"better", "equivalent", "worse"}:
            raise ProtocolError("Learning observation case outcome is invalid.")
        if not isinstance(case["critical_regression"], bool):
            raise ProtocolError(
                "Learning observation critical_regression must be boolean."
            )
        metrics = _require_object(
            case["metrics"],
            {
                "quality_delta",
                "cost_delta_usd",
                "latency_delta_ms",
                "tool_call_delta",
            },
            "Learning observation metrics",
        )
        _require_number(metrics["quality_delta"], "Learning quality_delta")
        _require_number(metrics["cost_delta_usd"], "Learning cost_delta_usd")
        _require_number(metrics["latency_delta_ms"], "Learning latency_delta_ms")
        if (
            not isinstance(metrics["tool_call_delta"], int)
            or isinstance(metrics["tool_call_delta"], bool)
        ):
            raise ProtocolError("Learning tool_call_delta must be an integer.")
        _require_string_list(
            case["evidence"],
            "Learning observation case evidence",
            non_empty=True,
        )
    if len(case_ids) != len(set(case_ids)):
        raise ProtocolError("Learning observation case ids must be unique.")
    started_at = _parse_datetime(
        observation["started_at"], "Learning observation started_at"
    )
    completed_at = _parse_datetime(
        observation["completed_at"], "Learning observation completed_at"
    )
    if completed_at < started_at:
        raise ProtocolError(
            "Learning observation completed_at cannot precede started_at."
        )
    _require_sha256(
        observation["content_sha256"],
        "Learning observation content_sha256",
    )
    _content_bound(observation, "Learning observation")
    return observation


def validate_learning_evaluation(
    evaluation: dict[str, Any],
) -> dict[str, Any]:
    _require_object(
        evaluation,
        {
            "version",
            "id",
            "candidate_id",
            "candidate_sha256",
            "evaluator_id",
            "observation_ids",
            "observation_sha256s",
            "verdict",
            "metrics",
            "findings",
            "authority",
            "can_approve",
            "can_promote",
            "evaluated_at",
            "content_sha256",
        },
        "Learning evaluation",
    )
    if evaluation["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Learning evaluation version must be '{PROTOCOL_VERSION}'."
        )
    for field in ("id", "candidate_id", "evaluator_id"):
        _require_string(evaluation[field], f"Learning evaluation {field}")
    _require_sha256(
        evaluation["candidate_sha256"],
        "Learning evaluation candidate_sha256",
    )
    observation_ids = _require_string_list(
        evaluation["observation_ids"],
        "Learning evaluation observation_ids",
        non_empty=True,
    )
    observation_sha256s = evaluation["observation_sha256s"]
    if (
        not isinstance(observation_sha256s, list)
        or len(observation_sha256s) != len(observation_ids)
    ):
        raise ProtocolError(
            "Learning evaluation observation digests must align with ids."
        )
    for digest in observation_sha256s:
        _require_sha256(digest, "Learning evaluation observation digest")
    if evaluation["verdict"] not in {
        "qualified",
        "rejected",
        "needs-more-evidence",
    }:
        raise ProtocolError("Learning evaluation verdict is invalid.")
    metrics = evaluation["metrics"]
    _require_object(
        metrics,
        {
            "observation_count",
            "case_count",
            "replay_case_count",
            "shadow_case_count",
            "better_count",
            "equivalent_count",
            "worse_count",
            "critical_regression_count",
            "quality_delta",
            "cost_delta_usd",
            "latency_delta_ms",
            "tool_call_delta",
        },
        "Learning evaluation metrics",
    )
    for field in (
        "observation_count",
        "case_count",
        "replay_case_count",
        "shadow_case_count",
        "better_count",
        "equivalent_count",
        "worse_count",
        "critical_regression_count",
    ):
        if (
            not isinstance(metrics[field], int)
            or isinstance(metrics[field], bool)
            or metrics[field] < 0
        ):
            raise ProtocolError(f"Learning evaluation {field} is invalid.")
    if (
        not isinstance(metrics["tool_call_delta"], int)
        or isinstance(metrics["tool_call_delta"], bool)
    ):
        raise ProtocolError("Learning evaluation tool_call_delta is invalid.")
    for field in ("quality_delta", "cost_delta_usd", "latency_delta_ms"):
        _require_number(metrics[field], f"Learning evaluation {field}")
    _require_string_list(
        evaluation["findings"],
        "Learning evaluation findings",
    )
    if (
        evaluation["authority"] != "advisory-only"
        or evaluation["can_approve"] is not False
        or evaluation["can_promote"] is not False
    ):
        raise ProtocolError("Learning evaluation cannot approve or promote.")
    _parse_datetime(evaluation["evaluated_at"], "Learning evaluation evaluated_at")
    _require_sha256(
        evaluation["content_sha256"],
        "Learning evaluation content_sha256",
    )
    _content_bound(evaluation, "Learning evaluation")
    return evaluation


def validate_learning_approval(approval: dict[str, Any]) -> dict[str, Any]:
    _require_object(
        approval,
        {
            "version",
            "id",
            "candidate_id",
            "candidate_sha256",
            "evaluation_id",
            "evaluation_sha256",
            "decision",
            "approved_by",
            "approver_role",
            "evidence",
            "decided_at",
            "content_sha256",
        },
        "Learning approval",
    )
    if approval["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Learning approval version must be '{PROTOCOL_VERSION}'."
        )
    for field in (
        "id",
        "candidate_id",
        "evaluation_id",
        "approved_by",
    ):
        _require_string(approval[field], f"Learning approval {field}")
    _require_sha256(
        approval["candidate_sha256"], "Learning approval candidate_sha256"
    )
    _require_sha256(
        approval["evaluation_sha256"], "Learning approval evaluation_sha256"
    )
    if approval["decision"] not in {"approve", "reject", "rollback"}:
        raise ProtocolError("Learning approval decision is invalid.")
    if approval["approver_role"] not in {"human-owner", "architecture-owner"}:
        raise ProtocolError("Learning approval role is invalid.")
    _require_string_list(
        approval["evidence"],
        "Learning approval evidence",
        non_empty=True,
    )
    _parse_datetime(approval["decided_at"], "Learning approval decided_at")
    _require_sha256(
        approval["content_sha256"],
        "Learning approval content_sha256",
    )
    _content_bound(approval, "Learning approval")
    return approval


def validate_learning_promotion(packet: dict[str, Any]) -> dict[str, Any]:
    _require_object(
        packet,
        {
            "version",
            "id",
            "candidate_id",
            "candidate_sha256",
            "evaluation_id",
            "evaluation_sha256",
            "approval_ids",
            "approval_sha256s",
            "promoted_by",
            "promoter_role",
            "target_ref",
            "artifact_sha256",
            "status",
            "applies_target_mutation",
            "created_at",
            "content_sha256",
        },
        "Learning promotion",
    )
    if packet["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Learning promotion version must be '{PROTOCOL_VERSION}'."
        )
    for field in (
        "id",
        "candidate_id",
        "evaluation_id",
        "promoted_by",
        "target_ref",
    ):
        _require_string(packet[field], f"Learning promotion {field}")
    for field in (
        "candidate_sha256",
        "evaluation_sha256",
        "artifact_sha256",
    ):
        _require_sha256(packet[field], f"Learning promotion {field}")
    approval_ids = _require_string_list(
        packet["approval_ids"],
        "Learning promotion approval_ids",
        non_empty=True,
    )
    approval_sha256s = packet["approval_sha256s"]
    if (
        not isinstance(approval_sha256s, list)
        or len(approval_sha256s) != len(approval_ids)
    ):
        raise ProtocolError(
            "Learning promotion approval digests must align with ids."
        )
    for digest in approval_sha256s:
        _require_sha256(digest, "Learning promotion approval digest")
    if packet["promoter_role"] != "promoter":
        raise ProtocolError("Learning promotion requires the promoter role.")
    if packet["status"] not in {"promoted", "rolled-back"}:
        raise ProtocolError("Learning promotion status is invalid.")
    if packet["applies_target_mutation"] is not False:
        raise ProtocolError("Learning promotion packets cannot mutate targets.")
    _parse_datetime(packet["created_at"], "Learning promotion created_at")
    _require_sha256(
        packet["content_sha256"],
        "Learning promotion content_sha256",
    )
    _content_bound(packet, "Learning promotion")
    return packet


class LearningRuntime:
    def __init__(
        self,
        path: Path,
        policy: dict[str, Any],
        *,
        profile: dict[str, Any],
        role_registry: dict[str, Any],
        authority_matrix: dict[str, Any],
    ):
        self.path = path.resolve()
        self.policy = validate_learning_policy(policy)
        self.policy_sha256 = _sha256(self.policy)
        self.authority_bindings = resolve_authority_bindings(
            profile,
            role_registry,
            authority_matrix,
        )
        self.authority_sha256 = self.authority_bindings["content_sha256"]
        self.project_id = self.authority_bindings["project_id"]

    def _require_authority(
        self,
        *,
        identity_id: str,
        role: str,
        resource: str,
        action: str,
        label: str,
    ) -> None:
        matching_bindings = [
            binding
            for binding in self.authority_bindings["role_bindings"]
            if binding["role"] == role and binding["identity"] == identity_id
        ]
        if len(matching_bindings) != 1:
            raise ProtocolError(
                f"{label} identity and role do not match resolved project authority."
            )
        matching_grants = [
            grant
            for grant in self.authority_bindings["grants"]
            if grant["role"] == role
            and grant["identity"] == identity_id
            and grant["resource"] == resource
        ]
        if len(matching_grants) != 1 or action not in matching_grants[0]["actions"]:
            raise ProtocolError(
                f"{label} lacks '{action}' authority for '{resource}'."
            )

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 30000")
        try:
            yield connection
        finally:
            connection.close()

    def initialize(self) -> dict[str, Any]:
        with self._connection() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("PRAGMA synchronous = FULL")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS metadata(
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS candidates(
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    status TEXT NOT NULL,
                    artifact_bytes BLOB NOT NULL,
                    artifact_sha256 TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS observations(
                    id TEXT PRIMARY KEY,
                    candidate_id TEXT NOT NULL REFERENCES candidates(id),
                    mode TEXT NOT NULL,
                    executor_id TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    completed_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS evaluations(
                    id TEXT PRIMARY KEY,
                    candidate_id TEXT NOT NULL REFERENCES candidates(id),
                    evaluator_id TEXT NOT NULL,
                    verdict TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    evaluated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS approvals(
                    id TEXT PRIMARY KEY,
                    candidate_id TEXT NOT NULL REFERENCES candidates(id),
                    evaluation_id TEXT NOT NULL REFERENCES evaluations(id),
                    decision TEXT NOT NULL,
                    approver_role TEXT NOT NULL,
                    approved_by TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    decided_at TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS idx_learning_approval_role
                    ON approvals(candidate_id, evaluation_id, decision, approver_role);
                CREATE TABLE IF NOT EXISTS promotions(
                    id TEXT PRIMARY KEY,
                    candidate_id TEXT NOT NULL REFERENCES candidates(id),
                    evaluation_id TEXT NOT NULL REFERENCES evaluations(id),
                    status TEXT NOT NULL,
                    artifact_json TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS learning_events(
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    candidate_id TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    previous_sha256 TEXT,
                    content_sha256 TEXT NOT NULL
                );
                """
            )
            metadata = {
                row["key"]: row["value"]
                for row in connection.execute("SELECT key, value FROM metadata")
            }
            expected = {
                "schema_version": str(LEARNING_STORE_SCHEMA_VERSION),
                "protocol_version": PROTOCOL_VERSION,
                "policy_sha256": self.policy_sha256,
                "authority_sha256": self.authority_sha256,
                "project_id": self.project_id,
            }
            if metadata:
                if metadata != expected:
                    raise ProtocolError(
                        "Learning store metadata does not match the runtime contract."
                    )
            else:
                connection.executemany(
                    "INSERT INTO metadata(key, value) VALUES(?, ?)",
                    sorted(expected.items()),
                )
            connection.commit()
        return self.status()

    def _require_initialized(self, connection: sqlite3.Connection) -> None:
        try:
            metadata = {
                row["key"]: row["value"]
                for row in connection.execute("SELECT key, value FROM metadata")
            }
        except sqlite3.OperationalError as exc:
            raise ProtocolError("Learning store is not initialized.") from exc
        expected = {
            "schema_version": str(LEARNING_STORE_SCHEMA_VERSION),
            "protocol_version": PROTOCOL_VERSION,
            "policy_sha256": self.policy_sha256,
            "authority_sha256": self.authority_sha256,
            "project_id": self.project_id,
        }
        if metadata != expected:
            raise ProtocolError(
                "Learning store metadata does not match the runtime contract."
            )

    def status(self) -> dict[str, Any]:
        with self._connection() as connection:
            self._require_initialized(connection)
            integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
            counts = {
                table: connection.execute(
                    f"SELECT COUNT(*) FROM {table}"
                ).fetchone()[0]
                for table in (
                    "candidates",
                    "observations",
                    "evaluations",
                    "approvals",
                    "promotions",
                    "learning_events",
                )
            }
            statuses = {
                row["status"]: row["count"]
                for row in connection.execute(
                    """
                    SELECT status, COUNT(*) AS count
                    FROM candidates
                    GROUP BY status
                    ORDER BY status
                    """
                )
            }
        return {
            "path": str(self.path),
            "integrity": integrity,
            "journal_mode": "wal",
            "foreign_keys": True,
            "policy_sha256": self.policy_sha256,
            "authority_sha256": self.authority_sha256,
            "project_id": self.project_id,
            "counts": counts,
            "candidate_statuses": statuses,
        }

    @staticmethod
    def _row_artifact(row: sqlite3.Row) -> dict[str, Any]:
        try:
            artifact = json.loads(row["artifact_json"])
        except (json.JSONDecodeError, TypeError) as exc:
            raise ProtocolError("Learning journal artifact JSON is invalid.") from exc
        if not isinstance(artifact, dict):
            raise ProtocolError("Learning journal artifact must be an object.")
        return artifact

    def _append_event(
        self,
        connection: sqlite3.Connection,
        *,
        event_type: str,
        candidate_id: str,
        occurred_at: str,
        payload: dict[str, Any],
    ) -> None:
        prior = connection.execute(
            """
            SELECT content_sha256
            FROM learning_events
            WHERE candidate_id = ?
            ORDER BY sequence DESC
            LIMIT 1
            """,
            (candidate_id,),
        ).fetchone()
        previous_sha256 = None if prior is None else prior["content_sha256"]
        unsigned = {
            "event_type": event_type,
            "candidate_id": candidate_id,
            "occurred_at": occurred_at,
            "payload": payload,
            "previous_sha256": previous_sha256,
        }
        digest = _sha256(unsigned)
        connection.execute(
            """
            INSERT INTO learning_events(
                event_type, candidate_id, occurred_at, payload_json,
                previous_sha256, content_sha256
            ) VALUES(?, ?, ?, ?, ?, ?)
            """,
            (
                event_type,
                candidate_id,
                occurred_at,
                _canonical_json(payload),
                previous_sha256,
                digest,
            ),
        )

    def _candidate_row(
        self,
        connection: sqlite3.Connection,
        candidate_id: str,
    ) -> sqlite3.Row:
        row = connection.execute(
            "SELECT * FROM candidates WHERE id = ?",
            (candidate_id,),
        ).fetchone()
        if row is None:
            raise ProtocolError(f"Learning candidate does not exist: {candidate_id}")
        candidate = self._row_artifact(row)
        validate_learning_candidate(candidate)
        if (
            candidate["id"] != row["id"]
            or candidate["project_id"] != row["project_id"]
            or candidate["kind"] != row["kind"]
            or candidate["status"] != row["status"]
            or candidate["artifact_sha256"] != row["artifact_sha256"]
            or candidate["content_sha256"] != row["content_sha256"]
            or _sha256_bytes(row["artifact_bytes"]) != row["artifact_sha256"]
        ):
            raise ProtocolError("Learning candidate journal row binding is invalid.")
        return row

    def _set_candidate_status(
        self,
        connection: sqlite3.Connection,
        row: sqlite3.Row,
        status: str,
    ) -> dict[str, Any]:
        candidate = self._row_artifact(row)
        candidate["status"] = status
        candidate = finalize_learning_artifact(candidate)
        validate_learning_candidate(candidate)
        connection.execute(
            """
            UPDATE candidates
            SET status = ?, artifact_json = ?, content_sha256 = ?
            WHERE id = ?
            """,
            (
                status,
                _canonical_json(candidate),
                candidate["content_sha256"],
                candidate["id"],
            ),
        )
        return candidate

    def propose(
        self,
        candidate: dict[str, Any],
        *,
        artifact_base: Path,
    ) -> dict[str, Any]:
        validate_learning_candidate(candidate)
        if candidate["status"] != "candidate":
            raise ProtocolError("New learning candidates must start as candidate.")
        if candidate["project_id"] != self.project_id:
            raise ProtocolError(
                "Learning candidate project does not match runtime authority."
            )
        self._require_authority(
            identity_id=candidate["created_by"],
            role=candidate["created_role"],
            resource="learning-candidate",
            action="propose",
            label="Learning candidate creator",
        )
        artifact_base = artifact_base.resolve()
        artifact_path = (
            artifact_base / Path(candidate["artifact_path"].replace("/", "\\"))
        ).resolve()
        try:
            artifact_path.relative_to(artifact_base)
        except ValueError as exc:
            raise ProtocolError(
                "Learning candidate artifact escapes the declared artifact base."
            ) from exc
        try:
            artifact_bytes = artifact_path.read_bytes()
        except OSError as exc:
            raise ProtocolError(
                f"Could not read learning candidate artifact: {artifact_path}"
            ) from exc
        if _sha256_bytes(artifact_bytes) != candidate["artifact_sha256"]:
            raise ProtocolError(
                "Learning candidate artifact_sha256 does not match artifact bytes."
            )
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                if connection.execute(
                    "SELECT 1 FROM candidates WHERE id = ?",
                    (candidate["id"],),
                ).fetchone():
                    raise ProtocolError(
                        f"Learning candidate already exists: {candidate['id']}"
                    )
                connection.execute(
                    """
                    INSERT INTO candidates(
                        id, project_id, kind, status, artifact_bytes,
                        artifact_sha256, artifact_json, content_sha256,
                        created_at, expires_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        candidate["id"],
                        candidate["project_id"],
                        candidate["kind"],
                        candidate["status"],
                        artifact_bytes,
                        candidate["artifact_sha256"],
                        _canonical_json(candidate),
                        candidate["content_sha256"],
                        candidate["created_at"],
                        candidate["expires_at"],
                    ),
                )
                self._append_event(
                    connection,
                    event_type="candidate-proposed",
                    candidate_id=candidate["id"],
                    occurred_at=candidate["created_at"],
                    payload={"candidate": candidate},
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return candidate

    def observe(self, observation: dict[str, Any]) -> dict[str, Any]:
        validate_learning_observation(observation)
        self._require_authority(
            identity_id=observation["executor_id"],
            role="learning-agent",
            resource="learning-candidate",
            action="execute",
            label="Learning observation executor",
        )
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                row = self._candidate_row(connection, observation["candidate_id"])
                candidate = self._row_artifact(row)
                if candidate["status"] in TERMINAL_CANDIDATE_STATUSES | {"approved"}:
                    raise ProtocolError(
                        "Terminal or approved learning candidates cannot accept observations."
                    )
                if _parse_datetime(
                    observation["completed_at"],
                    "Learning observation completed_at",
                ) > _parse_datetime(
                    candidate["expires_at"],
                    "Learning candidate expires_at",
                ):
                    raise ProtocolError(
                        "Learning observation completes after candidate expiry."
                    )
                if observation["mode"] == "shadow":
                    replay_cases = connection.execute(
                        """
                        SELECT artifact_json
                        FROM observations
                        WHERE candidate_id = ? AND mode = 'counterfactual-replay'
                        """,
                        (candidate["id"],),
                    ).fetchall()
                    replay_case_count = sum(
                        len(self._row_artifact(item)["cases"])
                        for item in replay_cases
                    )
                    required = self.policy["minimum_cases_by_mode"][
                        "counterfactual-replay"
                    ]
                    if replay_case_count < required:
                        raise ProtocolError(
                            "Shadow observation requires the minimum counterfactual replay cases."
                        )
                if connection.execute(
                    "SELECT 1 FROM observations WHERE id = ?",
                    (observation["id"],),
                ).fetchone():
                    raise ProtocolError(
                        f"Learning observation already exists: {observation['id']}"
                    )
                connection.execute(
                    """
                    INSERT INTO observations(
                        id, candidate_id, mode, executor_id, artifact_json,
                        content_sha256, completed_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        observation["id"],
                        observation["candidate_id"],
                        observation["mode"],
                        observation["executor_id"],
                        _canonical_json(observation),
                        observation["content_sha256"],
                        observation["completed_at"],
                    ),
                )
                status = (
                    "replay"
                    if observation["mode"] == "counterfactual-replay"
                    else "shadow"
                )
                candidate = self._set_candidate_status(connection, row, status)
                self._append_event(
                    connection,
                    event_type="observation-recorded",
                    candidate_id=candidate["id"],
                    occurred_at=observation["completed_at"],
                    payload={
                        "observation": observation,
                        "derived_candidate": candidate,
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return observation

    def evaluate(
        self,
        candidate_id: str,
        *,
        evaluator_id: str,
        evaluation_id: str | None = None,
        evaluated_at: str | None = None,
    ) -> dict[str, Any]:
        candidate_id = _require_string(candidate_id, "Learning candidate id")
        evaluator_id = _require_string(evaluator_id, "Learning evaluator id")
        self._require_authority(
            identity_id=evaluator_id,
            role="evaluator",
            resource="learning-evaluation",
            action="execute",
            label="Learning evaluator",
        )
        evaluated_at = evaluated_at or utc_now()
        _parse_datetime(evaluated_at, "Learning evaluated_at")
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                candidate_row = self._candidate_row(connection, candidate_id)
                candidate = self._row_artifact(candidate_row)
                if candidate["status"] in TERMINAL_CANDIDATE_STATUSES | {"approved"}:
                    raise ProtocolError(
                        "Terminal or approved learning candidates cannot be evaluated."
                    )
                observation_rows = connection.execute(
                    """
                    SELECT *
                    FROM observations
                    WHERE candidate_id = ?
                    ORDER BY completed_at, id
                    """,
                    (candidate_id,),
                ).fetchall()
                if not observation_rows:
                    raise ProtocolError(
                        "Learning evaluation requires recorded observations."
                    )
                observations: list[dict[str, Any]] = []
                for row in observation_rows:
                    observation = self._row_artifact(row)
                    validate_learning_observation(observation)
                    if observation["content_sha256"] != row["content_sha256"]:
                        raise ProtocolError(
                            "Learning observation journal digest is invalid."
                        )
                    observations.append(observation)
                executor_ids = {item["executor_id"] for item in observations}
                if (
                    evaluator_id == candidate["created_by"]
                    or evaluator_id in executor_ids
                ):
                    raise ProtocolError(
                        "Learning evaluator must be independent from creator and executors."
                    )
                all_cases = [
                    case for observation in observations for case in observation["cases"]
                ]
                by_mode = {
                    mode: sum(
                        len(item["cases"])
                        for item in observations
                        if item["mode"] == mode
                    )
                    for mode in self.policy["observation_modes"]
                }
                outcomes = {
                    outcome: sum(case["outcome"] == outcome for case in all_cases)
                    for outcome in self.policy["outcomes"]
                }
                critical_count = sum(
                    case["critical_regression"] for case in all_cases
                )
                findings: list[str] = []
                for mode in self.policy["promotion_requirements"]["required_modes"]:
                    minimum = self.policy["minimum_cases_by_mode"][mode]
                    if by_mode[mode] < minimum:
                        findings.append(
                            f"{mode} has {by_mode[mode]} cases; minimum is {minimum}."
                        )
                requirements = self.policy["promotion_requirements"]
                if outcomes["better"] < requirements["minimum_better_cases"]:
                    findings.append("Candidate has insufficient better cases.")
                if outcomes["worse"] > requirements["maximum_worse_cases"]:
                    findings.append("Candidate exceeds the allowed worse-case count.")
                if critical_count > requirements["maximum_critical_regressions"]:
                    findings.append("Candidate has critical regressions.")
                if outcomes["worse"] > requirements["maximum_worse_cases"] or (
                    critical_count > requirements["maximum_critical_regressions"]
                ):
                    verdict = "rejected"
                elif findings:
                    verdict = "needs-more-evidence"
                else:
                    verdict = "qualified"
                metrics = {
                    "observation_count": len(observations),
                    "case_count": len(all_cases),
                    "replay_case_count": by_mode["counterfactual-replay"],
                    "shadow_case_count": by_mode["shadow"],
                    "better_count": outcomes["better"],
                    "equivalent_count": outcomes["equivalent"],
                    "worse_count": outcomes["worse"],
                    "critical_regression_count": critical_count,
                    "quality_delta": sum(
                        case["metrics"]["quality_delta"] for case in all_cases
                    ),
                    "cost_delta_usd": sum(
                        case["metrics"]["cost_delta_usd"] for case in all_cases
                    ),
                    "latency_delta_ms": sum(
                        case["metrics"]["latency_delta_ms"] for case in all_cases
                    ),
                    "tool_call_delta": sum(
                        case["metrics"]["tool_call_delta"] for case in all_cases
                    ),
                }
                evaluation = finalize_learning_artifact(
                    {
                        "version": PROTOCOL_VERSION,
                        "id": evaluation_id
                        or f"learning-evaluation-{uuid.uuid4().hex}",
                        "candidate_id": candidate_id,
                        "candidate_sha256": candidate["content_sha256"],
                        "evaluator_id": evaluator_id,
                        "observation_ids": [item["id"] for item in observations],
                        "observation_sha256s": [
                            item["content_sha256"] for item in observations
                        ],
                        "verdict": verdict,
                        "metrics": metrics,
                        "findings": findings,
                        "authority": "advisory-only",
                        "can_approve": False,
                        "can_promote": False,
                        "evaluated_at": evaluated_at,
                    }
                )
                validate_learning_evaluation(evaluation)
                connection.execute(
                    """
                    INSERT INTO evaluations(
                        id, candidate_id, evaluator_id, verdict, artifact_json,
                        content_sha256, evaluated_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        evaluation["id"],
                        candidate_id,
                        evaluator_id,
                        verdict,
                        _canonical_json(evaluation),
                        evaluation["content_sha256"],
                        evaluated_at,
                    ),
                )
                self._append_event(
                    connection,
                    event_type="evaluation-recorded",
                    candidate_id=candidate_id,
                    occurred_at=evaluated_at,
                    payload={"evaluation": evaluation},
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return evaluation

    def decide(self, approval: dict[str, Any]) -> dict[str, Any]:
        validate_learning_approval(approval)
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                candidate_row = self._candidate_row(
                    connection, approval["candidate_id"]
                )
                candidate = self._row_artifact(candidate_row)
                evaluation_row = connection.execute(
                    "SELECT * FROM evaluations WHERE id = ?",
                    (approval["evaluation_id"],),
                ).fetchone()
                if evaluation_row is None:
                    raise ProtocolError("Learning approval evaluation does not exist.")
                evaluation = self._row_artifact(evaluation_row)
                validate_learning_evaluation(evaluation)
                if (
                    approval["candidate_sha256"] != candidate["content_sha256"]
                    or approval["evaluation_sha256"]
                    != evaluation["content_sha256"]
                    or evaluation["candidate_id"] != candidate["id"]
                ):
                    raise ProtocolError(
                        "Learning approval does not bind the current candidate and evaluation."
                    )
                if approval["approved_by"] in {
                    candidate["created_by"],
                    evaluation["evaluator_id"],
                }:
                    raise ProtocolError(
                        "Learning approval must be independent from creator and evaluator."
                    )
                required_roles = set(
                    self.policy["promotion_requirements"][
                        "required_approval_roles"
                    ][candidate["kind"]]
                )
                if approval["approver_role"] not in required_roles:
                    raise ProtocolError(
                        "Learning approval role is not authorized for this candidate kind."
                    )
                self._require_authority(
                    identity_id=approval["approved_by"],
                    role=approval["approver_role"],
                    resource="learning-promotion",
                    action="approve",
                    label="Learning approver",
                )
                if approval["decision"] == "approve":
                    if candidate["status"] not in {"replay", "shadow"}:
                        raise ProtocolError(
                            "Only evaluated replay or shadow candidates can be approved."
                        )
                    if evaluation["verdict"] != "qualified":
                        raise ProtocolError(
                            "Learning approval requires a qualified evaluation."
                        )
                elif approval["decision"] == "reject":
                    if candidate["status"] in TERMINAL_CANDIDATE_STATUSES:
                        raise ProtocolError(
                            "Terminal learning candidates cannot be rejected again."
                        )
                elif candidate["status"] != "promoted":
                    raise ProtocolError(
                        "Only promoted learning candidates can be approved for rollback."
                    )
                connection.execute(
                    """
                    INSERT INTO approvals(
                        id, candidate_id, evaluation_id, decision, approver_role,
                        approved_by, artifact_json, content_sha256, decided_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        approval["id"],
                        approval["candidate_id"],
                        approval["evaluation_id"],
                        approval["decision"],
                        approval["approver_role"],
                        approval["approved_by"],
                        _canonical_json(approval),
                        approval["content_sha256"],
                        approval["decided_at"],
                    ),
                )
                derived_status = candidate["status"]
                if approval["decision"] == "reject":
                    derived_status = "rejected"
                elif approval["decision"] == "approve":
                    roles = {
                        row["approver_role"]
                        for row in connection.execute(
                            """
                            SELECT approver_role
                            FROM approvals
                            WHERE candidate_id = ? AND evaluation_id = ?
                              AND decision = 'approve'
                            """,
                            (candidate["id"], evaluation["id"]),
                        )
                    }
                    if roles == required_roles:
                        derived_status = "approved"
                if derived_status != candidate["status"]:
                    candidate = self._set_candidate_status(
                        connection, candidate_row, derived_status
                    )
                self._append_event(
                    connection,
                    event_type="approval-recorded",
                    candidate_id=candidate["id"],
                    occurred_at=approval["decided_at"],
                    payload={
                        "approval": approval,
                        "derived_candidate": candidate,
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return approval

    def promote(
        self,
        candidate_id: str,
        *,
        promoted_by: str,
        promotion_id: str | None = None,
        created_at: str | None = None,
    ) -> dict[str, Any]:
        return self._finalize_promotion(
            candidate_id,
            promoted_by=promoted_by,
            status="promoted",
            promotion_id=promotion_id,
            created_at=created_at,
        )

    def rollback(
        self,
        candidate_id: str,
        *,
        promoted_by: str,
        promotion_id: str | None = None,
        created_at: str | None = None,
    ) -> dict[str, Any]:
        return self._finalize_promotion(
            candidate_id,
            promoted_by=promoted_by,
            status="rolled-back",
            promotion_id=promotion_id,
            created_at=created_at,
        )

    def _finalize_promotion(
        self,
        candidate_id: str,
        *,
        promoted_by: str,
        status: str,
        promotion_id: str | None,
        created_at: str | None,
    ) -> dict[str, Any]:
        candidate_id = _require_string(candidate_id, "Learning candidate id")
        promoted_by = _require_string(promoted_by, "Learning promoter id")
        self._require_authority(
            identity_id=promoted_by,
            role="promoter",
            resource="learning-promotion",
            action="promote",
            label="Learning promoter",
        )
        created_at = created_at or utc_now()
        _parse_datetime(created_at, "Learning promotion created_at")
        decision = "approve" if status == "promoted" else "rollback"
        with self._connection() as connection:
            self._require_initialized(connection)
            try:
                connection.execute("BEGIN IMMEDIATE")
                candidate_row = self._candidate_row(connection, candidate_id)
                candidate = self._row_artifact(candidate_row)
                expected_status = "approved" if status == "promoted" else "promoted"
                if candidate["status"] != expected_status:
                    raise ProtocolError(
                        f"Learning candidate must be {expected_status} before {status}."
                    )
                evaluation_row = connection.execute(
                    """
                    SELECT *
                    FROM evaluations
                    WHERE candidate_id = ?
                    ORDER BY evaluated_at DESC, id DESC
                    LIMIT 1
                    """,
                    (candidate_id,),
                ).fetchone()
                if evaluation_row is None:
                    raise ProtocolError("Learning promotion requires an evaluation.")
                evaluation = self._row_artifact(evaluation_row)
                if status == "promoted" and evaluation["verdict"] != "qualified":
                    raise ProtocolError(
                        "Learning promotion requires a qualified evaluation."
                    )
                approval_rows = connection.execute(
                    """
                    SELECT *
                    FROM approvals
                    WHERE candidate_id = ? AND evaluation_id = ? AND decision = ?
                    ORDER BY approver_role, id
                    """,
                    (candidate_id, evaluation["id"], decision),
                ).fetchall()
                approvals = [self._row_artifact(row) for row in approval_rows]
                required_roles = set(
                    self.policy["promotion_requirements"][
                        "required_approval_roles"
                    ][candidate["kind"]]
                )
                if {item["approver_role"] for item in approvals} != required_roles:
                    raise ProtocolError(
                        "Learning promotion is missing required accountable approvals."
                    )
                separated = {
                    candidate["created_by"],
                    evaluation["evaluator_id"],
                    *(item["approved_by"] for item in approvals),
                }
                if promoted_by in separated:
                    raise ProtocolError(
                        "Learning promoter must be separate from creator, evaluator, and approvers."
                    )
                packet = finalize_learning_artifact(
                    {
                        "version": PROTOCOL_VERSION,
                        "id": promotion_id
                        or f"learning-promotion-{uuid.uuid4().hex}",
                        "candidate_id": candidate_id,
                        "candidate_sha256": candidate["content_sha256"],
                        "evaluation_id": evaluation["id"],
                        "evaluation_sha256": evaluation["content_sha256"],
                        "approval_ids": [item["id"] for item in approvals],
                        "approval_sha256s": [
                            item["content_sha256"] for item in approvals
                        ],
                        "promoted_by": promoted_by,
                        "promoter_role": "promoter",
                        "target_ref": candidate["target_ref"],
                        "artifact_sha256": candidate["artifact_sha256"],
                        "status": status,
                        "applies_target_mutation": False,
                        "created_at": created_at,
                    }
                )
                validate_learning_promotion(packet)
                connection.execute(
                    """
                    INSERT INTO promotions(
                        id, candidate_id, evaluation_id, status, artifact_json,
                        content_sha256, created_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        packet["id"],
                        candidate_id,
                        evaluation["id"],
                        status,
                        _canonical_json(packet),
                        packet["content_sha256"],
                        created_at,
                    ),
                )
                candidate = self._set_candidate_status(
                    connection, candidate_row, status
                )
                self._append_event(
                    connection,
                    event_type=(
                        "promotion-recorded"
                        if status == "promoted"
                        else "rollback-recorded"
                    ),
                    candidate_id=candidate_id,
                    occurred_at=created_at,
                    payload={
                        "promotion": packet,
                        "derived_candidate": candidate,
                    },
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return packet

    def snapshot(self, candidate_id: str) -> dict[str, Any]:
        candidate_id = _require_string(candidate_id, "Learning candidate id")
        with self._connection() as connection:
            self._require_initialized(connection)
            connection.execute("BEGIN")
            candidate_row = self._candidate_row(connection, candidate_id)
            observation_rows = connection.execute(
                """
                SELECT * FROM observations
                WHERE candidate_id = ?
                ORDER BY completed_at, id
                """,
                (candidate_id,),
            ).fetchall()
            evaluation_rows = connection.execute(
                """
                SELECT * FROM evaluations
                WHERE candidate_id = ?
                ORDER BY evaluated_at, id
                """,
                (candidate_id,),
            ).fetchall()
            approval_rows = connection.execute(
                """
                SELECT * FROM approvals
                WHERE candidate_id = ?
                ORDER BY decided_at, id
                """,
                (candidate_id,),
            ).fetchall()
            promotion_rows = connection.execute(
                """
                SELECT * FROM promotions
                WHERE candidate_id = ?
                ORDER BY created_at, id
                """,
                (candidate_id,),
            ).fetchall()
            event_count = connection.execute(
                """
                SELECT COUNT(*) FROM learning_events
                WHERE candidate_id = ?
                """,
                (candidate_id,),
            ).fetchone()[0]
            connection.commit()
        candidate = self._row_artifact(candidate_row)
        observations = [self._row_artifact(row) for row in observation_rows]
        evaluations = [self._row_artifact(row) for row in evaluation_rows]
        approvals = [self._row_artifact(row) for row in approval_rows]
        promotions = [self._row_artifact(row) for row in promotion_rows]
        nodes = [
            {"id": f"learning-candidate:{candidate_id}", "type": "learning-candidate"}
        ]
        edges: list[dict[str, str]] = []
        for observation in observations:
            node = f"learning-observation:{observation['id']}"
            nodes.append({"id": node, "type": "learning-observation"})
            edges.append(
                {
                    "type": (
                        "replays"
                        if observation["mode"] == "counterfactual-replay"
                        else "shadows"
                    ),
                    "from": node,
                    "to": f"learning-candidate:{candidate_id}",
                }
            )
        for evaluation in evaluations:
            node = f"learning-evaluation:{evaluation['id']}"
            nodes.append({"id": node, "type": "learning-evaluation"})
            edges.append(
                {
                    "type": "evaluates",
                    "from": node,
                    "to": f"learning-candidate:{candidate_id}",
                }
            )
        for approval in approvals:
            node = f"learning-approval:{approval['id']}"
            nodes.append({"id": node, "type": "learning-approval"})
            edges.append(
                {
                    "type": "approves",
                    "from": node,
                    "to": f"learning-candidate:{candidate_id}",
                }
            )
        for promotion in promotions:
            node = f"learning-promotion:{promotion['id']}"
            nodes.append({"id": node, "type": "learning-promotion"})
            edges.append(
                {
                    "type": "promotes",
                    "from": node,
                    "to": f"learning-candidate:{candidate_id}",
                }
            )
        return {
            "candidate": candidate,
            "observations": observations,
            "evaluations": evaluations,
            "approvals": approvals,
            "promotions": promotions,
            "counts": {
                "observations": len(observations),
                "evaluations": len(evaluations),
                "approvals": len(approvals),
                "promotions": len(promotions),
                "events": event_count,
            },
            "graph": {"nodes": nodes, "edges": edges},
        }

    def verify_replay(self, candidate_id: str) -> dict[str, Any]:
        expected = self.snapshot(candidate_id)
        with self._connection() as connection:
            self._require_initialized(connection)
            connection.execute("BEGIN")
            candidate_row = self._candidate_row(connection, candidate_id)
            rows_by_table: dict[str, dict[str, dict[str, Any]]] = {}
            validators = {
                "observations": validate_learning_observation,
                "evaluations": validate_learning_evaluation,
                "approvals": validate_learning_approval,
                "promotions": validate_learning_promotion,
            }
            for table, validator in validators.items():
                table_rows = connection.execute(
                    f"SELECT * FROM {table} WHERE candidate_id = ? ORDER BY id",
                    (candidate_id,),
                ).fetchall()
                verified: dict[str, dict[str, Any]] = {}
                for row in table_rows:
                    artifact = self._row_artifact(row)
                    validator(artifact)
                    if artifact["content_sha256"] != row["content_sha256"]:
                        raise ProtocolError(
                            f"Learning {table} journal digest is invalid."
                        )
                    verified[artifact["id"]] = artifact
                rows_by_table[table] = verified
            event_rows = connection.execute(
                """
                SELECT * FROM learning_events
                WHERE candidate_id = ?
                ORDER BY sequence
                """,
                (candidate_id,),
            ).fetchall()
            replay_status: str | None = None
            replay_counts = {
                "observations": 0,
                "evaluations": 0,
                "approvals": 0,
                "promotions": 0,
            }
            seen: dict[str, set[str]] = {
                key: set() for key in replay_counts
            }
            previous: str | None = None
            for row in event_rows:
                try:
                    payload = json.loads(row["payload_json"])
                except (json.JSONDecodeError, TypeError) as exc:
                    raise ProtocolError(
                        "Learning event payload JSON is invalid."
                    ) from exc
                unsigned = {
                    "event_type": row["event_type"],
                    "candidate_id": row["candidate_id"],
                    "occurred_at": row["occurred_at"],
                    "payload": payload,
                    "previous_sha256": row["previous_sha256"],
                }
                if (
                    row["candidate_id"] != candidate_id
                    or row["previous_sha256"] != previous
                    or row["content_sha256"] != _sha256(unsigned)
                ):
                    raise ProtocolError("Learning event hash chain is invalid.")
                previous = row["content_sha256"]
                if row["event_type"] == "candidate-proposed":
                    candidate = payload.get("candidate")
                    validate_learning_candidate(candidate)
                    if replay_status is not None or candidate["status"] != "candidate":
                        raise ProtocolError(
                            "Learning replay contains an invalid candidate proposal."
                        )
                    persisted = self._row_artifact(candidate_row)
                    immutable = set(candidate) - {"status", "content_sha256"}
                    if any(candidate[field] != persisted[field] for field in immutable):
                        raise ProtocolError(
                            "Learning candidate event does not match persistence."
                        )
                    replay_status = "candidate"
                elif row["event_type"] == "observation-recorded":
                    artifact = payload.get("observation")
                    derived = payload.get("derived_candidate")
                    validate_learning_observation(artifact)
                    validate_learning_candidate(derived)
                    persisted = rows_by_table["observations"].get(artifact["id"])
                    if (
                        persisted != artifact
                        or derived["id"] != candidate_id
                        or derived["status"]
                        != (
                            "replay"
                            if artifact["mode"] == "counterfactual-replay"
                            else "shadow"
                        )
                    ):
                        raise ProtocolError(
                            "Learning observation event does not match persistence."
                        )
                    if artifact["id"] in seen["observations"]:
                        raise ProtocolError(
                            "Learning replay contains a duplicate observation."
                        )
                    seen["observations"].add(artifact["id"])
                    replay_counts["observations"] += 1
                    replay_status = derived["status"]
                elif row["event_type"] == "evaluation-recorded":
                    artifact = payload.get("evaluation")
                    validate_learning_evaluation(artifact)
                    if rows_by_table["evaluations"].get(artifact["id"]) != artifact:
                        raise ProtocolError(
                            "Learning evaluation event does not match persistence."
                        )
                    if artifact["id"] in seen["evaluations"]:
                        raise ProtocolError(
                            "Learning replay contains a duplicate evaluation."
                        )
                    seen["evaluations"].add(artifact["id"])
                    replay_counts["evaluations"] += 1
                elif row["event_type"] == "approval-recorded":
                    artifact = payload.get("approval")
                    derived = payload.get("derived_candidate")
                    validate_learning_approval(artifact)
                    validate_learning_candidate(derived)
                    if (
                        rows_by_table["approvals"].get(artifact["id"]) != artifact
                        or derived["id"] != candidate_id
                    ):
                        raise ProtocolError(
                            "Learning approval event does not match persistence."
                        )
                    if artifact["id"] in seen["approvals"]:
                        raise ProtocolError(
                            "Learning replay contains a duplicate approval."
                        )
                    seen["approvals"].add(artifact["id"])
                    replay_counts["approvals"] += 1
                    replay_status = derived["status"]
                elif row["event_type"] in {
                    "promotion-recorded",
                    "rollback-recorded",
                }:
                    artifact = payload.get("promotion")
                    derived = payload.get("derived_candidate")
                    validate_learning_promotion(artifact)
                    validate_learning_candidate(derived)
                    if (
                        rows_by_table["promotions"].get(artifact["id"]) != artifact
                        or derived["id"] != candidate_id
                        or derived["status"] != artifact["status"]
                    ):
                        raise ProtocolError(
                            "Learning promotion event does not match persistence."
                        )
                    if artifact["id"] in seen["promotions"]:
                        raise ProtocolError(
                            "Learning replay contains a duplicate promotion."
                        )
                    seen["promotions"].add(artifact["id"])
                    replay_counts["promotions"] += 1
                    replay_status = derived["status"]
                else:
                    raise ProtocolError(
                        f"Learning replay encountered unknown event: {row['event_type']}"
                    )
            connection.commit()
        if replay_status is None:
            raise ProtocolError("Learning replay contains no candidate proposal.")
        if replay_status != expected["candidate"]["status"]:
            raise ProtocolError(
                "Learning replay status does not match persisted candidate state."
            )
        for table in replay_counts:
            if (
                replay_counts[table] != expected["counts"][table]
                or seen[table] != set(rows_by_table[table])
            ):
                raise ProtocolError(
                    f"Learning replay {table} do not match persistence."
                )
        return {
            "status": "passed",
            "candidate_id": candidate_id,
            "candidate_status": replay_status,
            **{f"{key[:-1]}_count": value for key, value in replay_counts.items()},
            "event_count": len(event_rows),
            "event_chain_tip": previous,
        }
