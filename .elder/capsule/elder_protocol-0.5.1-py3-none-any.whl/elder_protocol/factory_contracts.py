from __future__ import annotations

from collections import Counter
from datetime import datetime
from pathlib import Path
import re
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.schema_validation import (
    validate_against_schema,
    validate_schema_catalog,
)


FACTORY_CONTRACT_VERSION = "1.0.0"
FACTORY_CONTRACTS_CONTENT_SHA256 = (
    "7a1ea07c4b6baa2a117d1e2e27800c71ac9b410bfd1defb9641dcf4f43acd311"
)
FACTORY_DIR = ROOT / "factory"
FACTORY_CONTRACTS_PATH = FACTORY_DIR / "factory-contracts.json"

REQUIRED_SCHEMA_PATHS = {
    "factory/factory-command.schema.json",
    "factory/factory-event.schema.json",
    "factory/factory-adapter-request.schema.json",
    "factory/factory-adapter-response.schema.json",
    "factory/factory-cursor.schema.json",
}
REQUIRED_OPERATIONS = {
    "worker-adapter": {
        "prepare": "mutation",
        "start": "mutation",
        "send": "mutation",
        "observe": "read",
        "checkpoint": "mutation",
        "cancel": "mutation",
        "recover": "mutation",
        "collect-evidence": "read",
    },
    "governance-adapter": {
        "classify": "read",
        "assemble-context": "read",
        "authorize": "read",
        "validate-delegation": "read",
        "evaluate": "read",
        "qualify": "read",
        "propose-learning": "mutation",
        "promote": "mutation",
    },
    "integration-adapter": {
        "ingest-signal": "mutation",
        "ingest-decision": "mutation",
        "publish-projection": "mutation",
    },
}
REQUIRED_OPERATION_FIELDS = {
    "worker-adapter": {
        "prepare": ({"work_item", "authority", "context"}, {"prepared_run"}),
        "start": ({"prepared_run"}, {"worker_session"}),
        "send": ({"command"}, {"accepted_command"}),
        "observe": ({"cursor"}, {"events", "next_cursor"}),
        "checkpoint": ({"session"}, {"checkpoint"}),
        "cancel": ({"session", "reason"}, {"cancellation_result"}),
        "recover": ({"session", "cursor"}, {"recovery_result"}),
        "collect-evidence": ({"session"}, {"evidence_bundle"}),
    },
    "governance-adapter": {
        "classify": ({"work_item"}, {"change_class"}),
        "assemble-context": ({"context_request"}, {"context_packet"}),
        "authorize": ({"action"}, {"authority_result"}),
        "validate-delegation": ({"delegation"}, {"validation_result"}),
        "evaluate": ({"evidence"}, {"evaluation_result"}),
        "qualify": ({"bundle"}, {"qualification_report"}),
        "propose-learning": ({"trajectory"}, {"learning_candidate"}),
        "promote": ({"promotion_packet"}, {"governed_target_result"}),
    },
    "integration-adapter": {
        "ingest-signal": ({"signal"}, {"accepted_signal"}),
        "ingest-decision": ({"decision"}, {"accepted_decision"}),
        "publish-projection": ({"event"}, {"delivery_result"}),
    },
}
REQUIRED_ERRORS = {
    "invalid-request": ("rejected", "never", "never", "not-started"),
    "unsupported-version": ("rejected", "never", "never", "not-started"),
    "unauthorized": ("rejected", "never", "never", "not-started"),
    "forbidden": ("rejected", "never", "never", "not-started"),
    "not-found": ("rejected", "never", "never", "not-started"),
    "conflict": ("rejected", "never", "never", "not-started"),
    "timeout": (
        "timeout",
        "same-request",
        "same-idempotency-key",
        "not-applied",
    ),
    "stale-cursor": (
        "stale-cursor",
        "refresh-cursor",
        "never",
        "not-applicable",
    ),
    "uncertain-mutation": ("uncertain", "never", "reconcile", "unknown"),
    "provider-unavailable": (
        "timeout",
        "same-request",
        "same-idempotency-key",
        "not-applied",
    ),
    "internal-error": (
        "failed",
        "same-request",
        "same-idempotency-key",
        "not-applied",
    ),
}
REQUIRED_EVENT_CONTRACTS = {
    "command.accepted": (
        {"factory-operations"},
        {"command_id", "command_status"},
        set(),
    ),
    "command.delivered": (
        {"factory-operations"},
        {"command_id", "command_status", "worker_session_id"},
        set(),
    ),
    "command.acknowledged": (
        {"factory-operations", "worker"},
        {"command_id", "command_status"},
        {"worker_reference"},
    ),
    "command.succeeded": (
        {"factory-operations", "worker"},
        {"command_id", "command_status", "result_ref"},
        set(),
    ),
    "command.rejected": (
        {"factory-operations", "worker"},
        {"command_id", "command_status", "error_code"},
        set(),
    ),
    "command.failed": (
        {"factory-operations", "worker"},
        {"command_id", "command_status", "error_code"},
        set(),
    ),
    "command.uncertain": (
        {"factory-operations", "worker"},
        {"command_id", "command_status", "reconciliation_ref"},
        set(),
    ),
    "command.cancelled": (
        {"factory-operations", "worker"},
        {"command_id", "command_status", "reason"},
        set(),
    ),
    "worker.session.started": (
        {"factory-operations", "worker"},
        {"worker_session_id", "session_generation"},
        {"external_session_ref"},
    ),
    "worker.session.waiting": (
        {"factory-operations", "worker"},
        {"worker_session_id", "waiting_reason"},
        set(),
    ),
    "worker.session.recovered": (
        {"factory-operations", "worker"},
        {"worker_session_id", "session_generation", "checkpoint_cursor"},
        set(),
    ),
    "worker.session.completed": (
        {"factory-operations", "worker"},
        {"worker_session_id", "outcome_ref"},
        set(),
    ),
    "worker.session.failed": (
        {"factory-operations", "worker"},
        {"worker_session_id", "error_code"},
        set(),
    ),
    "worker.session.lost": (
        {"factory-operations"},
        {"worker_session_id", "reconciliation_ref"},
        set(),
    ),
    "decision.requested": (
        {"factory-operations"},
        {"decision_request_id", "subject_sha256"},
        set(),
    ),
    "decision.resolved": (
        {"factory-operations", "product-owner"},
        {"decision_request_id", "decision_id", "decision"},
        set(),
    ),
    "run.started": (
        {"factory-operations"},
        {"run_id", "worker_session_id"},
        set(),
    ),
    "run.waiting": (
        {"factory-operations"},
        {"run_id", "waiting_reason"},
        set(),
    ),
    "run.completed": (
        {"factory-operations"},
        {"run_id", "outcome_id"},
        set(),
    ),
    "run.failed": (
        {"factory-operations"},
        {"run_id", "error_code"},
        set(),
    ),
    "run.cancelled": (
        {"factory-operations"},
        {"run_id", "reason"},
        set(),
    ),
    "integration.signal.accepted": (
        {"factory-operations"},
        {"signal_id", "source_reference"},
        set(),
    ),
    "integration.decision.accepted": (
        {"factory-operations"},
        {"decision_id", "decision_request_id"},
        set(),
    ),
}
PROVIDER_TERMS = {"mastra", "prime", "humanlayer", "codex", "factory-ai"}
SECRET_SHAPED_KEY = re.compile(
    r"(?:^|[_-])(secret|token|password|credential|api[_-]?key|private[_-]?key)(?:$|[_-])",
    re.IGNORECASE,
)
COMMON_SECRET_VALUE = re.compile(
    r"(?i)(?:"
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----|"
    r"\bBearer\s+[A-Za-z0-9._~+/=-]{8,}|"
    r"\b(?:sk|ghp|github_pat|xox[baprs])[-_][A-Za-z0-9_-]{8,}|"
    r"\bAKIA[0-9A-Z]{16}\b|"
    r"(?:^|[-_ ])(?:raw[-_ ])?(?:secret|password|credential)(?:$|[-_ :=])"
    r")"
)
OPAQUE_REFERENCE = re.compile(
    r"^[a-z][a-z0-9+.-]*:[^\s]{3,512}$"
)
SHA256_PATTERN = re.compile(r"^[a-f0-9]{64}$")


def _require_unique(records: list[dict[str, Any]], key: str, label: str) -> None:
    values = [record[key] for record in records]
    duplicates = sorted(
        value for value, count in Counter(values).items() if count > 1
    )
    if duplicates:
        raise ProtocolError(f"Duplicate {label} ids: {', '.join(duplicates)}")


def _parse_time(value: str, label: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO 8601 date-time.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed


def _parse_version(value: str, label: str) -> tuple[int, int, int]:
    match = re.fullmatch(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)", value)
    if match is None:
        raise ProtocolError(f"{label} must use MAJOR.MINOR.PATCH semantic versioning.")
    return tuple(int(part) for part in match.groups())


def _reject_secret_material(value: Any, *, path: str = "payload") -> None:
    if isinstance(value, dict):
        for key, nested in value.items():
            key_text = str(key)
            lower_key = key_text.lower()
            is_reference = lower_key.endswith(
                ("_ref", "-ref", "_reference", "-reference")
            )
            is_digest = lower_key.endswith(
                ("_sha256", "-sha256", "_digest", "-digest")
            )
            if SECRET_SHAPED_KEY.search(key_text) and not (
                is_reference or is_digest
            ):
                raise ProtocolError(
                    f"{path} contains secret-shaped field '{key}'; use an opaque reference."
                )
            if is_reference:
                if nested is None:
                    continue
                if not isinstance(nested, str) or not OPAQUE_REFERENCE.fullmatch(
                    nested
                ):
                    raise ProtocolError(
                        f"{path}.{key} must be an opaque URI-like reference."
                    )
                continue
            if is_digest:
                if nested is None:
                    continue
                if not isinstance(nested, str) or not SHA256_PATTERN.fullmatch(
                    nested
                ):
                    raise ProtocolError(
                        f"{path}.{key} must be a lowercase SHA-256 digest."
                    )
                continue
            _reject_secret_material(nested, path=f"{path}.{key}")
    elif isinstance(value, list):
        for index, nested in enumerate(value):
            _reject_secret_material(nested, path=f"{path}[{index}]")
    elif isinstance(value, str) and COMMON_SECRET_VALUE.search(value):
        raise ProtocolError(
            f"{path} contains secret-like material; use an opaque reference."
        )


def _validate_value_contract(
    value: Any,
    contract: dict[str, Any],
    *,
    label: str,
) -> None:
    value_type = contract["type"]
    if value_type == "string":
        valid = isinstance(value, str) and bool(value)
    elif value_type == "integer":
        valid = isinstance(value, int) and not isinstance(value, bool)
    elif value_type == "boolean":
        valid = isinstance(value, bool)
    elif value_type == "object":
        valid = isinstance(value, dict)
    elif value_type == "array":
        valid = isinstance(value, list)
    elif value_type == "sha256":
        valid = isinstance(value, str) and bool(SHA256_PATTERN.fullmatch(value))
    elif value_type == "opaque-reference":
        valid = isinstance(value, str) and bool(OPAQUE_REFERENCE.fullmatch(value))
    elif value_type == "factory-command":
        if not isinstance(value, dict):
            valid = False
        else:
            validate_factory_command_data(value)
            valid = True
    elif value_type == "factory-event":
        if not isinstance(value, dict):
            valid = False
        else:
            validate_factory_event_data(value)
            valid = True
    elif value_type == "factory-cursor":
        if not isinstance(value, dict):
            valid = False
        else:
            validate_factory_cursor_data(value)
            valid = True
    else:
        raise ProtocolError(f"{label} uses unknown value type '{value_type}'.")
    if not valid:
        raise ProtocolError(f"{label} must have value type '{value_type}'.")
    if value_type == "array":
        item_contract = {
            "type": contract["item_type"],
            "required_fields": [],
        }
        for index, item in enumerate(value):
            _validate_value_contract(
                item,
                item_contract,
                label=f"{label}[{index}]",
            )
    required_fields = set(contract["required_fields"])
    if required_fields:
        if not isinstance(value, dict) or not required_fields <= set(value):
            raise ProtocolError(
                f"{label} must contain fields {sorted(required_fields)}."
            )


def _contract_map(registry: dict[str, Any]) -> dict[str, dict[str, str]]:
    return {
        contract["id"]: {
            operation["name"]: operation["mutability"]
            for operation in contract["operations"]
        }
        for contract in registry["contracts"]
    }


def _operation_field_map(
    registry: dict[str, Any],
) -> dict[str, dict[str, tuple[set[str], set[str]]]]:
    return {
        contract["id"]: {
            operation["name"]: (
                set(operation["request_fields"]),
                set(operation["result_fields"]),
            )
            for operation in contract["operations"]
        }
        for contract in registry["contracts"]
    }


def validate_factory_contracts_data(
    registry: dict[str, Any],
    *,
    repository_root: Path = ROOT,
    factory_root: Path = FACTORY_DIR,
) -> dict[str, int]:
    validate_schema_catalog(factory_root)
    validate_against_schema(
        registry,
        "factory-contracts.schema.json",
        label="Stable factory contract registry",
        schema_root=factory_root,
    )
    if registry["version"] != FACTORY_CONTRACT_VERSION:
        raise ProtocolError(
            f"Factory contract registry version must be {FACTORY_CONTRACT_VERSION}."
        )

    _require_unique(registry["contracts"], "id", "factory contract")
    contracts = _contract_map(registry)
    if contracts != REQUIRED_OPERATIONS:
        raise ProtocolError(
            "Factory contract operations or mutability do not match the canonical set."
        )
    for contract in registry["contracts"]:
        _require_unique(contract["operations"], "name", f"{contract['id']} operation")
        for operation in contract["operations"]:
            normalized = " ".join(
                [
                    operation["name"],
                    *operation["request_fields"],
                    *operation["result_fields"],
                ]
            ).lower()
            if any(term in normalized for term in PROVIDER_TERMS):
                raise ProtocolError(
                    f"Factory contract '{contract['id']}' leaks provider-specific identity."
                )
            if set(operation["request_types"]) != set(
                operation["request_fields"]
            ):
                raise ProtocolError(
                    f"Operation '{contract['id']}.{operation['name']}' request "
                    "type contracts do not match request_fields."
                )
            if set(operation["result_types"]) != set(
                operation["result_fields"]
            ):
                raise ProtocolError(
                    f"Operation '{contract['id']}.{operation['name']}' result "
                    "type contracts do not match result_fields."
                )
    operation_fields = _operation_field_map(registry)
    if operation_fields != REQUIRED_OPERATION_FIELDS:
        raise ProtocolError(
            "Factory operation request or result fields do not match the canonical set."
        )

    _require_unique(registry["events"], "type", "factory event contract")
    events = {
        event["type"]: (
            set(event["source_planes"]),
            set(event["required_payload_fields"]),
            set(event["optional_payload_fields"]),
        )
        for event in registry["events"]
    }
    if events != REQUIRED_EVENT_CONTRACTS:
        raise ProtocolError(
            "Factory event types or payload contracts do not match the canonical set."
        )
    for event_type, (_, required, optional) in events.items():
        overlap = required & optional
        if overlap:
            raise ProtocolError(
                f"Factory event '{event_type}' repeats payload fields: {sorted(overlap)}"
            )
        event = next(item for item in registry["events"] if item["type"] == event_type)
        if set(event["payload_types"]) != required | optional:
            raise ProtocolError(
                f"Factory event '{event_type}' payload type contracts do not "
                "match its declared fields."
            )
    if next(
        contract
        for contract in registry["contracts"]
        if contract["id"] == "worker-adapter"
    )["canonical_write_authority"] != "none":
        raise ProtocolError("Worker adapters cannot hold canonical write authority.")
    if next(
        contract
        for contract in registry["contracts"]
        if contract["id"] == "integration-adapter"
    )["canonical_write_authority"] != "none":
        raise ProtocolError("Integration adapters cannot hold canonical write authority.")

    schemas = set(registry["schemas"])
    if schemas != REQUIRED_SCHEMA_PATHS:
        raise ProtocolError(
            "Factory contract registry schema paths do not match the canonical set."
        )
    for schema_path in schemas:
        resolved = (repository_root / schema_path).resolve()
        try:
            resolved.relative_to(repository_root.resolve())
        except ValueError as exc:
            raise ProtocolError(
                f"Factory contract schema escapes the repository: {schema_path}"
            ) from exc
        if not resolved.is_file():
            raise ProtocolError(f"Factory contract schema is missing: {schema_path}")

    _require_unique(registry["errors"], "code", "factory error")
    errors = {
        item["code"]: (
            item["disposition"],
            item["read_retry"],
            item["mutation_retry"],
            item["mutation_state"],
        )
        for item in registry["errors"]
    }
    if errors != REQUIRED_ERRORS:
        raise ProtocolError("Factory error taxonomy does not match the canonical set.")
    if registry["compatibility"]["same_major"] != (
        "exact-version-required-until-side-by-side-schema-negotiation-exists"
    ):
        raise ProtocolError(
            "Factory consumers must require the exact version until negotiation exists."
        )
    if registry["compatibility"]["unknown_fields"] != (
        "reject-except-namespaced-extensions"
    ):
        raise ProtocolError("Unknown contract fields must fail closed.")
    if registry["idempotency"]["required_for"] != "all-mutations":
        raise ProtocolError("All mutating adapter operations require idempotency.")
    if registry["cursor"]["delivery_rule"] != (
        "live-delivery-is-a-projection-and-the-durable-journal-remains-authoritative"
    ):
        raise ProtocolError("The durable journal must remain authoritative.")
    if registry["redaction"]["secret_values"] != (
        "forbidden-by-contract-common-formats-rejected-use-opaque-secret-references"
    ):
        raise ProtocolError("Stable contracts must forbid inline secret values.")
    if registry["redaction"]["restricted_payload"] != (
        "opaque-references-only-except-digest-only-events"
    ):
        raise ProtocolError(
            "Restricted adapter payloads must use opaque references."
        )
    if canonical_sha256(registry) != FACTORY_CONTRACTS_CONTENT_SHA256:
        raise ProtocolError(
            "Factory contract registry content does not match its canonical digest."
        )

    return {
        "contracts": len(registry["contracts"]),
        "operations": sum(len(items) for items in contracts.values()),
        "events": len(registry["events"]),
        "errors": len(registry["errors"]),
        "schemas": len(registry["schemas"]),
    }


def validate_factory_contracts(
    path: Path = FACTORY_CONTRACTS_PATH,
) -> dict[str, Any]:
    registry = load_json(path)
    validate_factory_contracts_data(
        registry,
        repository_root=path.parent.parent,
        factory_root=path.parent,
    )
    return registry


def versions_are_compatible(producer: str, consumer: str) -> bool:
    _parse_version(producer, "Producer version")
    _parse_version(consumer, "Consumer version")
    return producer == consumer


def require_compatible_version(
    producer: str,
    consumer: str = FACTORY_CONTRACT_VERSION,
) -> None:
    if not versions_are_compatible(producer, consumer):
        raise ProtocolError(
            f"Incompatible factory contract versions: producer={producer}, "
            f"consumer={consumer}."
        )


def _validate_payload_document(
    document: dict[str, Any],
    schema_name: str,
    label: str,
) -> None:
    validate_against_schema(
        document,
        schema_name,
        label=label,
        schema_root=FACTORY_DIR,
    )
    require_compatible_version(document["version"])
    _reject_secret_material(document, path=label)
    if document["payload_mode"] == "inline":
        expected = canonical_sha256(document["payload"])
        if document["payload_sha256"] != expected:
            raise ProtocolError(
                f"{label} payload_sha256 does not match the inline payload."
            )


def validate_factory_command_data(command: dict[str, Any]) -> dict[str, Any]:
    _validate_payload_document(
        command,
        "factory-command.schema.json",
        "Factory command",
    )
    if command["mutability"] == "mutation" and not command["idempotency_key"]:
        raise ProtocolError("Mutating factory commands require idempotency_key.")
    submitted = _parse_time(command["submitted_at"], "Command submitted_at")
    if command["expires_at"] is not None:
        expires = _parse_time(command["expires_at"], "Command expires_at")
        if expires <= submitted:
            raise ProtocolError("Command expires_at must be later than submitted_at.")
    if command["status"] == "uncertain" and command["mutability"] != "mutation":
        raise ProtocolError("Only a mutating command may enter uncertain status.")
    return command


def validate_factory_event_data(event: dict[str, Any]) -> dict[str, Any]:
    _validate_payload_document(
        event,
        "factory-event.schema.json",
        "Factory event",
    )
    occurred = _parse_time(event["occurred_at"], "Event occurred_at")
    recorded = _parse_time(event["recorded_at"], "Event recorded_at")
    if recorded < occurred:
        raise ProtocolError("Event recorded_at cannot be earlier than occurred_at.")
    if event["event_type"] not in REQUIRED_EVENT_CONTRACTS:
        raise ProtocolError(
            f"Unknown canonical factory event type '{event['event_type']}'."
        )
    allowed_planes, required_fields, optional_fields = REQUIRED_EVENT_CONTRACTS[
        event["event_type"]
    ]
    if event["source"]["plane"] not in allowed_planes:
        raise ProtocolError(
            f"Factory event '{event['event_type']}' cannot originate from plane "
            f"'{event['source']['plane']}'."
        )
    payload_fields = set(event["payload"])
    allowed_fields = required_fields | optional_fields
    if not required_fields <= payload_fields or not payload_fields <= allowed_fields:
        raise ProtocolError(
            f"Factory event '{event['event_type']}' payload fields must include "
            f"{sorted(required_fields)} and may only include "
            f"{sorted(allowed_fields)}."
        )
    event_contract = next(
        item
        for item in validate_factory_contracts()["events"]
        if item["type"] == event["event_type"]
    )
    for field in payload_fields:
        _validate_value_contract(
            event["payload"][field],
            event_contract["payload_types"][field],
            label=f"Factory event '{event['event_type']}' payload field '{field}'",
        )
    if event["event_type"].startswith("integration.") and not event["idempotency_key"]:
        raise ProtocolError(
            "Accepted external integration events require idempotency_key."
        )
    if event["event_type"].startswith("command."):
        expected_status = event["event_type"].split(".", 1)[1]
        if event["payload"]["command_status"] != expected_status:
            raise ProtocolError(
                f"Command event status must be '{expected_status}'."
            )
    cursor = validate_factory_cursor_data(event["cursor"])
    if event["record_kind"] == "journal-entry":
        if cursor["sequence"] < 1 or cursor["event_id"] != event["event_id"]:
            raise ProtocolError(
                "Journal events must bind their positive cursor sequence and event_id."
            )
    elif cursor["event_id"] != event["source_event_id"]:
        raise ProtocolError(
            "Live projections must bind the cursor of their canonical source event."
        )
    return event


def validate_factory_cursor_data(cursor: dict[str, Any]) -> dict[str, Any]:
    validate_against_schema(
        cursor,
        "factory-cursor.schema.json",
        label="Factory cursor",
        schema_root=FACTORY_DIR,
    )
    require_compatible_version(cursor["version"])
    _parse_time(cursor["issued_at"], "Cursor issued_at")
    return cursor


def validate_cursor_window(
    requested: dict[str, Any],
    current: dict[str, Any],
    minimum_available: dict[str, Any],
) -> str:
    requested = validate_factory_cursor_data(requested)
    current = validate_factory_cursor_data(current)
    minimum_available = validate_factory_cursor_data(minimum_available)
    streams = {
        requested["stream_id"],
        current["stream_id"],
        minimum_available["stream_id"],
    }
    if len(streams) != 1:
        raise ProtocolError("Cursor stream_id does not match the observed stream.")
    if requested["generation"] > current["generation"]:
        raise ProtocolError("Cursor generation is from the future.")
    if requested["generation"] < current["generation"]:
        return "stale"
    if minimum_available["generation"] != current["generation"]:
        raise ProtocolError("Current and minimum cursors must use the same generation.")
    if requested["sequence"] > current["sequence"]:
        raise ProtocolError("Cursor sequence is from the future.")
    if requested["sequence"] < minimum_available["sequence"]:
        return "stale"
    if requested["sequence"] == current["sequence"]:
        return "current"
    return "available"


def validate_adapter_request_data(
    request: dict[str, Any],
    *,
    registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    _validate_payload_document(
        request,
        "factory-adapter-request.schema.json",
        "Factory adapter request",
    )
    registry = registry or validate_factory_contracts()
    operations = _contract_map(registry)
    contract_id = request["contract_id"]
    operation = request["operation"]
    if operation not in operations[contract_id]:
        raise ProtocolError(
            f"Unknown operation '{operation}' for contract '{contract_id}'."
        )
    expected_mutability = operations[contract_id][operation]
    if request["mutability"] != expected_mutability:
        raise ProtocolError(
            f"Operation '{contract_id}.{operation}' must declare "
            f"mutability '{expected_mutability}'."
        )
    if expected_mutability == "mutation" and not request["idempotency_key"]:
        raise ProtocolError("Mutating adapter requests require idempotency_key.")
    expected_request_fields = REQUIRED_OPERATION_FIELDS[contract_id][operation][0]
    actual_request_fields = set(request["payload"])
    if actual_request_fields != expected_request_fields:
        raise ProtocolError(
            f"Operation '{contract_id}.{operation}' request fields must be "
            f"{sorted(expected_request_fields)}; received "
            f"{sorted(actual_request_fields)}."
        )
    operation_contract = next(
        item
        for contract in registry["contracts"]
        if contract["id"] == contract_id
        for item in contract["operations"]
        if item["name"] == operation
    )
    for field, value_contract in operation_contract["request_types"].items():
        _validate_value_contract(
            request["payload"][field],
            value_contract,
            label=f"Operation '{contract_id}.{operation}' request field '{field}'",
        )
    submitted = _parse_time(request["submitted_at"], "Request submitted_at")
    if request["deadline_at"] is not None:
        deadline = _parse_time(request["deadline_at"], "Request deadline_at")
        if deadline <= submitted:
            raise ProtocolError("Request deadline_at must be later than submitted_at.")
    return request


def validate_adapter_response_data(
    response: dict[str, Any],
    *,
    request: dict[str, Any],
    original_request: dict[str, Any] | None = None,
    original_response: dict[str, Any] | None = None,
    registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    validate_against_schema(
        response,
        "factory-adapter-response.schema.json",
        label="Factory adapter response",
        schema_root=FACTORY_DIR,
    )
    require_compatible_version(response["version"])
    registry = registry or validate_factory_contracts()
    validate_adapter_request_data(request, registry=registry)
    for field in ("contract_id", "operation", "request_id", "project_id"):
        if response[field] != request[field]:
            raise ProtocolError(
                f"Adapter response {field} does not match its request."
            )
    if response["request_sha256"] != canonical_sha256(request):
        raise ProtocolError(
            "Adapter response request_sha256 does not match its request."
        )
    _parse_time(response["responded_at"], "Response responded_at")
    _reject_secret_material(response, path="Adapter response")
    if response["result_mode"] == "inline" and response["result"]:
        if response["result_sha256"] != canonical_sha256(response["result"]):
            raise ProtocolError(
                "Adapter response result_sha256 does not match its result."
            )
    elif response["result_mode"] == "inline" and response["result_sha256"] is not None:
        raise ProtocolError(
            "Adapter response result_sha256 must be null when result is empty."
        )
    elif response["result_mode"] == "digest-only" and response["result_sha256"] is None:
        raise ProtocolError(
            "Digest-only adapter responses require result_sha256."
        )

    mutability = request["mutability"]
    disposition = response["disposition"]
    if response["error"] is not None:
        error_code = response["error"]["code"]
        if error_code not in REQUIRED_ERRORS:
            raise ProtocolError(f"Unknown factory error code '{error_code}'.")
        (
            expected_disposition,
            read_retry,
            mutation_retry,
            mutation_state,
        ) = REQUIRED_ERRORS[error_code]
        expected_retry = read_retry if mutability == "read" else mutation_retry
        expected_state = (
            "not-applicable" if mutability == "read" else mutation_state
        )
        if disposition != expected_disposition:
            raise ProtocolError(
                f"Factory error '{error_code}' requires disposition "
                f"'{expected_disposition}'."
            )
        if (response["retry"], response["mutation_state"]) != (
            expected_retry,
            expected_state,
        ):
            raise ProtocolError(
                f"Factory error '{error_code}' requires retry '{expected_retry}' "
                f"and mutation_state '{expected_state}'."
            )
        if response["operation_completed"]:
            raise ProtocolError(
                f"Adapter disposition '{disposition}' cannot claim completion."
            )
        if response["result"] or response["result_sha256"] is not None:
            raise ProtocolError(
                f"Adapter error '{error_code}' cannot carry a successful result."
            )
        if error_code == "uncertain-mutation" and mutability != "mutation":
            raise ProtocolError("Only mutations can have uncertain outcomes.")
    else:
        if disposition not in {"accepted", "succeeded", "duplicate"}:
            raise ProtocolError(
                f"Adapter disposition '{disposition}' requires an error."
            )
        if response["result_mode"] != "inline":
            raise ProtocolError(
                f"Adapter disposition '{disposition}' requires an inline result."
            )
        expected_result_fields = REQUIRED_OPERATION_FIELDS[
            request["contract_id"]
        ][request["operation"]][1]
        if set(response["result"]) != expected_result_fields:
            raise ProtocolError(
                f"Operation '{request['contract_id']}.{request['operation']}' "
                f"result fields must be {sorted(expected_result_fields)}."
            )
        operation_contract = next(
            item
            for contract in registry["contracts"]
            if contract["id"] == request["contract_id"]
            for item in contract["operations"]
            if item["name"] == request["operation"]
        )
        for field, value_contract in operation_contract["result_types"].items():
            _validate_value_contract(
                response["result"][field],
                value_contract,
                label=(
                    f"Operation '{request['contract_id']}."
                    f"{request['operation']}' result field '{field}'"
                ),
            )
        if disposition == "accepted":
            expected_state = (
                "not-started" if mutability == "mutation" else "not-applicable"
            )
            if response["operation_completed"]:
                raise ProtocolError("Command or operation acceptance is not completion.")
            if response["mutation_state"] != expected_state:
                raise ProtocolError(
                    f"Accepted {mutability} operations require mutation_state "
                    f"'{expected_state}'."
                )
        elif disposition == "succeeded":
            expected_state = (
                "applied" if mutability == "mutation" else "not-applicable"
            )
            if not response["operation_completed"]:
                raise ProtocolError(
                    "Succeeded adapter operations must claim completion."
                )
            if response["mutation_state"] != expected_state:
                raise ProtocolError(
                    f"Succeeded {mutability} operations require mutation_state "
                    f"'{expected_state}'."
                )
        else:
            if mutability != "mutation" or request["idempotency_key"] is None:
                raise ProtocolError(
                    "Duplicate disposition is valid only for idempotent mutations."
                )
        if response["retry"] != "never":
            raise ProtocolError(
                f"Adapter disposition '{disposition}' must not request a retry."
            )

    if disposition == "stale-cursor":
        if request["operation"] != "observe" or response["cursor"] is None:
            raise ProtocolError(
                "Stale cursor responses require observe and a refresh cursor."
            )
        requested_cursor = request["payload"]["cursor"]
        refresh_cursor = validate_factory_cursor_data(response["cursor"])
        requested_cursor = validate_factory_cursor_data(requested_cursor)
        if refresh_cursor["stream_id"] != requested_cursor["stream_id"]:
            raise ProtocolError(
                "Stale cursor refresh must use the requested stream_id."
            )
        if refresh_cursor["generation"] < requested_cursor["generation"]:
            raise ProtocolError(
                "Stale cursor refresh cannot move to an older generation."
            )
        if (
            refresh_cursor["generation"] == requested_cursor["generation"]
            and refresh_cursor["sequence"] <= requested_cursor["sequence"]
        ):
            raise ProtocolError(
                "Stale cursor refresh must advance in the same generation."
            )
        if refresh_cursor["snapshot_sha256"] is None:
            raise ProtocolError(
                "Stale cursor refresh requires a snapshot_sha256."
            )
    elif response["cursor"] is not None:
        raise ProtocolError(
            "Top-level response cursor is reserved for stale-cursor refresh."
        )

    if disposition == "duplicate":
        if response["original_response_sha256"] is None:
            raise ProtocolError(
                "Duplicate responses require original_response_sha256."
            )
        if original_request is None or original_response is None:
            raise ProtocolError(
                "Duplicate response validation requires the original exchange."
            )
        validate_idempotent_replay(original_request, request)
        validate_adapter_response_data(
            original_response,
            request=original_request,
            registry=registry,
        )
        if response["original_response_sha256"] != canonical_sha256(
            original_response
        ):
            raise ProtocolError(
                "Duplicate original_response_sha256 does not match the "
                "original durable response."
            )
        for field in (
            "operation_completed",
            "mutation_state",
            "source_of_truth",
            "result_mode",
            "redaction",
            "result_sha256",
            "result",
            "extensions",
        ):
            if response[field] != original_response[field]:
                raise ProtocolError(
                    f"Duplicate response field '{field}' does not match the "
                    "original durable response."
                )
    elif response["original_response_sha256"] is not None:
        raise ProtocolError(
            "Only duplicate responses may carry original_response_sha256."
        )

    contract_id = response["contract_id"]
    operation = response["operation"]
    source = response["source_of_truth"]
    if contract_id == "worker-adapter" and source != "adapter-observation":
        raise ProtocolError("Worker adapter responses are observations, not authority.")
    if contract_id == "governance-adapter" and source != "governance-record-reference":
        raise ProtocolError(
            "Governance adapter responses must reference governed records."
        )
    if contract_id == "integration-adapter":
        expected_source = (
            "projection-ack"
            if operation == "publish-projection"
            else "canonical-record-reference"
        )
        if source != expected_source:
            raise ProtocolError(
                f"Integration operation '{operation}' requires source_of_truth "
                f"'{expected_source}'."
            )
    return response


def validate_idempotent_replay(
    original: dict[str, Any],
    retry: dict[str, Any],
) -> None:
    validate_adapter_request_data(original)
    validate_adapter_request_data(retry)
    identity_fields = (
        "contract_id",
        "operation",
        "project_id",
        "work_item_id",
        "run_id",
        "session_id",
        "correlation_id",
        "causation_id",
        "mutability",
        "idempotency_key",
        "payload_mode",
        "redaction",
        "extensions",
    )
    for field in identity_fields:
        if retry[field] != original[field]:
            raise ProtocolError(
                f"Idempotent replay {field} does not match the original request."
            )
    if original["idempotency_key"] is None:
        raise ProtocolError("Read operations do not define mutation replay identity.")
    if retry["payload_sha256"] != original["payload_sha256"]:
        raise ProtocolError(
            "Idempotency key reuse with a different payload is a conflict."
        )
