from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, load_json, sha256_file, write_text


TRACE_ID_PATTERN = re.compile(r"^[0-9a-f]{32}$")
SPAN_ID_PATTERN = re.compile(r"^[0-9a-f]{16}$")
EVENT_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_.-]{2,127}$")
ATTRIBUTE_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_.-]{0,127}$")
SCOPES = {"product", "model", "tool", "factory", "cost", "outcome"}
SIGNALS = {"span", "event", "log", "measurement"}
STATUSES = {"ok", "error", "unset"}
SOURCE_KINDS = {"workbench", "factory", "evaluation", "native"}
CORRELATION_FIELDS = {
    "project_id",
    "work_item_id",
    "agent_run_id",
    "run_id",
    "artifact_digest",
    "deployment_id",
    "evaluation_id",
    "outcome_id",
}


def _require_exact_fields(
    value: Any,
    required: set[str],
    label: str,
) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProtocolError(f"{label} must be a JSON object.")
    if set(value) != required:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(required)}")
    return value


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(
        value
    )


def _validate_timestamp(value: Any, label: str) -> None:
    if not isinstance(value, str) or not value:
        raise ProtocolError(f"{label} must be a non-empty date-time string.")
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} is not a valid ISO-8601 date-time.") from exc


def _stable_id(prefix: str, *parts: Any, length: int) -> str:
    encoded = json.dumps(parts, sort_keys=True, separators=(",", ":"), default=str)
    digest = hashlib.sha256(f"{prefix}:{encoded}".encode("utf-8")).hexdigest()
    return digest[:length]


def _trace_id(*parts: Any) -> str:
    return _stable_id("trace", *parts, length=32)


def _span_id(*parts: Any) -> str:
    return _stable_id("span", *parts, length=16)


def _event_id(*parts: Any) -> str:
    return f"evt-{_stable_id('event', *parts, length=32)}"


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ProtocolError(f"Could not read telemetry source {path}: {exc}") from exc
    records: list[dict[str, Any]] = []
    for line_number, line in enumerate(lines, start=1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ProtocolError(
                f"Invalid JSONL in {path} at line {line_number}: {exc.msg}"
            ) from exc
        if not isinstance(record, dict):
            raise ProtocolError(
                f"Telemetry source {path} line {line_number} is not a JSON object."
            )
        records.append(record)
    if not records:
        raise ProtocolError(f"Telemetry source contains no events: {path}")
    return records


def validate_telemetry_contract(
    contract_or_path: dict[str, Any] | Path,
) -> dict[str, Any]:
    contract = (
        load_json(contract_or_path.resolve())
        if isinstance(contract_or_path, Path)
        else contract_or_path
    )
    required = {
        "version",
        "id",
        "semantic_conventions",
        "scopes",
        "correlation_fields",
        "privacy",
        "metric_policy",
        "budgets",
        "authority",
    }
    _require_exact_fields(contract, required, "Telemetry contract")
    if contract["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Telemetry contract version must be '{PROTOCOL_VERSION}'."
        )
    if not isinstance(contract["id"], str) or not contract["id"]:
        raise ProtocolError("Telemetry contract id must be a non-empty string.")

    conventions = _require_exact_fields(
        contract["semantic_conventions"],
        {"trace_context", "genai", "genai_status"},
        "Telemetry semantic conventions",
    )
    if conventions["trace_context"] != "W3C Trace Context Level 1":
        raise ProtocolError("Telemetry trace context must use W3C Trace Context Level 1.")
    if not isinstance(conventions["genai"], str) or not conventions["genai"]:
        raise ProtocolError("Telemetry contract must pin a GenAI convention reference.")
    if conventions["genai_status"] not in {"stable", "development", "mixed"}:
        raise ProtocolError("Telemetry GenAI convention status is invalid.")

    scopes = contract["scopes"]
    if not isinstance(scopes, list) or set(scopes) != SCOPES:
        raise ProtocolError(f"Telemetry scopes must be exactly: {sorted(SCOPES)}")
    correlation_fields = contract["correlation_fields"]
    if not isinstance(correlation_fields, list) or set(correlation_fields) != CORRELATION_FIELDS:
        raise ProtocolError(
            "Telemetry correlation fields must define the complete Elder correlation set."
        )

    privacy = _require_exact_fields(
        contract["privacy"],
        {
            "persist_prompts",
            "persist_outputs",
            "sensitive_attribute_patterns",
            "untrusted_trace_context",
        },
        "Telemetry privacy policy",
    )
    if privacy["persist_prompts"] or privacy["persist_outputs"]:
        raise ProtocolError("Telemetry must not persist prompts or model outputs by default.")
    patterns = privacy["sensitive_attribute_patterns"]
    if not isinstance(patterns, list) or not patterns or any(
        not isinstance(pattern, str) or not pattern for pattern in patterns
    ):
        raise ProtocolError("Telemetry sensitive attribute patterns must be non-empty.")
    if privacy["untrusted_trace_context"] != "validate-or-replace":
        raise ProtocolError("Untrusted trace context must be validated or replaced.")

    metric_policy = _require_exact_fields(
        contract["metric_policy"],
        {"forbidden_dimensions", "maximum_cardinality_per_metric"},
        "Telemetry metric policy",
    )
    forbidden = metric_policy["forbidden_dimensions"]
    if not isinstance(forbidden, list) or not {
        "trace_id",
        "span_id",
        "run_id",
        "agent_run_id",
        "work_item_id",
    } <= set(forbidden):
        raise ProtocolError(
            "Telemetry metric policy must forbid high-cardinality correlation dimensions."
        )
    cardinality = metric_policy["maximum_cardinality_per_metric"]
    if not isinstance(cardinality, int) or cardinality < 1:
        raise ProtocolError("Telemetry metric cardinality limit must be a positive integer.")

    budgets = _require_exact_fields(
        contract["budgets"],
        {
            "maximum_total_cost_usd",
            "maximum_error_rate",
            "maximum_p95_latency_ms",
            "minimum_correlation_completeness",
        },
        "Telemetry budgets",
    )
    for name, value in budgets.items():
        if not _is_number(value) or value < 0:
            raise ProtocolError(f"Telemetry budget '{name}' must be non-negative.")
    if budgets["maximum_error_rate"] > 1:
        raise ProtocolError("Telemetry maximum_error_rate cannot exceed 1.")
    if not 0 <= budgets["minimum_correlation_completeness"] <= 1:
        raise ProtocolError(
            "Telemetry minimum_correlation_completeness must be between 0 and 1."
        )

    authority = _require_exact_fields(
        contract["authority"],
        {"mode", "can_approve", "can_promote", "budget_owner"},
        "Telemetry authority",
    )
    if (
        authority["mode"] != "advisory-only"
        or authority["can_approve"] is not False
        or authority["can_promote"] is not False
        or not isinstance(authority["budget_owner"], str)
        or not authority["budget_owner"]
    ):
        raise ProtocolError("Telemetry authority must remain advisory-only.")
    return contract


def _validate_trace(trace: Any) -> None:
    trace = _require_exact_fields(
        trace,
        {"trace_id", "span_id", "parent_span_id", "origin"},
        "Telemetry trace",
    )
    if (
        not isinstance(trace["trace_id"], str)
        or not TRACE_ID_PATTERN.fullmatch(trace["trace_id"])
        or trace["trace_id"] == "0" * 32
    ):
        raise ProtocolError("Telemetry trace_id must be 32 non-zero lowercase hex digits.")
    if (
        not isinstance(trace["span_id"], str)
        or not SPAN_ID_PATTERN.fullmatch(trace["span_id"])
        or trace["span_id"] == "0" * 16
    ):
        raise ProtocolError("Telemetry span_id must be 16 non-zero lowercase hex digits.")
    parent = trace["parent_span_id"]
    if parent is not None and (
        not isinstance(parent, str)
        or not SPAN_ID_PATTERN.fullmatch(parent)
        or parent == "0" * 16
    ):
        raise ProtocolError(
            "Telemetry parent_span_id must be null or 16 non-zero lowercase hex digits."
        )
    if trace["origin"] not in {"native", "synthesized"}:
        raise ProtocolError("Telemetry trace origin must be native or synthesized.")


def _contains_sensitive_name(name: str, contract: dict[str, Any]) -> bool:
    normalized = name.upper()
    return any(
        re.search(pattern, normalized)
        for pattern in contract["privacy"]["sensitive_attribute_patterns"]
    )


def validate_telemetry_event(
    event: dict[str, Any],
    contract: dict[str, Any],
) -> dict[str, Any]:
    validate_telemetry_contract(contract)
    required = {
        "version",
        "event_id",
        "event_name",
        "signal",
        "scope",
        "recorded_at",
        "service",
        "operation",
        "status",
        "trace",
        "correlation",
        "attributes",
        "measurements",
        "cost",
        "outcome",
        "source",
    }
    _require_exact_fields(event, required, "Telemetry event")
    if event["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Telemetry event version must be '{PROTOCOL_VERSION}'."
        )
    if not isinstance(event["event_id"], str) or not re.fullmatch(
        r"evt-[0-9a-f]{32}", event["event_id"]
    ):
        raise ProtocolError("Telemetry event_id must use evt- plus 32 lowercase hex digits.")
    if not isinstance(event["event_name"], str) or not EVENT_NAME_PATTERN.fullmatch(
        event["event_name"]
    ):
        raise ProtocolError("Telemetry event_name must be a stable lowercase identifier.")
    if event["signal"] not in SIGNALS:
        raise ProtocolError(f"Telemetry signal must be one of: {sorted(SIGNALS)}")
    if event["scope"] not in SCOPES:
        raise ProtocolError(f"Telemetry scope must be one of: {sorted(SCOPES)}")
    _validate_timestamp(event["recorded_at"], "Telemetry recorded_at")
    for field in ["service", "operation"]:
        if not isinstance(event[field], str) or not event[field]:
            raise ProtocolError(f"Telemetry {field} must be a non-empty string.")
    if event["status"] not in STATUSES:
        raise ProtocolError(f"Telemetry status must be one of: {sorted(STATUSES)}")
    _validate_trace(event["trace"])

    correlation = event["correlation"]
    if not isinstance(correlation, dict) or not correlation:
        raise ProtocolError("Telemetry correlation must be a non-empty object.")
    unknown_correlation = set(correlation) - CORRELATION_FIELDS
    if unknown_correlation:
        raise ProtocolError(
            f"Telemetry correlation uses unknown fields: {sorted(unknown_correlation)}"
        )
    if not isinstance(correlation.get("project_id"), str) or not correlation["project_id"]:
        raise ProtocolError("Telemetry correlation requires project_id.")
    if not isinstance(correlation.get("run_id"), str) or not correlation["run_id"]:
        raise ProtocolError("Telemetry correlation requires run_id.")
    for name, value in correlation.items():
        if not isinstance(value, str) or not value:
            raise ProtocolError(f"Telemetry correlation '{name}' must be non-empty.")

    attributes = event["attributes"]
    if not isinstance(attributes, dict):
        raise ProtocolError("Telemetry attributes must be an object.")
    for name, value in attributes.items():
        if not isinstance(name, str) or not ATTRIBUTE_NAME_PATTERN.fullmatch(name):
            raise ProtocolError(f"Telemetry attribute name is invalid: {name!r}")
        if _contains_sensitive_name(name, contract):
            raise ProtocolError(f"Telemetry attribute name is sensitive: {name}")
        if not isinstance(value, (str, int, float, bool)) and value is not None:
            raise ProtocolError(
                f"Telemetry attribute '{name}' must be a scalar or null."
            )

    measurements = event["measurements"]
    if not isinstance(measurements, list):
        raise ProtocolError("Telemetry measurements must be a list.")
    forbidden_dimensions = set(contract["metric_policy"]["forbidden_dimensions"])
    for measurement in measurements:
        _require_exact_fields(
            measurement,
            {"name", "value", "unit", "kind", "dimensions"},
            "Telemetry measurement",
        )
        if not isinstance(measurement["name"], str) or not EVENT_NAME_PATTERN.fullmatch(
            measurement["name"]
        ):
            raise ProtocolError("Telemetry measurement name must be stable and lowercase.")
        if not _is_number(measurement["value"]):
            raise ProtocolError("Telemetry measurement value must be finite and numeric.")
        if not isinstance(measurement["unit"], str) or not measurement["unit"]:
            raise ProtocolError("Telemetry measurement unit must be non-empty.")
        if measurement["kind"] not in {"counter", "gauge", "histogram"}:
            raise ProtocolError("Telemetry measurement kind is invalid.")
        dimensions = measurement["dimensions"]
        if not isinstance(dimensions, dict):
            raise ProtocolError("Telemetry measurement dimensions must be an object.")
        prohibited = set(dimensions) & forbidden_dimensions
        if prohibited:
            raise ProtocolError(
                f"Telemetry metric uses forbidden dimensions: {sorted(prohibited)}"
            )
        for name, value in dimensions.items():
            if not isinstance(name, str) or not ATTRIBUTE_NAME_PATTERN.fullmatch(name):
                raise ProtocolError(f"Telemetry metric dimension is invalid: {name!r}")
            if _contains_sensitive_name(name, contract):
                raise ProtocolError(
                    f"Telemetry metric dimension name is sensitive: {name}"
                )
            if not isinstance(value, (str, int, bool)):
                raise ProtocolError(
                    f"Telemetry metric dimension '{name}' must be string, integer, or boolean."
                )

    cost = event["cost"]
    if cost is not None:
        _require_exact_fields(
            cost,
            {
                "currency",
                "amount_usd",
                "input_tokens",
                "output_tokens",
                "cached_tokens",
                "tool_calls",
                "compute_ms",
                "estimate",
            },
            "Telemetry cost",
        )
        if cost["currency"] != "USD":
            raise ProtocolError("Telemetry cost currency must be USD.")
        for name in [
            "amount_usd",
            "input_tokens",
            "output_tokens",
            "cached_tokens",
            "tool_calls",
            "compute_ms",
        ]:
            if not _is_number(cost[name]) or cost[name] < 0:
                raise ProtocolError(f"Telemetry cost '{name}' must be non-negative.")
        if not isinstance(cost["estimate"], bool):
            raise ProtocolError("Telemetry cost estimate must be boolean.")

    outcome = event["outcome"]
    if outcome is not None:
        _require_exact_fields(
            outcome,
            {"status", "metric", "baseline", "observed", "target", "direction"},
            "Telemetry outcome",
        )
        if outcome["status"] not in {"met", "missed", "unknown"}:
            raise ProtocolError("Telemetry outcome status is invalid.")
        if not isinstance(outcome["metric"], str) or not outcome["metric"]:
            raise ProtocolError("Telemetry outcome metric must be non-empty.")
        for name in ["baseline", "observed", "target"]:
            if outcome[name] is not None and not _is_number(outcome[name]):
                raise ProtocolError(
                    f"Telemetry outcome '{name}' must be numeric or null."
                )
        if outcome["direction"] not in {"higher-is-better", "lower-is-better", "target"}:
            raise ProtocolError("Telemetry outcome direction is invalid.")

    source = _require_exact_fields(
        event["source"],
        {"kind", "path", "sha256"},
        "Telemetry source",
    )
    if source["kind"] not in SOURCE_KINDS:
        raise ProtocolError(f"Telemetry source kind must be one of: {sorted(SOURCE_KINDS)}")
    if not isinstance(source["path"], str) or not source["path"]:
        raise ProtocolError("Telemetry source path must be non-empty.")
    if not isinstance(source["sha256"], str) or not re.fullmatch(
        r"[0-9a-f]{64}", source["sha256"]
    ):
        raise ProtocolError("Telemetry source sha256 must be 64 lowercase hex digits.")
    return event


def _event(
    *,
    event_id: str,
    event_name: str,
    signal: str,
    scope: str,
    recorded_at: str,
    service: str,
    operation: str,
    status: str,
    trace_id: str,
    span_id: str,
    parent_span_id: str | None,
    trace_origin: str,
    correlation: dict[str, str],
    attributes: dict[str, Any],
    measurements: list[dict[str, Any]],
    cost: dict[str, Any] | None,
    outcome: dict[str, Any] | None,
    source_kind: str,
    source_path: Path,
    source_sha256: str,
) -> dict[str, Any]:
    return {
        "version": PROTOCOL_VERSION,
        "event_id": event_id,
        "event_name": event_name,
        "signal": signal,
        "scope": scope,
        "recorded_at": recorded_at,
        "service": service,
        "operation": operation,
        "status": status,
        "trace": {
            "trace_id": trace_id,
            "span_id": span_id,
            "parent_span_id": parent_span_id,
            "origin": trace_origin,
        },
        "correlation": correlation,
        "attributes": attributes,
        "measurements": measurements,
        "cost": cost,
        "outcome": outcome,
        "source": {
            "kind": source_kind,
            "path": str(source_path),
            "sha256": source_sha256,
        },
    }


def ingest_workbench_trace(
    path: Path,
    contract: dict[str, Any],
    *,
    project_id: str = "elder-workbench",
) -> list[dict[str, Any]]:
    records = _read_jsonl(path.resolve())
    source_sha256 = sha256_file(path.resolve())
    run_ids = {record.get("run_id") for record in records}
    if len(run_ids) != 1 or not all(isinstance(run_id, str) and run_id for run_id in run_ids):
        raise ProtocolError("Workbench trace must contain exactly one non-empty run_id.")
    run_id = next(iter(run_ids))
    terminal = [
        record for record in records if record.get("status") in {"complete", "failed"}
    ]
    if not terminal:
        raise ProtocolError("Workbench trace contains no terminal node events.")
    raw_trace_ids = {
        record.get("trace_id")
        for record in records
        if isinstance(record.get("trace_id"), str)
    }
    trace_origin = "native" if len(raw_trace_ids) == 1 else "synthesized"
    trace_id = next(iter(raw_trace_ids)) if trace_origin == "native" else _trace_id(
        "workbench", project_id, run_id
    )
    if not TRACE_ID_PATTERN.fullmatch(trace_id) or trace_id == "0" * 32:
        trace_id = _trace_id("workbench-replaced", project_id, run_id)
        trace_origin = "synthesized"
    raw_root_ids = {
        record.get("parent_span_id")
        for record in terminal
        if isinstance(record.get("parent_span_id"), str)
    }
    root_span_id = (
        next(iter(raw_root_ids))
        if len(raw_root_ids) == 1
        and SPAN_ID_PATTERN.fullmatch(next(iter(raw_root_ids)))
        else _span_id("workbench-root", project_id, run_id)
    )
    correlation = {
        "project_id": project_id,
        "agent_run_id": run_id,
        "run_id": run_id,
    }
    total_duration = sum(
        float(record.get("elapsed_ms", 0))
        for record in terminal
        if _is_number(record.get("elapsed_ms", 0))
    )
    last = terminal[-1]
    root_status = "error" if any(record["status"] == "failed" for record in terminal) else "ok"
    events = [
        _event(
            event_id=_event_id("workbench-root", source_sha256, run_id),
            event_name="workbench.run.completed",
            signal="span",
            scope="product",
            recorded_at=last["recorded_at"],
            service="elder-workbench",
            operation="workbench.run",
            status=root_status,
            trace_id=trace_id,
            span_id=root_span_id,
            parent_span_id=None,
            trace_origin=trace_origin,
            correlation=correlation,
            attributes={
                "node_count": len(terminal),
                "trace_id_origin": trace_origin,
            },
            measurements=[
                {
                    "name": "workbench.run.duration",
                    "value": total_duration,
                    "unit": "ms",
                    "kind": "histogram",
                    "dimensions": {"service": "elder-workbench"},
                }
            ],
            cost=None,
            outcome=None,
            source_kind="workbench",
            source_path=path.resolve(),
            source_sha256=source_sha256,
        )
    ]
    for index, record in enumerate(terminal, start=1):
        node_id = record.get("node_id")
        if not isinstance(node_id, str) or not node_id:
            raise ProtocolError("Workbench terminal event is missing node_id.")
        span_id = record.get("span_id")
        if (
            not isinstance(span_id, str)
            or not SPAN_ID_PATTERN.fullmatch(span_id)
            or span_id == "0" * 16
        ):
            span_id = _span_id("workbench-node", project_id, run_id, node_id, index)
        elapsed = record.get("elapsed_ms", 0)
        if not _is_number(elapsed) or elapsed < 0:
            raise ProtocolError(f"Workbench node '{node_id}' elapsed_ms is invalid.")
        scope = "model" if node_id == "wayfinder" else "product"
        attributes: dict[str, Any] = {
            "node_id": node_id,
            "label": str(record.get("label", node_id)),
            "sequence": int(record.get("sequence", index)),
        }
        if "error_type" in record:
            attributes["error_type"] = str(record["error_type"])
        events.append(
            _event(
                event_id=_event_id(
                    "workbench-node", source_sha256, run_id, node_id, index
                ),
                event_name=(
                    "gen_ai.agent.operation"
                    if scope == "model"
                    else "workbench.node.operation"
                ),
                signal="span",
                scope=scope,
                recorded_at=record["recorded_at"],
                service="elder-workbench",
                operation=node_id,
                status="ok" if record["status"] == "complete" else "error",
                trace_id=trace_id,
                span_id=span_id,
                parent_span_id=root_span_id,
                trace_origin=trace_origin,
                correlation=correlation,
                attributes=attributes,
                measurements=[
                    {
                        "name": "workbench.node.duration",
                        "value": float(elapsed),
                        "unit": "ms",
                        "kind": "histogram",
                        "dimensions": {
                            "service": "elder-workbench",
                            "operation": node_id,
                            "scope": scope,
                        },
                    }
                ],
                cost=None,
                outcome=None,
                source_kind="workbench",
                source_path=path.resolve(),
                source_sha256=source_sha256,
            )
        )
    for event in events:
        validate_telemetry_event(event, contract)
    return events


def ingest_factory_trace(
    path: Path,
    contract: dict[str, Any],
    *,
    project_id: str = "elder-protocol",
) -> list[dict[str, Any]]:
    records = _read_jsonl(path.resolve())
    source_sha256 = sha256_file(path.resolve())
    events: list[dict[str, Any]] = []
    for index, record in enumerate(records, start=1):
        event_name = record.get("event")
        if not isinstance(event_name, str) or not event_name:
            raise ProtocolError("Factory trace event is missing event.")
        run_id = next(
            (
                str(record[field])
                for field in [
                    "build_id",
                    "work_item",
                    "artifact_sha256",
                    "environment",
                ]
                if isinstance(record.get(field), str) and record[field]
            ),
            f"factory-log-{source_sha256[:12]}",
        )
        trace_id = _trace_id("factory", project_id, run_id)
        span_id = _span_id("factory", source_sha256, index, event_name, run_id)
        status = "error" if record.get("status") == "failed" else "ok"
        attributes = {
            key.replace("-", "_"): value
            for key, value in record.items()
            if key
            not in {
                "recorded_at",
                "event",
                "status",
            }
            and isinstance(value, (str, int, float, bool))
            and not _contains_sensitive_name(key, contract)
        }
        correlation = {"project_id": project_id, "run_id": run_id}
        if isinstance(record.get("work_item"), str):
            correlation["work_item_id"] = record["work_item"]
        if isinstance(record.get("artifact_sha256"), str):
            correlation["artifact_digest"] = record["artifact_sha256"]
        if isinstance(record.get("environment"), str):
            correlation["deployment_id"] = record["environment"]
        measurements = []
        if _is_number(record.get("returncode")):
            measurements.append(
                {
                    "name": "factory.command.returncode",
                    "value": float(record["returncode"]),
                    "unit": "1",
                    "kind": "gauge",
                    "dimensions": {"event": event_name},
                }
            )
        normalized = _event(
            event_id=_event_id("factory", source_sha256, index, record),
            event_name=f"factory.{event_name.replace('-', '.')}",
            signal="event",
            scope="factory",
            recorded_at=record["recorded_at"],
            service="elder-factory",
            operation=event_name,
            status=status,
            trace_id=trace_id,
            span_id=span_id,
            parent_span_id=None,
            trace_origin="synthesized",
            correlation=correlation,
            attributes=attributes,
            measurements=measurements,
            cost=None,
            outcome=None,
            source_kind="factory",
            source_path=path.resolve(),
            source_sha256=source_sha256,
        )
        validate_telemetry_event(normalized, contract)
        events.append(normalized)
    return events


def ingest_evaluation_report(
    path: Path,
    contract: dict[str, Any],
    *,
    project_id: str = "elder-protocol",
) -> list[dict[str, Any]]:
    report = load_json(path.resolve())
    source_sha256 = sha256_file(path.resolve())
    required = {
        "evaluation_id",
        "candidate_id",
        "evaluator_id",
        "executor_id",
        "verdict",
        "metrics",
        "evaluated_at",
    }
    missing = required - set(report)
    if missing:
        raise ProtocolError(
            f"Evaluation telemetry source is missing: {sorted(missing)}"
        )
    metrics = report["metrics"]
    for field in [
        "pass_rate",
        "mean_score",
        "mean_latency_ms",
        "total_cost_usd",
        "total_tool_calls",
    ]:
        if not isinstance(metrics, dict) or not _is_number(metrics.get(field)):
            raise ProtocolError(f"Evaluation telemetry metric '{field}' is invalid.")
    evaluation_id = report["evaluation_id"]
    candidate_id = report["candidate_id"]
    run_id = candidate_id
    trace_id = _trace_id("evaluation", project_id, evaluation_id, candidate_id)
    root_span_id = _span_id("evaluation-root", evaluation_id, candidate_id)
    correlation = {
        "project_id": project_id,
        "run_id": run_id,
        "evaluation_id": evaluation_id,
        "outcome_id": f"{evaluation_id}-quality",
    }
    outcome_status = (
        "met"
        if report["verdict"] == "pass"
        else "unknown"
        if report["verdict"] == "needs-review"
        else "missed"
    )
    common = {
        "recorded_at": report["evaluated_at"],
        "service": "elder-evaluation",
        "trace_id": trace_id,
        "trace_origin": "synthesized",
        "correlation": correlation,
        "source_kind": "evaluation",
        "source_path": path.resolve(),
        "source_sha256": source_sha256,
    }
    events = [
        _event(
            event_id=_event_id("evaluation-outcome", source_sha256, evaluation_id),
            event_name="evaluation.outcome",
            signal="event",
            scope="outcome",
            operation="evaluation",
            status="ok" if report["verdict"] == "pass" else "error",
            span_id=root_span_id,
            parent_span_id=None,
            attributes={
                "dataset_id": str(report.get("dataset_id", "unknown")),
                "split": str(report.get("split", "unknown")),
                "verdict": str(report["verdict"]),
                "evaluator_id": str(report["evaluator_id"]),
                "executor_id": str(report["executor_id"]),
            },
            measurements=[
                {
                    "name": "evaluation.pass.rate",
                    "value": float(metrics["pass_rate"]),
                    "unit": "1",
                    "kind": "gauge",
                    "dimensions": {
                        "dataset": str(report.get("dataset_id", "unknown")),
                        "split": str(report.get("split", "unknown")),
                    },
                },
                {
                    "name": "evaluation.mean.score",
                    "value": float(metrics["mean_score"]),
                    "unit": "1",
                    "kind": "gauge",
                    "dimensions": {
                        "dataset": str(report.get("dataset_id", "unknown")),
                        "split": str(report.get("split", "unknown")),
                    },
                },
            ],
            cost=None,
            outcome={
                "status": outcome_status,
                "metric": "evaluation.pass_rate",
                "baseline": None,
                "observed": float(metrics["pass_rate"]),
                "target": float(report.get("thresholds", {}).get("minimum_pass_rate", 1)),
                "direction": "higher-is-better",
            },
            **common,
        ),
        _event(
            event_id=_event_id("evaluation-cost", source_sha256, evaluation_id),
            event_name="evaluation.cost",
            signal="measurement",
            scope="cost",
            operation="evaluation.cost",
            status="ok",
            span_id=_span_id("evaluation-cost", evaluation_id),
            parent_span_id=root_span_id,
            attributes={"estimate": False},
            measurements=[
                {
                    "name": "evaluation.total.cost",
                    "value": float(metrics["total_cost_usd"]),
                    "unit": "USD",
                    "kind": "counter",
                    "dimensions": {
                        "dataset": str(report.get("dataset_id", "unknown")),
                        "split": str(report.get("split", "unknown")),
                    },
                }
            ],
            cost={
                "currency": "USD",
                "amount_usd": float(metrics["total_cost_usd"]),
                "input_tokens": 0,
                "output_tokens": 0,
                "cached_tokens": 0,
                "tool_calls": float(metrics["total_tool_calls"]),
                "compute_ms": float(metrics["mean_latency_ms"]),
                "estimate": False,
            },
            outcome=None,
            **common,
        ),
        _event(
            event_id=_event_id("evaluation-tools", source_sha256, evaluation_id),
            event_name="evaluation.tool.usage",
            signal="measurement",
            scope="tool",
            operation="evaluation.tools",
            status="ok",
            span_id=_span_id("evaluation-tools", evaluation_id),
            parent_span_id=root_span_id,
            attributes={},
            measurements=[
                {
                    "name": "evaluation.tool.calls",
                    "value": float(metrics["total_tool_calls"]),
                    "unit": "1",
                    "kind": "counter",
                    "dimensions": {
                        "dataset": str(report.get("dataset_id", "unknown")),
                        "split": str(report.get("split", "unknown")),
                    },
                }
            ],
            cost=None,
            outcome=None,
            **common,
        ),
    ]
    for event in events:
        validate_telemetry_event(event, contract)
    return events


def ingest_telemetry(
    source_kind: str,
    input_path: Path,
    contract: dict[str, Any],
    *,
    project_id: str,
) -> list[dict[str, Any]]:
    if source_kind == "workbench":
        return ingest_workbench_trace(
            input_path, contract, project_id=project_id
        )
    if source_kind == "factory":
        return ingest_factory_trace(input_path, contract, project_id=project_id)
    if source_kind == "evaluation":
        return ingest_evaluation_report(
            input_path, contract, project_id=project_id
        )
    raise ProtocolError(
        "Telemetry source kind must be workbench, factory, or evaluation."
    )


def write_telemetry_events(
    path: Path,
    events: Iterable[dict[str, Any]],
    contract: dict[str, Any],
) -> None:
    materialized = list(events)
    if not materialized:
        raise ProtocolError("Cannot write an empty telemetry event set.")
    event_ids: set[str] = set()
    lines: list[str] = []
    for event in materialized:
        validate_telemetry_event(event, contract)
        if event["event_id"] in event_ids:
            raise ProtocolError(f"Duplicate telemetry event id: {event['event_id']}")
        event_ids.add(event["event_id"])
        lines.append(json.dumps(event, sort_keys=True))
    write_text(path.resolve(), "\n".join(lines) + "\n")


def load_telemetry_events(
    path: Path,
    contract: dict[str, Any],
) -> list[dict[str, Any]]:
    events = _read_jsonl(path.resolve())
    seen: set[str] = set()
    for event in events:
        validate_telemetry_event(event, contract)
        if event["event_id"] in seen:
            raise ProtocolError(f"Duplicate telemetry event id: {event['event_id']}")
        seen.add(event["event_id"])
    return events


def _percentile(values: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    rank = max(1, math.ceil(percentile * len(ordered)))
    return ordered[rank - 1]


def _rounded(value: float) -> float:
    return round(value, 12)


def build_telemetry_report(
    events: list[dict[str, Any]],
    contract: dict[str, Any],
) -> dict[str, Any]:
    validate_telemetry_contract(contract)
    if not events:
        raise ProtocolError("Telemetry report requires at least one event.")
    seen: set[str] = set()
    for event in events:
        validate_telemetry_event(event, contract)
        if event["event_id"] in seen:
            raise ProtocolError(f"Duplicate telemetry event id: {event['event_id']}")
        seen.add(event["event_id"])

    scope_counts = {scope: 0 for scope in sorted(SCOPES)}
    status_counts = {status: 0 for status in sorted(STATUSES)}
    durations: list[float] = []
    total_cost = 0.0
    total_tool_calls = 0.0
    total_input_tokens = 0.0
    total_output_tokens = 0.0
    total_cached_tokens = 0.0
    outcome_counts = {"met": 0, "missed": 0, "unknown": 0}
    complete_correlations = 0
    metric_series: dict[str, set[tuple[tuple[str, Any], ...]]] = {}
    for event in events:
        scope_counts[event["scope"]] += 1
        status_counts[event["status"]] += 1
        if event["correlation"].get("project_id") and event["correlation"].get(
            "run_id"
        ):
            complete_correlations += 1
        for measurement in event["measurements"]:
            if measurement["name"].endswith(".duration"):
                durations.append(float(measurement["value"]))
            dimensions = tuple(sorted(measurement["dimensions"].items()))
            metric_series.setdefault(measurement["name"], set()).add(dimensions)
        if event["cost"] is not None:
            total_cost += float(event["cost"]["amount_usd"])
            total_tool_calls += float(event["cost"]["tool_calls"])
            total_input_tokens += float(event["cost"]["input_tokens"])
            total_output_tokens += float(event["cost"]["output_tokens"])
            total_cached_tokens += float(event["cost"]["cached_tokens"])
        if event["outcome"] is not None:
            outcome_counts[event["outcome"]["status"]] += 1

    cardinality_limit = contract["metric_policy"]["maximum_cardinality_per_metric"]
    overflows = sorted(
        name for name, series in metric_series.items() if len(series) > cardinality_limit
    )
    event_count = len(events)
    error_rate = status_counts["error"] / event_count
    correlation_completeness = complete_correlations / event_count
    p95_latency = _percentile(durations, 0.95)
    budgets = contract["budgets"]
    checks = [
        {
            "id": "total-cost",
            "actual": _rounded(total_cost),
            "limit": budgets["maximum_total_cost_usd"],
            "passed": total_cost <= budgets["maximum_total_cost_usd"],
        },
        {
            "id": "error-rate",
            "actual": _rounded(error_rate),
            "limit": budgets["maximum_error_rate"],
            "passed": error_rate <= budgets["maximum_error_rate"],
        },
        {
            "id": "p95-latency",
            "actual": _rounded(p95_latency),
            "limit": budgets["maximum_p95_latency_ms"],
            "passed": p95_latency <= budgets["maximum_p95_latency_ms"],
        },
        {
            "id": "correlation-completeness",
            "actual": _rounded(correlation_completeness),
            "limit": budgets["minimum_correlation_completeness"],
            "passed": correlation_completeness
            >= budgets["minimum_correlation_completeness"],
        },
        {
            "id": "metric-cardinality",
            "actual": len(overflows),
            "limit": 0,
            "passed": not overflows,
        },
    ]
    verdict = "pass" if all(check["passed"] for check in checks) else "fail"
    trace_ids = sorted({event["trace"]["trace_id"] for event in events})
    run_ids = sorted({event["correlation"]["run_id"] for event in events})
    return {
        "version": PROTOCOL_VERSION,
        "report_id": f"telemetry-{_stable_id('report', sorted(seen), length=24)}",
        "contract_id": contract["id"],
        "authority": contract["authority"]["mode"],
        "can_approve": False,
        "can_promote": False,
        "verdict": verdict,
        "event_count": event_count,
        "trace_count": len(trace_ids),
        "run_count": len(run_ids),
        "scope_counts": scope_counts,
        "status_counts": status_counts,
        "correlation_completeness": _rounded(correlation_completeness),
        "latency_ms": {
            "count": len(durations),
            "p50": _rounded(_percentile(durations, 0.50)),
            "p95": _rounded(p95_latency),
            "maximum": _rounded(max(durations, default=0.0)),
        },
        "cost": {
            "currency": "USD",
            "total_amount": _rounded(total_cost),
            "input_tokens": _rounded(total_input_tokens),
            "output_tokens": _rounded(total_output_tokens),
            "cached_tokens": _rounded(total_cached_tokens),
            "tool_calls": _rounded(total_tool_calls),
        },
        "outcomes": outcome_counts,
        "metric_cardinality": {
            "limit": cardinality_limit,
            "series_by_metric": {
                name: len(series) for name, series in sorted(metric_series.items())
            },
            "overflow_metrics": overflows,
        },
        "budget_checks": checks,
    }


def write_telemetry_report(path: Path, report: dict[str, Any]) -> None:
    write_text(path.resolve(), json_text(report))
