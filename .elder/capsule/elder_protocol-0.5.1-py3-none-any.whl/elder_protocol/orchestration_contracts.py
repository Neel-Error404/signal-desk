from __future__ import annotations

import hashlib
import json
import math
from datetime import UTC, datetime
from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.schema_validation import validate_against_schema


BUDGET_FIELDS = (
    "token_limit",
    "cost_limit_usd",
    "tool_call_limit",
    "elapsed_seconds_limit",
)


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True)


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _parse_datetime(value: Any, label: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ProtocolError(f"{label} must be an ISO-8601 date-time.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO-8601 date-time.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


def _require_exact_fields(
    value: Any,
    required: set[str],
    label: str,
) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProtocolError(f"{label} must be a JSON object.")
    if set(value) != required:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(required)}")
    return value


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value.strip()


def _require_string_list(
    value: Any,
    label: str,
    *,
    allow_empty: bool = False,
) -> list[str]:
    if (
        not isinstance(value, list)
        or any(not isinstance(item, str) or not item.strip() for item in value)
        or len(value) != len(set(value))
    ):
        raise ProtocolError(f"{label} must be a unique list of non-empty strings.")
    if not allow_empty and not value:
        raise ProtocolError(f"{label} must not be empty.")
    return value


def _zero_budget() -> dict[str, int | float]:
    return {
        "token_limit": 0,
        "cost_limit_usd": 0.0,
        "tool_call_limit": 0,
        "elapsed_seconds_limit": 0,
    }


def _validate_budget(value: Any, label: str) -> dict[str, int | float]:
    budget = _require_exact_fields(value, set(BUDGET_FIELDS), label)
    for field in ("token_limit", "tool_call_limit", "elapsed_seconds_limit"):
        if (
            not isinstance(budget[field], int)
            or isinstance(budget[field], bool)
            or budget[field] < 0
        ):
            raise ProtocolError(f"{label}.{field} must be a non-negative integer.")
    if (
        not isinstance(budget["cost_limit_usd"], (int, float))
        or isinstance(budget["cost_limit_usd"], bool)
        or not math.isfinite(float(budget["cost_limit_usd"]))
        or budget["cost_limit_usd"] < 0
    ):
        raise ProtocolError(f"{label}.cost_limit_usd must be finite and non-negative.")
    return budget


def _add_budget(
    left: dict[str, int | float],
    right: dict[str, int | float],
) -> dict[str, int | float]:
    return {field: left[field] + right[field] for field in BUDGET_FIELDS}


def _budget_leq(
    consumed: dict[str, int | float],
    limit: dict[str, int | float],
) -> bool:
    return all(consumed[field] <= limit[field] for field in BUDGET_FIELDS)


def validate_runtime_policy(policy: dict[str, Any]) -> dict[str, Any]:
    validate_against_schema(
        policy,
        "multi-agent-runtime-policy.schema.json",
        label="Multi-agent runtime policy",
    )
    _require_exact_fields(
        policy,
        {
            "version",
            "id",
            "store",
            "dispatch",
            "sequencing",
            "enforcement",
            "replay",
            "authority",
        },
        "Multi-agent runtime policy",
    )
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Multi-agent runtime policy version must be '{PROTOCOL_VERSION}'."
        )
    if policy["id"] != "local-bounded-multi-agent-runtime":
        raise ProtocolError("Multi-agent runtime policy id is invalid.")
    store = _require_exact_fields(
        policy["store"],
        {
            "adapter",
            "journal_mode",
            "synchronous",
            "foreign_keys",
            "authority",
            "append_only_records",
        },
        "Multi-agent runtime store policy",
    )
    if store != {
        "adapter": "sqlite",
        "journal_mode": "WAL",
        "synchronous": "FULL",
        "foreign_keys": True,
        "authority": "local-reference-only",
        "append_only_records": [
            "actions",
            "messages",
            "checkpoints",
            "cancellations",
            "escalations",
            "runtime-events",
        ],
    }:
        raise ProtocolError("Multi-agent runtime store policy is not fail-closed.")
    dispatch = _require_exact_fields(
        policy["dispatch"],
        {
            "claim_mode",
            "maximum_lease_seconds",
            "reclaim_expired_leases",
            "claim_order",
        },
        "Multi-agent runtime dispatch policy",
    )
    if (
        dispatch["claim_mode"] != "assigned-identity-only"
        or not isinstance(dispatch["maximum_lease_seconds"], int)
        or dispatch["maximum_lease_seconds"] < 1
        or dispatch["reclaim_expired_leases"] is not True
        or dispatch["claim_order"] != ["submitted_at", "delegation_id"]
    ):
        raise ProtocolError("Multi-agent runtime dispatch policy is invalid.")
    if policy["sequencing"] != {
        "actions": "contiguous-per-child-run",
        "messages": "contiguous-per-child-run",
        "checkpoints": "contiguous-digest-chain",
        "runtime_events": "global-contiguous-digest-chain",
    }:
        raise ProtocolError("Multi-agent runtime sequencing policy is invalid.")
    if policy["enforcement"] != {
        "validate_project_authority_on_submit": True,
        "bind_context_packet_on_submit": True,
        "bind_repository_source_content": True,
        "enforce_child_lease": True,
        "enforce_full_lease_interval": True,
        "enforce_operation_authority_grants": True,
        "enforce_parent_lifecycle": True,
        "enforce_checkpoint_frequency": True,
        "aggregate_parent_budget": True,
        "propagate_cancellation": True,
        "fail_closed_on_expiry": True,
        "verify_journal_row_digests": True,
        "bind_complete_lease_transitions": True,
        "bind_cancellation_and_escalation_journals": True,
        "transactional_consistent_reads": True,
    }:
        raise ProtocolError("Multi-agent runtime enforcement policy is incomplete.")
    if policy["replay"] != {
        "mode": "deterministic-state-reconstruction",
        "verify_event_hash_chain": True,
        "verify_checkpoint_hash_chain": True,
        "verify_append_only_sequences": True,
        "counterfactual_execution": False,
    }:
        raise ProtocolError("Multi-agent runtime replay policy is invalid.")
    if policy["authority"] != {
        "messages_mutate_governed_state": False,
        "checkpoints_mutate_governed_state": False,
        "can_approve": False,
        "can_promote": False,
        "external_identity_authenticated": False,
    }:
        raise ProtocolError("Multi-agent runtime authority must remain local and bounded.")
    return policy


def validate_agent_action(action: dict[str, Any]) -> dict[str, Any]:
    validate_against_schema(
        action,
        "agent-action.schema.json",
        label="Agent action",
    )
    _require_exact_fields(
        action,
        {
            "version",
            "id",
            "project_id",
            "delegation_id",
            "run_id",
            "sequence",
            "resource",
            "action",
            "tool",
            "status",
            "evidence_refs",
            "budget_consumed",
            "started_at",
            "completed_at",
        },
        "Agent action",
    )
    if action["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Agent action version must be '{PROTOCOL_VERSION}'.")
    for field in (
        "id",
        "project_id",
        "delegation_id",
        "run_id",
        "resource",
        "action",
    ):
        _require_string(action[field], f"Agent action {field}")
    if not isinstance(action["sequence"], int) or action["sequence"] < 1:
        raise ProtocolError("Agent action sequence must be a positive integer.")
    if action["tool"] is not None:
        _require_string(action["tool"], "Agent action tool")
    if action["status"] not in {"completed", "failed"}:
        raise ProtocolError("Agent action status must be completed or failed.")
    _require_string_list(
        action["evidence_refs"],
        "Agent action evidence_refs",
        allow_empty=True,
    )
    _validate_budget(action["budget_consumed"], "Agent action budget_consumed")
    started = _parse_datetime(action["started_at"], "Agent action started_at")
    completed = _parse_datetime(action["completed_at"], "Agent action completed_at")
    if completed < started:
        raise ProtocolError("Agent action completed_at cannot precede started_at.")
    return action


def validate_runtime_lease(lease: dict[str, Any]) -> dict[str, Any]:
    validate_against_schema(
        lease,
        "runtime-lease.schema.json",
        label="Runtime lease",
    )
    _require_exact_fields(
        lease,
        {
            "version",
            "id",
            "project_id",
            "delegation_id",
            "run_id",
            "identity_id",
            "claimed_at",
            "expires_at",
            "released_at",
            "status",
            "token_sha256",
            "content_sha256",
        },
        "Runtime lease",
    )
    if lease["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Runtime lease version must be '{PROTOCOL_VERSION}'.")
    for field in (
        "id",
        "project_id",
        "delegation_id",
        "run_id",
        "identity_id",
    ):
        _require_string(lease[field], f"Runtime lease {field}")
    claimed_at = _parse_datetime(lease["claimed_at"], "Runtime lease claimed_at")
    expires_at = _parse_datetime(lease["expires_at"], "Runtime lease expires_at")
    if expires_at <= claimed_at:
        raise ProtocolError("Runtime lease expires_at must follow claimed_at.")
    if lease["status"] not in {"active", "released", "expired", "cancelled"}:
        raise ProtocolError("Runtime lease status is invalid.")
    released_at = lease["released_at"]
    if lease["status"] == "active":
        if released_at is not None:
            raise ProtocolError("An active runtime lease cannot have released_at.")
    else:
        released_time = _parse_datetime(released_at, "Runtime lease released_at")
        if released_time < claimed_at:
            raise ProtocolError(
                "Runtime lease released_at cannot precede claimed_at."
            )
    token_sha256 = lease["token_sha256"]
    if (
        not isinstance(token_sha256, str)
        or len(token_sha256) != 64
        or any(character not in "0123456789abcdef" for character in token_sha256)
    ):
        raise ProtocolError("Runtime lease token_sha256 must be lowercase SHA-256.")
    expected_digest = _sha256(
        {key: value for key, value in lease.items() if key != "content_sha256"}
    )
    if lease["content_sha256"] != expected_digest:
        raise ProtocolError("Runtime lease content_sha256 does not match its content.")
    return lease


def validate_cancellation(cancellation: dict[str, Any]) -> dict[str, Any]:
    validate_against_schema(
        cancellation,
        "cancellation.schema.json",
        label="Cancellation",
    )
    _require_exact_fields(
        cancellation,
        {
            "version",
            "id",
            "project_id",
            "subject_type",
            "subject_id",
            "requested_by",
            "reason",
            "propagate_to_active_children",
            "requested_at",
            "status",
        },
        "Cancellation",
    )
    if cancellation["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Cancellation version must be '{PROTOCOL_VERSION}'.")
    for field in ("id", "project_id", "subject_id", "requested_by", "reason"):
        _require_string(cancellation[field], f"Cancellation {field}")
    if cancellation["subject_type"] not in {"delegation", "agent-run"}:
        raise ProtocolError("Cancellation subject_type is invalid.")
    if cancellation["propagate_to_active_children"] is not True:
        raise ProtocolError("Cancellation must propagate to active children.")
    _parse_datetime(cancellation["requested_at"], "Cancellation requested_at")
    if cancellation["status"] != "requested":
        raise ProtocolError("New cancellation records must start as requested.")
    return cancellation


def validate_escalation(escalation: dict[str, Any]) -> dict[str, Any]:
    validate_against_schema(
        escalation,
        "escalation.schema.json",
        label="Escalation",
    )
    _require_exact_fields(
        escalation,
        {
            "version",
            "id",
            "project_id",
            "delegation_id",
            "run_id",
            "raised_by",
            "owner_role",
            "reason",
            "evidence_refs",
            "raised_at",
            "status",
        },
        "Escalation",
    )
    if escalation["version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Escalation version must be '{PROTOCOL_VERSION}'.")
    for field in (
        "id",
        "project_id",
        "delegation_id",
        "run_id",
        "raised_by",
        "owner_role",
        "reason",
    ):
        _require_string(escalation[field], f"Escalation {field}")
    _require_string_list(
        escalation["evidence_refs"],
        "Escalation evidence_refs",
    )
    _parse_datetime(escalation["raised_at"], "Escalation raised_at")
    if escalation["status"] != "open":
        raise ProtocolError("New escalations must start as open.")
    return escalation
