from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError, ValidationError
from referencing import Registry, Resource

from elder_protocol.constants import PROTOCOL_DIR
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json


@lru_cache(maxsize=4)
def _schema_catalog(
    schema_root_text: str,
) -> tuple[dict[str, dict[str, Any]], Registry]:
    schema_root = Path(schema_root_text)
    schemas = {
        path.name: load_json(path)
        for path in sorted(schema_root.glob("*.schema.json"))
    }
    registry = Registry().with_resources(
        (
            schema["$id"],
            Resource.from_contents(schema),
        )
        for schema in schemas.values()
    )
    return schemas, registry


def validate_schema_catalog(
    schema_root: Path = PROTOCOL_DIR,
) -> dict[str, dict[str, Any]]:
    schemas, _ = _schema_catalog(str(schema_root.resolve()))
    for name, schema in schemas.items():
        try:
            Draft202012Validator.check_schema(schema)
        except SchemaError as exc:
            raise ProtocolError(
                f"Invalid JSON Schema '{name}': {exc.message}"
            ) from exc
    return schemas


def validate_against_schema(
    instance: Any,
    schema_name: str,
    *,
    label: str,
    schema_root: Path = PROTOCOL_DIR,
) -> Any:
    try:
        serialized = json.dumps(
            instance,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise ProtocolError(
            f"{label} must be valid JSON data: {exc}"
        ) from exc
    _validate_serialized(
        serialized,
        schema_name,
        label,
        str(schema_root.resolve()),
    )
    return instance


@lru_cache(maxsize=512)
def _validate_serialized(
    serialized: str,
    schema_name: str,
    label: str,
    schema_root_text: str,
) -> None:
    instance = json.loads(serialized)
    schema_root = Path(schema_root_text)
    schemas, registry = _schema_catalog(str(schema_root.resolve()))
    if schema_name not in schemas:
        raise ProtocolError(f"Unknown JSON Schema: {schema_name}")
    schema = schemas[schema_name]
    try:
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(
            schema,
            registry=registry,
        ).validate(instance)
    except SchemaError as exc:
        raise ProtocolError(
            f"Invalid JSON Schema '{schema_name}': {exc.message}"
        ) from exc
    except ValidationError as exc:
        location = ".".join(str(item) for item in exc.absolute_path)
        suffix = f" at '{location}'" if location else ""
        raise ProtocolError(
            f"{label} does not match {schema_name}{suffix}: {exc.message}"
        ) from exc
