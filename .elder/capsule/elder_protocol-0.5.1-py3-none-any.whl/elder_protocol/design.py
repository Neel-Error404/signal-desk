from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json, sha256_file


DOCUMENT_FIELDS = {
    "id",
    "title",
    "path",
    "kind",
    "status",
    "owners",
    "change_classes",
    "supersedes",
    "notifies",
    "content_sha256",
}


def _string_list(value: Any, label: str, *, allow_empty: bool = False) -> list[str]:
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        raise ProtocolError(f"{label} must be a list of non-empty strings.")
    if not allow_empty and not value:
        raise ProtocolError(f"{label} must not be empty.")
    if len(value) != len(set(value)):
        raise ProtocolError(f"{label} cannot contain duplicates.")
    return value


def validate_design_registry(
    registry_path: Path,
    root: Path,
) -> dict[str, Any]:
    registry_path = registry_path.resolve()
    root = root.resolve()
    registry = load_json(registry_path)
    if set(registry) != {"version", "documents"}:
        raise ProtocolError("Design registry fields must be version and documents.")
    if registry["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Design registry version must be '{PROTOCOL_VERSION}'."
        )
    documents = registry["documents"]
    if not isinstance(documents, list) or not documents:
        raise ProtocolError("Design registry must contain at least one document.")

    ids = [document.get("id") for document in documents]
    if any(not isinstance(document_id, str) or not document_id for document_id in ids):
        raise ProtocolError("Every design document needs a non-empty id.")
    if len(ids) != len(set(ids)):
        raise ProtocolError("Design document ids must be unique.")
    known_ids = set(ids)
    valid_kinds = {"adr", "rfc", "design", "policy"}
    valid_statuses = {
        "proposed",
        "accepted",
        "implemented",
        "superseded",
        "rejected",
    }

    for document in documents:
        document_id = document["id"]
        if set(document) != DOCUMENT_FIELDS:
            raise ProtocolError(
                f"Design document '{document_id}' fields must be exactly: "
                f"{sorted(DOCUMENT_FIELDS)}"
            )
        if document["kind"] not in valid_kinds:
            raise ProtocolError(
                f"Design document '{document_id}' has an invalid kind."
            )
        if document["status"] not in valid_statuses:
            raise ProtocolError(
                f"Design document '{document_id}' has an invalid status."
            )
        _string_list(document["owners"], f"Design document '{document_id}' owners")
        _string_list(
            document["change_classes"],
            f"Design document '{document_id}' change classes",
        )
        supersedes = _string_list(
            document["supersedes"],
            f"Design document '{document_id}' supersedes",
            allow_empty=True,
        )
        _string_list(
            document["notifies"],
            f"Design document '{document_id}' notifications",
        )
        unknown = set(supersedes) - known_ids
        if unknown:
            raise ProtocolError(
                f"Design document '{document_id}' supersedes unknown document(s): "
                f"{sorted(unknown)}"
            )
        target = (root / document["path"]).resolve()
        if not target.is_relative_to(root):
            raise ProtocolError(
                f"Design document '{document_id}' escapes the registry root."
            )
        if not target.is_file():
            raise ProtocolError(
                f"Design document '{document_id}' does not exist: {target}"
            )
        actual_hash = sha256_file(target)
        if actual_hash != document["content_sha256"]:
            raise ProtocolError(
                f"Design document '{document_id}' content hash is stale. "
                f"Expected {document['content_sha256']}, found {actual_hash}."
            )

    return {
        "registry": str(registry_path),
        "document_count": len(documents),
        "by_status": dict(
            sorted(Counter(document["status"] for document in documents).items())
        ),
        "stale": [],
    }
