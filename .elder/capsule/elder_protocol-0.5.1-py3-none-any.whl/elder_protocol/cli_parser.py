from __future__ import annotations

import argparse
from pathlib import Path

from elder_protocol.constants import PROTOCOL_DIR, ROOT, SKILLS_DIR


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="elder", description="Build and validate Elder-governed project foundations."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser(
        "validate", help="Validate the Elder protocol and optionally a project profile."
    )
    validate_parser.add_argument("--profile", type=Path)

    intake_parser = subparsers.add_parser(
        "intake", help="Run Wayfinder intake and write a draft project profile."
    )
    intake_parser.add_argument("--answers", type=Path)
    intake_parser.add_argument("--output", type=Path, required=True)

    migrate_parser = subparsers.add_parser(
        "migrate-profile", help="Migrate a supported older project profile."
    )
    migrate_parser.add_argument("--profile", type=Path, required=True)
    migrate_parser.add_argument("--output", type=Path, required=True)

    ratify_parser = subparsers.add_parser(
        "ratify-profile",
        help="Ratify a valid draft project profile as its bound human owner.",
    )
    ratify_parser.add_argument("--profile", type=Path, required=True)
    ratify_parser.add_argument("--approved-by", required=True)
    ratify_parser.add_argument("--output", type=Path, required=True)

    compile_parser = subparsers.add_parser(
        "compile", help="Compile a project profile into protected project contracts."
    )
    compile_parser.add_argument("--profile", type=Path, required=True)
    compile_parser.add_argument("--output", type=Path, required=True)
    compile_parser.add_argument("--force", action="store_true")
    compile_parser.add_argument("--dry-run", action="store_true")
    compile_parser.add_argument("--diff", action="store_true")
    compile_parser.add_argument("--no-migrate", action="store_true")

    capsule_parser = subparsers.add_parser(
        "capsule",
        help="Build, verify, install, or inspect a portable per-repository Elder capsule.",
    )
    capsule_subparsers = capsule_parser.add_subparsers(
        dest="capsule_command",
        required=True,
    )
    capsule_build = capsule_subparsers.add_parser(
        "build",
        help="Build a deterministic portable Elder ZIP with a pinned wheel.",
    )
    capsule_build.add_argument("--output", type=Path, required=True)
    capsule_build.add_argument("--source-root", type=Path, default=ROOT)
    capsule_verify = capsule_subparsers.add_parser(
        "verify",
        help="Verify a portable Elder ZIP and its payload digests.",
    )
    capsule_verify.add_argument("--archive", type=Path, required=True)
    capsule_install = capsule_subparsers.add_parser(
        "install",
        help="Install or update a verified Elder capsule in one product repository.",
    )
    capsule_install.add_argument("--archive", type=Path, required=True)
    capsule_install.add_argument("--project-root", type=Path, default=Path.cwd())
    capsule_install.add_argument("--force", action="store_true")
    capsule_status = capsule_subparsers.add_parser(
        "status",
        help="Verify the capsule currently installed in a product repository.",
    )
    capsule_status.add_argument("--project-root", type=Path, default=Path.cwd())

    session_parser = subparsers.add_parser(
        "session", help="Activate a bounded Elder coding-agent session."
    )
    session_subparsers = session_parser.add_subparsers(
        dest="session_command", required=True
    )
    session_activate = session_subparsers.add_parser(
        "activate",
        help="Validate project instructions and emit a digest-bound activation packet.",
    )
    session_activate.add_argument("--project-root", type=Path, default=Path.cwd())
    session_activate.add_argument("--task", required=True)
    session_activate.add_argument("--output", type=Path)
    session_activate.add_argument("--env-file", type=Path)
    session_activate.add_argument(
        "--memory-live",
        action="store_true",
        help="Synchronize and recall trusted build memory through Mem0.",
    )
    session_close = session_subparsers.add_parser(
        "close",
        help="Extract governed build-memory candidates from completed-work evidence.",
    )
    session_close.add_argument("--project-root", type=Path, default=Path.cwd())
    session_close.add_argument("--activation", type=Path, required=True)
    session_close.add_argument(
        "--evidence",
        action="append",
        required=True,
        metavar="KIND=PATH",
    )
    session_close.add_argument("--env-file", type=Path)
    session_close.add_argument("--output", type=Path)

    dreaming_parser = subparsers.add_parser(
        "dreaming", help="Run governed Mem0 and Luna repository dreaming."
    )
    dreaming_subparsers = dreaming_parser.add_subparsers(
        dest="dreaming_command", required=True
    )
    dreaming_readiness = dreaming_subparsers.add_parser(
        "readiness",
        help="Report Mem0, Qdrant, Azure, and Luna readiness.",
    )
    dreaming_readiness.add_argument("--project-root", type=Path, default=Path.cwd())
    dreaming_readiness.add_argument("--env-file", type=Path)
    dreaming_readiness.add_argument("--live", action="store_true")
    dreaming_prepare = dreaming_subparsers.add_parser(
        "prepare",
        help="Create an evidence-only Mem0 and Luna candidate workspace.",
    )
    dreaming_prepare.add_argument("--project-root", type=Path, default=Path.cwd())
    dreaming_prepare.add_argument("--activation", type=Path, required=True)
    dreaming_prepare.add_argument("--work-item-id", required=True)
    dreaming_prepare.add_argument("--trigger", required=True)
    dreaming_prepare.add_argument(
        "--evidence",
        action="append",
        required=True,
        metavar="KIND=PATH",
    )
    dreaming_prepare.add_argument("--workspace", type=Path, required=True)
    dreaming_run = dreaming_subparsers.add_parser(
        "run",
        help="Extract candidate memories with Mem0 and generate one Luna candidate.",
    )
    dreaming_run.add_argument("--project-root", type=Path, default=Path.cwd())
    dreaming_run.add_argument("--workspace", type=Path, required=True)
    dreaming_run.add_argument(
        "--mode",
        choices=["routine", "escalation"],
        default="routine",
    )
    dreaming_run.add_argument("--env-file", type=Path)
    dreaming_accept = dreaming_subparsers.add_parser(
        "accept",
        help="Validate a Mem0 and Luna generated Elder learning candidate.",
    )
    dreaming_accept.add_argument("--workspace", type=Path, required=True)
    dreaming_accept.add_argument("--candidate", type=Path, required=True)
    dreaming_accept.add_argument("--output", type=Path, required=True)

    skills_parser = subparsers.add_parser("skills", help="Manage Elder repo-local skills.")
    skills_subparsers = skills_parser.add_subparsers(
        dest="skills_command", required=True
    )
    skills_subparsers.add_parser("validate", help="Validate skill files and registry.")

    route_parser = skills_subparsers.add_parser(
        "route", help="Rank skills for a task."
    )
    route_parser.add_argument("--task", required=True)
    route_parser.add_argument("--packs", default="")
    route_parser.add_argument("--limit", type=int, default=5)

    create_parser = skills_subparsers.add_parser(
        "create", help="Create and register a concise skill."
    )
    create_parser.add_argument("--name", required=True)
    create_parser.add_argument("--description", required=True)
    create_parser.add_argument("--capabilities", required=True)
    create_parser.add_argument("--triggers", required=True)
    create_parser.add_argument("--requires", default="")
    create_parser.add_argument("--packs", required=True)
    create_parser.add_argument("--priority", type=int, default=5)
    create_parser.add_argument("--skills-root", type=Path, default=SKILLS_DIR)
    create_parser.add_argument(
        "--registry",
        type=Path,
        default=PROTOCOL_DIR / "skill-registry.json",
    )

    subparsers.add_parser(
        "ontology", help="Validate the ontology and relationship contract."
    )

    graph_parser = subparsers.add_parser(
        "graph", help="Validate and emit the canonical Elder protocol graph."
    )
    graph_parser.add_argument("--output", type=Path)

    subparsers.add_parser(
        "assurance",
        help="Report evidence-bound P4 assurance coverage and factory maturity.",
    )

    design_parser = subparsers.add_parser(
        "design",
        help="Validate governed design-document registry state.",
    )
    design_subparsers = design_parser.add_subparsers(
        dest="design_command",
        required=True,
    )
    design_validate = design_subparsers.add_parser(
        "validate",
        help="Validate registered document metadata and content hashes.",
    )
    design_validate.add_argument(
        "--registry",
        type=Path,
        default=PROTOCOL_DIR / "design-registry.json",
    )
    design_validate.add_argument("--root", type=Path, default=ROOT)

    architecture_parser = subparsers.add_parser(
        "architecture",
        help="Run executable architecture-boundary adapters.",
    )
    architecture_subparsers = architecture_parser.add_subparsers(
        dest="architecture_command",
        required=True,
    )
    architecture_check = architecture_subparsers.add_parser(
        "check",
        help="Check a machine-readable architecture-boundary contract.",
    )
    architecture_check.add_argument("--contract", type=Path, required=True)
    architecture_check.add_argument("--root", type=Path, required=True)

    evaluate_parser = subparsers.add_parser(
        "evaluate",
        help="Run independent P4 assurance evaluators.",
    )
    evaluate_subparsers = evaluate_parser.add_subparsers(
        dest="evaluate_command",
        required=True,
    )
    transcript_parser = evaluate_subparsers.add_parser(
        "transcript",
        help="Review an immutable workflow JSONL transcript.",
    )
    transcript_parser.add_argument("--trace", type=Path, required=True)
    transcript_parser.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "transcript-review-policy.json",
    )
    transcript_parser.add_argument("--evaluator-id", required=True)
    transcript_parser.add_argument("--executor-id", required=True)
    transcript_parser.add_argument("--output", type=Path)

    dataset_parser = evaluate_subparsers.add_parser(
        "dataset",
        help="Validate the governed evaluation dataset registry.",
    )
    dataset_parser.add_argument(
        "--registry",
        type=Path,
        default=PROTOCOL_DIR / "evaluation-registry.json",
    )
    dataset_parser.add_argument("--root", type=Path, default=ROOT)

    calibrate_parser = evaluate_subparsers.add_parser(
        "calibrate",
        help="Calibrate an independent rubric judge against reference labels.",
    )
    calibrate_parser.add_argument(
        "--dataset",
        type=Path,
        default=PROTOCOL_DIR / "evaluation-dataset.json",
    )
    calibrate_parser.add_argument(
        "--contract",
        type=Path,
        default=PROTOCOL_DIR / "evaluator-contract.json",
    )
    calibrate_parser.add_argument("--judge-results", type=Path, required=True)
    calibrate_parser.add_argument("--output", type=Path)

    evaluation_run_parser = evaluate_subparsers.add_parser(
        "run",
        help="Evaluate immutable candidate outputs on a governed dataset split.",
    )
    evaluation_run_parser.add_argument(
        "--dataset",
        type=Path,
        default=PROTOCOL_DIR / "evaluation-dataset.json",
    )
    evaluation_run_parser.add_argument(
        "--contract",
        type=Path,
        default=PROTOCOL_DIR / "evaluator-contract.json",
    )
    evaluation_run_parser.add_argument("--candidate", type=Path, required=True)
    evaluation_run_parser.add_argument(
        "--split",
        choices=["development", "calibration", "holdout"],
        required=True,
    )
    evaluation_run_parser.add_argument("--evaluator-id", required=True)
    evaluation_run_parser.add_argument("--judge-results", type=Path)
    evaluation_run_parser.add_argument("--calibration", type=Path)
    evaluation_run_parser.add_argument("--output", type=Path)

    compare_parser = evaluate_subparsers.add_parser(
        "compare",
        help="Compare paired baseline and candidate evaluation reports.",
    )
    compare_parser.add_argument(
        "--contract",
        type=Path,
        default=PROTOCOL_DIR / "evaluator-contract.json",
    )
    compare_parser.add_argument("--baseline", type=Path, required=True)
    compare_parser.add_argument("--candidate", type=Path, required=True)
    compare_parser.add_argument("--output", type=Path)

    telemetry_parser = subparsers.add_parser(
        "telemetry",
        help="Normalize, validate, correlate, and report P4.3 telemetry.",
    )
    telemetry_subparsers = telemetry_parser.add_subparsers(
        dest="telemetry_command",
        required=True,
    )
    telemetry_validate = telemetry_subparsers.add_parser(
        "validate",
        help="Validate the telemetry contract and an optional JSONL event file.",
    )
    telemetry_validate.add_argument(
        "--contract",
        type=Path,
        default=PROTOCOL_DIR / "telemetry-contract.json",
    )
    telemetry_validate.add_argument("--events", type=Path)
    telemetry_ingest = telemetry_subparsers.add_parser(
        "ingest",
        help="Normalize an existing Workbench, factory, or evaluation source.",
    )
    telemetry_ingest.add_argument(
        "--contract",
        type=Path,
        default=PROTOCOL_DIR / "telemetry-contract.json",
    )
    telemetry_ingest.add_argument(
        "--source-kind",
        choices=["workbench", "factory", "evaluation"],
        required=True,
    )
    telemetry_ingest.add_argument("--input", type=Path, required=True)
    telemetry_ingest.add_argument("--output", type=Path, required=True)
    telemetry_ingest.add_argument("--project-id", required=True)
    telemetry_report = telemetry_subparsers.add_parser(
        "report",
        help="Aggregate correlated telemetry and evaluate local budgets.",
    )
    telemetry_report.add_argument(
        "--contract",
        type=Path,
        default=PROTOCOL_DIR / "telemetry-contract.json",
    )
    telemetry_report.add_argument("--events", type=Path, required=True)
    telemetry_report.add_argument("--output", type=Path)

    knowledge_parser = subparsers.add_parser(
        "knowledge",
        help="Operate the P4.4 persistent local knowledge graph.",
    )
    knowledge_subparsers = knowledge_parser.add_subparsers(
        dest="knowledge_command",
        required=True,
    )
    knowledge_init = knowledge_subparsers.add_parser(
        "init",
        help="Initialize or verify a local knowledge store.",
    )
    knowledge_init.add_argument("--store", type=Path, required=True)
    knowledge_status = knowledge_subparsers.add_parser(
        "status",
        help="Report knowledge-store integrity and record counts.",
    )
    knowledge_status.add_argument("--store", type=Path, required=True)
    knowledge_ingest = knowledge_subparsers.add_parser(
        "ingest",
        help="Transactionally ingest a provenance-bound knowledge graph.",
    )
    knowledge_ingest.add_argument("--store", type=Path, required=True)
    knowledge_ingest.add_argument("--graph", type=Path, required=True)
    knowledge_ingest.add_argument("--subject", default="executor")
    knowledge_query = knowledge_subparsers.add_parser(
        "query",
        help="Query active graph nodes and an optional node neighborhood.",
    )
    knowledge_query.add_argument("--store", type=Path, required=True)
    knowledge_query.add_argument("--query", default="")
    knowledge_query.add_argument("--node-id")
    knowledge_query.add_argument(
        "--authorities",
        default="primary,secondary,historical",
    )
    knowledge_query.add_argument("--statuses", default="active")
    knowledge_query.add_argument("--limit", type=int, default=20)
    knowledge_query.add_argument("--output", type=Path)

    memory_parser = subparsers.add_parser(
        "memory",
        help="Operate governed candidate and trusted memory.",
    )
    memory_subparsers = memory_parser.add_subparsers(
        dest="memory_command",
        required=True,
    )
    memory_propose = memory_subparsers.add_parser(
        "propose",
        help="Append a candidate memory record.",
    )
    memory_propose.add_argument("--store", type=Path, required=True)
    memory_propose.add_argument("--record", type=Path, required=True)
    memory_propose.add_argument(
        "--subject-role",
        choices=["human-owner", "learning-agent", "evaluator"],
        required=True,
    )
    for command, help_text in [
        ("promote", "Promote candidate memory with independent human approval."),
        ("reject", "Reject candidate memory with independent human approval."),
        ("supersede", "Supersede trusted memory with independent human approval."),
        ("revoke", "Revoke trusted memory with independent human approval."),
    ]:
        child = memory_subparsers.add_parser(command, help=help_text)
        child.add_argument("--store", type=Path, required=True)
        child.add_argument("--memory-id", required=True)
        child.add_argument("--approval", type=Path, required=True)
    memory_query = memory_subparsers.add_parser(
        "query",
        help="Query scoped memory; trusted is the default status.",
    )
    memory_query.add_argument("--store", type=Path, required=True)
    memory_query.add_argument("--namespace", required=True)
    memory_query.add_argument("--query", default="")
    memory_query.add_argument("--statuses", default="trusted")
    memory_query.add_argument("--limit", type=int, default=20)
    memory_query.add_argument("--output", type=Path)
    memory_extract = memory_subparsers.add_parser(
        "extract",
        help="Use Mem0 to propose governed candidate memories from immutable evidence.",
    )
    memory_extract.add_argument("--store", type=Path, required=True)
    memory_extract.add_argument("--project-root", type=Path, default=Path.cwd())
    memory_extract.add_argument("--namespace", required=True)
    memory_extract.add_argument(
        "--evidence",
        action="append",
        required=True,
        metavar="KIND=PATH",
    )
    memory_extract.add_argument("--env-file", type=Path)

    context_parser = subparsers.add_parser(
        "context",
        help="Assemble immutable authority-filtered context packets.",
    )
    context_subparsers = context_parser.add_subparsers(
        dest="context_command",
        required=True,
    )
    context_assemble = context_subparsers.add_parser(
        "assemble",
        help="Assemble repository, graph, and trusted-memory context.",
    )
    context_assemble.add_argument("--store", type=Path, required=True)
    context_assemble.add_argument("--request", type=Path, required=True)
    context_assemble.add_argument("--delegation", type=Path)
    context_assemble.add_argument("--parent-run", type=Path)
    context_assemble.add_argument("--authority-bindings", type=Path)
    context_assemble.add_argument("--profile", type=Path)
    context_assemble.add_argument("--output", type=Path, required=True)

    delegation_parser = subparsers.add_parser(
        "delegation",
        help="Validate bounded P4.5A delegation contracts.",
    )
    delegation_subparsers = delegation_parser.add_subparsers(
        dest="delegation_command",
        required=True,
    )
    delegation_validate = delegation_subparsers.add_parser(
        "validate",
        help="Fail closed when a delegation exceeds parent or project authority.",
    )
    delegation_validate.add_argument("--delegation", type=Path, required=True)
    delegation_validate.add_argument("--parent-run", type=Path, required=True)
    delegation_validate.add_argument(
        "--authority-bindings",
        type=Path,
        required=True,
    )
    delegation_validate.add_argument("--profile", type=Path, required=True)
    delegation_validate.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "delegation-policy.json",
    )

    orchestration_parser = subparsers.add_parser(
        "orchestration",
        help="Operate the bounded local P4.5B multi-agent coordinator.",
    )
    orchestration_subparsers = orchestration_parser.add_subparsers(
        dest="orchestration_command",
        required=True,
    )
    for name, help_text in [
        ("init", "Initialize or verify a local orchestration store."),
        ("status", "Report orchestration-store integrity and record counts."),
        ("submit", "Submit one validated parent-delegation-child chain."),
        ("claim", "Lease the next eligible delegation to its assigned identity."),
        ("action", "Append one typed child action under an active lease."),
        ("message", "Append one bound parent-child message."),
        ("checkpoint", "Append one digest-linked child checkpoint."),
        ("cancel", "Request and propagate governed cancellation."),
        ("escalate", "Append an escalation and block the child run."),
        ("release", "Release an active child-run lease."),
        ("snapshot", "Inspect one delegation runtime snapshot and graph."),
        ("replay", "Verify journals and reconstruct one delegation state."),
        ("sweep", "Expire overdue leases and delegations."),
    ]:
        child = orchestration_subparsers.add_parser(name, help=help_text)
        child.add_argument("--store", type=Path, required=True)
        child.add_argument(
            "--policy",
            type=Path,
            default=PROTOCOL_DIR / "multi-agent-runtime-policy.json",
        )
        if name == "submit":
            child.add_argument("--bundle", type=Path, required=True)
            child.add_argument("--context-base-dir", type=Path)
        elif name == "claim":
            child.add_argument("--project-id", required=True)
            child.add_argument("--identity-id", required=True)
            child.add_argument("--lease-seconds", type=int, default=300)
        elif name in {"action", "message", "checkpoint", "cancel", "escalate"}:
            child.add_argument("--record", type=Path, required=True)
            if name in {"action", "checkpoint", "escalate"}:
                child.add_argument("--lease-token", required=True)
            else:
                child.add_argument("--lease-token")
        elif name == "release":
            child.add_argument("--run-id", required=True)
            child.add_argument("--lease-token", required=True)
        elif name in {"snapshot", "replay"}:
            child.add_argument("--delegation-id", required=True)
        elif name == "sweep":
            child.add_argument("--at")

    learning_parser = subparsers.add_parser(
        "learning",
        help="Operate the quarantined local P4.6 learning runtime.",
    )
    learning_subparsers = learning_parser.add_subparsers(
        dest="learning_command",
        required=True,
    )
    learning_normalize = learning_subparsers.add_parser(
        "normalize",
        help="Normalize one bounded, read-only SF-500 learning trajectory.",
    )
    learning_normalize.add_argument("--source", type=Path, required=True)
    learning_normalize.add_argument("--output", type=Path, required=True)
    learning_normalize.add_argument("--max-events", type=int, default=256)
    learning_normalize.add_argument("--max-bytes", type=int, default=262144)
    for name, help_text in [
        ("init", "Initialize or verify a local learning store."),
        ("status", "Report learning-store integrity and record counts."),
        ("propose", "Store one immutable learning candidate artifact."),
        ("observe", "Append a side-effect-free replay or shadow observation."),
        ("evaluate", "Independently evaluate recorded learning observations."),
        ("decide", "Append one accountable approval, rejection, or rollback decision."),
        ("promote", "Emit an immutable promotion packet without target mutation."),
        ("rollback", "Emit an immutable rollback packet without target mutation."),
        ("snapshot", "Inspect one learning candidate and its evidence graph."),
        ("replay", "Verify learning journals and reconstruct candidate state."),
    ]:
        child = learning_subparsers.add_parser(name, help=help_text)
        child.add_argument("--store", type=Path, required=True)
        child.add_argument(
            "--policy",
            type=Path,
            default=PROTOCOL_DIR / "learning-policy.json",
        )
        child.add_argument("--profile", type=Path, required=True)
        if name == "propose":
            child.add_argument("--candidate", type=Path, required=True)
            child.add_argument("--artifact-base", type=Path, required=True)
        elif name == "observe":
            child.add_argument("--record", type=Path, required=True)
        elif name == "evaluate":
            child.add_argument("--candidate-id", required=True)
            child.add_argument("--evaluator-id", required=True)
            child.add_argument("--evaluation-id")
            child.add_argument("--at")
        elif name == "decide":
            child.add_argument("--approval", type=Path, required=True)
        elif name in {"promote", "rollback"}:
            child.add_argument("--candidate-id", required=True)
            child.add_argument("--promoted-by", required=True)
            child.add_argument("--promotion-id")
            child.add_argument("--at")
        elif name in {"snapshot", "replay"}:
            child.add_argument("--candidate-id", required=True)

    qualification_parser = subparsers.add_parser(
        "qualification",
        help="Validate signed hosted evidence against cumulative maturity gates.",
    )
    qualification_subparsers = qualification_parser.add_subparsers(
        dest="qualification_command",
        required=True,
    )
    qualification_validate = qualification_subparsers.add_parser(
        "validate",
        help="Validate qualification policy coverage and authority.",
    )
    qualification_validate.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "qualification-policy.json",
    )
    qualification_validate.add_argument(
        "--maturity",
        type=Path,
        default=PROTOCOL_DIR / "operational-maturity.json",
    )
    qualification_evaluate = qualification_subparsers.add_parser(
        "evaluate",
        help="Evaluate one immutable hosted evidence bundle.",
    )
    qualification_evaluate.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "qualification-policy.json",
    )
    qualification_evaluate.add_argument(
        "--maturity",
        type=Path,
        default=PROTOCOL_DIR / "operational-maturity.json",
    )
    qualification_evaluate.add_argument("--bundle", type=Path, required=True)
    qualification_evaluate.add_argument("--output", type=Path)
    qualification_evaluate.add_argument("--at")
    qualification_institutional_l2 = qualification_subparsers.add_parser(
        "institutional-l2",
        help=(
            "Evaluate the ratified institutional L2 benchmark without "
            "granting authority or mutating maturity."
        ),
    )
    qualification_institutional_l2.add_argument(
        "--packet",
        type=Path,
        required=True,
    )
    qualification_institutional_l2.add_argument(
        "--bundle",
        type=Path,
        required=True,
    )
    qualification_institutional_l2.add_argument("--output", type=Path)
    qualification_institutional_l2.add_argument("--at")
    qualification_issue_l2 = qualification_subparsers.add_parser(
        "issue-github-l2",
        help=(
            "Independently retrieve and verify one GitHub run before issuing "
            "a signed canonical L2 bundle."
        ),
    )
    qualification_issue_l2.add_argument(
        "--repository",
        default="Neel-Error404/elder-protocol",
    )
    qualification_issue_l2.add_argument("--run-id", required=True)
    qualification_issue_l2.add_argument("--run-attempt", default="1")
    qualification_issue_l2.add_argument(
        "--output-dir",
        type=Path,
        required=True,
    )
    qualification_issue_l2.add_argument(
        "--governance-evidence",
        type=Path,
        required=True,
        help=(
            "Signed operator approval, manual replay, and independent review "
            "bound to the hosted commit."
        ),
    )

    autonomy_parser = subparsers.add_parser(
        "autonomy",
        help="Operate P5.1-P5.3 bounded-autonomy gates.",
    )
    autonomy_subparsers = autonomy_parser.add_subparsers(
        dest="autonomy_command",
        required=True,
    )
    autonomy_validate = autonomy_subparsers.add_parser(
        "validate",
        help="Validate bounded-autonomy simulation and supervised-PR contracts.",
    )
    autonomy_validate.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-policy.json",
    )
    autonomy_validate.add_argument(
        "--classes",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-classes.json",
    )
    autonomy_validate.add_argument(
        "--change-classes",
        type=Path,
        default=PROTOCOL_DIR / "change-classes.json",
    )
    autonomy_validate.add_argument(
        "--qualification-policy",
        type=Path,
        default=PROTOCOL_DIR / "qualification-policy.json",
    )
    autonomy_validate.add_argument(
        "--maturity",
        type=Path,
        default=PROTOCOL_DIR / "operational-maturity.json",
    )
    for name, help_text in [
        ("match", "Match one structured work item to its certified autonomy class."),
        ("simulate", "Run a side-effect-free P5.1 work-item simulation."),
    ]:
        child = autonomy_subparsers.add_parser(name, help=help_text)
        child.add_argument(
            "--policy",
            type=Path,
            default=PROTOCOL_DIR / "autonomy-policy.json",
        )
        child.add_argument(
            "--classes",
            type=Path,
            default=PROTOCOL_DIR / "autonomy-classes.json",
        )
        child.add_argument(
            "--change-classes",
            type=Path,
            default=PROTOCOL_DIR / "change-classes.json",
        )
        child.add_argument(
            "--qualification-policy",
            type=Path,
            default=PROTOCOL_DIR / "qualification-policy.json",
        )
        child.add_argument(
            "--maturity",
            type=Path,
            default=PROTOCOL_DIR / "operational-maturity.json",
        )
        child.add_argument("--work-item", type=Path, required=True)
        child.add_argument("--certification", type=Path, required=True)
        child.add_argument("--output", type=Path)
    autonomy_replay = autonomy_subparsers.add_parser(
        "replay",
        help="Replay certification lifecycle and incident accounting deterministically.",
    )
    autonomy_replay.add_argument(
        "--classes",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-classes.json",
    )
    autonomy_replay.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-policy.json",
    )
    autonomy_replay.add_argument("--certification", type=Path, required=True)
    autonomy_replay.add_argument("--events", type=Path, required=True)
    autonomy_replay.add_argument("--at", required=True)
    autonomy_replay.add_argument("--output", type=Path)
    autonomy_readiness = autonomy_subparsers.add_parser(
        "readiness",
        help="Report canonical P5.2 activation blockers without weakening them.",
    )
    autonomy_readiness.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-policy.json",
    )
    autonomy_readiness.add_argument(
        "--classes",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-classes.json",
    )
    autonomy_readiness.add_argument(
        "--change-classes",
        type=Path,
        default=PROTOCOL_DIR / "change-classes.json",
    )
    autonomy_readiness.add_argument(
        "--qualification-policy",
        type=Path,
        default=PROTOCOL_DIR / "qualification-policy.json",
    )
    autonomy_readiness.add_argument(
        "--maturity",
        type=Path,
        default=PROTOCOL_DIR / "operational-maturity.json",
    )
    autonomy_readiness.add_argument(
        "--factory-contract",
        type=Path,
        default=ROOT / "factory" / "factory-contract.json",
    )
    canary_simulate = autonomy_subparsers.add_parser(
        "canary-simulate",
        help="Run a side-effect-free P5.3 canary-plan simulation.",
    )
    canary_simulate.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-policy.json",
    )
    canary_simulate.add_argument(
        "--classes",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-classes.json",
    )
    canary_simulate.add_argument(
        "--change-classes",
        type=Path,
        default=PROTOCOL_DIR / "change-classes.json",
    )
    canary_simulate.add_argument(
        "--qualification-policy",
        type=Path,
        default=PROTOCOL_DIR / "qualification-policy.json",
    )
    canary_simulate.add_argument(
        "--maturity",
        type=Path,
        default=PROTOCOL_DIR / "operational-maturity.json",
    )
    canary_simulate.add_argument("--plan", type=Path, required=True)
    canary_simulate.add_argument("--output", type=Path)
    canary_readiness = autonomy_subparsers.add_parser(
        "canary-readiness",
        help="Report canonical P5.3 activation blockers without weakening them.",
    )
    canary_readiness.add_argument(
        "--policy",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-policy.json",
    )
    canary_readiness.add_argument(
        "--classes",
        type=Path,
        default=PROTOCOL_DIR / "autonomy-classes.json",
    )
    canary_readiness.add_argument(
        "--change-classes",
        type=Path,
        default=PROTOCOL_DIR / "change-classes.json",
    )
    canary_readiness.add_argument(
        "--qualification-policy",
        type=Path,
        default=PROTOCOL_DIR / "qualification-policy.json",
    )
    canary_readiness.add_argument(
        "--maturity",
        type=Path,
        default=PROTOCOL_DIR / "operational-maturity.json",
    )
    canary_readiness.add_argument(
        "--factory-contract",
        type=Path,
        default=ROOT / "factory" / "factory-contract.json",
    )

    factory_parser = subparsers.add_parser(
        "factory", help="Operate the bounded P3 factory substrate."
    )
    factory_subparsers = factory_parser.add_subparsers(
        dest="factory_command", required=True
    )
    for name, help_text in [
        ("validate", "Validate the factory contract."),
        ("status", "Inspect local and remote factory activation state."),
        ("build", "Run a clean build and create a content-addressed artifact."),
        ("verify", "Smoke-test a content-addressed artifact."),
        ("worktree-create", "Create an isolated Git worktree."),
        ("worktree-remove", "Remove a clean isolated Git worktree."),
        ("promote", "Promote one verified artifact with separate approval."),
        ("rollback", "Roll an environment back with separate approval."),
    ]:
        child = factory_subparsers.add_parser(name, help=help_text)
        child.add_argument(
            "--contract",
            type=Path,
            default=ROOT / "factory" / "factory-contract.json",
        )
        if name not in {"validate", "status"}:
            child.add_argument("--state-root", type=Path)
        if name == "build":
            child.add_argument("--report", type=Path)
        elif name == "verify":
            child.add_argument("--digest", required=True)
        elif name in {"worktree-create", "worktree-remove"}:
            child.add_argument("--work-item", required=True)
        elif name == "promote":
            child.add_argument("--digest", required=True)
            child.add_argument("--environment", required=True)
            child.add_argument("--approval", type=Path, required=True)
        elif name == "rollback":
            child.add_argument("--environment", required=True)
            child.add_argument("--approval", type=Path, required=True)
    operations_init = factory_subparsers.add_parser(
        "operations-init",
        help="Initialize the SF-106 journal and projection definitions.",
    )
    operations_init.add_argument("--store", type=Path, required=True)
    operations_status = factory_subparsers.add_parser(
        "operations-status",
        help="Inspect SF-106 journal, projection, and capability status.",
    )
    operations_status.add_argument("--store", type=Path, required=True)
    operations_verify = factory_subparsers.add_parser(
        "operations-verify",
        help="Verify SF-106 journal, source, public stream, and projection truth.",
    )
    operations_verify.add_argument("--store", type=Path, required=True)
    operations_rebuild = factory_subparsers.add_parser(
        "operations-rebuild",
        help="Rebuild and activate one or all SF-106 projections.",
    )
    operations_rebuild.add_argument("--store", type=Path, required=True)
    operations_rebuild.add_argument(
        "--projection",
        default="all",
        choices=[
            "all",
            "commands",
            "products",
            "runs",
            "signals",
            "timeline",
            "transitions",
            "work-items",
        ],
    )
    operations_rebuild.add_argument(
        "--batch-size",
        type=int,
        default=100,
    )
    operations_events = factory_subparsers.add_parser(
        "operations-events",
        help="Read the separate SF-003 public event stream.",
    )
    operations_events.add_argument("--store", type=Path, required=True)
    operations_events.add_argument("--project-id", required=True)
    operations_events.add_argument("--cursor", type=Path)
    operations_events.add_argument("--limit", type=int, default=100)
    operations_backup = factory_subparsers.add_parser(
        "operations-backup",
        help="Publish one verified SF-106 operations-store backup.",
    )
    operations_backup.add_argument("--store", type=Path, required=True)
    operations_backup.add_argument(
        "--output-root",
        type=Path,
        required=True,
    )
    operations_backup.add_argument("--backup-id")
    operations_backup_verify = factory_subparsers.add_parser(
        "operations-backup-verify",
        help="Verify a published SF-106 operations-store backup.",
    )
    operations_backup_verify.add_argument(
        "--backup",
        type=Path,
        required=True,
    )
    operations_restore = factory_subparsers.add_parser(
        "operations-restore",
        help="Restore a verified SF-106 operations-store backup.",
    )
    operations_restore.add_argument("--backup", type=Path, required=True)
    operations_restore.add_argument("--target", type=Path, required=True)
    operations_api = factory_subparsers.add_parser(
        "operations-api",
        help="Run the local loopback-only SF-107 factory operations API.",
    )
    operations_api.add_argument("--store", type=Path, required=True)
    operations_api.add_argument(
        "--auth-policy",
        type=Path,
        required=True,
    )
    operations_api.add_argument(
        "--session-store",
        type=Path,
        help="SF-203 session-control store used by the owner inbox.",
    )
    operations_api.add_argument(
        "--recovery-store",
        type=Path,
        help="SF-206 recovery store used by the owner inbox.",
    )
    operations_api.add_argument(
        "--host",
        default="127.0.0.1",
    )
    operations_api.add_argument(
        "--port",
        type=int,
        required=True,
    )
    return parser
