from __future__ import annotations

import json
import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from elder_protocol.errors import ProtocolError


def _parse_datetime(value: Any, label: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise ProtocolError(f"{label} must be an ISO-8601 date-time.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(
            f"{label} must be an ISO-8601 date-time."
        ) from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


class SQLiteCanaryExecutionStore:
    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = self._connect()
        try:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS canary_executions (
                    authorized_packet_sha256 TEXT PRIMARY KEY,
                    execution_id TEXT NOT NULL UNIQUE,
                    plan_sha256 TEXT NOT NULL UNIQUE,
                    claimed_at TEXT NOT NULL,
                    deadline_at TEXT NOT NULL,
                    status TEXT NOT NULL,
                    packet_json TEXT NOT NULL,
                    response_sha256 TEXT,
                    response_json TEXT,
                    rollback_claimed_at TEXT,
                    rollback_packet_json TEXT,
                    rollback_response_sha256 TEXT,
                    last_error TEXT
                )
                """
            )
            connection.commit()
        finally:
            connection.close()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30)
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA synchronous = FULL")
        return connection

    def claim(self, packet: dict[str, Any], *, at: str) -> None:
        claimed_at = _parse_datetime(at, "Canary execution claim time")
        deadline_at = claimed_at + timedelta(
            minutes=packet["timing"]["maximum_duration_minutes"]
        )
        connection = self._connect()
        try:
            connection.execute(
                """
                    INSERT INTO canary_executions (
                        authorized_packet_sha256,
                        execution_id,
                        plan_sha256,
                        claimed_at,
                        deadline_at,
                        status,
                        packet_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    packet["content_sha256"],
                    packet["execution_id"],
                    packet["plan_sha256"],
                    claimed_at.isoformat(),
                    deadline_at.isoformat(),
                    "claimed",
                    json.dumps(
                        packet,
                        sort_keys=True,
                        separators=(",", ":"),
                        ensure_ascii=True,
                    ),
                ),
            )
            connection.commit()
        except sqlite3.IntegrityError as exc:
            raise ProtocolError(
                "Canary execution packet has already been consumed."
            ) from exc
        finally:
            connection.close()

    def complete(
        self,
        packet: dict[str, Any],
        response: dict[str, Any],
    ) -> None:
        connection = self._connect()
        try:
            cursor = connection.execute(
                """
                UPDATE canary_executions
                SET status = ?, response_sha256 = ?, response_json = ?
                WHERE authorized_packet_sha256 = ? AND status = ?
                """,
                (
                    "observing",
                    response["content_sha256"],
                    json.dumps(
                        response,
                        sort_keys=True,
                        separators=(",", ":"),
                        ensure_ascii=True,
                    ),
                    packet["content_sha256"],
                    "claimed",
                ),
            )
            if cursor.rowcount != 1:
                raise ProtocolError(
                    "Canary execution claim is missing or already completed."
                )
            connection.commit()
        finally:
            connection.close()

    def get_record(
        self,
        packet: dict[str, Any],
    ) -> dict[str, Any]:
        connection = self._connect()
        try:
            row = connection.execute(
                """
                SELECT status, claimed_at, deadline_at, packet_json,
                       response_json, rollback_claimed_at, rollback_packet_json
                FROM canary_executions
                WHERE authorized_packet_sha256 = ?
                """,
                (packet["content_sha256"],),
            ).fetchone()
        finally:
            connection.close()
        if row is None:
            raise ProtocolError(
                "Canary execution is not registered in canonical runtime state."
            )
        (
            status,
            claimed_at,
            deadline_at,
            packet_json,
            response_json,
            rollback_claimed_at,
            rollback_packet_json,
        ) = row
        stored_packet = json.loads(packet_json)
        if stored_packet != packet:
            raise ProtocolError(
                "Canary packet does not match canonical runtime state."
            )
        return {
            "status": status,
            "claimed_at": claimed_at,
            "deadline_at": deadline_at,
            "packet": stored_packet,
            "response": (
                json.loads(response_json) if response_json is not None else None
            ),
            "rollback_claimed_at": rollback_claimed_at,
            "rollback_packet": (
                json.loads(rollback_packet_json)
                if rollback_packet_json is not None
                else None
            ),
        }

    def accepted_response(
        self,
        packet: dict[str, Any],
    ) -> dict[str, Any]:
        record = self.get_record(packet)
        if record["status"] != "observing":
            raise ProtocolError(
                "Canary execution is not in observing canonical runtime state."
            )
        if record["response"] is None:
            raise ProtocolError(
                "Canary execution has no accepted canonical provider response."
            )
        return record["response"]

    def due(self, *, at: str) -> list[dict[str, Any]]:
        evaluated_at = _parse_datetime(at, "Canary deadline sweep time")
        connection = self._connect()
        try:
            rows = connection.execute(
                """
                SELECT status, claimed_at, deadline_at, packet_json,
                       response_json, rollback_claimed_at, rollback_packet_json
                FROM canary_executions
                WHERE status IN (?, ?, ?, ?)
                ORDER BY deadline_at, authorized_packet_sha256
                """,
                (
                    "claimed",
                    "observing",
                    "rollback-failed",
                    "rolling-back",
                ),
            ).fetchall()
        finally:
            connection.close()
        due_records: list[dict[str, Any]] = []
        for (
            status,
            claimed_at,
            deadline_at,
            packet_json,
            response_json,
            rollback_claimed_at,
            rollback_packet_json,
        ) in rows:
            packet = json.loads(packet_json)
            is_due = False
            if status == "claimed":
                recovery_at = _parse_datetime(
                    claimed_at, "Canary claimed_at"
                ) + timedelta(
                    minutes=packet["start_response_timeout_minutes"]
                )
                is_due = evaluated_at >= recovery_at
            elif status == "observing":
                is_due = evaluated_at >= _parse_datetime(
                    deadline_at, "Canary deadline_at"
                )
            elif status == "rollback-failed":
                is_due = True
            elif status == "rolling-back" and rollback_claimed_at is not None:
                reclaim_at = _parse_datetime(
                    rollback_claimed_at,
                    "Canary rollback_claimed_at",
                ) + timedelta(
                    minutes=packet["rollback_claim_timeout_minutes"]
                )
                is_due = evaluated_at >= reclaim_at
            if is_due:
                due_records.append(
                    {
                        "status": status,
                        "packet": packet,
                        "response": (
                            json.loads(response_json)
                            if response_json is not None
                            else None
                        ),
                        "rollback_packet": (
                            json.loads(rollback_packet_json)
                            if rollback_packet_json is not None
                            else None
                        ),
                    }
                )
        return due_records

    def claim_rollback(
        self,
        packet: dict[str, Any],
        rollback_packet: dict[str, Any],
        *,
        at: str,
        require_deadline: bool,
    ) -> bool:
        evaluated_at = _parse_datetime(at, "Canary rollback claim time")
        expected_status = (
            "claimed"
            if rollback_packet["trigger"] == "start-uncertain"
            else "observing"
        )
        deadline_clause = "AND deadline_at <= ?" if require_deadline else ""
        parameters: list[str] = [
            "rolling-back",
            evaluated_at.isoformat(),
            json.dumps(
                rollback_packet,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=True,
            ),
            packet["content_sha256"],
            expected_status,
        ]
        if require_deadline:
            parameters.append(evaluated_at.isoformat())
        connection = self._connect()
        try:
            cursor = connection.execute(
                f"""
                UPDATE canary_executions
                SET status = ?, rollback_claimed_at = ?,
                    rollback_packet_json = ?, last_error = NULL
                WHERE authorized_packet_sha256 = ?
                  AND status = ?
                  {deadline_clause}
                """,
                parameters,
            )
            connection.commit()
            return cursor.rowcount == 1
        finally:
            connection.close()

    def reclaim_rollback(
        self,
        packet: dict[str, Any],
        *,
        at: str,
    ) -> bool:
        evaluated_at = _parse_datetime(at, "Canary rollback reclaim time")
        stale_before = evaluated_at - timedelta(
            minutes=packet["rollback_claim_timeout_minutes"]
        )
        connection = self._connect()
        try:
            cursor = connection.execute(
                """
                UPDATE canary_executions
                SET status = ?, rollback_claimed_at = ?, last_error = NULL
                WHERE authorized_packet_sha256 = ?
                  AND rollback_packet_json IS NOT NULL
                  AND (
                    status = ?
                    OR (
                      status = ?
                      AND rollback_claimed_at <= ?
                    )
                  )
                """,
                (
                    "rolling-back",
                    evaluated_at.isoformat(),
                    packet["content_sha256"],
                    "rollback-failed",
                    "rolling-back",
                    stale_before.isoformat(),
                ),
            )
            connection.commit()
            return cursor.rowcount == 1
        finally:
            connection.close()

    def mark_rolled_back(
        self,
        packet: dict[str, Any],
        rollback_response: dict[str, Any],
    ) -> None:
        connection = self._connect()
        try:
            cursor = connection.execute(
                """
                UPDATE canary_executions
                SET status = ?, rollback_response_sha256 = ?, last_error = NULL
                WHERE authorized_packet_sha256 = ? AND status = ?
                """,
                (
                    "rolled-back",
                    rollback_response["content_sha256"],
                    packet["content_sha256"],
                    "rolling-back",
                ),
            )
            if cursor.rowcount != 1:
                raise ProtocolError(
                    "Canary rollback claim is missing or already completed."
                )
            connection.commit()
        finally:
            connection.close()

    def mark_rollback_failed(
        self,
        packet: dict[str, Any],
        error: Exception,
    ) -> None:
        connection = self._connect()
        try:
            cursor = connection.execute(
                """
                UPDATE canary_executions
                SET status = ?, last_error = ?
                WHERE authorized_packet_sha256 = ? AND status = ?
                """,
                (
                    "rollback-failed",
                    f"{type(error).__name__}: {error}",
                    packet["content_sha256"],
                    "rolling-back",
                ),
            )
            if cursor.rowcount != 1:
                raise ProtocolError(
                    "Canary rollback failure could not be recorded."
                )
            connection.commit()
        finally:
            connection.close()

    def mark_rollback_expired(
        self,
        packet: dict[str, Any],
        *,
        at: str,
    ) -> None:
        evaluated_at = _parse_datetime(at, "Canary rollback expiry time")
        connection = self._connect()
        try:
            cursor = connection.execute(
                """
                UPDATE canary_executions
                SET status = ?, last_error = ?
                WHERE authorized_packet_sha256 = ?
                  AND status IN (?, ?)
                """,
                (
                    "rollback-expired",
                    (
                        "ProtocolError: persisted rollback authority expired "
                        f"at {evaluated_at.isoformat()}"
                    ),
                    packet["content_sha256"],
                    "rollback-failed",
                    "rolling-back",
                ),
            )
            if cursor.rowcount != 1:
                raise ProtocolError(
                    "Expired canary rollback state could not be recorded."
                )
            connection.commit()
        finally:
            connection.close()
