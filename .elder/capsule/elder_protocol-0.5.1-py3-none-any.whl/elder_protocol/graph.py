from __future__ import annotations

from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError


def _node(
    node_id: str,
    node_type: str,
    label: str,
    source: str,
    *,
    status: str = "ratified",
    attributes: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "id": node_id,
        "type": node_type,
        "label": label,
        "source": source,
        "status": status,
        "attributes": attributes or {},
    }


def _edge(
    edge_type: str,
    source_id: str,
    target_id: str,
    source: str,
    *,
    attributes: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "id": f"{edge_type}:{source_id}->{target_id}",
        "type": edge_type,
        "from": source_id,
        "to": target_id,
        "source": source,
        "attributes": attributes or {},
    }


def build_protocol_graph(data: dict[str, dict[str, Any]]) -> dict[str, Any]:
    nodes: dict[str, dict[str, Any]] = {}
    edges: dict[str, dict[str, Any]] = {}

    def add_node(node: dict[str, Any]) -> None:
        nodes[node["id"]] = node

    def add_edge(edge: dict[str, Any]) -> None:
        edges[edge["id"]] = edge

    layers = data["meta-architecture"]["layers"]
    for layer in layers:
        node_id = f"layer:{layer['id']}"
        add_node(
            _node(
                node_id,
                "architecture-layer",
                layer["name"],
                "protocol/meta-architecture.json",
                attributes={
                    "order": layer["order"],
                    "mutability": layer["mutability"],
                    "responsibility": layer["responsibility"],
                },
            )
        )
    for previous, current in zip(layers, layers[1:]):
        add_edge(
            _edge(
                "precedes",
                f"layer:{previous['id']}",
                f"layer:{current['id']}",
                "protocol/meta-architecture.json",
            )
        )

    for pack in data["capability-packs"]["packs"]:
        pack_id = f"pack:{pack['id']}"
        add_node(
            _node(
                pack_id,
                "capability-pack",
                pack["id"],
                "protocol/capability-packs.json",
                status=pack["contract_status"],
                attributes={
                    "required": pack["required"],
                    "obligation_owner_role": pack["obligation_owner_role"],
                    "runtime_status": pack["runtime_status"],
                    "responsibilities": pack["responsibilities"],
                    "adapter_points": pack["adapter_points"],
                },
            )
        )
        obligation_template_id = f"obligation-template:{pack['id']}"
        add_node(
            _node(
                obligation_template_id,
                "obligation",
                f"{pack['id']} obligations",
                "protocol/capability-packs.json",
                status=pack["contract_status"],
                attributes={
                    "owner_role": pack["obligation_owner_role"],
                    "artifact_types": pack["required_artifacts"],
                    "required_evidence": pack["required_evidence"],
                },
            )
        )
        add_edge(
            _edge(
                "resolves-to",
                pack_id,
                obligation_template_id,
                "protocol/capability-packs.json",
            )
        )
        add_edge(
            _edge(
                "owned-by",
                obligation_template_id,
                f"role:{pack['obligation_owner_role']}",
                "protocol/capability-packs.json",
            )
        )
        add_edge(
            _edge(
                "belongs-to",
                pack_id,
                f"layer:{pack['layer']}",
                "protocol/capability-packs.json",
            )
        )
        for dependency in pack["requires"]:
            add_edge(
                _edge(
                    "requires",
                    pack_id,
                    f"pack:{dependency}",
                    "protocol/capability-packs.json",
                )
            )
        for capability in pack["provides"]:
            capability_id = f"capability:{capability}"
            add_node(
                _node(
                    capability_id,
                    "capability",
                    capability,
                    "protocol/capability-packs.json",
                    status=pack["runtime_status"],
                )
            )
            add_edge(
                _edge(
                    "provides",
                    pack_id,
                    capability_id,
                    "protocol/capability-packs.json",
                )
            )
        for artifact in pack["required_artifacts"]:
            artifact_id = f"artifact-contract:{artifact}"
            add_node(
                _node(
                    artifact_id,
                    "artifact-contract",
                    artifact,
                    "protocol/capability-packs.json",
                    status=pack["contract_status"],
                )
            )
            add_edge(
                _edge(
                    "requires-artifact",
                    pack_id,
                    artifact_id,
                    "protocol/capability-packs.json",
                )
            )
        for evidence_level in pack["required_evidence"]:
            evidence_id = f"evidence-level:{evidence_level.lower()}"
            add_node(
                _node(
                    evidence_id,
                    "evidence-level",
                    evidence_level,
                    "protocol/capability-packs.json",
                )
            )
            add_edge(
                _edge(
                    "requires-evidence",
                    pack_id,
                    evidence_id,
                    "protocol/capability-packs.json",
                )
            )
        for skill_id in pack["required_skills"]:
            add_edge(
                _edge(
                    "requires",
                    pack_id,
                    f"skill:{skill_id}",
                    "protocol/capability-packs.json",
                )
            )
        for interface in pack["interfaces"]:
            add_edge(
                _edge(
                    "uses-interface",
                    pack_id,
                    f"schema:{interface}",
                    "protocol/capability-packs.json",
                )
            )

    for recommendation in data["recommendation-ledger"]["recommendations"]:
        recommendation_id = f"recommendation:{recommendation['id']}"
        add_node(
            _node(
                recommendation_id,
                "recommendation",
                recommendation["title"],
                "protocol/recommendation-ledger.json",
                status=recommendation["operational_status"],
                attributes={
                    "principle": recommendation["principle"],
                    "source": recommendation["source"],
                    "known_gaps": recommendation["known_gaps"],
                },
            )
        )
        for layer in recommendation["architecture_layers"]:
            add_edge(
                _edge(
                    "governs",
                    recommendation_id,
                    f"layer:{layer}",
                    "protocol/recommendation-ledger.json",
                )
            )
        for control in recommendation["controls"]:
            control_id = f"control:{control['id']}"
            add_node(
                _node(
                    control_id,
                    "control",
                    control["id"],
                    "protocol/recommendation-ledger.json",
                    status=control["status"],
                    attributes={
                        "kind": control["kind"],
                        "enforcement": control["enforcement"],
                    },
                )
            )
            add_edge(
                _edge(
                    "implements",
                    control_id,
                    recommendation_id,
                    "protocol/recommendation-ledger.json",
                )
            )
        for artifact in recommendation["required_artifacts"]:
            artifact_id = f"artifact-contract:{artifact}"
            add_node(
                _node(
                    artifact_id,
                    "artifact-contract",
                    artifact,
                    "protocol/recommendation-ledger.json",
                    status=recommendation["operational_status"],
                )
            )
            add_edge(
                _edge(
                    "requires-artifact",
                    recommendation_id,
                    artifact_id,
                    "protocol/recommendation-ledger.json",
                )
            )
        for evidence_level in recommendation["required_evidence"]:
            evidence_id = f"evidence-level:{evidence_level.lower()}"
            add_node(
                _node(
                    evidence_id,
                    "evidence-level",
                    evidence_level,
                    "protocol/recommendation-ledger.json",
                )
            )
            add_edge(
                _edge(
                    "requires-evidence",
                    recommendation_id,
                    evidence_id,
                    "protocol/recommendation-ledger.json",
                )
            )

    maturity = data["operational-maturity"]
    standard = maturity["institutional_standard"]
    standard_id = f"maturity-standard:{standard['id']}"
    add_node(
        _node(
            standard_id,
            "maturity-standard",
            "Elder Factory Maturity Standard",
            "protocol/operational-maturity.json",
            status="ratified",
            attributes={
                "version": standard["version"],
                "effective_date": standard["effective_date"],
                "ratifying_adr": standard["ratifying_adr"],
                "content_sha256": standard["content_sha256"],
                "overall_level_rule": standard["overall_level_rule"],
                "evidence_rules": standard["evidence_rules"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            standard_id,
            "layer:assurance-learning",
            "protocol/operational-maturity.json",
        )
    )
    for dimension in standard["dimensions"]:
        dimension_id = f"maturity-dimension:{dimension['id']}"
        add_node(
            _node(
                dimension_id,
                "maturity-dimension",
                dimension["name"],
                "protocol/operational-maturity.json",
                status="ratified",
                attributes={"question": dimension["question"]},
            )
        )
        add_edge(
            _edge(
                "defines-dimension",
                standard_id,
                dimension_id,
                "protocol/operational-maturity.json",
            )
        )
        add_edge(
            _edge(
                "belongs-to",
                dimension_id,
                "layer:assurance-learning",
                "protocol/operational-maturity.json",
            )
        )

    for level in maturity["levels"]:
        level_id = f"maturity-level:{level['id']}"
        benchmark = standard["benchmarks"].get(level["id"])
        add_node(
            _node(
                level_id,
                "maturity-level",
                level["name"],
                "protocol/operational-maturity.json",
                status="implemented",
                attributes={
                    "claim": level["claim"],
                    "required_capabilities": level["required_capabilities"],
                    "required_evidence": level["required_evidence"],
                    "prohibited_claims": level["prohibited_claims"],
                    "institutional_standard": standard["id"],
                    "institutional_standard_version": standard["version"],
                    "institutional_benchmark": benchmark,
                },
            )
        )
        add_edge(
            _edge(
                "belongs-to",
                level_id,
                "layer:assurance-learning",
                "protocol/operational-maturity.json",
            )
        )
        add_edge(
            _edge(
                "defined-by",
                level_id,
                standard_id,
                "protocol/operational-maturity.json",
            )
        )
        if benchmark is not None:
            benchmark_id = f"maturity-benchmark:{level['id']}"
            add_node(
                _node(
                    benchmark_id,
                    "maturity-benchmark",
                    benchmark["designation"],
                    "protocol/operational-maturity.json",
                    status="ratified",
                    attributes=benchmark,
                )
            )
            add_edge(
                _edge(
                    "benchmarks",
                    benchmark_id,
                    level_id,
                    "protocol/operational-maturity.json",
                )
            )
            add_edge(
                _edge(
                    "defined-by",
                    benchmark_id,
                    standard_id,
                    "protocol/operational-maturity.json",
                )
            )

    for dimension in data["judgment-rubric"]["dimensions"]:
        dimension_id = f"judgment-dimension:{dimension['id']}"
        add_node(
            _node(
                dimension_id,
                "judgment-dimension",
                dimension["id"],
                "protocol/judgment-rubric.json",
                status="implemented",
                attributes={
                    "question": dimension["question"],
                    "evidence": dimension["evidence"],
                    "weight": dimension["weight"],
                },
            )
        )
        add_edge(
            _edge(
                "defines",
                dimension_id,
                "layer:assurance-learning",
                "protocol/judgment-rubric.json",
            )
        )

    for document in data["design-registry"]["documents"]:
        document_id = f"design-document:{document['id']}"
        add_node(
            _node(
                document_id,
                "design-document",
                document["title"],
                "protocol/design-registry.json",
                status=document["status"],
                attributes={
                    "path": document["path"],
                    "kind": document["kind"],
                    "owners": document["owners"],
                    "change_classes": document["change_classes"],
                    "notifies": document["notifies"],
                    "content_sha256": document["content_sha256"],
                },
            )
        )
        add_edge(
            _edge(
                "documents",
                document_id,
                "layer:kernel",
                "protocol/design-registry.json",
            )
        )

    transcript_policy = data["transcript-review-policy"]
    transcript_policy_id = f"control:{transcript_policy['id']}"
    add_node(
        _node(
            transcript_policy_id,
            "control",
            transcript_policy["id"],
            "protocol/transcript-review-policy.json",
            status="implemented",
            attributes={
                "trace_format": transcript_policy["trace_format"],
                "maximum_failed_events": transcript_policy[
                    "maximum_failed_events"
                ],
                "authority": "advisory-only",
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            transcript_policy_id,
            "layer:assurance-learning",
            "protocol/transcript-review-policy.json",
        )
    )

    registry_by_id = {
        entry["id"]: entry for entry in data["evaluation-registry"]["datasets"]
    }
    evaluation_dataset = data["evaluation-dataset"]
    evaluation_dataset_id = f"evaluation-dataset:{evaluation_dataset['id']}"
    registry_entry = registry_by_id[evaluation_dataset["id"]]
    add_node(
        _node(
            evaluation_dataset_id,
            "evaluation-dataset",
            evaluation_dataset["title"],
            "protocol/evaluation-dataset.json",
            status=registry_entry["status"],
            attributes={
                "objective": evaluation_dataset["objective"],
                "owner": evaluation_dataset["owner"],
                "sensitivity": evaluation_dataset["sensitivity"],
                "case_count": len(evaluation_dataset["cases"]),
                "splits": evaluation_dataset["splits"],
                "content_sha256": registry_entry["content_sha256"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            evaluation_dataset_id,
            "layer:assurance-learning",
            "protocol/evaluation-registry.json",
        )
    )

    evaluator_contract = data["evaluator-contract"]
    evaluator_contract_id = f"evaluator-contract:{evaluator_contract['id']}"
    add_node(
        _node(
            evaluator_contract_id,
            "evaluator-contract",
            evaluator_contract["id"],
            "protocol/evaluator-contract.json",
            status="implemented",
            attributes={
                "authority": evaluator_contract["authority"]["mode"],
                "allowed_graders": evaluator_contract["allowed_graders"],
                "calibration": evaluator_contract["calibration"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            evaluator_contract_id,
            "layer:assurance-learning",
            "protocol/evaluator-contract.json",
        )
    )
    add_edge(
        _edge(
            "evaluates",
            evaluator_contract_id,
            evaluation_dataset_id,
            "protocol/evaluator-contract.json",
        )
    )

    telemetry_contract = data["telemetry-contract"]
    telemetry_contract_id = f"telemetry-contract:{telemetry_contract['id']}"
    add_node(
        _node(
            telemetry_contract_id,
            "telemetry-contract",
            telemetry_contract["id"],
            "protocol/telemetry-contract.json",
            status="implemented",
            attributes={
                "scopes": telemetry_contract["scopes"],
                "trace_context": telemetry_contract["semantic_conventions"][
                    "trace_context"
                ],
                "genai": telemetry_contract["semantic_conventions"]["genai"],
                "authority": telemetry_contract["authority"]["mode"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            telemetry_contract_id,
            "layer:assurance-learning",
            "protocol/telemetry-contract.json",
        )
    )
    for schema_name in [
        "telemetry-contract.schema.json",
        "telemetry-event.schema.json",
        "telemetry-report.schema.json",
    ]:
        add_edge(
            _edge(
                "uses-interface",
                telemetry_contract_id,
                f"schema:{schema_name}",
                "protocol/telemetry-contract.json",
            )
        )

    context_policy = data["context-policy"]
    context_policy_id = f"context-policy:{context_policy['id']}"
    add_node(
        _node(
            context_policy_id,
            "context-policy",
            context_policy["id"],
            "protocol/context-policy.json",
            status="implemented",
            attributes={
                "allowed_authorities": context_policy["allowed_authorities"],
                "allowed_memory_statuses": context_policy[
                    "allowed_memory_statuses"
                ],
                "budgets": context_policy["budgets"],
                "authority": context_policy["authority"]["mode"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            context_policy_id,
            "layer:assurance-learning",
            "protocol/context-policy.json",
        )
    )
    for schema_name in [
        "context-policy.schema.json",
        "context-request.schema.json",
        "context-packet.schema.json",
        "knowledge-query.schema.json",
    ]:
        add_edge(
            _edge(
                "uses-interface",
                context_policy_id,
                f"schema:{schema_name}",
                "protocol/context-policy.json",
            )
        )

    memory_policy = data["memory-policy"]
    memory_policy_id = f"memory-policy:{memory_policy['id']}"
    add_node(
        _node(
            memory_policy_id,
            "memory-policy",
            memory_policy["id"],
            "protocol/memory-policy.json",
            status="implemented",
            attributes={
                "kinds": memory_policy["kinds"],
                "states": memory_policy["states"],
                "trusted_promoters": memory_policy["trusted_promoters"],
                "authority": memory_policy["authority"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            memory_policy_id,
            "layer:assurance-learning",
            "protocol/memory-policy.json",
        )
    )
    for schema_name in [
        "memory-policy.schema.json",
        "memory-record.schema.json",
        "memory-approval.schema.json",
        "knowledge-graph.schema.json",
    ]:
        add_edge(
            _edge(
                "uses-interface",
                memory_policy_id,
                f"schema:{schema_name}",
                "protocol/memory-policy.json",
            )
        )

    learning_policy = data["learning-policy"]
    learning_policy_id = f"learning-policy:{learning_policy['id']}"
    add_node(
        _node(
            learning_policy_id,
            "learning-policy",
            learning_policy["id"],
            "protocol/learning-policy.json",
            status="implemented",
            attributes={
                "candidate_kinds": learning_policy["candidate_kinds"],
                "observation_modes": learning_policy["observation_modes"],
                "promotion_packet_only": learning_policy["authority"][
                    "promotion_packet_only"
                ],
                "required_approval_roles": learning_policy[
                    "promotion_requirements"
                ]["required_approval_roles"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            learning_policy_id,
            "layer:assurance-learning",
            "protocol/learning-policy.json",
        )
    )
    for schema_name in [
        "learning-policy.schema.json",
        "learning-candidate.schema.json",
        "learning-observation.schema.json",
        "learning-evaluation.schema.json",
        "learning-approval.schema.json",
        "learning-promotion.schema.json",
    ]:
        add_edge(
            _edge(
                "uses-interface",
                learning_policy_id,
                f"schema:{schema_name}",
                "protocol/learning-policy.json",
            )
        )

    qualification_policy = data["qualification-policy"]
    qualification_policy_id = (
        f"qualification-policy:{qualification_policy['id']}"
    )
    add_node(
        _node(
            qualification_policy_id,
            "qualification-policy",
            qualification_policy["id"],
            "protocol/qualification-policy.json",
            status="implemented",
            attributes={
                "trust_anchor_count": len(
                    qualification_policy["trust"]["anchors"]
                ),
                "gate_count": len(qualification_policy["gates"]),
                "cumulative": qualification_policy["qualification"][
                    "cumulative"
                ],
                "advisory_only": qualification_policy["qualification"][
                    "advisory_only"
                ],
                "can_mutate_maturity": qualification_policy["qualification"][
                    "can_mutate_maturity"
                ],
                "can_promote": qualification_policy["qualification"][
                    "can_promote"
                ],
                "can_deploy": qualification_policy["qualification"][
                    "can_deploy"
                ],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            qualification_policy_id,
            "layer:assurance-learning",
            "protocol/qualification-policy.json",
        )
    )
    for schema_name in [
        "qualification-policy.schema.json",
        "hosted-evidence-bundle.schema.json",
        "qualification-report.schema.json",
    ]:
        add_edge(
            _edge(
                "uses-interface",
                qualification_policy_id,
                f"schema:{schema_name}",
                "protocol/qualification-policy.json",
            )
        )

    autonomy_policy = data["autonomy-policy"]
    autonomy_policy_id = f"autonomy-policy:{autonomy_policy['id']}"
    add_node(
        _node(
            autonomy_policy_id,
            "autonomy-policy",
            autonomy_policy["id"],
            "protocol/autonomy-policy.json",
            status="implemented",
            attributes={
                "mode": autonomy_policy["mode"],
                "calculation": autonomy_policy["effective_autonomy"][
                    "calculation"
                ],
                "hard_stops": autonomy_policy["effective_autonomy"]["hard_stops"],
                "qualification_consumption": autonomy_policy[
                    "qualification_consumption"
                ]["mode"],
                "simulation": autonomy_policy["simulation"]["mode"],
                "supervised_pr_level": autonomy_policy["supervised_pr"][
                    "required_effective_level"
                ],
                "authority": autonomy_policy["authority"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            autonomy_policy_id,
            "layer:assurance-learning",
            "protocol/autonomy-policy.json",
        )
    )
    add_edge(
        _edge(
            "consumes",
            autonomy_policy_id,
            qualification_policy_id,
            "protocol/autonomy-policy.json",
        )
    )
    for schema_name in [
        "autonomy-policy.schema.json",
        "autonomy-class.schema.json",
        "autonomy-certification.schema.json",
        "incident-budget.schema.json",
        "autonomy-suspension.schema.json",
        "autonomy-revocation.schema.json",
        "autonomy-renewal.schema.json",
        "qualification-consumption.schema.json",
        "effective-autonomy-report.schema.json",
        "autonomy-work-item.schema.json",
        "autonomy-match-report.schema.json",
        "autonomy-simulation-report.schema.json",
        "autonomy-certification-event.schema.json",
        "autonomy-replay-report.schema.json",
        "autonomy-authority-lease.schema.json",
        "supervised-pr-execution.schema.json",
        "supervised-pr-packet.schema.json",
    ]:
        add_edge(
            _edge(
                "uses-interface",
                autonomy_policy_id,
                f"schema:{schema_name}",
                "protocol/autonomy-policy.json",
            )
        )

    delegation_policy = data["delegation-policy"]
    delegation_policy_id = f"delegation-policy:{delegation_policy['id']}"
    add_node(
        _node(
            delegation_policy_id,
            "control",
            delegation_policy["id"],
            "protocol/delegation-policy.json",
            status="implemented",
            attributes={
                "authority_ceilings": delegation_policy["authority_ceilings"],
                "rules": delegation_policy["rules"],
                "message_effect": delegation_policy["message_effect"],
            },
        )
    )
    add_edge(
        _edge(
            "belongs-to",
            delegation_policy_id,
            "layer:factory",
            "protocol/delegation-policy.json",
        )
    )

    for adapter in data["stack-adapter-registry"]["adapters"]:
        adapter_id = f"stack-adapter:{adapter['id']}"
        add_node(
            _node(
                adapter_id,
                "stack-adapter",
                adapter["id"],
                "protocol/stack-adapter-registry.json",
                status=adapter["status"],
                attributes={
                    "technology": adapter["technology"],
                    "adapter_point": adapter["adapter_point"],
                    "implementation": adapter["implementation"],
                    "required_evidence": adapter["required_evidence"],
                },
            )
        )
        add_edge(
            _edge(
                "adapts",
                adapter_id,
                f"pack:{adapter['pack']}",
                "protocol/stack-adapter-registry.json",
            )
        )
        add_edge(
            _edge(
                "belongs-to",
                adapter_id,
                "layer:adapter",
                "protocol/stack-adapter-registry.json",
            )
        )

    for skill in data["skill-registry"]["skills"]:
        skill_id = f"skill:{skill['id']}"
        add_node(
            _node(
                skill_id,
                "skill",
                skill["id"],
                "protocol/skill-registry.json",
                status="implemented",
                attributes={"path": skill["path"], "priority": skill["priority"]},
            )
        )
        for dependency in skill["requires"]:
            add_edge(
                _edge(
                    "requires",
                    skill_id,
                    f"skill:{dependency}",
                    "protocol/skill-registry.json",
                )
            )
        for pack_id in skill["packs"]:
            add_edge(
                _edge(
                    "routes-to",
                    f"pack:{pack_id}",
                    skill_id,
                    "protocol/skill-registry.json",
                )
            )

    for invariant in data["invariants"]["invariants"]:
        invariant_id = f"invariant:{invariant['id']}"
        add_node(
            _node(
                invariant_id,
                "invariant",
                invariant["statement"],
                "protocol/invariants.json",
                status=invariant["status"],
                attributes={"owner": invariant["owner"]},
            )
        )
        add_edge(
            _edge(
                "governs",
                invariant_id,
                "layer:project",
                "protocol/invariants.json",
            )
        )
        add_edge(
            _edge(
                "governs",
                invariant_id,
                "layer:factory",
                "protocol/invariants.json",
            )
        )

    for change_class in data["change-classes"]["classes"]:
        change_id = f"change-class:{change_class['id']}"
        add_node(
            _node(
                change_id,
                "change-class",
                change_class["id"],
                "protocol/change-classes.json",
                attributes={
                    "risk": change_class["risk"],
                    "maximum_autonomy": change_class["maximum_autonomy"],
                },
            )
        )
        add_edge(
            _edge(
                "governs",
                change_id,
                "layer:project",
                "protocol/change-classes.json",
            )
        )

    for autonomy_class in data["autonomy-classes"]["classes"]:
        autonomy_class_id = f"autonomy-class:{autonomy_class['id']}"
        add_node(
            _node(
                autonomy_class_id,
                "autonomy-class",
                autonomy_class["id"],
                "protocol/autonomy-classes.json",
                status="implemented",
                attributes={
                    "risk": autonomy_class["risk"],
                    "maximum_autonomy": autonomy_class["maximum_autonomy"],
                    "allowed_operations": autonomy_class["allowed_operations"],
                    "incident_budget": autonomy_class["incident_budget"],
                },
            )
        )
        add_edge(
            _edge(
                "subclass-of",
                autonomy_class_id,
                f"change-class:{autonomy_class['parent_change_class']}",
                "protocol/autonomy-classes.json",
            )
        )
        add_edge(
            _edge(
                "governs",
                autonomy_policy_id,
                autonomy_class_id,
                "protocol/autonomy-policy.json",
            )
        )

    for name in sorted(key for key in data if key.endswith(".schema")):
        schema_id = f"schema:{name.removesuffix('.schema')}.schema.json"
        add_node(
            _node(
                schema_id,
                "schema",
                name.removesuffix(".schema"),
                f"protocol/{name}.json",
                status="implemented",
            )
        )
        add_edge(
            _edge(
                "defines",
                schema_id,
                "layer:capability",
                f"protocol/{name}.json",
            )
        )

    matrix = data["authority-matrix"]
    for role in data["role-registry"]["roles"]:
        subject = role["id"]
        subject_id = f"role:{subject}"
        add_node(
            _node(
                subject_id,
                "agent-or-human-role",
                subject,
                "protocol/role-registry.json",
                status="implemented",
                attributes={
                    "kind": role["kind"],
                    "aliases": role["aliases"],
                    "can_delegate": role["can_delegate"],
                    "can_approve": role["can_approve"],
                    "can_promote": role["can_promote"],
                },
            )
        )
    for resource in matrix["resources"]:
        resource_id = f"authority-resource:{resource['id']}"
        add_node(
            _node(
                resource_id,
                "authority-resource",
                resource["id"],
                "protocol/authority-matrix.json",
                status="implemented",
                attributes={"mutability": resource["mutability"]},
            )
        )
        for subject, actions in resource["permissions"].items():
            add_edge(
                _edge(
                    "permits",
                    f"role:{subject}",
                    resource_id,
                    "protocol/authority-matrix.json",
                    attributes={"actions": actions},
                )
            )
        add_edge(
            _edge(
                "governs",
                subject_id,
                "layer:project",
                "protocol/authority-matrix.json",
            )
        )

    for entity in data["ontology"]["entity_types"]:
        entity_id = f"ontology-entity:{entity['id']}"
        add_node(
            _node(
                entity_id,
                "ontology-entity",
                entity["id"],
                "protocol/ontology.json",
                attributes={"definition": entity["definition"]},
            )
        )
        add_edge(
            _edge(
                "defines",
                entity_id,
                "layer:kernel",
                "protocol/ontology.json",
            )
        )

    return {
        "version": PROTOCOL_VERSION,
        "kind": "protocol",
        "nodes": [nodes[node_id] for node_id in sorted(nodes)],
        "edges": [edges[edge_id] for edge_id in sorted(edges)],
    }


def build_project_graph(
    profile: dict[str, Any],
    data: dict[str, dict[str, Any]],
    skills: list[dict[str, Any]],
    resolved_pack_ids: list[str],
    design_documents: list[dict[str, Any]] | None = None,
    evaluation_dataset: dict[str, Any] | None = None,
    authority_bindings: dict[str, Any] | None = None,
    resolved_obligations: dict[str, Any] | None = None,
) -> dict[str, Any]:
    protocol_graph = build_protocol_graph(data)
    selected_packs = {f"pack:{pack_id}" for pack_id in resolved_pack_ids}
    selected_skills = {f"skill:{skill['id']}" for skill in skills}
    included = {
        node["id"]
        for node in protocol_graph["nodes"]
        if node["type"]
        in {
            "architecture-layer",
            "invariant",
            "change-class",
            "agent-or-human-role",
            "ontology-entity",
            "recommendation",
            "control",
            "maturity-standard",
            "maturity-dimension",
            "maturity-level",
            "maturity-benchmark",
            "judgment-dimension",
            "evaluation-dataset",
            "evaluator-contract",
            "telemetry-contract",
            "context-policy",
            "memory-policy",
            "learning-policy",
            "qualification-policy",
            "autonomy-policy",
            "autonomy-class",
            "obligation",
            "stack-adapter",
            "authority-resource",
        }
    }
    included |= selected_packs | selected_skills

    for edge in protocol_graph["edges"]:
        if edge["from"] in selected_packs and edge["type"] in {
            "provides",
            "requires-artifact",
            "requires-evidence",
            "uses-interface",
        }:
            included.add(edge["to"])

    nodes = {
        node["id"]: node
        for node in protocol_graph["nodes"]
        if node["id"] in included
    }
    edges = {
        edge["id"]: edge
        for edge in protocol_graph["edges"]
        if edge["from"] in included and edge["to"] in included
    }

    project_id = f"project:{profile['slug']}"
    nodes[project_id] = _node(
        project_id,
        "project",
        profile["name"],
        ".elder/project-profile.json",
        status=profile["profile_status"],
        attributes={
            "mission": profile["mission"],
            "risk_tier": profile["risk_tier"],
            "autonomy_ceiling": profile["autonomy_ceiling"],
        },
    )
    for pack_id in sorted(selected_packs):
        edge = _edge("selects", project_id, pack_id, ".elder/project-profile.json")
        edges[edge["id"]] = edge
    for skill_id in sorted(selected_skills):
        edge = _edge("routes-to", project_id, skill_id, ".elder/skills.json")
        edges[edge["id"]] = edge
    for node_id in sorted(included):
        if node_id.startswith(("invariant:", "change-class:")):
            edge = _edge("governed-by", project_id, node_id, ".elder/project-contract.json")
            edges[edge["id"]] = edge
    for document in design_documents or []:
        document_id = f"design-document:{document['id']}"
        nodes[document_id] = _node(
            document_id,
            "design-document",
            document["title"],
            ".elder/design-registry.json",
            status=document["status"],
            attributes={
                "path": document["path"],
                "kind": document["kind"],
                "owners": document["owners"],
                "change_classes": document["change_classes"],
                "content_sha256": document["content_sha256"],
            },
        )
        edge = _edge(
            "documents",
            document_id,
            "layer:project",
            ".elder/design-registry.json",
        )
        edges[edge["id"]] = edge
    if evaluation_dataset is not None:
        dataset_id = f"evaluation-dataset:{evaluation_dataset['id']}"
        nodes[dataset_id] = _node(
            dataset_id,
            "evaluation-dataset",
            evaluation_dataset["title"],
            ".elder/evaluation-dataset.json",
            status="draft",
            attributes={
                "objective": evaluation_dataset["objective"],
                "owner": evaluation_dataset["owner"],
                "sensitivity": evaluation_dataset["sensitivity"],
                "case_count": len(evaluation_dataset["cases"]),
                "splits": evaluation_dataset["splits"],
            },
        )
        edge = _edge(
            "selects",
            project_id,
            dataset_id,
            ".elder/evaluation-registry.json",
        )
        edges[edge["id"]] = edge
    for source in profile["knowledge_sources"]:
        source_id = f"knowledge-source:{source['id']}"
        nodes[source_id] = _node(
            source_id,
            "knowledge-source",
            source["id"],
            ".elder/project-profile.json",
            attributes={
                "location": source["location"],
                "authority": source["authority"],
                "source_type": source["type"],
            },
        )
        edge = _edge("reads", project_id, source_id, ".elder/project-profile.json")
        edges[edge["id"]] = edge

    for identity in (authority_bindings or {}).get("identities", []):
        identity_id = f"agent-identity:{identity['id']}"
        nodes[identity_id] = _node(
            identity_id,
            "agent-identity",
            identity["id"],
            ".elder/authority-bindings.json",
            attributes={"kind": identity["kind"]},
        )
    for binding in (authority_bindings or {}).get("role_bindings", []):
        edge = _edge(
            "bound-to",
            f"role:{binding['role']}",
            f"agent-identity:{binding['identity']}",
            ".elder/authority-bindings.json",
        )
        edges[edge["id"]] = edge
    for obligation in (resolved_obligations or {}).get("obligations", []):
        obligation_id = f"obligation:{obligation['id']}"
        nodes[obligation_id] = _node(
            obligation_id,
            "obligation",
            obligation["artifact_type"],
            ".elder/resolved-obligations.json",
            status=obligation["status"],
            attributes={
                "pack": obligation["pack"],
                "owner_role": obligation["owner_role"],
                "owner_identity": obligation["owner_identity"],
                "required_evidence": obligation["required_evidence"],
            },
        )
        for edge in [
            _edge(
                "resolves-to",
                f"pack:{obligation['pack']}",
                obligation_id,
                ".elder/resolved-obligations.json",
            ),
            _edge(
                "owned-by",
                obligation_id,
                f"agent-identity:{obligation['owner_identity']}",
                ".elder/resolved-obligations.json",
            ),
            _edge(
                "requires-artifact",
                obligation_id,
                f"artifact-contract:{obligation['artifact_type']}",
                ".elder/resolved-obligations.json",
            ),
        ]:
            edges[edge["id"]] = edge
        for evidence_level in obligation["required_evidence"]:
            edge = _edge(
                "requires-evidence",
                obligation_id,
                f"evidence-level:{evidence_level.lower()}",
                ".elder/resolved-obligations.json",
            )
            edges[edge["id"]] = edge

    graph = {
        "version": PROTOCOL_VERSION,
        "kind": "project",
        "project_id": project_id,
        "nodes": [nodes[node_id] for node_id in sorted(nodes)],
        "edges": [edges[edge_id] for edge_id in sorted(edges)],
    }
    validate_graph(graph)
    return graph


def validate_graph(graph: dict[str, Any]) -> None:
    required = {"version", "kind", "nodes", "edges"}
    if graph.get("kind") == "project":
        required.add("project_id")
    if set(graph) != required:
        raise ProtocolError(f"Protocol graph fields must be exactly: {sorted(required)}")
    if graph["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Protocol graph version must be '{PROTOCOL_VERSION}'."
        )
    if graph["kind"] not in {"protocol", "project"}:
        raise ProtocolError("Protocol graph kind must be protocol or project.")
    node_ids = [node.get("id") for node in graph["nodes"]]
    if any(not isinstance(node_id, str) or not node_id for node_id in node_ids):
        raise ProtocolError("Every protocol graph node needs a non-empty id.")
    if len(node_ids) != len(set(node_ids)):
        raise ProtocolError("Protocol graph node ids must be unique.")
    known = set(node_ids)
    edge_ids = [edge.get("id") for edge in graph["edges"]]
    if len(edge_ids) != len(set(edge_ids)):
        raise ProtocolError("Protocol graph edge ids must be unique.")
    for edge in graph["edges"]:
        if edge.get("from") not in known or edge.get("to") not in known:
            raise ProtocolError(
                f"Protocol graph edge '{edge.get('id')}' has an unknown endpoint."
            )
