from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json, write_text


SKILL_NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


def parse_skill_frontmatter(path: Path) -> dict[str, str]:
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise ProtocolError(f"Skill file does not exist: {path}") from exc
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ProtocolError(f"Skill must start with YAML frontmatter: {path}")
    try:
        end = lines.index("---", 1)
    except ValueError as exc:
        raise ProtocolError(f"Skill frontmatter is not closed: {path}") from exc
    metadata: dict[str, str] = {}
    for line in lines[1:end]:
        if not line.strip():
            continue
        if ":" not in line:
            raise ProtocolError(f"Invalid skill frontmatter line in {path}: {line}")
        key, value = line.split(":", 1)
        metadata[key.strip()] = value.strip().strip('"')
    if set(metadata) != {"name", "description"}:
        raise ProtocolError(
            f"Skill frontmatter must contain only name and description: {path}"
        )
    if not SKILL_NAME_PATTERN.fullmatch(metadata["name"]):
        raise ProtocolError(f"Invalid skill name '{metadata['name']}' in {path}")
    if len(metadata["description"]) < 20:
        raise ProtocolError(f"Skill description is too short in {path}")
    return metadata


def _dependency_order(skills: dict[str, dict[str, Any]]) -> list[str]:
    visiting: set[str] = set()
    visited: set[str] = set()
    order: list[str] = []

    def visit(skill_id: str) -> None:
        if skill_id in visiting:
            raise ProtocolError(f"Skill dependency cycle includes '{skill_id}'.")
        if skill_id in visited:
            return
        visiting.add(skill_id)
        for dependency in skills[skill_id].get("requires", []):
            if dependency not in skills:
                raise ProtocolError(
                    f"Skill '{skill_id}' requires unknown skill '{dependency}'."
                )
            visit(dependency)
        visiting.remove(skill_id)
        visited.add(skill_id)
        order.append(skill_id)

    for skill_id in skills:
        visit(skill_id)
    return order


def validate_skill_registry(registry_path: Path, skills_root: Path) -> dict[str, Any]:
    registry = load_json(registry_path)
    entries = registry.get("skills")
    if not isinstance(entries, list) or not entries:
        raise ProtocolError("Skill registry must define at least one skill.")
    by_id: dict[str, dict[str, Any]] = {}
    for entry in entries:
        required = {
            "id",
            "path",
            "description",
            "capabilities",
            "triggers",
            "requires",
            "packs",
            "priority",
        }
        if not isinstance(entry, dict) or set(entry) != required:
            raise ProtocolError(
                f"Every skill registry entry must contain exactly: {sorted(required)}"
            )
        skill_id = entry["id"]
        if not isinstance(skill_id, str) or not SKILL_NAME_PATTERN.fullmatch(skill_id):
            raise ProtocolError(f"Invalid skill registry id: {skill_id}")
        if skill_id in by_id:
            raise ProtocolError(f"Duplicate skill registry id: {skill_id}")
        for field in ["capabilities", "triggers", "requires", "packs"]:
            value = entry[field]
            if not isinstance(value, list) or any(
                not isinstance(item, str) or not item.strip() for item in value
            ):
                raise ProtocolError(f"Skill '{skill_id}' {field} must be strings.")
        if not isinstance(entry["priority"], int) or entry["priority"] < 1:
            raise ProtocolError(f"Skill '{skill_id}' priority must be a positive integer.")
        skill_path = skills_root / entry["path"]
        metadata = parse_skill_frontmatter(skill_path)
        if metadata["name"] != skill_id:
            raise ProtocolError(
                f"Skill registry id '{skill_id}' does not match {skill_path}."
            )
        if metadata["description"] != entry["description"]:
            raise ProtocolError(
                f"Skill registry description does not match {skill_path}."
            )
        by_id[skill_id] = entry
    _dependency_order(by_id)
    return registry


def _tokens(text: str) -> set[str]:
    return set(TOKEN_PATTERN.findall(text.lower()))


def route_skills(
    task: str,
    registry: dict[str, Any],
    selected_packs: set[str] | None = None,
    limit: int = 5,
) -> list[dict[str, Any]]:
    task_tokens = _tokens(task)
    entries = {entry["id"]: entry for entry in registry["skills"]}
    scored: list[tuple[int, int, str]] = []
    for entry in entries.values():
        if selected_packs and not (selected_packs & set(entry["packs"])):
            continue
        name_score = len(task_tokens & _tokens(entry["id"])) * 4
        trigger_score = sum(
            len(task_tokens & _tokens(trigger)) * 3 for trigger in entry["triggers"]
        )
        capability_score = sum(
            len(task_tokens & _tokens(capability)) * 2
            for capability in entry["capabilities"]
        )
        description_score = len(task_tokens & _tokens(entry["description"]))
        score = name_score + trigger_score + capability_score + description_score
        if score:
            scored.append((score, -entry["priority"], entry["id"]))
    scored.sort(reverse=True)

    selected: list[str] = []

    def include(skill_id: str) -> None:
        for dependency in entries[skill_id]["requires"]:
            include(dependency)
        if skill_id not in selected:
            selected.append(skill_id)

    direct_matches = 0
    for _, _, skill_id in scored:
        include(skill_id)
        direct_matches += 1
        if direct_matches >= limit:
            break
    return [entries[skill_id] for skill_id in selected]


def create_skill(
    skills_root: Path,
    registry_path: Path,
    name: str,
    description: str,
    capabilities: list[str],
    triggers: list[str],
    requires: list[str],
    packs: list[str],
    priority: int,
) -> Path:
    if not SKILL_NAME_PATTERN.fullmatch(name):
        raise ProtocolError("Skill name must use lowercase kebab-case.")
    if len(description.strip()) < 20:
        raise ProtocolError("Skill description must contain at least 20 characters.")
    for label, value in [
        ("capabilities", capabilities),
        ("triggers", triggers),
        ("packs", packs),
    ]:
        if not value or any(not item.strip() for item in value):
            raise ProtocolError(f"Skill {label} must contain non-empty values.")
    registry = load_json(registry_path)
    entries = registry.get("skills", [])
    known = {entry["id"] for entry in entries}
    if name in known:
        raise ProtocolError(f"Skill already exists in registry: {name}")
    unknown_dependencies = set(requires) - known
    if unknown_dependencies:
        raise ProtocolError(
            f"Skill requires unknown dependencies: {sorted(unknown_dependencies)}"
        )
    target = skills_root / name / "SKILL.md"
    if target.exists():
        raise ProtocolError(f"Skill path already exists: {target}")
    body = f"""---
name: {name}
description: "{description.strip()}"
---

# {name.replace('-', ' ').title()}

## Workflow

1. Confirm the task matches this skill's declared purpose.
2. Read the minimum authoritative project context.
3. Execute within the approved authority and change class.
4. Produce explicit evidence, unresolved risks, and the next proof gate.

## Stop Conditions

- Stop when required authority or evidence is missing.
- Do not broaden scope silently.
- Do not represent a specified capability as operational.
"""
    write_text(target, body)
    entries.append(
        {
            "id": name,
            "path": f"{name}/SKILL.md",
            "description": description.strip(),
            "capabilities": capabilities,
            "triggers": triggers,
            "requires": requires,
            "packs": packs,
            "priority": priority,
        }
    )
    registry["skills"] = sorted(entries, key=lambda item: item["id"])
    write_text(registry_path, json.dumps(registry, indent=2) + "\n")
    validate_skill_registry(registry_path, skills_root)
    return target
