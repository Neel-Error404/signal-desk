from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json


def _internal_imports(path: Path, prefix: str) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (OSError, UnicodeError, SyntaxError) as exc:
        raise ProtocolError(
            f"Could not parse architecture boundary source {path}: {exc}"
        ) from exc
    imports: set[str] = set()
    qualified_prefix = f"{prefix}."
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith(qualified_prefix):
                    imports.add(alias.name[len(qualified_prefix) :].split(".", 1)[0])
        elif (
            isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.startswith(qualified_prefix)
        ):
            imports.add(node.module[len(qualified_prefix) :].split(".", 1)[0])
    return imports


def _load_contract(contract_path: Path, root: Path) -> dict[str, Any]:
    contract = load_json(contract_path)
    required = {
        "version",
        "id",
        "adapter",
        "import_prefix",
        "unknown_module_policy",
        "modules",
    }
    if set(contract) != required:
        raise ProtocolError(
            f"Architecture boundary fields must be exactly: {sorted(required)}"
        )
    if contract["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Architecture boundary version must be '{PROTOCOL_VERSION}'."
        )
    if contract["adapter"] != "python-ast-imports":
        raise ProtocolError(
            f"Unsupported architecture boundary adapter: {contract['adapter']}"
        )
    if contract["unknown_module_policy"] not in {"allow", "deny"}:
        raise ProtocolError("Unknown module policy must be allow or deny.")
    modules = contract["modules"]
    if not isinstance(modules, list) or not modules:
        raise ProtocolError("Architecture boundary contract needs modules.")
    module_ids = [module.get("id") for module in modules]
    if any(not isinstance(module_id, str) or not module_id for module_id in module_ids):
        raise ProtocolError("Every architecture boundary module needs an id.")
    if len(module_ids) != len(set(module_ids)):
        raise ProtocolError("Architecture boundary module ids must be unique.")
    for module in modules:
        if set(module) != {"id", "path", "allowed_internal_dependencies"}:
            raise ProtocolError(
                f"Architecture module '{module.get('id')}' has invalid fields."
            )
        dependencies = module["allowed_internal_dependencies"]
        if not isinstance(dependencies, list) or len(dependencies) != len(
            set(dependencies)
        ):
            raise ProtocolError(
                f"Architecture module '{module['id']}' dependencies must be unique."
            )
        unknown = set(dependencies) - set(module_ids)
        if unknown:
            raise ProtocolError(
                f"Architecture module '{module['id']}' allows unknown modules: "
                f"{sorted(unknown)}"
            )
        path = (root / module["path"]).resolve()
        if not path.is_relative_to(root):
            raise ProtocolError(
                f"Architecture module '{module['id']}' escapes the project root."
            )
        if not path.is_file():
            raise ProtocolError(
                f"Architecture module '{module['id']}' does not exist: {path}"
            )
    return contract


def check_architecture_boundaries(
    contract_path: Path,
    root: Path,
) -> dict[str, Any]:
    contract_path = contract_path.resolve()
    root = root.resolve()
    contract = _load_contract(contract_path, root)
    declared = {module["id"]: module for module in contract["modules"]}
    violations: list[str] = []
    checked_paths: set[Path] = set()
    for module_id, module in declared.items():
        path = (root / module["path"]).resolve()
        checked_paths.add(path)
        imports = _internal_imports(path, contract["import_prefix"])
        forbidden = sorted(
            imports - set(module["allowed_internal_dependencies"])
        )
        if forbidden:
            violations.append(
                f"{module_id}: forbidden internal imports {forbidden}; allowed "
                f"{sorted(module['allowed_internal_dependencies'])}"
            )

    if contract["unknown_module_policy"] == "deny":
        source_directories = {path.parent for path in checked_paths}
        for directory in sorted(source_directories):
            for path in sorted(directory.glob("*.py")):
                if path not in checked_paths:
                    violations.append(
                        f"{path.stem}: module has no declared dependency policy"
                    )

    return {
        "contract": str(contract_path),
        "id": contract["id"],
        "adapter": contract["adapter"],
        "checked_modules": sorted(declared),
        "violations": violations,
    }


def enforce_architecture_boundaries(
    contract_path: Path,
    root: Path,
) -> dict[str, Any]:
    report = check_architecture_boundaries(contract_path, root)
    if report["violations"]:
        raise ProtocolError(
            "Architecture boundary violations: "
            + " | ".join(report["violations"])
        )
    return report
