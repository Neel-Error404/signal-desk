from __future__ import annotations

import base64
import binascii
import copy
import hashlib
import json
import re
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json


LEVELS = ["L0", "L1", "L2", "L3", "L4", "L5"]
CANONICAL_QUALIFICATION_POLICY_ID = "elder-hosted-production-qualification-v1"
CANONICAL_OPERATOR_ANCHOR_ID = "p4-8a-operator-verifier-v1"
CANONICAL_OPERATOR_SUBJECT = (
    "operator:Neel-Error404:elder-protocol:p4.8a-independent-verifier"
)
CANONICAL_OPERATOR_PUBLIC_KEY_BASE64 = (
    "QFI7UC1DE85T6RCoRHM3JXQM+TUEPv/1twjYHlptZ5Q="
)
CANONICAL_REVIEWER_ANCHOR_ID = "p4-8a-independent-reviewer-v1"
CANONICAL_REVIEWER_SUBJECT = (
    "codex-agent:019fd598-e0e5-7e83-a33b-6bee1bd8ff37:p4.8a-reviewer"
)
CANONICAL_REVIEWER_PUBLIC_KEY_BASE64 = (
    "2rGo9ceoB7twf542Zaph1H4OdBfl9AWF6NbAO2grOig="
)
P4_8A_GOVERNANCE_GATES = {
    "l0-evidence-successful-manual-replay": (
        "manual_replay",
        CANONICAL_OPERATOR_ANCHOR_ID,
        "accountable-operator",
    ),
    "l1-capability-human-approval": (
        "human_decision",
        CANONICAL_OPERATOR_ANCHOR_ID,
        "accountable-operator",
    ),
    "l1-evidence-human-decision-record": (
        "human_decision",
        CANONICAL_OPERATOR_ANCHOR_ID,
        "accountable-operator",
    ),
    "l2-capability-independent-review": (
        "independent_review",
        CANONICAL_REVIEWER_ANCHOR_ID,
        "independent-reviewer",
    ),
}
SHA256_PATTERN = re.compile(r"^[a-f0-9]{64}$")


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")


def _content_digest(value: dict[str, Any]) -> str:
    payload = {
        key: item for key, item in value.items() if key != "content_sha256"
    }
    return hashlib.sha256(_canonical_bytes(payload)).hexdigest()


def _require_fields(
    value: Any,
    required: set[str],
    label: str,
) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != required:
        raise ProtocolError(f"{label} fields must be exactly: {sorted(required)}")
    return value


def _require_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProtocolError(f"{label} must be a non-empty string.")
    return value


def _require_string_list(
    value: Any,
    label: str,
    *,
    allow_empty: bool = False,
) -> list[str]:
    if (
        not isinstance(value, list)
        or (not allow_empty and not value)
        or any(not isinstance(item, str) or not item.strip() for item in value)
    ):
        qualifier = "" if allow_empty else "non-empty "
        raise ProtocolError(f"{label} must be a {qualifier}list of strings.")
    if len(value) != len(set(value)):
        raise ProtocolError(f"{label} cannot contain duplicates.")
    return value


def _require_sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or SHA256_PATTERN.fullmatch(value) is None:
        raise ProtocolError(
            f"{label} must be 64 lowercase hexadecimal characters."
        )
    return value


def _parse_datetime(value: Any, label: str) -> datetime:
    _require_string(value, label)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be an ISO-8601 datetime.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed.astimezone(UTC)


def _verify_content_digest(value: dict[str, Any], label: str) -> None:
    _require_sha256(value.get("content_sha256"), f"{label} content_sha256")
    if value["content_sha256"] != _content_digest(value):
        raise ProtocolError(f"{label} content digest does not match its fields.")


def _resolve_payload(
    bundle_root: Path,
    relative: str,
    *,
    reject_symlinks: bool,
) -> Path:
    relative_path = Path(_require_string(relative, "Evidence payload_path"))
    if relative_path.is_absolute():
        raise ProtocolError("Evidence payload_path must be relative.")
    resolved_root = bundle_root.resolve()
    candidate = (resolved_root / relative_path).resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise ProtocolError(f"Evidence payload_path escapes the bundle: {relative}")
    if not candidate.is_file():
        raise ProtocolError(f"Evidence payload does not exist: {relative}")
    if reject_symlinks:
        current = resolved_root
        for part in relative_path.parts:
            current = current / part
            if current.is_symlink():
                raise ProtocolError(
                    f"Evidence payload cannot traverse a symlink: {relative}"
                )
    return candidate


def validate_qualification_trust(
    trust_value: Any,
) -> dict[str, dict[str, Any]]:
    trust = _require_fields(
        trust_value,
        {"algorithms", "require_signature", "anchors"},
        "Qualification trust",
    )
    algorithms = _require_string_list(
        trust["algorithms"], "Qualification trust algorithms"
    )
    if set(algorithms) != {"ed25519"}:
        raise ProtocolError("Qualification trust currently requires ed25519.")
    if trust["require_signature"] is not True:
        raise ProtocolError("Qualification evidence signatures are mandatory.")
    anchors = trust["anchors"]
    if not isinstance(anchors, list):
        raise ProtocolError("Qualification trust anchors must be a list.")
    anchor_map: dict[str, dict[str, Any]] = {}
    for anchor in anchors:
        _require_fields(
            anchor,
            {
                "id",
                "subject_identity",
                "algorithm",
                "public_key_base64",
                "roles",
                "providers",
                "source_hosts",
                "valid_from",
                "valid_until",
                "status",
            },
            "Qualification trust anchor",
        )
        anchor_id = _require_string(anchor["id"], "Trust anchor id")
        if anchor_id in anchor_map:
            raise ProtocolError(f"Duplicate qualification trust anchor: {anchor_id}")
        _require_string(
            anchor["subject_identity"],
            f"Trust anchor '{anchor_id}' subject_identity",
        )
        if anchor["algorithm"] != "ed25519":
            raise ProtocolError(
                f"Trust anchor '{anchor_id}' must use ed25519."
            )
        try:
            public_bytes = base64.b64decode(
                anchor["public_key_base64"],
                validate=True,
            )
        except (ValueError, binascii.Error) as exc:
            raise ProtocolError(
                f"Trust anchor '{anchor_id}' public key is not valid base64."
            ) from exc
        if len(public_bytes) != 32:
            raise ProtocolError(
                f"Trust anchor '{anchor_id}' must contain a 32-byte Ed25519 key."
            )
        _require_string_list(anchor["roles"], f"Trust anchor '{anchor_id}' roles")
        _require_string_list(
            anchor["providers"], f"Trust anchor '{anchor_id}' providers"
        )
        _require_string_list(
            anchor["source_hosts"], f"Trust anchor '{anchor_id}' source_hosts"
        )
        valid_from = _parse_datetime(
            anchor["valid_from"], f"Trust anchor '{anchor_id}' valid_from"
        )
        valid_until = _parse_datetime(
            anchor["valid_until"], f"Trust anchor '{anchor_id}' valid_until"
        )
        if valid_until <= valid_from:
            raise ProtocolError(
                f"Trust anchor '{anchor_id}' validity window is invalid."
            )
        if anchor["status"] not in {"active", "revoked"}:
            raise ProtocolError(
                f"Trust anchor '{anchor_id}' status must be active or revoked."
            )
        anchor_map[anchor_id] = anchor
    return anchor_map


def validate_qualification_policy(
    policy: dict[str, Any],
    maturity_model: dict[str, Any],
) -> dict[str, Any]:
    _require_fields(
        policy,
        {
            "version",
            "id",
            "trust",
            "bundle",
            "qualification",
            "gates",
        },
        "Qualification policy",
    )
    if policy["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Qualification policy version must be '{PROTOCOL_VERSION}'."
        )
    _require_string(policy["id"], "Qualification policy id")

    levels = maturity_model.get("levels")
    if (
        not isinstance(levels, list)
        or [item.get("id") for item in levels] != LEVELS
    ):
        raise ProtocolError(
            f"Qualification maturity levels must be ordered as: {LEVELS}"
        )

    anchors = validate_qualification_trust(policy["trust"])
    if policy["id"] == CANONICAL_QUALIFICATION_POLICY_ID:
        operator = anchors.get(CANONICAL_OPERATOR_ANCHOR_ID)
        expected_operator = {
            "subject_identity": CANONICAL_OPERATOR_SUBJECT,
            "public_key_base64": CANONICAL_OPERATOR_PUBLIC_KEY_BASE64,
            "roles": ["accountable-operator", "independent-verifier"],
            "providers": ["elder-governance", "github-actions"],
            "source_hosts": ["github.com"],
            "status": "active",
        }
        if operator is None:
            raise ProtocolError(
                "Canonical qualification policy is missing its operator anchor."
            )
        for field, value in expected_operator.items():
            if operator.get(field) != value:
                raise ProtocolError(
                    f"Canonical operator anchor field '{field}' is not pinned."
                )
        reviewer = anchors.get(CANONICAL_REVIEWER_ANCHOR_ID)
        if reviewer is None:
            raise ProtocolError(
                "Canonical qualification policy is missing its reviewer anchor."
            )
        expected_reviewer = {
            "subject_identity": CANONICAL_REVIEWER_SUBJECT,
            "public_key_base64": CANONICAL_REVIEWER_PUBLIC_KEY_BASE64,
            "roles": ["independent-reviewer"],
            "providers": ["elder-governance"],
            "source_hosts": ["github.com"],
            "status": "active",
        }
        for field, value in expected_reviewer.items():
            if reviewer.get(field) != value:
                raise ProtocolError(
                    f"Canonical reviewer anchor field '{field}' is not pinned."
                )

    bundle_policy = _require_fields(
        policy["bundle"],
        {
            "maximum_age_days",
            "maximum_records",
            "maximum_total_bytes",
            "allowed_environments",
            "require_https_source",
            "reject_symlinks",
        },
        "Qualification bundle policy",
    )
    if (
        not isinstance(bundle_policy["maximum_age_days"], int)
        or bundle_policy["maximum_age_days"] <= 0
    ):
        raise ProtocolError(
            "Qualification bundle maximum_age_days must be a positive integer."
        )
    for field in ["maximum_records", "maximum_total_bytes"]:
        if (
            not isinstance(bundle_policy[field], int)
            or bundle_policy[field] <= 0
        ):
            raise ProtocolError(
                f"Qualification bundle {field} must be a positive integer."
            )
    _require_string_list(
        bundle_policy["allowed_environments"],
        "Qualification allowed environments",
    )
    if bundle_policy["require_https_source"] is not True:
        raise ProtocolError("Hosted qualification sources must require HTTPS.")
    if bundle_policy["reject_symlinks"] is not True:
        raise ProtocolError("Hosted qualification must reject symlinked payloads.")

    authority = _require_fields(
        policy["qualification"],
        {
            "cumulative",
            "fail_on_contradiction",
            "fail_on_untrusted_record",
            "advisory_only",
            "can_mutate_maturity",
            "can_promote",
            "can_deploy",
        },
        "Qualification authority",
    )
    required_authority = {
        "cumulative": True,
        "fail_on_contradiction": True,
        "fail_on_untrusted_record": True,
        "advisory_only": True,
        "can_mutate_maturity": False,
        "can_promote": False,
        "can_deploy": False,
    }
    if authority != required_authority:
        raise ProtocolError(
            "Hosted qualification must remain cumulative, fail closed, advisory-only, "
            "and unable to mutate maturity, promote, or deploy."
        )

    expected_requirements = {
        (level["id"], "capability", requirement)
        for level in levels
        for requirement in level["required_capabilities"]
    } | {
        (level["id"], "evidence", requirement)
        for level in levels
        for requirement in level["required_evidence"]
    }
    gates = policy["gates"]
    if not isinstance(gates, list) or not gates:
        raise ProtocolError("Qualification policy must define maturity gates.")
    gate_ids: set[str] = set()
    actual_requirements: set[tuple[str, str, str]] = set()
    for gate in gates:
        _require_fields(
            gate,
            {
                "id",
                "level",
                "requirement_kind",
                "requirement",
                "evidence_types",
                "minimum_records",
                "maximum_age_days",
                "environments",
                "required_signer_roles",
                "require_independent_verifier",
            },
            "Qualification gate",
        )
        gate_id = _require_string(gate["id"], "Qualification gate id")
        if gate_id in gate_ids:
            raise ProtocolError(f"Duplicate qualification gate: {gate_id}")
        gate_ids.add(gate_id)
        if gate["level"] not in LEVELS:
            raise ProtocolError(
                f"Qualification gate '{gate_id}' has an invalid level."
            )
        if gate["requirement_kind"] not in {"capability", "evidence"}:
            raise ProtocolError(
                f"Qualification gate '{gate_id}' has an invalid requirement_kind."
            )
        requirement = _require_string(
            gate["requirement"], f"Qualification gate '{gate_id}' requirement"
        )
        actual_requirements.add(
            (gate["level"], gate["requirement_kind"], requirement)
        )
        _require_string_list(
            gate["evidence_types"],
            f"Qualification gate '{gate_id}' evidence_types",
        )
        if (
            not isinstance(gate["minimum_records"], int)
            or gate["minimum_records"] <= 0
        ):
            raise ProtocolError(
                f"Qualification gate '{gate_id}' minimum_records must be positive."
            )
        if (
            not isinstance(gate["maximum_age_days"], int)
            or gate["maximum_age_days"] <= 0
        ):
            raise ProtocolError(
                f"Qualification gate '{gate_id}' maximum_age_days must be positive."
            )
        environments = _require_string_list(
            gate["environments"],
            f"Qualification gate '{gate_id}' environments",
        )
        unknown_environments = (
            set(environments) - set(bundle_policy["allowed_environments"])
        )
        if unknown_environments:
            raise ProtocolError(
                f"Qualification gate '{gate_id}' uses unknown environments: "
                f"{sorted(unknown_environments)}"
            )
        _require_string_list(
            gate["required_signer_roles"],
            f"Qualification gate '{gate_id}' required_signer_roles",
        )
        if gate["require_independent_verifier"] is not True:
            raise ProtocolError(
                f"Qualification gate '{gate_id}' must require an independent verifier."
            )
    if actual_requirements != expected_requirements or len(gates) != len(
        expected_requirements
    ):
        missing = sorted(expected_requirements - actual_requirements)
        unknown = sorted(actual_requirements - expected_requirements)
        raise ProtocolError(
            "Qualification gates must map every maturity requirement exactly once. "
            f"Missing: {missing}; unknown: {unknown}."
        )
    return policy


def _verify_attestation(
    attestation_value: Any,
    *,
    statement: dict[str, Any],
    anchors: dict[str, dict[str, Any]],
    provider: str,
    source_host: str,
    producer_identity: str,
    required_roles: list[str],
    at: datetime,
    label: str,
) -> str:
    attestation = _require_fields(
        attestation_value,
        {
            "signer_id",
            "algorithm",
            "signed_statement_sha256",
            "signature_base64",
        },
        f"{label} attestation",
    )
    signer_id = _require_string(
        attestation["signer_id"],
        f"{label} signer_id",
    )
    anchor = anchors.get(signer_id)
    if anchor is None or anchor["status"] != "active":
        raise ProtocolError(f"{label} signer is not an active trust anchor.")
    valid_from = _parse_datetime(
        anchor["valid_from"], f"{label} trust-anchor valid_from"
    )
    valid_until = _parse_datetime(
        anchor["valid_until"], f"{label} trust-anchor valid_until"
    )
    if at < valid_from or at >= valid_until:
        raise ProtocolError(f"{label} signer trust anchor is outside its validity window.")
    if attestation["algorithm"] != "ed25519" or anchor["algorithm"] != "ed25519":
        raise ProtocolError(f"{label} attestation algorithm is invalid.")
    if provider not in anchor["providers"]:
        raise ProtocolError(f"{label} provider is not trusted for its signer.")
    if source_host.lower() not in {
        host.lower() for host in anchor["source_hosts"]
    }:
        raise ProtocolError(f"{label} source host is not trusted.")
    if not set(required_roles) <= set(anchor["roles"]):
        raise ProtocolError(f"{label} signer lacks the required role.")
    if producer_identity == anchor["subject_identity"]:
        raise ProtocolError(f"{label} verifier must be independent.")

    statement_bytes = _canonical_bytes(statement)
    statement_sha256 = hashlib.sha256(statement_bytes).hexdigest()
    _require_sha256(
        attestation["signed_statement_sha256"],
        f"{label} signed_statement_sha256",
    )
    if attestation["signed_statement_sha256"] != statement_sha256:
        raise ProtocolError(f"{label} signed statement digest does not match.")
    try:
        signature = base64.b64decode(
            attestation["signature_base64"],
            validate=True,
        )
        public_key = Ed25519PublicKey.from_public_bytes(
            base64.b64decode(anchor["public_key_base64"], validate=True)
        )
        public_key.verify(signature, statement_bytes)
    except (ValueError, binascii.Error, InvalidSignature) as exc:
        raise ProtocolError(f"{label} signature verification failed.") from exc
    return signer_id


def verify_trusted_statement(
    attestation: dict[str, Any],
    *,
    statement: dict[str, Any],
    qualification_policy: dict[str, Any],
    provider: str,
    source_uri: str,
    producer_identity: str,
    required_roles: list[str],
    at: str,
    label: str,
) -> str:
    anchors = validate_qualification_trust(qualification_policy.get("trust"))
    parsed_uri = urlparse(_require_string(source_uri, f"{label} source_uri"))
    if parsed_uri.scheme != "https" or not parsed_uri.hostname:
        raise ProtocolError(f"{label} source_uri must be HTTPS.")
    evaluated_at = _parse_datetime(at, f"{label} verification time")
    return _verify_attestation(
        attestation,
        statement=statement,
        anchors=anchors,
        provider=_require_string(provider, f"{label} provider"),
        source_host=parsed_uri.hostname,
        producer_identity=_require_string(
            producer_identity,
            f"{label} producer_identity",
        ),
        required_roles=required_roles,
        at=evaluated_at,
        label=label,
    )


def _verify_p4_8a_governance_payload(
    payload_bytes: bytes,
    *,
    record: dict[str, Any],
    manifest: dict[str, Any],
    policy: dict[str, Any],
    anchors: dict[str, dict[str, Any]],
    at: datetime,
) -> None:
    if policy["id"] != CANONICAL_QUALIFICATION_POLICY_ID:
        return
    requirement = P4_8A_GOVERNANCE_GATES.get(record["gate_id"])
    if requirement is None:
        return
    entry_name, expected_signer, required_role = requirement
    try:
        governance = json.loads(payload_bytes)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError(
            "Canonical P4.8A governance payload must be valid JSON."
        ) from exc
    if not isinstance(governance, dict):
        raise ProtocolError("Canonical P4.8A governance payload must be an object.")
    entry = governance.get(entry_name)
    if not isinstance(entry, dict) or set(entry) != {"statement", "attestation"}:
        raise ProtocolError(
            f"Canonical P4.8A governance payload is missing {entry_name}."
        )
    statement = entry["statement"]
    if not isinstance(statement, dict):
        raise ProtocolError(f"Canonical P4.8A {entry_name} must be an object.")
    expected_bindings = {
        "project_id": manifest["project_id"],
        "environment": manifest["environment"],
        "artifact_sha256": manifest["artifact_sha256"],
        "commit_sha": manifest["source_revision"],
        "source_uri": manifest["source_uri"],
    }
    for field, value in expected_bindings.items():
        if statement.get(field) != value:
            raise ProtocolError(
                f"Canonical P4.8A {entry_name} field '{field}' is not bundle-bound."
            )
    producer_identity = (
        record["producer_identity"]
        if expected_signer == CANONICAL_OPERATOR_ANCHOR_ID
        else anchors[CANONICAL_OPERATOR_ANCHOR_ID]["subject_identity"]
    )
    signer = verify_trusted_statement(
        entry["attestation"],
        statement=statement,
        qualification_policy=policy,
        provider="elder-governance",
        source_uri=manifest["source_uri"],
        producer_identity=producer_identity,
        required_roles=[required_role],
        at=at.isoformat(),
        label=f"Canonical P4.8A {entry_name}",
    )
    if signer != expected_signer:
        raise ProtocolError(
            f"Canonical P4.8A {entry_name} was signed by the wrong identity."
        )
    if entry_name == "human_decision":
        expected_scope = [
            "remote",
            "protected-branch",
            "ci",
            "signed-provenance",
            "external-identity",
            "trust-anchors",
            "l2-qualification",
        ]
        if (
            statement.get("decision") != "approved"
            or statement.get("decided_by") != "Neel-Error404"
            or statement.get("decided_as_role") != "accountable-operator"
            or statement.get("scope") != expected_scope
        ):
            raise ProtocolError("Canonical P4.8A human decision is not approved.")
    elif entry_name == "manual_replay":
        levels = statement.get("levels")
        expected_levels = ["Foundation", "Component", "Integration", "Workflow", "Stress"]
        if (
            not isinstance(levels, list)
            or any(not isinstance(item, dict) for item in levels)
            or [item.get("level") for item in levels] != expected_levels
            or any(
                item.get("status") != "passed"
                or not isinstance(item.get("test_count"), int)
                or item["test_count"] < 1
                for item in levels
            )
        ):
            raise ProtocolError("Canonical P4.8A manual replay is incomplete.")
    elif (
        statement.get("reviewer_id") != CANONICAL_REVIEWER_SUBJECT
        or statement.get("remaining_findings")
        != {"critical": 0, "high": 0, "medium": 0}
    ):
        raise ProtocolError("Canonical P4.8A independent review is not clean.")


def _verify_record(
    record: dict[str, Any],
    *,
    manifest: dict[str, Any],
    bundle_root: Path,
    policy: dict[str, Any],
    gate: dict[str, Any],
    anchors: dict[str, dict[str, Any]],
    at: datetime,
    bundle_created_at: datetime,
) -> dict[str, Any]:
    _require_fields(
        record,
        {
            "id",
            "gate_id",
            "evidence_type",
            "provider",
            "project_id",
            "environment",
            "artifact_sha256",
            "producer_identity",
            "source_uri",
            "payload_path",
            "payload_sha256",
            "result",
            "issued_at",
            "expires_at",
            "attestation",
            "content_sha256",
        },
        "Hosted evidence record",
    )
    record_id = _require_string(record["id"], "Hosted evidence record id")
    if record["gate_id"] != gate["id"]:
        raise ProtocolError(
            f"Evidence record '{record_id}' does not match gate '{gate['id']}'."
        )
    if record["evidence_type"] not in gate["evidence_types"]:
        raise ProtocolError(
            f"Evidence record '{record_id}' has an unsupported evidence type."
        )
    _require_string(record["provider"], f"Evidence record '{record_id}' provider")
    if record["project_id"] != manifest["project_id"]:
        raise ProtocolError(
            f"Evidence record '{record_id}' project does not match its bundle."
        )
    if record["environment"] != manifest["environment"]:
        raise ProtocolError(
            f"Evidence record '{record_id}' environment does not match its bundle."
        )
    if record["environment"] not in gate["environments"]:
        raise ProtocolError(
            f"Evidence record '{record_id}' does not satisfy the gate environment."
        )
    if record["artifact_sha256"] != manifest["artifact_sha256"]:
        raise ProtocolError(
            f"Evidence record '{record_id}' artifact does not match its bundle."
        )
    _require_sha256(
        record["artifact_sha256"],
        f"Evidence record '{record_id}' artifact_sha256",
    )
    _require_string(
        record["producer_identity"],
        f"Evidence record '{record_id}' producer_identity",
    )
    parsed_uri = urlparse(
        _require_string(record["source_uri"], f"Evidence record '{record_id}' source_uri")
    )
    if parsed_uri.scheme != "https" or not parsed_uri.hostname:
        raise ProtocolError(
            f"Evidence record '{record_id}' source_uri must be HTTPS."
        )
    payload = _resolve_payload(
        bundle_root,
        record["payload_path"],
        reject_symlinks=policy["bundle"]["reject_symlinks"],
    )
    _require_sha256(
        record["payload_sha256"],
        f"Evidence record '{record_id}' payload_sha256",
    )
    payload_bytes = payload.read_bytes()
    actual_payload_sha256 = hashlib.sha256(payload_bytes).hexdigest()
    if actual_payload_sha256 != record["payload_sha256"]:
        raise ProtocolError(
            f"Evidence record '{record_id}' payload digest does not match."
        )
    _verify_p4_8a_governance_payload(
        payload_bytes,
        record=record,
        manifest=manifest,
        policy=policy,
        anchors=anchors,
        at=at,
    )
    if record["result"] not in {"passed", "failed", "revoked"}:
        raise ProtocolError(
            f"Evidence record '{record_id}' result is invalid."
        )
    issued_at = _parse_datetime(
        record["issued_at"], f"Evidence record '{record_id}' issued_at"
    )
    expires_at = _parse_datetime(
        record["expires_at"], f"Evidence record '{record_id}' expires_at"
    )
    if issued_at > at:
        raise ProtocolError(
            f"Evidence record '{record_id}' cannot be future-dated."
        )
    if issued_at > bundle_created_at:
        raise ProtocolError(
            f"Evidence record '{record_id}' cannot be issued after its bundle."
        )
    if expires_at <= issued_at:
        raise ProtocolError(
            f"Evidence record '{record_id}' must expire after it is issued."
        )
    if at > expires_at:
        raise ProtocolError(f"Evidence record '{record_id}' is expired.")
    if at - issued_at > timedelta(days=gate["maximum_age_days"]):
        raise ProtocolError(f"Evidence record '{record_id}' is stale.")
    _verify_content_digest(record, f"Evidence record '{record_id}'")

    statement = {
        key: value
        for key, value in record.items()
        if key not in {"attestation", "content_sha256"}
    }
    signer_id = _verify_attestation(
        record["attestation"],
        statement=statement,
        anchors=anchors,
        provider=record["provider"],
        source_host=parsed_uri.hostname,
        producer_identity=record["producer_identity"],
        required_roles=gate["required_signer_roles"],
        at=at,
        label=f"Evidence record '{record_id}'",
    )
    return {
        "id": record_id,
        "gate_id": gate["id"],
        "result": record["result"],
        "issued_at": issued_at,
        "signer_id": signer_id,
        "payload_sha256": record["payload_sha256"],
        "content_sha256": record["content_sha256"],
    }


def qualify_hosted_bundle(
    manifest_path: Path,
    policy: dict[str, Any],
    maturity_model: dict[str, Any],
    *,
    at: str | None = None,
) -> dict[str, Any]:
    policy = validate_qualification_policy(policy, maturity_model)
    manifest_path = manifest_path.resolve()
    if not manifest_path.is_file():
        raise ProtocolError(
            f"Hosted evidence bundle manifest does not exist: {manifest_path}"
        )
    maximum_total_bytes = policy["bundle"]["maximum_total_bytes"]
    manifest_bytes = manifest_path.stat().st_size
    if manifest_bytes > maximum_total_bytes:
        raise ProtocolError("Hosted evidence bundle exceeds its byte-size limit.")
    manifest = load_json(manifest_path)
    _require_fields(
        manifest,
        {
            "version",
            "bundle_id",
            "source_revision",
            "project_id",
            "environment",
            "target_level",
            "artifact_sha256",
            "provider",
            "producer_identity",
            "source_uri",
            "created_at",
            "expires_at",
            "records",
            "attestation",
            "content_sha256",
        },
        "Hosted evidence bundle",
    )
    if manifest["version"] != PROTOCOL_VERSION:
        raise ProtocolError(
            f"Hosted evidence bundle version must be '{PROTOCOL_VERSION}'."
        )
    bundle_id = _require_string(manifest["bundle_id"], "Hosted bundle id")
    source_revision = _require_string(
        manifest["source_revision"],
        "Hosted bundle source_revision",
    )
    if not re.fullmatch(r"(?:[a-f0-9]{40}|[a-f0-9]{64})", source_revision):
        raise ProtocolError("Hosted bundle source_revision must be a full Git object id.")
    project_id = _require_string(manifest["project_id"], "Hosted bundle project_id")
    environment = _require_string(
        manifest["environment"], "Hosted bundle environment"
    )
    if environment not in policy["bundle"]["allowed_environments"]:
        raise ProtocolError(
            f"Hosted bundle environment '{environment}' is not allowed."
        )
    target_level = manifest["target_level"]
    if target_level not in LEVELS:
        raise ProtocolError("Hosted bundle target_level is invalid.")
    artifact_sha256 = _require_sha256(
        manifest["artifact_sha256"], "Hosted bundle artifact_sha256"
    )
    provider = _require_string(manifest["provider"], "Hosted bundle provider")
    producer_identity = _require_string(
        manifest["producer_identity"], "Hosted bundle producer_identity"
    )
    source_uri = urlparse(
        _require_string(manifest["source_uri"], "Hosted bundle source_uri")
    )
    if source_uri.scheme != "https" or not source_uri.hostname:
        raise ProtocolError("Hosted bundle source_uri must be HTTPS.")
    created_at = _parse_datetime(
        manifest["created_at"], "Hosted bundle created_at"
    )
    expires_at = _parse_datetime(
        manifest["expires_at"], "Hosted bundle expires_at"
    )
    if expires_at <= created_at:
        raise ProtocolError("Hosted bundle must expire after it is created.")
    evaluated_at = (
        _parse_datetime(at, "Qualification evaluation time")
        if at is not None
        else datetime.now(UTC)
    )
    if evaluated_at > expires_at:
        raise ProtocolError("Hosted evidence bundle is expired.")
    if created_at > evaluated_at:
        raise ProtocolError("Hosted evidence bundle cannot be future-dated.")
    if evaluated_at - created_at > timedelta(
        days=policy["bundle"]["maximum_age_days"]
    ):
        raise ProtocolError("Hosted evidence bundle is stale.")
    records = manifest["records"]
    if not isinstance(records, list):
        raise ProtocolError("Hosted evidence bundle records must be a list.")
    if len(records) > policy["bundle"]["maximum_records"]:
        raise ProtocolError("Hosted evidence bundle exceeds its record-count limit.")
    record_ids = [record.get("id") for record in records if isinstance(record, dict)]
    if len(record_ids) != len(records) or any(
        not isinstance(record_id, str) or not record_id for record_id in record_ids
    ):
        raise ProtocolError("Every hosted evidence record needs an id.")
    if len(record_ids) != len(set(record_ids)):
        raise ProtocolError("Hosted evidence record ids must be unique.")
    total_bytes = manifest_bytes
    for record in records:
        payload = _resolve_payload(
            manifest_path.parent,
            record.get("payload_path"),
            reject_symlinks=policy["bundle"]["reject_symlinks"],
        )
        total_bytes += payload.stat().st_size
        if total_bytes > maximum_total_bytes:
            raise ProtocolError("Hosted evidence bundle exceeds its byte-size limit.")
    _verify_content_digest(manifest, f"Hosted evidence bundle '{bundle_id}'")

    gates = {gate["id"]: gate for gate in policy["gates"]}
    records_by_gate: dict[str, list[dict[str, Any]]] = {
        gate_id: [] for gate_id in gates
    }
    anchors = {anchor["id"]: anchor for anchor in policy["trust"]["anchors"]}
    if records:
        statement = {
            key: value
            for key, value in manifest.items()
            if key not in {"attestation", "content_sha256"}
        }
        _verify_attestation(
            manifest["attestation"],
            statement=statement,
            anchors=anchors,
            provider=provider,
            source_host=source_uri.hostname,
            producer_identity=producer_identity,
            required_roles=["independent-verifier"],
            at=evaluated_at,
            label=f"Hosted evidence bundle '{bundle_id}'",
        )
    elif manifest["attestation"] is not None:
        raise ProtocolError(
            "An empty hosted evidence bundle cannot carry a qualification attestation."
        )
    for record in records:
        gate_id = record.get("gate_id")
        if gate_id not in gates:
            raise ProtocolError(
                f"Hosted evidence record uses unknown gate: {gate_id}"
            )
        verified = _verify_record(
            record,
            manifest=manifest,
            bundle_root=manifest_path.parent,
            policy=policy,
            gate=gates[gate_id],
            anchors=anchors,
            at=evaluated_at,
            bundle_created_at=created_at,
        )
        records_by_gate[gate_id].append(verified)

    target_index = LEVELS.index(target_level)
    gate_results: list[dict[str, Any]] = []
    level_passed: dict[str, bool] = {}
    blockers: list[str] = []
    for level in LEVELS:
        level_results: list[bool] = []
        required_for_target = LEVELS.index(level) <= target_index
        for gate in [item for item in policy["gates"] if item["level"] == level]:
            verified_records = records_by_gate[gate["id"]]
            passed = sorted(
                (
                    record
                    for record in verified_records
                    if record["result"] == "passed"
                ),
                key=lambda record: record["id"],
            )
            contradictions = sorted(
                (
                    record
                    for record in verified_records
                    if record["result"] in {"failed", "revoked"}
                ),
                key=lambda record: record["id"],
            )
            gate_blockers: list[str] = []
            if contradictions:
                gate_blockers.append("contradictory-or-revoked-evidence")
            if len(passed) < gate["minimum_records"]:
                gate_blockers.append("insufficient-current-evidence")
            status = "passed" if not gate_blockers else "failed"
            level_results.append(status == "passed")
            if required_for_target:
                blockers.extend(
                    f"{gate['id']}: {blocker}" for blocker in gate_blockers
                )
            gate_results.append(
                {
                    "gate_id": gate["id"],
                    "level": level,
                    "requirement_kind": gate["requirement_kind"],
                    "requirement": gate["requirement"],
                    "required_for_target": required_for_target,
                    "status": status,
                    "accepted_record_ids": [
                        record["id"] for record in passed
                    ],
                    "contradictory_record_ids": [
                        record["id"] for record in contradictions
                    ],
                    "blockers": gate_blockers,
                }
            )
        level_passed[level] = bool(level_results) and all(level_results)

    achieved_level: str | None = None
    for level in LEVELS:
        if not level_passed[level]:
            break
        achieved_level = level
    qualified = (
        achieved_level is not None
        and LEVELS.index(achieved_level) >= target_index
        and not blockers
    )
    report = {
        "version": PROTOCOL_VERSION,
        "report_id": f"qualification-{bundle_id}",
        "bundle_id": bundle_id,
        "project_id": project_id,
        "environment": environment,
        "artifact_sha256": artifact_sha256,
        "target_level": target_level,
        "achieved_level": achieved_level,
        "canonical_current_level": maturity_model["current_assessment"]["level"],
        "qualified": qualified,
        "evaluated_at": evaluated_at.isoformat(),
        "policy_id": policy["id"],
        "policy_sha256": hashlib.sha256(_canonical_bytes(policy)).hexdigest(),
        "maturity_model_sha256": hashlib.sha256(
            _canonical_bytes(maturity_model)
        ).hexdigest(),
        "bundle_sha256": manifest["content_sha256"],
        "gate_results": gate_results,
        "blockers": sorted(set(blockers)),
        "advisory_only": True,
        "applies_maturity_mutation": False,
        "can_promote": False,
        "can_deploy": False,
    }
    report["content_sha256"] = _content_digest(report)
    return copy.deepcopy(report)
