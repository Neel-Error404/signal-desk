"""Elder Protocol validator and project-foundation compiler."""

from elder_protocol.compiler import compile_project
from elder_protocol.constants import PROTOCOL_VERSION, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.profiles import migrate_profile, validate_profile
from elder_protocol.protocol import validate_protocol

__version__ = PROTOCOL_VERSION

__all__ = [
    "PROTOCOL_VERSION",
    "ProtocolError",
    "ROOT",
    "compile_project",
    "load_json",
    "migrate_profile",
    "validate_profile",
    "validate_protocol",
]
