from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, load_json, sha256_file, write_text
from elder_protocol.knowledge import KnowledgeStore, prepare_memory_record
from elder_protocol.mem0_adapter import Mem0SemanticMemory
from elder_protocol.memory_config import load_memory_runtime_config
from elder_protocol.schema_validation import validate_against_schema


LEDGER_RELATIVE_PATH = Path(".elder/memory/trusted.json")
STORE_RELATIVE_PATH = Path(".elder/runtime/knowledge.db")
SEMANTIC_INDEX_RELATIVE_PATH = Path(".elder/runtime/memory/qdrant")
PORTABLE_MEMORY_STATUSES = {"trusted", "superseded", "revoked"}


def _paths(project_root: Path) -> tuple[Path, Path, Path]:
    if (project_root / ".elder").is_dir():
        return (
            LEDGER_RELATIVE_PATH,
            STORE_RELATIVE_PATH,
            SEMANTIC_INDEX_RELATIVE_PATH,
        )
    return (
        Path(".factory/memory/trusted.json"),
        Path(".factory/runtime/knowledge.db"),
        Path(".factory/runtime/memory/qdrant"),
    )


def _canonical_sha256(value: dict[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        ).encode("utf-8")
    ).hexdigest()


def finalize_build_memory_ledger(
    project_id: str,
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    normalized_project_id = project_id.strip()
    if not normalized_project_id:
        raise ProtocolError("Build-memory project_id cannot be empty.")
    if not isinstance(records, list):
        raise ProtocolError("Build-memory records must be a list.")

    prepared_records: list[dict[str, Any]] = []
    record_ids: set[str] = set()
    for record in records:
        prepared = prepare_memory_record(record)
        if prepared["namespace"] != normalized_project_id:
            raise ProtocolError(
                "Portable build memory must use the owning Elder project id as namespace."
            )
        if prepared["status"] not in PORTABLE_MEMORY_STATUSES:
            raise ProtocolError(
                "Portable build memory may contain only trusted, superseded, or revoked records."
            )
        if prepared["approval_id"] is None or prepared["approved_by"] is None:
            raise ProtocolError("Portable build memory requires accountable approval.")
        if prepared["approved_at"] is None:
            raise ProtocolError("Portable build memory requires approved_at.")
        if prepared["id"] in record_ids:
            raise ProtocolError(f"Duplicate portable build-memory id: {prepared['id']}")
        record_ids.add(prepared["id"])
        prepared_records.append(prepared)

    unsigned = {
        "version": PROTOCOL_VERSION,
        "project_id": normalized_project_id,
        "records": sorted(prepared_records, key=lambda item: item["id"]),
    }
    ledger = {
        **unsigned,
        "content_sha256": _canonical_sha256(unsigned),
    }
    validate_against_schema(
        ledger,
        "build-memory-ledger.schema.json",
        label="Portable build-memory ledger",
    )
    return ledger


def validate_build_memory_ledger(
    ledger: dict[str, Any],
    *,
    expected_project_id: str,
) -> dict[str, Any]:
    validate_against_schema(
        ledger,
        "build-memory-ledger.schema.json",
        label="Portable build-memory ledger",
    )
    if ledger["project_id"] != expected_project_id:
        raise ProtocolError(
            "Portable build-memory ledger belongs to a different Elder project."
        )
    rebuilt = finalize_build_memory_ledger(
        ledger["project_id"],
        ledger["records"],
    )
    if rebuilt != ledger:
        raise ProtocolError("Portable build-memory ledger digest or normalization is invalid.")
    return ledger


def ensure_build_memory_ledger(
    project_root: Path,
    project_id: str,
) -> dict[str, Any]:
    project_root = project_root.resolve()
    ledger_relative, _, _ = _paths(project_root)
    path = project_root / ledger_relative
    if not path.exists():
        ledger = finalize_build_memory_ledger(project_id, [])
        write_text(path, json_text(ledger))
        return ledger
    return validate_build_memory_ledger(
        load_json(path),
        expected_project_id=project_id,
    )


def load_build_memory_ledger(
    project_root: Path,
    project_id: str,
) -> dict[str, Any]:
    project_root = project_root.resolve()
    ledger_relative, _, _ = _paths(project_root)
    path = project_root / ledger_relative
    if not path.is_file():
        raise ProtocolError(
            "Portable build-memory ledger is missing. Restore it from version control "
            "or rerun the approved Elder compile before activation."
        )
    return validate_build_memory_ledger(
        load_json(path),
        expected_project_id=project_id,
    )


def write_build_memory_ledger(
    project_root: Path,
    project_id: str,
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    ledger = finalize_build_memory_ledger(project_id, records)
    ledger_relative, _, _ = _paths(project_root.resolve())
    write_text(project_root.resolve() / ledger_relative, json_text(ledger))
    return ledger


def record_governed_memory(
    project_root: Path,
    project_id: str,
    record: dict[str, Any],
) -> dict[str, Any]:
    prepared = prepare_memory_record(record)
    if prepared["status"] not in PORTABLE_MEMORY_STATUSES:
        raise ProtocolError(
            "Only trusted, superseded, or revoked memory belongs in the portable ledger."
        )
    ledger = load_build_memory_ledger(project_root, project_id)
    by_id = {item["id"]: item for item in ledger["records"]}
    by_id[prepared["id"]] = prepared
    return write_build_memory_ledger(
        project_root,
        project_id,
        list(by_id.values()),
    )


def project_root_for_memory_store(store_path: Path) -> Path | None:
    resolved = store_path.resolve()
    if (
        resolved.name == "knowledge.db"
        and resolved.parent.name == "runtime"
        and resolved.parent.parent.name == ".elder"
    ):
        project_root = resolved.parent.parent.parent
        if (project_root / ".elder" / "project-profile.json").is_file():
            return project_root
    return None


def _activation_record(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": record["id"],
        "kind": record["kind"],
        "content": record["content"],
        "content_sha256": record["content_sha256"],
        "confidence": record["confidence"],
        "source_evidence": record["source_evidence"],
        "review_at": record["review_at"],
    }


def prepare_build_memory_context(
    *,
    project_root: Path,
    project_id: str,
    task: str,
    env_file: Path | None = None,
    live: bool = False,
    limit: int = 8,
    semantic_memory: Mem0SemanticMemory | None = None,
) -> dict[str, Any]:
    project_root = project_root.resolve()
    ledger_relative, store_relative, semantic_index_relative = _paths(project_root)
    ledger = (
        load_build_memory_ledger(project_root, project_id)
        if (project_root / ".elder").is_dir()
        else ensure_build_memory_ledger(project_root, project_id)
    )
    store_path = project_root / store_relative
    store = KnowledgeStore(store_path)
    store.initialize()
    for record in ledger["records"]:
        store.import_governed_memory(record)

    lexical = store.query_memory(
        project_id,
        task,
        statuses=["trusted"],
        limit=limit,
    )["records"]
    selected = lexical
    semantic_report = {
        "enabled": live,
        "indexed": 0,
        "unchanged": 0,
        "recalled": 0,
    }

    owned_memory = semantic_memory
    if live:
        if owned_memory is None:
            config = load_memory_runtime_config(project_root, env_file=env_file)
            owned_memory = Mem0SemanticMemory(config, project_root)
        trusted = [
            record for record in ledger["records"] if record["status"] == "trusted"
        ]
        try:
            sync = owned_memory.sync_trusted_memories(
                project_id=project_id,
                records=trusted,
            )
            recalled = (
                owned_memory.recall_trusted(
                    project_id=project_id,
                    query=task,
                    limit=limit,
                )
                if trusted
                else []
            )
        finally:
            if semantic_memory is None:
                owned_memory.close()

        canonical = {record["id"]: record for record in trusted}
        semantic_ids: list[str] = []
        for item in recalled:
            metadata = item.get("metadata", {})
            memory_id = (
                metadata.get("elder_memory_id")
                if isinstance(metadata, dict)
                else None
            )
            if isinstance(memory_id, str) and memory_id in canonical:
                semantic_ids.append(memory_id)
        ordered_ids = list(dict.fromkeys(semantic_ids + [item["id"] for item in lexical]))
        selected = [canonical[memory_id] for memory_id in ordered_ids[:limit]]
        semantic_report = {
            "enabled": True,
            "indexed": sync["indexed"],
            "unchanged": sync["unchanged"],
            "recalled": len(semantic_ids),
        }

    return {
        "required": True,
        "authority": "elder-portable-trusted-ledger",
        "provider": "mem0-oss",
        "mode": "mem0-semantic" if live else "portable-ledger",
        "ledger_path": ledger_relative.as_posix(),
        "ledger_sha256": sha256_file(project_root / ledger_relative),
        "store_path": store_relative.as_posix(),
        "semantic_index_path": semantic_index_relative.as_posix(),
        "query": task,
        "records": [_activation_record(record) for record in selected],
        "count": len(selected),
        "semantic": semantic_report,
        "status": "ready",
    }


def close_build_memory_session(
    *,
    project_root: Path,
    activation_path: Path,
    evidence: list[tuple[str, Path]],
    env_file: Path | None = None,
    semantic_memory: Any | None = None,
) -> dict[str, Any]:
    project_root = project_root.resolve()
    activation = load_json(activation_path.resolve())
    validate_against_schema(
        activation,
        "session-activation.schema.json",
        label="Session activation",
    )
    expected_digest = canonical_sha256(
        {
            key: value
            for key, value in activation.items()
            if key != "content_sha256"
        }
    )
    if activation["content_sha256"] != expected_digest:
        raise ProtocolError("Session activation digest is invalid.")
    profile = load_json(project_root / ".elder" / "project-profile.json")
    if (
        activation["mode"] != "generated-project"
        or activation["project_id"] != profile["slug"]
    ):
        raise ProtocolError("Session activation does not belong to this Elder project.")
    if not evidence:
        raise ProtocolError("Session close requires immutable evidence.")

    from elder_protocol.dreaming import extract_memory_candidates

    store = KnowledgeStore(project_root / STORE_RELATIVE_PATH)
    store.initialize()
    report = extract_memory_candidates(
        store=store,
        project_root=project_root,
        namespace=profile["slug"],
        evidence=evidence,
        env_file=env_file,
        semantic_memory=semantic_memory,
    )
    return {
        "project_id": profile["slug"],
        "activation_id": activation["id"],
        "activation_sha256": activation["content_sha256"],
        "memory_provider": "mem0-oss",
        "candidate_count": report["count"],
        "candidate_ids": [record["id"] for record in report["proposed"]],
        "status": "candidate-memory-proposed",
    }
