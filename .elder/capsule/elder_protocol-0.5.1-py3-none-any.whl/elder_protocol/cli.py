from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from elder_protocol.activation import activate_session
from elder_protocol.assurance import build_assurance_report
from elder_protocol.autonomy import validate_autonomy_policy
from elder_protocol.autonomy_runtime import (
    canonical_p5_2_readiness,
    match_autonomy_work_item,
    replay_certification,
    simulate_autonomy_work_item,
)
from elder_protocol.canary import (
    canonical_p5_3_readiness,
    simulate_canary_plan,
)
from elder_protocol.capsule import (
    build_portable_capsule,
    install_capsule,
    verify_capsule,
    verify_installed_capsule,
)
from elder_protocol.boundaries import check_architecture_boundaries
from elder_protocol.build_memory import (
    close_build_memory_session,
    project_root_for_memory_store,
    record_governed_memory,
)
from elder_protocol.cli_parser import build_parser
from elder_protocol.compiler import compile_project
from elder_protocol.constants import PROTOCOL_DIR, SKILLS_DIR
from elder_protocol.design import validate_design_registry
from elder_protocol.dreaming import (
    accept_dreaming_candidate,
    dreaming_readiness,
    execute_dreaming,
    extract_memory_candidates,
    prepare_dreaming_workspace,
)
from elder_protocol.eval_harness import (
    calibrate_judge,
    compare_evaluations,
    run_evaluation,
    validate_evaluation_registry,
)
from elder_protocol.errors import ProtocolError
from elder_protocol.evaluation import review_transcript
from elder_protocol.factory import Factory, validate_factory_contract
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    JournalInitializer,
    JournalIntegrity,
    OperationsBackupCoordinator,
    OperationsApiRuntime,
    ProjectionQueries,
    ProjectionRuntime,
    evaluate_institutional_l2,
    load_learning_trajectory_source,
    normalize_learning_trajectory,
)
from elder_protocol.governance import validate_delegation
from elder_protocol.intake import run_intake
from elder_protocol.io import json_text, load_json, write_text
from elder_protocol.knowledge import KnowledgeStore
from elder_protocol.learning import LearningRuntime
from elder_protocol.orchestration import MultiAgentRuntime
from elder_protocol.profiles import migrate_profile, ratify_profile, validate_profile
from elder_protocol.protocol import validate_protocol
from elder_protocol.qualification import (
    qualify_hosted_bundle,
    validate_qualification_policy,
)
from elder_protocol.hosted_qualification import (
    issue_github_l2_bundle_from_provider,
)
from elder_protocol.skills import (
    create_skill,
    route_skills,
    validate_skill_registry,
)
from elder_protocol.telemetry import (
    build_telemetry_report,
    ingest_telemetry,
    load_telemetry_events,
    validate_telemetry_contract,
    write_telemetry_events,
    write_telemetry_report,
)


def _csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def _evidence_spec(value: str) -> tuple[str, Path]:
    kind, separator, path = value.partition("=")
    if not separator or not kind.strip() or not path.strip():
        raise ProtocolError("Dreaming evidence must use KIND=PATH.")
    return kind.strip(), Path(path.strip())


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "validate":
            data = validate_protocol()
            if args.profile:
                profile, notes = migrate_profile(load_json(args.profile.resolve()))
                validate_profile(profile, data)
                for note in notes:
                    print(f"Migration note: {note}")
            print("Elder Protocol validation passed.")
        elif args.command == "intake":
            data = validate_protocol()
            profile = run_intake(
                data,
                args.output.resolve(),
                args.answers.resolve() if args.answers else None,
            )
            print(
                f"Wrote draft profile for '{profile['name']}' to {args.output.resolve()}"
            )
        elif args.command == "migrate-profile":
            data = validate_protocol()
            profile, notes = migrate_profile(load_json(args.profile.resolve()))
            validate_profile(profile, data)
            write_text(args.output.resolve(), json_text(profile))
            print(f"Wrote migrated profile to {args.output.resolve()}")
            for note in notes:
                print(f"Migration note: {note}")
        elif args.command == "ratify-profile":
            data = validate_protocol()
            profile, notes = migrate_profile(load_json(args.profile.resolve()))
            ratified = ratify_profile(profile, data, args.approved_by)
            write_text(args.output.resolve(), json_text(ratified))
            print(
                f"Ratified project profile as '{args.approved_by}' "
                f"at {args.output.resolve()}"
            )
            for note in notes:
                print(f"Migration note: {note}")
        elif args.command == "compile":
            report = compile_project(
                args.profile.resolve(),
                args.output.resolve(),
                force=args.force,
                dry_run=args.dry_run,
                show_diff=args.diff,
                allow_migration=not args.no_migrate,
            )
            action = "Planned" if args.dry_run else "Compiled"
            print(f"{action} Elder project contract at: {report.output}")
            print(f"Changed files: {len(report.changes)}")
            print(f"Unchanged files: {len(report.unchanged)}")
            for note in report.migration_notes:
                print(f"Migration note: {note}")
            if args.diff and report.diff:
                print(report.diff)
        elif args.command == "capsule":
            if args.capsule_command == "build":
                report = build_portable_capsule(
                    args.output,
                    source_root=args.source_root,
                )
                print(
                    json.dumps(
                        {
                            "archive": str(report.archive),
                            "sha256": report.sha256,
                            "source_commit": report.source_commit,
                            "protocol_version": report.protocol_version,
                            "files": list(report.files),
                        },
                        indent=2,
                        sort_keys=True,
                    )
                )
            elif args.capsule_command == "verify":
                print(
                    json.dumps(
                        verify_capsule(args.archive),
                        indent=2,
                        sort_keys=True,
                    )
                )
            elif args.capsule_command == "install":
                print(
                    json.dumps(
                        install_capsule(
                            args.archive,
                            args.project_root,
                            force=args.force,
                        ),
                        indent=2,
                        sort_keys=True,
                    )
                )
            elif args.capsule_command == "status":
                print(
                    json.dumps(
                        verify_installed_capsule(args.project_root),
                        indent=2,
                        sort_keys=True,
                    )
                )
        elif args.command == "session":
            if args.session_command == "activate":
                packet = activate_session(
                    args.project_root,
                    args.task,
                    env_file=args.env_file,
                    memory_live=args.memory_live,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(packet))
                    print(f"Wrote Elder session activation to {args.output.resolve()}")
                else:
                    print(json.dumps(packet, indent=2, sort_keys=True))
            elif args.session_command == "close":
                report = close_build_memory_session(
                    project_root=args.project_root,
                    activation_path=args.activation,
                    evidence=[_evidence_spec(item) for item in args.evidence],
                    env_file=args.env_file,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "dreaming":
            if args.dreaming_command == "readiness":
                report = dreaming_readiness(
                    project_root=args.project_root,
                    env_file=args.env_file,
                    live=args.live,
                )
                print(json.dumps(report, indent=2, sort_keys=True))
                if not report["ready"]:
                    return 1
            elif args.dreaming_command == "prepare":
                request = prepare_dreaming_workspace(
                    project_root=args.project_root,
                    activation_path=args.activation,
                    evidence=[_evidence_spec(item) for item in args.evidence],
                    work_item_id=args.work_item_id,
                    trigger=args.trigger,
                    workspace=args.workspace,
                )
                print(
                    f"Prepared repository dreaming request {request['id']} "
                    f"at {args.workspace.resolve()}"
                )
            elif args.dreaming_command == "run":
                execution = execute_dreaming(
                    project_root=args.project_root,
                    workspace=args.workspace,
                    mode=args.mode,
                    env_file=args.env_file,
                )
                print(json.dumps(execution, indent=2, sort_keys=True))
            elif args.dreaming_command == "accept":
                candidate = accept_dreaming_candidate(
                    workspace=args.workspace,
                    candidate_path=args.candidate,
                    output=args.output,
                )
                print(
                    f"Accepted untrusted learning candidate {candidate['id']} "
                    f"at {args.output.resolve()}"
                )
        elif args.command == "skills":
            registry_path = getattr(
                args, "registry", PROTOCOL_DIR / "skill-registry.json"
            ).resolve()
            skills_root = getattr(args, "skills_root", SKILLS_DIR).resolve()
            if args.skills_command == "validate":
                validate_skill_registry(registry_path, skills_root)
                print("Elder skill registry validation passed.")
            elif args.skills_command == "route":
                registry = validate_skill_registry(registry_path, skills_root)
                routed = route_skills(
                    args.task,
                    registry,
                    set(_csv(args.packs)) or None,
                    args.limit,
                )
                print(json.dumps(routed, indent=2))
            elif args.skills_command == "create":
                target = create_skill(
                    skills_root,
                    registry_path,
                    args.name,
                    args.description,
                    _csv(args.capabilities),
                    _csv(args.triggers),
                    _csv(args.requires),
                    _csv(args.packs),
                    args.priority,
                )
                print(f"Created skill: {target}")
        elif args.command == "ontology":
            validate_protocol()
            print("Elder ontology validation passed.")
        elif args.command == "graph":
            graph = validate_protocol()["protocol-graph"]
            if args.output:
                output = args.output.resolve()
                write_text(output, json_text(graph))
                print(
                    f"Wrote protocol graph to {output} "
                    f"({len(graph['nodes'])} nodes, {len(graph['edges'])} edges)."
                )
            else:
                print(json.dumps(graph, indent=2))
        elif args.command == "assurance":
            data = validate_protocol()
            print(json.dumps(build_assurance_report(data), indent=2, sort_keys=True))
        elif args.command == "design":
            if args.design_command == "validate":
                report = validate_design_registry(
                    args.registry.resolve(),
                    args.root.resolve(),
                )
                print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "architecture":
            if args.architecture_command == "check":
                report = check_architecture_boundaries(
                    args.contract.resolve(),
                    args.root.resolve(),
                )
                print(json.dumps(report, indent=2, sort_keys=True))
                if report["violations"]:
                    return 1
        elif args.command == "evaluate":
            if args.evaluate_command == "transcript":
                report = review_transcript(
                    args.trace.resolve(),
                    args.policy.resolve(),
                    evaluator_id=args.evaluator_id,
                    executor_id=args.executor_id,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
                if report["verdict"] == "fail":
                    return 1
            elif args.evaluate_command == "dataset":
                report = validate_evaluation_registry(
                    args.registry.resolve(),
                    args.root.resolve(),
                )
                print(json.dumps(report, indent=2, sort_keys=True))
            elif args.evaluate_command == "calibrate":
                report = calibrate_judge(
                    args.dataset.resolve(),
                    args.judge_results.resolve(),
                    args.contract.resolve(),
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
                if not report["qualified"]:
                    return 1
            elif args.evaluate_command == "run":
                report = run_evaluation(
                    args.dataset.resolve(),
                    args.candidate.resolve(),
                    args.contract.resolve(),
                    split=args.split,
                    evaluator_id=args.evaluator_id,
                    judge_results_path=(
                        args.judge_results.resolve() if args.judge_results else None
                    ),
                    calibration_path=(
                        args.calibration.resolve() if args.calibration else None
                    ),
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
                if report["verdict"] == "fail":
                    return 1
            elif args.evaluate_command == "compare":
                report = compare_evaluations(
                    args.baseline.resolve(),
                    args.candidate.resolve(),
                    args.contract.resolve(),
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
                if report["verdict"] == "candidate-worse":
                    return 1
        elif args.command == "telemetry":
            contract = validate_telemetry_contract(args.contract.resolve())
            if args.telemetry_command == "validate":
                event_count = 0
                if args.events:
                    event_count = len(
                        load_telemetry_events(args.events.resolve(), contract)
                    )
                print(
                    json.dumps(
                        {
                            "contract_id": contract["id"],
                            "event_count": event_count,
                            "status": "passed",
                        },
                        indent=2,
                        sort_keys=True,
                    )
                )
            elif args.telemetry_command == "ingest":
                events = ingest_telemetry(
                    args.source_kind,
                    args.input.resolve(),
                    contract,
                    project_id=args.project_id,
                )
                write_telemetry_events(args.output.resolve(), events, contract)
                print(
                    json.dumps(
                        {
                            "event_count": len(events),
                            "output": str(args.output.resolve()),
                            "scopes": sorted({event["scope"] for event in events}),
                        },
                        indent=2,
                        sort_keys=True,
                    )
                )
            elif args.telemetry_command == "report":
                events = load_telemetry_events(args.events.resolve(), contract)
                report = build_telemetry_report(events, contract)
                if args.output:
                    write_telemetry_report(args.output.resolve(), report)
                print(json.dumps(report, indent=2, sort_keys=True))
                if report["verdict"] == "fail":
                    return 1
        elif args.command == "knowledge":
            store = KnowledgeStore(args.store.resolve())
            if args.knowledge_command == "init":
                report = store.initialize()
            elif args.knowledge_command == "status":
                report = store.status()
            elif args.knowledge_command == "ingest":
                report = store.ingest_graph(
                    load_json(args.graph.resolve()),
                    subject=args.subject,
                )
            elif args.knowledge_command == "query":
                report = store.query_graph(
                    args.query,
                    node_id=args.node_id,
                    authorities=_csv(args.authorities),
                    statuses=_csv(args.statuses),
                    limit=args.limit,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
            print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "memory":
            store = KnowledgeStore(args.store.resolve())
            if args.memory_command == "propose":
                report = store.propose_memory(
                    load_json(args.record.resolve()),
                    subject_role=args.subject_role,
                )
            elif args.memory_command in {
                "promote",
                "reject",
                "supersede",
                "revoke",
            }:
                approval = load_json(args.approval.resolve())
                if approval.get("action") != args.memory_command:
                    raise ProtocolError(
                        "Memory approval action must match the requested CLI command."
                    )
                report = store.transition_memory(args.memory_id, approval)
                if report["status"] in {"trusted", "superseded", "revoked"}:
                    project_root = project_root_for_memory_store(args.store)
                    if project_root is not None:
                        profile = load_json(
                            project_root / ".elder" / "project-profile.json"
                        )
                        record_governed_memory(
                            project_root,
                            profile["slug"],
                            report,
                        )
            elif args.memory_command == "query":
                report = store.query_memory(
                    args.namespace,
                    args.query,
                    statuses=_csv(args.statuses),
                    limit=args.limit,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
            elif args.memory_command == "extract":
                store.initialize()
                report = extract_memory_candidates(
                    store=store,
                    project_root=args.project_root,
                    namespace=args.namespace,
                    evidence=[_evidence_spec(item) for item in args.evidence],
                    env_file=args.env_file,
                )
            print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "context":
            if args.context_command == "assemble":
                request_path = args.request.resolve()
                store = KnowledgeStore(args.store.resolve())
                protocol = validate_protocol()
                report = store.assemble_context(
                    load_json(request_path),
                    base_dir=request_path.parent,
                    delegation=(
                        load_json(args.delegation.resolve())
                        if args.delegation
                        else None
                    ),
                    parent_run=(
                        load_json(args.parent_run.resolve())
                        if args.parent_run
                        else None
                    ),
                    authority_bindings=(
                        load_json(args.authority_bindings.resolve())
                        if args.authority_bindings
                        else None
                    ),
                    delegation_policy=(
                        protocol["delegation-policy"]
                        if args.delegation
                        else None
                    ),
                    profile=(
                        load_json(args.profile.resolve())
                        if args.profile
                        else None
                    ),
                    role_registry=(
                        protocol["role-registry"]
                        if args.delegation
                        else None
                    ),
                    authority_matrix=(
                        protocol["authority-matrix"]
                        if args.delegation
                        else None
                    ),
                )
                write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "delegation":
            if args.delegation_command == "validate":
                protocol = validate_protocol()
                profile = load_json(args.profile.resolve())
                delegation = validate_delegation(
                    load_json(args.delegation.resolve()),
                    load_json(args.parent_run.resolve()),
                    load_json(args.authority_bindings.resolve()),
                    load_json(args.policy.resolve()),
                    profile=profile,
                    role_registry=protocol["role-registry"],
                    authority_matrix=protocol["authority-matrix"],
                )
                print(
                    json.dumps(
                        {
                            "delegation_id": delegation["delegation_id"],
                            "status": "passed",
                        },
                        indent=2,
                        sort_keys=True,
                    )
                )
        elif args.command == "orchestration":
            runtime = MultiAgentRuntime(
                args.store.resolve(),
                load_json(args.policy.resolve()),
            )
            protocol = None
            if args.orchestration_command == "init":
                report = runtime.initialize()
            elif args.orchestration_command == "status":
                report = runtime.status()
            elif args.orchestration_command == "submit":
                protocol = validate_protocol()
                bundle_path = args.bundle.resolve()
                bundle = load_json(bundle_path)
                required = {
                    "profile",
                    "authority_bindings",
                    "parent_run",
                    "delegation",
                    "child_run",
                    "context_packet",
                }
                if set(bundle) != required:
                    raise ProtocolError(
                        f"Runtime submission bundle fields must be exactly: {sorted(required)}"
                    )
                report = runtime.submit(
                    parent_run=bundle["parent_run"],
                    delegation=bundle["delegation"],
                    child_run=bundle["child_run"],
                    context_packet=bundle["context_packet"],
                    context_base_dir=(
                        args.context_base_dir.resolve()
                        if args.context_base_dir
                        else bundle_path.parent
                    ),
                    profile=bundle["profile"],
                    authority_bindings=bundle["authority_bindings"],
                    delegation_policy=protocol["delegation-policy"],
                    role_registry=protocol["role-registry"],
                    authority_matrix=protocol["authority-matrix"],
                )
            elif args.orchestration_command == "claim":
                report = runtime.claim(
                    project_id=args.project_id,
                    identity_id=args.identity_id,
                    lease_seconds=args.lease_seconds,
                )
            elif args.orchestration_command in {
                "action",
                "message",
                "checkpoint",
            }:
                protocol = validate_protocol()
                record = load_json(args.record.resolve())
                runtime_kwargs = {
                    "delegation_policy": protocol["delegation-policy"],
                    "role_registry": protocol["role-registry"],
                    "authority_matrix": protocol["authority-matrix"],
                }
                if args.orchestration_command == "action":
                    report = runtime.record_action(
                        record,
                        lease_token=args.lease_token,
                        **runtime_kwargs,
                    )
                elif args.orchestration_command == "message":
                    report = runtime.record_message(
                        record,
                        lease_token=args.lease_token,
                        **runtime_kwargs,
                    )
                else:
                    report = runtime.record_checkpoint(
                        record,
                        lease_token=args.lease_token,
                        **runtime_kwargs,
                    )
            elif args.orchestration_command == "cancel":
                report = runtime.cancel(
                    load_json(args.record.resolve()),
                    lease_token=args.lease_token,
                )
            elif args.orchestration_command == "escalate":
                report = runtime.escalate(
                    load_json(args.record.resolve()),
                    lease_token=args.lease_token,
                )
            elif args.orchestration_command == "release":
                report = runtime.release(
                    run_id=args.run_id,
                    lease_token=args.lease_token,
                )
            elif args.orchestration_command == "snapshot":
                report = runtime.snapshot(args.delegation_id)
            elif args.orchestration_command == "replay":
                report = runtime.verify_replay(args.delegation_id)
            elif args.orchestration_command == "sweep":
                report = runtime.sweep(at=args.at)
            print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "learning":
            if args.learning_command == "normalize":
                source_path = args.source.resolve()
                output_path = args.output.resolve()
                same_file = source_path == output_path
                if (
                    not same_file
                    and source_path.exists()
                    and output_path.exists()
                ):
                    try:
                        same_file = source_path.samefile(output_path)
                    except OSError as exc:
                        raise ProtocolError(
                            "Learning trajectory source/output identity "
                            f"could not be verified: {exc}"
                        ) from exc
                if same_file:
                    raise ProtocolError(
                        "Learning trajectory output must differ from the source file."
                    )
                report = normalize_learning_trajectory(
                    load_learning_trajectory_source(source_path),
                    maximum_events=args.max_events,
                    maximum_bytes=args.max_bytes,
                )
                write_text(output_path, json_text(report))
            else:
                protocol = validate_protocol()
                profile = load_json(args.profile.resolve())
                validate_profile(profile, protocol)
                runtime = LearningRuntime(
                    args.store.resolve(),
                    load_json(args.policy.resolve()),
                    profile=profile,
                    role_registry=protocol["role-registry"],
                    authority_matrix=protocol["authority-matrix"],
                )
                if args.learning_command == "init":
                    report = runtime.initialize()
                elif args.learning_command == "status":
                    report = runtime.status()
                elif args.learning_command == "propose":
                    report = runtime.propose(
                        load_json(args.candidate.resolve()),
                        artifact_base=args.artifact_base.resolve(),
                    )
                elif args.learning_command == "observe":
                    report = runtime.observe(load_json(args.record.resolve()))
                elif args.learning_command == "evaluate":
                    report = runtime.evaluate(
                        args.candidate_id,
                        evaluator_id=args.evaluator_id,
                        evaluation_id=args.evaluation_id,
                        evaluated_at=args.at,
                    )
                elif args.learning_command == "decide":
                    report = runtime.decide(load_json(args.approval.resolve()))
                elif args.learning_command == "promote":
                    report = runtime.promote(
                        args.candidate_id,
                        promoted_by=args.promoted_by,
                        promotion_id=args.promotion_id,
                        created_at=args.at,
                    )
                elif args.learning_command == "rollback":
                    report = runtime.rollback(
                        args.candidate_id,
                        promoted_by=args.promoted_by,
                        promotion_id=args.promotion_id,
                        created_at=args.at,
                    )
                elif args.learning_command == "snapshot":
                    report = runtime.snapshot(args.candidate_id)
                elif args.learning_command == "replay":
                    report = runtime.verify_replay(args.candidate_id)
            print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "qualification":
            if args.qualification_command in {"validate", "evaluate"}:
                policy = load_json(args.policy.resolve())
                maturity = load_json(args.maturity.resolve())
                validate_qualification_policy(policy, maturity)
            if args.qualification_command == "validate":
                report = {
                    "policy_id": policy["id"],
                    "gate_count": len(policy["gates"]),
                    "trust_anchor_count": len(policy["trust"]["anchors"]),
                    "status": "passed",
                    "advisory_only": policy["qualification"]["advisory_only"],
                    "can_mutate_maturity": policy["qualification"][
                        "can_mutate_maturity"
                    ],
                    "can_promote": policy["qualification"]["can_promote"],
                    "can_deploy": policy["qualification"]["can_deploy"],
                }
                print(json.dumps(report, indent=2, sort_keys=True))
            elif args.qualification_command == "evaluate":
                report = qualify_hosted_bundle(
                    args.bundle.resolve(),
                    policy,
                    maturity,
                    at=args.at,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
                if not report["qualified"]:
                    return 1
            elif args.qualification_command == "institutional-l2":
                report = evaluate_institutional_l2(
                    load_json(args.packet.resolve()),
                    bundle_path=args.bundle.resolve(),
                    at=args.at,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
                if not report["qualified"]:
                    return 1
            elif args.qualification_command == "issue-github-l2":
                private_key = os.environ.get(
                    "ELDER_P4_8A_OPERATOR_PRIVATE_KEY_B64"
                )
                if not private_key:
                    raise ProtocolError(
                        "Independent L2 issuance requires "
                        "ELDER_P4_8A_OPERATOR_PRIVATE_KEY_B64."
                    )
                reviewer_public_key = os.environ.get(
                    "ELDER_P4_8A_REVIEWER_PUBLIC_KEY_B64"
                )
                if not reviewer_public_key:
                    raise ProtocolError(
                        "Independent L2 issuance requires the out-of-band "
                        "ELDER_P4_8A_REVIEWER_PUBLIC_KEY_B64 pin."
                    )
                report = issue_github_l2_bundle_from_provider(
                    output_dir=args.output_dir,
                    governance_evidence_path=args.governance_evidence,
                    private_key_base64=private_key,
                    reviewer_public_key_base64=reviewer_public_key,
                    repository=args.repository,
                    run_id=args.run_id,
                    run_attempt=args.run_attempt,
                )
                print(json.dumps(report, indent=2, sort_keys=True))
        elif args.command == "autonomy":
            registry = load_json(args.classes.resolve())
            policy = load_json(args.policy.resolve())
            if args.autonomy_command == "replay":
                certification = load_json(args.certification.resolve())
                autonomy_class = next(
                    (
                        item
                        for item in registry["classes"]
                        if item["id"] == certification["autonomy_class_id"]
                    ),
                    None,
                )
                if autonomy_class is None:
                    raise ProtocolError(
                        "Certification references an unknown autonomy class."
                    )
                event_set = load_json(args.events.resolve())
                if set(event_set) != {"events"} or not isinstance(
                    event_set["events"], list
                ):
                    raise ProtocolError(
                        "Certification event file must contain exactly an events list."
                    )
                report = replay_certification(
                    certification,
                    autonomy_class,
                    event_set["events"],
                    policy=policy,
                    at=args.at,
                )
                if args.output:
                    write_text(args.output.resolve(), json_text(report))
                print(json.dumps(report, indent=2, sort_keys=True))
            else:
                qualification_policy = load_json(
                    args.qualification_policy.resolve()
                )
                validate_autonomy_policy(
                    policy,
                    registry,
                    load_json(args.change_classes.resolve()),
                    qualification_policy=qualification_policy,
                    maturity_model=load_json(args.maturity.resolve()),
                )
                if args.autonomy_command == "validate":
                    report = {
                        "policy_id": policy["id"],
                        "mode": policy["mode"],
                        "class_registry_id": registry["id"],
                        "class_count": len(registry["classes"]),
                        "hard_stops": policy["effective_autonomy"]["hard_stops"],
                        "simulation_mode": policy["simulation"]["mode"],
                        "required_pr_level": policy["supervised_pr"][
                            "required_effective_level"
                        ],
                        "required_canary_level": policy["canary"][
                            "required_effective_level"
                        ],
                        "authority_activated": False,
                        "can_create_pr_when_qualified": policy["authority"][
                            "can_create_pr"
                        ],
                        "can_execute_canary_when_qualified": policy["authority"][
                            "can_execute_canary"
                        ],
                        "can_promote_canary": policy["authority"][
                            "can_promote_canary"
                        ],
                        "can_merge": policy["authority"]["can_merge"],
                        "can_deploy": policy["authority"]["can_deploy"],
                        "status": "passed",
                    }
                elif args.autonomy_command in {"match", "simulate"}:
                    work_item = load_json(args.work_item.resolve())
                    certification = load_json(args.certification.resolve())
                    function = (
                        match_autonomy_work_item
                        if args.autonomy_command == "match"
                        else simulate_autonomy_work_item
                    )
                    report = function(
                        work_item,
                        registry,
                        certification=certification,
                        policy=policy,
                    )
                    if args.output:
                        write_text(args.output.resolve(), json_text(report))
                elif args.autonomy_command == "canary-simulate":
                    report = simulate_canary_plan(
                        load_json(args.plan.resolve()),
                        policy,
                    )
                    if args.output:
                        write_text(args.output.resolve(), json_text(report))
                elif args.autonomy_command == "readiness":
                    factory = Factory(args.factory_contract.resolve())
                    report = canonical_p5_2_readiness(
                        policy,
                        qualification_policy=qualification_policy,
                        factory_status=factory.status(),
                        active_authority_source_present=any(
                            project["status"] == "active"
                            for project in load_json(
                                PROTOCOL_DIR / "autonomy-authority-source.json"
                            )["projects"]
                        ),
                        active_certification_present=False,
                        valid_l2_consumption_present=False,
                    )
                elif args.autonomy_command == "canary-readiness":
                    factory = Factory(args.factory_contract.resolve())
                    authority_source = load_json(
                        PROTOCOL_DIR / "autonomy-authority-source.json"
                    )
                    report = canonical_p5_3_readiness(
                        policy,
                        qualification_policy=qualification_policy,
                        factory_status=factory.status(),
                        active_authority_source_present=any(
                            project["status"] == "active"
                            for project in authority_source["projects"]
                        ),
                        active_certification_present=False,
                        valid_l3_consumption_present=False,
                        l3_capable_class_present=any(
                            item["maximum_autonomy"] == "L3"
                            for item in registry["classes"]
                        ),
                        secret_broker_verified=False,
                        central_telemetry_verified=False,
                        rollback_verified=False,
                    )
                else:
                    raise ProtocolError(
                        f"Unsupported autonomy command: {args.autonomy_command}"
                    )
                print(json.dumps(report, indent=2, sort_keys=True))
                if args.autonomy_command in {
                    "match",
                    "simulate",
                    "canary-simulate",
                } and (
                    report.get("matched") is False
                    or report.get("status") == "blocked"
                ):
                    return 1
        elif args.command == "factory":
            if args.factory_command == "operations-init":
                print(
                    json.dumps(
                        FactoryOperationsBootstrap(
                            args.store.resolve()
                        ).initialize(),
                        indent=2,
                        sort_keys=True,
                    )
                )
                return 0
            if args.factory_command == "operations-status":
                queries = ProjectionQueries(args.store.resolve())
                print(
                    json.dumps(
                        {
                            "journal": JournalInitializer(
                                args.store.resolve()
                            ).status(),
                            "projections": queries.get_projection_status(),
                            "capabilities": (
                                queries.get_capability_status()
                            ),
                        },
                        indent=2,
                        sort_keys=True,
                    )
                )
                return 0
            if args.factory_command == "operations-verify":
                print(
                    json.dumps(
                        JournalIntegrity(args.store.resolve()).verify(),
                        indent=2,
                        sort_keys=True,
                    )
                )
                return 0
            if args.factory_command == "operations-rebuild":
                runtime = ProjectionRuntime(args.store.resolve())
                if args.projection == "all":
                    report = runtime.rebuild_all(
                        batch_size=args.batch_size
                    )
                else:
                    report = runtime.rebuild_projection(
                        args.projection,
                        batch_size=args.batch_size,
                    )
                print(json.dumps(report, indent=2, sort_keys=True))
                return 0
            if args.factory_command == "operations-events":
                cursor = (
                    load_json(args.cursor.resolve())
                    if args.cursor
                    else None
                )
                report = JournalIntegrity(
                    args.store.resolve()
                ).read_public_events(
                    project_id=args.project_id,
                    cursor=cursor,
                    limit=args.limit,
                )
                print(json.dumps(report, indent=2, sort_keys=True))
                return 0
            if args.factory_command == "operations-backup":
                report = OperationsBackupCoordinator(
                    args.store.resolve()
                ).create(
                    args.output_root.resolve(),
                    backup_id=args.backup_id,
                )
                print(json.dumps(report, indent=2, sort_keys=True))
                return 0
            if args.factory_command == "operations-backup-verify":
                report = OperationsBackupCoordinator.verify_backup(
                    args.backup.resolve()
                )
                print(json.dumps(report, indent=2, sort_keys=True))
                return 0
            if args.factory_command == "operations-restore":
                report = OperationsBackupCoordinator.restore(
                    args.backup.resolve(),
                    args.target.resolve(),
                )
                print(json.dumps(report, indent=2, sort_keys=True))
                return 0
            if args.factory_command == "operations-api":
                runtime = OperationsApiRuntime(
                    store_path=args.store.resolve(),
                    auth_policy_path=args.auth_policy.resolve(),
                    host=args.host,
                    port=args.port,
                    session_store_path=(
                        args.session_store.resolve()
                        if args.session_store
                        else None
                    ),
                    recovery_store_path=(
                        args.recovery_store.resolve()
                        if args.recovery_store
                        else None
                    ),
                )
                print(
                    json.dumps(runtime.status(), indent=2, sort_keys=True),
                    flush=True,
                )
                try:
                    runtime.serve_forever()
                except KeyboardInterrupt:
                    runtime.close()
                return 0
            contract_path = args.contract.resolve()
            if args.factory_command == "validate":
                validate_factory_contract(contract_path)
                print(f"Elder factory contract validation passed: {contract_path}")
            else:
                state_root = getattr(args, "state_root", None)
                factory = Factory(
                    contract_path,
                    state_root_override=state_root.resolve() if state_root else None,
                )
                if args.factory_command == "status":
                    print(json.dumps(factory.status(), indent=2, sort_keys=True))
                elif args.factory_command == "build":
                    result = factory.build()
                    payload = result.to_dict()
                    if args.report:
                        write_text(args.report.resolve(), json_text(payload))
                    print(json.dumps(payload, indent=2, sort_keys=True))
                elif args.factory_command == "verify":
                    print(
                        json.dumps(
                            factory.verify(args.digest),
                            indent=2,
                            sort_keys=True,
                        )
                    )
                elif args.factory_command == "worktree-create":
                    print(factory.create_worktree(args.work_item))
                elif args.factory_command == "worktree-remove":
                    factory.remove_worktree(args.work_item)
                    print(f"Removed worktree: {args.work_item}")
                elif args.factory_command == "promote":
                    print(
                        json.dumps(
                            factory.promote(
                                args.digest,
                                args.environment,
                                approval_path=args.approval.resolve(),
                            ),
                            indent=2,
                            sort_keys=True,
                        )
                    )
                elif args.factory_command == "rollback":
                    print(
                        json.dumps(
                            factory.rollback(
                                args.environment,
                                approval_path=args.approval.resolve(),
                            ),
                            indent=2,
                            sort_keys=True,
                        )
                    )
        return 0
    except ProtocolError as exc:
        print(f"Elder Protocol error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
