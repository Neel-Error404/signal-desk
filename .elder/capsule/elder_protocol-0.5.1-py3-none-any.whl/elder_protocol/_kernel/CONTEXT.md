# Elder Domain Language

## Elder Protocol

The protected rules and contracts that govern how a project is framed, generated, changed,
verified, operated, and improved.

Avoid: using "template" when referring to the whole system.

## Protocol Compiler

A tool that resolves a project profile and selected capability packs into a project-specific
operating contract. It does not decide product intent on behalf of humans.

## Factory Kernel

The product-agnostic Elder constitution, compiler, protocol graph, contracts, and factory
controls shared across generated projects.

Avoid: treating a reference project or one technology stack as the factory kernel.

## Hierarchical Meta-Architecture

The canonical layering of universal kernel, capability packs, stack adapters, project
implementation, factory operations, and assurance and learning.

## Project Profile

The explicit description of a project's mission, risk, topology, lifecycle, project identities,
autonomy ceiling, languages, deployment targets, and selected capability packs.

## Capability Pack

A conditional contract containing responsibilities, required artifacts, evidence, skills,
interfaces, and stack-adapter points for a project category.

## Stack Adapter

A governed translation from capability-pack requirements into technology-specific practices for
a language, framework, provider, datastore, toolchain, or deployment environment.

## Protocol Graph

The deterministic graph connecting Elder layers, packs, capabilities, skills, schemas,
invariants, authority, change classes, artifacts, and evidence requirements.

## Project Graph

The generated overlay containing one project's selected packs, skills, knowledge sources,
governance constraints, and required evidence.

## Reference Project

An executable product used to prove selected Elder contracts. It is not the universal product
template and does not make unselected capabilities operational.

## Invariant

A stable rule that protects system integrity and has an owner, scope, enforcement mechanism,
verification method, and exception authority.

## Change Class

A category that determines a change's minimum evidence, approval requirements, and maximum
allowed autonomy.

## Authority

The permission to propose, modify, approve, execute, or promote an operation. Tool availability
does not imply authority.

## Resolved Obligation

A selected capability-pack requirement bound to a canonical owner role, project identity,
required artifact type, evidence levels, evidence references, and current status.

## Delegation

A digest-bound contract that lets one parent agent run assign a narrower objective, scope,
authority, tools, budget, deadline, evidence requirement, checkpoint policy, and escalation path
to one child identity.

## Agent Identity

A project-scoped human, agent, or service identity bound to one or more canonical roles.

## Checkpoint

An immutable progress, budget, scope, and evidence record for a delegated agent run.

## Runtime Lease

A short-lived local capability issued only to the identity assigned by a validated delegation.
Its raw token is returned to the claimant while only its digest is persisted.

## Agent Action

A typed immutable record of one delegated resource action, optional tool, evidence, timing, and
incremental budget consumption.

## Bounded Multi-Agent Runtime

The transactional local coordinator that submits validated delegation chains, dispatches them
through assigned-identity leases, persists append-only journals, propagates cancellation, and
verifies deterministic lifecycle replay. It does not authenticate external identities or
execute model and tool providers.

## Autonomy Ceiling

The highest autonomy level a project permits. Each change class may impose a lower ceiling.

## Evidence

An artifact that supports a claim: test output, trace, review, signed build record, runtime
observation, user outcome, or other reproducible result.

## Trace

A linked record of intent, context, actions, outputs, approvals, artifacts, deployment, and
observed outcome.

## Learning Candidate

A proposed memory, skill, policy, evaluator, or architectural change derived from evidence. It
is untrusted until separately evaluated and promoted.

## Operational

Implemented, executable in the intended environment, and verified with current evidence.

Avoid: treating a document, placeholder, or configured-but-unrun workflow as operational.

## Factory Contract

The machine-readable definition of source inputs, ordered checks, artifact contents, Git policy,
workspace paths, identity boundaries, and promotion transitions.

## Content-Addressed Artifact

An immutable build output identified by the SHA-256 digest of its exact bytes. Environment
promotion changes pointers and records; it does not rebuild the artifact.

## Workload Identity

A short-lived identity issued from an external trust relationship for one workload and purpose.
An environment variable containing a long-lived token is not workload identity.

## Recommendation Ledger

The machine-readable mapping from an adopted source principle to architecture layers, controls,
required artifacts, evidence, operational status, and known gaps.

## Slop

Output that is produced faster than accountable humans or agents can understand, verify, operate,
or maintain. Code volume alone does not determine slop; missing intent, boundaries, traces, and
ownership do.

## Judgment And Taste

Evidence-cited assessment of outcome fit, coherence, simplicity, changeability, operability,
user trust, and evidence quality. It is probabilistic or human evaluation and cannot override a
deterministic control failure.

## Operational Maturity

The highest factory behavior claim supported by current capabilities and evidence for a declared
scope. Partial implementation of a higher level does not raise the overall claim.

## Autonomy Class

A narrow reversible subclass of an existing change class with explicit path, operation, tool,
evidence, incident-budget, expiry, suspension, revocation, and renewal boundaries.

## Autonomy Certification

A project, environment, class, scope, tool, qualification, evidence, and time-bound decision
that may consume verified maturity but cannot create or reinterpret it.

## Qualification Consumption

A deterministic re-verification of a P4.7 bundle against approved qualification-policy,
maturity-model, and trust-anchor-set digests for one autonomy request.

## Effective Autonomy

The minimum of verified hosted maturity, project autonomy ceiling, selected autonomy-class maximum,
and active certification level after hard-stop checks. Invalid qualification, expiry,
suspension, revocation, contradiction, or exhausted incident budget resolves to no authority.

## Incident Budget

A class-specific windowed limit for incidents and rollbacks. Exhaustion suspends the associated
autonomy certification.

## Autonomy Authority Lease

A short-lived, work-item-bound permission to create one supervised pull request. It is derived
from signed-bundle qualification re-verification, active certification lifecycle replay,
trusted-source effective-autonomy, match, and simulation recomputation, and current hard-stop
checks. A caller-provided report is evidence to compare, not authority to trust.

## Supervised Pull-Request Packet

An immutable packet reconstructed from one validated authority lease and one exact execution
record. Submission revalidates its digest, project and work-item bindings, current lease,
qualification, certification, paths, operations, and before/after content digests before calling
the hosted provider. The execution consumes independently signed hosted Git evidence, and the
provider response must echo the packet digest, authorized repository, branches, full Git object
identifiers, and diff digest. It grants no merge or release authority.

## Git Revision

A full Git object identifier interpreted under an explicit repository object format. SHA-1
repositories use 40 lowercase hexadecimal characters and SHA-256 repositories use 64. Git object
identifiers are not SHA-256 content or diff digests.

## Design Registry

A hash-bound index of governed design documents, their status, owners, applicable change classes,
notification audience, and supersession relationships.

## Architecture Boundary Adapter

A deterministic implementation that translates a machine-readable dependency contract into
stack-specific checks. P4.1 provides the first adapter for Python AST imports.

## Transcript Review

An independent advisory evaluation of an immutable execution trace. It may report findings and a
verdict but cannot approve, promote, mutate the trace, or modify evaluator policy.

## Evaluation Dataset

A governed, content-hash-bound set of cases with explicit provenance, sensitivity, thresholds,
risk slices, and separate development, calibration, and holdout splits.

## Evaluator Calibration

Evidence that a rubric judge meets declared accuracy, F1, abstention, identity-separation, and
dataset-revision thresholds against human reference labels.

## Evaluation Comparison

A paired case-level comparison of a candidate and baseline, including score, pass-rate, cost,
latency, tool-call, and critical-regression evidence. It is advisory-only.

## Correlated Telemetry

A provider-neutral event model connecting product, model, tool, factory, cost, and outcome
signals through valid trace context plus project and run identifiers. Work-item, agent-run,
artifact, deployment, evaluation, and outcome identifiers remain event correlation fields rather
than metric dimensions.

## Telemetry Budget

An advisory deterministic check over cost, error rate, latency, correlation completeness, and
metric cardinality. A failed budget blocks a claim; a passing budget cannot approve or promote.

## Governed Knowledge Runtime

A persistent provider-neutral store that keeps provenance-bound graph entities, relationships,
memory records, and audit events. The local SQLite adapter is a reference implementation, not a
claim of hosted multi-tenant production durability.

## Candidate Memory

A scoped episodic, semantic, or procedural learning proposal with source evidence and expiry.
It is not trusted context until independently approved by an accountable human owner.

## Trusted Memory

A promoted memory record with independent human approval, provenance, review time, namespace,
and lifecycle state. Retrieval does not give it more authority than its sources.

## Context Packet

A digest-bound immutable assembly of selected source content, provenance, assumptions, budget
usage, and explicit exclusions. Required sources fail closed when missing, stale, unauthorized,
or too large.
