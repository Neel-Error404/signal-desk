# AGENTS.md

Repository-local operating contract for Elder Protocol.

## Mission

Build a protocol compiler that gives projects explicit outcomes, authority boundaries,
architecture invariants, evidence requirements, and bounded autonomy.

## Current Phase

`P5.3 - Fail-Closed Canary Mechanisms (Canonical Authority Inactive)`

P0 through P4.7 are implemented for their declared local or contract scope. P4.4 provides a transactional
local graph and memory store, independent human promotion of trusted memory, deterministic
authority-filtered context assembly, and digest-bound context packets. P4.5A provides canonical
roles and project identities, resolved obligations, delegation contracts, parent-child run
relationships, checkpoints, and fail-closed fixtures. P4.5B provides a transactional local
coordinator with assigned-identity leases, typed action and message journals, digest-linked
checkpoints, cancellation propagation, expiry, and deterministic lifecycle replay. P4.6 provides
a transactional local learning store with immutable candidate artifacts, side-effect-free replay
and shadow observations, independent evaluation, accountable approval, separate promotion,
rollback packets, and deterministic journal replay. P4.7 provides signed hosted evidence bundle
verification and cumulative maturity gates. P4.8A configures separate operator and reviewer
trust anchors, a private GitHub remote, successful hosted CI, provider OIDC verification,
reproducible artifact evidence, and independently signed provenance. Elder remains canonically
L1 because hosted qualification is advisory and has not been human-ratified. P4.8A issued and
canonically replayed an advisory L2 bundle for exact commit
`d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`. P5.0 defines five initial
autonomy subclasses and effective-autonomy contracts. P5.1 adds exact structured work-item
matching, side-effect-free simulation, certification replay, and incident accounting. P5.2 adds
an L2-gated short-lived authority lease and supervised pull-request packet whose authority chain
is reconstructed from the signed qualification bundle, certification lifecycle, source work
item, exact execution evidence, and current hard-stop checks before provider invocation. Humans
retain merge and release. Authority source records come from a current independently signed
governance statement that must match the repository-owned canonical authority-source registry.
Hosted workspace, exact file changes, tests, evaluator evidence, and controls come from current
independently signed provider evidence, and the accepted provider
response is bound to the exact authorized packet, repository, branches, Git object identifiers,
diff, and trusted repository URL prefix. Canonical P5.2 activation remains blocked because no
active authority source or certification exists and the base branch is not protected. P5.3 adds
side-effect-free canary-plan simulation, separately governed project class registries capped at
L3, L3-only canary leases, signed provider controls, exact deployment-response and observation
binding, and rollback-required threshold evaluation. Canonical P5.3 authority remains inactive
because there is no valid L3 consumption, L3-capable canonical class certification, secret
broker, central production telemetry, or verified automatic rollback. Do not claim hosted
knowledge durability, vector search, autonomous memory consolidation, tenant isolation,
distributed multi-agent orchestration or hosted checkpoints, external runtime identity
authentication, a hosted collector, production retention or alerting, hosted evaluator
isolation, live model-provider evaluation, protected hosted Git rules, GitHub-native persisted
attestations, secret brokering, or production deployment without direct evidence.

## Truth Order

1. Executable behavior and current test results.
2. Machine-readable files under `protocol/`.
3. `ELDER_PROTOCOL.md` and accepted ADRs.
4. Roadmaps and unimplemented design documents.

Allowed status labels: `VERIFIED`, `IMPLEMENTED`, `SPECIFIED`, `PLANNED`, `BLOCKED`.

## Codex Session Activation

Codex loads this file automatically only when the session starts inside this repository's Git
scope. Before governed implementation, activate Elder explicitly:

```powershell
py -m elder_protocol.cli session activate `
  --project-root . `
  --task "<current user request>" `
  --output .tmp/session-activation.json
```

Do not begin governed edits when activation fails. Use the packet's routed skill entries,
instruction-source digests, sandbox boundary, test order, and repository-dreaming policy. The
project `.codex/config.toml` defaults Codex to workspace-write, on-request approval, and no
sandbox network access. Elder still enforces delegated leases and journals only for actions
submitted through Elder runtimes; it does not intercept every direct shell or edit call.

## Protected Surfaces

Agents may propose changes to these files but must not treat their own edits as approved:

- `ELDER_PROTOCOL.md`
- `protocol/invariants.json`
- `protocol/recommendation-ledger.json`
- `protocol/judgment-rubric.json`
- `protocol/operational-maturity.json`
- `protocol/design-registry.json`
- `protocol/transcript-review-policy.json`
- `protocol/evaluation-registry.json`
- `protocol/evaluation-dataset.json`
- `protocol/evaluator-contract.json`
- `protocol/telemetry-contract.json`
- `protocol/context-policy.json`
- `protocol/memory-policy.json`
- `protocol/learning-policy.json`
- `protocol/repository-dreaming-policy.json`
- `protocol/qualification-policy.json`
- `protocol/autonomy-authority-source.json`
- `protocol/autonomy-policy.json`
- `protocol/autonomy-classes.json`
- `protocol/authority-matrix.json`
- `protocol/role-registry.json`
- `protocol/delegation-policy.json`
- `protocol/change-classes.json`
- `protocol/meta-architecture.json`
- `protocol/capability-packs.json`
- accepted ADRs under `docs/adr/`

`protocol/protocol-graph.json` is generated from protocol truth. Update its
sources and regenerate it rather than editing graph relationships directly.

Constitutional changes require a new ADR, explicit human approval, updated tests, and a version
change.

## Writable Surfaces

Agents may edit implementation, tests, draft documents, examples, and generated outputs within
the current approved scope. Generated output belongs under `.tmp/` or a user-selected target and
must not silently overwrite a non-empty project.

## Development Protocol

1. Establish the intended outcome and change class.
2. Read the relevant protocol manifest and ADR.
3. Define evidence and failure conditions.
4. Implement the smallest coherent change.
5. Test in order: Foundation, Component, Integration, Workflow, Stress.
6. Re-run the same failed level after fixing its root cause.
7. Update readiness claims only when evidence exists.

## Git Protocol

- Never stage, commit, push, reset, clean, or rewrite history without explicit permission.
- One work item and one concern per branch or stacked PR.
- Record the change class and evidence in the PR description.
- The authoring agent cannot be the sole evaluator or promoter for governed changes.

## Error Handling

- Raise explicit, actionable errors.
- Do not silently fall back to weaker behavior.
- Do not create or expose secrets.
- Do not claim software-factory maturity above the current evidence-bound assessment.
- Probabilistic review may discover issues but cannot override deterministic failures.
- Keep registered design-document hashes current and review the intentional diff.
- Architecture-boundary and transcript-review findings are evidence; they do not grant authority.
- Evaluation and comparison reports are advisory evidence; they do not grant authority.
- Reject rubric results that are not bound to a qualified calibration and dataset revision.
- Reject telemetry that contains secret-shaped fields or correlation IDs as metric dimensions.
- Reject required context that is stale, unauthorized, missing, or outside the declared budget.
- Reject delegations that expand parent scope, authority, tools, budget, deadline, or identity.
- Treat messages and checkpoints as evidence; they cannot directly mutate governed state.
- Require the assigned child lease before accepting child-originated runtime operations.
- Verify runtime event and checkpoint replay before making a P4.5B operational claim.
- Verify candidate artifact bytes, learning rows, event replay, and authority separation before
  making a P4.6 operational claim.
- Verify bundle and record digests, payload bytes, Ed25519 signatures, signer trust, source host,
  freshness, project, environment, artifact, contradictions, and cumulative gates before making
  a P4.7 hosted qualification claim.
- Qualification reports cannot mutate maturity, approve, promote, deploy, or replace accountable
  human authority.
- Re-verify the approved pinned qualification policy, maturity model, trust-anchor set, evidence
  records, signatures, payloads, freshness, and contradictions before consuming P4.7 evidence.
- Certification can consume verified hosted maturity but cannot create, update, or reinterpret it.
- Resolve effective autonomy to none when qualification is invalid or expired, certification is
  suspended or revoked, a newer contradiction exists, or the incident budget is exhausted.
- P5.1 matching, simulation, replay, and incident accounting cannot mutate a workspace or create
  a pull request.
- P5.2 can issue a PR-scoped lease only after re-running signed-bundle hosted L2 qualification,
  resolving the project from the repository-owned canonical authority source, verifying an
  independently signed complete governance-source statement against that source, replaying
  certification lifecycle state, and recomputing effective autonomy, exact matching, and
  simulation from trusted sources.
- Before PR provider invocation, reconstruct and validate the lease and packet, current lease
  expiry, project and work-item bindings, exact execution content, current qualification hard
  stops, ordered tests, independent evaluation, independently signed hosted execution and Git
  governance, and external identity. Reject any provider response that does not echo the authorized
  packet digest, repository, branches, Git object identifiers, and diff exactly or whose URL does
  not match the trusted repository prefix and pull-request identifier.
- Context assembly may retrieve only query-matched, policy-capped graph sources; wildcard,
  empty-term, or wholesale graph injection is forbidden.
- P5.2 cannot merge, deploy, mutate maturity, or auto-renew; humans retain merge and release.
- P5.3 can start only one exactly bound canary under current L3 qualification, an active
  L3-capable project class certification, signed provider identity, secret-broker, telemetry,
  immutable-artifact, promotion-gate, and rollback evidence. Reconstruct the lease and packet and
  re-verify current qualification before provider invocation.
- Bind every accepted canary response and signed observation to the exact packet, provider,
  target, artifact pair, deployment identifier, URL prefix, traffic allocation, and execution
  time. Any health, sample, or maximum-duration breach requires rollback.
- Healthy canary evidence can only continue observation. P5.3 cannot promote, perform full
  rollout, merge, mutate maturity, or auto-renew.
- Learning promotion packets cannot mutate memory, skills, policy, evaluators, architecture, or
  production directly.
- Candidate memory cannot be retrieved as trusted memory or promoted by its owner.
- Fail closed when authority, profile validity, or output safety is uncertain.

## Commands

```powershell
py -m elder_protocol.cli validate
py -m elder_protocol.cli skills validate
py -m elder_protocol.cli session activate --project-root . --task "<current user request>" --output .tmp/session-activation.json
py -m elder_protocol.cli dreaming readiness --project-root . --env-file .env --live
py -m elder_protocol.cli dreaming run --project-root . --env-file .env --workspace <workspace> --mode routine
py -m elder_protocol.cli intake --answers examples/intake-answers.json --output .tmp/profile.json
py -m elder_protocol.cli compile --profile .tmp/profile.json --output .tmp/example --dry-run --diff
py -m elder_protocol.cli factory status
py -m elder_protocol.cli factory build --report .factory/latest-build.json
py -m elder_protocol.cli evaluate dataset
py -m elder_protocol.cli knowledge status --store .tmp\knowledge.db
py -m elder_protocol.cli context assemble --store .tmp\knowledge.db --request <request.json>
py -m elder_protocol.cli context assemble --store .tmp\knowledge.db --request <delegated-request.json> --delegation <delegation.json> --parent-run <run.json> --authority-bindings <bindings.json> --profile <project-profile.json> --output <packet.json>
py -m elder_protocol.cli delegation validate --delegation <delegation.json> --parent-run <run.json> --authority-bindings <bindings.json> --profile <project-profile.json>
py -m elder_protocol.cli orchestration status --store <runtime.db>
py -m elder_protocol.cli orchestration replay --store <runtime.db> --delegation-id <delegation-id>
py -m elder_protocol.cli learning status --store <learning.db>
py -m elder_protocol.cli qualification validate
py -m elder_protocol.cli qualification evaluate --bundle <bundle.json> --output <report.json>
py -m elder_protocol.cli autonomy validate
py -m elder_protocol.cli autonomy canary-readiness
py -m elder_protocol.cli learning replay --store <learning.db> --profile <project-profile.json> --candidate-id <candidate-id>
py -m unittest discover -s tests/foundation -v
```

## Memory Routing

- Code, manifests, and tests are implementation truth.
- ADRs explain hard-to-reverse decisions.
- Obsidian is the cross-project routing layer after a meaningful milestone.
- Do not duplicate long project history into this file.
- Vault: `D:/Balcony/Obsidian`
- Memory contract:
  `D:/Balcony/Obsidian/01-Operating-System/Memory Contract.md`
- Integration registry:
  `D:/Balcony/Obsidian/01-Operating-System/Project Integration Registry.md`
- Project note: `D:/Balcony/Obsidian/02-Projects/Elder Protocol.md`
- Current evidence entrypoints: `ELDER_PROTOCOL.md`, `protocol/`,
  `docs/software-factory/`, and the relevant evidence file under `docs/`.

Elder Protocol does not currently use a canonical `founder_logs/` tree. Update
protocol/docs evidence first, then keep the vault note to current state, latest
decision, next action, and links.
