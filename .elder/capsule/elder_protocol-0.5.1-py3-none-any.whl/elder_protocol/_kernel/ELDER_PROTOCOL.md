# Elder Protocol Constitution

**Version:** 0.3.8
**Status:** Amended through ADR 0022 on 2026-08-14 under explicit human-owner instruction
**Authority:** Human-ratified constitutional document
**Amendment:** ADR, impact analysis, explicit approval, test update, and version change

## Purpose

Elder governs progressively autonomous project organizations. It coordinates product intent,
software engineering, agent execution, delivery, operations, learning, economics, and
go-to-market work without treating model output as authority.

## Constitutional Axioms

1. The harness is not the factory.
2. Autonomy is earned per change class, not enabled globally.
3. Tool access does not grant authority.
4. Evidence precedes operational claims.
5. Agents cannot approve or promote their own governed changes.
6. Deterministic controls outrank probabilistic opinions.
7. Production credentials remain outside agent sandboxes.
8. The same immutable artifact is promoted across environments.
9. Learning occurs in quarantine before trusted-memory or policy promotion.
10. Human accountability remains attached to mission, invariants, exceptions, and consequences.
11. Factory maturity cannot exceed its verified non-agent substrate.
12. Probabilistic judgment cannot override deterministic control failure.
13. Adopted recommendations remain traceable to controls, artifacts, evidence, status, and gaps.
14. Probabilistic evaluators qualify against human reference labels before governed holdout use.
15. Telemetry cannot expose secrets or turn high-cardinality correlation identifiers into metric dimensions.
16. Retrieval, context assembly, and memory cannot expand source authority; trusted memory
    requires provenance and independent accountable approval.
17. Delegation cannot expand parent authority, scope, tools, budget, deadline, or approval rights.
18. Messages and checkpoints are evidence-bearing records, not direct governed-state mutation.
19. Runtime coordination requires assigned-identity leases and replayable append-only journals.
20. A certification can consume verified maturity but cannot create, update, or reinterpret it.
21. Invalid qualification, expiry, suspension, revocation, contradiction, or exhausted incident
    budget resolves effective autonomy to no authority.

## Operating Planes

| Plane | Governs |
|---|---|
| Outcome | Mission, users, economics, success, and failure |
| Constitution | Invariants, authority, risk, and amendments |
| Ontology | Canonical entities, vocabulary, relationships, and evidence |
| Organization | Human roles, agent roles, ownership, and escalation |
| Architecture | Components, contracts, boundaries, and dependency direction |
| Factory substrate | Workspaces, builds, identity, secrets, environments, and developer experience |
| Execution | Harnesses, agents, tools, skills, MCPs, and workflow graphs |
| Change | Git, worktrees, PRs, artifacts, deployment, and rollback |
| Assurance | Tests, evals, security, observability, provenance, and delayed quality |
| Learning | Memory, knowledge graphs, retrospectives, dreaming, and promotion |

## Mutability Classes

| Class | Examples | Default agent authority |
|---|---|---|
| Constitutional | Mission, invariants, authority policy | Read and propose |
| Governed | Schemas, APIs, workflows, evaluators | Modify through approval |
| Writable | Implementation, tests, drafts | Modify within approved scope |
| Generated | Graphs, reports, resolved contracts | Regenerate from sources |
| Ephemeral | Sandboxes, scratch data, candidate memory | Mutate and discard |
| External | Production accounts, billing, legal commitments | Human-authorized operation |

## Architecture Rules

- Elder is the product-agnostic factory kernel; reference projects prove the
  kernel and do not redefine it as one product.
- The hierarchy is universal kernel -> capability packs -> stack adapters ->
  project implementation -> factory operations -> assurance and learning.
- Capability packs define required properties and evidence. Stack adapters
  define technology-specific implementation.
- `ARCHITECTURE.md` in a generated project is concise and contains only stable boundaries.
- Every invariant identifies its enforcement and verification mechanism.
- Dependency and contract diagrams should be generated from machine-readable truth.
- Cross-language boundaries use typed schemas and explicit error behavior.
- High-risk actions cannot be controlled by unvalidated free-form model strings.
- Monorepo, multirepo, single-repo, and federated topologies are selected deliberately.
- Every authority-bearing component declares an operating contract.
- Governed design documents are registered by identity, status, owner, notification audience,
  supersession, and content digest.
- Dependency direction is enforced by machine-readable adapter contracts.

## Agent Rules

- Intake, planning, execution, evaluation, and promotion are separate responsibilities.
- The same agent run cannot be the sole executor, evaluator, and promoter.
- Agents receive the minimum tools, context, credentials, and duration required.
- Agent sessions produce append-only traces with secret redaction.
- Meta-agents may identify problems but do not replace deterministic checks or accountable review.
- Agent transcripts are immutable evaluation inputs and never promotion authority.
- Transcript evaluators must be independent from executors and remain advisory-only.
- Rubric judges must be calibrated for the same immutable dataset revision they assess.
- Evaluation reports are evidence inputs and never release authority.
- Telemetry reports are advisory evidence and never approval or promotion authority.
- Prompts and model outputs are not persisted in telemetry by default.
- Agents may propose candidate memory but cannot self-promote it into trusted memory.
- Context assembly must preserve source authority, provenance, freshness, exclusions, and budget.
- Every child run traces to one bounded delegation with expiry, termination, checkpoints, and escalation.
- Delegated tool grants never imply approval or promotion authority.
- Child runtime operations require an active lease issued to the assigned identity.
- Runtime journals and checkpoints must replay to the persisted lifecycle state.
- Effective autonomy is the minimum of verified hosted maturity, project autonomy ceiling,
  selected autonomy-class maximum, and active certification level.
- Autonomy certification, independent evaluation, suspension, revocation, and renewal remain
  separate responsibilities.
- Certification simulation is side-effect-free and cannot mutate a workspace.
- Pull-request authority requires signed-bundle hosted qualification re-verification, active
  certification lifecycle replay, exact concrete certified scope, trusted-source report
  recomputation, ordered evidence, independent evaluation, current hard-stop checks, and a
  short-lived work-item-bound lease.
- Pull-request submission must reconstruct and validate the authority lease and immutable packet,
  including current expiry and exact execution content, before invoking a hosted provider.
- Pull-request authority does not imply merge, deployment, maturity mutation, or renewal
  authority.

## Change Rules

- Every work item declares a change class before implementation.
- Each change links outcome, requirement, design, agent run, diff, tests, review, commit, artifact,
  deployment, runtime observation, and learning.
- Small or stacked PRs are preferred when they preserve reviewability and independent rollback.
- A production-live state is distinct from a governed release with complete provenance.

## Assurance Rules

Testing progresses one level at a time:

1. Foundation
2. Component
3. Integration
4. Workflow
5. Stress

A failure blocks progression until its root cause is fixed and the same level is rerun.

Quality is a vector: correctness, architecture, changeability, comprehensibility, security,
reproducibility, observability, recoverability, cost, and product outcome. Passing tests at merge
time is not conclusive evidence of maintainability.

Evaluation datasets declare provenance, sensitivity, development, calibration, and holdout
splits. Deterministic graders are preferred; rubric graders require qualified calibration,
case-level evidence, and a separately accountable evaluator. A critical paired regression
cannot be hidden by an aggregate score.

Product, model, tool, factory, cost, and outcome signals use one correlated event contract.
Trace, span, run, work-item, agent-run, artifact, deployment, evaluation, and outcome identifiers
remain trace or event context rather than metric dimensions.

Context assembly is deterministic and authority-filtered. Required context fails closed when
missing, stale, unauthorized, or outside the declared budget. Trusted memory requires source
evidence, namespace scope, review time, and independent human approval.

## Learning Rules

The learning path is:

```text
trace -> cluster -> minimal hypothesis -> sandbox replay -> evaluation
-> candidate skill/policy/memory -> shadow mode -> human ratification
-> canary -> promotion or rollback
```

One incident should normally produce a narrow candidate hypothesis, not a global rule. Learning
systems cannot directly edit constitutional policy, trusted evaluators, or production.

## Autonomy Levels

| Level | Meaning |
|---|---|
| L0 | Reproducible manual execution |
| L1 | Traceable assisted execution |
| L2 | Hosted supervised delivery: agents may create exact reviewable pull requests for bounded work; humans retain merge, release, deployment, certification-renewal, and maturity authority |
| L3 | Bounded production operation: one certified reversible low-risk class may reach bounded canary and automatic rollback; humans retain class definition, scope expansion, full rollout, release, certification-renewal, and maturity authority |
| L4 | Bounded operational autonomy with canary and rollback |
| L5 | Lights-off execution only for certified reversible change classes |

No project profile may grant more autonomy than its evidence, infrastructure, or change class
allows.

The canonical institutional benchmark is
`elder-factory-maturity-standard` version `1.0.0` in
`protocol/operational-maturity.json`. Whole-factory maturity is the minimum
verified level across every mandatory dimension; stronger evidence in one
dimension cannot compensate for a weaker required dimension. Promotion is
cumulative, exact-revision and exact-environment bound, independently
evaluated, contradiction-free, time-bound, and human-ratified.

## Required Kernel Artifacts

- Hierarchical meta-architecture
- Protocol graph
- Capability-pack contracts
- Project profile
- Ontology
- Authority matrix
- Invariants
- Change classes
- Capability-pack selection
- Golden path
- Git/change protocol
- Operational readiness record
- Current validation evidence
- Recommendation ledger
- Component operating contract
- Judgment rubric
- Operational maturity model
- Design-document registry
- Architecture-boundary contract
- Transcript-review policy and result
- Correlated telemetry contract, event, and report
- Context and memory policies
- Persistent knowledge-graph contract
- Digest-bound context packet
- Canonical role registry and project identity bindings
- Resolved capability-pack obligations
- Delegation policy, delegation, message, checkpoint, and approval-decision contracts
- Multi-agent runtime policy, typed action contract, and runtime lease contract
- Stack-adapter contract and registry
- Autonomy policy and autonomy-class registry
- Autonomy certification and incident-budget contracts
- Suspension, revocation, renewal, and qualification-consumption contracts
- Effective-autonomy report
- Structured autonomy work item, match report, and simulation report
- Hash-chained certification event and deterministic replay report
- Hosted Git evidence, supervised pull-request authority lease, execution record, immutable PR
  packet, and provider response

## Definition Of Operational

A capability is operational only when it is implemented, executable in its target environment,
observed in a current run, and accompanied by evidence and a known rollback or failure path.
