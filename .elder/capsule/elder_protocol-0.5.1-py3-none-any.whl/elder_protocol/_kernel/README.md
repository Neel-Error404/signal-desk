# Elder Protocol

**Compiler version:** 0.5.1
**Constitution:** 0.3.8 ratified
**Current phase:** P5.3 - Fail-closed canary mechanisms, canonically inactive

Elder is a governed project-foundation compiler for human-agent software work. It combines a
small protected constitution with machine-readable profiles, ontology, authority, invariants,
change classes, capability packs, skills, and safe generated project contracts.

## Operational Today

- Wayfinder intake from interactive prompts or governed answer files.
- Project-profile validation and migration from v0.1.0.
- Capability-pack dependency resolution.
- Ratified hierarchical meta-architecture separating kernel, packs, adapters,
  project implementation, factory operations, and assurance/learning.
- Complete capability-pack contracts with separate contract and runtime status.
- Deterministic canonical protocol graph and generated project overlays.
- Ontology entity and relationship validation.
- Eleven repo-local skills with dependency-aware routing.
- Skill creation and registry validation.
- Typed schemas for work items, agent runs, evidence, knowledge graphs, tools, MCPs, context,
  memory, and learning candidates.
- Idempotent project compilation.
- Dry-run and unified diff output.
- Hash-based protection for generated files.
- Preservation of unrelated project-owned files.
- Generated project ADR, architecture, testing, ownership, golden-path, trace, and agent
  contracts.
- Mandatory factory-operations and assurance packs for every compiled project.
- Recommendation-to-control traceability, component operating contracts, judgment rubric,
  anti-slop rules, and evidence-bound maturity claims.
- Hash-bound design registry, Python architecture-boundary adapter, and independent
  deterministic transcript review.
- Cryptographically verified hosted evidence bundles with cumulative L0-L5 qualification gates,
  immutable advisory reports, and separate canonical operator and reviewer trust anchors.
- Five bounded autonomy subclasses plus typed certification, incident-budget,
  qualification-consumption, suspension, revocation, renewal, and effective-autonomy contracts.
- Deterministic effective autonomy calculated as the minimum of four evidence-bound ceilings,
  with explicit fail-closed hard stops.
- Exact structured autonomy work-item matching, side-effect-free certification simulation,
  hash-chained lifecycle replay, and derived incident accounting.
- L2-gated short-lived authority leases reconstructed from a repository-owned canonical
  authority source, signed-bundle qualification, independently signed governance-source records,
  certification lifecycle replay, and trusted-source report recomputation.
- Immutable supervised pull-request packets with exact path, operation, and content-digest
  binding, ordered tests, independent evaluation, independently signed workspace and execution
  evidence, exact repository/branch/Git-object/diff response binding, trusted repository URL
  binding, current-state
  re-verification before provider invocation, and human-only merge and release.
- Side-effect-free P5.3 canary-plan simulation, separately governed project L3 class registries,
  L3-only short-lived canary leases, exact signed plan authority, independently signed provider
  controls, runtime-owned durable one-shot plan and packet consumption, non-future-dated current
  governance revalidation, exact responses, fresh signed deployment observations,
  evaluation-time duration checks, scheduled and restart-recoverable no-telemetry watchdog
  rollback, immutable rollback packets, and exact rollback responses. Canary promotion and full
  rollout remain forbidden.
- Hash-bound evaluation datasets, deterministic graders, offline rubric-judge calibration,
  real Workbench holdout evaluation, and paired candidate comparison.
- Native Workbench trace context plus typed Workbench, factory, and evaluation telemetry
  adapters.
- Correlated product, model, tool, factory, cost, and outcome events with advisory budgets and
  metric-cardinality controls.
- Transactional local knowledge graph, governed candidate/trusted memory, append-only knowledge
  audit events, and deterministic authority-filtered context assembly.
- Digest-bound context packets with explicit provenance, assumptions, exclusions, and budgets.
- Query-matched, policy-capped graph context with wildcard and wholesale graph injection rejected.
- Canonical role registry, project identities, resolved authority bindings, and selected-pack
  obligations.
- Fail-closed delegation, agent-run, message, checkpoint, approval, budget, deadline,
  cancellation, and escalation contracts.
- Delegated context identity and scope plus low-risk L1 and high-risk restricted-data L2
  contract fixtures.
- Stack-adapter contract with the Python AST import-boundary reference adapter.
- Transactional local multi-agent coordinator with assigned-identity leases, typed action and
  message journals, digest-linked checkpoints, cancellation propagation, expiry, and replay.
- Transactional quarantined learning runtime with immutable candidate artifacts,
  counterfactual replay, side-effect-free shadow observations, independent evaluation,
  accountable approvals, promotion and rollback packets, and journal replay.
- Digest-bound Codex session activation that verifies Elder-owned instructions, ratified
  project identity, project sandbox configuration, routed native project skills, and mandatory
  portable build memory.
- Deterministic portable Elder capsule ZIPs with a commit-bound wheel, payload manifest,
  repository-local PowerShell launcher, isolated tooling environment, guarded installation,
  update verification, intake example, and embedded new-project prompt.
- Tracked per-project trusted build-memory ledgers that hydrate local Elder SQLite state and
  rebuildable Mem0/Qdrant semantic indexes during activation.
- Candidate-only repository dreaming that copies immutable evidence into a disposable
  workspace, uses Mem0 OSS with local Qdrant for candidate extraction and semantic recall,
  calls Azure `gpt-5.6-luna` for one structured proposal, and accepts only schema-valid,
  digest-bound learning candidates.
- Mem0-extracted memories enter Elder's existing SQLite store only as expiring candidates;
  independent human approval remains required before trusted retrieval.
- Elder Workbench reference product with a typed eleven-node workflow.
- Local API and responsive operator workspace.
- Append-only runtime traces and atomic run snapshots.
- Architecture dependency fitness checks.
- Economics, operations, and proof-backed go-to-market blueprint planes.
- Secretless clean-room build execution.
- Deterministic content-addressed artifacts and append-only provenance.
- Git worktree lifecycle, promotion, rollback, CI, and hosted ruleset contracts.
- Verified local Phase 1 factory operations through SF-106: Product Factory registry, signal
  intake, canonical work-item ledger, transition authority, durable dispatch, run/session/workspace
  binding, append-only operations journal, seven rebuildable projections, integrity checks,
  and operations-store backup/restore.
- SF-107 closes local Gate B with an authenticated numeric-loopback operations API, durable
  idempotency and reconciliation, bounded event polling, truthful health/readiness, graceful
  local drain, and four process-restart proofs. Canonical maturity remains L1.
- SF-200 verifies the provider-neutral worker adapter contract through a deterministic fake
  worker, restart-safe one-effect recovery, SF-105 identity binding, non-authoritative event
  projections, checkpoint authority separation, and installed-wheel conformance.
- SF-201 verifies one bounded real Codex worker adapter with exact local policy enforcement,
  provider/factory identity separation, protected durable state, bounded first-turn process
  ownership, post-turn thread reattachment, fail-closed terminal outcomes, and digest-bound
  evidence.
- SF-202 verifies exact local Git worktree materialization, trusted-instruction and Windows
  reparse checks, canonical-state-fenced workspace leases, durable secretless sandbox binding,
  inspection, quarantine, clean release, recovery, subprocess contention, and one real Codex
  workflow.
- SF-203 verifies durable exact-idempotent session controls, canonical SF-202 binding and Elder
  checkpoint identity, validated SF-200 responses, restart-safe waiting continuation,
  fail-closed incomplete effects, monotonic event cursors, cancellation cleanup, and
  spawned-process contention.
- SF-205 and SF-206 verify durable scheduling, heartbeat, recovery, reconciliation, and orphan
  accounting. Gate C passed on 2026-08-13 when one real Codex issue reached a validated
  evidence packet through hard process restart with one prompt effect. SF-300
  through SF-305 and Gate D verify one supervised local owner workflow through
  control-room refresh and API process restart. SF-400 now verifies the concrete,
  digest-bound Elder governance adapter with fail-closed errors and durable
  learning-mutation replay. SF-401 now verifies persisted, immutable,
  activation-bound context assembly from a queued work item and Elder child
  run, including restart, refresh, stale-input rejection, and concurrent replay.
  SF-402 now verifies the composed P4.5A/B authority start gate, exact
  assigned-child lease, use-time context and expiry checks, durable
  owner-visible rejection, cancellation propagation, restart, and concurrent
  replay. SF-403 now verifies an immutable ordered test plan, exact Git diff
  and artifact binding, stale and failed evidence rejection, independent
  advisory evaluation, durable tamper detection, restart-safe owner status,
  concurrent exact replay, and a completion packet consumed by the existing
  human outcome transition. SF-404 now verifies current SF-402 authority and
  SF-403 completion before existing P5.2 lease and packet creation, persists
  the product-owner delivery decision before provider invocation, accepts only
  an exact supervised pull-request response, and fences uncertain or
  concurrent retries. Gate E is verified for one exact classified
  issue-to-supervised-delivery workflow reconstructed through every Phase 4
  store, plus owner-visible rejection of expired authority, stale context,
  missing evidence, and unauthorized transition. Phase 4 is complete at 18/18
  mandatory tasks. ADR 0022 now ratifies
  `elder-factory-maturity-standard` version `1.0.0`: L2 means real hosted
  supervised issue-to-PR delivery with human merge and release, while L3
  means one certified reversible class may reach bounded canary and automatic
  rollback with humans retaining full rollout and scope expansion. Canonical
  maturity remains L1. SF-500 now implements a bounded, read-only learning
  trajectory normalizer with exact source/evidence bindings, opaque
  references, free-text and secret redaction, deterministic sampling,
  explicit exclusions and missing links, and complete expected-outcome
  attachment. SF-500 is verified through independent review, package build,
  and outside-checkout installed-wheel execution. SF-501 through SF-507 and
  Gate F have not started. SF-600 now implements an inactive PostgreSQL-hosted
  storage boundary with ordered migrations, canonical SQLite checkpoint
  import, transactional outbox/inbox delivery, competing-consumer and
  projection lease fencing, and digest-bound backup/restore. Its PostgreSQL
  DDL passes a direct local engine check, but no hosted resource or active
  binding exists. SF-601 is verified for an inactive provider-neutral
  OIDC/JWKS workload identity and scoped secret-broker boundary with
  short-lived leases, rotation, revocation, and secret-free audit. No external
  identity provider, vault, or credential is configured. SF-602 is verified
  for an inactive hardened hosted-workspace boundary with pinned image and
  repository artifacts, default-deny egress, exact tools and resources,
  live-broker credential injection, quarantine, retention, destruction, and
  cross-instance fences. No cloud workspace is configured. SF-603 is verified
  for an inactive provider-neutral integration boundary covering authenticated
  webhook intake, current workload and broker credentials, idempotent outbound
  calls, pagination, rate limits, reconciliation, dead letters, replay, and
  policy-bound audit for GitHub, issue tracker, chat, CI, and notification
  classes. No external provider is configured. SF-604 is verified for an
  inactive hosted Git control boundary using canonical P4.8A trust anchors,
  exact protected-branch rules and required checks, signed governance,
  provenance and provider response, an exact open SF-404/P5.2 delivery record,
  canonical independent review, and append-only restart-safe evidence. No live
  Git provider or repository rule is configured. SF-605 is verified for an
  inactive exact multi-product boundary covering tenant/product authorization,
  derived storage partitions, quota-reservation accounting, worker and cache
  isolation, product audit export, immutable checkpoints, registered backup,
  exact source-path restore, and disaster procedure. No cloud tenant or
  provider-native recovery is configured. SF-606 now implements and executes
  a diagnostic-only ADR-0022 institutional L2 evaluator pinned to canonical
  policy, maturity, and trust anchors. It cannot qualify, declare ratification
  readiness, or grant authority from caller assertions. The exercise is
  blocked: the only signed L2 bundle is historical and revision-mismatched,
  branch protection is unavailable on the current private-repository plan,
  and there is no provider-bound 30-day, 20-item exact-revision hosted work
  history. Gate G remains unqualified and canonical maturity remains L1.

## Not Operational Yet

- Hosted branch protection and merge queue.
- External secret brokering.
- Real MCP servers or external tool execution.
- Hosted telemetry collection, OTLP export, production retention, alerting, and multi-host observability.
- Live model-provider evaluation and hosted evaluator isolation.
- Hosted or multi-tenant knowledge-graph service and backup/recovery.
- Autonomous trusted-memory promotion.
- Direct interception of arbitrary Codex shell, edit, or tool calls by Elder.
- Activated hosted brokers, remote agent workers, distributed scheduling,
  external runtime identity authentication, managed failover, and qualified
  hosted checkpoints.
- Hosted shadow traffic, target-application adapters, and production self-learning.
- Additional stack adapters and technology-specific practice generators.
- GitHub-native persisted artifact attestation, deployment, canary, and rollback evidence.
- Canonically active autonomy certification, supervised PR creation, or canary execution,
  because the authority source is empty, no active certification or valid L3 consumption exists,
  the canonical classes remain capped at L2, and hosted production controls are unavailable.
- Autonomous merge, deployment, maturity mutation, or automatic certification renewal.
- Hosted deployment of the owner control room and remote Phase 2
  issue-to-evidence operation over provisioned recoverable workspaces.

See [operational readiness](docs/operational-readiness.md) and the
[P2 architecture audit](docs/p2-architecture-audit.md). To apply Elder to a new or existing
product repository without copying the factory checkout, follow
[Using Elder In A Product Repository](docs/using-elder-in-a-project.md).

Run the P2 reference product:

```powershell
cd reference_projects\elder-workbench
py run.py
```

Operate the P3 local factory:

```powershell
py -m elder_protocol.cli factory validate
py -m elder_protocol.cli factory status
py -m elder_protocol.cli factory build --report .factory/latest-build.json
py -m elder_protocol.cli factory verify --digest <artifact-sha256>
py -m elder_protocol.cli graph --output .tmp/protocol-graph.json
py -m elder_protocol.cli assurance
py -m elder_protocol.cli design validate
py -m elder_protocol.cli architecture check --contract <contract.json> --root <project-root>
py -m elder_protocol.cli evaluate transcript --trace <trace.jsonl> --evaluator-id <reviewer> --executor-id <executor>
py -m elder_protocol.cli evaluate dataset
py -m elder_protocol.cli evaluate calibrate --judge-results <judge-results.json> --output <calibration.json>
py -m elder_protocol.cli evaluate run --candidate <candidate.json> --split holdout --evaluator-id <reviewer> --judge-results <judge-results.json> --calibration <calibration.json> --output <evaluation.json>
py -m elder_protocol.cli evaluate compare --baseline <baseline.json> --candidate <evaluation.json> --output <comparison.json>
py -m elder_protocol.cli telemetry ingest --source-kind workbench --input <trace.jsonl> --project-id <project> --output <events.jsonl>
py -m elder_protocol.cli telemetry validate --events <events.jsonl>
py -m elder_protocol.cli telemetry report --events <events.jsonl> --output <report.json>
py -m elder_protocol.cli knowledge init --store <knowledge.db>
py -m elder_protocol.cli knowledge ingest --store <knowledge.db> --graph <graph.json>
py -m elder_protocol.cli knowledge query --store <knowledge.db> --query <text>
py -m elder_protocol.cli memory propose --store <knowledge.db> --record <memory.json>
py -m elder_protocol.cli memory promote --store <knowledge.db> --memory-id <id> --approval <approval.json>
py -m elder_protocol.cli context assemble --store <knowledge.db> --request <request.json> --output <packet.json>
py -m elder_protocol.cli context assemble --store <knowledge.db> --request <delegated-request.json> --delegation <delegation.json> --parent-run <run.json> --authority-bindings <bindings.json> --profile <project-profile.json> --output <packet.json>
py -m elder_protocol.cli delegation validate --delegation <delegation.json> --parent-run <run.json> --authority-bindings <bindings.json> --profile <project-profile.json>
py -m elder_protocol.cli orchestration init --store <runtime.db>
py -m elder_protocol.cli orchestration submit --store <runtime.db> --bundle <bundle.json>
py -m elder_protocol.cli orchestration claim --store <runtime.db> --project-id <project> --identity-id <identity>
py -m elder_protocol.cli orchestration replay --store <runtime.db> --delegation-id <delegation>
py -m elder_protocol.cli learning init --store <learning.db> --profile <project-profile.json>
py -m elder_protocol.cli learning propose --store <learning.db> --profile <project-profile.json> --candidate <candidate.json> --artifact-base <repo>
py -m elder_protocol.cli learning replay --store <learning.db> --profile <project-profile.json> --candidate-id <candidate>
py -m elder_protocol.cli autonomy validate
py -m elder_protocol.cli autonomy match --work-item <work-item.json> --certification <certification.json>
py -m elder_protocol.cli autonomy simulate --work-item <work-item.json> --certification <certification.json>
py -m elder_protocol.cli autonomy replay --certification <certification.json> --events <events.json> --at <iso-8601-time>
py -m elder_protocol.cli autonomy readiness
py -m elder_protocol.cli autonomy canary-simulate --plan <canary-plan.json>
py -m elder_protocol.cli autonomy canary-readiness
```

Current local canary:

```text
http://127.0.0.1:8767
```

It runs from the immutable artifact recorded in the P3 evidence file.

## Commands

```powershell
# Validate the protocol and an optional profile
py -m elder_protocol.cli validate
py -m elder_protocol.cli validate --profile examples/minimal-project-profile.json

# Run governed intake
py -m elder_protocol.cli intake `
  --answers examples/intake-answers.json `
  --output .tmp/intake-profile.json

# Ratify the profile as its bound human owner
py -m elder_protocol.cli ratify-profile `
  --profile .tmp/intake-profile.json `
  --approved-by <human-owner-identity> `
  --output .tmp/ratified-profile.json

# Inspect skill routing
py -m elder_protocol.cli skills validate
py -m elder_protocol.cli skills route `
  --task "design agent architecture nodes edges and dependency boundaries" `
  --packs core,agentic

# Preview and compile
py -m elder_protocol.cli compile `
  --profile .tmp/intake-profile.json `
  --output .tmp/generated-project `
  --dry-run `
  --diff

py -m elder_protocol.cli compile `
  --profile .tmp/ratified-profile.json `
  --output .tmp/generated-project

# Build and verify the portable per-repository Elder capsule
py -m elder_protocol.cli capsule build `
  --output dist/elder-capsule-0.5.1.zip

py -m elder_protocol.cli capsule verify `
  --archive dist/elder-capsule-0.5.1.zip

# Install the capsule into one product repository
py -m elder_protocol.cli capsule install `
  --archive dist/elder-capsule-0.5.1.zip `
  --project-root <product-root>

# Hosted CI publishes elder-portable-capsule-<run-id>-<attempt>
# with a manifest bound to that run's exact source commit.

# Start or restart Codex inside the generated project, then activate Elder
./elder.ps1 session activate `
  --project-root . `
  --task "<current user request>" `
  --env-file .elder/runtime/memory.env `
  --memory-live `
  --output .tmp/session-activation.json

# Install the optional local memory and dreaming runtime
py -m pip install -e ".[memory]"

# Verify Mem0, local Qdrant, Azure extraction/embeddings, and Luna
py -m elder_protocol.cli dreaming readiness `
  --project-root . `
  --env-file .elder/runtime/memory.env `
  --live

# Prepare an evidence-only quarantine workspace
py -m elder_protocol.cli dreaming prepare `
  --project-root . `
  --activation .tmp/session-activation.json `
  --work-item-id <work-item-id> `
  --trigger completed-work-item `
  --evidence test-result=<test-result-path> `
  --workspace .tmp/dreaming

# Run Mem0 extraction, semantic recall, and Luna candidate generation
py -m elder_protocol.cli dreaming run `
  --project-root . `
  --env-file .elder/runtime/memory.env `
  --workspace .tmp/dreaming `
  --mode routine

# Validate a provider-produced candidate without applying or promoting it
py -m elder_protocol.cli dreaming accept `
  --workspace .tmp/dreaming `
  --candidate .tmp/dreaming/candidate.json `
  --output .tmp/accepted-learning-candidate.json

# Propose expiring Elder candidate memories from immutable evidence
py -m elder_protocol.cli memory extract `
  --store .tmp/knowledge.db `
  --project-root . `
  --env-file .elder/runtime/memory.env `
  --namespace elder-protocol `
  --evidence decision=<decision-path>

# Close an evidence-bearing product-development session and propose build memory
./elder.ps1 session close `
  --project-root . `
  --activation .elder/runtime/activation.json `
  --env-file .elder/runtime/memory.env `
  --evidence test-result=<test-result-path> `
  --output .elder/runtime/session-close.json
```

The compiler writes only declared Elder-owned paths. Regeneration refuses to overwrite a
modified generated file unless `--force` is explicitly supplied. The ownership manifest is a
local integrity guardrail, not a signed security boundary.

Project `.codex/config.toml` is loaded when a new Codex session starts in a trusted project.
Restart Codex after compilation or configuration changes. Session activation verifies the
declared boundary but does not retrofit a running process or intercept direct Codex tools.

## Test Ladder

```powershell
py -m unittest discover -s tests/foundation -v
py -m unittest discover -s tests/component -v
py -m unittest discover -s tests/integration -v
py -m unittest discover -s tests/workflow -v
py -m unittest discover -s tests/stress -v
```

## Read Order

1. [ELDER_PROTOCOL.md](ELDER_PROTOCOL.md)
2. [CONTEXT.md](CONTEXT.md)
3. [docs/meta-architecture.md](docs/meta-architecture.md)
4. [ADR 0004](docs/adr/0004-hierarchical-meta-architecture.md)
5. [ADR 0007](docs/adr/0007-p4-2-evaluation-harness.md)
6. [P4.2 evaluation harness](docs/p4-2-evaluation-harness.md)
7. [ADR 0008](docs/adr/0008-p4-3-correlated-telemetry.md)
8. [P4.3 correlated telemetry](docs/p4-3-correlated-telemetry.md)
9. [ADR 0009](docs/adr/0009-p4-4-governed-knowledge-runtime.md)
10. [P4.4 governed knowledge runtime](docs/p4-4-governed-knowledge-runtime.md)
11. [ADR 0010](docs/adr/0010-p4-5a-multi-agent-entry-gate.md)
12. [P4.5A multi-agent entry gate](docs/p4-5a-multi-agent-entry-gate.md)
13. [ADR 0011](docs/adr/0011-p4-5b-bounded-multi-agent-runtime.md)
14. [P4.5B bounded multi-agent runtime](docs/p4-5b-bounded-multi-agent-runtime.md)
15. [ADR 0012](docs/adr/0012-p4-6-quarantined-learning-runtime.md)
16. [P4.6 quarantined learning runtime](docs/p4-6-quarantined-learning-runtime.md)
17. [ADR 0013](docs/adr/0013-p4-7-hosted-production-qualification.md)
18. [P4.7 hosted production qualification](docs/p4-7-hosted-production-qualification.md)
19. [ADR 0014](docs/adr/0014-p5-0-autonomy-class-contracts.md)
20. [P5.0 autonomy-class contracts](docs/p5-0-autonomy-class-contracts.md)
21. [ADR 0015](docs/adr/0015-p5-1-certification-simulation.md)
22. [P5.1 certification simulation](docs/p5-1-certification-simulation.md)
23. [ADR 0016](docs/adr/0016-p5-2-supervised-autonomous-prs.md)
24. [P5.2 supervised autonomous pull requests](docs/p5-2-supervised-autonomous-prs.md)
25. [ADR 0018](docs/adr/0018-p5-3-fail-closed-canary.md)
26. [P5.3 fail-closed canary execution](docs/p5-3-fail-closed-canary.md)
27. [docs/p3-factory-audit.md](docs/p3-factory-audit.md)
28. [Codex activation and repository dreaming](docs/codex-activation-and-repository-dreaming.md)
29. [docs/operational-readiness.md](docs/operational-readiness.md)
30. [ROADMAP.md](ROADMAP.md)
31. [docs/golden-path.md](docs/golden-path.md)
32. [docs/git-change-protocol.md](docs/git-change-protocol.md)

## Non-Claim

P5.3 proves a product-agnostic hierarchy, typed capability-pack contracts, generated project
graphs, a local bounded factory substrate, a local independent evaluation harness, and local
correlated telemetry with advisory budgets, plus a local governed knowledge, memory, and context
runtime, resolved obligations, canonical identity bindings, and fail-closed delegation
contracts. It also proves local lease-bound coordination, typed journals, cancellation
propagation, expiry, deterministic lifecycle replay, quarantined counterfactual and shadow
observations, independent learning evaluation, immutable promotion and rollback packets, and a
cryptographic cumulative hosted-qualification mechanism. P4.8A configures separate operator and
reviewer trust anchors, a private GitHub remote, hosted CI, provider OIDC workload identity,
reproducible artifact evidence, independently signed provenance, and a canonically replayed
18-record advisory L2 bundle for exact commit
`d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`. Hosted qualification remains advisory, so Elder
remains canonically L1.
It also proves bounded-autonomy contracts, deterministic simulation and lifecycle replay, the
L2-gated supervised-PR mechanism, and an L3-gated fail-closed canary mechanism with signed
provider and observation evidence. The canonical authority-source registry is empty, the
canonical classes remain capped at L2, and the repository has no valid L3 consumption or active
certification. It therefore does not activate canary authority. No canary result grants
promotion, full rollout, merge, maturity mutation, or automatic renewal.
The P5 change set completed independent security and correctness review with no remaining
Critical, High, or Medium findings and is committed under explicit operator authorization.
It does not prove a hosted broker,
remote workers, distributed scheduler, external runtime identity authentication, hosted
checkpoint durability, autonomous promotion, hosted collector, OTLP export,
production retention or alerting,
live model-provider evaluation, hosted evaluator isolation, broad dataset representativeness,
protected hosted branch governance, GitHub-native persisted attestation, external secret
brokering, production deployment, vector retrieval, hosted knowledge
durability, hosted shadow traffic, target-specific candidate application, or production
self-learning.
