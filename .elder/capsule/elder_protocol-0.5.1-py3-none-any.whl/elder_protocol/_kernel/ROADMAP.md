# Elder Protocol Roadmap

## P0 - Protocol Kernel

**Status:** COMPLETE and ratified on 2026-08-05.

**Goal:** Establish a coherent constitution and machine-readable contract.

Exit criteria:

- Core manifests parse and cross-reference correctly.
- Minimal project profile validates.
- Compiler emits a resolved contract and protected project instructions.
- Foundation tests pass.
- Current operational gaps are explicitly documented.

## P1 - Compiler And Packs

**Status:** IMPLEMENTED; verification evidence recorded in
`docs/evidence/2026-08-05-p1-compiler-and-skills.md`.

**Goal:** Generate tailored project foundations rather than static copies.

Deliverables:

- Capability-pack dependency resolution.
- Interactive Wayfinder intake.
- Profile migration and versioning.
- Generated ADR, architecture, test, and ownership scaffolds.
- Dry-run and diff modes.
- Idempotent regeneration without overwriting project-owned content.
- Repo-local skill registry, creator, validator, dependency graph, and router.
- Ontology entity and relationship contracts.
- Typed work-item, trace, tool, MCP, context, memory, and learning schemas.

## P2 - Reference Project

**Status:** IMPLEMENTED for local operation; closure pending architecture-owner
ratification and delayed maintainability evidence.

**Goal:** Prove the protocol against one real agentic product.

Deliverables:

- Backend, frontend, data, agent, security, operations, and go-to-market surfaces.
- Architecture fitness functions.
- Layered test execution.
- Execution and outcome evidence.
- First delayed maintainability review.

Implemented reference:

- `reference_projects/elder-workbench`
- Eleven-node governed workflow.
- Local API, operator frontend, append-only traces, atomic snapshots.
- Architecture fitness function and five-level test ladder.
- Economics, operations, and proof-backed go-to-market contracts.

Scheduled closure reviews:

- First review: on or after 2026-08-12.
- Thirty-day review: around 2026-09-04.
- Ninety-day review: around 2026-11-03.

## P3 - Factory Substrate

**Status:** LOCAL SUBSTRATE AND LOCAL CANARY OPERATIONAL; hosted activation remains open.

**Goal:** Make bounded agent execution operational.

Deliverables:

- Git repository, branch protections, merge queue, and stacked-PR path.
- Isolated worktrees and sandboxes.
- Reproducible clean-room builds.
- Workload identity and external secret broker.
- CI, artifact provenance, promotion, canary, and rollback.
- Product and factory execution traces.

Implemented locally:

- machine-readable factory substrate contract;
- root Git repository initialized on `main` with an authorized baseline and
  P3 closure commit;
- isolated worktree lifecycle validated in a committed fixture repository;
- secretless clean-room test execution;
- deterministic content-addressed artifacts;
- append-only local provenance and factory traces;
- approval-gated promotion and rollback engine;
- merge-queue-compatible CI definition with OIDC artifact attestation;
- desired hosted GitHub ruleset.
- digest-bound human-approved local canary running from the immutable artifact.

Activation gates:

- Git remote and accountable hosted identities;
- hosted ruleset, required checks, review, and merge queue activation;
- successful hosted CI and verified signed attestation;
- external workload identity and secret broker;
- remote digest-specific release approval and hosted canary observation.

## P3.1 - Hierarchical Architecture Closure

**Status:** IMPLEMENTED and human-ratified on 2026-08-05.

**Goal:** Make Elder explicitly product-agnostic and connect protocol truth
through typed capability packs and deterministic graphs.

Delivered:

- universal kernel -> capability packs -> stack adapters -> project
  implementation -> factory operations -> assurance and learning hierarchy;
- accepted ADR 0004 and canonical meta-architecture;
- typed capability-pack registry with separate contract and runtime status;
- deterministic protocol graph with drift validation;
- generated selected project graph and selected pack contracts;
- generated `AGENTS.md` routing across profile, contract, graph, packs, skills,
  ownership, and evidence;
- protocol version 0.3.0 and 0.2.0 profile migration;
- ownership-protected Workbench regeneration without product-source changes.

Open after P3.1:

- stack-adapter contract and adapters;
- specialty-pack practice implementation;
- persistent graph ingest, query, and visualization runtime;
- dynamic execution, evidence, and learning graph storage.

## P4 - Evaluation And Learning

**Status:** P4.0 THROUGH P4.7 IMPLEMENTED FOR THEIR DECLARED LOCAL OR CONTRACT SCOPE.

**Goal:** Make quality, evaluation, and learning evidence-bound without self-authorizing
policy drift.

Deliverables:

- P4.0 recommendation-to-control ledger, component operating contract, judgment
  rubric, maturity claims, and anti-slop architecture.
- P4.1 design-document registry, executable architecture-boundary adapters, and
  deterministic independent transcript review.
- P4.2 independent evaluation harness, datasets, calibration, and executor/evaluator
  separation.
- P4.3 correlated product, model, tool, factory, cost, and outcome telemetry.
- P4.4 context assembler, governed memory runtime, and persistent knowledge graph.
- P4.5 multi-agent messaging, delegation, checkpoints, and authority enforcement.
- P4.6 quarantined replay, counterfactual comparison, shadow mode, and promotion.
- P4.7 hosted production qualification against maturity-level gates.
- Agent-trajectory evaluation datasets.
- Independent executor/evaluator separation.
- Human-evaluator calibration.
- Quarantined replay and counterfactual testing.
- Candidate memory, skill, and policy promotion workflow.
- Seven, thirty, and ninety-day maintainability measurements.

P4.0 implemented:

- adopted recommendation ledger with twenty mapped software-factory,
  anti-slop, typed-boundary, trace, and judgment principles;
- mandatory `factory-operations` and `assurance` capability packs;
- component operating contract schema;
- evidence-cited judgment rubric with deterministic vetoes;
- L0-L5 operational maturity model capped at L1 for the current local reference scope;
- protocol graph integration and `elder assurance` status reporting;
- generated assurance, component, recommendation, judgment, and maturity contracts.

P4.1 implemented:

- hash-bound design-document registry with ownership, status, change classes,
  notifications, and supersession validation;
- reusable architecture-boundary schema and `python-ast-imports` adapter;
- Workbench project-owned boundary contract and executable Foundation check;
- deterministic JSONL transcript evaluator with executor/evaluator separation;
- advisory-only transcript-review result schema and CLI;
- generated design registry, boundary instructions, transcript policy, and review instructions.

P4.2 implemented:

- hash-bound evaluation dataset registry with development, calibration, and holdout splits;
- typed candidate-output, judge-result, calibration, evaluation, and comparison contracts;
- exact, contains, numeric, and rubric graders;
- mandatory executor/evaluator separation and immutable dataset binding;
- offline rubric-judge calibration with accuracy, precision, recall, F1, abstention, and
  confusion-matrix evidence;
- paired baseline comparison with cost, latency, tool-call, score, pass-rate, and critical
  regression reporting;
- project-specific generated evaluation dataset, registry, evaluator contract, graph node,
  and operating instructions;
- real Workbench holdout evaluation using an independently calibrated judge artifact.

P4.3 implemented:

- typed telemetry contract, event, and aggregate report schemas;
- W3C-compatible trace and span identifiers with validate-or-replace handling;
- native Workbench run, root-span, and node-span correlation;
- deterministic adapters for Workbench JSONL, factory JSONL, and evaluation reports;
- correlated product, model, tool, factory, cost, and outcome signals;
- secret-shaped attribute rejection and prompt/output non-persistence by default;
- prohibition of trace, span, run, work-item, artifact, deployment, evaluation, and outcome
  identifiers as metric dimensions;
- advisory cost, error-rate, p95-latency, correlation-completeness, outcome, and metric-cardinality
  reports;
- compiler-generated telemetry contract and operating instructions;
- real Workbench integration evidence covering all six telemetry scopes.

P4.4 implemented:

- transactional SQLite reference store with foreign keys, WAL, full synchronous durability,
  busy timeout, schema metadata, and integrity checks;
- provenance-bound persistent graph nodes and edges with transactional idempotent ingest;
- namespace-scoped episodic, semantic, and procedural candidate memory;
- independent `human-owner` approval for trusted-memory and terminal lifecycle transitions;
- trusted-only default retrieval with expiry and review enforcement;
- deterministic authority/status/freshness/budget-filtered context assembly;
- explicit optional-source exclusions and fail-closed required sources;
- immutable digest-bound context packets;
- generated context and memory policy contracts and Workbench operating instructions;
- real Workbench graph, memory, and context runtime evidence.

P4.5A entry-gate scope:

- canonical role registry, project identities, and resolved authority bindings;
- selected capability packs resolved into inspectable obligations;
- delegation, agent-run, message, checkpoint, grant, budget, deadline, cancellation,
  escalation, and approval-decision contracts;
- deterministic delegation invariants and fail-closed validation;
- delegated context identity and scope;
- low-risk L1 and high-risk restricted-data L2 JSON fixtures;
- one specified stack-adapter contract with the existing Python AST reference adapter.

P4.5A explicitly does not implement queues, brokers, schedulers, hosted checkpoint storage,
runtime cancellation propagation, autonomous promotion, or a second reference product.

P4.5B implemented:

- transactional local SQLite coordinator with WAL, foreign keys, full synchronous durability,
  integrity checks, and append-only runtime journals;
- complete submission validation across project authority, parent run, delegation, child run,
  and digest-bound delegated context packet;
- deterministic assigned-identity dispatch with short-lived hashed lease tokens;
- typed child action records with authority, tool, budget, deadline, and checkpoint-frequency
  enforcement;
- exact parent-child message binding and contiguous append-only sequencing;
- digest-linked checkpoint continuity bound to cumulative journaled action consumption;
- transactional cancellation propagation across active descendant delegations, runs, and leases;
- expiry sweep, escalation blocking, runtime snapshots, and connected runtime graphs;
- global runtime-event hash chain and deterministic lifecycle replay verification;
- generated runtime policy and operating instructions.

P4.5B explicitly does not implement external identity authentication, a hosted broker, remote
agent workers, distributed scheduling, model or tool execution, hosted durability, autonomous
approval or promotion, or P4.6 counterfactual learning.

P4.6 implemented:

- transactional local SQLite learning store with policy-digest binding, integrity checks, and
  append-only event journals;
- immutable candidate artifact bytes bound to candidate, target, evidence, creator, expiry, and
  content digests;
- side-effect-free counterfactual replay and shadow observation contracts over immutable input
  and output digests;
- minimum replay coverage before shadow observation;
- independent deterministic evaluation across quality, cost, latency, tool calls, worse cases,
  and critical regressions;
- kind-specific accountable approval roles and creator/evaluator/approver/promoter separation;
- immutable promotion and rollback packets that cannot apply target mutation;
- deterministic row, artifact-byte, event-chain, count, and lifecycle replay verification;
- generated learning policy and operating instructions plus Workbench reference integration.

P4.6 explicitly does not implement live model or tool execution, production traffic shadowing,
external identity authentication, hosted learning durability, automatic trusted-memory writes,
repository skill installation, policy/evaluator/architecture mutation, deployment, production
rollback, or production self-learning.

P4.7 implemented:

- exact qualification-policy coverage for every capability and evidence requirement across
  cumulative L0-L5 maturity gates;
- immutable project, environment, artifact, time, and payload-bound hosted evidence bundles;
- Ed25519 trust anchors constrained by verifier role, provider, source host, and lifecycle;
- canonical record signatures plus record, bundle, and payload SHA-256 verification;
- freshness, expiry, future-date, path-containment, symlink, project, environment, artifact,
  signer-independence, and contradiction checks;
- deterministic order-independent gate results and immutable advisory qualification reports;
- CLI, compiler, schemas, ontology, invariants, authority, recommendation, graph, assurance, and
  Workbench integration.

P4.7 explicitly does not configure external trust anchors, collect hosted evidence, create a
remote or hosted CI run, provision infrastructure, authenticate humans, mutate the canonical
maturity assessment, promote, deploy, roll back production, or implement P5 autonomy. Elder
remains L1 until a separately governed signed hosted bundle passes the requested cumulative
gates.

## P5 - Bounded Autonomy

**Goal:** Certify selected reversible change classes for higher autonomy.

P5.0 implemented and verified for its contract-only scope:

- exactly five initial subclasses for documentation-only corrections, deterministic generated
  regeneration, semantic-preserving formatting, approved deterministic lint fixes, and add-only
  tests;
- typed certification, incident-budget, qualification-consumption, suspension, revocation,
  renewal, and effective-autonomy contracts;
- pinned re-verification of P4.7 qualification inputs rather than trust in an arbitrary report;
- deterministic effective autonomy as the minimum of verified hosted maturity, project ceiling,
  class maximum, and active certification level;
- hard stops for invalid or expired qualification, suspension, revocation, newer contradiction,
  and exhausted incident budget;
- ontology, authority, invariant, recommendation, graph, assurance, compiler, CLI, fixture, and
  test integration.

P5.1 implemented and verified:

- digest-bound structured work items with exact operations, paths, classifications, tools,
  rules, checks, equivalence evidence, and observed effects;
- exact class, certification, concrete-path scope, tool, and rule matching;
- side-effect-free simulation with no workspace mutation or PR authority;
- contiguous hash-chained certification events, future-event rejection, policy-specific roles,
  and deterministic lifecycle replay;
- derived incident and rollback accounting, budget exhaustion, and suspension requirement;
- CLI, compiler, schema, ontology, invariant, recommendation, graph, assurance, and layered-test
  integration.

P5.2 mechanism implemented and verified:

- L2 minimum enforced by re-running P4.7 from the signed hosted bundle;
- repository-owned canonical authority sources pin each active project's ceiling and approved
  policy, class, change-class, qualification, and maturity digests before signed evidence is
  consumed;
- short-lived digest-bound authority leases scoped to one work item, active lifecycle replay,
  certification, qualification, and recomputed reports;
- exact actual path, operation, and content-digest binding, ordered Foundation through Stress
  evidence, and independent evaluation;
- current independently signed hosted Git governance and external identity evidence;
- immutable supervised pull-request packets, complete lease and packet reconstruction before
  provider invocation, and current qualification and lease-expiry checks;
- explicit Git object-format handling and exact provider-response binding to the authorized packet,
  repository, branches, base and head revisions, diff, and trusted repository URL prefix;
- a constitutional no-wholesale-graph-context invariant with wildcard and over-limit negative
  coverage;
- human-only merge and release, with deployment, maturity mutation, and automatic renewal
  forbidden;
- canonical fail-closed readiness reporting.

P5.2 canonical activation remains blocked until an active canonical project authority source,
a valid hosted L2 qualification consumption, an active class certification, and verified hosted
branch protection exist.
Synthetic fixtures verify mechanics but do not satisfy that gate.

P5 governance closure completed after independent review found no remaining Critical, High, or
Medium findings and the change set was committed under explicit operator authorization.

P5.3 mechanism implemented:

- canonical initial autonomy classes remain exactly five and capped at L2, while separately
  governed project registries may define classes capped at L3 and by the parent class ceiling;
- side-effect-free digest-bound production canary plans with bounded traffic, duration,
  observation, health, immutable predecessor, and automatic rollback;
- L3-only short-lived leases reconstructed from the existing canonical P5 authority chain;
- independently signed canary authority bound to one exact plan and an explicitly canary-capable
  project L3 class;
- independently signed provider evidence for external identity, secret brokering, promotion
  gates, central telemetry, immutable artifacts, and rollback readiness;
- immutable execution packets and accepted provider responses bound to one target, artifact
  pair, traffic allocation, deployment identifier, URL prefix, and execution time;
- runtime-owned canonical durable plan and packet consumption plus non-future-dated
  certification, budget, suspension, revocation, qualification, and signed authority
  revalidation before provider invocation;
- independently signed deployment observations with deterministic health and duration
  evaluation;
- immutable rollback packets, automatic rollback-adapter invocation, and exact bounded rollback
  responses on any breach, including scheduled and restart-recoverable absent-telemetry work at
  the hard duration deadline, while promotion and full rollout remain explicitly forbidden;
- canonical fail-closed readiness reporting and layered positive, negative, CLI, compiler, graph,
  and determinism coverage.

P5.3 operational authority remains inactive until a valid L3 qualification is consumed with an
active L3-capable project class certification and verified production identity, secrets,
telemetry, and rollback controls. Synthetic fixtures prove mechanisms only.

Remaining sequence:

- P4.8A exact-commit signed review and advisory L2 issuance are verified for commit
  `d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`.
- P4.8B remains a separate governed work item.
- P5.4 adds longitudinal governance after the preceding gates are evidenced.

## Current Position

P0 and P1 are complete for their declared scope. The P2 implementation bridge is operational
locally and remains open for ratification and delayed reviews. The P3 local substrate is now
implemented and verified. P3.1 now provides the ratified product-agnostic hierarchy, complete
pack contracts, and generated protocol/project graphs. P4.8A now provides a private GitHub
remote, successful hosted CI, GitHub OIDC workload identity, canonical trust anchors, and an
independently signed provenance path. Protected branch governance, secret brokering, and a
remotely approved hosted canary remain activation gates. The digest-approved local canary is
operational. Stack adapters and deeper
specialty packs should accompany later P4 phases; no P4-P5 capability should be represented as
operational without current evidence. P4.1 makes deterministic independent trace review and one
Python architecture adapter operational locally. P4.2 makes local dataset governance, offline
judge calibration, holdout evaluation, and paired comparison operational. P4.3 makes local
trace-context generation, source normalization, six-scope correlation, and advisory telemetry
budgets operational. A hosted collector, OTLP export, production retention and alerting, live
model-provider evaluation, hosted evaluator isolation, production calibration drift detection,
persistent hosted knowledge, autonomous memory consolidation, distributed multi-agent
coordination, production shadow traffic, target-application adapters, and production
self-learning remain open. P4.4 makes a transactional local graph, governed memory lifecycle,
and deterministic context assembly operational. P4.5B makes bounded local coordination and
lifecycle replay operational. P4.6 makes quarantined local replay, shadow evidence, independent
learning evaluation, and non-mutating promotion and rollback packets operational. P4.7 makes
signed hosted evidence qualification executable and fail closed. P4.8A configures separate
operator and reviewer trust anchors and the provider-bound issuance path; exact-commit run
`31088377331` produced a verified advisory L2 bundle. P5.1 makes simulation, replay, and incident accounting
operational locally without side effects. P5.2 implements the supervised-PR mechanism but its
canonical activation gate remains closed. P5.3 implements the fail-closed canary mechanism, but
its L3 operational gate remains closed. None of these raise the current canonical L1 claim.
