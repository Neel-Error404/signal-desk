# P4.2 Evaluation Harness

## Purpose

P4.2 turns evaluation from an informal review step into a typed, reproducible, evidence-bound
workflow. It measures candidates against a governed dataset and qualifies rubric judges before
their scores can affect an evaluation report.

## Contract Chain

```text
evaluation registry -> immutable dataset revision -> candidate outputs
-> deterministic graders + calibrated rubric judge
-> evaluation report -> paired comparison -> accountable human decision
```

None of the evaluation artifacts grant approval or promotion authority.

## Dataset Governance

Every dataset declares:

- a stable id, objective, owner, source, license, and sensitivity;
- development, calibration, and holdout splits;
- case-level slices and risk tiers;
- deterministic or rubric grader configuration;
- minimum pass rate and maximum failed cases;
- a content digest recorded in the evaluation registry.

Cases cannot appear in multiple splits. Missing, duplicate, unassigned, or unknown cases fail
validation.

## Graders

- `exact`: normalized exact comparison.
- `contains`: required-content comparison.
- `numeric`: numeric comparison with an explicit absolute tolerance.
- `rubric`: independently supplied label and score bound to a rubric id.

Rubric grading requires a calibration report for the same dataset revision, judge, and
evaluator identity.

Evaluation and comparison reports record content digests for their dataset, evaluator
contract, candidate, judge results, calibration report, and paired input reports as
applicable.

## Calibration

Calibration compares judge labels on the calibration split with human reference labels and
reports:

- sample count;
- accuracy;
- precision;
- recall;
- F1;
- abstention rate;
- confusion matrix.

Qualification thresholds come from `protocol/evaluator-contract.json`. An unqualified judge
cannot score a governed holdout evaluation. The harness recomputes qualification from the
reported metrics and current contract thresholds; altered authority, independence, threshold,
or qualification fields fail closed.

## Comparison

Comparison is paired by case id and reports wins, losses, ties, pass-rate delta, mean-score
delta, cost delta, latency delta, and critical regressions.

A candidate that newly fails a critical case is classified as worse regardless of its
aggregate score.

## CLI Workflow

```powershell
py -m elder_protocol.cli evaluate dataset

py -m elder_protocol.cli evaluate calibrate `
  --judge-results examples/eval-calibration-judge-results.json `
  --output .tmp/calibration.json

py -m elder_protocol.cli evaluate run `
  --candidate examples/eval-candidate.json `
  --split holdout `
  --evaluator-id independent-evaluator `
  --judge-results examples/eval-candidate-judge-results.json `
  --calibration .tmp/calibration.json `
  --output .tmp/candidate-evaluation.json

py -m elder_protocol.cli evaluate compare `
  --baseline .tmp/baseline-evaluation.json `
  --candidate .tmp/candidate-evaluation.json `
  --output .tmp/comparison.json
```

## Explicit Limits

P4.2 does not:

- call a model provider directly;
- certify a judge from self-generated labels;
- permit the executor to evaluate its own work;
- approve or promote a candidate;
- establish hosted evaluator isolation;
- cryptographically sign local calibration or evaluation evidence;
- prove real-world product outcomes;
- replace delayed maintainability or production telemetry.
