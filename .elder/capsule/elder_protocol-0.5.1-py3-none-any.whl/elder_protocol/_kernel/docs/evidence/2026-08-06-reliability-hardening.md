# Reliability Hardening Evidence

**Date:** 2026-08-06
**Status:** Local verification complete; hosted verification pending push

## Changes Verified

- The wheel carries the canonical protocol kernel and resolves it from installed package data.
- Integration builds and installs the wheel into a temporary virtual environment, changes to a
  temporary directory outside the checkout, removes `PYTHONPATH`, and runs protocol validation.
- Generated runtime lease tokens have a stable non-option prefix, including when the random
  payload begins with `-`.
- CI test evidence records each test level and aggregates the exact repository, commit, ref,
  workflow, run ID, run attempt, job, runner, Python version, and content digests.
- Hosted evidence ingestion rejects foreign repository, commit, run, attempt, or incomplete test
  evidence before issuing downstream qualification input.
- A shared local-only Draft 2020-12 schema registry validates canonical manifests, project
  profiles, orchestration contracts, and canary contracts before semantic validation.
- CLI parser construction is isolated in `elder_protocol/cli_parser.py`.
- Runtime contract and shared validation helpers are isolated in
  `elder_protocol/orchestration_contracts.py`.
- Canary SQLite persistence is isolated in `elder_protocol/canary_store.py` while preserving the
  existing public import from `elder_protocol.canary`.

## Protocol Test Ladder

```text
Foundation:  18 passed
Component:  154 passed
Integration: 27 passed
Workflow:    15 passed
Stress:      14 passed
Total:      228 passed
```

## Reference Project Test Ladder

```text
Foundation:   2 passed
Component:    3 passed
Integration:  1 passed
Workflow:     1 passed
Stress:       1 passed
Total:        8 passed
```

Protocol validation, Python compilation, isolated installed-wheel validation, and
`git diff --check` also passed.

## Hosted Non-Claim

The workflow defect that allowed a generated lease token to be parsed as a command-line option
is covered by regression tests, and the workflow now produces exact commit/run-bound evidence.
No new hosted run is claimed in this document because the working-tree revision has not been
committed or pushed. Historical hosted evidence remains tied to its historical commit and run.
