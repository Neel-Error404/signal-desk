# P4.6 Quarantined Learning Runtime Evidence

**Date:** 2026-08-05
**Protocol version:** 0.4.7
**Constitution version:** 0.3.5
**Baseline:** `acc8b3d38d1b657f55fe2470e4c729c5f273f9b6`
**Governed implementation commit:** `1779856230f23e3425873761152fa6bb78d520d9`
**Verdict:** VERIFIED for the declared local reference scope
**Maturity effect:** No increase; Elder remains L1

## Claim

Elder can carry one immutable project-bound learning candidate through side-effect-free
counterfactual replay, shadow observation, independent deterministic evaluation, accountable
approval, separate promotion, rollback-packet emission, and deterministic journal replay.

The runtime emits immutable packets only. It cannot apply memory, skill, policy, evaluator,
architecture, production, or other target mutations.

## Implemented Runtime

- Transactional SQLite store with WAL, full synchronous durability, foreign keys, busy timeout,
  integrity checks, and schema metadata.
- Store initialization bound to the learning policy, protocol version, project id, and resolved
  project-authority digest.
- Immutable candidate artifacts copied into the store and bound to repository-relative paths,
  artifact bytes, SHA-256, source evidence, hypothesis, creator, target, expiry, and content
  digest.
- Project-bound candidate creation. The candidate project, creator identity, creator role, and
  `learning-candidate:propose` permission must match resolved authority.
- Side-effect-free counterfactual and shadow observations over immutable input, baseline-output,
  and candidate-output digests.
- Shadow admission blocked until the configured counterfactual replay minimum exists.
- Observation execution restricted to the project-bound `learning-agent` identity with explicit
  execution authority.
- Independent deterministic evaluation restricted to the project-bound `evaluator` identity.
  Candidate creators and observation executors cannot evaluate their own evidence.
- Qualification thresholds for required modes, case counts, better outcomes, worse outcomes,
  critical regressions, quality, cost, latency, and tool-call deltas.
- Kind-specific approvals bound to the project identity and authority matrix:
  `human-owner` for memory, `architecture-owner` for skills, and both roles for policy,
  evaluator, and architecture candidates.
- Separate project-bound promoter with explicit `learning-promotion:promote` authority.
- Immutable promotion and rollback packets with `applies_target_mutation: false`.
- Per-candidate append-only event hash chains, persisted-row content digests, artifact-byte
  verification, record-count comparison, and deterministic lifecycle reconstruction.
- CLI, compiler, schemas, ontology, authority matrix, invariants, capability pack, protocol graph,
  assurance report, profile migration, generated Workbench contracts, and learning-promotion
  skill integration.

## Authority Hardening

Final review found that role labels alone could be forged. Before release, the runtime was bound
to the existing P4.5A project identity and authority model:

- the store rejects a different project profile or authority snapshot;
- cross-project candidates fail closed;
- forged candidate creators fail closed;
- unbound observation executors and evaluators fail closed;
- forged approver-role identity combinations fail closed;
- non-promoter identities cannot emit promotion or rollback packets;
- every protected operation requires the corresponding resource action in resolved authority.

External authentication and signed human decisions remain explicit non-claims.

## Ordered Verification

Root protocol:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 16 | passed |
| Component | 85 | passed |
| Integration | 23 | passed |
| Workflow | 12 | passed |
| Stress | 10 | passed |
| **Total** | **146** | **passed** |

Compiled Elder Workbench:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 2 | passed |
| Component | 3 | passed |
| Integration | 1 | passed |
| Workflow | 1 | passed |
| Stress | 1 | passed |
| **Total** | **8** | **passed** |

Additional checks:

- `py -m pytest -q`: 146 passed in one repository-wide run.
- `py -m pytest --collect-only -q`: 146 tests collected.
- `py -m elder_protocol.cli validate`: passed.
- `py -m elder_protocol.cli assurance`: P4.6 local runtime reported, hosted learning false,
  target mutation false, maturity remains L1.
- Workbench regeneration: 0 changed, 43 unchanged.
- Repository JSON parsing: passed.
- `py -m compileall -q elder_protocol`: passed.
- `git diff --check`: passed.
- Canonical protocol graph: 526 nodes and 981 edges.
- Generated Workbench graph: 546 nodes and 1,551 edges.

## Corrected Failures

1. Component initially rejected the P4.5A fixtures because their protocol versions had migrated
   to 0.4.7 while delegation and checkpoint content digests still represented 0.4.6. The
   digest-bound fixtures were regenerated in dependency order and Component passed on rerun.
2. Repository-wide pytest collection initially found duplicate `test_p4_6_learning.py` module
   basenames across Component and Integration. The Integration module received a unique name,
   Integration was rerun, and full collection and execution passed.
3. Updating ADR 0012 invalidated its governed design-registry hash. The registry digest and
   canonical graph were regenerated before protocol validation and all test ladders.

## Candidate Artifact

- Exact-revision build ID: `b901578459f3`
- Source tree SHA-256:
  `31815b301645c8f3f59aebcddc7db4187988c15a7aafd94e6391adb02297dc76`
- Artifact SHA-256:
  `968de7cc3ce40f31fe4648b8482aad0761c846081a833e1044a03e698209c612`
- Artifact verification: passed
- Smoke decision: `needs-approval`
- Promotion: not performed

The exact implementation revision reproduced the pre-commit candidate artifact without a
source-tree or artifact-digest change.

## P4.6 Non-Claims

P4.6 does not provide:

- live model-provider or external tool execution;
- production traffic mirroring or a hosted shadow service;
- external identity authentication, signed human approvals, or workload identity;
- automatic trusted-memory mutation;
- repository skill installation or policy, evaluator, or architecture modification;
- deployment, production promotion, or automatic target rollback;
- autonomous candidate generation, approval, renewal, or self-ratification;
- hosted durability, tenant isolation, encryption, retention, backup, recovery, or disaster
  recovery;
- target-specific application adapters;
- production self-learning or maturity above the existing evidence-bound L1 assessment.

No artifact promotion, deployment, remote push, or P4.7 implementation was performed. P4.7 must
not start until this committed P4.6 state is explicitly approved.
