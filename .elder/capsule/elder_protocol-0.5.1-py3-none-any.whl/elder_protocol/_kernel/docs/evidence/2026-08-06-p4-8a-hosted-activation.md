# P4.8A Hosted Git and Identity Activation Evidence

**Date:** 2026-08-06

**Status:** VERIFIED for advisory L2 qualification on exact commit
`d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`

## Scope

This work activates the private GitHub remote, hosted CI, provider workload identity capture,
canonical qualification trust material, independently signed provenance, and a genuine advisory
L2 qualification. It does not claim branch protection or GitHub-native stored attestations while
the current private-repository plan rejects those controls.

## Human Decision

The accountable operator explicitly directed implementation of P4.8A after P5 governance
closure. ADR 0017 records the accepted trust boundary: GitHub produces provider evidence, while a
separate operator-held Ed25519 key performs independent verification and signing.

## Local Replay

The ordered root test ladder passed after final hardening:

- Foundation: 18 passed.
- Component: 122 passed.
- Integration: 26 passed.
- Workflow: 15 passed.
- Stress: 13 passed.

Protocol validation, canonical graph regeneration, qualification-policy validation, autonomy
policy validation, Python compilation, and `git diff --check` also passed.

## Independent Review

An independent reviewer rejected the initial same-workflow signing design with two Critical, one
High, and three Medium findings:

- a production signing secret was reachable by pull-request workflow code;
- the workflow signed its own unsupported L0-L2 assertions;
- required checks were represented as caller-generated success strings;
- issuance accepted caller-selected policy and maturity files;
- the trust-anchor subject was not strongly bound;
- negative coverage did not exercise those boundaries.

The design was replaced rather than waived:

- the GitHub environment signing secret was deleted and issuance was disabled;
- no repository workflow receives a qualification private key;
- the evidence-input job runs only for a push to `refs/heads/main`;
- provider runs, attempts, jobs, job IDs, conclusions, revisions, and artifacts are retrieved
  independently through authenticated GitHub API calls;
- OIDC RS256 signatures and immutable repository subjects are verified against GitHub JWKS;
- canonical qualification, maturity, and trust-anchor digests are mandatory;
- every cited source file is hashed from a clean checkout at the hosted head revision;
- the operator verifier signs provenance, records, and the bundle only after those checks pass.

The first hardened hosted run, GitHub Actions run `31083470641`, passed all four required jobs
against commit `bb9de86f5a567a22d1339df8e2254b9d2705ff08`.

A follow-up review then found one High and six Medium issues: generic signed pass records,
excess pull-request permissions, a contradictory active-ruleset claim, missing artifact
digest/job binding, duplicate-job collapse, missing end-to-end issuance coverage, and excessive
OIDC artifact retention. Those issues were fixed with requirement-specific evidence, an
external separately signed governance envelope, least-privilege jobs, exact artifact
ID/URL/digest/size binding, duplicate and incomplete-provider rejection, an end-to-end signed
bundle test, and one-day OIDC artifact retention.

The final review cycle found and closed additional OIDC replay, mutable source, provider job
identity, stale provider-run, and malformed artifact-ID weaknesses. Final enforcement now:

- binds OIDC issuance and validity to the trusted evidence-job execution window;
- rejects provider evidence older than 24 hours at qualification issuance;
- reads cited source bytes from Git objects at the exact hosted revision;
- requires unique positive provider job IDs and canonical repository/run/job URLs;
- requires a positive integer artifact ID before URL construction or download.

The independent reviewer reported no remaining Critical, High, or Medium findings on exact
commit `d8c8eb3f5412bf1fe062a6cee55e35dd45e46589` and signed the exact
commit/run/artifact statement with trust anchor `p4-8a-independent-reviewer-v1`.

## Hosted Qualification Result

GitHub Actions run `31088377331` passed the four required jobs on the exact reviewed commit:

- `P3 / protocol`: job `92573174088`;
- `P3 / reference-project`: job `92573174068`;
- `P3 / reproducible-artifact`: job `92573174023`;
- `P4.8A / hosted-evidence-input`: job `92573336604`.

Provider artifact `8962374642` was downloaded and independently checked against its GitHub API
ID, canonical archive URL, byte size, and provider SHA-256.

- Provider archive SHA-256:
  `c78c0bbceb9263bd1e10724fe275bf8f25912db63bf2ce3c93cfc53c4bdcce1c`.
- Reproducible build artifact SHA-256:
  `2aba1a7e3cb185a6161b709bd103dda7a2c258e54869f0217637080c1c045dae`.
- Source-tree SHA-256:
  `39ea3ddeb997ef004a59660383985d38c06942d4492089e1e6b670802d5aca38`.
- Signed evidence records: 18.
- Issued level: advisory `L2`.
- Canonical maturity after issuance: `L1`.
- Raw bundle-file SHA-256:
  `65149bdcca11fd0c89ff9b7e4d04a4439feef4ad9ad8a0b146a424a5598e3a45`.
- Canonical bundle SHA-256:
  `8f9ee4f34e244e51ae3fe5d8428749ca6f0fca4443bbc6370effa314aa7ef5c0`.
- Qualification-report SHA-256:
  `ca4e4d53350d6f259034ecb09773d8c55b9ee6598e02c0d69a967ac90bb32bfd`.

The canonical verifier replayed the emitted bundle against maturity digest
`6161859718f5477ccdc19218d03971dd4cdf2a6d40e1c1095f1fc5a6ec13bac8`, accepted all 18 required
L0-L2 records, reported no L2 blockers, and confirmed that the result is advisory only. Durable
verifier inputs and current replay outputs are stored in
`docs/evidence/artifacts/p4-8a-run-31088377331/`. The raw downloaded provider archive is not
committed because it contains the short-lived GitHub OIDC token.

## External Blockers

GitHub returned plan-level errors for:

- branch protection and repository rulesets on the user-owned private repository;
- deployment-branch restrictions on the `production` environment;
- GitHub-native persisted artifact attestations.

The planned rules remain fail-closed. They may be activated only after the repository becomes
public or the account plan is upgraded.

These external blockers prevent protected-branch activation and P5.2 authority activation, but
they do not invalidate the provider-bound advisory L2 qualification for the reviewed commit.
