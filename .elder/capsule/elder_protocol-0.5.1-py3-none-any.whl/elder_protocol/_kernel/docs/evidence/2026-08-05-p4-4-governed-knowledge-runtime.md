# P4.4 Governed Knowledge Runtime Evidence

**Date:** 2026-08-05
**Protocol version:** 0.4.4
**Constitution version:** 0.3.4
**Verdict:** VERIFIED for the declared local reference scope
**Maturity effect:** No increase; Elder remains L1

## Claim

Elder can persist a provenance-bound local knowledge graph, keep candidate and trusted memory
separate, require independent human approval for trusted-memory transitions, and assemble
deterministic authority-filtered context packets with explicit budgets and exclusions.

## Implemented Controls

- SQLite reference store with foreign keys, WAL mode, full synchronous durability, busy timeout,
  schema metadata, and integrity checks.
- Transactional idempotent graph ingest with typed nodes, edges, provenance, lifecycle status,
  authority, and content digests.
- Namespace-scoped episodic, semantic, and procedural memory.
- Candidate-only agent writes with expiry and evidence requirements.
- Independent `human-owner` approval for promotion, rejection, supersession, and revocation.
- Trusted-only default retrieval with expiry and review enforcement.
- Append-only audit events for graph ingest and memory transitions.
- Deterministic authority, status, freshness, identifier, and budget filtering.
- Content-digest deduplication and explicit optional-source exclusions.
- Fail-closed required sources.
- Immutable context packets bound by `content_sha256`.
- Provider-neutral CLI, compiler output, protocol graph, ontology, invariant, authority, pack,
  assurance, and Workbench integration.

## Graph And Contract Evidence

- Canonical protocol graph: 422 nodes and 721 edges.
- Context policy: `elder-governed-context-v1`.
- Memory policy: `elder-governed-memory-v1`.
- Allowed context authority: primary, secondary, and historical.
- Default memory retrieval status: trusted only.
- Trusted-memory promoter role: `human-owner`.
- Context authority mode: read-only assembly.
- General factory operational: false.
- Current factory maturity ceiling: L1.

## Verification Ladder

Root protocol:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 13 | passed |
| Component | 51 | passed |
| Integration | 7 | passed |
| Workflow | 8 | passed |
| Stress | 5 | passed |
| **Total** | **84** | **passed** |

Reference Workbench:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 2 | passed |
| Component | 3 | passed |
| Integration | 1 | passed |
| Workflow | 1 | passed |
| Stress | 1 | passed |
| **Total** | **8** | **passed** |

JSON parsing, Python compilation, protocol validation, graph drift validation, compiler
regeneration, and `git diff --check` also passed. The factory clean build reran the complete
Workbench ladder.

## Corrected Failures

1. Foundation initially rejected the evaluation registry after the protocol-version migration
   changed the governed dataset digest. The registry digest was recomputed and Foundation passed
   on rerun.
2. A Component negative test expected an unknown graph endpoint to fail during store ingest.
   The graph finalizer correctly rejected it earlier, so the test was corrected to assert the
   actual fail-closed boundary and Component passed on rerun.
3. Final compatibility review found that profile migration accepted through `0.4.2` but omitted
   `0.4.3`. The migration path and a regression test were added before the final ladder.
4. The temporary evidence summarizer requested `packet_sha256`; the contract correctly exposes
   `content_sha256`. The collector was corrected without changing the already valid runtime
   packet.

## Real Workbench Runtime Evidence

Fresh artifacts under `.tmp/p4-4-evidence-20260805-final/` contain the Workbench run, generated
knowledge graph, SQLite store, approval artifact, context request, context packet, and summary.

| Measure | Result |
|---|---:|
| Workbench decision | `needs-approval` |
| Knowledge-store integrity | `ok` |
| Journal mode | `wal` |
| Foreign keys | enabled |
| Graph nodes | 7 |
| Graph edges | 6 |
| Trusted memories | 1 |
| Audit events | 3 |
| Context sources | 5 |
| Source kinds | repository, knowledge-node, memory |
| Context exclusions | 0 |
| Estimated context tokens | 1,656 |
| Context digest | `5ff7b1f530fa6ac4fe437bb89af5b65650fa41b4650e21ff0f27a23cf4d5ae81` |

The trusted episodic memory was proposed by `workbench-learning-agent` and promoted by the
separate `elder-architecture-owner` human role. The context packet retained repository,
knowledge-node, and trusted-memory provenance.

## Candidate Artifact

- Build ID: `2ab17d7218aa`
- Source tree SHA-256:
  `8b1b8672a83a1c3824f68e253b2e28aada1a0901b2d63f52d15bf35d9adcdeb1`
- Artifact SHA-256:
  `0a14be0d1365cc2dc04780958b36c3baa70bd426652cfc877ebfaba14a5229f7`
- Artifact verification: passed
- Smoke decision: `needs-approval`
- Promotion: not performed

## Remaining Gaps

P4.4 does not provide:

- hosted or multi-tenant graph and memory service;
- authentication, authorization, encryption-key management, backup, restore, or disaster
  recovery for the local store;
- embeddings, vector search, semantic reranking, or hosted visualization;
- autonomous memory consolidation or trusted-memory promotion;
- agent messaging, delegation, checkpoint orchestration, or shared multi-agent state;
- quarantined replay, counterfactual evaluation, shadow mode, or learning promotion;
- signed hosted provenance or production durability evidence.

These boundaries keep P4.4 operational for its local reference scope without overstating a
production software factory. No push, deployment, artifact promotion, or P4.5 implementation was
performed.
