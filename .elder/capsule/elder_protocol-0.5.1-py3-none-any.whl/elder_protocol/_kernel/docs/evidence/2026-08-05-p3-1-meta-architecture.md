# P3.1 Hierarchical Meta-Architecture Evidence

**Date:** 2026-08-05
**Protocol version:** 0.3.0
**Decision:** ADR 0004 accepted and human-ratified

## Claim

Elder now represents a product-agnostic software-factory hierarchy through
machine-readable meta-architecture, typed capability-pack contracts, a
deterministic canonical protocol graph, and generated project overlays.

## Implemented

- Six-layer hierarchy:
  - universal kernel;
  - capability packs;
  - stack adapters;
  - project implementation;
  - factory operations;
  - assurance and learning.
- Capability-pack schema and complete contracts for core, agentic, web product,
  data, regulated, learning, and go-to-market packs.
- Separate `contract_status` and `runtime_status` to prevent configuration from
  being represented as operational capability.
- Canonical protocol graph generated from meta-architecture, packs, skills,
  schemas, invariants, change classes, authority roles, and ontology.
- Validation fails when the checked-in graph differs from deterministic
  regeneration.
- Generated selected capability-pack contracts and project graph.
- Generated `AGENTS.md` read order, factory/product boundary, mutability rules,
  and evidence route.
- `elder graph --output <path>` inspection command.
- Profile migration from 0.1.0 and 0.2.0 to 0.3.0 draft review.
- Ownership-protected Elder Workbench regeneration.

## Graph Evidence

```text
Canonical protocol graph: 170 nodes, 257 edges
Workbench project graph:   147 nodes, 235 edges
Selected Workbench packs:  core, agentic, web-product, data, go-to-market
```

The agentic pack contract is implemented while its runtime status is
`reference-only`. Memory, eval, MCP, and external tool capabilities therefore
remain non-operational claims.

## Verification

```text
Foundation:  8 passed
Component:  23 passed
Integration: 3 passed
Workflow:    3 passed
Stress:      3 passed
Total:      40 passed
```

Stress evidence includes fifty compiler regenerations, ten fixture clean
builds resolving to one digest, and three full Workbench clean builds remaining
stable.

Additional closure checks:

- `elder validate` passed.
- Canonical graph CLI emission passed.
- Workbench dry-run regeneration reported zero changes and thirteen unchanged
  Elder-owned files.
- Product-owned Workbench source, tests, UI, data, and product ADRs were not
  overwritten.

## Verified Candidate Artifact

```text
Artifact SHA-256:
fca10740dedd82ed6f5a61de28c8c676caa9a9205e0a7037b2ee4e365278f189

Build:
66075a19bbb8

Source tree SHA-256:
59517a04a8b8a508b985eb8c530e271fda39ef50627646a281c5317f35c4c99d

Smoke verification:
passed; decision needs-approval
```

This candidate was not promoted. Approval for an earlier canary digest does
not authorize the P3.1 artifact.

## Boundaries

P3.1 does not implement:

- stack-adapter contracts or technology-specific adapters;
- persistent graph database, ingestion, query, or graph service;
- runtime evidence and learning graph storage;
- comprehensive specialty-pack practice generators;
- independent eval, replay, memory promotion, or multi-agent runtime;
- hosted Git governance, external identity, secret broker, or production
  deployment.

These remain explicit next-stage work and must not be inferred from pack
selection or graph presence.
