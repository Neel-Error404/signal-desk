# P4.1 Operational Assurance Evidence

**Date:** 2026-08-05
**Protocol version:** 0.4.1
**Scope:** Versioned design governance, executable architecture boundaries, and
independent deterministic transcript review.

## Implemented

- A hash-bound design-document registry with explicit owners, status, change class,
  notification policy, supersession, and content-digest validation.
- Six registered ADRs with validation that rejects missing, stale, duplicate, or
  out-of-root documents.
- A machine-readable architecture-boundary contract and a Python AST import adapter.
- A project-owned Elder Workbench boundary contract covering ten Python modules.
- An independent transcript-review runtime that rejects self-review and reports
  findings without approval or promotion authority.
- Transcript checks for run identity, event sequencing, lifecycle completeness,
  failed-event budget, elapsed time, and secret-shaped fields.
- Protocol graph, capability-pack, ontology, assurance-report, compiler, CLI, and
  generated-project integration for all three controls.

## Graph Evidence

- Canonical protocol graph: 351 nodes and 578 edges.
- Registered design documents: 6.
- Architecture-boundary adapters: `python-ast-imports`.
- Transcript evaluator: `deterministic-advisory`.
- Current factory maturity ceiling: L1, traceable assisted.
- `general_factory_operational`: false.

## Operational Verification

- Root design registry: 6 documents, no stale content hashes.
- Generated Workbench design registry: 1 proposed ADR, no stale content hashes.
- Workbench architecture boundary: 10 modules, no dependency violations.
- Actual Workbench trace review: 22 events across 11 nodes, independently reviewed,
  advisory-only, verdict `pass`.
- No evaluator approval or artifact-promotion authority exists.

## Test Evidence

Root protocol:

- Foundation: 10 passed.
- Component: 32 passed.
- Integration: 4 passed.
- Workflow: 5 passed.
- Stress: 3 passed.
- Total: 54 passed.

Elder Workbench:

- Foundation: 2 passed.
- Component: 3 passed.
- Integration: 1 passed.
- Workflow: 1 passed.
- Stress: 1 passed.
- Total: 8 passed.

## Candidate Artifact

- Artifact digest:
  `3acf9c2e5fd47d9e7987f5e6633bda0067c1b529bdf4b73a51ced9e7ebcff112`
- Build ID: `9063ffe1a70e`.
- Source tree digest:
  `9d05689cdee030d0d3cca2f29f117231238b592f584d770a12ffe235bb60817b`
- All five artifact build test levels passed.
- Artifact smoke verification passed.
- Smoke decision: `needs-approval`.
- The artifact was not promoted.

## Operational Verdict

P4.1 closes three deterministic local assurance gaps: design intent can be checked
for staleness, Python dependency direction is executable, and execution transcripts
can receive an independent advisory review.

The whole-system maturity claim remains L1. P4.1 does not establish hosted required
checks, signed provenance, external workload identity, hardened isolation,
probabilistic evaluation and calibration, production telemetry, remote canary
observation, or real rollback evidence.

No Git staging, commit, push, artifact promotion, or deployment was performed.
