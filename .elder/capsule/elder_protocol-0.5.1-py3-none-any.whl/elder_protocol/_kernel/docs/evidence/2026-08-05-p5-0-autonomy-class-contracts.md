# P5.0 Autonomy-Class Contracts Evidence

> Historical checkpoint: this file records the P5.0-only verification state before P5.1 and
> P5.2 were implemented. For the current P5 implementation and governance status, see
> `docs/evidence/2026-08-06-p5-1-p5-2-bounded-autonomy.md`.

**Date:** 2026-08-05
**Protocol version:** 0.4.9
**Constitution version:** 0.3.6
**Baseline:** `95260f9ea5b9bc8df4c5846bc6cec8aa890ca03d`
**Implementation state:** Working tree only; no commit created without explicit permission
**Verdict:** VERIFIED for the declared contract-only scope
**Maturity effect:** No increase; Elder remains L1

## Claim

Elder can represent five narrow reversible autonomy subclasses, re-verify approved P4.7
qualification inputs, validate certification and governance records, and deterministically
calculate an evidence-bound effective autonomy level.

This verifies contracts and calculation only. It does not activate certification or grant
runtime, pull-request, merge, deployment, maturity-mutation, or automatic-renewal authority.

## Implemented Contracts

- Exactly five initial subclasses:
  documentation-only corrections, deterministic generated regeneration,
  semantic-preserving formatting, approved deterministic lint fixes, and add-only tests.
- Dependency and configuration changes remain excluded.
- Approved qualification-policy, maturity-model, and trust-anchor-set digest pinning.
- P4.7 bundle re-verification with project, environment, artifact, requested-level, freshness,
  signature, payload, and contradiction checks.
- Certification, incident-budget, qualification-consumption, suspension, revocation, renewal,
  and effective-autonomy schemas and validators.
- Effective autonomy as the minimum of verified hosted maturity, project ceiling, selected
  autonomy-class maximum, and active certification level.
- Fail-closed handling for invalid or expired qualification, certification expiry, suspension,
  revocation, contradiction, and incident-budget exhaustion.
- Explicit no-authority fields for certification activation, runtime leases, PR creation,
  merge, deployment, maturity mutation, and automatic renewal.
- Ontology, authority matrix, invariants, recommendation ledger, capability pack, canonical
  graph, assurance report, compiler, CLI, generated Workbench contracts, and documentation.

## Canonical Result

- Current maturity: L1.
- Initial autonomy classes: 5.
- Maximum initial class level: L2.
- Qualification consumption: `reverify-pinned-inputs`.
- Effective calculation: `minimum`.
- Authority activated: false.
- Active certification: none.
- Configured canonical P4.7 trust anchors: 0.

## Ordered Verification

Root protocol:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 18 | passed |
| Component | 100 | passed |
| Integration | 25 | passed |
| Workflow | 14 | passed |
| Stress | 12 | passed |
| **Total** | **169** | **passed** |

Compiled Elder Workbench:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 2 | passed |
| Component | 3 | passed |
| Integration | 1 | passed |
| Workflow | 1 | passed |
| Stress | 1 | passed |
| **Total** | **8** | **passed** |

Additional checks:

- `py -m elder_protocol.cli validate`: passed.
- `py -m elder_protocol.cli autonomy validate`: five classes, contracts-only, no authority.
- `py -m elder_protocol.cli assurance`: L1 and all P5.0 authority fields false.
- Python byte compilation: passed.
- Repository JSON parsing: passed.
- `git diff --check`: passed.
- Canonical protocol graph: 591 nodes and 1,142 edges.
- Generated Workbench graph: 618 nodes and 1,787 edges.

## Corrected Failures

1. The protocol-version migration changed the registered evaluation dataset bytes. The
   evaluation registry retained the prior digest, so connected validation failed closed. The
   registry digest was updated to the migrated dataset bytes and validation passed on rerun.
2. The P4.5A fixture versions migrated to 0.4.9 while delegation, invalid-delegation, and
   checkpoint digests still represented 0.4.8. All six fixture digests were regenerated and the
   entire Component level passed on rerun.
3. Contract review tightened documentation-only exclusions for governed, architecture,
   generated, policy, prompt, and runbook files and exposed every denied P5.0 authority in the
   effective-autonomy report.
4. Closing review enforced the class certification TTL and required incident-budget limits and
   windows to remain within the selected autonomy class.

## P5.0 Non-Claims

P5.0 does not provide:

- an active autonomy certification or certification issuance workflow;
- work-item classification, simulated execution, replay, or incident accounting from P5.1;
- autonomous branch creation, pull-request creation or submission, merge, or deployment;
- runtime authority leases or remote agent execution;
- automatic suspension execution, revocation execution, or renewal;
- maturity creation, mutation, promotion, or reinterpretation;
- configured external qualification trust anchors or a qualifying hosted evidence bundle;
- L2 or L3 hosted qualification required by P5.2 or P5.3;
- hosted Git governance, CI evidence, workload identity, secret brokering, or production canary
  evidence.

At this historical checkpoint, no commit, push, promotion, deployment, maturity change, or P5.1
implementation was performed.
