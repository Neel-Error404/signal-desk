# P4.3 Correlated Telemetry Evidence

**Date:** 2026-08-05  
**Protocol version:** 0.4.3  
**Constitution version:** 0.3.3  
**Verdict:** VERIFIED for the declared local reference scope  
**Maturity effect:** No increase; Elder remains L1

## Claim

Elder can normalize and correlate local product, model, tool, factory, cost, and outcome
evidence through one typed provider-neutral contract. It can validate privacy and trace-context
rules, aggregate low-cardinality metrics, evaluate local budgets, and preserve advisory-only
authority.

## Implemented Controls

- `protocol/telemetry-contract.json` pins trace context, reviewed GenAI convention status,
  six telemetry scopes, correlation fields, privacy, metric cardinality, budgets, and authority.
- `protocol/telemetry-event.schema.json` and `protocol/telemetry-report.schema.json` define the
  append-only event and advisory aggregate contracts.
- `elder_protocol/telemetry.py` normalizes Workbench JSONL, factory JSONL, and evaluation reports.
- Workbench runs now emit one native trace ID, one root span, and child node spans.
- Invalid historical context is synthesized deterministically and marked as synthesized.
- `project_id` and `run_id` are mandatory on every event.
- Work-item, agent-run, artifact, deployment, evaluation, and outcome identifiers are prohibited
  as metric dimensions.
- Prompt and model-output persistence is disabled by default.
- Secret-shaped attributes and dimensions fail closed.
- Reports aggregate cost, tokens, tool calls, duration, error rate, outcomes, correlation
  completeness, and metric-series cardinality.
- Reports cannot approve or promote.

## Verification Ladder

Root protocol:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 12 | passed |
| Component | 45 | passed |
| Integration | 6 | passed |
| Workflow | 7 | passed |
| Stress | 4 | passed |

Reference Workbench:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 2 | passed |
| Component | 3 | passed |
| Integration | 1 | passed |
| Workflow | 1 | passed |
| Stress | 1 | passed |

The factory also executed the complete Workbench ladder during the clean candidate build.

## Corrected Failures

1. Foundation initially rejected the P4.2 evaluation registry because the protocol-version
   migration changed the dataset digest. The registry digest was updated and Foundation was
   rerun successfully.
2. Component initially rejected five P4.2 candidate/judge fixtures that still declared version
   0.4.2. The governed fixtures were migrated to 0.4.3 and Component was rerun successfully.
3. Workflow initially rejected the Workbench architecture-boundary contract at version 0.4.2.
   The project-owned contract was migrated to 0.4.3 and Workflow was rerun successfully.
4. Temporary evidence aggregation initially used PowerShell UTF-8 with a BOM. The strict JSONL
   parser correctly rejected it; the temporary aggregate was rewritten as UTF-8 without BOM.

## Correlated Runtime Evidence

Fresh evidence under `.tmp/p4-3-evidence/` combined:

- one real Workbench run with native trace context;
- the actual append-only factory lifecycle trace;
- one governed holdout evaluation report.

Aggregate result:

| Measure | Result |
|---|---:|
| Events | 127 |
| Traces | 25 |
| Runs | 25 |
| Product events | 11 |
| Model events | 1 |
| Tool events | 1 |
| Factory events | 112 |
| Cost events | 1 |
| Outcome events | 1 |
| Correlation completeness | 1.0 |
| Error rate | 0.0 |
| P95 recorded duration | 2.163 ms |
| Total measured cost | USD 0.07 |
| Tool calls | 5 |
| Met outcomes | 1 |
| Cardinality overflow metrics | 0 |
| Budget verdict | pass |
| Approval authority | false |
| Promotion authority | false |

## Candidate Artifact

- Build ID: `f6d551f3531d`
- Source tree SHA-256:
  `a5a9d0707bf37597a9551d58be8612f9ad5c99beaec00ab7c097976aae3494b6`
- Artifact SHA-256:
  `98e9af8d267e61754b1fe42700afa8998f6f1c359f65cd537786bf31c3731b25`
- Smoke verification: passed
- Smoke decision: `needs-approval`

## Remaining Gaps

P4.3 does not provide:

- OTLP export or a hosted OpenTelemetry collector;
- production retention, access control, alerting, dashboards, or paging;
- trace exemplars attached to an external metrics backend;
- remote canary or rollback observation;
- production model-provider token metering;
- convention-drift automation;
- persistent knowledge-graph, context, or memory runtime;
- approval, promotion, or spending authority.

These gaps keep the whole-system maturity assessment at L1 and define the activation boundary
for hosted production observability and later P4 stages.
