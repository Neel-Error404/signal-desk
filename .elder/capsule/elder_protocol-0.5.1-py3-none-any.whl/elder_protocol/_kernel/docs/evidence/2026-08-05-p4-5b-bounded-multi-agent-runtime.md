# P4.5B Bounded Multi-Agent Runtime Evidence

**Date:** 2026-08-05
**Protocol version:** 0.4.6
**Constitution version:** 0.3.5
**Baseline:** `f8eed0cf6c140d370c81496796f08a8381aed477`
**Verdict:** VERIFIED for the declared local reference scope
**Maturity effect:** No increase; Elder remains L1

## Claim

Elder can coordinate one validated parent/delegation/child chain through a transactional local
SQLite runtime. The coordinator binds child operations to an assigned-identity lease, journals
typed actions and messages, enforces authority and resource ceilings, persists checkpoints,
propagates cancellation, expires overdue work, and verifies deterministic lifecycle replay.

The coordinator cannot approve, promote, deploy, or mutate policy.

## Implemented Runtime

- SQLite coordinator with WAL, full synchronous durability, foreign keys, busy timeout, integrity
  checks, and a runtime-policy digest fixed at initialization.
- Complete submission validation across project authority, parent run, delegation, child run,
  context packet, delegated scope, deadlines, budgets, and tools.
- Deterministic claim order and short-lived assigned-identity leases whose tokens are stored only
  as SHA-256 digests. Complete lease artifacts and lifecycle transitions are digest-bound.
- Typed append-only action, message, checkpoint, cancellation, escalation, and runtime-event
  journals. Cancellation and escalation rows are digest-bound to their complete event artifacts.
- Operation-specific run authority checks; possession of a lease does not grant message,
  checkpoint, cancellation, escalation, approval, or promotion authority.
- Action validation covering identity, authority, tool grants, contiguous sequence, full lease
  interval, deadline, cumulative budget, and checkpoint frequency.
- Checkpoints bound to cumulative action budget, a signed `action_sequence`, monotonic time,
  previous-checkpoint digest, scope completion, and required evidence.
- Transactional cancellation propagation across active descendant delegations, runs, and leases.
- Earliest-deadline expiry using delegation deadline, delegation expiry, and child-run deadline.
- Consistent runtime snapshots, connected runtime graphs, persisted-row digest validation, global
  event hash-chain validation, and deterministic state reconstruction.
- Compiler, CLI, ontology, protocol graph, capability pack, assurance, and generated Workbench
  integration.

## Review And Hardening

The first independent subagent review found nine material gaps. All were closed before the final
ladder:

1. Terminal cancellation behavior and direct-child delegation closure were made consistent.
2. Delegated context submission was rebound to actual repository content.
3. Parent lifecycle and active-descendant constraints were enforced.
4. Action start and completion must both occur inside the active lease.
5. Expiry now includes the child-run deadline.
6. Journal-row content digests are verified during replay.
7. Snapshot and replay reads use consistent transactions.
8. The runtime-policy schema now matches the Python validator.
9. Stress-test naming and pytest discovery were corrected.

The second review found three narrower gaps:

- checkpoint action coverage existed outside the signed checkpoint;
- repository provenance metadata and whitespace comparison were incomplete;
- pytest still considered the shared workspace helper test-like.

The checkpoint contract now signs `action_sequence`, admission requires it to equal the persisted
action count, and replay binds the checkpoint field to the event and journal. Repository
provenance must resolve to the same file as `location`, `record_id` must be null for repository
sources, and raw UTF-8 bytes are decoded without newline translation so CRLF/LF and trailing
whitespace changes fail closed. The shared workspace helper is explicitly excluded from pytest
collection.

A final independent verification confirmed checkpoint tampering fails replay, provenance and
ordinary whitespace binding are enforced, and pytest collection is clean. It then identified the
CRLF normalization edge case; raw-byte decoding and a CRLF-to-LF regression test closed it. No
other immediate P4.5B correctness regression remained.

The replay-journal hardening pass then closed four persistence gaps:

- cancellation replay no longer infers a cancelled lease when no lease exists;
- every lease row stores a complete digest-bound artifact, and claim, release, expiry, and
  cancellation events carry complete validated lease transitions;
- cancellation and escalation rows are digest-bound and their events must carry the same complete
  artifact and digest;
- replay compares lease, cancellation, and escalation artifacts and counts with persistence.

Negative integration tests mutate and delete each of the lease, cancellation, and escalation
record types and require replay to fail closed. The local runtime-store schema is now version 2;
schema-version-1 stores require an explicit rebuild because P4.5B does not claim an in-place
migration.

## Ordered Verification

Root protocol:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 15 | passed |
| Component | 79 | passed |
| Integration | 20 | passed |
| Workflow | 11 | passed |
| Stress | 8 | passed |
| **Total** | **133** | **passed** |

Compiled Elder Workbench:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 2 | passed |
| Component | 3 | passed |
| Integration | 1 | passed |
| Workflow | 1 | passed |
| Stress | 1 | passed |
| **Total** | **8** | **passed** |

Additional checks:

- `py -m elder_protocol.cli validate`: passed.
- `py -m elder_protocol.cli assurance`: P4.5B runtime orchestration true, hosted orchestration
  false, maturity remains L1.
- `py -m compileall`: passed.
- `py -m pytest --collect-only -q`: 133 tests collected; no helper miscollection.
- `git diff --check`: passed.
- Workbench regeneration changed only `.elder/multi-agent-runtime-policy.json` and its generated
  ownership digest.
- Workbench product source, web assets, and product tests: unchanged.
- Canonical protocol graph: 507 nodes and 935 edges.
- Candidate artifact:
  `9f1a57dc0a317b69c1b0346062fce5e25daa12fb08fec9fae769b60510195267`.
- Candidate build `30dc6c925bd6`, source-tree digest
  `3c69a9a1563229da6c6243494d287ee4d2a677b8fdf2f0bb8567b43c28a4238e`.
- Artifact smoke verification: passed with decision `needs-approval`.

## P4.5B Non-Claims

P4.5B does not provide:

- external identity authentication, signed human requests, or workload identity;
- a hosted broker, remote worker service, distributed scheduler, or multi-tenant coordinator;
- OS or container isolation for untrusted tools;
- model-provider or tool execution;
- hosted checkpoint durability, encryption, retention, backup, restore, or disaster recovery;
- autonomous evaluation, accountable approval, artifact promotion, deployment, or policy change;
- counterfactual execution, shadow learning, candidate promotion, or production self-learning;
- a second reference product or proof of general software-factory operation;
- production readiness above the existing evidence-bound L1 assessment.

No artifact promotion, deployment, remote push, or P4.6 implementation was performed. P4.6 must
not start until this committed P4.5B state is explicitly approved.
