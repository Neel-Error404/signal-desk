# P4.2 Evaluation Harness Evidence

**Date:** 2026-08-05
**Protocol version:** 0.4.2
**Scope:** Governed evaluation datasets, calibrated independent rubric judgment,
paired candidate comparison, and advisory-only evaluation reports.

## Implemented

- A hash-bound evaluation-dataset registry with owner, status, notification, and
  content-digest validation.
- A ten-case reference dataset separated into development, calibration, and
  holdout splits.
- Exact, contains, numeric-tolerance, and rubric graders.
- A typed evaluator contract that requires immutable inputs and distinct executor
  and evaluator identities.
- Human-owned calibration reference labels with minimum sample, accuracy, F1, and
  maximum abstention thresholds.
- Calibration reports bound to the exact dataset, evaluator contract, and judge
  result revisions.
- Candidate reports with quality, latency, cost, tool-call, trace, and slice
  evidence.
- Paired baseline/candidate comparison with critical-regression fail-closed
  behavior.
- Compiler, protocol graph, capability-pack, ontology, assurance, CLI, and
  generated-project integration.

## Graph And Contract Evidence

- Canonical protocol graph: 381 nodes and 631 edges.
- Registered evaluation datasets: 1 active dataset.
- Dataset cases: 10 total.
- Split sizes: 2 development, 4 calibration, and 4 holdout.
- Allowed graders: `exact`, `contains`, `numeric`, and `rubric`.
- Evaluation and comparison authority: advisory-only.
- Evaluators cannot approve, promote, or modify policy.
- Current factory maturity ceiling: L1, traceable assisted.
- `general_factory_operational`: false.

## Operational Verification

- Dataset registry validation: 1 dataset, 1 active, no stale digest.
- Reference judge calibration: 4 samples, 1.0 accuracy, 1.0 precision, 1.0
  recall, 1.0 F1, and 0.0 abstention.
- Weak baseline: 0 of 4 holdout cases passed; expected CLI exit code 1.
- P4.2 candidate: 4 of 4 holdout cases passed.
- Paired comparison: 4 wins, 0 losses, 0 ties, and no critical regression.
- Real Workbench smoke output passed the calibrated holdout evaluation.
- Contract-revision drift and evaluator/executor identity collisions fail closed.

## Test Evidence

Root protocol:

- Foundation: 11 passed.
- Component: 40 passed.
- Integration: 5 passed.
- Workflow: 6 passed.
- Stress: 3 passed.
- Total: 65 passed.

Elder Workbench:

- Foundation: 2 passed.
- Component: 3 passed.
- Integration: 1 passed.
- Workflow: 1 passed.
- Stress: 1 passed.
- Total: 8 passed.

## Candidate Artifact

- Artifact digest:
  `c2466e4e9cfeb61e707e7c12e7778295dc4fdffa10a7c9fbeec5f42f61efcd3f`.
- Build ID: `b6e41cd6d013`.
- Source tree digest:
  `4fba1a3e13cea2b086bc23b249abb51195a89e523b3ed60373297f9ba80ffd1f`.
- All five artifact build test levels passed.
- Artifact smoke verification passed.
- Smoke decision: `needs-approval`.
- The artifact was not promoted.

## Operational Verdict

P4.2 provides a working local evaluation substrate for deterministic and
probabilistic grading. It makes calibration, dataset revision, evaluator
independence, candidate evidence, and comparative regression explicit and
machine-checkable.

The whole-system maturity claim remains L1. P4.2 does not provide a live model
provider, hosted evaluator isolation, multi-rater agreement, calibration-drift
monitoring, signed evidence, delayed production-quality measurement, or promotion
authority.

No push, artifact promotion, or deployment was performed.
