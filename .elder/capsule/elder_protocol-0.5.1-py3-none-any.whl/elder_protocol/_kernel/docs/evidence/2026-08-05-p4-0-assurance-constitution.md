# P4.0 Assurance Constitution Evidence

**Date:** 2026-08-05
**Protocol version:** 0.4.0
**Scope:** Recommendation traceability, anti-slop architecture, component contracts,
judgment and taste, production maturity claims, and generated project assurance contracts.

## Ratified Inputs

The operator adopted:

- software-factory realism and the requirement to build non-agent substrate first;
- sandboxing, deliberate repository topology, reproducible builds, CI/CD, identity, secrets,
  and agent developer experience;
- concise stable architecture invariants and rigorous versioned design intent;
- executable dependency boundaries;
- independent meta-agent transcript review without approval authority;
- inspectable execution traces;
- typed tools and cross-language boundaries;
- explicit AI judgment and taste subordinate to deterministic controls.

The ledger also records primary production standards for NIST AI secure development, SLSA
provenance, OpenTelemetry GenAI telemetry, and MCP authorization.

## Implemented

- Protocol version raised from 0.3.0 to 0.4.0.
- ADR 0005 accepted and the constitutional axioms extended.
- Twenty-entry recommendation ledger with forty controls.
- Validation rejects unknown layers, duplicate controls, invalid evidence, and
  probabilistic-only enforcement.
- Mandatory `factory-operations` and `assurance` capability packs.
- Required packs are automatically selected for every project profile.
- Component operating contract schema covering types, dependencies, side effects, authority,
  data, failures, telemetry, cost, verification, deployment, and rollback.
- Evidence-cited judgment rubric with deterministic vetoes.
- L0-L5 operational maturity model with a current L1 assessment.
- `elder assurance` machine-readable status report.
- Protocol graph integration for recommendations, controls, maturity levels, and judgment
  dimensions.
- Generated project recommendation ledger, judgment rubric, maturity assessment, assurance
  contract, and component contract instructions.
- Ownership-protected Elder Workbench regeneration under 0.4.0.

## Graph Evidence

- Canonical protocol graph: 331 nodes and 553 edges.
- Current recommendations: 20.
- Current controls: 40.
- Current factory maturity ceiling: L1, traceable assisted.
- `general_factory_operational`: false.

## Verification

Root protocol:

- Foundation: 9 passed.
- Component: 24 passed.
- Integration: 3 passed.
- Workflow: 4 passed.
- Stress: 3 passed.
- Total: 43 passed.

Elder Workbench:

- Foundation: 2 passed.
- Component: 3 passed.
- Integration: 1 passed.
- Workflow: 1 passed.
- Stress: 1 passed.
- Total: 8 passed.

`git diff --check` passed.

## Candidate Artifact

- Artifact digest:
  `382e4bb09c50359bd10a66054a91c5941b4bd14e96fa985a33c0192f7e60c3cb`
- Build ID: `2bf904982f09`
- Source tree digest:
  `8f22b6f64d9f04c635f82791af8b586ffafd2589ed142f0926fff2628b0592fb`
- All five artifact build test levels passed.
- Artifact smoke verification passed.
- Smoke decision: `needs-approval`.
- The artifact was not promoted.

## Operational Verdict

P4.0 is operational as protocol validation, graph generation, project compilation, assurance
reporting, and local evidence production.

The software factory is not generally operational or almost lights-out. The current whole-system
claim remains L1 because the following are not verified:

- hosted branch protection, merge queue, CI, and signed provenance;
- external workload identity and secret brokering;
- OS or container isolation for untrusted tools;
- independent evaluation and transcript-review services;
- calibration datasets and delayed maintainability measurement;
- OpenTelemetry GenAI export and central retention;
- persistent knowledge graph, governed memory, replay, shadow, and learning promotion;
- remote canary observation and real rollback against a second approved artifact.

No Git staging, commit, push, or artifact promotion was performed.
