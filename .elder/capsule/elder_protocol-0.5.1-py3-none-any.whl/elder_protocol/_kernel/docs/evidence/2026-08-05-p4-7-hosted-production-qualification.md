# P4.7 Hosted Production Qualification Evidence

**Date:** 2026-08-05
**Protocol version:** 0.4.8
**Constitution version:** 0.3.5
**Baseline:** `0a82eb8a78957ce8feb95185f874cbbf2fe2c5e9`
**Governed implementation commit:** `7f7cb467c078b041995cadf0c80d09ed1da26dbf`
**Verdict:** VERIFIED for the declared qualification-mechanism scope
**Maturity effect:** No increase; Elder remains L1

## Claim

Elder can deterministically validate independently signed hosted evidence bundles and evaluate
their records against every cumulative L0-L5 capability and evidence gate. Qualification
reports are immutable, advisory-only, and unable to mutate maturity, approve or promote an
artifact, deploy a release, or exercise production authority.

This verifies the qualification mechanism. It does not claim that Elder has configured external
trust anchors, collected hosted evidence, or qualified above L1.

## Implemented Mechanism

- Qualification policy with 43 gates mapping every operational-maturity requirement exactly
  once across L0-L5.
- Project, production-environment, target-level, artifact, provider, producer, source, creation,
  expiry, complete-record-set, and content-digest binding for hosted evidence bundles.
- Ed25519 bundle-envelope signatures for every non-empty bundle.
- Per-record project, environment, artifact, gate, provider, producer, HTTPS source, payload
  path, payload digest, result, issue time, expiry, attestation, and content-digest binding.
- Ed25519 record signatures from active trust anchors constrained by signer role, provider, and
  source host.
- Independent verifier enforcement for bundle and record producers.
- Bundle-contained payload resolution with path-escape and symlink rejection.
- Future-date, freshness, expiry, signature, digest, source, trust, contradiction, revocation,
  deletion, and missing-evidence checks that fail closed.
- Cumulative maturity evaluation where a failed lower level blocks all higher levels.
- Stable accepted and contradictory record ordering independent of input record order.
- Immutable qualification reports containing all gate results, blockers, source digests,
  canonical maturity level, and explicit non-authority fields.
- CLI, compiler, schemas, ontology, invariants, authority matrix, capability pack, protocol
  graph, assurance report, profile migration, generated Workbench policy, and instructions.

## Canonical Result

- Current maturity: L1.
- Qualification gates: 43.
- Configured trust anchors: 0.
- Hosted qualified: false.
- Advisory-only: true.
- Can mutate maturity: false.
- Can promote: false.
- Can deploy: false.

An empty canonical diagnostic bundle can produce an unqualified report. Any non-empty bundle
requires a trusted bundle-envelope signature, and no canonical trust anchor currently exists.

## Ordered Verification

Root protocol:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 17 | passed |
| Component | 92 | passed |
| Integration | 24 | passed |
| Workflow | 13 | passed |
| Stress | 11 | passed |
| **Total** | **157** | **passed** |

Compiled Elder Workbench:

| Level | Tests | Result |
|---|---:|---|
| Foundation | 2 | passed |
| Component | 3 | passed |
| Integration | 1 | passed |
| Workflow | 1 | passed |
| Stress | 1 | passed |
| **Total** | **8** | **passed** |

Additional checks:

- `py -m pytest -q`: 157 passed in one repository-wide run.
- `py -m pytest --collect-only -q`: 157 tests collected.
- `py -m elder_protocol.cli validate`: passed.
- `py -m elder_protocol.cli qualification validate`: 43 gates, zero trust anchors, passed.
- `py -m elder_protocol.cli assurance`: L1, hosted qualified false, no promotion/deployment or
  maturity-mutation authority.
- Workbench regeneration: 0 changed, 45 unchanged.
- Repository JSON parsing: 131 files passed.
- Python byte compilation: passed.
- `git diff --check`: passed.
- Canonical protocol graph: 548 nodes and 1,033 edges.
- Generated Workbench graph: 570 nodes and 1,628 edges.

## Corrected Failures

1. Component initially rejected the P4.5A fixtures because their protocol versions had migrated
   to 0.4.8 while delegation, invalid-delegation, and checkpoint digests still represented
   0.4.7. All six fixture digests were regenerated and Component passed on rerun.
2. Workflow initially rejected the Workbench architecture-boundary contract because that
   project-owned file remained at 0.4.7. It was migrated to 0.4.8 and Workflow passed on rerun.
3. Pre-commit trust-boundary review found that signed records alone did not prevent a party from
   deleting a contradictory record and recomputing the unsigned bundle digest. Non-empty bundle
   manifests are now independently signed over the complete record set and target bindings.
   Negative tests prove record deletion and target-level mutation fail closed.
4. The bundle-signature decision changed ADR 0013. Its governed registry digest, canonical
   graph, and generated Workbench design registry were refreshed before final validation.

## Candidate Artifact

- Exact-revision build ID: `e2157d0caa34`
- Source tree SHA-256:
  `9179ed8e86f087d02bae76143660605764ca6ec38f5fa0ec6bb00e4f08b25aba`
- Artifact SHA-256:
  `ebf72d5ad10af1bafde7dc639d12b9406ebf2055e9e915c92d0fbc2e5b78a52b`
- Artifact verification: passed
- Smoke decision: `needs-approval`
- Promotion: not performed

## P4.7 Non-Claims

P4.7 does not provide:

- a Git remote, hosted branch protection, merge queue, or hosted required checks;
- external trust-anchor keys or a signed hosted evidence bundle for Elder;
- cloud or source-control evidence collection adapters;
- workload identity, secret brokering, or human identity authentication;
- OS, VM, or container isolation for untrusted agent tools;
- hosted model, evaluator, telemetry, knowledge, memory, or multi-agent services;
- central telemetry retention, production alerts, exemplars, or delayed outcome measurement;
- production databases, encryption-key management, tenant isolation, backups, or recovery;
- canary deployment, production promotion, rollback execution, revocation, or renewal;
- target-application or provider-specific stack adapters;
- automatic maturity mutation, self-certification, or production self-learning;
- P5 bounded autonomy or a generally operational lights-out software factory.

No artifact promotion, deployment, remote push, or P5 implementation was performed.
