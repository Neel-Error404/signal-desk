# P3 Factory Substrate Validation

**Date:** 2026-08-05
**Scope:** Git preparation, isolated workspaces, clean builds, provenance,
promotion, rollback, CI definitions, and secretless local execution
**Verdict:** PASS for local substrate scope

## Root Test Ladder

```text
Foundation: 6 passed
Component: 18 passed
Integration: 3 passed
Workflow: 2 passed
Stress: 3 passed
Total: 32 passed
```

Stress coverage:

- ten fixture clean builds produced one artifact digest;
- three full Elder Workbench clean builds produced one artifact digest;
- fifty compiler regenerations remained stable.

The Workbench Component suite also passed twenty consecutive runs after the
oversized-request transport fix.

## Real Build Evidence

Two real builds produced:

```text
artifact SHA-256:
0ed5454db59ba71d1342ecfaacf91cecda64c62af5d699df0aa1aae002ad7bef

source-tree SHA-256:
e196a3f81441867f21a4433bb8f088530964784588d71e5acf120bb34ccff68d
```

Both builds executed the five reference-project levels successfully. Their
artifact path was identical and their provenance paths were different.

After generated-file whitespace hygiene was corrected, the current verified
baseline candidate became:

```text
e1dbbe3d419e932f4e605f011d48dd3c2bbd88b17c6d380620721e4e5f4a6ab9
```

It remains a candidate because the operator's release approval is correctly
bound to the earlier canary digest rather than to future artifacts.

Artifact smoke verification returned:

```json
{
  "decision": "needs-approval",
  "status": "ok"
}
```

## Real Local Canary

The human operator explicitly approved the artifact digest for
`local-canary`. Promotion retained the same registered ZIP and recorded the
approval authority in environment history.

The materialized release passed its local smoke command and was started from:

```text
.factory/releases/local-canary/
0ed5454db59ba71d1342ecfaacf91cecda64c62af5d699df0aa1aae002ad7bef
```

Current canary:

```text
URL: http://127.0.0.1:8767
health: ok
provider: deterministic-v1
```

## Git State

- Repository initialized on branch `main`.
- Human-authorized baseline commit:
  `452e8c2c97c12b71158444dca6f9e63f95eb96de`.
- No remote exists.
- Post-commit baseline candidate provenance records that exact revision.

## Configured But Not Activated

- GitHub required checks and merge-queue-compatible workflow.
- Commit-pinned checkout, Python setup, artifact upload, and attestation actions.
- GitHub OIDC permissions for artifact attestation.
- Desired hosted ruleset.

These are implementation evidence, not hosted-operation evidence.

## External Boundaries

- No production or cloud credentials were created or read.
- No external secret broker is configured.
- No workload-identity trust relationship is configured.
- The real candidate was promoted to `local-canary` under digest-specific human
  approval.
- Rollback behavior passed in isolated Component tests; a real rollback awaits
  a second approved artifact.
