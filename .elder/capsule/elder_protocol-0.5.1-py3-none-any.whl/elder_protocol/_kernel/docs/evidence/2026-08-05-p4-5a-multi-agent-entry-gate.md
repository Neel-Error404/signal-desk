# P4.5A Multi-Agent Entry-Gate Evidence

**Date:** 2026-08-05
**Scope:** Contract-only preparation for P4.5B multi-agent runtime work
**Protocol version:** 0.4.5
**Constitution version:** 0.3.5

## P4.4 Closure Check

P4.5A began from the committed P4.4 baseline `3a478122c0fb348df28721620c5cf6fb2baaad51`.
Protocol validation, the ordered root ladder, the Workbench ladder, graph regeneration, registry
hash validation, and P4.4 evidence were clean before P4.5A changes.

P4.4 non-claims remain explicit: the SQLite adapter does not prove hosted durability,
multi-tenant access control, encryption-key management, backup/recovery, vector retrieval,
autonomous consolidation, or multi-agent checkpoints.

## Implemented Contracts

- Canonical role registry and project-scoped identity bindings.
- Resolved authority grants using role -> identity -> action -> resource.
- Selected capability packs resolved into owner-bound artifact and evidence obligations.
- Delegation, agent-run, message, checkpoint, approval-decision, authority-grant, tool-grant,
  budget, deadline, cancellation, and escalation schemas.
- Delegation policy enforcing authority, scope, tool, budget, deadline, expiry, separation,
  cancellation, and message-state invariants.
- Delegated context identity and scope.
- Stack-adapter contract and registry with one Python AST reference adapter.
- Protocol and generated project graphs containing roles, identities, obligations, authority
  resources, and selected adapter relationships.
- CLI delegation validation that fails closed.

## P4.5A Hardening Closure

The follow-up hardening pass closed the five reported trust-boundary defects and the equivalent
standalone-validator bypasses:

- Parent runs must explicitly claim `delegation:delegate`, and every claimed action is checked
  against source-bound project authority.
- Authority-binding artifacts contain profile, role-registry, authority-matrix, and content
  digests and must exactly match recomputed authoritative sources.
- Child runs cannot exceed delegated authority, tools, any budget dimension, deadline, expiry,
  or normalized scope.
- Forbidden scope overlap is rejected in both containment directions.
- Checkpoints are admitted to graphs only after complete parent/delegation/child validation and
  exact project, delegation, run, scope, budget, and deadline binding.
- Delegated context assembly and packet validation require the full validated delegation chain,
  bind the delegation digest, and reject out-of-scope repository sources.
- Delegated graph and memory retrieval remain disabled until those records carry enforceable
  scope provenance.

Independent subagent specification review found no remaining P4.5A compliance defects. No P4.5B
runtime, queue, broker, scheduler, or orchestrator work was introduced.

## Contract Fixtures

`tests/fixtures/p4_5a/fixture-a-low-risk.json` represents a low-risk, single-repo, Python, L1
project. `tests/fixtures/p4_5a/fixture-b-high-risk.json` represents a high-risk, multirepo,
restricted-data, L2 project.

Both fixtures contain a profile, parent run, bounded delegation, child run, checkpoint,
delegated context request, invalid delegation, and deterministic expected parent-child graph.
They do not contain product source code.

## Ordered Verification

Root:

- Foundation: 14 passed.
- Component: 63 passed.
- Integration: 10 passed.
- Workflow: 10 passed.
- Stress: 6 passed.
- Total: 103 passed.

Elder Workbench after regeneration:

- Foundation: 2 passed.
- Component: 3 passed.
- Integration: 1 passed.
- Workflow: 1 passed.
- Stress: 1 passed.

Additional closure checks:

- `py -m elder_protocol.cli validate`: passed.
- `py -m elder_protocol.cli assurance`: current maturity remains L1 and
  `runtime_orchestration` is false.
- `git diff --check`: passed.
- Workbench product source and product tests were not changed by regeneration.
- Canonical protocol graph: 497 nodes and 919 edges.
- Candidate artifact:
  `6308024b08619875be12a4814ebe548a16f8c9dfd3dfd10970260e05ad512b94`.
- Candidate build `f5647e28ec5d`, source-tree digest
  `2b1713d1268eaaf5d37caab916958a323afdf076f5fbb6e9a0f8e91fca9f03e7`.
- Artifact smoke verification passed with decision `needs-approval`.

## P4.5A Non-Claims

P4.5A does not implement:

- a queue, message broker, scheduler, or orchestrator;
- a remote or concurrent agent runtime;
- hosted checkpoint persistence;
- runtime cancellation propagation;
- checkpoint sequence-chain continuity, replay, or previous-checkpoint verification;
- autonomous evaluation, approval, promotion, or release;
- external identity or secret brokering;
- additional product implementations;
- a general or lights-out software factory.

The runtime validator is authoritative for delegated source restrictions. Schema-only consumers do
not prove delegated graph or memory scope. Because P4.5A was not approved or released before this
hardening, pre-hardening local packets without `delegation_sha256` are intentionally invalidated
rather than migrated.

P4.5B remains blocked until this committed P4.5A state is reviewed and explicitly approved.
