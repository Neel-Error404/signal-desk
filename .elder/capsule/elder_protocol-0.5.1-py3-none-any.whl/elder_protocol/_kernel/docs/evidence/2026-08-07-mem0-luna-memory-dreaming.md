# Mem0 And Luna Memory Dreaming Evidence

**Date:** 2026-08-07
**Scope:** Local Elder memory and repository-dreaming adapter
**Status:** Local implementation verified; hosted CI pending push

## Implemented Boundary

- Mem0 OSS 2.0.17 configured with Azure GPT-4.1 extraction.
- Azure `text-embedding-ada-002` configured at 1,536 dimensions.
- Local persistent Qdrant candidate index.
- Azure `gpt-5.6-luna` for routine medium and escalation high reasoning.
- Strict environment validation with one Azure host.
- Mem0 telemetry disabled.
- Digest-bound dreaming execution report and learning candidate.
- Mem0 extraction converted only into expiring Elder candidate memory.
- Existing Elder SQLite approval and trusted retrieval authority retained.

## Live Pre-Implementation Probes

- Azure Luna Responses probe: completed.
- Mem0 extraction: one candidate memory produced.
- Azure embedding plus local Qdrant write: completed.
- Semantic recall: one matching result returned.

## Final Verification

- Foundation: 18 passed.
- Component: 159 passed.
- Integration: 27 passed, 1 live test skipped in the secretless base run.
- Workflow: 15 passed.
- Stress: 14 passed.
- Opt-in live Azure integration: 1 passed.
- Isolated installed-wheel verification: passed.
- Python bytecode compilation: passed.
- Git diff whitespace validation: passed.

The full CLI journey completed:

```text
session activate
-> dreaming prepare
-> Mem0 extraction
-> local Qdrant recall
-> Luna routine generation
-> dreaming accept
```

Bound execution:

- Request: `dream-elder-protocol-f13f58f1f0c9b23a`
- Candidate: `candidate-dream-elder-protocol-f13f58f1f0c9b23a-f6854fca9d15`
- Candidate digest: `c31a1c3c4e21b3b9dc690cbb48c4c31116846a5833f9b75e8edcb1a55007083d`
- Execution digest: `167cb56d73b7286e7438f2d471b76ab150acda55605369ef6110322e2fc4c1ba`
- Extracted semantic memories in the run: 7
- Recalled semantic memories in the run: 7

The separate `memory extract` operator flow proposed nine expiring candidate memories and
confirmed that default trusted-memory retrieval does not promote or expose them as trusted.

Implementation commit:
`57473b082ff2a2f24842c22ae62a419b49cfec90`

This evidence binding is finalized by the follow-up evidence-closure commit. Hosted CI is not
claimed until this revision is pushed and its exact run completes.
