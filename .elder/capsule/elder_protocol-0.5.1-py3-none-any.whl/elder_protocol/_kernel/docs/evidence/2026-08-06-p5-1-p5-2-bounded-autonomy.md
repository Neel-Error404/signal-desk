# P5.1 Certification Simulation and P5.2 Supervised Pull Requests

**Date:** 2026-08-06
**Protocol version:** 0.5.1
**Constitution version:** 0.3.7
**Phase:** P5.2
**Operational maturity:** L1

## Scope

This milestone implements:

- P5.1 side-effect-free autonomy work-item matching, simulation, certification lifecycle
  events, incident-budget derivation, and deterministic replay;
- P5.2 short-lived supervised pull-request authority leases, exact execution-evidence
  validation, immutable pull-request packets, and an explicit provider submission boundary.

It does not activate canonical autonomous pull-request authority. P5.2 remains fail-closed until
the repository consumes current externally verified L2 hosted qualification evidence and an
active, matching autonomy certification.

## P5.1 Implementation

The implementation adds typed work-item, match-report, simulation-report,
certification-event, and replay-report schemas.

Work-item matching validates:

- exact normalized concrete certification paths without wildcard expansion and exact operations;
- before and after content digests;
- autonomy-class file classifications and path boundaries;
- certified tool identifiers, pinned tool digests, and approved rule identifiers;
- required checks and semantic-equivalence evidence;
- forbidden effects, including dependencies, configuration, production behavior, and
  governance changes.

Simulation is side-effect-free and emits a digest-bound report. Certification replay requires a
contiguous sequence, a valid previous-event digest chain, monotonic timestamps, policy-specific
lifecycle roles, and valid lifecycle transitions. Events after the replay evaluation time are
rejected. Incident and rollback counts are derived from replayed history rather than accepted
from an untrusted summary. Expired incident-budget windows fail closed, and the initial
zero-tolerance budgets require suspension after the first incident or rollback. Standalone
renewal validation and replay enforce the same class TTL.

## P5.2 Implementation

A supervised pull-request authority lease requires:

- effective autonomy of at least L2;
- a repository-owned canonical authority source pinning the project ceiling and approved
  autonomy, class, change-class, qualification, and maturity digests;
- P4.7 re-evaluation from the signed hosted evidence bundle;
- caller-provided qualification consumption that exactly matches that re-evaluation;
- an active, current, matching certification whose event chain replays to active;
- effective-autonomy, match, simulation, and lifecycle reports that exactly match trusted-source
  recomputation;
- a short bounded lease lifetime.

Execution validation requires:

- actual paths, operations, and before/after content digests to match the approved work item;
- an isolated workspace declaration;
- ordered Foundation, Component, Integration, Workflow, and Stress evidence;
- all required checks to pass;
- independent evaluator approval;
- current independently signed hosted Git evidence binding the project, provider, repository,
  object format, base and head branches, full Git object identifiers, diff digest, branch
  protection, required checks, signed provenance, and external identity;
- no forbidden effect, merge, deployment, maturity mutation, or automatic renewal.

A validated execution can produce an immutable pull-request packet. Before invoking the provider,
submission validates the packet digest, reconstructs the packet from the source execution,
reconstructs the lease from trusted sources, checks current lease expiry, and re-runs signed
qualification and hard-stop checks. The accepted provider response must echo the authorized packet
digest, provider, repository, object format, base and head branches, base and head revisions, and
diff digest exactly. Its URL must match the trusted provider-signed repository URL prefix and
pull-request identifier, with the repository identity at the exact leading provider-relative
path; unrelated HTTPS URLs and path-substring tricks fail closed. The authority ends at
pull-request creation. Humans retain merge and release authority.

Git revisions use the repository's declared object format: SHA-1 repositories require full
40-character object identifiers and SHA-256 repositories require full 64-character object
identifiers. Content and diff digests remain SHA-256.

P4.7 trust anchors now separately bind subject identity and validity windows. Hosted evidence
bundles enforce policy-defined record-count and aggregate-byte limits.

Context assembly now has an explicit no-wholesale-graph invariant. Graph sources must be
query-matched and policy-capped; wildcard, empty-term, and over-limit requests fail closed.

## Canonical Readiness

`py -m elder_protocol.cli autonomy readiness` returns `ready: false`.

Current blockers:

- `branch-protection-not-verified`
- `external-identity-not-verified`
- `no-active-autonomy-certification`
- `no-active-canonical-authority-source`
- `no-external-trust-anchors`
- `no-hosted-git-remote`
- `no-valid-l2-qualification-consumption`

Synthetic fixtures test the mechanism but do not count as hosted qualification, identity,
branch-protection, or certification evidence.

## Verification

Root test ladder:

- Foundation: 18 passed
- Component: 115 passed
- Integration: 26 passed
- Workflow: 15 passed
- Stress: 13 passed
- Total: 187 passed

Elder Workbench test ladder:

- Foundation: 2 passed
- Component: 3 passed
- Integration: 1 passed
- Workflow: 1 passed
- Stress: 1 passed
- Total: 8 passed

Graph verification:

- canonical graph: 643 nodes and 1,251 edges;
- Elder Workbench graph: 644 nodes and 1,865 edges.

Protocol validation and autonomy-policy validation pass. Elder Workbench regeneration is
idempotent at 0 changed and 49 unchanged generated files and does not alter product-owned source.
Python byte compilation passes, and 279 repository JSON files parse successfully.

## Governance Status

The complete P5 diff received independent security and correctness review. The reviewer
reproduced the caller-selected authority attack, verified the canonical authority-source fix,
identified and re-tested repository URL-binding weaknesses, and reported no remaining Critical,
High, or Medium findings after remediation. The change set is committed under the operator's
explicit authorization.

## Authority and Change Record

- No pull request was created against a hosted repository.
- No merge, deployment, canary, promotion, maturity mutation, or certification auto-renewal was
  performed.
- P4.8A later supplied real external trust anchors, hosted qualification evidence, and GitHub
  workload identity; no active certification or P5 authority was fabricated.
- The P5 change set was staged and committed only after the ordered test ladders and independent
  review completed.
- No push, hosted pull request, merge, deployment, or maturity promotion was performed as part of
  P5 closure.
