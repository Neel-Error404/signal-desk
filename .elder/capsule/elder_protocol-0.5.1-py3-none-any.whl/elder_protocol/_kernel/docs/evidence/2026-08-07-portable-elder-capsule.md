# Portable Elder Capsule And Build Memory Evidence

**Date:** 2026-08-07
**Protocol phase:** P5.3
**Protocol version:** 0.5.1
**Implementation commit:** `94d7cae9080b887d5ec90571d7a2b50027e9a403`
**Status:** Local and hosted exact-commit verification complete

## Implemented Boundary

- Deterministic portable ZIP with a pinned Elder wheel.
- Manifest bound to the full source commit and every payload digest.
- Public builder requires a clean Git source tree and derives the commit from `HEAD`.
- Canonical ZIP-path validation and guarded install/update behavior.
- Repository-local `elder.ps1` launcher and ignored Elder tooling environment.
- Archived hosted-evidence payloads excluded from the operational wheel.
- Mandatory tracked `.elder/memory/trusted.json` build-memory authority.
- Shared JSON Schema validation for the portable ledger and activation packet.
- SQLite hydration plus Mem0/Qdrant trusted synchronization and semantic ranking.
- Candidate-only session closure with independent promotion into the portable ledger.
- Product memory explicitly separated from Elder development memory.
- Reference product regenerated and compiler idempotency verified.

## Exact Capsule

```text
Path: dist/elder-capsule-0.5.1.zip
Size: 739589 bytes
SHA-256: f88e0578d7d15ca8b32f96fdcd354c5e79a8dfe57b0d6862407285dcb6442d4a
Source commit: 94d7cae9080b887d5ec90571d7a2b50027e9a403
Embedded wheel size: 787554 bytes
```

The exact archive was installed into an empty Windows product directory. Its launcher created
`.elder/runtime/tooling/`, installed the pinned wheel and memory dependencies, passed
`elder validate`, and passed `elder capsule status`.

## Hosted Closure

GitHub Actions run `31128385118` completed successfully for closure commit
`d70f9b679cec276b56a7b683d147d0aec9e1c5a8`.

```text
Artifact: elder-portable-capsule-31128385118-1
Size: 722057 bytes
SHA-256: bac7e64fe8a85bfc87179a807a140aed71fb3a9731aa5e38aae650514e8aab81
Manifest source commit: d70f9b679cec276b56a7b683d147d0aec9e1c5a8
```

The downloaded hosted artifact passed local capsule verification after the run. Its digest
differs from the pre-closure local artifact because the closure commit adds this evidence
document to the packaged kernel. The hosted artifact is the preferred shareable build for the
closed revision.

## Verification

- Foundation: 18 passed.
- Component: 167 passed.
- Integration: 29 passed, 1 opt-in live Azure test skipped in the secretless ladder.
- Workflow: 15 passed.
- Stress: 14 passed.
- Opt-in live Azure Mem0/Luna integration: 1 passed with resource warnings treated as errors.
- Installed wheel outside the source checkout: passed.
- Fresh capsule bootstrap and compile without the factory checkout: passed.
- Exact Windows launcher bootstrap from the release ZIP: passed.
- Python bytecode compilation: passed.
- Protocol validation and graph drift check: passed.
- Git diff whitespace validation: passed.

## Authority Result

The central Elder repository is the upstream factory, not the runtime for every product. Each
product receives and versions its own capsule, compiles its own Elder contracts, carries its own
approved development-memory ledger, and rebuilds local Mem0/Qdrant state from that ledger.
Cross-repository memory and knowledge graphs remain future higher-level systems.

The hosted workflow verified the protocol ladder, reference project, reproducible artifact, and
portable capsule for the exact closure commit. P4.8A hosted qualification and native attestation
were correctly skipped because the run was manually dispatched rather than triggered by a
public-repository push.
