# Codex Activation And Repository Dreaming Evidence

**Date:** 2026-08-06
**Status:** Local activation and candidate boundary verified; live Prime execution blocked

## Verified Locally

- The factory kernel emits a schema-valid, digest-bound activation packet.
- The parent Template workspace has a thin `AGENTS.md` router and matching conservative Codex
  project configuration for sessions started one directory above the Git repository.
- Generated projects install selected Elder skills as native Codex project skills.
- Activation rejects draft profiles and modified Elder-owned generated instructions.
- Activation verifies the project Codex configuration is workspace-write, on-request, and
  no-network.
- Every factory-kernel routed skill path resolves to an existing `SKILL.md`.
- Repository dreaming copies only declared immutable evidence into a disposable workspace.
- Dreaming requests and accepted candidates are schema-valid and digest-bound.
- Candidate artifacts must remain under the quarantine `artifacts/` directory.
- Candidates cannot reference evidence outside the request.
- Prime candidates remain untrusted and cannot approve, promote, or mutate their target.

## Runtime Readiness Check

```text
prime-agent: unavailable
Docker: unavailable
Podman: unavailable
WSL: installed, no Linux distribution
External Elder sandbox adapter: not configured
Dreaming readiness: false
```

## Boundary Non-Claims

- Elder does not intercept arbitrary direct Codex tools.
- The current Codex process is not retroactively changed by project configuration.
- Prime Agent has not been executed.
- No autonomous repository mutation, approval, promotion, merge, deployment, or global
  refinement is claimed.

## Test Ladder

```text
Elder Protocol:
  Foundation:   18 passed
  Component:   154 passed
  Integration:  27 passed
  Workflow:     15 passed
  Stress:       14 passed
  Total:       228 passed

Elder Workbench reference project:
  Foundation:    2 passed
  Component:     3 passed
  Integration:   1 passed
  Workflow:      1 passed
  Stress:        1 passed
  Total:         8 passed
```

Protocol validation, Python bytecode compilation, generated-project activation, factory-kernel
activation, isolated installed-wheel execution, and `git diff --check` passed. The generated
reference project activated with `status: ready`, `sandbox_mode: workspace-write`, all routed
native skill files present, and repository dreaming configured as candidate-only.
