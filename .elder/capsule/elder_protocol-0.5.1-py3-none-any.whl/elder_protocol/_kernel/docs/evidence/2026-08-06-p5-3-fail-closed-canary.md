# P5.3 Fail-Closed Canary Mechanism Evidence

**Date:** 2026-08-06
**Phase:** P5.3
**Status:** Mechanism implemented and verified; canonical operational authority inactive

## Implemented

- Side-effect-free digest-bound canary-plan simulation.
- A separately governed project autonomy-class registry contract capped at L3, while the
  canonical initial registry remains exactly five L2 classes.
- L3-only short-lived canary leases reconstructed from the canonical P5 authority chain.
- Current signed hosted-bundle L3 re-evaluation and exact qualification-consumption matching.
- Independently signed canary-authority evidence bound to the exact general authority statement,
  plan, target, rollback artifact, traffic, timing, health, and rollback contract.
- Independently signed provider evidence for external identity, secret brokering, promotion
  gates, central telemetry, rollback readiness, and immutable artifacts.
- Immutable execution packets and accepted provider responses bound to the exact target,
  artifact pair, traffic allocation, deployment identifier, trusted URL prefix, and start time.
- Runtime-owned canonical durable plan, execution-ID, and packet consumption that prevents
  caller-selected-store bypass, sequential replay, concurrent replay, and repackaged-plan replay.
- Current certification replay, incident-budget, suspension, revocation, effective autonomy,
  match, simulation, authority-evidence, and canary-authority validation immediately before the
  provider call.
- Independently signed observations bound to the exact accepted deployment response.
- Deterministic sample, error-rate, p95-latency, success-rate, observation-window, and
  maximum-duration evaluation.
- Immutable rollback packets, automatic provider rollback invocation, and exact rollback
  response validation on any declared breach.
- Evaluation-time maximum-duration enforcement, durable packet/response/deadline registration,
  automatic in-process start-response and deadline watchdog scheduling, restart-safe due-work
  sweeping, and no-telemetry rollback without inventing observation evidence.
- Immediate `watchdog-unavailable` rollback if the post-response hard-deadline timer cannot be
  installed.
- Explicit denial of canary promotion, full rollout, merge, maturity mutation, and automatic
  renewal.
- Canonical readiness reporting that remains fail closed.

## Negative Coverage

- L2 qualification cannot issue a canary lease.
- A non-canary class cannot issue canary authority, and one signed canary-authority statement
  cannot authorize a different plan or target.
- A valid execution packet cannot be replayed sequentially or claimed concurrently, and its
  signed plan cannot be repackaged under a second execution ID.
- A current suspension denies execution before provider invocation even while the lease remains
  unexpired.
- Future-dated contradiction, suspension, and revocation checks are rejected.
- Fabricated packets and structural lease drift fail before provider invocation.
- Expired leases fail before provider invocation.
- Stale, forged, or plan-mismatched provider evidence is rejected.
- Provider response artifact, packet, target, traffic, URL, deployment, and time drift is
  rejected.
- Provider failure, malformed response, and a claimed start that survives process restart all
  require `start-uncertain` rollback using the provider-reserved deployment identifier.
- Unsigned, forged, stale, future, pre-deployment, or foreign-deployment observations are
  rejected.
- Caller-substituted deployment responses cannot redirect observation or rollback authority.
- Fabricated rollback packets and drifted or late rollback responses are rejected.
- The full rollback activation interval is checked on the runtime clock before claim and provider
  invocation; future-dated and expired packets fail before side effects.
- Direct observation and deadline rollback executors use the same atomic canonical claim and
  cannot replay provider side effects.
- A future deadline rollback packet cannot satisfy the persisted deadline predicate early.
- Failed and stale in-progress rollback claims are durably recoverable without permitting
  duplicate completed rollback, changing the persisted packet digest, or extending the original
  authorization window.
- A stale rollback claim that is recovered after its original authorization expires is rejected.
- Deadline sweeping uses the runtime clock rather than a caller-supplied timestamp, records
  expired rollback authority as terminal, and continues processing later due canaries before
  reporting aggregate failures.
- Traffic, duration, observation, and rollback bounds fail closed.
- Delayed observations cannot extend maximum duration, and missing telemetry requires rollback
  at the hard deadline.
- Healthy observations cannot promote or perform full rollout.
- Rolled-back and other terminal executions reject further observations.

## Test Ladder

```text
Foundation:  18 passed
Component:  148 passed
Integration: 27 passed
Workflow:    15 passed
Stress:      14 passed
Total:      222 passed
```

Protocol validation, Python compilation, deterministic protocol-graph regeneration,
canonical readiness verification, and `git diff --check` also passed.

## Independent Review

Independent adversarial review reproduced and then verified closure of the P5.3 authority,
provider-binding, one-shot replay, current-governance, future-time, start-uncertainty,
watchdog-installation, accepted-response substitution, rollback-claim crash, stale recovery,
authorization-renewal, sweep isolation, direct-executor replay, terminal-observation, and
future-activation paths.

Final review found no remaining Critical, High, or Medium security or correctness findings.

## Non-Claim

The positive execution fixture uses synthetic signed L3 evidence and a project L3 class to prove
the mechanism. It is not canonical operational evidence.

The canonical authority-source registry remains empty. The canonical class registry remains
capped at L2. No valid L3 qualification consumption, active L3 certification, verified protected
branch, external secret broker, central production telemetry, remote canary observation, or real
automatic rollback evidence exists. P5.3 canary authority is inactive, and Elder remains
canonically L1.
