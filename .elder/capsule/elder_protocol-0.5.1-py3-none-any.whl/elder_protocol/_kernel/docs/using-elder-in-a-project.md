# Using A Portable Elder Capsule

## Operating Model

Each product repository owns an individual, pinned Elder Protocol capsule.

The central `elder-protocol` repository is the factory and upstream source. Products do not
execute against that checkout after installation. A portable capsule ZIP carries:

- a pinned Elder wheel;
- a source-commit and payload-digest manifest;
- a repository-local `elder.ps1` launcher;
- a bootstrap script that creates an ignored Elder tooling environment;
- an intake-answer example;
- a detailed `START_PROJECT_PROMPT.md`;
- the `.elder/runtime/` ignore boundary.

Extract or install the capsule into the product repository. The capsule then compiles the
product-specific Elder contracts into that same repository.

```text
product-repository/
|-- elder.ps1
|-- .elder/
|   |-- capsule/                  pinned Elder runtime and bootstrap
|   |-- memory/trusted.json      tracked portable build-memory authority
|   |-- runtime/                 ignored local indexes, databases, and tooling
|   |-- project-profile.json     personalized project identity
|   `-- ...                      compiled policies and contracts
|-- .codex/                      project sandbox and native skills
|-- AGENTS.md
|-- ARCHITECTURE.md
`-- product source
```

The product's own virtual environment, package manager, dependencies, credentials, runtime,
and deployment remain separate.

## Build The Portable ZIP

Build only from a clean, committed Elder source tree:

```powershell
Set-Location D:\Balcony\Template\elder-protocol

py -m elder_protocol.cli capsule build `
  --output dist\elder-capsule-0.5.1.zip

py -m elder_protocol.cli capsule verify `
  --archive dist\elder-capsule-0.5.1.zip
```

The manifest binds the capsule to the full Elder Git commit and every payload digest.

GitHub Actions also publishes the ZIP as
`elder-portable-capsule-<run-id>-<attempt>`. Use a successful run for the exact Elder commit
you intend to install.

## Install It Into A Product

When a central Elder checkout is available, use the guarded installer:

```powershell
py -m elder_protocol.cli capsule install `
  --archive D:\Balcony\Template\elder-protocol\dist\elder-capsule-0.5.1.zip `
  --project-root D:\Balcony\Template\my-product
```

The ZIP may also be extracted directly into an empty product repository. The result must contain
`elder.ps1` and `.elder/capsule/manifest.json`.

Verify the installed copy:

```powershell
Set-Location D:\Balcony\Template\my-product
.\elder.ps1 capsule status --project-root .
.\elder.ps1 validate
```

The first launcher invocation creates `.elder/runtime/tooling/` and installs the pinned local
wheel plus the Mem0/Azure dependencies. That environment belongs to Elder, not to the product,
and remains ignored.

## Personalize The Product

Start Codex in the product repository and use:

```text
Read .elder/capsule/START_PROJECT_PROMPT.md and execute it phase by phase.
Do not implement the product until the Elder capsule, intake, ratification, dry-run compile,
mandatory build-memory readiness, Codex restart, and live session activation all succeed.
Ask me every material product question that the prompt requires. Do not invent missing answers.
```

The prompt directs Codex to:

1. verify the repository-local capsule;
2. inspect the existing repository;
3. run the Wayfinder product interview;
4. create and present a draft profile;
5. wait for explicit human ratification;
6. dry-run the Elder overlay and stop on path conflicts;
7. compile the personalized contracts;
8. configure mandatory development memory;
9. restart Codex so project instructions load;
10. activate with live Mem0 recall before implementation.

## Mandatory Build Memory

Every Elder project has repository-development memory even when the product has no memory
feature.

The portable authority is:

```text
.elder/memory/trusted.json
```

It contains only independently approved records and is committed with the product repository.
On activation Elder:

1. validates the ledger and its content digest;
2. hydrates `.elder/runtime/knowledge.db`;
3. synchronizes trusted records into the repository's local Mem0/Qdrant index;
4. semantically ranks records for the current task;
5. returns canonical ledger content in the activation packet.

Mem0 does not become the authority. It extracts candidates and provides semantic ranking.
Qdrant remains a rebuildable ignored index under:

```text
.elder/runtime/memory/qdrant/
```

At session close, Mem0 proposes expiring candidates from immutable work evidence:

```powershell
.\elder.ps1 session close `
  --project-root . `
  --activation .elder/runtime/activation.json `
  --env-file .elder/runtime/memory.env `
  --evidence test-result=<path> `
  --output .elder/runtime/session-close.json
```

Human promotion through the Elder memory command updates the tracked portable ledger. A fresh
clone rebuilds its local query store and semantic index from that ledger.

## Product Memory Is Separate

Application or customer memory is optional and product-owned. Even when the product also uses
Mem0, it must use separate:

- namespaces and collections;
- storage locations;
- credentials;
- retention rules;
- privacy controls;
- promotion authority.

Product memory is never automatically available to Elder build memory, and build memory is
never automatically exposed to product users.

## Updating Elder In A Product

Build a capsule from the new committed Elder version, then install it over the existing capsule:

```powershell
py -m elder_protocol.cli capsule install `
  --archive <new-capsule.zip> `
  --project-root <product-root>
```

The installer verifies the currently installed capsule before replacing capsule-owned files.
It does not overwrite product source or compiled personalized contracts. Then run:

```powershell
Set-Location <product-root>
.\elder.ps1 validate
.\elder.ps1 compile `
  --profile .elder\project-profile.json `
  --output . `
  --dry-run `
  --diff
```

Review migrations and generated changes, compile after approval, restart Codex, and activate
again. Product-specific profiles, approved memory, source code, and project-owned documents
remain local to that repository.

## Existing Repository Adoption

Preserve the current Git state before compilation. The compiler fails closed when an Elder
target path is already project-owned or a previously generated file was modified.

Do not use `--force` as the normal adoption path. Existing `AGENTS.md`, `ARCHITECTURE.md`, or
governed document collisions require an explicit ownership and content reconciliation.
