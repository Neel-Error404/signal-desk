# P4.3 Correlated Telemetry

## Purpose

P4.3 makes runtime and factory evidence queryable as one bounded execution story:

```text
project -> work item -> agent run -> product/model/tool spans
-> cost -> artifact/factory action -> deployment -> outcome
```

It is a local, provider-neutral reference runtime. It does not claim a hosted collector,
production monitoring service, or durable knowledge graph.

## Canonical Signals

| Scope | Examples | Required correlation |
|---|---|---|
| Product | workflow and user-visible operations | project and run |
| Model | bounded agent or model operations | project, run, and agent run when known |
| Tool | tool invocation counts and failures | project and run |
| Factory | build, test, verify, promote, rollback | project and run; artifact or deployment when known |
| Cost | currency, tokens, tool calls, compute time | project and run |
| Outcome | target, observation, direction, status | project, run, and outcome |

Every canonical event contains a trace ID, span ID, optional parent span, source digest, stable
event name, status, scalar attributes, low-cardinality measurements, and typed cost or outcome
records.

## Correlation Rules

- Native runtimes should generate W3C-compatible random trace and span IDs.
- Historical adapters may synthesize deterministic valid IDs and must label the origin.
- Invalid or all-zero incoming IDs are replaced rather than propagated.
- `project_id` and `run_id` are mandatory.
- Work-item, agent-run, artifact, deployment, evaluation, and outcome IDs remain correlation
  fields on traces or events.
- Correlation IDs are prohibited as metric dimensions.

## Privacy Rules

- Prompts and model outputs are not persisted by default.
- Secret, credential, authorization, cookie, token, and private-key shaped attribute names fail
  closed.
- The local adapter only copies allowlisted scalar factory metadata.
- Stack adapters are responsible for classification, retention, access control, and redaction
  before export.

## Metrics And Budgets

The local report aggregates:

- event, trace, run, scope, and status counts;
- p50, p95, and maximum duration;
- USD cost, token counts, tool calls, and compute time;
- met, missed, and unknown outcomes;
- correlation completeness;
- distinct metric-series cardinality.

The canonical contract evaluates maximum total cost, error rate, p95 latency, minimum
correlation completeness, and metric-cardinality overflow. A failed budget blocks the telemetry
claim. A passing budget remains advisory and cannot approve or promote.

## Runtime Adapters

`elder_protocol.telemetry` provides:

- Workbench JSONL normalization with native trace-context preservation;
- factory JSONL normalization with synthesized trace context;
- evaluation-report normalization into outcome, cost, and tool signals;
- deterministic JSONL validation and duplicate-event rejection;
- aggregate telemetry reporting.

## CLI

```powershell
py -m elder_protocol.cli telemetry validate

py -m elder_protocol.cli telemetry ingest `
  --source-kind workbench `
  --input <trace.jsonl> `
  --project-id elder-workbench `
  --output <events.jsonl>

py -m elder_protocol.cli telemetry report `
  --events <events.jsonl> `
  --output <report.json>
```

Factory and evaluation inputs use `--source-kind factory` and
`--source-kind evaluation`.

## Explicit Boundary

P4.3 does not provide:

- an OTLP exporter or hosted collector;
- production retention, alerting, dashboards, or SLO paging;
- remote canary or rollback observation;
- prompt or response content capture;
- a persistent knowledge graph or context/memory runtime;
- approval, promotion, or budget-spending authority.

Those boundaries keep P4.3 operational for its local reference scope without inflating the
whole-system maturity claim.
