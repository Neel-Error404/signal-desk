# Codex Activation, Mem0 Memory, And Repository Dreaming

## Purpose

Elder is the governed project protocol. Each product owns a pinned portable Elder capsule,
compiled project contracts, and mandatory build memory. Codex is the coding harness that reads
those project instructions, recalls build memory, selects tools, edits files, and runs
verification. Mem0 OSS is Elder's semantic build-memory adapter. Azure `gpt-5.6-luna` is the
repository-dreaming model. Neither provider receives approval, promotion, merge, deployment, or
trusted-state mutation authority.

## Startup Sequence

1. Install or extract a commit-bound Elder capsule into the product repository.
2. Run the capsule's `START_PROJECT_PROMPT.md` through Codex.
3. Run Elder intake and produce a draft project profile.
4. Ratify the profile using the identity bound to the `human-owner` role.
5. Compile the project. Elder emits contracts, `AGENTS.md`, `.codex/config.toml`, native project
   skills, and the repository-dreaming policy.
6. Add the Azure values from `.env.example` to the ignored local
   `.elder/runtime/memory.env`.
7. Verify live Mem0, Qdrant, embeddings, and Luna readiness.
8. Start or restart Codex inside the product repository.
9. Run `./elder.ps1 session activate --memory-live`.
10. Stop if activation fails. Otherwise execute through the declared test ladder.

Activation verifies:

- the project profile is ratified;
- Elder-owned generated files match the ownership manifest;
- required instruction sources exist and are digest-bound;
- selected capability packs and routed skills resolve;
- the portable trusted-memory ledger is valid and bound to this project;
- trusted build memory is hydrated and recalled for the current task;
- Codex declares `workspace-write`, `on-request`, and no default sandbox network;
- repository-dreaming policy is schema-valid.

The no-network Codex default remains intentional. `elder dreaming run` is the explicit bounded
operation that may require an approved network-capable execution. Elder validates one HTTPS
Azure host and does not expose the API key in reports.

## Memory Authority

The tracked `.elder/memory/trusted.json` ledger is the portable authority of record. Elder's
SQLite store is its rebuildable local query representation. Together they own memory identity,
namespace, provenance, lifecycle state, approval, review, expiry, and trusted retrieval.

Mem0 OSS:

- uses GPT-4.1 to extract durable candidate facts from immutable evidence;
- uses `text-embedding-ada-002` for 1,536-dimensional embeddings;
- persists semantic vectors in local Qdrant;
- indexes approved ledger records without re-inferring their content;
- semantically ranks trusted records during live session activation;
- disables Mem0 telemetry;
- may update its own candidate semantic index;
- cannot write trusted Elder memory.

`elder memory extract` and `elder session close` convert Mem0 results into expiring Elder
candidate records. Promotion still requires the existing independent `human-owner` approval
flow and updates the portable trusted ledger.

## Repository Dreaming

The governed flow is:

```text
activation packet + immutable evidence
-> evidence-only workspace
-> Mem0 candidate extraction and semantic recall
-> Azure Luna structured proposal
-> digest-bound Elder learning candidate
-> P4.6 replay and shadow evaluation
-> accountable approval
-> non-mutating promotion packet
-> separate target-specific application
```

Routine and escalation both use `gpt-5.6-luna`. Routine uses medium reasoning; escalation uses
high reasoning. `xhigh` is not an automatic route.

The provider receives copied evidence only. Evidence is treated as untrusted data, not
instructions. The source repository is not included in the request. The candidate artifact,
request, execution report, evidence, and content digests remain inspectable.

## Commands

```powershell
elder dreaming readiness --project-root . --env-file .elder/runtime/memory.env --live

elder dreaming prepare `
  --project-root . `
  --activation .elder/runtime/activation.json `
  --work-item-id <id> `
  --trigger completed-work-item `
  --evidence test-result=<path> `
  --workspace .elder/runtime/dreaming/<id>

elder dreaming run `
  --project-root . `
  --env-file .elder/runtime/memory.env `
  --workspace .elder/runtime/dreaming/<id> `
  --mode routine

elder dreaming accept `
  --workspace .elder/runtime/dreaming/<id> `
  --candidate .elder/runtime/dreaming/<id>/candidate.json `
  --output .elder/runtime/dreaming/<id>/accepted-candidate.json

elder memory extract `
  --store .elder/runtime/knowledge.db `
  --project-root . `
  --env-file .elder/runtime/memory.env `
  --namespace <project-id> `
  --evidence decision=<path>
```

Readiness proves provider configuration and, with `--live`, performs actual extraction,
embedding, semantic recall, and Luna generation against a temporary local Qdrant store.
Successful dreaming remains candidate generation, not trusted-memory promotion.
