# P4.6 Quarantined Learning Runtime

## Purpose

P4.6 makes replay, shadow comparison, and learning promotion inspectable without creating a
self-modifying factory. The local reference runtime promotes immutable candidate packets, not
target mutations.

## Learning Chain

```text
trace, evaluation, telemetry, outcome, or incident evidence
-> narrow candidate hypothesis
-> immutable candidate artifact copied into quarantine
-> counterfactual replay
-> side-effect-free shadow observations
-> independent deterministic evaluation
-> kind-specific accountable approvals
-> separate promoter
-> immutable promotion packet
-> target-specific governed application outside P4.6
```

## Operational Controls

- Candidate artifacts are copied into SQLite and bound to their original SHA-256.
- The store is bound to one project profile and resolved authority snapshot.
- Every actor identity must match its project role binding and the required resource action.
- Candidate expiry is mandatory.
- Observation cases bind immutable input, baseline-output, and candidate-output digests.
- Counterfactual replay runs in `quarantine`; shadow observations run in `shadow`.
- Both modes declare `side_effects: false`.
- Shadow evidence is blocked until the configured replay case minimum exists.
- Evaluation aggregates replay and shadow cases, quality, cost, latency, tool-call deltas, worse
  cases, and critical regressions.
- Candidate creator, observation executor, evaluator, approver, and promoter identities are
  separated according to policy.
- Memory candidates require `human-owner` approval.
- Skill candidates require `architecture-owner` approval.
- Policy, evaluator, and architecture candidates require both `human-owner` and
  `architecture-owner` approval.
- Promotion and rollback packets cannot apply target mutation.
- Runtime replay verifies candidate artifact bytes, journal-row digests, event hashes, record
  counts, and final lifecycle state.

## Local Commands

```powershell
py -m elder_protocol.cli learning init --store <learning.db> --profile <project-profile.json>
py -m elder_protocol.cli learning propose --store <learning.db> --profile <project-profile.json> --candidate <candidate.json> --artifact-base <repo>
py -m elder_protocol.cli learning observe --store <learning.db> --profile <project-profile.json> --record <observation.json>
py -m elder_protocol.cli learning evaluate --store <learning.db> --profile <project-profile.json> --candidate-id <id> --evaluator-id <identity>
py -m elder_protocol.cli learning decide --store <learning.db> --profile <project-profile.json> --approval <approval.json>
py -m elder_protocol.cli learning promote --store <learning.db> --profile <project-profile.json> --candidate-id <id> --promoted-by <identity>
py -m elder_protocol.cli learning rollback --store <learning.db> --profile <project-profile.json> --candidate-id <id> --promoted-by <identity>
py -m elder_protocol.cli learning snapshot --store <learning.db> --profile <project-profile.json> --candidate-id <id>
py -m elder_protocol.cli learning replay --store <learning.db> --profile <project-profile.json> --candidate-id <id>
```

## Non-Claims

P4.6 does not provide:

- live model-provider or tool execution;
- production traffic mirroring or hosted shadow services;
- external identity authentication or signed human decisions;
- automatic trusted-memory mutation;
- repository skill installation or policy, evaluator, or architecture modification;
- deployment, production promotion, or automatic rollback;
- autonomous candidate generation, approval, or renewal;
- hosted durability, tenant isolation, encryption, backup, recovery, or retention;
- production self-learning or maturity above the existing L1 assessment.
