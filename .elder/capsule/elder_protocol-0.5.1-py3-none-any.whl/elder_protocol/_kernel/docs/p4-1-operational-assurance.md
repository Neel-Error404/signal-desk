# P4.1 Operational Assurance

## Design Registry

`protocol/design-registry.json` is the canonical index of governed design documents. Each entry
binds identity, location, status, owners, change classes, notifications, supersession, and content
digest.

Validation fails closed when the document and registry disagree.

## Architecture Boundaries

`architecture-boundary.schema.json` defines an adapter-based contract. P4.1 implements
`python-ast-imports`:

```text
contract -> declared modules -> allowed internal dependencies
-> Python AST import extraction -> violations -> delivery failure
```

Additional language adapters must preserve the same contract outcome: undeclared or forbidden
dependencies are machine-visible and can block delivery.

## Transcript Evaluation

The first evaluator checks workflow JSONL traces for:

- one run identity;
- valid monotonic sequences;
- required running and terminal events;
- failed-event budgets;
- elapsed-time evidence;
- secret-shaped field names;
- executor/evaluator identity separation.

The result is advisory evidence. It cannot approve, promote, edit the trace, or change evaluator
policy.

## P4.2 Boundary

P4.2 remains responsible for probabilistic model review, evaluation datasets, human calibration,
A/B comparison, hallucination and tool-efficiency scoring, and evaluator quality measurement.
