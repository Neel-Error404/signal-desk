# P5.2 Supervised Autonomous Pull Requests

## Purpose

P5.2 permits one narrow operational action after P5.1: creating a supervised pull request. It
does not permit merge, deployment, maturity mutation, or automatic certification renewal.

## Mandatory Gate

Every authority lease requires:

1. a signed hosted bundle re-evaluated through P4.7 at lease issuance;
2. a repository-owned canonical authority source pinning the project ceiling and approved
   autonomy, class, change-class, qualification, and maturity digests;
3. a current independently signed governance statement bound to that canonical source and
   covering the configured policies and models, project ceiling, certification and lifecycle
   chain, current hard-stop state, artifact, and derived reports;
4. a caller-provided qualification consumption that exactly matches signed-bundle re-evaluation;
5. an active unexpired class certification whose event chain replays to active;
6. no suspension, revocation, contradiction, expired budget window, or exhausted incident budget;
7. recomputed effective-autonomy, exact-match, and side-effect-free simulation reports;
8. an isolated workspace;
9. Foundation, Component, Integration, Workflow, and Stress evidence in order;
10. an independent evaluator;
11. a current independently signed hosted-provider statement covering exact file changes, test
   results, evaluator evidence, the repository, protected
   base branch, required checks, signed provenance, and external identity;
12. exact binding between that statement and the execution's project, workspace, file content,
    tests, evaluator, branches, revisions, and
    diff.

The lease is short lived and binds every input digest. Actual paths, operations, and before/after
content digests must exactly equal the declared work item.

## Pull-Request Packet

A ready packet contains the provider and repository, explicit Git object format, separate base and
head branches, full base and head Git object identifiers, diff SHA-256, ordered test evidence,
independent evaluation, certification and lease bindings, and the human merge and release
requirements. SHA-1 repositories use 40-character Git object identifiers; SHA-256 repositories use
64-character Git object identifiers. Content and diff digests remain SHA-256 in either case.

Before provider invocation, submission validates the packet digest, source execution, current
lease and expiry, project, work item, certification lifecycle, and current signed qualification.
The accepted provider response must echo the authorized packet digest, provider, repository,
object format, branches, revisions, and diff digest exactly. Its URL must match the trusted
provider-signed repository URL prefix and returned pull-request identifier; an unrelated HTTPS
host, leading path segment, or repository substring match is rejected. The provider cannot change
scope or add merge authority.

## Canonical State

```powershell
py -m elder_protocol.cli autonomy readiness
```

The canonical authority-source registry is deliberately empty. P4.8A now provides pinned external
trust anchors, verified GitHub workload identity, and a valid advisory L2 bundle for exact commit
`d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`. The canonical repository still has no approved
qualification consumption, active autonomy certification, or verified hosted branch protection.
Synthetic fixtures exercise code paths only; they do not activate canonical P5.2.
