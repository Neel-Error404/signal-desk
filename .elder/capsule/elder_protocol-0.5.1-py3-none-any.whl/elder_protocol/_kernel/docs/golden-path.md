# Elder Golden Path

## 1. Frame

- State the user outcome, business outcome, constraints, non-goals, and failure conditions.
- Identify the accountable humans.

## 2. Clarify

- Run Wayfinder intake.
- Grill assumptions and unresolved terms.
- Refuse implementation while material ambiguity remains.

## 3. Model

- Resolve ontology and sources of authority.
- Select repository topology and capability packs.
- Set risk tier and autonomy ceiling.

## 4. Ratify

- Define architecture invariants.
- Classify writable, governed, constitutional, generated, ephemeral, and external surfaces.
- Approve the initial project profile.

## 5. Design

- Produce an RFC or ADR for hard-to-reverse decisions.
- Define contracts, workflow graph, nodes, edges, side effects, failure states, and evidence.
- Split work into independently reviewable changes.

## 6. Prepare

- Create an isolated worktree or sandbox.
- Provision minimum scoped identity and tools.
- Reproduce the clean build before editing.

## 7. Execute

- Implement within the approved work item and change class.
- Record context, tools, commands, outputs, cost, and decisions.
- Do not broaden scope silently.

## 8. Verify

- Foundation -> Component -> Integration -> Workflow -> Stress.
- Run deterministic architecture and security checks.
- Use an independent evaluator for governed changes.

## 9. Deliver

- Open a small or stacked PR with intent, evidence, risk, and rollback.
- Merge through the governed branch path.
- Build once, record provenance, and promote the same artifact.

## 10. Operate

- Canary, observe, compare to success and failure conditions, and roll back when necessary.
- Connect runtime behavior to the originating change trace.

## 11. Learn

- Convert incidents and outcomes into minimal hypotheses.
- Replay in quarantine.
- Promote only independently evaluated skills, memory, policy, or architecture updates.

## 12. Communicate

- Update product truth, user communication, economics, launch material, and feedback routing.
- Do not declare completion from code output alone.
