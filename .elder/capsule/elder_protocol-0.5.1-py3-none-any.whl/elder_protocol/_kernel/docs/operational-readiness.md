# Operational Readiness

**Assessment date:** 2026-08-07
**Current phase:** P5.3 - Fail-closed canary mechanism

| Capability | State | Evidence | Required Next Step |
|---|---|---|---|
| Constitution | VERIFIED | `ELDER_PROTOCOL.md` ratified | Amendment workflow automation |
| Hierarchical meta-architecture | VERIFIED | ADR 0004 and Foundation validation | Additional project-selected stack adapters |
| Capability-pack contract | VERIFIED | typed registry and cross-reference validation | Specialty-pack implementation |
| Canonical protocol graph | VERIFIED | deterministic graph and drift check | Hosted query service and visualization |
| Generated project graph | VERIFIED | compiler output and reference migration | Runtime evidence graph |
| Ontology | VERIFIED | entity/relation validation tests | Graph persistence and query |
| Authority matrix | IMPLEMENTED | protocol validation | Runtime workflow enforcement |
| Canonical roles and identities | VERIFIED | role registry, profile bindings, and Foundation/Component tests | External identity-provider adapter |
| Resolved obligations | VERIFIED | compiler output and low/high-risk fixtures | Project artifact and evidence lifecycle updates |
| Delegation contracts | VERIFIED | schemas, CLI validator, invalid fixtures, parent-child graph, and runtime submission gate | Hosted identity and distributed coordination |
| Multi-agent runtime | VERIFIED (local reference) | SQLite coordinator, assigned-identity leases, typed journals, cancellation, expiry, and replay | Hosted broker, remote workers, external identity, backup/recovery |
| Quarantined learning runtime | VERIFIED (local reference) | Immutable candidate artifacts, replay and shadow observations, independent evaluation, accountable approvals, promotion and rollback packets, and deterministic replay | Hosted shadow traffic, target-application adapters, external identity, backup/recovery, production self-learning |
| Hosted production qualification | VERIFIED (advisory L2) | Exact-commit run `31088377331`, 18 signed L0-L2 records, separate operator/reviewer anchors, provider-bound OIDC evidence, signed governance and provenance, and canonical replay | Preserve freshness and re-issue for future qualifying revisions |
| Bounded autonomy simulation | VERIFIED (local, side-effect-free) | Exact concrete-path work-item matching, certified tool/rule binding, simulation, future-event rejection, policy-bound lifecycle replay, incident accounting, CLI, compiler, graph, assurance, and layered tests | Collect real class-specific simulation history |
| Supervised autonomous PRs | VERIFIED LOCALLY (governance open) | Signed-bundle P4.7 re-evaluation, independently signed governance-source and hosted-execution evidence, lifecycle replay, trusted-source report recomputation, short-lived lease, exact execution binding, ordered tests, independent evaluation, packet reconstruction, hosted-control requirements, and provider boundary | Configure active authority, qualification consumption, certification, and protected branch governance |
| Stack-adapter contract | VERIFIED | typed registry and Python AST reference adapter | Add adapters only for selected real stacks |
| Architecture invariants | VERIFIED | invariant validation and Workbench AST fitness function | Architecture-owner ratification |
| Change classes | IMPLEMENTED | protocol validation | PR and CI enforcement |
| Capability packs | VERIFIED | dependency-resolution tests | Pack-specific runtime generators |
| Project profile | VERIFIED | shared schema engine plus intake, validation, and migration tests | Ratification workflow |
| Wayfinder intake | VERIFIED | CLI Workflow test | Interactive reader testing |
| Skill registry | VERIFIED | skill validation and dependency tests | Project-pack skill generation |
| Codex session activation | VERIFIED (local) | digest-bound activation packet, generated-file ownership verification, ratified profile gate, project config validation, and routed skill existence tests | Restart Codex in the project after config changes; add external enforcement if direct-tool interception becomes required |
| Native Codex project skills | VERIFIED (generated project) | compiler installs selected `SKILL.md` files under `.codex/skills/` and records them in ownership | Evaluate task-routing quality against real project sessions |
| Portable Elder capsule | VERIFIED (historical hosted, commit-bound) | `docs/evidence/2026-08-07-portable-elder-capsule.md`: run `31128385118` passed for exact commit `d70f9b679cec276b56a7b683d147d0aec9e1c5a8`; current local capsule tests also pass | Reissue hosted evidence for the current revision when needed; add release-tag publication only when a durable release channel is required |
| Mandatory build memory | VERIFIED (generated-project and local kernel scope) | Generated projects use a tracked `.elder/memory/trusted.json` authority ledger; the central factory kernel falls back to local `.factory/memory/trusted.json`; shared schema, hydration, recall, activation, candidate closure, and promotion tests pass | Accumulate approved product-building memories, evaluate recall quality, and avoid treating the central ignored fallback as a tracked product ledger |
| Repository dreaming | VERIFIED (operational local) | evidence-only workspace, Mem0 OSS extraction, local Qdrant recall, Azure Luna structured generation, request/execution/candidate schemas, digests, and layered tests | Accumulate product-building evidence and evaluate candidate quality |
| Mem0 and Luna adapter | VERIFIED (local mechanism; historical live opt-in) | Current local adapter tests pass; the live Mem0 2.0.17 extraction, Azure embedding, and Luna Responses probe are historical opt-in evidence and were not rerun in SF-001 | Hosted backup/recovery, provider availability monitoring, and a current opt-in live rerun when required |
| Skill creator | VERIFIED | create and duplicate-safety tests | Bundled script/reference lifecycle |
| Skill router | VERIFIED | dependency-aware route tests | Semantic routing evaluation |
| Compiler regeneration | VERIFIED | idempotency and 50-cycle stress tests | Migration compatibility policy |
| Generated contracts | VERIFIED | Component and Workflow tests | Delayed regeneration review |
| Ownership protection | VERIFIED | modified-file rejection test | Git/signing anchor |
| Dry-run and diff | VERIFIED | compiler component tests | Machine-readable plan output |
| Trace/evidence schemas | VERIFIED | schema validation, native Workbench trace context, and typed telemetry events | Hosted telemetry backend |
| Tool/MCP contracts | IMPLEMENTED | schema validation | Tool registry and permission broker |
| Context/memory contracts | VERIFIED (operational local) | policy validation, governed lifecycle tests, Mem0 candidate extraction, local Qdrant semantic recall, query-matched graph limits, wholesale-context rejection, and context-packet assembly | Hosted access control, backup, and recovery |
| Learning contracts | VERIFIED (local reference) | schema validation, replay, shadow evaluation, approval, promotion packets, and replay | Target-specific application and hosted learning |
| Git repository | VERIFIED | private `Neel-Error404/elder-protocol` remote on `main` | Protected branch eligibility |
| CI | VERIFIED (historical hosted, commit-bound) | GitHub Actions run `31128385118` passed for exact commit `d70f9b679cec276b56a7b683d147d0aec9e1c5a8`; it is not current-HEAD evidence | Re-run hosted CI for the current revision and activate branch-required checks when the plan permits |
| Worktree isolation | VERIFIED (fixture scope) | create/remove lifecycle test | Declared root work item and lifecycle exercise |
| Sandboxing | IMPLEMENTED (process scope) | clean copy and secretless environment | OS/container isolation for untrusted tools |
| Reproducible builds | VERIFIED (current local; historical hosted) | Current Integration and Stress tests reproduce artifacts locally; hosted deterministic ZIP evidence is commit-bound to run `31128385118` | Current hosted rerun and cross-runner platform diversity |
| Identity and secrets | IMPLEMENTED (provider identity) | GitHub OIDC signature and immutable subject verification; no workflow signing key | External secret broker |
| Agent harness | VERIFIED (reference scope) | eleven-node Workbench execution | Tool runtime, checkpoints, external providers |
| Runtime observability | VERIFIED (local scope) | health endpoint, run snapshots, native trace context, normalized JSONL telemetry | Central collector, alerts, retention |
| Correlated telemetry | VERIFIED (local reference) | Workbench, factory, and evaluation adapters covering product, model, tool, factory, cost, and outcome scopes | OTLP export, hosted collector, exemplars, retention, and production alerts |
| Eval harness | VERIFIED (local reference) | hash-bound dataset, calibrated judge, real Workbench holdout run, and paired comparison | Live provider adapter, hosted isolation, and larger representative datasets |
| Recommendation traceability | VERIFIED | typed twenty-entry ledger and graph validation | Source-file ingestion and change notifications |
| Component operating contract | IMPLEMENTED | schema and generated project contract | Stack-specific runtime enforcement |
| Judgment and taste | VERIFIED (local calibration scope) | rubric, vetoes, calibration dataset, and qualified reference judge | Multi-rater human baseline and production drift monitoring |
| Anti-slop review | VERIFIED (deterministic local) | design registry, boundary adapter, traces, and transcript evaluator | Probabilistic review and calibration |
| Factory maturity claims | VERIFIED | L0-L5 model and `elder assurance` report | Hosted evidence needed above L1 |
| Design-document registry | VERIFIED | content digests, ownership, status, notification, and supersession validation | External notification delivery |
| Architecture-boundary runtime | VERIFIED (Python reference) | reusable schema, CLI adapter, and Workbench Foundation check | TypeScript, Rust, and other stack adapters |
| Transcript review | VERIFIED (deterministic local) | independent JSONL evaluator and advisory result | Live model-based trace reviewer and hosted evaluator isolation |
| Evaluation dataset registry | VERIFIED | content digest, provenance, sensitivity, splits, thresholds, and case validation | External dataset storage, access controls, and notification delivery |
| Evaluator calibration | VERIFIED (offline local) | held-out human labels with accuracy, precision, recall, F1, abstention, and confusion matrix | Multi-rater labels, live model adapter, and drift schedule |
| Candidate comparison | VERIFIED (local reference) | paired case comparison with critical-regression veto and cost/latency deltas | Statistical uncertainty and longitudinal outcome linkage |
| Knowledge-graph runtime | VERIFIED (local reference) | SQLite initialization, transactional ingest, query, audit, and Workbench integration | Hosted service, access control, backup/restore, and visualization |
| Artifact provenance | VERIFIED (signed hosted path) | GitHub-bound artifact digest plus independent Ed25519 provenance in the verified L2 bundle | Native GitHub attestation remains plan-blocked |
| Deployment and rollback | VERIFIED (local fixture scope) | simulated canary and rollback mechanism tests | Real target deployment, observation, and automatic rollback exercise |
| Factory execution traces | VERIFIED | `.factory/traces/factory.jsonl` | Central retention and correlation |
| Economics | VERIFIED (local telemetry scope) | typed USD, token, tool-call, compute, and budget aggregation | Production metering and measured unit economics |
| Go-to-market operations | IMPLEMENTED | proof-backed asset plan and publishing authority | Audience validation and campaign results |
| Reference frontend/backend | VERIFIED | browser and API workflow evidence | Authenticated multi-user deployment |

## Readiness Verdict

P3 is operational locally for governed clean builds, content-addressed artifacts, append-only
provenance, smoke verification, isolated worktree lifecycle, approval-gated promotion and
rollback, and secretless process execution. Current evidence is recorded in
`docs/evidence/2026-08-05-p3-factory-substrate.md`. P3.1 hierarchy, pack, and graph evidence is
recorded in `docs/evidence/2026-08-05-p3-1-meta-architecture.md`.

P4.0 is operational as a protocol-validation and generation layer. It maps adopted recommendations
to controls and evidence, automatically includes factory and assurance packs, emits component and
judgment contracts, and reports the current maturity ceiling.

P4.1 is operational locally for design-registry drift detection, Python import-boundary
enforcement, and deterministic independent transcript review. The evaluator is advisory-only and
cannot approve or promote. P4.2 builds the dataset and calibration layer above this deterministic
trace foundation.

P4.2 is operational locally for governed evaluation datasets, deterministic graders, typed
probabilistic judge results, offline judge calibration, holdout evaluation, and paired baseline
comparison. A real Workbench execution passes the reference holdout set. The evaluator remains
advisory-only; model-provider execution, hosted evaluator isolation, multi-rater calibration,
statistical confidence intervals, and production drift monitoring remain future work.

P4.3 is operational locally for native Workbench trace context, deterministic Workbench,
factory, and evaluation normalization, complete project/run correlation, all six declared
telemetry scopes, cost/error/latency/correlation budgets, outcome aggregation, secret-field
rejection, and metric-cardinality enforcement. Reports are advisory-only. OTLP export, hosted
collection, production retention, exemplars, alerting, and remote canary observation remain
future work.

P4.4 is operational locally for a transactional SQLite graph and memory store, provenance-bound
idempotent ingest, append-only knowledge audit events, candidate-memory expiry, independent
human promotion into trusted memory, trusted-only retrieval, and deterministic
authority/status/freshness/budget-filtered context assembly. Required context fails closed and
context packets are digest-bound. Mem0 OSS now extracts candidate memories, Azure embeddings
feed a persistent local Qdrant semantic index, and Mem0 output can enter Elder only as an
expiring candidate. The local adapter does not establish hosted durability, tenant
authentication, encryption key management, backup/restore, autonomous trusted promotion, or
multi-agent checkpoints.

P4.5A is operational as a deterministic contract and validation layer. Selected capability
packs resolve into owner-bound obligations; canonical roles bind to project identities; valid
delegations remain within parent and project authority; child runs and checkpoints are
traceable; delegated context binds identity and scope; and invalid fixtures fail closed. P4.5A
does not implement queues, brokers, schedulers, runtime orchestration, hosted checkpoints,
runtime cancellation propagation, or autonomous promotion.

P4.5B is operational as a bounded local coordinator. It transactionally submits complete
delegation chains, binds child operations to assigned-identity leases, journals typed actions and
messages, enforces cumulative budgets and checkpoint frequency, links checkpoint digests,
propagates cancellation, expires overdue work, emits connected runtime snapshots, and verifies
deterministic lifecycle replay. The coordinator cannot approve or promote and does not
authenticate external identities or execute model and tool providers. Hosted brokers, remote
workers, distributed scheduling, multi-tenant durability, backup/recovery, and production
checkpoint retention remain future work.

P4.6 is operational as a quarantined local learning runtime. It copies immutable candidate
artifact bytes into a policy-bound SQLite store, records side-effect-free counterfactual replay
and shadow observations, derives independent advisory evaluations, requires kind-specific
accountable approvals, separates the promoter identity, emits non-mutating promotion and
rollback packets, and verifies the journal through deterministic replay. It does not apply
trusted-memory, skill, policy, evaluator, architecture, deployment, or production changes.
Hosted shadow traffic, external identity, target-specific application adapters, hosted
durability, and production self-learning remain future work.

P4.7 is operational as a hosted qualification mechanism. It verifies immutable payload-bound
records using configured Ed25519 trust anchors, constrains signers by role, provider, and HTTPS
source host, rejects stale, expired, future-dated, forged, contradictory, mismatched, or
out-of-bundle evidence, and evaluates all maturity requirements cumulatively. Reports are
advisory and cannot mutate maturity, approve, promote, or deploy. P4.8A configures separate
operator and reviewer anchors plus provider-bound issuance. Run `31088377331` issued and
canonically replayed a genuine advisory L2 bundle for exact commit
`d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`. Elder remains canonically L1 because qualification
is advisory and ratification authority is unchanged.

ADR 0022 ratifies `elder-factory-maturity-standard` version `1.0.0`.
Whole-factory maturity is the minimum verified level across eight mandatory
dimensions rather than an average. Institutional L2 is real hosted supervised
delivery to exact reviewable pull requests with human merge, release, and
deployment authority. Institutional L3 is one explicitly certified reversible
class operating from trusted signal through bounded canary and automatic
rollback while humans retain full rollout and class expansion. The standard
adds 30-day and real-execution evidence thresholds, failure exercises, exact
authority prohibitions, independent review, and human ratification. It does
not change the current L1 assessment or make the historical advisory L2 bundle
current for this revision.

P5.0 is implemented as a contract layer for exactly five initial reversible autonomy
subclasses. It defines pinned P4.7 qualification consumption, evidence-bound certification,
windowed incident budgets, suspension, revocation, human-governed renewal, and deterministic
effective-autonomy calculation. Effective autonomy is the minimum of verified hosted maturity,
the project ceiling, the class maximum, and the active certification level, and resolves to
none on every declared hard stop.

P5.1 is operational locally as a deterministic side-effect-free evaluation layer. It binds one
structured work item to one autonomy class and certification, requires exact concrete certified
paths, checks operations, tools, rules, required checks, semantic equivalence, and forbidden
effects, and replays a contiguous certification event hash chain. Future events are rejected,
lifecycle roles come from policy, and incident and rollback counts are derived from history.
Expired budget windows fail closed, and the initial zero-tolerance budgets require suspension
after the first incident or rollback.

P5.2 is implemented as a supervised pull-request mechanism. A short-lived authority lease
first resolves the project ceiling and approved configuration digests from the repository-owned
canonical authority source. It then requires P4.7 re-evaluation from the signed hosted bundle,
an independently signed governance statement bound to that source, an active certification lifecycle replay,
exact trusted-source recomputation of effective autonomy, match, and simulation, exact actual
path, operation, and content-digest binding, ordered Foundation through Stress evidence,
independent evaluation, independently signed hosted execution and Git governance, and external
identity. Before provider invocation,
submission reconstructs the lease and packet and verifies current lease and qualification state.
Hosted control state must come from a current independently signed provider statement rather than
caller booleans. Git revisions are validated as full SHA-1 or SHA-256 object identifiers under the
declared repository object format. The accepted provider response must bind the exact authorized
packet digest, provider, repository, branches, revisions, diff, and provider-signed repository URL
prefix plus pull-request identifier.
A ready packet cannot merge, deploy, mutate maturity, or auto-renew. Humans retain merge and
release.

Canonical P5.2 activation is blocked: the authority-source registry has no active project, no
active autonomy certification exists, and hosted branch protection is unavailable. Synthetic
test fixtures do not satisfy these operational gates, so Elder remains L1.

The P5 implementation completed independent security and correctness review with no remaining
Critical, High, or Medium findings and is governance-closed by its explicitly authorized commit.

Reliability hardening on 2026-08-06 made the installed wheel self-contained, added an isolated
wheel validation from outside the checkout, eliminated option-shaped generated lease tokens,
introduced shared Draft 2020-12 schema validation, emitted digest-bound test-ladder evidence
from CI, and separated CLI parser construction and canary persistence from their former
monolithic modules. Runtime contract validation is also isolated from the SQLite orchestration
coordinator. Local protocol and reference-project ladders are recorded in
`docs/evidence/2026-08-06-reliability-hardening.md`. A new hosted result is not claimed until
this revision is pushed and GitHub Actions completes.

Codex activation and repository dreaming hardening adds a generated
`.codex/config.toml`, native project skill installation, explicit human profile ratification,
digest-bound activation packets, candidate-only Mem0 extraction, local Qdrant semantic recall,
and Azure Luna repository dreaming. The mechanism verifies project instructions and the declared
workspace-write, on-request, no-network Codex default. `elder dreaming run` is the explicit
bounded Azure operation; Elder accepts only one configured HTTPS host. It does not intercept
arbitrary direct Codex calls and cannot change an already-running Codex sandbox. Provider output
remains untrusted until the existing replay, evaluation, approval, and promotion lifecycle is
completed.

The portable capsule closes the product-adoption boundary. The central Elder checkout now builds
a deterministic ZIP containing a commit-bound wheel, manifest, local launcher, bootstrap, intake
example, and new-project prompt. Each product owns its pinned copy and its personalized compiled
contracts. Mandatory build memory is stored in the tracked
`.elder/memory/trusted.json` authority ledger; local SQLite and Qdrant state are derived and
rebuildable. Activation recalls only canonical trusted records, and session closure can create
candidate memories but cannot promote them.

P5.3 is implemented as a fail-closed canary mechanism. A separately governed project autonomy
class registry may define classes up to L3 while the canonical five initial classes remain L2.
A canary lease requires current signed L3 qualification consumption, canonical project authority,
an active L3 certification and lifecycle replay, exact work-item and canary simulation, and
independently signed exact-plan canary authority plus provider evidence for external identity,
secret brokering, promotion gates, central telemetry, immutable artifacts, and rollback
readiness. Execution reconstructs the lease and packet, atomically consumes the plan and
one-shot packet in the runtime-owned canonical store, and re-verifies current qualification,
certification events, incident budget, suspensions,
revocations, effective autonomy, match, simulation, and signed authority before invoking a
project-owned provider adapter. The accepted response is bound to the exact packet, target,
artifact pair, initial
traffic, deployment identifier, URL prefix, and start time. Signed observations are bound to that
deployment; maximum duration uses the evaluation clock. The accepted packet, response, and hard
deadline are persisted. Elder schedules the start-response timeout before provider invocation
and the hard deadline after response acceptance, with a durable recovery sweep after restart.
Failure to install the hard-deadline watchdog immediately rolls the canary back. Any provider
uncertainty, sample, health, duration, or missing-telemetry deadline breach creates an immutable
rollback packet, atomically claims rollback, invokes the provider rollback adapter, and accepts
only an exact response inside the original rollback window. Crash recovery reuses the exact
persisted rollback packet and cannot renew its authority. Restart sweeping uses the runtime clock,
records expired rollback authority terminally, and isolates failures so one expired record cannot
block another due canary. All direct rollback executors use the same canonical claim, verify
the full runtime-clock activation interval before claim and provider invocation, compare deadline
claims to runtime time, and reject future activation and replay. Terminal executions reject
further observations.
Healthy observations can only continue observation and never authorize promotion or full rollout.

Canonical P5.3 authority is inactive. There is no valid L3 qualification consumption, active
L3-capable certification, verified protected branch, external secret broker, central production
telemetry, or real automatic rollback evidence. Synthetic L3 fixtures validate the mechanism
only, so Elder remains L1.

Elder is not yet a production software factory. The private remote, hosted CI, provider workload
identity, trust anchors, and signed provenance path are active. Protected branch rules, merge
queue, GitHub-native persisted attestations, external secret brokering, and a real rollback still
require external infrastructure or account eligibility. Hosted telemetry, hosted knowledge
durability, distributed multi-agent coordination, external runtime identity, and hosted
evaluator services remain future work.
