# Elder Hierarchical Meta-Architecture

## Identity

Elder is the product-agnostic factory kernel. It compiles an idea and ratified
project profile into governed repository contracts. Reference projects prove
the kernel. Generated repositories contain project-owned products.

Elder is not a fixed application template and does not require one frontend,
backend, model provider, database, repository topology, or deployment target.

## Hierarchy

| Layer | Stable responsibility | Typical owner |
|---|---|---|
| Universal kernel | Outcomes, ontology, authority, invariants, change classes, evidence | Human architecture owner |
| Capability packs | Conditional domain and engineering obligations | Pack owner |
| Stack adapters | Technology-specific translation of pack contracts | Stack owner |
| Project implementation | Product domain, code, data, workflows, and user experience | Project team |
| Factory operations | Isolation, build, provenance, promotion, deployment, observation, rollback | Release and platform owners |
| Assurance and learning | Evals, replay, memory candidates, delayed quality, promotion | Independent evaluation and human owners |

The machine-readable source is `protocol/meta-architecture.json`.

## Compilation Path

```text
idea and evidence
-> Wayfinder intake
-> ratified project profile
-> capability-pack dependency resolution
-> stack-adapter selection
-> selected protocol graph
-> generated repository contracts
-> project-specific architecture ratification
-> project-owned implementation
-> ordered verification and independent evaluation
-> immutable artifact and promotion
-> runtime evidence and governed learning
```

## Graphs

The canonical protocol graph connects:

- architecture layers;
- capability packs and provided capabilities;
- required artifacts and evidence levels;
- skills and skill dependencies;
- schemas and interfaces;
- invariants and change classes;
- human and agent roles;
- ontology entities.

Each generated project receives a bounded overlay containing its selected
packs, skills, contracts, knowledge sources, invariants, roles, and evidence
requirements. Runtime execution and learning graphs remain separate append-only
evidence surfaces.

## Ownership Boundary

Elder owns only files declared in `.elder/ownership.json`. Regeneration may
update unchanged Elder-owned files and must refuse modified or project-owned
files unless the operator explicitly authorizes replacement.

Project source code, product-specific architecture, data models, integrations,
and user experience remain project-owned.

## Operational Boundary

A selected or generated capability is not operational merely because it appears
in a profile or graph. Operational status requires implementation, execution in
the target environment, current evidence, and a known failure or rollback path.
