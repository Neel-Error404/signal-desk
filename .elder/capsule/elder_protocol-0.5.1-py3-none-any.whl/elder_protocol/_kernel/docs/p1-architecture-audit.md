# P1 Architecture Audit

**Date:** 2026-08-05
**Question:** Does P1 implement the Elder architecture we intended?

## Verdict

P1 implements the project-definition and compilation layer. It does not implement the software
factory substrate or autonomous production organization. The architecture remains aligned
because those boundaries are explicit rather than hidden behind placeholder claims.

| Elder plane | P1 implementation | Remaining operational gap |
|---|---|---|
| Outcome | Profile success and failure outcomes | Product analytics and economic measurement |
| Constitution | Ratified constitution, invariants, authority | External approval and exception service |
| Ontology | Entity and relationship types, graph schema | Graph store, ingestion, query, visualization |
| Organization | Human owners and agent roles | Team directory, delegation runtime, segregation enforcement |
| Architecture | Generated architecture and ADR scaffolds | Project component graph and executable fitness functions |
| Factory substrate | Typed tool/MCP/context contracts | Worktrees, sandboxes, identity, secrets, hermetic builds |
| Execution | Wayfinder, skills, routing, generated agent contract | Agent harness, nodes, edges, checkpoints, tool runtime |
| Change | Change classes and Git protocol | Git repository, CI, protections, merge queue, provenance |
| Assurance | Test ladder, trace and evidence schemas | Collectors, eval datasets, calibrated evaluators, delayed metrics |
| Learning | Memory and learning-candidate schemas, promotion skill | Replay environment, shadow mode, canary, trusted promotion |

## Architecture Checks

### Aligned

- The harness is not represented as the factory.
- Constitution, generated content, and project-owned content are separated.
- Capability packs are conditional rather than universally installed.
- Skill dependencies are explicit and validated.
- Ontology relationships connect outcomes, work, agents, evidence, artifacts, and learning.
- Executor and evaluator separation remains an invariant.
- Learning artifacts remain candidates until independent promotion.
- Operational claims remain evidence-gated.

### Known Limitations

- The local ownership manifest uses hashes but is not signed or externally anchored.
- Profile validation is implemented in Python; the JSON Schema is not yet evaluated by a full
  standards-compliant schema engine.
- Skill routing is lexical and deterministic, not semantic or learned.
- Generated architecture is a scaffold, not a graph derived from project code.
- Tool and MCP contracts are schemas only; no server or permission broker exists.
- Knowledge graphs, memory, traces, and evals have contracts but no persistence runtime.
- No delayed maintainability evidence exists because no reference project has been operated.

## P2 Entry Conditions

P2 may begin when:

1. The P1 evidence suite passes.
2. A real reference project and accountable owners are selected.
3. Its profile is ratified.
4. The first architecture boundaries and change classes are approved.
5. The project accepts that Git, CI, sandboxing, secrets, deployment, and observability remain
   later implementation work unless pulled forward as reference-project requirements.
