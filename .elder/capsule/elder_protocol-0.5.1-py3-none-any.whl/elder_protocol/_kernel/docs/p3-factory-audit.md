# P3 Factory Substrate Audit

**Date:** 2026-08-05
**Verdict:** Local substrate operational; hosted and external activation gates remain.

## Operational Now

| Capability | Implementation | Current evidence |
|---|---|---|
| Factory contract | Typed manual validation plus JSON Schema | Foundation tests |
| Git repository | Root initialized on `main` | baseline `452e8c2` |
| Worktree isolation | `work/<work-item>` lifecycle | Temporary committed-repo Component test |
| Clean build | Short repo-owned staging copy | Real Workbench Integration and Workflow tests |
| Secret boundary | Allowlisted environment and forbidden secret-shaped names | Component test |
| Reproducible artifact | Deterministic ZIP and SHA-256 registry | Three full clean builds plus two real builds |
| Provenance | One append-only record per build | Two records for the same real artifact digest |
| Artifact verification | Safe extraction and smoke command | Real candidate smoke evidence |
| Promotion | Predecessor, evidence, and separate approval gates | Real local canary plus Component test |
| Rollback | Previous verified digest and separate approval | Component test |
| Factory traces | Append-only JSONL lifecycle events | `.factory/traces/factory.jsonl` |
| CI definition | Protocol, reference, and artifact jobs | Static contract checks |
| GitHub provenance | Commit-pinned `actions/attest` with OIDC permissions | Configured only |
| Ruleset and merge queue | Desired policy plus `merge_group` event | Configured only |

## Active Canary And Baseline Candidate

```text
active local-canary artifact:
0ed5454db59ba71d1342ecfaacf91cecda64c62af5d699df0aa1aae002ad7bef

canary source tree:
e196a3f81441867f21a4433bb8f088530964784588d71e5acf120bb34ccff68d

newer verified baseline candidate:
e1dbbe3d419e932f4e605f011d48dd3c2bbd88b17c6d380620721e4e5f4a6ab9
```

Two successive clean builds produced the same artifact digest and distinct
provenance records. Extraction and smoke verification passed with the workflow
ending at `needs-approval`.

The human operator approved that exact digest for `local-canary`. The factory
materialized the registered artifact without rebuilding it, its release-local
smoke run passed, and the extracted artifact started independently at
`http://127.0.0.1:8767` with a healthy `/health` response.

Repository hygiene regeneration produced the newer candidate digest shown
above. It is verified but was not promoted because approval for the older
canary digest does not authorize a different artifact.

## Defects Found During P3

1. The first clean-build staging path exceeded reliable Windows path handling.
   Build staging now uses a short repo-owned `.tmp/factory-builds/<id>` path.
2. The oversized-request test intermittently lost its response while the client
   was still sending a body. The API now drains bounded near-limit overages and
   returns `413 Payload Too Large`. The Component suite then passed twenty
   consecutive runs.
3. Initial provenance storage overwrote the prior record for the same artifact.
   Provenance is now append-only under the artifact digest.
4. The first CI output expression had invalid nested quoting. It was corrected
   before final verification.

## Activation Gates

P3 must not be called fully hosted or production-operational until:

1. A Git remote and real repository ownership identities are configured.
2. The desired ruleset, required checks, review requirement, and merge queue are
   activated and read back from the host.
3. The CI workflow runs successfully in the hosted repository.
4. GitHub artifact attestation availability is confirmed for the repository
   plan and a signed attestation is verified.
5. A cloud workload-identity trust and external secret broker are configured
   and audited.
6. Remote promotion receives a separate digest-specific release approval.
7. Rollback is exercised against a real target after a second approved artifact
   exists. Local rollback mechanics are currently verified in Component tests.
