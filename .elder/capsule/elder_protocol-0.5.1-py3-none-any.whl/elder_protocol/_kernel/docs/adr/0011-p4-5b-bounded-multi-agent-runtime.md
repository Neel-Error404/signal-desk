# ADR 0011: P4.5B Bounded Multi-Agent Runtime

## Status

Accepted.

## Context

P4.5A established the authority, delegation, child-run, message, checkpoint, cancellation, and
context contracts required before multi-agent execution. Those contracts did not yet coordinate
live local work, bind child operations to a runtime identity capability, persist lifecycle state,
propagate cancellation, or verify checkpoint and event replay.

## Decision

1. Implement one transactional SQLite coordinator as the local reference runtime.
2. Submit work only after validating the complete parent, delegation, child, project authority,
   digest-bound context packet chain, and repository-source contents.
3. Dispatch work through short-lived leases claimable only by the assigned child identity.
4. Journal typed actions, messages, checkpoints, cancellations, escalations, and runtime events
   as append-only records.
5. Enforce delegated resource actions, tools, cumulative budget, deadline, expiry, checkpoint
   frequency, contiguous sequence numbers, active parent lifecycle, full action lease interval,
   and operation-specific run authority before accepting child work, messages, checkpoints,
   cancellation, or escalation.
6. Derive runtime lifecycle transitions deterministically without granting approval or promotion
   authority to messages, checkpoints, or the coordinator.
7. Propagate cancellation transactionally to active descendant delegations, runs, and leases.
   Agent-originated cancellation must bind one active leased requester run and cannot target an
   ancestor, sibling, or terminal run.
8. Persist complete digest-bound lease states and emit complete lease artifacts for claim,
   release, expiry, and cancellation transitions. Replay must reconstruct each lease from those
   transitions and compare the final artifact and count with persistence.
9. Digest-bind cancellation and escalation rows to their complete artifacts, bind their runtime
   events to the same artifacts and digests, and compare replayed identifiers and counts with
   persistence. Cancellation without an active lease remains valid and must replay with no
   inferred lease state.
10. Verify persisted journal-row digests, the global runtime-event hash chain, checkpoint digest
   chain, signed checkpoint action coverage, append-only sequences, and reconstructed lifecycle
   state from a consistent read snapshot.
11. Bind delegated repository evidence to the resolved repository path and exact UTF-8 bytes,
   including line endings and otherwise invisible whitespace.
12. Keep external identity authentication, remote agents, distributed scheduling, model and tool
   execution, hosted durability, and autonomous promotion outside the local reference scope.

## Consequences

- P4.5 delegation contracts can now coordinate and inspect bounded local multi-agent work.
- A forged child identity or lease token cannot append child operations.
- Runtime state can be independently reconstructed from immutable journals, including complete
  lease transitions and cancellation and escalation records.
- Existing schema-version-1 local runtime stores require explicit rebuild or future migration;
  the reference runtime does not silently upgrade them.
- The coordinator remains an L1 local reference capability and does not raise the factory's
  overall maturity claim.

## Alternatives Rejected

- Trust the child identity string without a lease: rejected because any local caller could forge
  child-originated operations.
- Treat messages or checkpoints as approval: rejected because evidence cannot grant authority.
- Start with a hosted broker or distributed scheduler: rejected because hosted identity,
  tenancy, durability, and recovery are not yet established.
- Put counterfactual execution and learning promotion into P4.5B: rejected because those belong
  to the quarantined P4.6 learning phase.
