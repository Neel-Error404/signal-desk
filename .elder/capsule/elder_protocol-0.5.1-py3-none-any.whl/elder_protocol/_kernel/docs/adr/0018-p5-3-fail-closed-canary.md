# ADR 0018: P5.3 Fail-Closed Canary Execution

## Status

Accepted for mechanism implementation. Operational authority remains inactive.

## Context

P5.2 can create a supervised pull request under current L2 authority, but it deliberately grants
no deployment authority. P5.3 introduces the next bounded consequence: starting one production
canary with limited traffic, mandatory observation, and automatic rollback.

This boundary is materially stronger than pull-request creation. Provider identity, secret
access, telemetry, rollback readiness, immutable artifacts, and production targeting cannot be
caller assertions. A healthy canary also cannot become an implicit promotion decision.

The canonical Elder repository has no valid L3 qualification consumption, no L3-capable
canonical autonomy class or active L3 certification, no verified branch protection, no external
secret broker, no central production telemetry, and no real automatic rollback evidence.
Therefore P5.3 mechanisms may be implemented, but canonical canary authority must remain
inactive.

## Decision

1. Require effective autonomy L3. Re-run P4.7 from the signed hosted evidence bundle and require
   the supplied qualification consumption to exactly match current L3 recomputation.
2. Reuse the repository-owned P5.2 canonical authority source, independently signed governance
   statement, certification lifecycle replay, hard-stop evaluation, exact match, and work-item
   simulation. P5.3 does not create a parallel authority chain.
3. Preserve the canonical initial registry as exactly five L2 classes. Permit a separately
   governed `elder-project-autonomy-classes-v1` registry to define project classes capped at L3
   and by their parent change-class ceiling.
4. Define a digest-bound production canary plan containing one artifact, a distinct immutable
   rollback artifact, bounded traffic, bounded duration, an observation window, health
   thresholds, and automatic rollback.
5. Keep canary-plan simulation deterministic and side-effect-free. A passing simulation grants
   no authority.
6. Issue a separate short-lived canary lease that permits only start, observe, and rollback for
   one exact plan. It forbids full rollout, canary promotion, merge, maturity mutation, and
   automatic renewal.
7. Require a separate current independently signed canary-authority statement bound to the
   general autonomy-authority statement and exact plan, target, rollback artifact, traffic,
   timing, health, and rollback contract. The selected project L3 class must explicitly permit
   the `canary` consequence.
8. Require current independently signed provider evidence bound to the plan, target, artifact
   pair, traffic, timing, health, and rollback policy. The statement must verify external
   identity, secret brokering, a separate promotion gate, central telemetry, rollback readiness,
   immutable artifacts, and a provider-reserved deployment identifier known before side effects.
9. Pass only an immutable execution packet to a project-owned provider adapter. Reconstruct the
   lease and packet from trusted source records; then re-verify current qualification,
   certification lifecycle, incident budget, suspension, revocation, match, simulation, signed
   authority evidence, and signed canary authority before provider invocation.
10. Atomically consume the plan digest, packet digest, and execution ID in one runtime-owned
    canonical durable store before provider invocation. The execution caller cannot supply or
    replace this store. A claimed plan cannot be repackaged or reused, including after an invalid
    provider response.
11. Accept a provider response only when it exactly binds the authorized packet digest, provider,
   target, production environment, artifact pair, initial traffic, deployment identifier,
   trusted target URL prefix, and authorized execution time.
12. Treat a claimed start without an accepted response as recoverable uncertainty. Schedule the
    bounded start-response timeout before provider invocation. Provider failure or invalid
    responses trigger immediate idempotent `start-uncertain` rollback; the in-process watchdog
    and restart sweep recover claimed or hung starts after the bounded response timeout using
    the reserved deployment ID.
13. Require independently signed telemetry observations bound to that exact packet and the exact
    accepted response persisted in canonical runtime state, deployment identifier, provider,
    target, and artifact.
14. Require fresh observations. Measure maximum duration at evaluation time, not observation
    time. When samples or health thresholds fail or maximum duration is
    exceeded, create an immutable rollback packet, automatically invoke the provider rollback
    adapter, and accept only an exact rollback response completed inside the bounded rollback
    window. Every rollback executor must atomically claim canonical observing state and verify
    `requested_at <= runtime clock <= required_by` before both claim and provider invocation;
    future-dated authority and direct executor replay cannot bypass the claim. Deadline claims
    compare the persisted canary deadline with runtime time rather than a packet-selected
    timestamp. This is the only authority-bearing automatic consequence.
15. On accepted execution, persist the packet, response, and hard deadline and schedule a
    deadline watchdog. If watchdog installation fails, immediately create a
    `watchdog-unavailable` rollback bound to the accepted response. If usable telemetry is absent
    at maximum duration, create a `telemetry-deadline` rollback packet with no claimed
    observation hashes and invoke the same exact rollback path. Persist the exact rollback packet
    with its atomic claim, support durable due-work sweep after restart, and reclaim stale claims
    after a shorter claim timeout only by reusing the unchanged packet and digest inside its
    original rollback authorization window. The sweep uses the runtime clock, exposes no
    caller-controlled evaluation timestamp, records expired rollback authority terminally, and
    isolates per-record failures so one expired record cannot block rollback of another due
    canary.
16. A healthy observation emits only `continue-observing` while canonical state is still
    `observing`. Terminal canaries reject further observations. No response or observation report
    can promote, perform full rollout, merge, mutate maturity, or widen authority.
17. Keep canonical readiness false until valid L3 qualification consumption, an active
    L3-capable certification, canonical authority, protected hosted Git, external identity,
    secret brokering, central telemetry, and automatic rollback are all verified.

## Consequences

- P5.3 is product-agnostic: deployment-platform behavior remains behind a typed provider
  adapter, while the authority and evidence contracts remain protocol-owned.
- Fabricated plans, leases, authority statements, packets, provider booleans, responses, or
  observations cannot create authority.
- Execution packets are one-shot capabilities, and current governance changes can deny an
  otherwise unexpired lease before the provider is invoked.
- Governance state checks are bounded to the execution time and cannot be backdated or
  future-dated.
- Provider and telemetry trust uses the configured P4.7 trust-anchor model.
- Automatic rollback is permitted only inside the exact canary lease; promotion remains a
  separate accountable human-governed action.
- Synthetic tests prove mechanism behavior only and cannot activate the canonical repository.

## Alternatives Rejected

- Treat a P5.2 PR lease as deployment authority: rejected because code-authoring and production
  consequences require different maturity and controls.
- Trust provider-control booleans supplied by the caller: rejected because those claims are the
  production evidence being verified.
- Let healthy telemetry promote the artifact: rejected because observation is evidence, not
  promotion authority.
- Activate canonical P5.3 using the existing advisory L2 bundle: rejected because P5.3 requires
  current L3 qualification and L3 factory evidence.
