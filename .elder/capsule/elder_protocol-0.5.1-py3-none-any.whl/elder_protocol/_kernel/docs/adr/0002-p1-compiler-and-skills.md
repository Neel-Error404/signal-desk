# ADR 0002: P1 Compiler Ownership And Skill Architecture

## Status

Accepted for P1.

## Context

A useful Elder implementation must regenerate project contracts without replacing project-owned
work. It also needs reusable skills and ontology relationships without loading every instruction
into every agent context.

## Decision

1. Profiles are explicit, versioned, and migratable.
2. Capability-pack dependencies are resolved deterministically.
3. Skill trigger metadata lives in a central registry while each concise `SKILL.md` contains
   only `name`, `description`, and procedural instructions.
4. Generated project files are recorded in `.elder/ownership.json` with content hashes.
5. Regeneration overwrites only unchanged Elder-owned files.
6. Modified or unowned target files fail closed unless the operator explicitly uses `--force`.
7. Dry-run and unified diff are first-class compiler modes.
8. Context, tools, MCPs, memory, traces, and learning use typed schemas before runtime services
   are introduced.

## Consequences

- Elder can compile into an existing project without owning the whole repository.
- Skill routing is deterministic and inspectable.
- Profile upgrades can introduce explicit review notes.
- The ownership manifest is not tamper-proof until Git, signing, and CI provenance exist.
- Runtime enforcement remains P2-P4 work.

## Alternatives Considered

- Overwrite a fixed template: rejected because it destroys project ownership.
- Put all skill routing rules inside every `SKILL.md`: rejected because metadata would drift and
  require loading excessive context.
- Delay typed interfaces until runtime implementation: rejected because later harnesses would
  invent incompatible contracts.
