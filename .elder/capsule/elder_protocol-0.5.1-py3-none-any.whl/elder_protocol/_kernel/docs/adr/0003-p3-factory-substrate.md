# ADR 0003: Bounded Factory Substrate

## Status

Implemented locally and proposed for architecture, security, and release-owner
ratification.

## Context

P2 proved a governed local product workflow but did not provide isolated Git
workspaces, clean builds, immutable artifacts, provenance, promotion, or
rollback. P3 must add those controls without treating configuration as proof of
hosted branch protection, cloud identity, or production deployment.

## Decision

Adopt `factory/factory-contract.json` as the machine-readable substrate contract.
The P3 implementation provides:

```text
work item -> isolated worktree -> clean source copy -> ordered tests
-> deterministic artifact -> content-addressed registry -> smoke evidence
-> separate approval -> same-digest promotion -> rollback history
```

Local commands run with an allowlisted, secretless environment. Names matching
token, secret, password, credential, API key, or private-key patterns are never
inherited by build or verification commands.

Artifact ZIP entries use sorted paths, fixed timestamps, stable permissions, and
fixed compression settings. The SHA-256 digest is the artifact identity.
Repeated builds may add new provenance records but cannot mutate the registered
artifact bytes.

Promotion to `local-canary` or `local-stable` requires:

1. the exact digest to be current in its predecessor environment;
2. passing smoke evidence for that digest;
3. a separate release approval bound to action, digest, and environment.

Rollback uses the same approval and health requirements and rematerializes a
previously verified digest.

## Git And Hosted CI

The root repository is initialized on `main` with human-authorized baseline
commit `452e8c2c97c12b71158444dca6f9e63f95eb96de`. Worktree lifecycle is
executable and tested in an isolated committed fixture repository. Root
worktrees are now technically available, although no worktree is created
without a declared work item.

The GitHub workflow defines exact required check names, handles pull requests,
`main` pushes, and merge-queue events, and uses commit-pinned official actions.
The artifact job requests only `contents: read`, `id-token: write`, and
`attestations: write`. A desired ruleset is recorded in
`factory/github-ruleset-plan.json`.

Hosted branch rules, merge queue, and GitHub OIDC attestations remain unverified
until a remote repository, applicable GitHub plan, administrator activation,
and successful workflow run exist.

## Consequences

- Local artifacts are reproducible and content-addressed.
- Local build and verification commands receive no inherited credentials.
- Release approval remains separate from the authoring agent.
- Local approval records are governance evidence, not cryptographic signatures.
- Remote or production secret access remains fail-closed because no external
  broker or cloud trust relationship is configured.
- The local directory now has an exact baseline revision, but no remote, branch
  protection, or active merge queue.
