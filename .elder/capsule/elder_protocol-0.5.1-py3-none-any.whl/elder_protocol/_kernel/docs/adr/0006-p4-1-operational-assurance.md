# ADR 0006: P4.1 Operational Assurance

## Status

Accepted by operator instruction on 2026-08-05.

## Context

P4.0 made assurance principles machine-readable, but three recommendations remained contract-only:

- design documents had no versioned registry or drift detection;
- architecture boundaries had one hard-coded reference check rather than a reusable adapter
  contract;
- transcript review had no executable independent evaluator.

Without these runtimes, design intent could change without notification, dependency rules could
remain prose, and meta-agent review could be discussed without producing inspectable evidence.

## Decision

Elder Protocol 0.4.1 implements P4.1.

1. Design documents are registered with path, status, owners, change classes, notification
   audience, supersession links, and a content digest.
2. Protocol validation fails when a registered document is missing, stale, malformed, or refers
   to an unknown superseded document.
3. Architecture boundaries use a versioned adapter contract. The first adapter parses Python AST
   imports, enforces allowed internal dependencies, and rejects undeclared modules when configured
   fail-closed.
4. Elder Workbench moves its Python dependency policy into a project-owned boundary contract and
   retains an executable Foundation fitness function.
5. Transcript review consumes immutable JSONL workflow traces under a versioned policy.
6. The evaluator identity must differ from the executor identity.
7. Review output is advisory-only, cannot approve or promote, and records findings, metrics,
   verdict, policy, identities, and timestamp.
8. Deterministic transcript checks are the first runtime. Probabilistic model review and
   calibration remain P4.2 work.

## Consequences

- Design-document changes require an explicit registry digest update.
- Python dependency rules are data rather than hard-coded source constants.
- Transcript review now produces reusable evidence without receiving authority.
- Generated projects receive design, boundary, and transcript-review contracts.
- P4.1 improves local assurance but does not raise the whole-factory maturity above L1.

## Alternatives Considered

- Rely on Git history for design versioning. Rejected because Git does not declare owners,
  notification audiences, supersession, or required change classes.
- Keep architecture rules in language-specific source code. Rejected because project graphs and
  agents cannot inspect or translate them consistently.
- Start with an LLM evaluator only. Rejected because a deterministic baseline is required before
  probabilistic judgment and calibration.
