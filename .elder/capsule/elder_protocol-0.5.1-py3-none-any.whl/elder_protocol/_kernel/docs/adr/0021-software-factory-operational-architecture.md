# ADR 0021: Software Factory Operational Architecture

## Status

Accepted. Human-ratified on 2026-08-08.

## Date

2026-08-08

## Context

Elder has a product-agnostic protocol kernel, local reference runtimes for knowledge,
coordination, learning, qualification, and bounded autonomy, and a P3 artifact substrate. It does
not have the durable operations loop required to receive signals, own a backlog, transition work,
dispatch workers, preserve commands across restart, rebuild projections, or present one
owner-visible operating history.

SF-002 defines a provider-neutral factory domain. SF-003 defines stable worker, governance,
integration, command, event, cursor, idempotency, error, and redaction contracts. SF-004
recommends an independent local adaptation instead of direct Mastra package integration or a
fork. SF-005 confirms Codex as the primary worker behind a factory-owned adapter and limits Prime
Agent to a deferred optional continuity sidecar.

This decision must preserve the accepted Elder hierarchy and authority boundaries. In
particular, an operations store cannot absorb governance, trusted memory, learning approval,
qualification, certification, release, or production authority merely because those records are
correlated in one owner view.

## Decision

### 1. Architecture Shape

Adopt four planes connected through one stable contract family and one logical event spine:

1. Product and owner plane.
2. Factory operations plane.
3. Worker plane.
4. Elder governance and learning plane.

The factory operations plane owns canonical operational state. The worker plane remains
non-authoritative. Elder remains the authority for governance, context, evaluation,
qualification, autonomy, and learning promotion.

The logical event spine does not mean one universal physical database. The operations journal is
canonical for factory operations. Elder governance and learning records remain canonical in
their existing governed stores. Operations may append digest-bound references or normalized
facts about those records for correlation and projection, but those mirrors cannot replace or
reinterpret the source record.

### 2. Phase 1 Implementation Choice

Build an independently implemented Python operations kernel in the central `elder-protocol`
repository behind the SF-003 contracts.

- Keep the provider-neutral domain, schemas, and adapter contracts under the existing
  `factory/` and `elder_protocol` boundaries.
- Place the Phase 1 operations implementation behind a dedicated
  `elder_protocol.factory_operations` package boundary.
- Keep product source, product architecture, and product-local Elder capsules in their product
  repositories.
- Bind product repositories by stable project and repository references; perform mutations only
  in isolated, authorized workspaces.

Mastra remains a pinned behavioral and failure-test reference. Do not add `@mastra/factory`,
vendor source, or create a selective fork for Phase 1. Any later package integration requires a
new compatibility, license, dependency, and conformance decision.

### 3. Components

The local operations kernel consists of these bounded components:

| Component | Responsibility | May depend on |
|---|---|---|
| contract boundary | SF-002 entities and SF-003 schemas and validation | protocol primitives |
| product registry | persist product-owner-authorized factory bindings and owner-view projections without owning product intent | contract boundary, operations store |
| signal intake | authentication result, quarantine, normalization, dedupe | product registry, ledger |
| work ledger | work items, revisions, source links, dependencies, optimistic concurrency | contract boundary, operations store |
| transition service | deterministic guards, authority references, atomic history | ledger, governance gateway |
| dispatcher | durable claims, leases, retries, uncertainty, dead letters | ledger, command journal |
| run controller | run, workspace, worker-session, checkpoint, and artifact bindings | dispatcher, worker gateway |
| operations journal | append-only operational facts, cursors, replay, projection checkpoints | operations store |
| projections | rebuildable owner and API read models | operations journal |
| worker gateway | SF-003 worker adapter invocation and response normalization | worker adapters |
| governance gateway | SF-003 governance adapter invocation and source-record binding | Elder public contracts |
| operations API | authenticated commands, queries, health, and event cursors | application services, projections |

Components communicate through typed application contracts. Database tables, provider objects,
and internal Python objects are not cross-component APIs.

### 4. Contract Layering

The existing P3 contract and the SF-003 registry are layered and neither silently supersedes the
other:

| Contract | Scope | Canonical consumer |
|---|---|---|
| `factory/factory-contract.json` | P3 repository isolation, build, artifact, promotion, rollback, Git, and local workspace policy | P3 factory CLI, build, qualification, and autonomy evidence paths |
| `factory/factory-domain.json` | Provider-neutral operations entities, lifecycles, ownership planes, and invariants | Phase 1 operations implementation and conformance tests after ratification |
| `factory/factory-contracts.json` | Worker, governance, integration, command, event, cursor, error, idempotency, and redaction boundaries | Operations, worker, governance, and integration adapters after ratification |

The P3 substrate remains authoritative for build and artifact behavior. SF-002 and SF-003 add the
operations model above it. Consolidation or supersession requires a separate public-contract
ADR, compatibility plan, and migration evidence.

Before ratification, SF-002 and SF-003 remain draft artifacts validated by their dedicated
Foundation suites. They must not be required inputs to canonical `elder validate`. After
ratification, their exact bytes and status are registered before they become canonical protocol
prerequisites.

### 5. Authority Derivation

Factory ownership and `authorized_roles` identify roles eligible to request or record a
transition. They do not independently grant mutation authority.

Every accepted canonical transition must bind:

1. the authenticated project identity and role binding;
2. the mapped Elder resource and action permission;
3. the current work-item, run, and record version;
4. the applicable accountable human command or validated delegation;
5. an active assigned-identity Elder runtime lease when the operation is delegated;
6. a governance-adapter authorization result bound to the exact transition request.

`modify-only`, `execute-bounded`, `human-approval`, and `promotion-only` are required authority
modes, not self-authenticating labels. A transition with no exact Elder action/resource mapping
or current authority evidence is rejected. Dispatch leases serialize operational ownership and
never substitute for delegation, approval, identity, or authority.

The Phase 1 transition service must add the exact mapping as machine-readable dependency truth.
If that mapping requires new protected authority resources or actions, SF-103 must present the
intentional `protocol/authority-matrix.json` diff for human approval before enabling the
transition.

### 6. Dependency Direction

Allowed:

```text
owner client -> operations API
integration adapter -> signal intake
operations application services -> contract boundary
transition service -> governance gateway
dispatcher and run controller -> worker gateway
worker gateway -> version-pinned worker adapter
worker adapter -> external worker runtime
projections -> operations journal
operations journal references -> Elder source-record digests
learning proposal -> Elder learning runtime
```

Forbidden:

```text
owner client -> direct database mutation
integration adapter -> direct worker invocation
worker runtime -> direct work-item or transition mutation
worker runtime -> direct trusted-memory, policy, decision, or promotion mutation
provider object -> canonical factory identity or lifecycle
projection or live event -> canonical command completion
operations store -> replacement of Elder governance or learning authority
Elder protocol kernel -> dependency on Codex, Prime, Mastra, or one provider
```

### 7. Store Ownership

Use separate authority stores:

| Store | Local implementation | Canonical contents |
|---|---|---|
| operations store | SQLite, WAL, full synchronous durability | product-owner-authorized factory bindings, signals, work ledger, transitions, runs, sessions, workspaces, commands, schedules, incidents, idempotency, dispatch leases, operational journal, projection checkpoints |
| artifact registry | existing content-addressed P3 filesystem registry | immutable artifacts, provenance, promotion and rollback history |
| knowledge store | existing Elder P4.4 SQLite adapter | graph, candidate memory, trusted memory, context provenance |
| coordination store | existing Elder P4.5B SQLite adapter | delegated-run leases and governed runtime journals |
| learning store | existing Elder P4.6 SQLite adapter | candidates, observations, evaluations, approvals, promotion packets |
| qualification and autonomy records | existing signed records and governed manifests | hosted evidence, qualification, certification, leases, and authority packets |
| source repositories | Git | product and factory source history |
| provider runtime | external and adapter-local | provider sessions, turns, processes, and native events |

The local operations store path is `.factory/runtime/operations.db`. It is runtime state and is
not committed. It must expose explicit schema versioning, integrity checks, backup, replay, and
rebuild behavior.

Physical custody does not change entity authority. `ProductFactory` remains canonical to the
product-owner plane. The operations store may persist the accepted binding and a rebuildable
owner projection, but it cannot originate or reinterpret product intent, profile ratification,
autonomy ceiling, or accountable product decisions.

Cross-store references use stable identifiers and content digests. Phase 1 does not use
cross-database transactions. A failed governance or worker boundary call leaves an explicit
pending, rejected, failed, or uncertain operational record that can be reconciled.

Runtime primitives remain distinct:

| Primitive | Authority and store |
|---|---|
| factory dispatch lease | Operations-store concurrency claim; never authority |
| Elder delegation/runtime lease | P4.5B coordination-store authorization for an assigned delegated identity |
| provider session generation | Operations-store recovery and stale-writer fence |
| worker checkpoint observation | Adapter observation until accepted through the governance gateway |
| canonical delegated checkpoint | P4.5B coordination-store evidence bound to delegation and child run |
| projection checkpoint | Operations-store internal read-model offset; not an SF-002 `Checkpoint` |

The operations store keeps references and digests to canonical delegated checkpoints. It cannot
copy a provider checkpoint into canonical Elder state without the governance checks required by
P4.5B.

### 8. Worker Selection

Codex is the primary implementation worker behind a factory-owned, version-pinned adapter.

- Prefer the app-server v2 control surface for interactive start, resume, steer, interrupt, and
  event observation.
- Keep `codex exec --json` as a bounded batch fallback and diagnostic surface.
- Supply and verify effective workspace, approval, sandbox, network, and additional-root policy
  for every started or resumed session.
- Keep provider session, thread, turn, item, process, rollout, configuration, and credential
  identifiers opaque and non-authoritative.
- Treat a lost mutating response as uncertain until factory-owned reconciliation completes.

Prime is not a Phase 1 dependency. It may be reconsidered in SF-204 as an optional supervised
continuity sidecar after Windows or hosted-Linux operation, identity, credential, lease,
translation, and refinement-interception proof. Prime refinement may only create an Elder
learning candidate.

### 9. Repository Topology

Use one central Elder repository for the protocol, factory implementation, schemas, adapters,
tests, and release artifacts. Keep each product in its own repository with its own pinned Elder
capsule and product-owned source.

The factory may create isolated worktrees or workspaces for a bound product repository. It does
not absorb product source into the Elder repository and does not overwrite project-owned files
outside an authorized work item.

This is a deliberate multi-repository product topology with a single factory-kernel repository,
not a universal product monorepo.

### 10. Rollout

1. Phase 1: local single-process Python kernel, SQLite operations store, one active Codex worker
   capacity, restart-safe ledger, dispatcher, journal, projections, and API.
2. Phase 2: real Codex adapter, isolated workspace lifecycle, recovery, evidence collection, and
   supervised issue-to-evidence flow.
3. Phases 3 through 5: owner control room, explicit Elder lifecycle gates, and one quarantined
   learning target.
4. Hosted L2: replace the operations storage adapter with Postgres, add a durable broker or
   stream, workload identity, secret broker, hardened workspaces, central telemetry, backups,
   recovery, and independent qualification.
5. Narrow L3: only after current L3 evidence and certification, add one bounded canary class with
   verified automatic rollback. Healthy observation never promotes by itself.

Phase advancement remains evidence-bound. Local implementation does not raise canonical
maturity above L1.

### 11. Storage Migration And Rollback

SQLite-to-Postgres migration must use a single-writer cutover:

1. Put the operations service in maintenance mode and stop new claims.
2. Reconcile all uncertain commands and expire or release active leases.
3. Record a source checkpoint, SQLite backup digest, schema version, and journal tip.
4. Import immutable journal and canonical records into a fresh Postgres database.
5. Rebuild projections and compare record counts, journal hashes, and projection digests.
6. Switch the storage binding only after independent verification.
7. Keep the SQLite snapshot read-only until the rollback window closes.

Do not operate dual writable primaries. Rollback before hosted writes switches back to the
verified SQLite snapshot. Rollback after hosted writes requires a validated reverse journal
export or forward repair; it must not silently discard accepted work.

### 12. Ratified Inputs

Acceptance of this ADR ratifies the following for Phase 1:

- SF-002 factory domain version `0.1.0`;
- SF-003 factory contracts version `1.0.0`;
- SF-004 local-adaptation recommendation;
- SF-005 Codex-primary and Prime-deferred recommendation;
- the component, dependency, store, repository, worker, migration, and rollout decisions above.

Ratification binds the exact SHA-256 digests listed in
`factory/operational-architecture.json`, including the domain, contract, entity, command, event,
adapter, cursor, and operational-architecture schemas. The approval record also binds a
canonical accepted-architecture digest that excludes only its two cycle-breaking linkage
fields: `accepted_architecture_sha256` and `approval_record_sha256`. A changed domain, contract,
schema, spike decision, or substantive architecture field requires a refreshed review and
approval record.

It does not approve third-party code reuse, package integration, hosted activation, provider
credentials, maturity changes, autonomous certification, merge, release, or deployment.

## Fitness Functions

The implementation must make these executable:

1. Architecture-boundary checks reject forbidden imports and provider coupling.
2. Every canonical operational mutation goes through one application command and transaction.
3. Duplicate signal and mutating command identities do not repeat effects.
4. Journal replay rebuilds byte-equivalent or digest-equivalent projections.
5. Accepted commands survive process termination.
6. Lease loss or stale generation prevents stale completion.
7. Unknown mutation state cannot enter a normal retry path.
8. Worker output cannot directly mutate work-item, decision, authority, memory, or promotion
   records.
9. Every transition verifies an exact Elder action/resource mapping and current authorization
   evidence; role membership alone is insufficient.
10. Operations references to governance and learning records verify source identifiers and
   digests.
11. Secret-shaped payloads and direct credentials are rejected before journal persistence.
12. Store integrity, schema version, backup, restore, and migration comparison fail closed.
13. Every completed work item links outcome, run, source revision, diff or artifact, ordered
    tests, evidence, decisions, and delivery state.

## Threat Review

Primary threats and required controls:

| Threat | Required control |
|---|---|
| confused-deputy worker or integration | no direct execution or state mutation; exact project, work-item, command, authority, and workspace binding |
| duplicate or uncertain side effect | durable acceptance, idempotency, provider receipt reconciliation, no blind retry |
| stale lease or recovered process writes | owner and generation fencing on every completion |
| role membership mistaken for authority | exact Elder action/resource mapping, governance authorization, and active delegated lease where applicable |
| provider identity becomes authority | opaque provider references and factory-owned canonical identifiers |
| event or projection spoofing | append-only journal, digest and cursor validation, source-plane allowlists |
| cross-store authority drift | digest-bound source references and revalidation at governance gates |
| secret persistence | secret broker references, redaction validation, secret-shaped field rejection |
| repository escape | canonical path resolution, isolated workspace, root containment, authorized changed-path checks |
| migration data loss or split brain | maintenance mode, single writer, journal-tip comparison, no dual writable primaries |
| self-ratifying architecture or learning | explicit human approval, independent review, P4.6 promotion separation |

## Consequences

- Elder gains a concrete implementation path without making a provider or third-party framework
  canonical.
- The central repository owns more operations code and must maintain its failure semantics.
- SQLite is sufficient only for the local single-process gate.
- Multiple authority stores require explicit correlation and reconciliation instead of hidden
  cross-database transactions.
- The owner UI can present one history while preserving each source system's authority.
- Hosted migration is an adapter and operational-evidence project, not a database connection
  string change.

## Alternatives Rejected

- Direct Mastra package integration: rejected for Phase 1 because stable public operations seams,
  provider-neutral state ownership, Windows behavior, and compatible dependency evidence are not
  established.
- Selective Mastra fork: rejected because it imports excessive source and maintenance ownership.
- Prime as the canonical worker daemon: rejected because Windows operation, credential boundary,
  provider-local authority, and refinement interception are not proven.
- One universal SQLite database: rejected because it collapses operational, governance,
  knowledge, learning, qualification, and autonomy authority.
- One physical global event journal: rejected because governance and learning source records have
  independent replay and authority requirements.
- Postgres and broker in Phase 1: rejected because they add operational surface before local
  correctness and restart behavior are proven.

## Ratification

The human owner explicitly recorded:

```text
RATIFY ADR 0021 AS HUMAN-OWNER, ARCHITECTURE-OWNER, AND CODE-OWNER
```

The accepted decision is bound to
`docs/software-factory/evidence/SF-006-ratification.json`, retained byte-exact proposal
snapshots, the canonical accepted machine-architecture digest, and the exact ratified SF-002
through SF-005 documents and public schemas.

This Gate A decision covers the `public-contract` architecture and its `internal-code`
validation support. It does not approve infrastructure activation. SF-100 and later
implementation tasks must separately satisfy their applicable security-owner and release-owner
evidence and approval requirements.
