# ADR 0008: P4.3 Correlated Telemetry

## Status

Accepted by operator approval on 2026-08-05.

## Context

Elder already records Workbench workflow traces, factory lifecycle traces, evaluation reports,
artifact provenance, costs, and outcomes. These records use different shapes and cannot be
queried or budgeted as one execution story. The missing link is not another vendor dashboard; it
is a stable provider-neutral contract that connects product behavior, model operations, tools,
factory actions, cost, and observed outcomes without leaking prompts, secrets, or high-cardinality
identifiers into metrics.

OpenTelemetry and W3C Trace Context provide the interoperability baseline, but GenAI semantic
conventions continue to evolve. Elder therefore pins the reviewed convention reference in a
contract, isolates translation in adapters, and keeps the canonical Elder event envelope stable.

## Decision

1. Add a typed telemetry contract, event schema, and report schema.
2. Require W3C-compatible non-zero trace and span identifiers.
3. Require `project_id` and `run_id` on every event, with optional work-item, agent-run,
   artifact, deployment, evaluation, and outcome correlations.
4. Keep high-cardinality correlation identifiers out of metric dimensions.
5. Reject secret-shaped attribute and metric-dimension names.
6. Do not persist prompts or model outputs by default.
7. Normalize Workbench, factory, and evaluation evidence through deterministic local adapters.
8. Aggregate cost, error rate, latency, correlation completeness, outcomes, and metric
   cardinality into an advisory budget report.
9. Give telemetry no approval or promotion authority.
10. Keep hosted collectors, alerting, retention, exemplars, and production backends as explicit
    activation work rather than representing the local JSONL runtime as production observability.

## Consequences

- A single local report can explain one or more correlated runs across all six P4.3 scopes.
- Workbench traces carry native trace context instead of relying only on post-processing.
- Historical evidence remains usable through synthesized, clearly marked identifiers.
- Metric cardinality and telemetry privacy become deterministic controls.
- Stack adapters may export the canonical event envelope to OpenTelemetry-compatible backends
  without making the backend Elder's source of truth.
- Elder remains at operational maturity L1 because no hosted telemetry, production alerting,
  remote canary observation, or retention service has been verified.

## Rejected Alternatives

- Treat every JSON log line as telemetry without a typed envelope.
- Use trace, span, run, or work-item IDs as metric labels.
- Persist prompts and model outputs for convenience.
- Couple the kernel directly to one collector, vendor, or GenAI SDK.
- Let a passing telemetry report authorize deployment.

## Verification

- Foundation validation of the contract, schemas, ontology, graph, authority, and design hash.
- Component tests for adapters, privacy, trace identifiers, metric dimensions, budgets, and
  cardinality.
- Integration evidence from a real Workbench run plus factory and evaluation evidence.
- Workflow verification through the telemetry CLI.
- Stress verification across repeated correlated runs and cardinality overflow.
