# ADR 0007: P4.2 Independent Evaluation Harness

## Status

Accepted by operator instruction on 2026-08-05.

## Context

P4.1 can verify design-document integrity, Python dependency direction, and transcript
structure. It cannot compare candidate behavior against a governed dataset, calibrate a
probabilistic judge, or determine whether a proposed configuration regresses against a
baseline.

Evaluation is itself a governed production component. Dataset drift, evaluator self-review,
uncalibrated model judges, outcome-only grading, and aggregate scores that hide critical
regressions can all create false confidence.

## Decision

Implement a provider-neutral evaluation harness with:

- a content-hash-bound dataset registry;
- explicit development, calibration, and holdout splits;
- exact, contains, numeric, and rubric grader contracts;
- immutable candidate and judge-result artifacts;
- mandatory executor/evaluator identity separation;
- offline calibration of rubric judges against human reference labels;
- accuracy, precision, recall, F1, abstention, cost, latency, and tool-call metrics;
- paired candidate-versus-baseline comparison;
- fail-closed critical-risk regressions;
- advisory-only evaluation, calibration, and comparison reports.

Model invocation is an adapter boundary. P4.2 consumes typed judge results and validates their
calibration; it does not embed provider credentials or permit a model judge to approve,
promote, or modify its own policy.

## Consequences

- Deterministic graders remain the preferred control when a property can be expressed exactly.
- Rubric judges must qualify on the calibration split before they can score holdout cases.
- Evaluation datasets become governed artifacts with owners, sensitivity, licensing, split,
  threshold, and content-digest metadata.
- A passing aggregate cannot conceal a newly failed critical case.
- Reports can inform a human decision but cannot authorize a release.
- Hosted isolation, live model-provider adapters, statistical confidence intervals, and
  longitudinal outcome calibration remain future work.

## Sources Considered

- OpenAI evaluation guidance: define objectives, collect representative datasets, prefer
  task-specific graders, and continuously evaluate.
- UK AI Security Institute Inspect: typed samples, multiple scorer types, model grading,
  per-sample metadata, splits, logs, and aggregate metrics.
- Current agent-evaluation research emphasizing trajectory analysis, held-out human
  validation, precision/recall reporting, and outcome-linked failure analysis.
