# ADR 0020: Repository-Local Elder Capsule And Mandatory Build Memory

**Status:** Accepted
**Date:** 2026-08-07

## Context

Elder is useful only when its contracts, agent instructions, skills, activation checks, and
learning boundary are available inside each product repository. Making every product execute
against one central Elder checkout would create an undeclared runtime dependency, prevent
project-specific pinning, and make upgrades capable of changing many products at once.

Development memory also needs to survive a fresh clone without committing a large virtual
environment, SQLite database, or vector index. Mem0 semantic state cannot be the sole authority
because it is derived, provider-shaped, and not independently approved.

## Decision

1. The central Elder repository remains the upstream factory, test bed, and release source.
2. The factory produces a deterministic portable ZIP containing a pinned Elder wheel, a
   commit-bound manifest, a local launcher, bootstrap logic, an intake example, and a complete
   new-project prompt.
3. Every product installs and versions its own capsule under `.elder/capsule/`.
4. Capsule installation and updates verify all currently owned files before replacement.
5. Capsule updates may replace only prior capsule-owned files. They do not replace product
   source, project-owned documents, or compiled personalized Elder contracts.
6. `.elder/runtime/tooling/` is an ignored Elder-only environment. The product's package
   environment remains independent.
7. Every Elder product has mandatory build memory, regardless of whether the product itself
   has an application-memory feature.
8. `.elder/memory/trusted.json` is the tracked, digest-bound, independently approved authority
   for portable build memory.
9. `.elder/runtime/knowledge.db` and `.elder/runtime/memory/qdrant/` are derived local state and
   may be rebuilt from the trusted ledger.
10. Live activation synchronizes trusted records into Mem0 and uses semantic recall only to rank
    canonical ledger records for the current task.
11. Session closure may propose candidate memories from immutable evidence. Candidates require
    independent human promotion before entering the trusted ledger.
12. Product or customer memory remains a separate product-owned system with separate storage,
    credentials, policy, retention, and authority.

## Consequences

- A product can operate under its pinned Elder version without the factory checkout.
- The exact Elder source commit and payload digests are inspectable in each product.
- Product teams can upgrade deliberately and regenerate personalized contracts after review.
- A fresh clone restores trusted development memory and rebuilds local semantic state.
- Each active product may create an ignored Elder tooling environment; this consumes local disk
  but avoids coupling Elder dependencies to the product runtime.
- Cross-repository learning and a shared knowledge graph remain future higher-level systems.
