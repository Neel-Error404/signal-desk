# ADR 0016: P5.2 Supervised Autonomous Pull Requests

## Status

Accepted.

## Context

P5.1 can prove that a bounded work item matches a certified class and can replay its governance
state without side effects. The next autonomy boundary is not merge or deployment. It is a
supervised pull request created from an isolated workspace after current hosted qualification,
ordered tests, and independent evaluation.

The canonical Elder repository has no configured external qualification trust anchors, no valid
hosted L2 qualification consumption, no active class certification, no verified hosted branch
protection, and no verified external workload identity. The implementation must therefore expose
the mechanism while keeping canonical activation blocked.

## Decision

1. Require effective autonomy of at least L2 from the minimum calculation defined in P5.0.
2. Re-run P4.7 from the signed hosted bundle at authority issuance. Treat caller-provided
   qualification consumption and derived reports only as evidence to compare against trusted
   recomputation.
3. Resolve the project authority universe from a repository-owned canonical authority source
   before consuming any signed statement. The source pins the project ceiling and the approved
   autonomy policy, autonomy classes, change classes, qualification policy, and maturity-model
   digests. Require a current independently signed governance statement that binds that canonical
   source and its digest; the configured policy digests and project ceiling; work item;
   certification and complete lifecycle chain; qualification consumption; incident budget;
   suspensions, revocations, and hard-stop state; artifact; and every derived report. A caller
   cannot select a different policy, ceiling, trust configuration, or authority source.
4. Require an active unexpired certification whose lifecycle event chain replays to active at
   the lease issue time, a passing P5.1 match, and a passing P5.1 simulation.
5. Issue a short-lived digest-bound authority lease scoped to one project, work item, autonomy
   class, certification, lifecycle replay, qualification consumption, effective-autonomy
   calculation, match report, and simulation report.
6. Permit only isolated-workspace creation, bounded change application, ordered test execution,
   evidence-packet creation, and pull-request creation.
7. Require Foundation, Component, Integration, Workflow, and Stress evidence in that order.
8. Require executor and evaluator separation.
9. Replace caller-asserted hosted-state booleans and caller-computable execution reports with a
   current independently signed provider statement that binds the project, provider, repository,
   isolated workspace, exact changed paths, operations and before/after content digests, ordered
   test results, executor and evaluator identities, independent evaluation, base and head
   branches, full Git object identifiers, diff SHA-256, required checks, branch protection,
   signed provenance, and external identity.
10. Bind actual paths, operations, and before/after content digests exactly to the declared work
   item.
11. Treat Git revisions as full object identifiers under an explicit repository object format:
    40 lowercase hexadecimal characters for SHA-1 repositories and 64 for SHA-256 repositories.
    Keep Git object identifiers distinct from SHA-256 content and diff digests.
12. Before provider invocation, validate the packet digest, reconstruct the packet from its
    execution and current lease, reconstruct the lease from trusted source records, verify lease
    time bounds, and re-run current signed qualification checks.
13. Keep pull-request submission behind an explicit provider interface. The provider receives
    only an already-authorized immutable packet and must return an open pull-request identity
    bound to that packet digest, provider, repository, object format, base and head branches, base
    and head revisions, diff digest, and a trusted provider-signed repository URL prefix. Reject
    unrelated hosts, repository paths, credentials, query strings, fragments, or a URL whose
    terminal identifier differs from the returned pull-request identifier. Treat the repository
    identity as the exact provider-relative leading URL path, not a substring match.
14. Retain human merge and release authority. The lease and packet cannot merge, deploy, mutate
    maturity, or renew a certification automatically.
15. Report the canonical repository as blocked until genuine external L2 evidence and hosted
    controls exist. Test fixtures verify mechanics but do not satisfy that operational gate.

## Consequences

- A certified agent can prepare and submit a narrowly scoped pull request only when every
  qualification, certification, workspace, evidence, and hosted-governance gate passes.
- Caller-computable hashes, caller-selected policy inputs, and caller-provided reports cannot
  create authority without the repository-owned canonical authority source, signed hosted bundle,
  and complete cross-bound source chain.
- Self-asserted hosted controls and provider responses that drift from the authorized packet fail
  closed.
- A valid policy alone does not activate P5.2.
- Humans remain accountable for merge and release.
- P5.3 can later govern canary execution without widening the P5.2 lease.

## Alternatives Rejected

- Allow local or synthetic qualification to activate canonical P5.2: rejected because it would
  fabricate hosted maturity.
- Grant merge authority with pull-request authority: rejected because review and release remain
  separate accountable decisions.
- Let a provider infer or widen scope: rejected because submission must consume an immutable
  authorized packet.
