# ADR 0013: P4.7 Hosted Production Qualification

## Status

Accepted

## Context

Elder has local evidence for bounded builds, evaluation, telemetry, knowledge, multi-agent
coordination, and quarantined learning. Those local runtimes do not prove hosted branch
governance, external identity, signed provenance, production telemetry, recovery, canary, or
rollback operation. Configuration and self-authored JSON are not sufficient evidence for a
higher factory maturity claim.

P4.7 needs a deterministic way to evaluate externally produced hosted evidence against the
existing L0-L5 maturity model without allowing the evaluator to alter that model, promote an
artifact, deploy a release, or manufacture trust.

## Decision

1. Add one machine-readable qualification policy that maps every required capability and
   required evidence item in the maturity model to exactly one cumulative gate.
2. Accept only immutable hosted evidence bundles bound to one project, environment, target
   maturity level, artifact digest, creation time, and expiry.
3. Bind every evidence record to an in-bundle payload path and SHA-256 digest.
4. Require an Ed25519 signature from an active configured trust anchor for every record and
   every non-empty bundle manifest.
5. Restrict each trust anchor by separately bound subject identity, validity window, verifier
   role, provider, and HTTPS source host.
6. Require the verifier subject identity to be independent from the evidence producer.
7. Verify record and bundle content digests, signatures, payload bytes, project, environment,
   artifact, freshness, expiry, and source trust before evaluating a gate.
8. Evaluate maturity cumulatively from L0. A missing lower-level gate blocks every higher-level
   claim.
9. Treat current failed or revoked evidence as a contradiction that fails the affected gate.
10. Emit an immutable digest-bound qualification report containing every gate result and
    blocker.
11. Keep qualification advisory-only. It cannot modify the canonical current assessment,
    approve or promote an artifact, deploy a release, or exercise production authority.
12. Ship the canonical policy with no trust anchors. Accountable external keys must be added by
    a separately governed project or hosted environment before any hosted qualification can
    pass.
13. Keep evidence collection, remote API access, cloud provisioning, deployment, and secret
    acquisition outside P4.7.
14. Enforce policy-defined record-count and total-byte limits before evaluating bundle records
    or payloads.

## Consequences

- Hosted maturity claims become reproducible, cumulative, cryptographically verifiable, and
  fail closed.
- A forged record, manifest mutation, record deletion, modified or deleted payload, stale or
  expired proof, unknown signer, untrusted source host, project mismatch, artifact mismatch, or
  contradictory result blocks qualification.
- An expired trust anchor, producer/verifier subject collision, oversized manifest, excessive
  record count, or oversized aggregate payload also blocks qualification.
- Elder can distinguish an implemented qualification mechanism from an actually qualified
  hosted factory.
- The canonical Elder assessment remains L1 because no external trust anchors or hosted
  evidence bundle are configured.
- A future project can configure provider-specific trust anchors without changing the universal
  qualification algorithm.

## Rejected Alternatives

- Raise Elder to L2 because the verifier exists. Rejected because a verification mechanism is
  not operational evidence.
- Accept unsigned evidence hashes. Rejected because an untrusted actor can forge both payload
  and hash.
- Let the qualification command update `operational-maturity.json`. Rejected because an
  evaluator cannot self-ratify an operational claim.
- Fetch remote evidence inside the verifier. Rejected because network credentials, API
  authorization, retention, and provider semantics belong in explicit adapters.
- Make one L2 or L3 success bypass lower levels. Rejected because maturity claims are
  cumulative.
