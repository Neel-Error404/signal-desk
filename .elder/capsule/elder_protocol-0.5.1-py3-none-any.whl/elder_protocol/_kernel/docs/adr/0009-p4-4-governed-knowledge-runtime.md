# ADR 0009: P4.4 Governed Knowledge Runtime

## Status

Accepted by operator approval on 2026-08-05.

## Context

Elder defines knowledge-source, context-packet, memory-record, and knowledge-graph contracts,
but P4.3 leaves them as disconnected schemas. Agents still lack a deterministic way to assemble
bounded context, persist graph state, distinguish candidate memory from trusted memory, or prove
who promoted a learned record.

The runtime must remain provider-neutral and locally executable. It must also preserve the
constitutional boundary that retrieval, learning, and memory writes do not grant additional
authority.

## Decision

1. Use a transactional SQLite reference store with explicit foreign-key enforcement, WAL mode,
   full synchronous durability, integrity checks, and an append-only audit table.
2. Persist typed graph nodes and edges with authority, status, source, content digests,
   provenance, and idempotent ingest.
3. Store memory by namespace and type as candidate, trusted, superseded, rejected, or revoked.
4. Permit agent roles to propose candidate memory only.
5. Require an independent `human-owner` approval artifact to promote, reject, supersede, or
   revoke memory.
6. Exclude candidate, expired, revoked, rejected, and superseded memory from default retrieval.
7. Assemble context deterministically by authority, source kind, and identifier. Graph retrieval
   must be query-matched and source-capped; wildcard, empty-term, and wholesale graph injection
   are forbidden.
8. Deduplicate by content digest and record every budget, authority, status, freshness, or
   duplicate exclusion.
9. Fail closed when a required source is missing, stale, unauthorized, or cannot fit the declared
   budget.
10. Emit immutable, digest-bound context packets with embedded source content and provenance.
11. Keep vector retrieval, embeddings, hosted graph services, multi-agent messaging, autonomous
    consolidation, and learning promotion outside P4.4.

## Consequences

- Projects can operate a durable local knowledge runtime without an external service.
- Candidate and trusted memory have enforceable, inspectable lifecycle boundaries.
- Context packets are reproducible evidence rather than opaque prompt construction.
- Graph and memory records can be queried together while preserving source authority.
- A graph can inform context only through bounded query matches, never by wholesale injection.
- SQLite is a reference adapter, not a claim of multi-host production operation.
- Elder remains at maturity L1 until hosted durability, access control, backup/restore,
  encryption, monitoring, and recovery are qualified.

## Rejected Alternatives

- Treat all retrieved text as equal authority.
- Let an agent update trusted memory directly.
- Silently truncate required context.
- Store only embeddings without source text and provenance.
- Bind the protocol kernel to LangGraph, a vector database, or a hosted graph vendor.
- Add agent delegation or checkpoint orchestration in P4.4.

## Verification

- Foundation validation of schemas, policies, ontology, graph, authority, invariant, and design
  hashes.
- Component tests for store integrity, idempotent graph ingest, lifecycle transitions, retrieval,
  expiry, approval separation, and context budgeting.
- Integration evidence from a real Workbench run ingested into the graph and assembled into a
  context packet.
- Workflow verification through the knowledge, memory, and context CLI commands.
- Stress verification for repeated ingest, concurrent writers, namespace isolation, and bounded
  retrieval.
