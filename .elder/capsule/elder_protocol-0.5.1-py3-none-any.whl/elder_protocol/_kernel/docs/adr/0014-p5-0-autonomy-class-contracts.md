# ADR 0014: P5.0 Autonomy-Class Contracts

## Status

Accepted.

## Context

P4.7 can independently verify signed hosted evidence against cumulative maturity gates, but its
reports remain advisory. Elder still needs a deterministic contract for consuming that evidence
without allowing a certification to manufacture maturity, expand project authority, or activate
autonomous execution.

The initial P5 scope must remain narrower than the existing change-class registry. Documentation,
generated outputs, formatting, lint, tests, dependencies, and configuration do not carry the same
risk. A single global autonomy switch would collapse those distinctions and violate the
constitution.

## Decision

1. Define effective autonomy as the minimum of verified hosted maturity, project autonomy
   ceiling, selected autonomy-class maximum, and active autonomy certification level.
2. Resolve effective autonomy to no authority when qualification is invalid, evidence or
   certification is expired, a suspension or revocation applies, a contradiction exists, or the
   incident budget is exhausted.
3. Re-run P4.7 from approved policy, maturity-model, trust-anchor-set, and bundle digests rather
   than trusting an arbitrary qualification report file.
4. Bind consumed qualification to project, environment, artifact, requested level, achieved
   level, evaluation time, earliest evidence expiry, and current contradiction, suspension, and
   revocation checks.
5. Introduce only five initial autonomy subclasses:
   documentation-only corrections, deterministic generated regeneration, semantic-preserving
   formatting, deterministic lint fixes, and add-only tests.
6. Keep dependency and configuration changes outside the initial registry.
7. Require exact path and tool allowlists for every class. Require pinned generators, formatters,
   and linters where applicable.
8. Cap every initial autonomy class at L2 and require zero-incident, zero-rollback budgets.
9. Keep certification issuance, evaluation, suspension, revocation, and renewal as separate
   authority-bearing records.
10. Keep P5.0 contract-only. It cannot activate a certification, issue a runtime authority lease,
    create a pull request, merge, deploy, mutate maturity, or renew automatically.
11. Generate the autonomy policy and class registry into compiled projects and connect them to
    the canonical protocol and project graphs.
12. Defer work-item matching, simulated execution, certification replay, and incident accounting
    workflows to P5.1.

## Consequences

- Elder can represent class-specific autonomy without granting any new operational authority.
- Certifications can consume current hosted maturity but cannot create or reinterpret it.
- The current canonical repository still has no configured qualification trust anchors or active
  certification, so effective operational autonomy remains none and Elder remains L1.
- P5.2 remains blocked until a selected project has a valid L2 hosted qualification and an active
  class certification. P5.3 remains blocked until valid L3 qualification, canary, telemetry, and
  rollback controls exist.

## Alternatives Rejected

- Enable autonomy globally: rejected because risk, reversibility, evidence, and rollback differ by
  change class.
- Trust a copied qualification report: rejected because the report is advisory and can become
  stale or detached from approved policy and trust inputs.
- Include dependency or configuration changes initially: rejected because transitive,
  supply-chain, security, cost, data, and deployment effects are not sufficiently narrow.
- Implement PR or deployment automation in P5.0: rejected because P5.0 is the contract boundary,
  while P4.8 and later P5 stages provide the hosted operational gates.
