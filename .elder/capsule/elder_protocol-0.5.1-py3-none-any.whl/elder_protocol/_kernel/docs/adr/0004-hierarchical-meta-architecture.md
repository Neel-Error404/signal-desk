# ADR 0004: Hierarchical Meta-Architecture And Protocol Graph

## Status

Accepted and human-ratified on 2026-08-05.

## Context

Elder already defined a constitution, capability-pack selection, project
profiles, generated repository contracts, a reference agent harness, and a
local factory substrate. Those surfaces described most of the intended
software-factory organization, but they were not connected through one
canonical hierarchy.

Capability packs were lists of labels rather than complete contracts. The
ontology described possible relationships, but no protocol graph connected
layers, packs, skills, schemas, invariants, authority, and change classes.
Generated `AGENTS.md` files identified rules and skills but did not clearly
separate the Elder factory kernel from project-owned product implementation.

## Decision

1. Elder is ratified as a product-agnostic project-foundation compiler and
   software-factory protocol.
2. The canonical hierarchy is:

   ```text
   universal kernel
   -> capability packs
   -> stack adapters
   -> project implementation
   -> factory operations
   -> assurance and learning
   ```

3. Capability packs define required properties, artifacts, evidence, skills,
   interfaces, and adapter points. They do not prescribe one technology stack.
4. Stack adapters translate pack requirements into framework, language,
   provider, and infrastructure-specific implementation. Adapter contracts are
   the next extension boundary and remain specified rather than operational.
5. `protocol/protocol-graph.json` is generated deterministically from
   machine-readable protocol truth and must match regeneration during
   validation.
6. Generated projects receive a selected project graph and selected
   capability-pack contracts under `.elder/`.
7. Generated `AGENTS.md` is a concise router into the project profile,
   contracts, graph, packs, skills, ownership, and evidence path.
8. Reference projects prove the kernel and selected packs. They are not the
   universal product Elder generates.
9. Selecting a pack remains configuration evidence, not operational evidence.

## Consequences

- Protocol relationships become inspectable and machine-verifiable.
- Missing pack depth is visible through pack status, required artifacts, and
  adapter points instead of being hidden behind broad capability names.
- New products can share the outer governance model while retaining
  project-owned architecture and source code.
- Generated repositories gain a bounded graph for agent navigation without
  loading the entire Elder repository.
- Protocol version `0.3.0` requires existing `0.2.0` profiles to migrate to
  draft and receive owner review.
- Stack-adapter contracts, graph persistence/query, and full specialty-pack
  implementation remain future governed work.

## Alternatives Considered

- Keep capability packs as labels: rejected because selection did not create a
  testable implementation obligation.
- Put every specialty practice directly in the kernel: rejected because it
  would make all projects carry irrelevant context and technology choices.
- Make the reference Workbench the template: rejected because one product
  cannot represent every domain, topology, risk tier, or stack.
- Hand-maintain diagrams without a protocol graph: rejected because diagrams
  would drift from registries and contracts.
