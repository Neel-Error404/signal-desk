# ADR 0012: P4.6 Quarantined Learning Runtime

## Status

Accepted.

## Context

P4.2 can evaluate immutable candidates, P4.4 can govern candidate and trusted memory, and P4.5B
can replay multi-agent lifecycle state. Elder still lacked one bounded workflow that turns trace,
evaluation, telemetry, and outcome evidence into a learning candidate; tests it through
counterfactual replay and shadow observation; and carries an independently approved immutable
candidate to a promoter without allowing the learning system to modify governed state.

## Decision

1. Implement one transactional SQLite reference runtime for quarantined learning.
2. Copy candidate artifact bytes into the store and bind the candidate record to their SHA-256
   digest, target reference, source evidence, creator, expiry, and content digest.
3. Represent replay and shadow results as side-effect-free observation records over immutable
   input, baseline-output, and candidate-output digests.
4. Require the configured minimum case count for counterfactual replay before accepting shadow
   observations.
5. Derive an advisory evaluation deterministically from all bound observations. The evaluator
   must differ from the candidate creator and every observation executor.
6. Reject qualification when critical regressions or worse cases exceed policy, and require at
   least one better case plus the configured replay and shadow coverage.
7. Bind the runtime store to one validated project profile and resolved authority snapshot.
   Candidate creators, observation executors, evaluators, approvers, and promoters must match
   their project role binding and permitted action.
8. Require kind-specific accountable human roles before promotion. Approvers must differ from
   the creator and evaluator.
9. Require a separate promoter identity. The promoter cannot be the creator, evaluator, or an
   approver.
10. Emit immutable promotion and rollback packets with `applies_target_mutation: false`.
11. Keep application of memory, skill, policy, evaluator, architecture, and production changes
    in their existing owner-controlled workflows.
12. Verify persisted row digests, candidate artifact bytes, append-only event chains, record
    counts, and reconstructed candidate state.
13. Keep hosted shadow traffic, live model or tool execution, external identity authentication,
    target-specific application adapters, production learning, and self-ratifying policy outside
    the local reference scope.

## Consequences

- Elder can inspect and replay one complete local candidate-to-promotion-packet lifecycle.
- Candidate improvements must survive replay, shadow evidence, independent evaluation, human
  approval, and promoter separation.
- Learning remains quarantined and cannot directly alter trusted or production state.
- The local runtime does not raise Elder above the existing evidence-bound L1 maturity claim.

## Alternatives Rejected

- Let the learning agent write trusted state directly: rejected because it violates INV-006 and
  collapses execution, evaluation, approval, and promotion authority.
- Treat a passing evaluation as approval: rejected because evaluators remain advisory-only.
- Let promotion apply arbitrary target mutations: rejected because target-specific authority and
  rollback semantics differ for memory, skills, policy, evaluators, architecture, and production.
- Start with hosted shadow traffic: rejected because external identity, isolation, retention,
  privacy, traffic routing, and production consequence controls are not yet operational.
