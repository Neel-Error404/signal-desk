# ADR 0010: P4.5A Multi-Agent Entry Gate

## Status

Accepted.

## Context

P4.4 established governed knowledge, memory, and context assembly. Multi-agent execution still
lacked canonical project identities, resolved obligations, bounded delegation, parent-child run
contracts, checkpoints, and deterministic authority constraints. Implementing queues or runtime
orchestration before these contracts would make authority ambiguous.

## Decision

1. Canonicalize human-owner, product-owner, architecture-owner, security-owner, release-owner,
   code-owner, executor, evaluator, and promoter roles.
2. Bind canonical roles to project-scoped human, agent, or service identities.
3. Resolve every selected capability-pack artifact requirement into an inspectable obligation.
4. Require every delegation to narrow parent scope, authority, tools, budget, and deadline.
5. Treat messages and checkpoints as immutable evidence, never direct governed-state mutation.
6. Require every child run to trace to exactly one parent delegation.
7. Fail closed on invalid authority, scope, identity, budget, deadline, expiry, or digest.
8. Prove diversity with two JSON contract fixtures rather than additional products.
9. Specify a stack-adapter contract and retain only the existing Python AST reference adapter.

## Consequences

- P4.5B runtime orchestration has a deterministic entry gate.
- Generated projects can inspect selected obligations and project authority.
- Agent communication remains non-authoritative until an accountable approval record exists.
- Runtime cancellation, queues, brokers, schedulers, hosted checkpoints, and autonomous
  promotion remain unimplemented.

## Alternatives Rejected

- Build a second product first: rejected because product code does not resolve authority ambiguity.
- Implement messaging infrastructure first: rejected because transport cannot define governance.
- Treat tool access as authority: rejected because it permits silent privilege expansion.
