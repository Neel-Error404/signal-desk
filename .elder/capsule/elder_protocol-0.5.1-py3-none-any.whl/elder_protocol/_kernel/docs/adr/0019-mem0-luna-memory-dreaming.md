# ADR 0019: Mem0 OSS And Azure Luna Memory Dreaming

**Status:** Accepted
**Date:** 2026-08-07

## Context

Elder already owns governed memory, learning candidates, approval, replay, and promotion
contracts. The previous repository-dreaming adapter stopped at an unexecuted external-provider
boundary. The repository needed operational semantic recall and candidate generation without
allowing an external memory library or model to become an authority source.

## Decision

1. Elder SQLite remains the memory authority of record.
2. Mem0 OSS is used for candidate extraction and semantic recall.
3. Local Qdrant persists Mem0 vectors; no Mem0 hosted API is used.
4. Azure GPT-4.1 extracts candidate memories.
5. Azure `text-embedding-ada-002` creates 1,536-dimensional embeddings.
6. Azure `gpt-5.6-luna` performs routine and escalated repository dreaming.
7. Routine reasoning is medium and escalated reasoning is high.
8. Mem0 telemetry is disabled.
9. Provider output can enter Elder only as an expiring memory candidate or learning candidate.
10. Existing independent approval and non-mutating promotion rules remain unchanged.

## Consequences

- The memory and dreaming path is operational without a Mem0 API key, WSL, Docker, or an
  external agent harness.
- Azure access is an explicit bounded runtime dependency.
- Semantic-index mutation is not equivalent to trusted-memory mutation.
- Core Elder installation remains lightweight; the runtime is installed with the `memory` extra.
- Hosted durability, backup, multi-tenant isolation, and autonomous trusted promotion remain
  outside this release.
