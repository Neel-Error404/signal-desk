# ADR 0022: Institutional Factory Maturity Standard

## Status

Accepted by explicit human-owner instruction on 2026-08-14.

## Context

Elder already defines cumulative L0 through L5 operational maturity, but the
short L2 and L3 claims do not fully distinguish hosted pull-request delivery
from bounded production operation. Roadmap task counts also risk being read as
whole-factory readiness even when hosted execution, production observation, or
rollback remain unverified.

The factory needs one stable institutional standard that agents, owners,
qualification workflows, and the protocol graph can retrieve without
reinterpreting conversational guidance. The standard must preserve the
separation between maturity, project ceilings, change-class ceilings, and
active certification.

## Decision

1. Ratify `elder-factory-maturity-standard` version `1.0.0` as the canonical
   institutional maturity benchmark.
2. Keep the current canonical assessment at L1. Defining a benchmark does not
   provide evidence that the benchmark has been achieved.
3. Resolve whole-factory maturity as the minimum verified level across eight
   mandatory dimensions:
   product intake and planning; worker execution and isolation; security and
   supply-chain integrity; testing, evidence, and evaluation; delivery and
   production authority; reliability, recovery, and incidents; owner
   visibility, outcomes, and economics; and learning and long-term quality.
4. Prohibit average-based promotion. A stronger dimension cannot compensate
   for a weaker mandatory dimension.
5. Define L2 as hosted supervised delivery:
   - authenticated bounded work may reach an exact reviewable pull request;
   - execution uses external identity, scoped secrets, isolated hosted
     workspaces, hosted CI, protected delivery controls, provenance, and
     independent evaluation;
   - humans retain merge, release, deployment, certification renewal, and
     maturity authority.
6. Define L3 as bounded production operation:
   - one explicitly certified reversible low-risk class may move from a
     trusted signal through immutable artifact creation, bounded canary,
     trusted observation, and automatic rollback;
   - humans retain class definition, scope expansion, full rollout, release,
     certification renewal, and maturity authority.
7. Bind institutional L2 promotion to at least 20 real hosted work items over
   at least 30 days, at least 90 percent reaching a reviewable pull request
   without database, runtime-file, or background-terminal inspection, 100
   percent identity/trace/test/provenance coverage, zero authority escapes,
   zero secret exposures, required failure exercises, a current cumulative
   signed L0-L2 bundle, independent review, and human ratification.
8. Bind institutional L3 promotion to at least 20 real bounded canaries over
   at least 30 days, at least three injected rollback exercises, 100 percent
   threshold-breach rollback conformance, zero automatic full rollouts, zero
   authority escapes, required failure exercises, a current cumulative signed
   L0-L3 bundle, exact class certification, independent review, and human
   ratification.
9. Keep P4.7 qualification advisory. Future canonical promotion requires both
   cumulative qualification and institutional benchmark evidence; neither may
   mutate maturity by itself.
10. Generate the standard, dimensions, L2 benchmark, and L3 benchmark into the
    canonical and project protocol graphs.
11. Treat any material change to the standard version, dimensions, authority
    boundaries, quantitative gates, or promotion evidence as a constitutional
    change requiring a new ADR, explicit human approval, updated validation,
    and a standard-version change.
12. Bind the complete machine-readable payload to `ADR-0022`, standard version
    `1.0.0`, and a canonical `content_sha256`. Deterministic validation must
    reject any changed date, dimension text, benchmark text, control,
    exercise, evidence requirement, authority boundary, or metric unless a new
    constitutional version and digest are ratified.

## Consequences

- L2 means that the owner reviews pull requests while humans retain all merge,
  release, and deployment authority.
- L3 means that standing authority may cover one exact reversible class
  through canary and rollback, not arbitrary product development or full
  rollout.
- A sophisticated local implementation can remain L1 when hosted or
  production dimensions are unverified.
- SF-606 must produce an institutional benchmark report in addition to a
  cumulative hosted qualification before requesting canonical L2.
- L4 and L5 remain separately governed future levels requiring operational
  history, independent certification, suspension, delayed quality evidence,
  revocation, and renewal.

## Alternatives Rejected

- Use roadmap completion percentages as maturity: rejected because task counts
  do not measure hosted or production readiness.
- Let qualification reports promote maturity automatically: rejected because
  evidence cannot approve or ratify itself.
- Define L2 as autonomous merge or deployment: rejected because L2 is a
  supervised delivery level.
- Define L3 as general product autonomy: rejected because L3 is restricted to
  one explicitly certified reversible class and bounded production
  consequences.
- Average maturity dimensions: rejected because one missing authority,
  security, rollback, or recovery control can invalidate the whole claim.

## Ratification

The human owner explicitly directed Elder to make the L2 and L3 definitions
stable, canonical, and available through the knowledge graph, and then to use
those definitions as the target for SF-500 and hosted SF-600 through SF-604.
This instruction approves the constitutional definition change. It does not
approve a maturity increase, infrastructure deployment, credential creation,
merge, release, or production execution.
