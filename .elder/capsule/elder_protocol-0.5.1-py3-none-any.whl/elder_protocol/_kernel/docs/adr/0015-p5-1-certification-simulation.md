# ADR 0015: P5.1 Certification Simulation

## Status

Accepted.

## Context

P5.0 defined narrow autonomy classes and qualification-bound certification records, but it did
not determine whether a concrete work item fits a class, replay certification history, account
for incidents, or simulate required controls. Activating operational authority before these
functions are deterministic would allow scope drift and unverifiable certification state.

## Decision

1. Represent every autonomy work item as a digest-bound structured record with exact file
   operations, path classifications, before and after digests, tool identity, optional tool
   digest, rule ids, required checks, semantic-equivalence evidence, and observed effects.
2. Match each work item to exactly one requested autonomy class and one active certification.
   Certification scope is an exact allowlist of normalized concrete paths; wildcard characters
   are prohibited. Every path must fit both the class and certification scope.
3. Bind tools and rule ids to certification tool bindings. Classes that require pinned tools or
   rule allowlists fail closed when those bindings are absent or different.
4. Keep simulation side-effect-free. It evaluates scope, operations, checks, equivalence, and
   forbidden effects but cannot mutate a workspace or create a pull request.
5. Record certification lifecycle events in a contiguous hash chain and replay them
   deterministically. Reject every event later than the requested replay time.
6. Derive certification status, validity, incident count, rollback count, budget exhaustion, and
   required suspension from replay rather than mutable counters.
7. Treat the first incident or rollback as budget exhaustion for the initial zero-tolerance
   classes.
8. Enforce suspension, revocation, renewal, issuance, and activation roles from the active
   autonomy policy rather than a generic accountable-role set.
9. Apply the same class TTL rule in standalone renewal validation and lifecycle replay.
10. Generate the new schemas and operating instructions into compiled projects.

## Consequences

- Class eligibility and certification history can be evaluated before any operational authority
  exists.
- A forged, reordered, duplicated, detached, or future event fails replay.
- Simulation evidence cannot be presented as a changed workspace, pull request, merge,
  deployment, or maturity update.
- P5.2 may consume a passing simulation, but it cannot bypass P4.7 qualification or certification
  validity.

## Alternatives Rejected

- Infer class membership from prose: rejected because classifications would be non-deterministic.
- Trust mutable incident counters: rejected because history and suspension decisions would not
  replay.
- Execute tools during simulation: rejected because P5.1 has no operational mutation authority.
