# ADR 0005: P4 Assurance Constitution

## Status

Accepted by operator instruction on 2026-08-05.

## Context

The P3 hierarchy and local factory substrate established contracts, builds, traces, promotion,
and bounded execution. They did not provide an auditable route from external recommendations to
enforcement, an explicit definition of acceptable judgment and taste, or a truthful maturity
boundary for claims such as software factory, almost lights-out, or autonomous.

The adopted source principles emphasize two related facts:

1. General software factories are not a solved product category. Progress depends heavily on
   non-agent infrastructure such as isolation, repository topology, reproducible builds, CI/CD,
   identity, secrets, and developer experience.
2. Higher code volume cannot substitute for stable architecture, rigorous design intent,
   executable dependency boundaries, execution traces, typed interfaces, and independent review
   of agent behavior.

## Decision

Elder Protocol 0.4.0 adds P4.0 as an assurance constitution.

- Every adopted recommendation maps to architecture layers, controls, required artifacts,
  evidence levels, operational status, and known gaps.
- `factory-operations` and `assurance` are mandatory capability packs for every generated project.
- Authority-bearing components use a typed component operating contract.
- Judgment uses an evidence-cited rubric with deterministic vetoes.
- Operational claims use an L0-L5 maturity model. The current Elder local reference scope is
  capped at L1 until hosted governance, external identity, strong sandboxing, independent
  evaluation, production telemetry, and rollback evidence exist.
- Meta-agent transcript review is an independent probabilistic control. It cannot approve,
  promote, or override deterministic failures.
- Generated projects receive the ledger, rubric, maturity assessment, assurance instructions,
  and component contract instructions.

## Consequences

- Protocol validation now rejects incomplete recommendation mappings and probabilistic-only
  controls.
- Existing 0.3.0 profiles migrate to 0.4.0 as drafts because mandatory pack selection changes.
- The protocol graph grows to include recommendations, controls, maturity levels, and judgment
  dimensions.
- P4.0 is operational only as contract validation, graph generation, compilation, and status
  reporting. Runtime evaluators, transcript review, persistent knowledge, and learning remain
  later phases.

## Alternatives Considered

- Keep the recommendations as narrative documentation. Rejected because agents could not
  deterministically discover coverage or gaps.
- Treat code review by another model as sufficient assurance. Rejected because probabilistic
  review cannot replace deterministic boundaries or accountable authority.
- Claim L2 or L3 maturity from the local P3 substrate. Rejected because hosted controls,
  workload identity, strong isolation, and independent evaluation are not currently evidenced.
