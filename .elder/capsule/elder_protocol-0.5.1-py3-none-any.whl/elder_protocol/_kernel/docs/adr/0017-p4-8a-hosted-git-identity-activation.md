# ADR 0017: P4.8A Hosted Git and Identity Activation

## Status

Accepted by the accountable operator on 2026-08-06.

## Context

P4.7 verifies signed hosted evidence but deliberately shipped without a canonical trust anchor or
hosted evidence bundle. P5.2 consumes that evidence only after re-verification and separately
requires hosted Git governance and external identity. The Elder repository now has a private
GitHub remote and hosted CI, but GitHub rejects branch-protection rules, deployment-branch
restrictions, and native artifact attestations for this user-owned private repository under the
current account plan.

## Decision

1. Pin separate accountable-operator and independent-reviewer Ed25519 public keys in the
   canonical qualification policy.
2. Keep the matching private keys outside GitHub. The operator key remains in the accountable
   operator's machine-local protected secret store, while the independent reviewer retains its
   own isolated key. No repository workflow receives either signing key.
3. Permit the hosted evidence-input job only for a push to `refs/heads/main`. The job obtains a
   short-lived OIDC token with the `elder-protocol` audience and uploads that provider token with
   the reproducible build inputs. Pull-request code cannot access a qualification secret.
4. Require the independent operator verifier to retrieve the exact workflow run, attempt, jobs,
   job identifiers, conclusions, head revision, and artifacts through authenticated GitHub API
   calls. Caller-provided success booleans do not qualify.
5. Build the reference artifact twice from the same source tree and reject digest drift.
6. Verify the OIDC token's RS256 signature against GitHub's published JWKS at its provider event
   time. Bind its immutable repository subject, repository and owner identifiers, commit, ref,
   workflow, run, actor, visibility, and hosted-runner claims into signed provenance. The signed
   bundle retains only the token digest and verified claims.
7. Require an external governance envelope containing an operator-signed approval, an
   operator-signed ordered manual replay, and an independently signed zero-finding review. Every
   statement and signature must bind the exact hosted head revision.
8. Hash every repository source cited by an L0-L2 record from a clean checkout at the exact hosted
   head revision. Generic success booleans are not evidence; each gate consumes provider facts,
   signed governance, concrete contracts, or signed provenance.
9. Issue the cumulative 18-record L0-L2 evidence bundle only after the protocol,
   reference-project, reproducible-artifact, and evidence-input jobs all pass and are bound to the
   same run and head revision.
10. Keep GitHub-native artifact attestation enabled for repositories where GitHub permits it.
   The private repository instead uses the protocol's independently verifiable Ed25519
   provenance until account eligibility changes.
11. Keep branch protection fail-closed and explicitly blocked. Do not represent the planned
   ruleset as active until GitHub accepts it.
12. Keep hosted qualification advisory. A passing L2 report does not mutate the canonical
   maturity assessment and does not activate P5 authority by itself.

## Consequences

- Hosted evidence can be traced to a GitHub OIDC workload identity and verified with repository
  trust material.
- The signing secret is not committed, sent to GitHub, printed, embedded in an artifact, or
  written to the evidence bundle.
- The raw OIDC token remains only in the private provider evidence-input artifact and expires
  before independent issuance. Artifact retention is one day, and the signed bundle contains its
  SHA-256 digest rather than the bearer token.
- Key rotation or qualification renewal requires reviewed operator and reviewer trust-anchor
  lifecycle changes.
- Branch protection, environment deployment restrictions, and GitHub-native stored attestations
  remain externally blocked while the repository stays private on the current plan.
- Human merge, release, maturity ratification, certification activation, and deployment authority
  remain unchanged.
