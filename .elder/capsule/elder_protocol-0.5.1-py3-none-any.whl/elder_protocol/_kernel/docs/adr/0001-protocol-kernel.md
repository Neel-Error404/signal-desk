# ADR 0001: Replace The Static Template With A Protocol Kernel

## Status

Accepted for v0.1 drafting.

## Context

The previous repository copied a trading-derived founder-log structure into every project. It
contained useful evidence and agent-onboarding ideas but did not encode ontology, authority,
invariants, change risk, autonomy, infrastructure, learning, or operational verification. It
also described unexecuted capabilities as production-tested.

## Decision

Build Elder as a protocol compiler:

1. Keep a small human-ratified constitution.
2. Store cross-project governance as versioned machine-readable manifests.
3. Accept a project profile describing actual needs and risk.
4. Resolve capability packs into a project-specific contract.
5. Generate only the protected minimum; let projects own implementation details.
6. Treat every capability as non-operational until executable evidence exists.

## Consequences

- Projects will not receive identical folder trees.
- The compiler becomes a product that requires tests and compatibility policy.
- Human clarification is required before compilation.
- Capability packs can evolve without expanding the mandatory kernel.
- Operational infrastructure remains a separate implementation phase.

## Alternatives Considered

- Continue copying the old template: rejected because it creates false universality and drift.
- Create one extremely large standard repository: rejected because optional concerns become
  mandatory complexity.
- Provide guidance only: rejected because rules without validation remain easy to ignore.
