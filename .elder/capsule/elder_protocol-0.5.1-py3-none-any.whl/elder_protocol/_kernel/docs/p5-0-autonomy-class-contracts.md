# P5.0 Autonomy-Class Contracts

## Purpose

P5.0 defines how Elder may reason about bounded autonomy without activating it. It introduces
class-specific contracts, pinned hosted-qualification consumption, incident budgets, suspension,
revocation, renewal, and a deterministic effective-autonomy calculation.

## Core Calculation

```text
if qualification invalid
or certification expired
or suspension active
or revocation active
or contradiction present
or incident budget exhausted:
    effective autonomy = none
else:
    effective autonomy =
        min(
            verified hosted maturity,
            project autonomy ceiling,
            selected autonomy-class maximum,
            active certification level
        )
```

A certification can consume verified maturity. It cannot create, update, or reinterpret maturity.

## Qualification Consumption

P5.0 does not trust an arbitrary P4.7 report file. It re-runs qualification from:

- an approved qualification-policy digest;
- an approved maturity-model digest;
- an approved trust-anchor-set digest;
- the immutable hosted evidence bundle;
- current project, environment, artifact, and requested-level bindings;
- current contradiction, suspension, and revocation checks.

The resulting qualification-consumption record expires at the earliest bundle or evidence-record
expiry.

## Initial Classes

| Class | Boundary |
|---|---|
| Documentation-only correction | Non-executable, non-governed, non-generated project documentation |
| Deterministic generated regeneration | Exact generated output allowlist, pinned generator, unchanged inputs |
| Semantic-preserving formatting | Pinned formatter plus language-specific semantic-equivalence adapter |
| Deterministic lint fix | Pinned linter, approved deterministic rules, semantic-equivalence adapter |
| Add-only tests | New test files only; no production, fixture, snapshot, config, skip, assertion, or baseline changes |

Dependencies and configuration are explicitly excluded.

## P5.0 Authority

P5.0 cannot:

- activate a certification;
- issue a runtime authority lease;
- create or submit a pull request;
- merge;
- deploy or execute a canary;
- mutate operational maturity;
- renew a certification automatically.

The P5.0 implementation validates and calculates contracts only. P5.1 subsequently added
side-effect-free simulation and deterministic certification replay, and P5.2 added a
qualification-gated supervised pull-request mechanism. Neither later phase grants merge,
deployment, maturity-mutation, or automatic-renewal authority.
