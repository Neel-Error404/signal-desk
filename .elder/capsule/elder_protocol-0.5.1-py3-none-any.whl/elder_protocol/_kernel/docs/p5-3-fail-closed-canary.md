# P5.3 Fail-Closed Canary Execution

## Purpose

P5.3 defines one narrow production operation: start an L3-qualified canary, observe it through
trusted telemetry, and automatically require rollback on a declared breach. It does not grant
promotion or full-rollout authority.

## Authority Chain

Canary lease issuance reuses and reconstructs the P5 authority chain:

1. repository-owned canonical project authority;
2. current independently signed governance-source evidence;
3. signed hosted evidence re-evaluated cumulatively through L3;
4. an active L3 certification and deterministic lifecycle replay;
5. current hard-stop and incident-budget checks;
6. exact work-item match and side-effect-free work simulation;
7. a passing side-effect-free canary-plan simulation;
8. a separate independently signed canary-authority statement bound to the exact plan, target,
   rollback artifact, traffic, timing, health, and rollback contract.

The lease expires within 15 minutes and permits only `canary:start`, `canary:observe`, and
`canary:rollback`.

The canonical `elder-initial-autonomy-classes-v1` registry remains exactly five L2 classes. A
project that later earns P5.3 authority must use a separately governed
`elder-project-autonomy-classes-v1` registry with an L3-capable class whose parent change class
also permits L3 and whose `allowed_consequences` explicitly includes `canary`.

## Provider Boundary

The protocol owns the immutable plan, lease, provider evidence, execution packet, accepted
response, observation, and observation-report contracts. A project-owned adapter implements:

```python
class CanaryProvider(Protocol):
    def start_canary(self, packet: dict[str, Any]) -> dict[str, Any]:
        ...

    def rollback_canary(self, packet: dict[str, Any]) -> dict[str, Any]:
        ...
```

Before calling the adapter, Elder reconstructs the lease and packet, re-verifies the signed
qualification bundle, replays the current certification events, recalculates the current
incident-budget, suspension, revocation, match, and simulation state, and validates a fresh
signed authority statement plus a fresh plan-specific canary-authority statement. Provider
evidence must be independently signed and verify external identity, secret brokering, a separate
promotion gate, central telemetry, rollback readiness, immutable artifacts, and a provider-
reserved deployment ID known before side effects.

Every execution packet has an explicit execution ID and is atomically claimed in the
runtime-owned canonical SQLite store before provider invocation. The execution caller cannot
select or substitute that store. A packet or execution ID can be consumed only once, and the
same signed plan cannot be repackaged under a second execution ID, including after a provider
returns an invalid response.

The claimed packet remains recoverable before an accepted response exists. Before provider
invocation, Elder schedules the bounded start-response timeout. If the provider performs a side
effect and then raises, returns malformed data, hangs, or the process exits, Elder uses the
reserved deployment ID to issue idempotent `start-uncertain` rollback. Invalid responses trigger
recovery immediately; the in-process watchdog and restart sweep recover claimed starts after the
one-minute response timeout.

The accepted response must exactly echo the packet digest, provider, target, environment,
artifact pair, and initial traffic. Its deployment ID and URL must match the trusted target
prefix, and its start time must equal the authorized execution time.

## Observation And Rollback

Observations are fresh independently signed provider telemetry bound to the exact packet and the
accepted deployment response persisted in canonical runtime state. Caller-supplied response
objects cannot redirect rollback authority. Elder evaluates sample count, error rate, p95
latency, success rate, and maximum duration. Maximum duration is measured at evaluation time
rather than the observation timestamp, so delayed telemetry cannot extend a canary.

- Any breach produces an immutable rollback packet, automatically invokes the provider rollback
  adapter, and accepts only a response bound to the exact failed deployment and rollback artifact
  inside the configured rollback window. Every public rollback executor first atomically claims
  the canonical observing record only after the runtime clock enters the exact
  `requested_at`-through-`required_by` interval. The same interval is rechecked before the
  provider is called. Future-dated or replayed rollback executors therefore fail before side
  effects.
- Successful execution durably records the exact packet, accepted response, and hard deadline,
  then schedules the deadline watchdog. Failure to install that watchdog immediately emits a
  `watchdog-unavailable` rollback rather than leaving an active unobserved canary. If no usable
  telemetry has arrived by the hard deadline, the watchdog emits a `telemetry-deadline` rollback
  packet and invokes the same exact rollback adapter without fabricating observation evidence. A
  durable sweep uses the runtime clock and accepts no caller-supplied evaluation time. It
  processes every due record independently after process restart, reports aggregate failures
  only after later due canaries have been handled, and rollback claiming prevents timer/sweep
  duplication. The exact rollback packet is persisted with the claim; stale `rolling-back`
  claims become reclaimable after a shorter claim timeout, reuse the unchanged packet and digest,
  and cannot extend the original rollback authorization window. Expired rollback authority is
  recorded as terminal `rollback-expired` state.
- A healthy result produces `continue-observing`.
- Observations are accepted only while canonical runtime state remains `observing`; rolled-back,
  expired, and other terminal executions reject further observations.
- Every report has `can_promote: false` and `can_full_rollout: false`.

P5.3 deliberately does not implement automatic promotion.

## Canonical State

```powershell
py -m elder_protocol.cli autonomy canary-readiness
```

Canonical readiness remains blocked. The current repository has no valid L3 qualification
consumption, no active L3 certification, no L3-capable canonical class, no verified protected
branch, no external secret broker, no central production telemetry, and no real automatic
rollback evidence. Synthetic L3 fixtures validate mechanics only.
