# SF-605 Multi-Product Boundaries And Recovery Task Packet

**Status:** VERIFIED

**Date:** 2026-08-15

**Base revision:** `65efae29904fb37cf92b08f1679dab2316e043a4`

## Outcome

Ensure that two hosted product factories cannot read or mutate one another
through factory authorization, storage paths, quotas, reusable workers,
caches, audit export, backup, or restore.

## Change Class

High-risk hosted isolation and recovery implementation. The implementation is
provider-neutral and inactive. It changes no protected protocol surface,
canonical maturity, qualification, certification, merge, release, or
deployment authority.

## In Scope

- exact tenant, product, project, principal, and action grants;
- non-caller-controlled product storage partitions and contained paths;
- per-product active-worker, storage, and retained-evidence quotas;
- durable worker generations that require release before cross-product reuse;
- worker-binding-scoped caches that reject stale or cross-product bindings;
- immutable per-product audit chains and product-scoped export;
- digest-bound product backup with scoped component snapshots;
- empty-target restore that rejects another product and converts active
  workers to `recovery-required`;
- restart replay, idempotent identities, operator-error rejection, and
  cross-process serialization;
- a concrete product recovery runbook.

## Out Of Scope

- provisioning tenants, cloud accounts, databases, object stores, or keys;
- encrypting hosted storage or configuring provider-native backup;
- changing existing SF-600 through SF-604 provider adapters;
- current hosted qualification or human L2 ratification, which belongs to
  SF-606;
- Phase 7, L3 certification, canary, merge, release, or deployment.

## Required Proof

1. An exact principal can access only its granted tenant and product.
2. Product storage paths cannot escape or alias another partition.
3. Quota use is transactionally bounded per product.
4. A worker must be released before reuse and receives a new generation.
5. A stale or cross-product worker binding cannot read cached data.
6. Audit exports contain only the requested product and replay their chain.
7. Backup components and state are bound to one tenant, product, and project.
8. Restore rejects a different product and a non-empty target.
9. Restore leaves prior active workers unable to resume without recovery.
10. Concurrent operations cannot overrun quota or create two active bindings.

## Stop Boundary

Close and push SF-605 separately. Do not begin SF-606 until SF-605 has an
exact verified commit.
