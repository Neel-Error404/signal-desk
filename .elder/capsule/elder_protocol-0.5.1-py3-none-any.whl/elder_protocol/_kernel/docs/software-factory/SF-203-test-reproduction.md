# SF-203 Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

**Python:** `C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe`

## Scope

This record covers local durable owner and executor control of one SF-105-bound
worker session through the existing SF-200 adapter and exact SF-202 workspace
binding. It does not cover SF-205 schedules or heartbeats, SF-206 automatic
reconciliation, hosted workers, or the complete Gate C issue-to-evidence flow.

## Baseline

Before implementation, 19 relevant existing Foundation tests passed in
`3.773s`. No pre-existing failure was observed.

## Foundation

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m unittest `
  tests.foundation.test_session_control_contract `
  tests.foundation.test_run_controller -v
```

Final post-review result: `7 passed in 1.286s`.

Coverage includes closed schemas and operation payloads, package exports,
secret rejection, exact payload digests, and unchanged SF-105 contract
behavior.

## Component

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.component.test_session_control -v
```

The seven current Component scenarios are green. Before review, the complete
six-test suite passed in `219.952s`. Review corrections added one scenario and
expanded four existing scenarios. The five affected tests ran in `161.484s`;
one waiting-cancellation assertion exposed a retained waiting reason, and only
that failed test was rerun, passing in `39.313s`.

Coverage includes exact duplicate replay, collision rejection, one-command
leases, start and prompt execution, waiting continuation, checkpoint
observation, ordered events, restart recovery, cancellation priority, bounded
safe retry, and deadline rejection.

## Integration

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.integration.test_session_control -v
```

Final post-review result: `1 passed in 40.564s`.

The test composes the real SF-105 controller, a physical SF-202 worktree and
lease, the SF-201 Codex adapter, and a reopened session controller. A waiting
session continues on the same persisted provider thread after restart.

## Workflow

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.workflow.test_sf203_session_control -v
```

Final post-review result: `1 passed in 44.510s`.

The workflow covers prompt, wait, restart, owner follow-up, adapter checkpoint,
pause, resume, steer, and cancel. It also proves that an adapter checkpoint
does not fabricate the canonical SF-105 Elder checkpoint cursor.

## Stress

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.stress.test_session_control_concurrency -v
```

Final post-review result: `2 passed in 107.965s`.

Both tests use Windows spawned processes. They prove one winner for a control
claim and exact idempotent duplicate submission under process contention.

## Root-Cause Corrections

### Secret fixture did not match the canonical detector

The first Foundation fixture used a generic value that was not secret-shaped.
It now uses the repository's canonical API-key shape and proves rejection.

### Start assertion reconstructed an invalid command

The Component test mutated a completed record into an invalid start request.
The assertion now uses the persisted valid command and checks the intended
idempotency behavior.

### Event drift fixture failed schema validation first

The drift fixture used an invalid URI and never reached the ordering check. It
now remains schema-valid while changing the intended event identity.

### Cancel timing expired at the exact claim boundary

The test timestamp equaled the lease expiry and correctly triggered recovery.
The fixture now places cancellation strictly inside the active lease.

### Windows SQLite inspection retained a file handle

One test connection was not explicitly closed before temporary-directory
cleanup. It now uses `contextlib.closing`.

### Restart assertion assumed a new provider start

The Codex adapter correctly resumed the persisted thread without a second
start. The Integration assertion now verifies the same thread identity and no
new start invocation.

### Review found completion and authority gaps

The first independent review found two blockers and seven required findings:
incomplete adapter acceptance was treated as completion, cursor state could
advance or regress without durable events, completed duplicates could fail
lifecycle validation, checkpoints were not bound to canonical Elder evidence,
adapter responses and event aggregate identity were not fully validated, the
workspace binding was self-asserted, checkpoint observation bypassed response
semantics, and waiting cancellation retained continuation state.

The corrections validate the issued SF-202 binding, canonical Elder checkpoint,
every SF-200 response, event aggregate correlations, and monotonic cursor
updates. Incomplete or duplicate external effects become uncertain, exact
duplicates replay before lifecycle checks, and cancellation clears waiting
state. Targeted re-review found no remaining current-scope `BLOCKER` or
`REQUIRED` finding.

## Sustainable Rerun Inventory

The ordered levels were run once. After a correction, only the failed or
behaviorally invalidated scenario was rerun. Expensive already-green
Integration, Workflow, and Stress tests were not repeated for documentation or
package-only edits.

## Closure Checks

The final closure inventory is:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m elder_protocol.cli validate
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m compileall -q elder_protocol tests scripts
git diff --check
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m build --sdist --wheel --outdir .tmp\sf203-dist
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.integration.test_installed_wheel -v
```

The final installed-wheel result was `1 passed in 159.934s`. Package artifact
hashes are recorded in the SF-203 evidence file.
