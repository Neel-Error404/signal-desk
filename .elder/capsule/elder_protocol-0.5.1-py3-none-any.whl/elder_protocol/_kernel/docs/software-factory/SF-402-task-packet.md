# SF-402 Task Packet

**Status:** VERIFIED

## Outcome

Run and child work cannot exceed current project or parent authority.

## Bounded Scope

- compose the verified SF-401 context packet with the existing P4.5A run chain;
- submit through the unchanged P4.5B local coordinator;
- issue only an assigned-identity, short-lived runtime lease;
- recheck context, lease, identity, expiry, and current runtime state before use;
- propagate cancellation through P4.5B;
- persist accepted and rejected decisions for an owner-facing read model;
- retain canonical maturity at L1.

SF-403 evidence and test-pipeline implementation is outside this task.

## Acceptance

1. A queued work item with current governed context can enter P4.5B only after
   its complete project, parent, delegation, child, and context chain validates.
2. The lease is issued only to the delegation's assigned child identity and
   expires no later than the delegated limit.
3. Scope, tool, budget, deadline, or identity expansion fails before execution.
4. Missing, released, expired, cancelled, or mismatched assigned-child leases
   stop execution.
5. Cancellation propagates to active delegated work and leases.
6. Accepted and rejected decisions survive service restart and expose an
   actionable owner reason without database inspection.
7. Exact concurrent retries converge to one decision and one runtime lease.
8. The raw lease token is never persisted by the integration or runtime stores.

## Failure Conditions

- stale or changed governed context;
- non-queued or changed work item;
- invalid parent-child delegation chain;
- authority, scope, tool, budget, deadline, expiry, or identity expansion;
- missing or mismatched assigned-child lease;
- cancellation or runtime replay inconsistency;
- request identifier collision;
- secret lease material in durable decision records.

## Delivery Rule Trace

```text
finding
-> SF-402 run and child authority acceptance
-> bounded local coordinator and generated project
-> deterministic P4.5A/B validation or focused reproduction
-> smallest Factory Operations integration correction
-> rerun the failed ladder level
-> L1 governed local authority claim only
```
