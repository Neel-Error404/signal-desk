# SF-300 - Owner Inbox And Attention Model

**Status:** VERIFIED

**Date:** 2026-08-13

**Change class:** bounded local owner read model and query contract

**Owner:** factory operations

**Approver:** human repository owner

**Depends on:** verified Gate C commit
`2ecfd6b323cde2fa660b54324aa9dc32a6f1fe5e`

## Outcome

One deterministic owner inbox exposes every current local state that requires
human attention, including work-item decisions, waiting session controls,
uncertain or rejected worker effects, and owner-required or contradictory
recovery evidence.

Each item explains:

- why attention is required;
- what happens if no action is taken;
- how long the condition has been open;
- which exact canonical records support it;
- which owner intents are applicable without granting new authority.

## Non-Goals

- the SF-301 portfolio board or general work-item list;
- the SF-302 work-room timeline, messaging, diff, or artifact UI;
- SF-303 decision mutation, approval identity, expiry, or response handling;
- changing work-item, session, recovery, delegation, or maturity state;
- hosted notification delivery, mobile push, email, or multi-tenant routing;
- treating a suggested action as authorization or execution.

## Required Guarantees

- every eligible source record appears in exactly one open attention item;
- orphan findings without a trustworthy project binding remain visible in the
  unfiltered queue only to a client with an explicit global-route grant;
- duplicate source records coalesce without dropping evidence;
- item identity and ordering are deterministic across restart;
- age is computed from an explicit observation time;
- consequence and allowed actions are state-derived, not model-generated;
- source records remain authoritative and the inbox remains read-only;
- secret-shaped data is rejected;
- unavailable or corrupt required sources fail explicitly rather than
  returning an apparently complete empty inbox.

## Source Boundary

The implementation consumes:

- work items in `waiting`, `validation`, `blocked`, or `failed`;
- session controls in `waiting-owner`, `uncertain`, or `rejected`;
- worker recovery cases in `owner-required` or `contradictory`;
- worker recovery orphan findings in `owner-required` or `contradictory`.

Attention-requiring material changes are represented when they enter one of
these canonical owner-required states. General change history belongs to the
SF-304 audit and replay view. Run-board state, durable approval decisions,
escalations, and costs remain SF-301, SF-303, and SF-305 concerns.

## Failure Conditions

- a waiting or owner-required source record is absent from the inbox;
- two items represent the same project, work item or run, and reason family;
- coalescing loses a source identifier or digest;
- priority changes when source records are read in another order;
- the item suggests authority unavailable to the owner;
- a source database is unavailable and the result is presented as complete;
- a UI or API integration is claimed before its focused proof exists.

## Test Plan

1. Foundation: closed schemas, content digests, enum and secret rejection.
2. Component: source mapping, deterministic severity, age, actions,
   coalescing, and complete evidence coverage.
3. Integration: reopen separate operations, session, and recovery stores and
   reproduce the same inbox.
4. Workflow: expose the inbox through the authenticated operations API.
5. Stress: concurrent reads remain identical while source records are stable.

## Completion Gate

SF-300 closes with the read model, project-authorized owner API
representation, ordered test ladder, focused independent review, package
verification, documentation, and this separate closure commit. SF-301 owns
the visual control-room shell and portfolio board that consume this
representation.
