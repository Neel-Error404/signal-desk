# SF-304 - Audit And Replay View

**Status:** VERIFIED

**Date:** 2026-08-14

**Change class:** read-only owner audit projection

**Owner:** factory operations

**Approver:** human repository owner

**Depends on:** verified SF-303 commit
`4d6f6be1c32bd686d9c1adacfebfe51778b8c68a`

## Outcome

An authenticated owner can inspect one work item's ordered operational history
and answer who acted, what changed, why it changed, which authority and evidence
were recorded, and which links cannot be proven. Rebuilding projections from
the immutable journal reproduces the same journal-backed audit entries.

## In Scope

- one read-only audit snapshot for an exact project and work item;
- journal sequence, chain digest, source, actor, correlation, and causation;
- correlated owner notes, controls, decisions, checkpoints, and artifacts;
- explicit authority and evidence references when present;
- explicit limitations when a required link is absent or outside the journal;
- deterministic snapshot and entry digests;
- owner API and control-room presentation;
- replay verification against the active journal-backed timeline projection.

## Non-Goals

- a second event store or duplicated operational history;
- mutation, approval, authorization, merge, release, or deployment authority;
- invention of actors, causes, authority, or evidence from labels;
- retroactive journal enrichment;
- hosted audit retention, tenant isolation, or external attestations;
- SF-305 metrics, cost, or outcome aggregation.

## Required Guarantees

- the audit view is read-only and project/work-item scoped;
- journal entries preserve their exact ordering and chain digests;
- non-journal records retain source type and immutable content digest;
- missing relationships are reported as limitations, not inferred as facts;
- source changes during assembly cause a bounded retry and then fail closed;
- a journal replay rebuild produces the same journal-backed entry identities
  and digests;
- API authentication and project role checks remain enforced;
- no audit record grants authority or mutates governed state.

## Test Plan

1. Foundation: closed schema, route/binding contracts, and capability truth.
2. Component: correlation, actor/authority/evidence extraction, limitations,
   deterministic digests, tamper rejection, and replay comparison.
3. Integration: authenticated loopback API, restart, projection rebuild, and
   exact work-item scoping.
4. Workflow: owner opens audit view and traces intent through decision,
   execution evidence, and outcome without terminal access.
5. Stress: repeated concurrent reads remain deterministic while source changes
   either converge within the retry bound or fail explicitly.

## Completion Gate

SF-304 closes only after the ordered invalidated ladder, desktop/mobile browser
proof, focused implementation review, package verification, evidence update,
Obsidian milestone update, and a separate commit. SF-305 must begin only from
that clean commit.
