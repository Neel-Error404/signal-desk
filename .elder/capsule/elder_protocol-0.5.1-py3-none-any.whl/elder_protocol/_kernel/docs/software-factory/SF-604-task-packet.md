# SF-604 Hosted Git And Review Controls Task Packet

**Status:** VERIFIED

**Date:** 2026-08-15

**Base revision:** `bd5ef11688cd178c11dc43fd15a42c6caeaddd6b`

## Outcome

Provide a provider-neutral fail-closed boundary that can verify active protected
branch rules, required checks, independently signed review, exact artifact
provenance, and an exact P5.2 pull-request response before retaining a durable
delivery proof.

The proof treats the configured base as a protected branch only when every
required rule is present in a current trusted provider statement.

## Change Class

High-risk hosted-governance implementation. This work does not change protected
protocol surfaces, provider settings, canonical maturity, or autonomy
certification.

## In Scope

- exact repository, provider, protected-base-branch, and trusted-URL policy;
- canonical P4.8A Ed25519 trust anchors with provider and reviewer role
  separation, current validity, and provider-host restrictions;
- signed branch-governance and artifact-provenance statements;
- independently signed zero-finding review bound to the exact PR packet;
- exact required-check names, results, evidence digests, and head revision;
- exact open SF-404/P5.2 delivery record, packet, trusted-source digest, and
  independently signed provider-response binding;
- durable evidence retention, restart replay, duplicate handling, and
  cross-instance serialization;
- explicit rejection of bypass, stale evidence, changed revisions, untrusted
  URLs, and missing checks.

## Out Of Scope

- changing GitHub plans, rulesets, branch protection, merge queues, or account
  settings;
- creating a hosted pull request or claiming current provider activation;
- multi-product isolation, which belongs to SF-605;
- hosted qualification or L2 ratification, which belongs to SF-606;
- merge, release, deployment, maturity mutation, certification activation, or
  any L3 authority.

## Required Proof

1. Exact signed governance proves every configured branch rule and required
   check.
2. Signed provenance binds the P5.2 packet, repository, branches, revisions,
   diff, artifact, checks, provider identity, and source URI.
3. An independent signer approves the exact packet and provenance with no
   Critical, High, or Medium findings.
4. The provider response echoes the exact packet and trusted PR URL.
5. The retained proof survives restart and replays deterministically.
6. An exact duplicate is idempotent; changed evidence for the same packet is a
   conflict.
7. Bypass, stale statement, changed commit, untrusted URL, and missing check
   attempts fail before retention.
8. Concurrent verifier instances cannot create two records for one packet.

## Stop Boundary

Close SF-604 separately. Do not begin SF-605, SF-606 qualification, Phase 7,
or any L3 implementation.
