# SF-404 Test Reproduction

**Status:** VERIFIED on 2026-08-14

## Foundation

```powershell
py -m unittest tests.foundation.test_sf404_supervised_delivery_contract -v
```

## Component

```powershell
py -m unittest tests.component.test_sf404_supervised_delivery -v
```

Proves ready and open delivery, owner rejection, expired qualification,
inactive certification, unprotected branch, changed local proof, unauthorized
owner, provider mismatch, URL mismatch, reconciliation fencing, and durable-row
tamper rejection.

## Integration

```powershell
py -m unittest tests.integration.test_sf404_supervised_delivery -v
```

Proves one packet and accepted response bind SF-402 authority, SF-403
completion, and the existing P5.2 lease and execution.

## Workflow

```powershell
py -m unittest tests.workflow.test_sf404_supervised_delivery -v
```

Proves authorization, packet readiness, owner submission, provider response,
and owner view through service restarts.

## Stress

```powershell
py -m unittest tests.stress.test_sf404_supervised_delivery_concurrency -v
```

Proves concurrent exact owner submissions produce at most one provider call
and an exact retry during the provider call returns the durable in-flight state
without invoking the provider again.

## Additional

```powershell
py -m unittest tests.component.test_p5_1_p5_2_autonomy -v
py -m unittest tests.component.test_sf403_evidence_pipeline -v
py -m unittest tests.foundation.test_operational_architecture -v
py -m compileall -q elder_protocol tests scripts
py -m elder_protocol.cli validate
git diff --check
```

## Verified Results

| Level | Result |
|---|---|
| Foundation | 3 passed |
| Component | 7 passed |
| Integration | 1 passed |
| Workflow | 1 passed |
| Stress | 2 passed |

Additional regressions: operational architecture `8/8`, SF-403 evidence
pipeline `6/6`, and focused P5.2 supervised-delivery behavior `2/2`.
