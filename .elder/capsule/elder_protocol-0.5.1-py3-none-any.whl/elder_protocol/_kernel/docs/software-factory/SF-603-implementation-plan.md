# SF-603 Production Integrations Implementation Plan

**Status:** VERIFIED

1. Define and validate the provider-neutral integration policy, webhook,
   command, provider response, reconciliation page, and audit contracts.
2. Implement a hash-chained local audit ledger with deterministic replay.
3. Implement live SF-601 credential verification for inbound signing and
   outbound provider authentication.
4. Implement signed webhook intake and exact source-event deduplication.
5. Implement outbound command idempotency, explicit rate-limit handling,
   bounded retries, and dead letters.
6. Implement one-page cursor reconciliation and external-record drift
   quarantine.
7. Implement explicit dead-letter replay and cross-manager operation fencing.
8. Verify Foundation, Component, Integration, Workflow, then Stress.
9. Complete focused correctness review, package build, installed-wheel proof,
   evidence, roadmap, README, and Obsidian updates.
10. Commit and push SF-603 separately, then begin SF-604.
