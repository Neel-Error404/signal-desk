# SF-601 Task Packet

**Status:** VERIFIED

## Outcome

Factory Operations has an inactive provider-neutral boundary for verified
external workload identity and exact scoped access to short-lived brokered
credentials.

## Bounded Scope

- exact RS256 OIDC/JWKS issuer, audience, subject, project, and workload
  verification;
- digest-pinned JWKS and policy inputs;
- token lifetime, policy lifetime, revocation, and exact subject binding;
- opaque versioned broker resource references;
- exact project, broker, resource, version, action, and TTL grants;
- short-lived credential leases whose bytes are excluded from representation
  and audit;
- caller-supplied request identities that are timestamp-independent, durable,
  and single-use before provider invocation;
- explicit rotation and revocation;
- intent and terminal audit records that make uncertain external effects block
  restart and further broker mutation;
- secret-free hash-chained audit records;
- provider adapters injected behind one narrow contract.

SF-602 through SF-606 are outside this task. SF-601 does not provision an
identity provider or vault, inject credentials into workspaces, add production
integrations, activate hosted Git rules, qualify Gate G, or grant autonomy.

## Acceptance

1. Wrong issuer, key, audience, subject, project, workload, or timing fails
   closed.
2. Raw workload tokens are never returned or persisted.
3. Broker access requires one exact verified project and workload grant.
4. Wildcard projects, subjects, resources, versions, and grants are rejected.
5. A brokered credential cannot outlive its workload token or grant TTL.
6. Secret bytes are returned only in a redacted lease object and never enter
   audit records.
7. Rotation advances the resource version and revokes prior active leases.
8. Revocation is exact-workload and exact-lease bound.
9. Broker outage cannot be represented as a successful issue, rotation, or
   revocation.
10. Audit replay detects changed payloads or broken chain continuity.
11. A request identity cannot execute twice with a changed timestamp.
12. Rotation atomically advances one resource and revokes the exact active
    lease set, including leases issued to other workloads in the same project.

## Authority And Maturity

Verified authentication and scoped credential access do not create Elder
authority. The adapter is inactive and no external resource is configured.

Canonical Elder maturity remains L1.
