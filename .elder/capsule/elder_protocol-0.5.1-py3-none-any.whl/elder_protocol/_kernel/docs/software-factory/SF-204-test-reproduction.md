# SF-204 Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

**Python:** `C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe`

## Scope

This record covers the optional Prime Agent adapter, its unchanged SF-200
contract, provider-specific restart and journal behavior, refinement
isolation, package visibility, and the shared receipt race exposed by the
concurrency proof.

## Ordered Results

### Foundation

Initial focused run:

```powershell
& $python -m unittest tests.foundation.test_prime_worker_contract -v
```

Result: 4 tests passed.

After the final refinement-policy correction, the same invalidated level was
rerun: 4 tests passed in 0.038 seconds.

The shared fake/Codex/Prime contract regression set also passed:

```text
14 tests passed in 1.007 seconds
```

### Component

Initial focused run failed because the new test fixture called a nonexistent
scenario helper. The fixture was corrected without changing runtime behavior,
then 5 tests passed.

After refinement-event extraction was added, 6 tests passed in 7.372 seconds.
Final review then found that Prime's `serializedRefine` flag enables rather
than disables refinement and that auto-refine defaults on. The runtime now
forces dedicated-agent `autoRefine.enabled = false`, rejects a conflicting
project override before dispatch, and sends `serializedRefine = false`.

The invalidated component level was rerun:

```powershell
& $python -m unittest tests.component.test_prime_worker_adapter -v
```

Result: 7 tests passed in 8.107 seconds.

The earlier shared fake/Codex/Prime component regression set passed:

```text
20 tests passed in 54.767 seconds
```

### Integration

```text
tests.integration.test_prime_worker_adapter
2 tests passed in 11.521 seconds

tests.integration.test_prime_daemon_bridge
tests.integration.test_prime_worker_adapter
3 tests passed in 11.687 seconds
```

The bridge proof used a real Node process and Windows named pipe. It verified
the exact JSONL envelope and stable client/command identity. The earlier
shared worker recovery regression set passed 6 tests in 55.406 seconds.

The final refinement-policy correction did not change the bridge, SF-200
mapping, adapter recovery, or integration fixtures, so this level was not
rerun.

### Workflow

The first run exposed only a test report-shape assumption. After the test used
the explicit collect-evidence operation, the workflow passed. The final
focused result was:

```text
1 test passed in 10.586 seconds
```

The combined SF-200 and SF-204 workflow regression set passed 2 tests in
28.330 seconds. The final refinement-policy correction affected concrete
Prime session configuration only; the deterministic end-to-end workflow was
not invalidated and was not repeated.

### Stress

The initial concurrent duplicate-command proof exposed a real shared adapter
race:

```text
sqlite3.IntegrityError: UNIQUE constraint failed: receipts.identity
```

Root cause: simultaneous adapters could both observe an absent receipt before
one committed the unique identity. The shared worker base now serializes one
adapter instance and performs a bounded retry when another process or instance
wins receipt acceptance.

The same stress level then passed:

```text
1 test passed in 7.790 seconds
```

No later change touched receipt acceptance or the deterministic concurrency
runtime, so Stress was not repeated.

## Package And Static Checks

- Python compilation: passed.
- Node `--check` for `prime_daemon_bridge.mjs`: passed.
- Package build: wheel and source archive produced.
- Fresh `pip --target` install: passed.
- Import from the isolated install target: passed.
- Installed `prime_daemon_bridge.mjs` presence: passed.
- `git diff --check`: passed, with only repository line-ending warnings.
- `python -m elder_protocol.cli validate`: passed.

## Deliberate Limits

Prime dependencies and credentials were not installed for this task. No live
model request is claimed. The concrete transport was exercised against a
test-owned Node named-pipe server; the adapter behavior, pinned source
contract, deterministic provider runtime, recovery, and package boundary are
the verified scope.
