# SF-200 Worker Adapter Conformance Suite Design

**Status:** VERIFIED

**Design date:** 2026-08-13

**Implementation branch:** `work/sf-107-factory-api-health`

**Base revision:** `03d8a2e9152118e0ee9fb943e3f0ebb5c064b603`

**Activation:** `.tmp/session-activation-sf200.json`

**Change class:** `internal-code`

## Outcome

SF-200 defines one provider-neutral Python adapter protocol, a deterministic fake worker, and a
reusable conformance runner for the exact ratified SF-003 worker operations:

```text
prepare
start
send
observe
checkpoint
cancel
recover
collect-evidence
```

No Codex, Prime, or model-provider process is invoked.

## Ownership Boundary

The factory owns work-item, run, worker-session, workspace, command, authority, correlation,
causation, idempotency, and canonical event identity.

The adapter may persist only private receipts, private effect markers, provider observations,
cursor state, checkpoint observations, terminal provider disposition, and evidence references.
Those records prove adapter behavior but do not schedule work, grant authority, issue session
generations, append canonical journal facts, or mutate canonical lifecycle state.

Every response remains `source_of_truth: adapter-observation`.

## Interface

`WorkerAdapter` exposes:

- `capabilities()` for validated implementation metadata;
- `execute(request)` for dispatch through the eight SF-003 operations;
- `record_factory_projection(source_event, projection)` as a host callback, not a ninth adapter
  operation. It accepts only a validated non-authoritative projection bound to an already
  canonical factory journal event.

The implementation may also expose operation-named methods for direct testing. Capability
discovery cannot add operations or authority.

## Capability Manifest

The manifest contains:

- adapter identifier and implementation version;
- `contract_id: worker-adapter`;
- a unique subset of the ratified operation names;
- supported `send` command types from `worker.prompt`, `worker.follow-up`, and `worker.steer`;
- `source_of_truth: adapter-observation`;
- `canonical_write_authority: none`.

Unknown operations, unknown command types, duplicate declarations, authority claims, and
inconsistent `send` metadata fail before provider effect.

A partial manifest is valid capability metadata but is not SF-200 conformant. The complete
conformance runner requires all eight operations and all three `send` command types.

## SF-105 Identity Binding

The existing SF-003 envelope remains unchanged.

- `request.run_id` is the factory-owned run ID.
- `request.session_id` is the factory-owned SF-105 worker-session ID.
- `elder.factory/session-generation` in request extensions carries the positive factory-issued
  session generation.
- `elder.factory/workspace-id` carries the pre-bound workspace reference.
- `elder.factory/authority-ref` repeats the pre-validated SF-105 authority reference.
- `elder.factory/context-sha256` repeats the pre-validated SF-105 context digest.
- checkpoint requests additionally carry `elder.factory/checkpoint-id` and
  `elder.factory/checkpoint-sha256`, supplied by the factory from a separately constructed
  canonical Elder checkpoint.
- `prepare.context.content_sha256` carries the exact governed context digest.

SF-200 does not authorize work or validate the Elder delegation chain. It consumes an already
validated SF-105 binding and checks exact reference and digest equality only.

The equality invariants are:

| Value | Envelope or extension | Nested request | Response observation |
|---|---|---|---|
| project | `project_id` | `prepare.work_item.project_id`, command | prepared/session evidence |
| work item | `work_item_id` | `prepare.work_item.id`, command | prepared/evidence |
| run | `run_id` | prepared run, command | prepared/evidence |
| worker session | `session_id` | prepared run, command, session | start/checkpoint/evidence |
| factory session generation | session-generation extension | prepared run, session | start/checkpoint/recover/evidence |
| workspace | workspace extension | prepared run | prepared/evidence |
| authority | authority extension | `prepare.authority.authority_ref`, command | prepared/evidence |
| context | context extension | `prepare.context.content_sha256` | prepared/evidence |
| correlation/causation | envelope | command | projected event and evidence |

Any mismatch fails before effect. `start` acknowledges the same worker-session ID and generation.
Any provider session reference is separate, opaque, and cannot replace factory identity.

## Idempotency

Mutation identity is:

```text
contract_id + operation + project_id + idempotency_key
```

The first accepted mutation stores the full canonical request. A duplicate calls
`validate_idempotent_replay()` before any result is returned. This preserves work item, run,
session, correlation, causation, redaction, extensions, payload mode, and payload digest.

Exact completed duplicates return the original result and original-response digest without
repeating the effect. Changed payload, context, identity, or generation is a typed conflict.

## Fake Worker State

The fake adapter uses one adapter-private SQLite file with:

- immutable request receipts and state;
- one effect marker and effect count per mutation identity;
- durable canonical response bytes when available;
- factory-session observations and opaque provider references;
- raw provider observations that have no canonical event authority;
- ordered live projections supplied by the factory projection-ingress callback;
- checkpoint observations;
- deterministic evidence references.

The store is test-scoped and restartable. It is not a reusable supervisor or canonical
worker-session service.

## Crash Boundaries

The fake adapter can stop at four deterministic points:

1. before durable acceptance;
2. after acceptance before effect;
3. after effect before result;
4. after durable result before response.

Before acceptance proves non-application and permits same-key retry. After possible effect, a
duplicate cannot execute again and returns uncertainty until `recover` reconciles the receipt.
After durable result, a duplicate returns the original result.

## Operations

### Prepare

Validates work item, project, authority reference, context digest, run, session, generation, and
workspace binding. Returns a deterministic prepared-run observation.

### Start

Acknowledges the exact prepared run, factory worker-session ID, and generation. Returns a
separate opaque provider-session reference.

### Send

Validates one canonical command. Prompt, follow-up, and steer are command types under `send`, not
new operations. Unsupported command types fail before effect.

### Observe

`send` records a raw provider observation only. The conformance harness acts as the factory,
creates an authoritative canonical source event, derives the exact live projection, and supplies
both through `record_factory_projection`. The adapter validates that the source is a journal
entry, the projection is non-authoritative, the source event ID and cursor match exactly, and the
factory session generation and projection sequence are current. The adapter cannot create either
canonical event.

The SF-003 cursor generation is the adapter event-stream generation. For this fake adapter it is
deterministically equal to the current factory session generation, but the two remain separate
namespaces: SF-105 owns the session generation and SF-200 only validates the equality for the
current session incarnation. A new SF-105 generation starts a new adapter stream at sequence zero.
Sequences are contiguous within one adapter stream generation.

Projection ingress is replay-safe:

- exact source-event and projection bytes at the same sequence replay without mutation;
- changed source bytes, changed projection bytes, or another event at an occupied sequence fail;
- a gap or out-of-order new sequence fails;
- exact replay after reopening the private store succeeds;
- the source-event digest and projection bytes are both durable.

`observe` returns only these factory-supplied projections. Exact wire outcomes are:

- stale generation or retention: `error.code=stale-cursor`,
  `disposition=stale-cursor`, `retry=refresh-cursor`,
  `mutation_state=not-applicable`, with the refresh cursor at top-level `response.cursor`;
- future generation or sequence: `error.code=invalid-request`,
  `disposition=rejected`, `retry=never`, `mutation_state=not-applicable`, and no result cursor;
- current or available: `disposition=succeeded` with ordered `events` and `next_cursor`.

### Checkpoint

Returns a checkpoint observation bound to worker-session ID and factory session generation. The
factory first constructs and validates a canonical Elder checkpoint, then supplies only its ID and
canonical content digest through the two checkpoint extensions. The adapter echoes those exact
values and separately records `adapter_state_sha256`, calculated from:

```text
worker_session_id
factory_session_generation
provider status
ordered projection snapshot digest
```

The adapter does not construct, validate, approve, or store the canonical Elder checkpoint bytes.
SF-105 acceptance still requires the separately supplied full checkpoint to validate against
`protocol/checkpoint.schema.json` and to match the echoed ID and canonical digest. The adapter
state digest never substitutes for the canonical checkpoint digest.

### Cancel

Prepared or active provider state may be cancelled. The first successful cancellation reports
`status=cancelled`; an exact same-key duplicate returns the original result without another
effect. A pre-dispatch timeout is `not-applied`; an after-effect response loss is uncertain and
must be reconciled. Recovery of uncertain cancellation reports the same terminal cancelled
state.

### Recover

Validates the exact factory session, factory session generation, event-stream ID, and adapter
stream generation, then reconciles every incomplete receipt for that exact project, session, and
generation in deterministic mutation-identity order. Each reported item contains the original
operation, idempotency key, effect identity, outcome, and reconstructed response digest. No effect
is executed twice.

Adapter-local reconciliation is a mandatory precondition to the SF-105 lifecycle recovery
transition:

1. while the canonical session is still detached at generation `N`, the host invokes SF-200
   `recover` with session generation `N` and adapter stream generation `N`;
2. every eligible generation-`N` incomplete receipt is reconciled or recovery fails closed;
3. only then may the host submit the separate SF-105 transition from generation `N` to `N+1`;
4. after that transition, generation-`N` receipts are frozen evidence and cannot accept new
   effects; the generation-`N+1` adapter stream starts at sequence zero.

SF-200 cannot issue or advance a factory session generation. Calling it after SF-105 has already
advanced the generation is an orchestration error and fails closed instead of bypassing the
stale-writer fence.

### Collect Evidence

Returns a deterministic evidence bundle with:

- request identity, request digest, state, effect count, and response digest;
- provider-observation digests;
- factory-projection event digests;
- checkpoint-observation digests;
- worker-session ID, generation, opaque provider reference, and terminal status.

`content_sha256` is the canonical JSON SHA-256 of every bundle field except
`content_sha256` itself. The outer SF-003 response digest independently binds the complete bundle.
The bundle is evidence, not authority.

Collection ordering and deduplication are fixed:

- request receipts are unique by mutation identity and ordered by that identity;
- provider observations are unique and ordered by command ID;
- projection events are unique by session, stream generation, and sequence and ordered by
  sequence;
- checkpoint observations are unique by session, factory session generation, and checkpoint ID
  and ordered by checkpoint ID.

Primary-key conflicts with changed bytes fail before collection. Exact replay therefore produces
the same arrays and bundle digest across adapter restart.

## Response Safety

The conformance boundary reuses the existing request, response, command, event, cursor,
idempotency, digest, redaction, and error validators. It additionally rejects nested worker
results that claim canonical product, work-item, authority, decision, memory, promotion, release,
or deployment writes.

## Completion

SF-200 passes only when the same runner covers all eight operations, the fake worker passes
Foundation through Workflow verification, restart and uncertainty proofs produce one effect,
package verification includes the implementation, documentation states that no real provider
ran, and independent review finds no unresolved current-scope `BLOCKER` or `REQUIRED` issue.
