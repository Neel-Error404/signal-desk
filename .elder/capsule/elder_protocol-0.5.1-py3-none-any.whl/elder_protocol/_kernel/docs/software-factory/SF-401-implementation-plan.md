# SF-401 Governed Context Assembly Implementation Plan

**Status:** VERIFIED

**Date:** 2026-08-14

1. Read SF-400, P4.4 policy, activation, work-item, and P4.5A contracts.
2. Define an internal exact-field submission and immutable binding record.
3. Add an Elder-owned request and packet repository with restart-safe replay.
4. Derive context from the queued work item and validated child-run chain.
5. Call the unchanged SF-400 `assemble-context` operation using a safe
   request reference.
6. Assemble and validate the full packet through P4.4 behind Elder.
7. Revalidate activation, work, run lineage, source bytes, and the authorized
   packet digest before use.
8. Prove failures and restart/concurrency behavior in ordered test levels.
9. Complete focused review, protocol validation, package/install proof,
   roadmap evidence, and the project vault update.

SF-402 authority and delegation lifecycle integration is explicitly excluded.
Canonical Elder maturity remains L1.
