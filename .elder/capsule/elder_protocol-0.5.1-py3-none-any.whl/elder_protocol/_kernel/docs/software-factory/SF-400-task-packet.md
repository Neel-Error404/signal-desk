# SF-400 Task Packet

**Status:** VERIFIED

**Date:** 2026-08-14

## Objective

Implement the concrete local Elder governance boundary so Factory Operations
can request stable, versioned decisions without importing Elder runtime objects
or weakening Elder authority.

## Success

- the ratified `governance-adapter` request and response contracts remain
  unchanged;
- all eight registered governance operations can be dispatched to explicit
  Elder handlers;
- every request is bound to the current protocol digest and the current
  operation-policy digest;
- protocol drift, stale policy, unavailable dependencies, malformed handler
  results, and uncertain learning mutations fail closed;
- duplicate learning mutations return the original durable result without
  repeating the handler effect.

## Failure

- Operations can invoke an unregistered operation or bypass the SF-003
  envelope;
- a digest mismatch reaches an Elder handler;
- a missing or failed dependency is reported as success;
- an invalid handler result crosses the boundary;
- a duplicate or uncertain mutation is executed again;
- the implementation creates authority, raises maturity, or begins SF-401.

## Constraints

- local single-process Python and SQLite only;
- preserve `factory/factory-contracts.json` version `1.0.0`;
- preserve canonical Elder maturity at L1;
- do not modify protected protocol surfaces;
- no context packet persistence, run-start authority gate, evidence completion
  guard, supervised delivery, hosted service, deployment, or tenant isolation.

## Change Class

`internal-code`. The stable public contract is consumed, not changed.

## Authority

The boundary may validate, route, and record contract results. It cannot create
authority or reinterpret Elder decisions. Each handler remains responsible for
the applicable Elder validator, runtime, source store, and accountable role.

## Current State

SF-003 ratified a provider-neutral governance adapter contract, but no concrete
Factory Operations gateway implements it. Elder already exposes local
classification data, context assembly, authority and delegation validation,
evaluation, qualification, autonomy, and learning runtimes.

## Finding Trace

```text
no concrete governance gateway
-> SF-400 requires Operations to call Elder through stable decisions
-> local Factory Operations and Elder runtimes
-> the ratified governance adapter has schemas but no implementation
-> add one digest-bound dispatcher with durable mutation replay
-> focused Foundation, Component, Integration, Workflow, and Stress proof
-> Operations can consume Elder decisions without owning Elder authority
```

## Ordered Proof

1. Foundation: static contract, protocol snapshot, documentation, syntax.
2. Component: all operations, drift, unavailability, invalid results, replay.
3. Integration: Factory request envelopes call existing Elder validators and
   runtimes.
4. Workflow: one ordered local decision sequence uses only boundary calls.
5. Stress: concurrent duplicate mutation and uncertain in-flight replay.

## Outputs

- `elder_protocol/factory_operations/elder_boundary.py`;
- focused tests at each invalidated ladder level;
- SF-400 design, implementation plan, reproduction, and evidence;
- roadmap, phase task catalog, README, and Obsidian state at closure.

## Deferred Owners

- SF-401 owns context request derivation, packet persistence, run binding, and
  refresh.
- SF-402 owns lifecycle authority and delegation gates.
- SF-403 owns completion evidence and ordered-test enforcement.
- SF-404 owns supervised pull-request packet invocation.
