# SF-603 Production Integrations Design

**Status:** VERIFIED

## Composition

```text
signed external webhook
-> exact source policy and current brokered verification key
-> timestamp and HMAC verification
-> provider-specific normalization
-> source-event idempotency and safe durable record

current raw OIDC token
-> SF-601 workload verification
-> live brokered provider credential
-> exact integration command or reconciliation cursor
-> durable intent
-> provider-neutral adapter
-> exact response, rate limit, failure, dead letter, or drift record
```

## Policy Boundary

Each integration policy binds one integration identifier, provider adapter,
kind, project, workload, inbound source identity, signing credential
reference, outbound credential reference, allowed actions, cursor page limit,
attempt budget, retry interval, webhook freshness window, and policy lifetime.

The five supported kinds are `github`, `issue-tracker`, `chat`, `ci`, and
`notification`. The common runtime does not collapse their identities:
provider and integration identifiers remain exact on every call and record.

## Authentication

Inbound requests prove the declared external source through an exact source
identifier, provider event identifier, timestamp, and HMAC-SHA256 signature.
The signed bytes are canonical structured data containing the source, event
identity, timestamp, and request-body digest. The verification bytes must come
from the configured live SF-601 broker credential. Future or stale timestamps
fail. Signature bytes and request bodies are never persisted.

Outbound commands and reconciliation re-verify a current raw workload token.
The verified project and workload must match policy, and the supplied
credential must be the exact live object issued by the configured SF-601
broker for the policy-bound resource and version. This check applies before a
new provider call, durable duplicate return, or dead-letter replay mutation.

## Idempotency And Provider Effects

Webhook identity is `(integration_id, source_event_id)`. An exact duplicate is
a no-op; the same identity with changed body or normalized record digest is a
conflict.

Outbound identity is `(integration_id, command_id)`. The command digest and
provider idempotency key are recorded before invocation. Exact completed
replay returns the durable result without another provider call. Reuse with a
changed command fails closed.

Provider exceptions are discarded before fixed local errors are raised. A
failed call remains safely retryable because every provider invocation uses
the same exact idempotency key and request digest.

## Pagination, Rate Limits, And Reconciliation

One reconciliation call can consume one bounded page. The provider must echo
the requested cursor and exact integration binding. The returned next cursor
must advance to a cursor not previously observed in that integration or
terminate.

Rate limits are explicit terminal observations with a trusted retry time.
Calls before that time fail without provider invocation.

External records contain identifiers, monotonically increasing versions,
content digests, update times, and deletion flags. A higher version can
advance. The same version with a changed digest or deletion state is drift and
is quarantined instead of silently overwriting durable truth.

## Dead Letters And Replay

Every failed command attempt records a safe reason code and retry time. At the
configured attempt limit, the command becomes a durable dead letter.
Reprocessing requires an explicit replay request with a new replay generation;
it never occurs automatically. Exact replay requests are idempotent.

## Audit And Concurrency

The local proof ledger uses contiguous sequence numbers, prior-entry digests,
derived event identities, request identities, and canonical payload digests.
Replay verifies the full chain and reconstructs webhook, command, cursor,
record, rate-limit, and dead-letter state.

Each ledger is permanently bound to one exact policy digest. A manager with a
changed provider or integration generation cannot share that ledger.

A shared audit-path operation fence serializes separate manager instances
around state refresh, provider invocation, and terminal recording. This is a
local contract proof, not a claim of configured hosted infrastructure.

## Non-Claims

No external provider is configured. No real webhook, issue, message, CI run,
notification, branch rule, pull request, review, deployment, hosted
qualification, L2 ratification, or L3 authority is claimed.
