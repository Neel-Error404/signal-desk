# SF-303 - Approvals And Escalations

**Status:** VERIFIED

**Date:** 2026-08-14

**Change class:** governed local owner decision lifecycle

**Owner:** factory operations with Elder authority validation

**Approver:** human repository owner

**Depends on:** verified SF-302 commit
`a6a837f32bd59d7fc529bb6d074fdd26854a97a3`

## Outcome

An authenticated project actor can raise one durable, expiring decision
request over the exact current work-item digest. The accountable owner holding
the request's exact required role can select one declared choice. Elder records
an immutable decision and reconciles its bounded work-item transition without
allowing a stale subject, wrong approver, duplicate response, or expired
request to mutate work.

## In Scope

- approval and escalation decision requests over a work item;
- declared choices with impact and optional bounded transition;
- exact project, work item, run, subject digest, requester, and required-role
  binding;
- immutable approved, rejected, and changes-requested decisions;
- waiting, resolved, cancelled, and expired request states with append-only
  history;
- replayable decision effects for `accept-outcome`, `request-rework`, and
  `cancel`;
- owner API and Work Room presentation.

## Non-Goals

- modification of the canonical authority matrix or protocol approval schema;
- P4.5B delegation escalation replacement;
- session-control, release, deployment, merge, learning, or hosted approvals;
- decision supersession after a downstream transition;
- notifications, email, external approval providers, or multi-tenant access;
- SF-304 audit/replay UI or SF-305 metrics.

## Required Guarantees

- request creators hold a canonical writer role for `DecisionRequest`;
- the required approver role has `approval-decision:approve` authority;
- the deciding identity holds exactly the required role in the current
  project profile;
- the current work-item digest and version match the request subject;
- decision choice and transition mapping are closed and digest-bound;
- one immutable decision resolves one request;
- exact retries reconstruct the same request, decision, and effect;
- a pending effect is safely reconciled after process loss;
- expired, cancelled, resolved, stale, or wrong-project requests fail closed;
- workers, leases, inbox visibility, and UI presence never imply approval.

## Test Plan

1. Foundation: closed schemas, route/binding contracts, authority mapping, and
   capability truth.
2. Component: request lifecycle, wrong approver, expiry, cancellation, stale
   subject, immutable decision, exact replay, and effect reconciliation.
3. Integration: authenticated loopback API, downstream transition, restart,
   and idempotent replay.
4. Workflow: owner raises an outcome approval, reviews impact and evidence,
   decides in the Work Room, and observes the resolved request and resulting
   work-item state.
5. Stress: concurrent duplicate and competing decisions produce one terminal
   decision and one transition effect.

## Completion Gate

SF-303 closes only after the invalidated ordered ladder, desktop/mobile browser
proof, focused implementation review, package verification, evidence update,
Obsidian milestone update, and a separate commit. SF-304 must not begin in the
same stage.
