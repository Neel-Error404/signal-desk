# SF-202 Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

**Runtime:** `codex-cli 0.146.1`

**Python:** `C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe`

## Scope

This record covers the local Git worktree and sandbox lifecycle for SF-105-bound
runs. SF-203 durable session control, SF-205 goals and heartbeats, SF-206 worker
reconciliation, complete Gate C, hosted workspaces, and deployment remain out
of scope.

## Foundation

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.foundation.test_workspace_lifecycle_contract -v
```

Final result: `5 passed in 2.011s`.

Coverage includes package-visible schemas and exports, immutable binding and
policy checks, instruction/secret/cache classification, secretless sandbox
content, and fail-closed Windows reparse metadata errors.

## Component

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.component.test_workspace_lifecycle -v
```

Final complete result: `15 passed in 66.236s`.

Final post-review path and adapter-boundary regression:

```text
3 passed in 1.071s
```

Coverage includes prepare, validation, lease acquisition/renewal/release,
clean binding, inspection, quarantine, release, recovery, dirty source,
trusted-instruction drift, tracked and generated secret paths, nested ignored
secrets, dependency caches, canonical stop fencing, durable quarantine reason,
Windows worktree-root and workspace-leaf junctions, and mandatory SF-202 Codex
sandbox construction.

The existing SF-201 adapter regression remained green after adding the SF-202
construction boundary:

```text
7 passed in 14.627s
```

## Integration

The three real-controller integration scenarios were run individually because
their combined command exceeded the wrapper timeout on this Windows host.
Already-green scenarios were not replayed again.

| Scenario | Result |
|---|---:|
| SF-105 workspace effect, SF-202 sandbox, unchanged SF-200 conformance through SF-201 | `passed in 248.069s` |
| Missing-manifest restart reconstruction from SF-105 plus Git | `passed in 237.684s` |
| Canonical SF-105 transition serializes with SF-202 workspace binding | `passed in 172.871s` |

The serialization test pauses binding while it holds the SF-105
`BEGIN IMMEDIATE` fence and verifies that a concurrent canonical release
transition cannot commit until the physical operation exits.

## Workflow

Deterministic real-controller workflow:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.workflow.test_sf202_workspace_lifecycle -v
```

Result: `1 passed in 185.862s`.

The workflow provisions through SF-105, binds the exact workspace and sandbox
to the SF-201 adapter, writes one bounded result, records dirty-but-safe
inspection evidence, transitions the canonical run/session/workspace to
failure and quarantine, and retains the worktree with no file contents in the
runtime manifest.

Real Codex workflow:

```powershell
$env:ELDER_RUN_LIVE_CODEX = "1"
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.workflow.test_sf202_workspace_lifecycle_live -v
Remove-Item Env:ELDER_RUN_LIVE_CODEX
```

Final result: `1 passed in 93.186s`.

Codex used an SF-202-created worktree through
`CodexWorkerAdapter.for_sf202()`, consumed the exact durable sandbox binding,
created only `RESULT.txt` with `SF-202-LIVE-PASS` plus one newline, was
cancelled, and was then quarantined with a persisted reason digest.

## Stress

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.stress.test_workspace_lifecycle_concurrency -v
```

Final result: `2 passed in 18.770s`.

Both tests use Windows `multiprocessing` spawn, not threads. They prove one
winner for concurrent lease acquisition and non-cross-bound worktree creation
for two runs sharing one repository.

## Root-Cause Corrections

### Instruction bytes differed on Windows

Git blob bytes did not match CRLF-filtered checkout bytes. Instruction
verification now uses `git cat-file --filters --path=...` so the trusted
revision is compared to materialized bytes.

### Git tree identity was mislabeled

The Git tree object ID was placed in a SHA-256 field. SF-202 now stores the
canonical SHA-256 digest of the tree object identifier.

### Ignored directories hid nested unsafe paths

Collapsed `git status --ignored` output could expose only a directory name.
Inspection now uses `git ls-files --others --ignored --exclude-standard -z`
to inventory nested ignored files.

### Canonical stop decisions could race physical operations

Reading SF-105 state before the workspace lock left a stale-status window.
`RunController.locked_get()` now holds the same SQLite write fence used by
canonical mutations for the complete SF-202 operation.

### Quarantine could clear a live worker lease

Unsafe inspection now enters `uncertain` and retains an active lease. Stable
quarantine requires canonical quarantine/release/failure authority and a
terminal worker session before clearing a still-active lease.

### Windows path redirection was incomplete

Authorization now uses lexical paths, checks repository, worktree root,
parents, workspace leaf, changed-path ancestors, symlinks, junctions, and all
Windows reparse flags. Metadata inspection errors fail closed.

### Sandbox evidence was digest-only

The complete secretless sandbox document is now stored in the runtime
manifest. `CodexWorkerAdapter.for_sf202()` requires that exact workspace and
digest-bound sandbox pair and rejects omission.

## Installed Package

The first installed-wheel attempt failed because the verifier tried to import
packaged tests without adding the installed kernel root to `sys.path`.

The second attempt proved that importing the complete Component suite from its
deep `site-packages` path is not a valid Windows package smoke: checkout-relative
schema paths were wrong and test repositories exceeded practical path limits.

The verifier now uses a short external temporary workspace and the installed
kernel `ROOT`. It validates packaged schemas and documents, initializes a real
Git repository, prepares and leases an SF-202 worktree, constructs
`CodexWorkerAdapter.for_sf202()` from the exact sandbox binding, releases the
lease, and removes the clean worktree.

Final result:

```text
1 passed in 190.474s
```

## Closure Checks

The following checks passed after the documentation set was complete:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m elder_protocol.cli validate
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m compileall -q elder_protocol tests scripts
git diff --check
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.integration.test_installed_wheel -v
```

Protocol validation, compilation, and `git diff --check` passed. The final
source/wheel build and artifact hashes are recorded in the SF-202 evidence file.

The default build output could not replace an existing Windows-locked artifact
under `dist\`. The same source built successfully to a fresh ignored output
directory:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m build --sdist --wheel --outdir .tmp\sf202-dist
```

Artifacts:

```text
B9450D7479F0D0215E7707BE4B5AF4086D06E51DB540C64C644BD1BB723872EE  elder_protocol-0.5.1.tar.gz
7DC090984DD642630BF7F3E819E4B6A41B616C8953FEEDBD54C6C0363B0F84EF  elder_protocol-0.5.1-py3-none-any.whl
```
