# SF-606 Hosted L2 Qualification Exercise

**Status:** IMPLEMENTED; QUALIFICATION BLOCKED

**Change class:** hosted qualification and institutional benchmark evaluation

**Owner:** factory operations

**Approver:** human repository owner

**Base revision:** `6962d34c1423f44e064c435f14a79320192f7da2`

## Objective

Evaluate current signed hosted evidence and the ratified institutional L2
benchmark for the exact SF-605 revision. Produce a deterministic diagnostic
report and a complete future authority checklist without granting authority,
declaring ratification readiness, or mutating maturity.

## Success

- a current signed cumulative L0-L2 bundle is valid for the exact revision,
  project, and production environment;
- the observation window is at least 30 days;
- at least 20 real hosted work items are measured from raw work history;
- at least 90 percent reach reviewable pull requests without internal
  inspection;
- identity, trace, ordered-test, and provenance coverage is 100 percent;
- authority escapes and secret exposures are zero;
- all required controls, exercises, and eight mandatory dimensions are
  independently verified at L2;
- no active contradiction exists;
- separately signed independent-review and human-ratification records exist;
- a complete current provider-bound contradiction ledger has no active entry;
- an authority-capable evaluator, implemented as a separate future change,
  can verify every source rather than trusting packet assertions.

## Failure

- a historical bundle is treated as exact-revision evidence;
- roadmap completion or local test volume substitutes for hosted history;
- branch protection or required checks are claimed while GitHub rejects them;
- inactive provider-neutral mechanisms are represented as live controls;
- missing work history is converted into passing percentages;
- the evaluator, agent, or qualification report grants authority;
- canonical maturity changes without separate accountable human promotion.

## Current Result

The exercise is `BLOCKED`. The diagnostic evaluator always preserves the
canonical current level and cannot return a qualified or ratification-ready
result. This is intentional because provider-bound raw work history, a signed
contradiction snapshot, separate independent-review evidence, and separate
human-ratification evidence are not implemented.

The historical signed bundle still replays as an advisory L2 bundle, but it is
bound to
`d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`, not the SF-605 revision. There
are zero qualifying exact-revision hosted work items and zero days of
institutional observation. GitHub returned HTTP 403 for branch protection on
the private repository under the current account plan. The exact report has
42 blockers and digest
`a4682675c810034f16b070c23589cb03a88d6705c5039413e0a4b56e3c231cdf`.

Canonical Elder maturity remains L1. This task does not grant authority.

## Scope

- compose current P4.7 qualification and the ADR-0022 benchmark;
- add one deterministic diagnostic institutional L2 evaluator and CLI command;
- record current GitHub control-plane observations;
- emit a blocked ratification-readiness report;
- do not provision hosted services, create credentials, weaken controls,
  change protected protocol truth, or begin Phase 7.

## Test Order

Foundation -> Component -> Integration -> Workflow -> Stress.

## Stop

Do not begin Phase 7. A future SF-606 rerun must use new exact-revision signed
evidence and real longitudinal hosted work history.
