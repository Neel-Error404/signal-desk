# SF-301 Product Portfolio And Work Board Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Design Position

The portfolio is a read-only composition over existing product and work-item
truth. It does not introduce another lifecycle store.

```text
product registry --------+
work-item ledger ---------+--> deterministic portfolio snapshot
product/work projections -+             |
journal tip --------------+             +--> product switcher and counts
                                         +--> stage board and list
                                         +--> dependency and blocker state
                                         +--> freshness and stale-cursor proof
```

## Authority Boundary

`GET /v1/owner-portfolio` is available only to an authenticated `owner-ui`.
The service receives the exact project grants from the validated auth policy
and cannot accept a broader project set from the browser. An optional project
filter must remain inside those grants.

The control room stores the client id and bearer token only in JavaScript
memory. Refreshing the page requires authentication again. Static assets
contain no factory data or credentials.

## Snapshot Contract

The snapshot contains:

- all authorized product factories and per-stage/per-priority counts;
- one filtered, bounded work-item page;
- exact dependency target status and whether it currently blocks;
- combined current product/work-item projection identity;
- exact journal position and zero-lag freshness;
- a content digest over the complete response.

`depends-on` blocks until the target reaches `completed`. A failed or
cancelled target remains visible as a stronger dependency state. `related-to`
is informative and never blocks. A work item explicitly in `blocked` remains
blocked even without a dependency edge.

## Paging And Live Updates

The cursor binds the filters, page size, ordered last work-item identity,
combined projection digest, and journal position. Any state advance makes the
cursor stale. The API returns the existing stale-cursor response and the
control room restarts at page one.

The browser polls at a bounded interval. A successful response marks the board
current. A delayed or failed poll changes the visible freshness indicator
without hiding the last verified snapshot.

## Presentation Boundary

The first screen is the actual control room:

- product navigation;
- compact operational totals;
- stage board and dense list modes;
- project, stage, priority, dependency, and text filters;
- manual refresh and bounded auto-refresh;
- loading, empty, stale, unauthorized, and unavailable states.

No work-item action, approval, message, diff, or artifact control appears in
SF-301.
