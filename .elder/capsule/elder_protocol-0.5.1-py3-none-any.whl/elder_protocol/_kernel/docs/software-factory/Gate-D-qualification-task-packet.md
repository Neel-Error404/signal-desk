# Gate D - Supervised Local Factory Qualification

**Status:** VERIFIED

**Change class:** bounded local qualification and owner-control-room correction

**Owner:** factory operations

**Approver:** human repository owner

**Dependencies:** SF-300, SF-301, SF-302, SF-303, SF-304, SF-305

**Source revision:** `3e2237428e7df031818730523d3f7a2ba3251fd8`

## Objective

Prove that one authenticated owner can discover a realistic local run that is
waiting for input, understand its objective, state, evidence, and blocker,
submit one valid follow-up, observe the durable effect, restart the operations
API, and reconstruct the same work, decision context, audit, and metrics
without reading SQLite rows, runtime files, or terminal history.

## Success

- required owner attention is visible in the control room with reason,
  consequence, age, evidence count, and allowed intents;
- the portfolio and Work Room expose the same waiting work item and run;
- the Work Room exposes plan, activity, controls, checkpoints, tests, diffs,
  artifacts, approvals, audit reconstruction, and project metrics;
- an authenticated owner submits one exact follow-up against the visible
  `waiting-owner` control;
- the submitted control is visible after refresh and after API restart;
- the restarted API uses a new runtime generation while durable source digests,
  audit reconstruction, and owner metrics remain valid;
- desktop and mobile browser checks report no page, console, API, or overflow
  errors;
- cost and learning impact remain explicitly unavailable;
- canonical Elder maturity remains L1.

## Failure

- attention exists only in JSON and is not visible in the control room;
- the owner must inspect a database, runtime file, or terminal to identify the
  work item, blocker, action, or result;
- the follow-up is not bound to the exact waiting control or current run;
- refresh or restart loses the owner action, evidence, audit, or metrics;
- the proof uses unauthenticated access or bypasses existing SF-203 admission;
- any lower test level is failing;
- the evidence implies SF-400, hosted operation, deployment, or maturity above
  L1.

## Finding Trace

```text
SF-300 attention was available only through the owner-inbox JSON route
-> Gate D requires owner inbox and board in one usable control room
-> local authenticated loopback owner UI
-> control_room/app.js contained no owner-inbox request or rendering
-> add one read-only inbox band backed by the existing route
-> static contract plus composed browser regression
-> owner attention is visible without adding lifecycle or authority behavior
```

Disposition: `BLOCKER` before correction.

## Constraints

- local Windows loopback runtime, SQLite, one project, one run, one owner;
- compose existing production classes and stores;
- no protected protocol-surface changes;
- no hosted services, telemetry infrastructure, billing, learning, tenant
  isolation, merge, release, or deployment;
- no SF-400 implementation;
- no Git write operation without explicit human authorization.

## Authority

The existing local auth policy grants one `owner-ui` client the exact inbox,
portfolio, Work Room, audit, metrics, and Work Room input routes for one
project. The follow-up remains subject to current workspace binding and
SF-203 command admission. Qualification evidence grants no new authority.

## Test Plan

1. Foundation: control-room composition and qualification-document contract.
2. Component: direct composition of the six owner read models over one waiting
   run.
3. Integration: authenticated HTTP reads, follow-up submission, refresh, API
   restart, and durable reconstruction.
4. Workflow: real Chrome desktop and mobile owner journey with same-port API
   process restart.
5. Stress: concurrent post-restart Work Room, audit, and metrics reads remain
   deterministic after one exact owner follow-up.

## Completion Gate

Gate D may be marked `VERIFIED` only after the ordered ladder, browser proof,
focused correctness review, protocol validation, clean package build,
isolated installed-package verification, and documentation updates pass.
Closure remains uncommitted until the human owner authorizes a separate Gate D
commit. SF-400 remains stopped after closure.
