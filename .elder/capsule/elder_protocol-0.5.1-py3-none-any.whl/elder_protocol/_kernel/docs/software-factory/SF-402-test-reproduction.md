# SF-402 Test Reproduction

**Status:** VERIFIED

## Foundation

```powershell
py -m unittest tests.foundation.test_sf402_authority_delegation_contract -v
```

Proves the bounded contract, exports, documentation, L1 claim, and explicit
SF-403 exclusion.

## Component

```powershell
py -m unittest tests.component.test_sf402_authority_delegation -v
```

Proves exact replay, token redaction, all five expansion failures, missing and
expired lease rejection, stale-context owner visibility, restart, and
cancellation persistence.

## Integration

```powershell
py -m unittest tests.integration.test_sf402_authority_delegation -v
```

Proves the SF-401 packet enters P4.5B under the exact assigned-child lease and
the complete runtime journal replays.

## Workflow

```powershell
py -m unittest tests.workflow.test_sf402_authority_delegation -v
```

Proves an owner can inspect authorization after restart, cancel delegated work,
inspect the durable result after another restart, and observe execution stop.

## Stress

```powershell
py -m unittest tests.stress.test_sf402_authority_delegation_concurrency -v
```

Proves 24 concurrent exact starts across 12 workers and variable decision
timestamps converge to one decision and one lease.

## Additional Verification

```powershell
py -m unittest tests.integration.test_p4_5b_runtime -v
py -m unittest tests.foundation.test_operational_architecture -v
py -m compileall -q elder_protocol tests scripts
py -m elder_protocol.cli validate
git diff --check
```

Package and installed-package commands and hashes are recorded in the evidence
file.
