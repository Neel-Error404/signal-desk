# SF-200 Completion And Implementation Directive

**Status:** SPECIFIED

**SF-200 entry:** COMPLETE - local Gate B closure and SF-200 conformance are verified

**Purpose:** Finish the extended SF-107 remainder without production overreach, close local Gate
B truthfully, and then implement SF-200 as a bounded worker-adapter conformance task.

## Copyable Directive Prompt

```text
You are the primary implementation orchestrator for the Elder Protocol software factory.

REPOSITORY

- D:\Balcony\Template\elder-protocol
- Preserve all existing user and agent work.
- Do not stage, commit, push, reset, clean, merge, deploy, or promote without explicit human
  permission.
- Canonical maturity remains L1.

MISSION

Complete the remaining local Gate B work without introducing production-only transport
guarantees. Then implement SF-200, the provider-neutral Worker Adapter Conformance Suite.

The value path is:

truthful local operations kernel
-> executable worker contract
-> real Codex adapter
-> isolated workspace
-> durable session control
-> issue-to-evidence workflow

Do not optimize or harden a later phase before this path reaches it.

MANDATORY SCOPE RULE

Read and obey:

- AGENTS.md
- docs/software-factory/05-task-execution-contract.md
- docs/software-factory/16-phase-proportional-delivery-rule.md

For every review finding, complete:

finding
-> current acceptance clause
-> current environment or threat
-> reproduction or invariant
-> smallest correction
-> same-level regression test
-> truthful resulting claim

Classify each finding as BLOCKER, REQUIRED, DEFERRED, LIMITATION, or SPECULATIVE. Do not edit code
for DEFERRED, LIMITATION, or SPECULATIVE findings.

Trigger a scope reset when:

- two review rounds create new blockers mainly from guarantees introduced by the previous fix;
- a fix introduces a global lock, background service, durable store, protocol revision, or
  cross-process coordinator not required by the task;
- 60 minutes pass without advancing an acceptance clause or test level;
- a full test ladder has passed and the new finding has no completed trace.

STAGE 0 - INITIALIZATION

1. Inspect branch, HEAD, worktree, and existing uncommitted changes.
2. Activate Elder for the exact current task.
3. Read the activation packet and routed skills.
4. Create or update the current task packet.
5. Record pre-existing failures separately.
6. Do not change protected surfaces without the declared constitutional process.

STAGE 1 - FINISH SF-107 PROPORTIONATELY

SF-107's maximum claim is:

- local numeric-loopback HTTP API;
- one active process;
- controlled local clients;
- authenticated and project/role-scoped /v1 access;
- durable idempotent mutation handling;
- restart-safe operations state;
- bounded local event polling;
- honest health, readiness, and degradation;
- no remote, hosted, multi-tenant, or production transport claim.

Perform these steps:

1. Reconcile the current SF-107 implementation and documentation against that claim.
2. Preserve working API, auth, authorization, idempotency, query, mutation, event, runtime,
   health, reconciliation, backup, and installed-package behavior.
3. Retain only transport corrections that satisfy the phase-proportional required trace.
4. Authentication and authorization must occur before scarce long-poll capacity is consumed.
5. Define graceful drain normally: requests admitted before drain may finish; drain blocks new
   admissions. Do not promise that no response byte can cross the drain transition.
6. Treat route/auth configuration as boot-bound for the active process. A configuration change
   requires a controlled restart. Health may report detected on-disk drift without claiming an
   operating-system-wide tamper lock.
7. Use canonical transaction and runtime-generation checks for mutation safety. Do not perform a
   complete journal and all-projection verification inside every response publication.
8. Return each health/readiness route's declared response type when it becomes not ready.
9. Remove, supersede, or mark as deferred any claim requiring byte-level publication locks,
   public-network adversaries, multi-process fairness, arbitrary external tamper exclusion, or
   production drain guarantees.
10. Update the machine-readable transport note only if it remains necessary. It must describe
    the narrowed local contract, not a stronger production contract.
11. Run the ordered test ladder relevant to the final SF-107 delta.
12. Retain exact commands, durations, counts, failures, root causes, and reruns.
13. Obtain one independent review against the narrowed Phase 1 claim. Review does not reopen
    later-phase concerns.
14. Update SF-107 design, evidence, reproduction, dossier status, and Obsidian only after tests
    support closure.
15. Present Gate B as PASS, PARTIAL, FAIL, or BLOCKED.
16. Stop for explicit staging and commit authorization.

Do not begin SF-200 while SF-107 has an unresolved current-scope BLOCKER or REQUIRED finding.

STAGE 2 - START SF-200

Exact outcome:

One executable, provider-neutral conformance suite proves that any worker adapter implements the
eight SF-003 worker operations and preserves factory-owned identity, idempotency, event,
uncertainty, recovery, redaction, capability, and evidence semantics.

SF-200 implements a deterministic fake worker and the reusable conformance suite. It does not
invoke Codex or any model provider.

Required reading:

- factory/factory-contracts.json
- factory/factory-adapter-request.schema.json
- factory/factory-adapter-response.schema.json
- factory/factory-command.schema.json
- factory/factory-event.schema.json
- factory/factory-cursor.schema.json
- docs/software-factory/12-stable-contracts-and-events.md
- docs/software-factory/14-codex-prime-worker-spike.md
- docs/software-factory/evidence/SF-005.md
- docs/software-factory/SF-105-design.md
- docs/software-factory/evidence/SF-105.md
- existing factory_contracts implementation and tests

SF-200 non-goals:

- real Codex execution;
- app-server or codex exec process management;
- a general worker process supervisor;
- workspace creation or cleanup;
- owner or scheduler command queues;
- pause, resume, waiting, detach, reattach, or session-lease control;
- a shared durable worker-session service;
- owner UI;
- full Elder context or authority integration;
- Prime Agent integration;
- hosted identity, secrets, telemetry, or multiple workers;
- changing SF-003 operation names or semantics without a separate contract decision.

STAGE 3 - SF-200 DESIGN

1. Create .tmp/software-factory/SF-200-task-packet.md.
2. Record the eight exact operations:
   prepare, start, send, observe, checkpoint, cancel, recover, collect-evidence.
3. Define one adapter protocol or interface using existing repository patterns.
4. Define a capability manifest for supported operations and optional command capabilities.
   Capability discovery is implementation metadata; it cannot create authority or silently
   change the SF-003 operation set.
5. Define deterministic fake-worker state:
   prepared-run receipt, exact pre-bound SF-105 worker-session identity and generation,
   adapter-private effect receipts, observed event stream, checkpoint observation, terminal
   provider disposition, and evidence references.
6. Define durable mutation identity as:
   contract_id + operation + project_id + idempotency_key.
7. Require `validate_idempotent_replay()` and preserve every SF-003 replay-bound field: work item,
   run, session, correlation, causation, redaction, extensions, payload mode, and payload digest.
8. Define exact duplicate, timeout, rejection, uncertainty, stale-cursor, unsupported-capability,
   payload-drift, context-drift, identity-drift, and generation-drift results.
9. Define provider observations as non-authoritative. The conformance suite must reject any
   adapter that claims canonical product, work-item, authority, decision, memory, promotion,
   release, or deployment writes.
10. Define `start` as acknowledgement or activation of the exact factory-owned SF-105
    `worker_session_id` and generation. A provider session ID remains a separate opaque external
    reference and cannot replace factory identity.
11. Define how send represents prompt, follow-up, and steer command types without inventing new
   adapter operations.
12. Define inspect behavior through existing observe/session/capability results. Do not add a new
    public operation merely to match informal wording.
13. Define crash boundaries required for the fake adapter:
    before durable acceptance, after acceptance before effect, after effect before result, and
    after durable result before response.
14. Keep all persistence adapter-private and test-scoped. It may prove receipt, effect,
    idempotency, observation, and recovery behavior, but it cannot own scheduling, canonical
    session lifecycle, session leases, pause/resume, waiting, or canonical journal append.
15. Obtain design review only for contract contradictions, authority leakage, missing required
    operation behavior, or untestable completion criteria.

STAGE 4 - SF-200 IMPLEMENTATION

Implement the smallest coherent production-quality conformance package:

1. Worker adapter interface.
2. Capability manifest and validation.
3. Deterministic fake worker adapter.
4. Minimal adapter-private receipt and effect ledger sufficient for deterministic restart and
   uncertainty conformance tests.
5. Normalized event observations and cursor handling. The factory remains responsible for
   canonical journal append.
6. Checkpoint creation bound to session generation and content digest.
7. Recovery that validates the exact factory-owned session identity and generation and
   reconciles uncertain adapter effects. SF-200 does not implement session-generation authority.
8. Evidence bundle creation with deterministic references and verdict.
9. Reusable conformance runner that can later execute unchanged against the SF-201 Codex adapter.
10. Explicit unsupported-capability and actionable error behavior.

Use existing canonical validators. Do not duplicate SF-003 schemas or create a parallel event,
command, error, cursor, idempotency, or redaction model.

STAGE 5 - SF-200 REQUIRED TESTS

Foundation:

- the worker operation set is exactly the ratified eight operations;
- request/result field contracts remain unchanged;
- adapter responses remain source_of_truth=adapter-observation;
- capability declarations use known operations and commands;
- unknown operations, provider-specific canonical fields, secret-shaped values, and canonical
  write authority fail closed;
- the fake adapter and conformance package are included in package/install verification.

Component:

- prepare succeeds and validates work item, authority reference, and context digest;
- start acknowledges the exact pre-bound SF-105 worker-session identity and generation;
- a provider session reference remains opaque and cannot replace factory identity;
- send accepts prompt, follow-up, and steer command forms;
- duplicate mutation returns the original result without repeating the effect;
- same idempotency key with changed payload is a conflict;
- table-driven replay tests reject changes to work item, run, session, correlation, causation,
  redaction, extensions, payload mode, payload digest, or generation;
- observe returns ordered normalized events and a valid next cursor;
- stale and future cursors fail with exact dispositions;
- checkpoint binds worker session, generation, and content digest;
- cancel is idempotent and terminal where declared;
- recover reconciles the declared state and generation;
- collect-evidence returns a digest-valid evidence bundle;
- timeout before dispatch proves non-application and permits same-key retry;
- lost response after possible effect becomes uncertain and requires reconciliation;
- unsupported capabilities reject before provider effect.

Integration:

- a new fake-adapter instance recovers the adapter-private receipt/effect ledger;
- accepted state survives process restart;
- any subprocess used for restart proof is deterministic and test-owned, not a reusable worker
  supervisor;
- an uncertain command is reconciled without a second effect;
- canonical events validate and retain correlation, causation, session, generation, and cursor;
- run/session/workspace references agree with the existing SF-105 records;
- normalized observations do not directly mutate canonical factory state.

Workflow:

- prepare -> start -> prompt -> follow-up -> steer -> checkpoint -> observe -> collect evidence;
- repeat with adapter restart between effect and response;
- cancel and recover produce one deterministic terminal history;
- the final evidence links requests, commands, events, checkpoint, session generation, and
  outcome.

Stress is required only if SF-200 introduces concurrent access. If it does:

- synchronized duplicate commands still produce one effect;
- concurrent observe calls preserve monotonic cursors;
- restart and duplicate pressure do not corrupt the local fake journal.

Do not add hosted, network, multi-tenant, real-provider, or production-load tests to SF-200.

STAGE 6 - SF-200 COMPLETION

SF-200 is PASS only when:

1. One reusable conformance runner covers all eight operations.
2. The deterministic fake adapter passes the complete suite.
3. Duplicate commands cannot repeat effects.
4. Uncertain mutations cannot be retried blindly.
5. Recovery works across a fresh adapter instance and required process boundary.
6. Events and cursors validate against SF-003.
7. Capability discovery rejects unsupported work before effect.
8. Evidence is digest-bound and non-authoritative.
9. Package/install verification includes the conformance implementation.
10. Documentation states that no real Codex execution has occurred.
11. No unresolved BLOCKER or REQUIRED finding remains inside SF-200's declared scope.
12. An independent implementation reviewer verifies the completed behavior and the primary
    orchestrator reconciles findings against executable evidence and the declared SF-200 scope.

Record:

- exact changed files;
- test commands, counts, durations, and reruns;
- current worktree and commit state;
- limitations and deferred risks;
- the exact stable inputs delivered to SF-201.

Stop for explicit staging and commit authorization.

NEXT TASK

After the human authorizes and closes SF-200, proceed to SF-201 - Codex Worker Adapter.
SF-201 must run the same conformance suite against real, version-pinned Codex translation.
```

## Expected SF-200 Deliverables

The implementing agent may adjust paths to match the repository, but the ownership split should
remain:

```text
elder_protocol/factory_workers/
  adapter.py
  capabilities.py
  fake_worker.py
  conformance.py

tests/foundation/
  test_worker_adapter_conformance_contract.py

tests/component/
  test_fake_worker_adapter.py
  test_worker_adapter_conformance.py

tests/integration/
  test_worker_adapter_recovery.py

tests/workflow/
  test_sf200_worker_conformance.py

docs/software-factory/
  SF-200-design.md
  SF-200-test-reproduction.md
  evidence/SF-200.md
```

Do not create all paths mechanically if an existing module already owns the behavior. Reuse the
existing factory-contract validators and operations-store patterns.
