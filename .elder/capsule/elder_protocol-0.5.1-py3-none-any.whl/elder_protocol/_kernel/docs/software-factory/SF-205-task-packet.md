# SF-205 - Goals, Schedules, And Heartbeats

**Status:** VERIFIED

**Change class:** bounded local worker-runtime implementation

**Owner:** factory operations

**Approver:** human repository owner

**Dependencies:** SF-105, SF-200, SF-202, SF-203

**Source revision:** `a4538f2cc1ae54c687929eb62bc4f485108b37fe`

## Outcome

One current SF-105 run can hold one durable factory-owned goal and recurring
schedule. Due ticks create exact SF-203 controls only while current Elder
authority, deadline, run state, and continuation budgets permit re-entry.

## Non-Goals

- automatic reconciliation of interrupted worker or provider effects;
- a hosted broker, distributed scheduler, cron-expression parser, or multi-run
  fairness system;
- worker-owned goals, schedules, heartbeats, or authority;
- implicit resumption of owner-waiting or paused work;
- changing SF-105 lifecycle authority or the SF-200 adapter contract;
- owner control-room routes, merge, release, deployment, or maturity changes.

## Required Guarantees

- goal, schedule, tick, heartbeat, usage, and stop reason are durable;
- every goal is bound to the exact current run, session generation, workspace,
  SF-202 binding, Elder delegation, child run, and runtime lease;
- token, elapsed-time, continuation, deadline, and authority limits fail closed;
- one scheduled instant maps to one deterministic tick and one SF-203 control;
- missed ticks are coalesced instead of accumulated;
- paused and owner-waiting work does not receive a continuation;
- an interrupted claimed tick becomes uncertain after its bounded claim lease;
- a known submitted tick waits for an explicit result and is not redispatched;
- uncertain ticks are never replayed blindly.

## Failure Conditions

- a duplicate tick submits another SF-203 control;
- expired authority or an exhausted budget dispatches a continuation;
- paused, waiting, terminal, stale-generation, or rebound work is continued;
- a process interruption after dispatch is treated as not applied;
- a mutable SF-203 record digest is confused with immutable command identity;
- a missed interval produces an unbounded catch-up backlog;
- secrets, provider credentials, or provider-local authority enter the store.

## Phase Proportionality

Current gate: Phase 2 Worker Runtime progressing toward Gate C.

Declared runtime: Windows local loopback, SQLite, one operations process, one
active continuation dispatch, one current SF-105 run, one SF-203 controller.

Deferred to SF-206: automatic inspection and reconciliation of uncertain
worker effects, orphan recovery, and convergence after process failure.

## Test Plan

1. Foundation: schemas, exports, closed records, secret rejection, authority
   snapshot, and documentation.
2. Component: exact duplicate, budgets, deadline, authority expiry, missed tick,
   paused/waiting work, pause/resume, immutable histories, and uncertainty.
3. Integration: SF-105 lineage, SF-202 binding, SF-203 control submission and
   completion, restart reopening, and one provider effect.
4. Workflow: bounded recurring issue continuation through explicit completion.
5. Stress: spawned duplicate due-tick contention and one deterministic control.

## Completion Gate

SF-205 closes only after the ordered focused ladder passes, package installation
is verified, implementation review has no open current-scope blocker, evidence
is recorded, and the stage is committed separately before SF-206 begins.

## Completion

The ordered focused ladder, independent review reconciliation, fresh wheel
installation, installed-schema proof, and closure evidence pass for the
declared local scope. See [design](SF-205-design.md),
[test reproduction](SF-205-test-reproduction.md), and
[evidence](evidence/SF-205.md).
