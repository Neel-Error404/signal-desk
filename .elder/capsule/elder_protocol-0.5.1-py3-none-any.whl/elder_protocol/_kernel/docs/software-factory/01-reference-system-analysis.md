# Reference System Analysis

**Status:** SPECIFIED - source analysis, not architecture ratification

## Evaluation Method

Each reference was inspected for executable mechanisms rather than marketing claims. The analysis
asks:

- What durable state does the system own?
- What causes work to start or resume?
- How are duplicate, uncertain, failed, and concurrent operations handled?
- How can an owner inspect and steer work?
- What can the system learn, and who may promote that learning?
- Which boundaries are enforced in code?

## Elder Protocol

### What Elder Already Provides

- Protocol compiler, project profiles, ontology, invariants, authority matrix, and change classes.
- Digest-bound context assembly with authority, freshness, and budget filters.
- Canonical roles, project identities, delegation contracts, child runs, and checkpoints.
- A transactional local coordinator with leases, action/message journals, cancellation, expiry,
  and deterministic replay.
- Evaluation, telemetry, qualification, autonomy matching, supervised pull-request packets, and
  fail-closed canary contracts.
- A quarantined learning store with immutable candidates, replay, shadow observations,
  independent evaluation, approvals, promotion packets, rollback packets, and replay.

### What Elder Does Not Yet Provide

- A durable product work-item ledger and owner-facing backlog.
- Signal intake, rules, dispatch scheduling, retry queues, dead-letter handling, and worker
  provisioning as one operating loop.
- A provider-neutral worker adapter that starts and resumes Codex or other harnesses.
- A hosted owner control room for discussions, decisions, approvals, run state, and costs.
- Autonomous learning-candidate generation from trajectories and outcomes.
- Target-specific application of approved learning packets.
- Hosted identity, tenant boundaries, durable event infrastructure, and production operations.

### Correct Role

Elder is the governance and learning authority used by the factory. It should not become a wrapper
around every direct coding action. The operations plane invokes Elder at explicit control points:
intake, planning, delegation, context assembly, authority issuance, evidence verification,
qualification, learning evaluation, promotion, and rollback.

## Prime Agent

### Mechanisms Worth Adopting

- Daemon-backed sessions that survive terminal detachment.
- One worker per root session tree, session leases, command journals, crash recovery, and
  reattachment.
- Persistent goals, automatic compaction, heartbeats, schedules, and bounded autonomous
  continuation.
- Agent messaging with daemon-derived identity and constrained relationships.
- A continual harness with typed entries:
  `prompt`, `memory`, `skill`, and `subagent`.
- Local and global scopes, entry versions, before/after snapshots, refinement history, and
  rollback.
- Automatic refinement triggers after trajectories or compaction.
- Interfaces suitable for adaptation: SDK, RPC, event streams, and ACP.

### Learning Strength

Prime Agent closes a gap that Elder intentionally leaves open: it observes a trajectory, asks
whether a reusable lesson exists, and proposes or applies a small change to the harness. This is
the strongest self-learning mechanism among the inspected references because learning is part of
the normal session lifecycle rather than a separate manual retrospective.

### Risks And Limits

- The model-backed review and proposal can directly alter harness state.
- The evidence is primarily the recent trajectory and prompt instruction, not an independently
  verified evaluation.
- Global changes may affect later sessions.
- It does not provide Elder's separation among learner, evaluator, approver, promoter, and target.
- It is a coding-agent runtime, not a product work ledger or factory control plane.
- Its process model is not a security sandbox.
- Bounded harness summaries can make stored entries difficult to retrieve if routing is weak.

### Correct Role

Use Prime Agent in two ways:

1. As a source of worker-runtime patterns and, after a spike, an optional worker adapter.
2. As the design source for an automatic learning-proposal engine.

Do not replace Codex as the primary worker merely to gain these capabilities. Do not allow Prime
Agent refinement to bypass Elder's learning quarantine.

## Mastra Factory

### Mechanisms Worth Adopting

- Canonical work-item storage with exclusive stage, history, revisions, and source references.
- Transition service and default stages such as triage, planning, execution, and review.
- Deferred decisions and pending starts with durable statuses.
- Dispatch leases, renewal, retry/backoff, bounded attempts, and concurrent in-flight work.
- Idempotency keys and causal-depth tracking.
- Server-side session start, source-control workspace binding, and initial kickoff.
- Audit and metrics domains.
- GitHub, Linear, Slack, Postgres, Redis streams, and sandbox composition.
- A working owner-facing factory board and operational UI.

### Risks And Limits

- The package and related dependencies are alpha-stage and can change quickly.
- Its assumptions are TypeScript/Mastra-specific.
- It is not the canonical authority for Elder policy or maturity.
- Its learning model does not match Prime Agent's continual harness.
- A direct fork can create a large maintenance burden before the product boundary is stable.

### Correct Role

Mastra is the strongest reference for the operations plane. Start with a bounded integration
spike comparing:

- use the package directly;
- fork selected modules;
- reimplement the domain contracts behind stable Elder-owned interfaces.

The spike, not preference, decides the path.

## HumanLayer

### Mechanisms Worth Adopting

- Explicit waiting-for-human and running session states.
- Approval requests correlated with tool calls and sessions.
- Human-as-tool and contact-channel semantics.
- Session continuation and parent-child relationships.
- Clear separation between an active stable daemon and a development daemon.

### Limits

- The inspected public daemon is an older architecture.
- Some event delivery is in-memory and lossy under slow subscribers.
- Prime Agent and Mastra provide stronger current runtime and operations mechanisms.

### Correct Role

Adopt the human interaction semantics, not the whole daemon. The factory needs durable approval,
clarification, escalation, and decision records regardless of which worker executes the task.

## Factory.ai

The cloned public repository had no commits, so there was no code to reuse. Product behavior is
still useful as an interaction reference:

- persistent automations;
- visible triggers and instructions;
- run targets and visibility;
- dashboard status;
- pause, resume, run, and fork;
- owner-readable metrics and outcomes.

Treat these as product requirements. Do not claim code reuse.

## Combined Conclusion

No single reference is the desired factory.

| Need | Strongest source |
|---|---|
| Governance, authority, context, qualification | Elder |
| Product work ledger and dispatcher | Mastra Factory |
| Durable worker sessions and long-running continuation | Prime Agent |
| Automatic learning proposal | Prime Agent |
| Independent learning evaluation and promotion authority | Elder |
| Human approval and waiting semantics | HumanLayer |
| Owner-facing automation UX | Factory.ai and Mastra Factory |

The final system should combine these strengths through stable contracts while preserving Elder's
fail-closed boundaries.
