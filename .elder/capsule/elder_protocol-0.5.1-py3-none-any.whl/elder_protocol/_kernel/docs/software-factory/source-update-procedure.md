# Research Source Update Procedure

Use this procedure when adding a source, moving an inspected path, changing a pin, or discovering
new license or package evidence. A source update does not authorize code reuse.

## Preconditions

1. Activate Elder for the exact SF work item.
2. Preserve the current worktree and record branch, HEAD, and uncommitted changes.
3. Confirm the task permits network access before contacting an upstream remote.
4. Stop for owner review when a license, distribution model, package integration, fork, or code
   reuse decision would change.

## Refresh

For an existing local research clone:

```powershell
git -C .tmp/factory-research/<source> status --short --branch
git -C .tmp/factory-research/<source> remote get-url origin
git -C .tmp/factory-research/<source> rev-parse HEAD
git -C .tmp/factory-research/<source> rev-parse --is-shallow-repository
```

When network access is approved, fetch the requested exact revision without changing a canonical
implementation workspace:

```powershell
git -C .tmp/factory-research/<source> fetch --depth 1 origin <commit>
git -C .tmp/factory-research/<source> checkout --detach <commit>
```

Do not record a branch name or mutable tag as the reproducible pin.

## Inspect

1. Verify the commit object, origin URL, clean status, and shallow/full history state.
2. Re-read the root and selected-path license files. Record package-only or path-specific license
   evidence without upgrading it to a repository-wide grant.
3. Re-read package manifests and lockfiles for selected paths.
4. Record exact repository-relative paths and SHA-256 digests for license and package evidence.
5. Mark package metadata as parsed only when the validator can verify its declared name and
   version; use `digest-only` for lockfiles or formats whose metadata is recorded as an explicit
   limitation.
6. Record source availability, code reuse, package integration, independent reimplementation,
   reference use, compatibility,
   approval state, attribution obligations, and limitations separately.
7. Treat an empty repository or missing license as `unknown` or `not-observed`, never permissive.
8. Reopen owner review for copyleft, source-available, proprietary, dual-license, patent,
   trademark, redistribution, or conflicting component terms.

Compute a file digest with:

```powershell
(Get-FileHash -Algorithm SHA256 -LiteralPath <path>).Hash.ToLowerInvariant()
```

## Validate

Run Foundation validation first:

```powershell
.venv\Scripts\python.exe -m elder_protocol.cli validate
.venv\Scripts\python.exe -m unittest discover -s tests/foundation -v
```

These portable checks validate the manifest, bound dossier artifacts, and fail-closed policy
relationships without requiring ignored `.tmp` research clones to exist.

When the local research clones are present, verify their remotes, commits, license files, and
package manifests. This explicit evidence mode also verifies Elder's declared baseline HEAD and
worktree state, clean reference checkouts, parsed package metadata, every inspected-path digest,
and supplemental product-material captures:

```powershell
@'
from pathlib import Path
from elder_protocol.research_sources import validate_research_sources

print(validate_research_sources(
    Path("docs/software-factory/research-sources.json"),
    Path("."),
    verify_checkouts=True,
))
'@ | .venv\Scripts\python.exe -
```

Fix the root cause and rerun the same level before proceeding.

## Reproduce One Pin

Without network access, a local clone may prove that the pinned object can be reproduced from the
preserved research source:

```powershell
git clone --no-hardlinks .tmp/factory-research/<source> .tmp/software-factory/reclone-<source>
git -C .tmp/software-factory/reclone-<source> checkout --detach <commit>
git -C .tmp/software-factory/reclone-<source> rev-parse HEAD
```

The final HEAD must exactly equal the manifest commit. Preserve the command and result in the task
packet.

## Update Evidence

1. Update `research-sources.json`.
2. Update the decision record only when the human owner changes the policy.
3. Update attribution records only for an approved external use.
4. Update bound artifact digests after intentional document changes.
5. Record tests, limitations, approval evidence, and the next dependent task.
6. Do not change maturity, dependency selection, or architecture status from source-refresh
   evidence alone.
