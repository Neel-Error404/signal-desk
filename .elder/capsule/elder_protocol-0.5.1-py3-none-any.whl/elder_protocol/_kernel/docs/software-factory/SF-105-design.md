# SF-105 Run, Session, And Workspace Binding Design

**Status:** VERIFIED

**Implementation:** VERIFIED

**Design date:** 2026-08-11

**Implementation branch:** `work/sf-105-run-session-workspace-binding`

**Activation:** `activation-elder-protocol-1f14e04a02083174`

**Change class:** `internal-code`

## Outcome

SF-105 adds the durable operations-store boundary that turns one exact completed SF-104
`worker.start` pre-binding dispatch into factory-owned run, worker-session, and workspace
identities.

The controller must:

- consume only a completed, non-uncertain SF-104 start dispatch;
- bind the exact Product Factory, work item, work-item revision, queue transition, authority,
  context packet, repository, source revision, worker policy, workspace intent, worker session,
  and execution attempt;
- create deterministic factory identities before any provider or workspace side effect;
- keep initial bindings immutable while lifecycle state remains explicitly mutable;
- reject wrong-repository, stale-revision, wrong-session, stale-generation, and duplicate-start
  drift;
- preserve checkpoint and artifact references without copying Elder checkpoint authority or
  artifact bytes into the operations record;
- retain recovery metadata, cleanup intent, and terminal cleanup state across restart;
- request work-item lifecycle changes only through SF-103;
- persist each accepted or rejected lifecycle command, its exact authority decisions, and its
  deterministic result before returning;
- expose enough validated state for SF-106 journal events and SF-107 APIs without implementing
  either task early.

The maximum truthful claim is a local SQLite run-binding controller with simulated provider and
workspace observations. SF-105 does not prove a real Codex session, physical isolated worktree,
hosted durability, provider-side exactly-once behavior, or canonical maturity above L1.

## Governed Intake

```text
Objective:
  Add restart-safe execution identity and binding state after durable dispatch.

Success:
  Every accepted execution attempt has one exact run, worker session, workspace,
  authority/context/source lineage, checkpoint-reference chain, artifact-reference set,
  recovery state, and cleanup intent.

Failure:
  The controller accepts a changed dispatch, wrong project or repository, stale work-item or Git
  revision, invalid authority/context proof, reused active workspace, stale session generation,
  mutable initial binding, or unconfirmed terminal cleanup.

Constraints:
  Local single-process Python, SQLite WAL/FULL durability, one active worker capacity, existing
  SF-002/SF-003 contracts, delegated executor authority for Phase 1 starts, SF-103-only work-item
  transitions, no network, and no real provider.

Non-goals:
  Codex invocation, Git worktree creation/removal, provider event collection, canonical event
  journal, projections, API, UI, schedules, hosted workers, secrets, and workspace pooling.

Risk:
  High. Incorrect binding creates confused-deputy, repository-escape, stale-writer, and evidence
  attribution failures.

Authority:
  Factory operations owns binding and lifecycle records. Elder remains canonical for authority,
  delegated leases, context, and checkpoints. Workers provide observations only.

Capability packs:
  core, factory-operations, agentic, assurance, data.

Knowledge sources:
  ADR 0021, factory domain/contracts, SF-104 evidence, Elder P4.4/P4.5 contracts, pinned Mastra
  and Prime checkouts.

Open questions:
  None that block the Phase 1 local design. Real workspace and Codex semantics remain explicitly
  deferred to Phase 2.

Next proof gate:
  Foundation contract validation, followed by Component implementation and the ordered full
  ladder.
```

## Ratified Inputs

This design implements, but does not amend:

- ADR 0021 and `factory/operational-architecture.json`;
- the SF-002 `Run`, `WorkerSession`, and `Workspace` entities and lifecycles;
- SF-003 worker `prepare`, `start`, `checkpoint`, `recover`, and error semantics;
- SF-100 Product Factory profile, repository, and worker-policy binding;
- SF-102 current work-item and immutable revision lineage;
- SF-103 as the sole work-item stage transition boundary;
- SF-104 completed `worker.start` dispatch and immutable queue-transition lineage;
- Elder P4.4 context-packet validation;
- Elder P4.5 delegated run, runtime-lease, and checkpoint authority boundaries;
- P3 workspace containment and worktree policy as the future physical workspace substrate.

Pinned behavioral references:

- Mastra Factory commit `d81fe95420e4a001a2850c56b9193106bf400682`;
- Prime Agent commit `b9a4461149419156599d60174dddf15458e2b9ee`.

No source is copied, vendored, imported, or added as a dependency.

## Reference Findings

### Mastra

Adapt these behaviors:

- commit binding state before kickoff or provider messaging;
- replay an exact start into the existing binding;
- scope start idempotency and reject changed replays;
- bind a session to the exact project repository and thread;
- create binding state before requesting a governed stage transition;
- coalesce concurrent materialization for one session/workspace identity;
- separate untrusted checkout content from trusted instruction sources;
- scrub and verify a released workspace before any later reuse.

Do not adapt:

- provider session/thread identifiers as canonical factory identity;
- best-effort cleanup as a correctness guarantee;
- silent continuation after policy or model drift;
- direct worker-owned work-item stage mutation.

### Prime

Adapt these behaviors:

- one durable factory session identity for one execution lineage;
- generation-aware recovery and stale-event rejection;
- persisted session-file/reference lineage rather than process identity;
- recovery snapshots and cursors after process replacement;
- explicit detach, recover, cancel, and lost states.

Do not adapt:

- provider-local active-session IDs as authority;
- same-user process leases as a security boundary;
- provider goals, messages, or refinements as canonical Elder state;
- blind replay after an uncertain mutation.

## Scope Boundary

SF-105 owns:

- start-binding submission and exact replay;
- deterministic run, worker-session, and workspace IDs;
- immutable initial binding lineage;
- mutable run, session, and workspace lifecycle state;
- provider-neutral session generation and recovery metadata;
- logical workspace intent, containment, source revision, and instruction-trust binding;
- active-worker capacity fencing;
- checkpoint references to canonical Elder checkpoints;
- artifact references to immutable artifact or diff evidence;
- cleanup policy, cleanup request, quarantine, release confirmation, and restart recovery;
- status, queries, history, and integrity checks.

SF-105 does not own:

- real Codex `thread/start`, `thread/resume`, turns, steering, or interruption;
- Git clone, checkout, worktree creation, worktree removal, or sandbox pooling;
- canonical delegated lease issuance or checkpoint creation;
- context assembly or storage of complete context source content;
- build, artifact creation, verification, promotion, or rollback;
- direct work-item mutation;
- the SF-106 event journal or projections;
- the SF-107 API or authentication;
- hosted identity, secret brokering, distributed coordination, or multi-tenant isolation.

## Core Architectural Decision

SF-105 is a binding and lifecycle controller, not a worker gateway and not a workspace provider.

The controller records a planned isolated workspace and a prepared worker session. Phase 2 will
perform the external workspace and Codex effects against these exact records. This preserves the
Phase 1 architecture boundary while still proving durable identity, binding, concurrency,
recovery, and cleanup semantics.

The SF-104 dispatch is an accepted request to begin an execution attempt. Its completed delivery
does not create a provider session and does not prove that a workspace exists. The SF-104 record
is therefore a **pre-binding dispatch fact**, not the canonical SF-002 `command.delivered` event:
that canonical transition requires a worker-session ID, which does not exist until SF-105 binds
it. SF-105 consumes the dispatch as causation, creates factory-owned identities, and leaves any
later canonical command delivery to a session-bound worker-gateway operation.

## Start-Binding Contract

Add `factory/operations/run-binding-submission.schema.json`.

The submission contains:

- `version`;
- `dispatch_id` and expected dispatch digest;
- expected work-item ID, current record version, current content digest, revision ID, revision
  entity digest, and revision snapshot digest;
- expected Product Factory ID, profile digest, repository root, and worker-policy digest;
- exact product workspace-policy capsule, its product-owner authorization, and the source P3
  contract plus `git` and `workspace` subset digests;
- full validated Elder context packet, supplied for validation but not copied into the durable
  binding;
- full validated Elder parent run, delegation, assigned child agent run, and active runtime lease;
- exact digests for those four Elder source records;
- source binding:
  - repository root;
  - exact full Git commit ID;
  - trusted instruction mode;
  - trusted instruction revision;
- cleanup policy;
- requested timestamp.

Semantic validation requires:

- SF-104 dispatch status `completed`;
- current SF-104 adapter-delivery status `delivered` or `succeeded`, interpreted only as the
  pre-binding dispatch result and never emitted as canonical `command.delivered`;
- command type `worker.start`;
- command payload exactly identifies the same work item and `operation: start`;
- command and adapter request still have null run/session IDs, because SF-105 owns those IDs;
- exact dispatch, command, request, queue-transition, and authority lineage;
- active Product Factory and unchanged profile, repository, and worker policy;
- current work item still `queued` and equal to the exact queue-transition output;
- current work-item revision equal to every submitted revision binding;
- repository root equal to the Product Factory repository root after canonical resolution;
- source revision exists as a Git commit and equals current repository `HEAD`;
- context packet is valid, assembled, digest-correct, and bound to the same project and work item;
- delegated context, parent run, delegation, child run, and runtime lease form one valid P4.5
  chain;
- child agent run matches the project, work item, assigned identity, executor role, context packet,
  scope, authority grants, tool grants, budget, and deadline required by the start;
- delegated runtime lease ID/reference equals the SF-103
  `authority.delegated_runtime_lease_ref`, names the child agent-run ID, is active, unexpired,
  assigned to the same identity, project-bound, and digest-valid;
- the product workspace-policy capsule validates, names the same Product Factory/repository, has a
  current product-owner authorization, and exactly matches the submitted P3 source and policy
  digests;
- no secret-shaped field, secret-like value, inline lease token, credential, or forbidden
  secret-reference scheme.

Phase 1 SF-105 does not accept a non-delegated local authority string. Canonical `run-claim`
requires active-lease evidence, and a dispatch lease is concurrency only. A future non-delegated
start mode requires a separately ratified authority mapping; it cannot be synthesized from a local
digest.

## Deterministic Identities

IDs are factory-owned and derived from canonical JSON, never raw string concatenation.

```text
binding seed object = {
  "namespace": "elder.factory.run-binding.v1",
  "dispatch_id": ...,
  "dispatch_sha256": ...,
  "project_id": ...,
  "work_item_revision_id": ...,
  "source_revision": ...
}

binding seed       = SHA-256(canonical-json(binding seed object))
run ID             = run-<first 32 hex chars of binding seed>
worker-session ID  = worker-session-<first 32 hex chars of
                     SHA-256(canonical-json({"namespace":
                     "elder.factory.worker-session.v1", "binding_seed": binding seed}))>
workspace ID       = workspace-<first 32 hex chars of
                     SHA-256(canonical-json({"namespace":
                     "elder.factory.workspace.v1", "binding_seed": binding seed,
                     "repository": canonical repository root}))>
```

The full 64-character binding seed is stored under a unique index; the shortened identifier is
only its readable key. Exact replay returns the original records. Reusing the dispatch ID, full
binding seed, or shortened identifier with changed content is an explicit collision. Provider
session, thread, process, and rollout identifiers remain nullable opaque observations and never
replace these IDs.

## Immutable Initial Binding

Add `factory/operations/run-binding-record.schema.json`.

Each aggregate contains an immutable `initial_binding` with:

- project and Product Factory IDs;
- profile and worker-policy digests;
- work-item ID, queued record version and digest;
- work-item revision ID, entity digest, and snapshot digest;
- dispatch, command, request, and queue-transition IDs and digests;
- authority reference, accountable command reference, authorization request/result digests;
- delegated runtime-lease reference, lease record digest, and lease-token digest;
- Elder parent-run, delegation, child agent-run, and runtime-lease IDs and content digests;
- context-packet ID, digest, delegation ID, and delegation digest;
- run, worker-session, and workspace IDs;
- worker adapter ID;
- repository root and repository-binding digest;
- P3 source-contract, Git-policy, workspace-policy, repository-observation, and product
  workspace-policy-capsule digests;
- exact base/source revision;
- planned branch, workspace path, and isolation mode;
- instruction-trust mode and trusted instruction revision;
- execution attempt;
- creation actor and timestamp;
- cleanup policy;
- initial-binding content digest.

These fields never change in current rows or history. A later source revision, new context packet,
new authority packet, or new worker attempt requires a new run.

## Canonical Entity Mapping

The aggregate embeds and separately persists validated SF-002 entity envelopes.

### Run

Creation records:

```text
prepared -> queued
```

The prepared history row proves initial creation. The current row may become `queued` in the same
transaction because the workspace ID and authority reference are already bound.

Run payload:

- work-item ID;
- work-item revision ID;
- worker-session ID;
- workspace ID;
- context-packet ID;
- authority reference;
- attempt.

The factory record is not directly validated as an Elder agent-run because the status and payload
vocabularies differ. Instead, the immutable binding stores an `elder_run_binding` that references
and digest-binds the validated assigned child run.

The adapter mapping is exact:

| Factory concern | Elder child agent-run source |
|---|---|
| project and work item | `project_id`, `work_item_id` |
| assigned identity and role | `identity_id`, `role` |
| parent/delegation lineage | `parent_run_id`, `delegation_id` |
| provider-independent execution contract | `model`, `scope`, `tool_grants` |
| authority | `authority_grants` plus the current runtime lease |
| context | `context_packet_id` |
| limits | `budget`, `deadline` |
| factory outputs | references only; Elder `outputs` remains governance-owned |

The adapter's status projection is explicit:

| Factory run status | Projected Elder status |
|---|---|
| `prepared`, `queued`, `starting`, `running`, `validating` | `running`, cancellation `active` |
| `waiting`, `paused` | `blocked`, cancellation `active` |
| `cancelling` | `running` or `blocked`, cancellation `requested` |
| `completed` | `complete` |
| `failed` | `failed` |
| `cancelled` | `cancelled`, cancellation `cancelled` |
| `lost` | `aborted` |

This projection proves semantic compatibility; it does not mutate or impersonate the canonical
P4.5 run. The latest observed canonical Elder run ID, status, digest, and observation time are
stored separately with `elder_reconciliation_state` (`current`, `pending`, or `contradictory`).
A factory transition may make reconciliation pending, but a contradictory canonical terminal
state, changed identity/authority lineage, or stale source digest fails closed. Factory closure
reports the pending cross-store reconciliation explicitly.

### WorkerSession

Creation status is `prepared`.

Payload:

- run ID;
- worker adapter;
- nullable opaque external session reference;
- delegated runtime-lease reference;
- lease-token SHA-256 digest;
- session generation `1`;
- recovery attempt `0`;
- nullable checkpoint cursor;
- nullable waiting reason.

An external session reference is not required until an adapter acknowledgement activates the
session. The field remains present with null value while prepared.

### Workspace

Creation status is `requested`.

Payload:

- run ID;
- canonical repository root;
- exact base revision;
- deterministic work branch;
- planned absolute workspace path;
- isolation mode `planned-git-worktree`.

SF-105 validates path containment under the product repository's P3 worktree root but does not
create the directory. Workspace status cannot become `ready` without a later explicit verified
workspace observation.

## Workspace And Instruction Trust

Phase 1 uses a product-bound workspace-policy capsule rather than pretending that the P3 reference
project contract is itself a product contract. Add
`factory/operations/product-workspace-policy.schema.json`. The capsule contains:

- Product Factory ID and exact repository-binding digest;
- applicable canonical product repository root;
- source scope `central-p3-policy-subsets`;
- source repository and path, fixed in Phase 1 to this Elder repository's
  `factory/factory-contract.json`;
- source contract version and full content digest;
- exact copied `git` and `workspace` objects and their canonical digests;
- product-owner identity and exact `human-approval` authorization mapped to
  `approval-decision/approve`, including accountable command, request/result digests, decision,
  and timestamp;
- capsule content digest.

Only the P3 contract's repository-relative `git` and `workspace` objects are reusable global policy
in Phase 1. Its `project` object names `elder-workbench` and is explicitly not applied to a Product
Factory. The capsule binds the reusable subsets to one registered product repository under
product-owner authority. Product-specific overrides or a product-local P3 contract require a
future SF-100 registry revision; they are not inferred from files in an untrusted product checkout.

The deterministic execution key is:

```text
base = lowercase work-item ID without the "work-item-" prefix
base = replace each non [a-z0-9-] run with "-", trim "-", and cap at 44 characters
execution key = <base>-<first 12 hex chars of binding seed>
```

The key must match `[a-z0-9][a-z0-9-]{2,63}`. The planned branch and workspace root are derived
exactly as P3 derives them:

```text
branch = <P3 git.work_branch_prefix><execution-key>
path   = <product-repository>/<P3 workspace.state_root>/
         <P3 workspace.worktrees>/<execution-key>
```

The controller resolves both repository and target paths and rejects:

- path escape;
- repository mismatch;
- duplicate active path;
- use of the host checkout as the execution workspace;
- source revision not present as a commit;
- source revision different from current `HEAD`;
- branch names outside the bound P3 branch pattern;
- a changed P3 contract or policy digest.

The Product Factory repository binding remains the repository authority. The product-bound
capsule, digest-linked to the P3 source subsets and owner approval, is the workspace-policy
authority. Neither silently substitutes for the other.

Instruction trust modes:

- `trusted-source-revision`: instructions may be loaded only from the exact bound source
  revision;
- `trusted-base-only`: the checkout is untrusted, and instruction files may be loaded only from
  a separately bound trusted revision.

For `trusted-base-only`, the trusted instruction revision must exist, be explicit, and not be
silently replaced by workspace files. SF-105 records the restriction; Phase 2 must enforce and
read back effective worker settings before activation.

## No Workspace Reuse In Phase 1

SF-105 does not reuse a workspace path or provider sandbox.

This is deliberate. Correct reuse requires physical scrub evidence, clean-state verification,
credential removal, source reset, and provider reattachment behavior that belongs to Phase 2.

A future reuse operation must require:

- prior workspace `released`;
- same repository binding;
- new run and workspace identities;
- fresh source revision verification;
- clean/scrub evidence;
- no retained credentials;
- no active session or lease;
- a new generation and new immutable binding.

## Persistence Model

Use the existing operations SQLite database with WAL, foreign keys, busy timeout, and
`synchronous=FULL`.

### `factory_run_controller_metadata`

One immutable component metadata row records:

- run-controller schema version `1`;
- factory-domain version and digest;
- factory-contract version and digest;
- product-workspace-policy schema version;
- lifecycle-authority-mapping version and digest;
- accepted ADR ID;
- creation timestamp.

The shared operations-store `PRAGMA user_version` remains at the currently ratified store version.
SF-105 does not silently bump it or add keys to the SF-100 metadata table, because existing
components validate that table exactly. A future shared-store migration must update all component
readers together. An unknown or changed run-controller schema version fails closed.

### `factory_product_workspace_policies`

Immutable product-bound policy capsules keyed by capsule ID and content digest. Exact replay is
allowed. Reusing a capsule ID with changed repository, source contract, policy subsets, owner
authorization, or digest is rejected. A run stores the exact capsule ID/digest it consumed; later
capsules do not rewrite existing run bindings.

### `factory_runs`

Current run entity and aggregate identity:

- run ID primary key;
- project, work item, revision, dispatch, session, and workspace IDs;
- current status and record version;
- immutable-binding digest;
- aggregate JSON and content digest;
- latest observed Elder run digest and reconciliation state;
- created and updated timestamps;
- terminal timestamp;
- pending SF-103 transition command ID when activation confirmation is incomplete.

Uniqueness:

- one run per dispatch;
- one run per exact binding seed;
- one nonterminal run per project/work-item revision/attempt.

### `factory_run_history`

Append-only run aggregate snapshots with contiguous record versions.

### `factory_run_elder_observations`

Append-only reconciliation observations:

- factory run ID and contiguous observation version;
- canonical Elder child-run ID, status, cancellation status, and content digest;
- source coordination-store reference and observation timestamp;
- reconciliation state: `current`, `pending`, or `contradictory`;
- reason, causation command ID, and observation digest.

The latest validated observation is projected into `factory_runs`; history is the replay source.
A contradictory observation cannot be overwritten by a later in-place update.

### `factory_worker_sessions`

One current worker session per run:

- factory session ID;
- run ID;
- adapter;
- current status and record version;
- opaque external reference;
- authority/lease reference and token digest;
- session generation;
- recovery attempt;
- checkpoint cursor;
- waiting reason;
- active-capacity slot;
- entity JSON and digest;
- timestamps.

A partial unique index permits only one local session in `starting`, `active`, `waiting`,
`paused`, `detached`, `recovering`, or `cancelling` capacity at a time. Prepared sessions may
queue without consuming the worker slot.

### `factory_worker_session_history`

Append-only session snapshots. Generation and recovery attempt may only increase according to
the recovery protocol.

### `factory_workspaces`

One current workspace per run:

- workspace ID;
- run ID;
- repository, base revision, branch, and path;
- current status and record version;
- isolation mode;
- verification reference;
- cleanup state;
- entity JSON and digest;
- timestamps.

Active workspace paths are unique. Released or failed records remain historical and are never
deleted.

### `factory_workspace_history`

Append-only workspace snapshots.

### `factory_run_checkpoint_refs`

Immutable local observation wrappers around canonical Elder checkpoint references:

- reference ID;
- factory run and worker-session IDs;
- canonical Elder child-run ID and digest;
- canonical delegation and project IDs;
- session generation;
- checkpoint ID and content digest;
- local adapter cursor and provider observation sequence;
- canonical checkpoint sequence and previous-checkpoint digest;
- worker checkpoint observation ID and digest;
- recorded timestamp;
- reference digest.

The worker adapter's `{checkpoint_id, content_sha256}` result is only an observation. Acceptance
requires a separately supplied full canonical Elder checkpoint that validates against
`protocol/checkpoint.schema.json`. Its `run_id` must equal the immutable Elder child-run ID; its
delegation and project must equal the immutable start lineage; and its ID/digest must equal the
worker observation. Session generation, adapter cursor, and provider observation sequence belong
only to the local wrapper because they are not Elder checkpoint fields. The operations store does
not copy checkpoint authority or reinterpret checkpoint status.

### `factory_run_artifact_refs`

Immutable references that preserve the canonical SF-002 Artifact payload:

- reference ID;
- run ID;
- `artifact_sha256`;
- `artifact_type` (`diff`, `build-artifact`, `test-evidence`, or `evidence-bundle`);
- `provenance_ref`;
- artifact status, initially `produced`;
- optional target locator as non-authoritative retrieval metadata;
- producing session generation;
- recorded timestamp;
- reference digest.

Legacy design terms map exactly as follows: `content digest -> artifact_sha256`,
`kind -> artifact_type`, and `target reference -> provenance_ref`. The canonical payload fields are
stored directly; the aliases are not separate persisted truth.

An empty set is valid while execution has produced no artifact. Completion is not valid until
the later run-completion gate has the artifact or diff and evidence required by FD-009.

### `factory_run_lifecycle_commands`

One immutable submission row per lifecycle command:

- command ID primary key and globally unique idempotency key;
- exact command JSON and digest;
- operation and target entity IDs;
- expected run/session/workspace versions;
- submitted actor and timestamp;
- created timestamp.

### `factory_run_lifecycle_command_results`

Append-only result revisions for each command:

- command ID and contiguous result version;
- status: `applied`, `rejected`, `pending-external`, `confirmed`, or `uncertain`;
- deterministic result JSON and digest;
- recorded timestamp and causation digest.

Exact command replay returns the latest validated result. Reusing a command ID or idempotency key
with a changed command digest is rejected. `pending-external` and `uncertain` are never treated as
ordinary retryable failures.

### `factory_run_command_authorizations`

Each lifecycle command has one immutable row per canonical transition it requests:

- command ID and canonical transition ID;
- authenticated identity and role;
- factory authority mode;
- exact Elder resource and action;
- authority, accountable-command, and delegated-runtime-lease references;
- current factory record IDs, versions, and digests;
- governance request, decision, and result digests;
- decision timestamp and source-record digest.

Composite commands carry multiple authorization rows. For example, pausing an active execution
requires separate proofs for `run-pause` (`modify-only`) and `worker-session-pause`
(`execute-bounded`). One broad authority result cannot be reused across different transitions.

### `factory_run_external_step_history`

Cross-store SF-103 activation is an append-only recoverable step history:

- deterministic step ID and lifecycle command ID;
- contiguous step version;
- exact SF-103 command ID and digest;
- internal state: `pending`, `recorded-accepted`, `recorded-rejected`, or `uncertain`;
- raw SF-103 transition entity status (`recorded` or `rejected`);
- raw `decision.accepted`, reason code, decision digest, transition ID, transition digest, and
  work-item before/after digests when resolved;
- observation timestamp and digest.

SQLite triggers reject update or delete of histories, command submissions, command
results, authorizations, external-step revisions, checkpoint references, and artifact references.

## External Observation Ports

SF-105 depends on an injectable read-only `RepositoryInspector` port:

- `resolve_root(path)`;
- `head(repository)`;
- `commit_exists(repository, revision)`;
- `observe_workspace(path)`.

The production implementation uses local Git and filesystem reads only. Tests use a deterministic
fake; they do not mutate process-global Git state. `bind_start` takes an observation before the
transaction and repeats the root, `HEAD`, and commit checks immediately before commit. A changed
observation aborts the transaction. Later physical worktree verification remains Phase 2.

SF-105 also depends on an injectable read-only `CoordinationInspector` port:

- `read_parent_run(id)`;
- `read_delegation(id)`;
- `read_child_run(id)`;
- `read_runtime_lease(id)`;
- `read_checkpoint(id)`.

The production adapter reads the P4.5 coordination store. Tests use deterministic observations.
For every lease-gated transaction, SF-105 reads the lease before `BEGIN IMMEDIATE` and again
immediately before commit. Both observations must be byte/digest-equal, active, unreleased, bound
to the same child run/identity/project, and unexpired at the intended commit timestamp. The
command result stores both validation timestamps, `expires_at`, and remaining lifetime at commit.
If the second read changes or the transaction reaches or passes expiry, it rolls back.

Cross-store atomicity is not claimed: authority can change immediately after commit, so every
later lease-gated command revalidates. A later lease loss can move lifecycle state only through
the declared fail/lost path; it cannot retroactively rewrite the accepted command.

## Start Transaction

`bind_start` performs one `BEGIN IMMEDIATE` transaction:

1. load and validate the exact completed SF-104 dispatch and its full history;
2. validate Product Factory, profile, repository, and worker policy;
3. validate current queued work item and revision lineage;
4. validate and persist/replay the exact product workspace-policy capsule and its source P3
   Git/workspace policy digests;
5. independently resolve Git repository root, `HEAD`, and commit existence through the
   repository inspector;
6. validate context, parent run, delegation, child agent run, active runtime lease, and exact
   transition authorization lineage;
7. derive IDs, execution key, branch, path, and immutable binding digest;
8. return the existing binding for an exact replay;
9. reject any collision or active duplicate;
10. insert the immutable `bind_start` command and its authorization rows;
11. insert prepared run history;
12. insert prepared worker session;
13. insert requested workspace;
14. advance run to queued and append its second history row;
15. repeat repository and coordination-store observations, validate lease equality and commit-time
    expiry, and reject drift;
16. store the applied command result, lease-freshness proof, and commit before returning.

No provider callback, worktree operation, or work-item transition occurs inside this transaction.

## Lifecycle Commands

Add `factory/operations/run-lifecycle-command.schema.json`.

Every mutation carries:

- command ID and idempotency key;
- operation;
- run, session, and workspace IDs as applicable;
- expected record versions;
- actor identity;
- one exact authorization object per canonical transition, including role, mode, resource, action,
  authority reference, accountable command, delegated runtime lease, current record bindings,
  governance request/result digests, decision, decision reference, and decision timestamp;
- session generation when session state changes;
- evidence or observation references;
- reason and timestamp;
- exact payload digest.

Commands and their authorization rows are inserted in the same `BEGIN IMMEDIATE` transaction
before any entity history row is appended. Accepted and rejected commands both persist and replay
exactly. Changed duplicate commands fail closed.

Add `factory/operations/run-lifecycle-authority-mapping.json` and its schema. The mapping is
non-authoritative dependency truth derived from the ratified factory domain and
`protocol/authority-matrix.json`; it records both source digests. Phase 1 accepts only the
`executor` role:

| Canonical transition or operation | Factory mode | Elder resource/action |
|---|---|---|
| all `execute-bounded` Run/WorkerSession/Workspace transitions except those named below | `execute-bounded` | `implementation/execute` |
| `run-wait`, `worker-session-wait`, `worker-session-detach`, `worker-session-recover` | `execute-bounded` | `checkpoint/checkpoint` |
| `run-pause`, `workspace-quarantine` | `modify-only` | `implementation/modify` |
| `worker-session-pause` | `execute-bounded` | `implementation/execute` |
| checkpoint reference | `execute-bounded` | `checkpoint/checkpoint` |
| artifact reference | `execute-bounded` | `implementation/execute` |

If a canonical transition's declared mode, eligible role, or required evidence does not match this
mapping, the command is rejected. Product-owner and security-owner operational requests require a
later API/governance command that resolves to an executor-authorized lifecycle command; SF-105
does not invent permissions that are absent from the authority matrix.

Supported Phase 1 operations:

- record workspace provisioning request;
- record verified workspace readiness;
- begin session start;
- record session acknowledgement and opaque external reference;
- wait, pause, resume/attach, detach, and recover session;
- record checkpoint reference;
- record artifact reference;
- request cancellation;
- fail or lose run/session;
- record session completion, run validation, and run acceptance;
- request terminal cleanup;
- confirm workspace release;
- quarantine workspace;
- inspect status and history.

These are provider-neutral state operations. Tests supply deterministic observations; no real
worker or worktree is invoked.

## Complete Lifecycle Matrix

Each row below names the only legal current-state mutation. Required fields and evidence are
copied from the ratified SF-002 domain and are enforced in addition to the exact authorization
proof above.

### Run

| Transition | From -> To | Required binding/evidence |
|---|---|---|
| `run-queue` | `prepared -> queued` | authority ref, workspace ID |
| `run-claim` | `queued -> starting` | authority ref, current active Elder runtime lease |
| `run-start` | `starting/waiting/paused -> running` | worker-session ID |
| `run-wait` | `running -> waiting` | waiting reason |
| `run-pause` | `running/waiting -> paused` | pause reason |
| `run-cancel-request` | `starting/running/waiting/paused -> cancelling` | cancellation reason |
| `run-cancelled` | `cancelling -> cancelled` | worker cancellation confirmation |
| `run-validate` | `running/waiting -> validating` | checkpoint and evidence records |
| `run-complete` | `validating -> completed` | validated evidence bundle |
| `run-fail` | `starting/running/waiting/paused/cancelling/validating -> failed` | failure evidence |
| `run-lost` | `starting/running/waiting/paused/cancelling -> lost` | lease or worker loss evidence |

### WorkerSession

| Transition | From -> To | Required binding/evidence |
|---|---|---|
| `worker-session-start` | `prepared -> starting` | run ID, worker adapter |
| `worker-session-activate` | `starting/waiting/paused/recovering -> active` | opaque external ref, worker acknowledgement |
| `worker-session-wait` | `active -> waiting` | waiting reason |
| `worker-session-pause` | `active/waiting -> paused` | pause reason |
| `worker-session-detach` | `active/waiting/paused -> detached` | checkpoint cursor and accepted checkpoint ref |
| `worker-session-recover` | `detached -> recovering` | external ref, lease ref/token digest, next generation/recovery attempt, cursor, session/lease/checkpoint lineage |
| `worker-session-cancel` | `starting/active/waiting/paused/detached/recovering -> cancelling` | cancellation reason |
| `worker-session-cancelled` | `cancelling -> cancelled` | worker cancellation confirmation |
| `worker-session-complete` | `active/waiting -> completed` | final accepted checkpoint |
| `worker-session-fail` | `starting/active/waiting/paused/detached/recovering/cancelling -> failed` | failure evidence |
| `worker-session-lost` | `starting/active/waiting/paused/detached/recovering/cancelling -> lost` | lease ref and lease-loss evidence |

### Workspace

| Transition | From -> To | Required binding/evidence |
|---|---|---|
| `workspace-provision` | `requested -> provisioning` | repository and base revision |
| `workspace-ready` | `provisioning -> ready` | path, isolation mode, workspace verification |
| `workspace-bind` | `ready -> in-use` | run ID |
| `workspace-quarantine` | `in-use -> quarantined` | quarantine reason |
| `workspace-release` | `ready/in-use/quarantined -> releasing` | retention decision |
| `workspace-released` | `releasing -> released` | release confirmation |
| `workspace-fail` | `provisioning/ready/in-use/quarantined/releasing -> failed` | failure evidence |

No SF-105 method may invent an omitted transition. In particular, `requested` cannot jump to
`ready`, `in-use`, `quarantined`, `releasing`, or `failed`; and a queued run has no terminal
transition in the current domain. Such records remain explicitly pending and require either legal
forward progress or a future ratified domain change.

## Activation Through SF-103

Work-item transition and run/session activation are deliberately separate, restart-recoverable
steps.

```text
1. request_workspace_provisioning:
     workspace requested -> provisioning
2. record_workspace_ready:
     workspace provisioning -> ready
3. begin_session_start:
     worker session prepared -> starting
4. record_session_acknowledgement:
     worker session starting -> active
5. prepare_work_item_start, in one transaction:
     revalidate the active Elder runtime lease
     run queued -> starting
     workspace ready -> in-use
     persist a deterministic pending SF-103 command and active-run evidence
6. caller submits the exact command to SF-103
7. confirm_work_item_start verifies SF-103 status "recorded" and decision.accepted true
8. SF-105 moves run starting -> running and records the step as recorded-accepted
```

The generated SF-103 command is exact:

- transition ID/rule: `work-item-start`;
- trigger: `start`;
- expected work-item state: the immutable queued record version;
- actor/role: the bound executor;
- authority mode: `execute-bounded`;
- Elder mapping: `implementation/execute`;
- evidence: `active run reference` URI bound to the run ID, current run record version, current
  run digest, worker-session ID/generation, workspace ID, and runtime-lease digest;
- field bindings: empty unless the canonical work-item transition later requires fields.

SF-103 result mapping is exact:

- transition entity status `recorded` plus `decision.accepted: true` ->
  `recorded-accepted`;
- transition entity status `rejected` plus `decision.accepted: false` ->
  `recorded-rejected`;
- any other status/decision combination -> protocol error.

The external-step revision retains the raw transition entity, command digest, decision digest,
before/after work-item digests, reason code, and content digest. If the process stops after SF-103
records an accepted decision, restart reconciliation queries the exact deterministic command ID,
verifies those fields, and completes confirmation. SF-105 never writes the work-item stage
directly.

An SF-103 timeout or unknown result marks the external step `uncertain`. It is not submitted under
a new ID and cannot enter ordinary retry; reconciliation must first resolve the exact original
command.

If SF-103 returns the exact `recorded-rejected` mapping, one compensation command atomically
records the rejection and begins the legal failure path:

- run `starting -> failed` with the SF-103 rejection as failure evidence;
- worker session `active -> cancelling` with activation-rejection reason;
- workspace `in-use -> quarantined` because an acknowledged session existed before the rejection.

A later cancellation-confirmation command moves the session `cancelling -> cancelled`.
Quarantine is already a valid retained cleanup state; an explicit retention decision may later
move it through `releasing -> released`. If session cancellation itself becomes uncertain, the
session and external step remain visibly uncertain and the workspace remains quarantined.

Because the work item remains `queued`, a later retry requires a new SF-104 dispatch identity and
a new execution attempt after the failed run is closed. The rejected dispatch and failed binding
are never rewritten or reused.

Wrong work item, version, authority, transition trigger, stage, or transition digest is rejected.

## Session Recovery

Recovery is allowed only from `detached`.

The recovery command must bind:

- exact run and worker-session IDs;
- exact opaque external session reference;
- current delegated runtime-lease reference and token digest;
- prior session generation;
- next generation equal to prior plus one;
- recovery attempt equal to prior plus one;
- exact prior checkpoint cursor and checkpoint reference;
- recovery observation and timestamp.

Recovery performs:

```text
detached -> recovering
session generation N -> N + 1
recovery attempt M -> M + 1
```

Only a matching acknowledgement can move `recovering -> active`. Delayed observations from an
older generation cannot update lifecycle, checkpoints, artifacts, cleanup, or completion.

Missing checkpoint lineage, expired delegated lease, changed external reference, skipped
generation, or changed workspace binding fails closed.

## Checkpoints

Worker checkpoint output is an adapter observation until accepted through Elder governance.

SF-105 accepts a checkpoint reference only after:

- full checkpoint schema and digest validation;
- exact project and delegation binding;
- checkpoint `run_id` equal to the immutable canonical Elder child-run ID, not the factory run ID;
- worker observation checkpoint ID/digest equal to the canonical checkpoint ID/digest;
- exact current worker-session generation;
- canonical checkpoint sequence continuity and local provider-observation sequence continuity;
- previous checkpoint digest continuity;
- cursor monotonicity;
- active authority/lease validation where applicable.

The operations record stores only the reference fields and digest. It cannot create, approve, or
mutate canonical Elder checkpoint state.

## Artifacts

Artifact references are append-only and generation-bound.

SF-105 does not create or verify artifact bytes. It records only references already produced by
the P3 artifact substrate, a Git diff evidence record, a test evidence record, or a later
evidence bundle.

Duplicate exact references replay. Reusing an ID with changed kind, target, digest, run, or
generation is rejected.

## Cleanup And Terminal State

The immutable cleanup policy contains:

- completed run: `release`;
- cancelled run: `release`;
- failed or lost run: state-dependent legal cleanup, preferring quarantine only from `in-use`;
- evidence-retention requirement;
- physical deletion permitted: `false` in Phase 1.

Terminalization and cleanup are separate commands:

```text
run/session terminal observation
-> cleanup requested
-> choose the only legal workspace transition for its current state
-> release confirmation, quarantine retention, or explicit workspace failure
-> terminal cleanup complete or visibly unresolved
```

For successful or cancelled runs, the workspace transitions to `releasing`. SF-105 records
release confirmation but performs no filesystem deletion.

For failed or lost runs:

| Current workspace | Legal cleanup |
|---|---|
| `in-use` | `quarantined`, retaining exact source, path, session, checkpoint, artifact, and failure lineage |
| `ready` | `releasing -> released`, or `failed` when failure evidence shows the workspace is unsafe |
| `provisioning` | `failed`; quarantine is not a legal transition |
| `quarantined` | retain, or `releasing -> released` after a retention decision |
| `releasing` | `released` on confirmation or `failed` on cleanup failure |
| `released` or `failed` | already terminal; no outgoing transition |

A `requested` workspace has no cleanup or failure transition in the ratified domain. Because a run
also cannot fail or cancel from `queued`, SF-105 reports that pre-provisioning binding as pending
rather than claiming terminal cleanup. This limitation is evidence for a future domain amendment,
not permission to invent a shortcut.

A run may carry a terminal execution result while `cleanup_state` is still pending, but it is not
reported as fully closed until cleanup reaches `released` or `quarantined`. Restart status must
surface pending cleanup explicitly.

## Store Backup, Restore, And Rebuild

SF-105 adds component-scoped operations without claiming that SF-106 journal replay already
exists.

- `backup(target)` uses SQLite's online backup API into a new file, then records a sidecar manifest
  with source path, run-controller schema version, SQLite integrity result, current/history row
  counts, immutable-reference counts, and deterministic history-tip digests.
- `restore(source, target)` restores only into a new or empty target, validates the sidecar digest,
  SQLite integrity, component metadata, immutable triggers, current/history equality, command
  replay results, and all source-reference digests before making the target usable.
- `rebuild_current()` reconstructs run/session/workspace current rows from immutable histories in a
  fresh database and compares byte-equivalent canonical JSON and content digests.
- Schema migration is unsupported in run-controller version 1. A different component schema
  version fails closed with an actionable migration-required error.
- Backup or restore never mutates the source database and never operates as a second writable
  primary.

## Integrity And Replay

Every read validates:

- all three canonical entity envelopes;
- exact immutable initial binding;
- run-controller schema metadata and all pinned source digests;
- current row equality with each history tip;
- contiguous record versions;
- legal run/session/workspace transitions;
- every lifecycle command, idempotency key, authorization row, external-step revision, and replayed
  result digest;
- profile, work-item, dispatch, authority, context, repository, and revision lineage;
- Elder parent/delegation/child-run/runtime-lease lineage and status compatibility;
- explicit Elder run reconciliation state, including any pending terminal synchronization;
- active-capacity and workspace-path uniqueness;
- generation and recovery monotonicity;
- checkpoint and artifact reference digests;
- cleanup-state consistency;
- no secret material.

`status()` runs SQLite `quick_check`, validates every current row and immutable reference, and
returns schema/source digests plus counts by run, session, workspace, command, external-step,
recovery, and cleanup status.

## Error Handling

All failures are explicit `ProtocolError` errors with actionable messages.

No fallback:

- from changed dispatch to a new run;
- from stale source revision to current `HEAD`;
- from wrong repository to the registered repository;
- from missing authority or context to ungoverned execution;
- from a dispatch lease or local digest to Elder execution authority;
- from stale generation to current session state;
- from untrusted checkout instructions to workspace-local instruction files;
- from failed cleanup to silent release;
- from worker observation to canonical Elder checkpoint authority;
- from SF-104 pre-binding delivery to canonical `command.delivered`;
- from an illegal cleanup shortcut to a convenient terminal status;
- from SF-105 lifecycle code to direct work-item mutation.

## Planned Files

Implementation should remain scoped to:

- `elder_protocol/factory_operations/run_controller.py`;
- `elder_protocol/factory_operations/__init__.py`;
- `factory/operations/run-binding-submission.schema.json`;
- `factory/operations/run-binding-record.schema.json`;
- `factory/operations/product-workspace-policy.schema.json`;
- `factory/operations/run-lifecycle-command.schema.json`;
- `factory/operations/run-lifecycle-command-result.schema.json`;
- `factory/operations/run-lifecycle-authority-mapping.schema.json`;
- `factory/operations/run-lifecycle-authority-mapping.json`;
- `factory/operations/run-external-step.schema.json`;
- `factory/operations/run-elder-observation.schema.json`;
- `factory/operations/run-checkpoint-reference.schema.json`;
- `factory/operations/run-artifact-reference.schema.json`;
- `factory/operations/run-backup-manifest.schema.json`;
- `tests/foundation/test_run_controller.py`;
- `tests/component/test_run_controller.py`;
- `tests/integration/test_run_binding_flow.py`;
- `tests/stress/test_run_controller_stress.py`;
- SF-105 reproduction and evidence documents after implementation.

Existing SF-100 through SF-104 modules should change only for a narrowly justified public export
or read-only helper. Protected protocol and accepted ADR surfaces are not implementation targets.

## Verification Plan

### Foundation

- all SF-105 schemas validate and reject unknown fields;
- canonical Run, WorkerSession, and Workspace fields and statuses are not weakened;
- immutable/mutable field partitions are explicit;
- factory-to-Elder run mapping is complete and rejects identity, authority, context, budget,
  deadline, status, or source-digest drift;
- product workspace-policy capsules reject project-object reuse, wrong repository scope, changed
  P3 subset bytes, and missing owner authorization;
- checkpoint observation wrappers keep session generation/cursor local while preserving canonical
  Elder run/delegation/checkpoint authority;
- secret-shaped fields, credential values, inline tokens, and provider-specific canonical IDs
  are rejected;
- lifecycle, authority, activation-compensation, and cleanup matrices are complete;
- every lifecycle transition has a machine-readable role/mode/resource/action mapping.

### Component

- completed start dispatch creates one exact binding;
- exact replay returns the original binding;
- changed duplicate dispatch or submission fails;
- pending, uncertain, dead-lettered, or cancelled dispatch fails;
- wrong Product Factory, profile, repository, worker policy, work item, revision, authority,
  context, parent run, delegation, child run, or delegated lease fails;
- non-delegated local authority fails;
- changed P3 contract, Git policy, workspace policy, or repository observation fails;
- product policy capsules cannot apply the `elder-workbench` project object to a product repository;
- stale or unknown Git revision fails;
- source `HEAD` drift fails;
- runtime lease change or expiry before commit rolls back without a binding;
- deterministic IDs, branch, path containment, and host-checkout rejection;
- run prepared-to-queued history;
- workspace requested, ready, in-use, releasing, released, quarantined, and failed paths;
- workspace requested-to-provisioning and provisioning-to-ready cannot be skipped;
- session prepared, starting, active, waiting, paused, detached, recovering, cancelling, and
  terminal paths;
- durable lifecycle-command replay, collision, rejection, multi-authorization, and restart paths;
- one active worker capacity;
- stale version, actor, authority, owner, and generation fencing;
- recovery generation and checkpoint continuity;
- checkpoint and artifact exact replay/collision behavior;
- Artifact references preserve `artifact_sha256`, `artifact_type`, and `provenance_ref`;
- terminal cleanup pending, release confirmation, and quarantine;
- restart durability, history equality, tamper detection, and immutable reference triggers.
- backup, restore-to-fresh-target, current-row rebuild, wrong-schema, and manifest-tamper paths.

### Integration

- SF-100 -> SF-102 -> SF-103 -> SF-104 -> SF-105 exact lineage;
- SF-105 consumes only the completed SF-104 start delivery;
- SF-104 output is consumed as a pre-binding dispatch fact and is never emitted as canonical
  `command.delivered`;
- binding is committed before any SF-103 running transition;
- queued-to-running transition occurs only through SF-103;
- crash after an SF-103 `recorded` transition with `decision.accepted: true` reconciles to running;
- SF-103 raw `recorded`/`rejected` status and `decision.accepted` combinations map exactly and
  invalid combinations fail;
- SF-103 rejection performs the exact run-fail/session-cancel/workspace-quarantine compensation;
- SF-103 uncertainty remains unresolved until the exact command is reconciled;
- delegated lease and context packet remain reference-bound across P4.4/P4.5 boundaries;
- terminal cleanup state remains visible without physical workspace mutation.

### Workflow

- run the complete existing workflow suite;
- add one owner-visible local lifecycle fixture only if the current workflow test structure has a
  natural factory-kernel boundary;
- do not introduce SF-107 API behavior.

### Stress

- concurrent exact starts produce one binding;
- conflicting concurrent starts produce one winner and explicit conflict;
- worker capacity remains one under concurrent activation;
- concurrent checkpoint/artifact appends preserve uniqueness and ordering;
- stale generation cannot write after recovery;
- process restart during pending SF-103 confirmation reconciles deterministically;
- many released/quarantined historical workspaces do not permit active path reuse;
- pending cleanup backlog remains queryable and integrity-valid.

## Runtime Budget

Run one level at a time and stop on the first failure:

| Level | Initial timeout budget |
|---|---:|
| Foundation | 10 minutes |
| Component | 30 minutes |
| Integration | 25 minutes |
| Workflow | 15 minutes |
| Stress | 25 minutes |

The SF-105 reproduction document must record:

- exact interpreter and Python version;
- exact command per level;
- timeout budget;
- observed unittest runtime and wall time;
- tests run, passed, failed, and skipped;
- every initial failure and root cause;
- same-level rerun after each fix;
- final protocol, skill, compilation, diff, package, and installed-wheel checks.

## Design Fitness Functions

SF-105 implementation is acceptable only when executable tests prove:

1. no run exists without exact Product Factory, work-item revision, authority, context,
   Elder child-run/runtime-lease, repository policy, source revision, worker session, and workspace
   binding;
2. no changed replay can reuse a durable start identity;
3. no worker or provider identifier becomes factory authority;
4. no stale session generation can mutate current state;
5. no workspace path escapes the authorized root or equals the host checkout;
6. no work-item stage changes outside SF-103;
7. no worker checkpoint becomes canonical Elder state by observation alone;
8. no terminal run is reported fully closed while cleanup is unresolved;
9. no real provider or workspace effect occurs in Phase 1 tests;
10. all records survive restart and validate from durable history;
11. no canonical lifecycle mutation lacks a persisted command and exact per-transition authority
    result;
12. no illegal domain transition is used for activation, compensation, or cleanup;
13. backup, restore, and current-row rebuild preserve digest-equivalent state.

## Design Review Gate

The 2026-08-11 independent design review initially rejected implementation readiness. The design
was revised until the reviewer confirmed that:

- all 29 canonical Run, WorkerSession, and Workspace transitions are represented without shortcut
  states;
- lifecycle commands, results, per-transition authorizations, external SF-103 steps, Elder
  reconciliation observations, checkpoint wrappers, and artifact references are durably modeled;
- delegated-only Phase 1 authority, commit-time lease freshness, canonical ID derivation, and
  product-scoped workspace policy fail closed;
- SF-104 pre-binding delivery is not confused with canonical `command.delivered`;
- SF-103 raw transition status and decision semantics are retained exactly;
- backup, restore, rebuild, cleanup, and deterministic test ports are specified.

The pre-implementation independent design verdict was **ready for implementation**, with no
remaining Critical or High design finding. Independent implementation and test reviews then
identified authority, replay, recovery, immutable-source, cleanup, backup, and coverage defects.
Those findings were reproduced, fixed at their originating test level, and included in the final
complete ladder.

Final implementation verdict: **VERIFIED for the declared local Phase 1 scope**. This verdict is
bound to the exact implementation, complete ordered test ladder, installed-wheel verification,
and evidence in `docs/software-factory/evidence/SF-105.md`. It does not claim a commit, hosted
durability, distributed operation, real provider execution, deployment, merge, release, or
maturity increase.

## Implementation Sequence

After this design is accepted:

1. add Foundation schemas, lifecycle authority mapping, and static matrices;
2. add component schema metadata plus backup/restore/rebuild primitives;
3. implement repository-inspector and Elder-run/lease validation ports;
4. implement immutable start binding and exact replay;
5. implement current rows, histories, durable commands, authorizations, and integrity reads;
6. implement the complete legal lifecycle and active-capacity fencing;
7. implement SF-103 activation, uncertainty reconciliation, and rejection compensation;
8. implement checkpoint observation wrappers and artifact references;
9. implement recovery generation and state-dependent terminal cleanup;
10. add Integration and Stress fixtures;
11. run the full ordered ladder with the documented budgets;
12. produce reproduction and evidence documents;
13. update the Obsidian project note at verified completion;
14. request explicit permission before staging or committing SF-105.

## Phase Handoff

The full ordered ladder and installed-wheel verification passed on 2026-08-11. SF-105 is ready
for explicit human closure and commit.

SF-106 must be designed and independently reviewed on its own branch before implementation. It
adds append-only operational facts and rebuildable projections over the durable SF-100 through
SF-105 state. SF-107 adds the stable owner/integration/worker API and health surface.

Gate B remains open until SF-105, SF-106, and SF-107 are separately implemented and verified,
then the Phase 1 kill-and-restart exit scenario passes.
