# Stable Factory Contracts And Events

**Status:** RATIFIED for Phase 1 by ADR 0021 on 2026-08-08

**Task:** SF-003 - Define Stable Contracts And Events

**Contract version:** `1.0.0`

**Authority:** These contracts do not amend Elder authority, maturity, or qualification. ADR
0021 ratifies them as the Phase 1 public-contract boundary. Later compatibility changes retain
the approvals assigned to the `public-contract` change class.

## Outcome

The factory now has a language-neutral boundary for:

- worker adapters;
- governance adapters;
- external integration adapters;
- durable commands;
- canonical journal events and live projections;
- adapter requests and responses;
- generation-aware event cursors;
- stable error, idempotency, compatibility, and redaction behavior.

The boundary is expressed as JSON Schema plus deterministic semantic validation. It does not
import provider runtime objects into product truth.

## Machine-Readable Surface

| File | Purpose |
|---|---|
| `factory/factory-contracts.json` | canonical operation, compatibility, error, cursor, idempotency, redaction, and authority registry |
| `factory/factory-contracts.schema.json` | registry structure |
| `factory/factory-command.schema.json` | provider-neutral durable command |
| `factory/factory-event.schema.json` | canonical journal event or non-authoritative live projection |
| `factory/factory-adapter-request.schema.json` | versioned adapter invocation envelope |
| `factory/factory-adapter-response.schema.json` | bound result, error, retry, mutation, and source-of-truth envelope |
| `factory/factory-cursor.schema.json` | stream, generation, sequence, event, and snapshot cursor |
| `elder_protocol/factory_contracts.py` | semantic compatibility and fail-closed validation |

All canonical behavior fields are strict. Provider-specific extension data appears under
namespaced `extensions` keys such as `example.provider/session_hint`. Provenance fields such as
`adapter_id` and `source_ref` may identify the implementation that produced an observation, but
provider identity cannot define entity identity, authority, lifecycle, payload shape,
idempotency, cursor order, or completion.

## Adapter Contracts

### Worker Adapter

```text
prepare(work_item, authority, context) -> prepared_run
start(prepared_run) -> worker_session
send(command) -> accepted_command
observe(cursor) -> normalized_events
checkpoint(session) -> checkpoint
cancel(session, reason) -> cancellation_result
recover(session) -> recovery_result
collect-evidence(session) -> evidence_bundle
```

Worker responses use `source_of_truth: adapter-observation`. A worker reports observations and
evidence. It cannot directly mutate product, authority, decision, or promotion truth.

### Governance Adapter

```text
classify(work_item) -> change_class
assemble-context(request) -> context_packet
authorize(action) -> authority_result
validate-delegation(delegation) -> validation_result
evaluate(evidence) -> evaluation_result
qualify(bundle) -> qualification_report
propose-learning(trajectory) -> learning_candidate
promote(packet) -> governed_target_result
```

Governance responses use `source_of_truth: governance-record-reference`. The adapter references
or performs authority already established by the applicable Elder contract. It cannot create,
raise, or reinterpret authority.

For a mutating factory transition, `authorize` must bind the exact project, actor identity, role
binding, mapped Elder action and resource, work item, run, transition, current record version,
accountable command or delegation, and active assigned-identity runtime lease when delegated.
Factory role membership, a dispatch lease, a provider session, or tool access alone is never an
authorization result.

The `promote` operation remains target-specific and must preserve P4.6 approval, promoter, target,
artifact, digest, and separation-of-duty requirements.

### Integration Adapter

```text
ingest-signal(signal) -> accepted_signal
ingest-decision(decision) -> accepted_decision
publish-projection(event) -> delivery_result
```

Signal and decision ingestion returns a canonical record reference. Projection delivery returns
only a projection acknowledgement. An external integration cannot execute a worker or mutate
canonical state directly.

Every one of the 19 operations declares an exact request-field and result-field set in
`factory-contracts.json`. An adapter cannot substitute provider-specific payload keys while
retaining the same operation name. Each field also declares a language-neutral value contract:
primitive type, required nested object fields, SHA-256, opaque reference, factory command,
factory event, or factory cursor. Array contracts also declare and validate their item type, so
`observe.events` contains canonical factory events rather than provider-native records.

## Command Semantics

A command binds:

- contract version and stable command identity;
- project, work item, run, and worker session where applicable;
- command type and read or mutation classification;
- durable idempotency identity for every mutation;
- authority reference, correlation, and causation;
- attempt, lifecycle status, submission, and expiry;
- payload digest, payload mode, redaction classification, and namespaced extensions.

The lifecycle remains:

```text
pending -> accepted -> delivered -> acknowledged -> succeeded
   |          |           |              |
   +-> rejected / cancelled              +-> failed / uncertain
```

`accepted` means the adapter durably accepted the request. It does not mean the command completed.
`uncertain` means a mutating side effect may have occurred but no durable result is known.
Uncertainty is nonterminal and requires reconciliation by the original idempotency key.

## Response Semantics

Every adapter response is digest-bound to the exact request and separates:

- `disposition`: accepted, succeeded, rejected, failed, timeout, duplicate, uncertain, or
  stale-cursor;
- `operation_completed`: whether successful completion is confirmed;
- `mutation_state`: not applicable, not started, not applied, applied, or unknown;
- `retry`: never, same idempotency key, reconcile, or refresh cursor;
- `source_of_truth`: observation, canonical record reference, governance record reference, or
  projection acknowledgement.
- `result_mode` and redaction classification: inline or digest-only result handling.

Important combinations:

| Situation | Disposition | Mutation state | Retry |
|---|---|---|---|
| accepted but not completed | `accepted` | `not-started` | `never` |
| confirmed success | `succeeded` | `applied` for a mutation | `never` |
| rejected before dispatch | `rejected` | `not-started` | `never` |
| timeout with proven non-application | `timeout` | `not-applied` | `same-idempotency-key` |
| duplicate mutation | `duplicate` | original durable state | `never` |
| possible unobserved side effect | `uncertain` | `unknown` | `reconcile` |
| cursor outside retention | `stale-cursor` | `not-applicable` | `refresh-cursor` |

A mutation with unknown state cannot use `timeout`, `failed`, or a normal retry. It must use
`uncertain` and reconcile.

Duplicate validation requires the original request and original durable response. The duplicate
must match the original completion, mutation, source, redaction, result mode, result digest, and
result content and extensions, and its `original_response_sha256` must recompute from that
response.

## Error Taxonomy

The stable error codes are:

```text
invalid-request
unsupported-version
unauthorized
forbidden
not-found
conflict
timeout
stale-cursor
uncertain-mutation
provider-unavailable
internal-error
```

Each code has one canonical disposition, one retry rule for reads, one retry rule for mutations,
and one mutation-state rule. Unknown codes and contradictory combinations fail closed. Messages
and details are diagnostic only and cannot override deterministic behavior.

## Idempotency

Mutation identity is scoped by:

```text
contract_id + operation + project_id + idempotency_key
```

Rules:

1. Every mutating adapter request and mutating command requires an idempotency key.
2. A retry reuses the original key.
3. A duplicate returns or references the original durable response.
4. Reusing the same key with a different payload digest is a conflict.
5. Work item, run, session, correlation, causation, redaction, and extension context cannot drift
   under the same key.
6. A duplicate cannot repeat the side effect.
7. An uncertain mutation must reconcile by the original key before any retry.
8. Idempotency records must outlive the maximum command and provider reconciliation window.

## Event And Cursor Semantics

A factory event includes:

- event identity and type;
- contract version;
- occurred and recorded times;
- product, project, work item, run, and session correlations;
- actor and source;
- correlation and causation identifiers;
- input idempotency identity where applicable;
- payload digest and redaction classification;
- stream, generation, sequence, event, and snapshot cursor.

`record_kind: journal-entry` is authoritative and binds its own event ID to a positive cursor
sequence. `record_kind: live-projection` is non-authoritative and binds the cursor and source event
of the canonical journal entry.

The registry defines 23 canonical event types for command, worker-session, decision, run, signal,
and decision-ingress behavior. Each type has exact required and optional payload fields and an
allowed source-plane set. Unknown event types and provider-specific payload shapes fail closed.

Cursor rules:

- sequence `0` is the initial cursor and has no event ID;
- a cursor from an older generation is stale;
- a cursor before the retained minimum is stale;
- a future generation or sequence is rejected;
- a stale response supplies a current snapshot or refresh cursor;
- a same-generation refresh must strictly advance the sequence;
- live delivery never replaces the durable append-only journal.

## Redaction

Classifications are `public`, `internal`, `confidential`, and `restricted`.

- Raw secret values are forbidden by contract. Common credential formats and secret-like values
  fail validation across payloads, results, errors, metadata, and extensions.
- Secret-shaped field names fail validation unless they explicitly carry a reference or digest.
- Opaque reference fields use a non-empty URI-like `scheme:value` form; digest fields contain
  lowercase 64-character SHA-256.
- Restricted adapter requests and responses carry opaque references; confidential and restricted
  event payloads are digest-only.
- Redacted fields are JSON Pointer paths.
- Stable metric or correlation dimensions must not contain secrets or direct personal contact or
  payment values.

No generic validator can prove that every arbitrary string is not a secret. Adapters remain
responsible for secret-broker use and pre-serialization scanning. Redaction does not make a value
authoritative or safe for a broader audience. Transport, retention, and access controls remain
implementation responsibilities.

## Compatibility And Migration

The registry uses semantic version syntax but requires exact version equality for the current
`1.0.0` schemas.

- `1.0.0` producers and consumers are compatible.
- A minor release requires a side-by-side schema and explicit consumer support; current schemas
  do not silently accept it.
- Patch releases may clarify or make backward-compatible fixes only.
- A new major requires an explicit adapter or migration.
- Unknown top-level fields, operations, and errors are rejected.
- Provider additions use namespaced `extensions`.
- A deprecated field or operation remains available for one supported major before removal.

Migration procedure:

1. Add the new schema or operation without changing existing meaning.
2. Add conformance fixtures for old and new consumers.
3. Run compatibility analysis and both supported contract versions.
4. Introduce a translation adapter for any major-version boundary.
5. Keep the old major until consumers and durable records have migrated.
6. Remove it only through a separately approved public-contract change.

## Elder Reuse Boundary

The contracts reuse Elder semantics without coupling operations to internal Python objects:

| Factory result | Elder semantic source |
|---|---|
| context packet | `protocol/context-packet.schema.json` |
| bounded delegation | `protocol/delegation.schema.json` |
| checkpoint | `protocol/checkpoint.schema.json` |
| evidence bundle | `protocol/evidence-bundle.schema.json` |
| telemetry event | `protocol/telemetry-event.schema.json` |
| action and command evidence | `protocol/agent-action.schema.json` |

These are semantic references. A concrete adapter must translate and validate both sides; schema
names alone do not prove direct wire compatibility.

## Conformance Evidence

Foundation fixtures fail closed for:

- incompatible major versions;
- mutation without idempotency;
- accepted response claimed as completed;
- contradictory disposition, error, retry, or mutation state;
- provider-specific canonical contract identity;
- wrong per-operation request or result fields;
- unknown event types or invalid event source planes;
- restricted inline event payload;
- stale cursor without a refresh cursor;
- stale refresh cursor on the wrong stream or moving backward;
- uncertain mutation configured for direct retry.

The fake worker adapter Component tests cover:

- success;
- rejection;
- pre-dispatch timeout;
- duplicate idempotent replay;
- stale cursor refresh;
- uncertain mutation reconciliation.
- governance authority-result source binding;
- integration projection acknowledgement binding.

## Limitations

- This is a ratified Phase 1 contract and conformance layer, not an implemented operations API.
- No production operations service, journal store, queue, dispatcher, provider adapter, API,
  integration endpoint, or owner UI exists from this task.
- Fake-adapter tests do not prove process restart, network partition, database durability,
  provider behavior, or hosted interoperability.
- Integration, Workflow, and Stress evidence remain future tasks.
- No maturity, qualification, certification, autonomy, approval, promotion, merge, release, or
  deployment authority is created.

## SF-004 Handoff

The Mastra operations spike must evaluate candidate implementations behind these contracts. It
must not adopt provider stages, dispatcher records, retries, cursors, or pending-start semantics
that conflict with this source-of-truth, idempotency, uncertainty, redaction, or authority model.
