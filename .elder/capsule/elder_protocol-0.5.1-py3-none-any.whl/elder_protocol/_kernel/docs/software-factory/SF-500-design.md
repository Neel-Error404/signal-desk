# SF-500 Learning Trajectory Design

**Status:** VERIFIED

## Composition

```text
existing operational source adapters
-> digest-bound source manifest
-> binding, trust, time, and evidence validation
-> structured-fact redaction
-> duplicate and collision handling
-> required/anchor preservation
-> deterministic optional-event sampling
-> explicit outcome and missing-link reconstruction
-> immutable normalized trajectory artifact
```

The normalizer does not crawl databases or runtime files. Existing adapters
select source records and supply structured facts plus canonical source
digests. This keeps source ownership with the current journal, evidence,
context, telemetry, owner-decision, and incident boundaries.

## Trust And Binding

Each source binds:

- project, work item, and optional run;
- occurrence and recording time;
- producer and an opaque URI-like source reference;
- primary, secondary, historical, or candidate authority;
- at least one evidence identifier and digest;
- a canonical digest of the exact structured facts.

Candidate-authority records never become trusted trajectory events. A required
candidate source fails closed; an optional one is recorded as excluded.

## Redaction

The artifact never needs raw prompts, responses, messages, transcripts, or
free-form output. Raw-content key families are omitted, and every
whitespace-bearing free-text string is omitted regardless of nesting. Secret
field names, known secret values, secret-reference schemes, and oversized
strings are handled the same way. Compact structured labels, identifiers,
references, statuses, and token-count metrics remain available.

The source digest still binds the original structured source object, while the
event digest binds the safe normalized representation.

## Deterministic Sampling

The source file is read through a hard 2 MiB byte bound before parsing.
`required-anchor-hash-rank-v1` always retains:

- required sources;
- explicit source anchors;
- owner corrections;
- incidents;
- outcomes;
- declared blocked, failed, rejected, stale, uncertain, or waiting states.

Optional events are ranked by a hash over the order-independent source
snapshot, event identity, and event digest. Selection stops at the declared
event and byte limits. Source order and evidence-array order are semantically
irrelevant. Every omitted source has an explicit reason.

## Outcome Delay

Completed work, passing tests, or assembled retrieval do not imply a business
outcome. An outcome attaches only when an explicit outcome event names the
expected reference and records `met` or `missed`. Every expected reference must
be completely measured before the trajectory reports an attached outcome.
Unknown, missing, partially measured, mismatched, or contradictory measurements
remain visible and non-inferential, with one delayed link per unresolved
expected reference and one contradiction diagnostic per conflicting reference.

## Non-Claims

SF-501 through SF-507, Prime refinement, trigger detection, typed proposal
creation, replay, evaluation, approval, target application, learning
monitoring, retrieval quality, and Gate F qualification are not implemented.
Canonical Elder maturity remains L1.
