# SF-403 Task Packet

**Status:** VERIFIED

## Outcome

Work-item completion depends on ordered, linked, current test and evaluator
proof.

## Scope

- derive required test levels from the current work-item evidence plan;
- bind the plan to the SF-402-authorized child and exact Git diff;
- ingest results only in Foundation through Stress order;
- verify commands, timestamps, traces, artifact bytes, and one diff digest;
- request and record one independent advisory evaluation;
- issue one completion packet for the existing transition engine;
- expose progress and blockers through an owner read model.

SF-404 supervised delivery is outside this task. Canonical maturity remains L1.

## Acceptance

1. A current SF-402 lease and context are required to create a test plan.
2. Lower test levels must pass before higher levels are accepted.
3. Every result binds the immutable command, current diff, trace digest, and
   exact artifact bytes.
4. Stale results, changed diff, changed artifacts, and secret-shaped traces
   fail closed.
5. Completion requires all planned tests and a passing independent evaluator.
6. The completion packet supplies exact validated-evidence and outcome
   references to the existing human completion transition.
7. Plan, results, evaluation, completion, and owner view survive restart.
8. Exact concurrent result ingestion converges to one durable result.

## Failure Conditions

- failed lower level;
- out-of-order or unplanned command;
- stale result;
- changed diff after plan or test;
- missing or changed artifact;
- missing, non-independent, or non-passing evaluator;
- secret-shaped trace;
- request or result identifier collision.
