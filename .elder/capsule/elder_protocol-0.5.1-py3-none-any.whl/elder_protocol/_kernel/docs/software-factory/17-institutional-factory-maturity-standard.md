# Institutional Factory Maturity Standard

**Status:** RATIFIED by ADR 0022

**Standard:** `elder-factory-maturity-standard` version `1.0.0`

**Effective date:** 2026-08-14

**Ratifying ADR:** `ADR-0022`

## Purpose

Provide stable institutional meanings and evidence thresholds for L2 and L3.
The machine-readable source is
`protocol/operational-maturity.json`; this document explains that source
without replacing it.

## Resolution Rule

The whole-factory level is the minimum verified level across every mandatory
dimension:

1. product intake and planning;
2. worker execution and isolation;
3. security and supply-chain integrity;
4. testing, evidence, and evaluation;
5. delivery and production authority;
6. reliability, recovery, and incidents;
7. owner visibility, outcomes, and economics;
8. learning and long-term quality.

Promotion is cumulative, exact-revision and exact-environment bound,
independently evaluated, contradiction-free, time-bound, and human-ratified.
No average score can compensate for a missing mandatory control.

## L2 - Hosted Supervised Delivery

An authenticated bounded work item can reach an exact reviewable pull request
through real hosted controls. Humans review and approve the pull request and
retain merge, release, deployment, certification-renewal, and maturity
authority.

The institutional minimum is:

- at least 30 days of observation;
- at least 20 real hosted work items;
- at least 90 percent reach a reviewable pull request without raw database,
  internal runtime-file, or background-terminal inspection;
- 100 percent external identity, trace, ordered-test, and provenance coverage;
- zero authority escapes and zero secret exposures;
- worker crash, duplicate intake, broker or CI outage, provider uncertainty,
  and backup/restore exercises;
- a current signed cumulative L0-L2 bundle, exact-revision work history,
  enforced checks, provenance, independent review, and human ratification.

L2 does not permit autonomous merge, release, deployment, maturity mutation,
or certification renewal.

## L3 - Bounded Production Operation

One explicitly certified reversible low-risk class can move from a trusted
signal through immutable artifact creation, bounded canary, trusted
observation, and automatic rollback. Humans define and certify the class and
retain scope expansion, full rollout, release, certification-renewal, and
maturity authority.

The institutional minimum is:

- at least 30 days of observation;
- at least 20 real bounded canaries;
- at least three injected rollback exercises;
- 100 percent threshold-breach rollback conformance;
- zero automatic full rollouts and zero authority escapes;
- telemetry-loss, provider-uncertainty, restart-during-rollback, and
  incident-budget suspension exercises;
- a current signed cumulative L0-L3 bundle, exact class certification, real
  canary and observation history, rollback and incident evidence, independent
  review, and human ratification.

L3 does not permit general product autonomy, uncertified class expansion,
automatic full rollout, maturity mutation, or certification renewal.

## Current Assessment

Canonical Elder maturity remains L1. The local factory has substantial L2 and
L3 mechanisms, but current hosted L2 operation and real bounded production L3
evidence are not established.

## Change Control

Changing the dimensions, authority boundary, quantitative gate, evidence
rule, or standard version requires a new constitutional ADR, explicit human
approval, updated deterministic validation, graph regeneration, and a new
standard version. The complete machine-readable standard payload is bound to
its version by `content_sha256`; changing descriptive text, controls,
exercises, evidence requirements, dimensions, dates, or benchmarks without a
new version fails protocol validation.
