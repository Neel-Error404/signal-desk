# SF-301 - Product Portfolio And Work Board

**Status:** VERIFIED

**Date:** 2026-08-14

**Change class:** bounded local owner read model and control-room presentation

**Owner:** factory operations

**Approver:** human repository owner

**Depends on:** verified SF-300 commit
`4cf4bbb1b475b8dc497fad238671c30f056e16aa`

## Outcome

An authenticated owner can switch among every factory in the client's exact
project grants and inspect real work-item stages, priorities, dependencies,
blockers, projection freshness, and current backlog counts through one
responsive local control-room board.

## Non-Goals

- SF-302 work-room detail, messaging, diff, artifact, or terminal views;
- SF-303 approval, escalation, or other decision mutations;
- changing canonical product, work-item, projection, or authority state;
- hosted access, tenant routing, push notifications, or mobile applications;
- replacing the work-item ledger or projections with UI-owned state.

## Required Guarantees

- the portfolio includes exactly the authenticated client's project grants;
- every product summary and work item is derived from validated current stores;
- dependency blockers resolve against exact current work-item state;
- product and board counts are deterministic across replay and restart;
- large backlogs are filterable and cursor-paged;
- stale cursors fail explicitly and the UI refreshes from current truth;
- credentials remain in browser memory and are never written by the UI;
- live refresh never grants mutation authority.

## Test Plan

1. Foundation: closed schema, digest, ordering, secret rejection, route contract.
2. Component: filters, dependencies, counts, cursor binding, and stale cursor.
3. Integration: API authorization and current projection binding.
4. Workflow: real loopback control room loads and refreshes the board.
5. Stress: large backlog paging and concurrent stable reads.

## Completion Gate

SF-301 closes only after the test ladder, desktop and mobile browser checks,
focused implementation review, package verification, evidence update,
Obsidian milestone update, and a separate commit. Gate D remains open.
