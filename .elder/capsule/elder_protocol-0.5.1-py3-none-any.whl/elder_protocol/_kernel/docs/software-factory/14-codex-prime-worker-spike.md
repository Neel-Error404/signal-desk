# Codex And Prime Worker Spike

**Status:** VERIFIED for the bounded SF-005 spike

**Task:** SF-005 - Codex And Prime Worker Spike

**Decision:** Codex is the primary worker runtime. Prime Agent is a deferred optional
execution-continuity sidecar, not factory authority.

**Authority:** ADR 0021 ratifies Codex-primary and Prime-deferred architecture. This spike does
not add a runtime dependency or amend Elder authority.

## Outcome

The SF-003 worker contract can represent fake, Codex, and Prime-style worker behavior without
making provider objects canonical factory state.

The disposable conformance harness exercised the same workflow for all three profiles:

```text
prepare
-> start
-> prompt
-> duplicate prompt
-> steer
-> lost provider response
-> checkpoint
-> observe
-> detach
-> adapter restart
-> recover
-> reconcile
-> cancel
-> collect evidence
```

Each profile preserved one side effect per command, returned `duplicate` for a replayed completed
mutation, returned `uncertain` for a provider-accepted command whose response was lost, reconciled
that command after restart, advanced the worker-session generation, emitted canonical events, and
produced digest-bound evidence.

The Codex and Prime profiles use distinct provider-translation requests, but provider execution
is simulated. The conformance result proves the factory translation and recovery boundary, not
real Codex or Prime execution. Real interface probes were run separately without a model-provider
request.

## Runtime Decision

### Codex: Primary

Use Codex as the primary implementation worker behind a factory-owned adapter.

The installed `codex-cli 0.146.1` provides:

- native Windows x64 execution;
- persisted session and thread identifiers;
- explicit workspace binding;
- non-interactive JSONL output;
- resume by session identifier;
- final-message and output-schema files for bounded batch jobs;
- an experimental app-server v2 protocol with `thread/start`, `thread/resume`, `turn/start`,
  `turn/steer`, and `turn/interrupt`;
- structured thread, turn, item, approval, tool, process, diff, and completion notifications.

The first production Codex adapter should prefer the version-pinned app-server v2 protocol for
interactive work because it has explicit start, resume, steer, interrupt, and notification
surfaces. `codex exec --json` remains a useful batch fallback and diagnostic surface. It is not
sufficient by itself for durable same-turn steering or exactly-once command delivery.

Codex thread IDs, turn IDs, item IDs, rollout paths, session names, configuration names, and
provider credentials remain opaque adapter references. The factory owns work-item identity,
command identity, idempotency, checkpoints, event sequence, evidence, cancellation disposition,
and recovery state.

### Prime Agent: Optional And Deferred

Do not add Prime Agent as a canonical dependency in Phase 1.

Prime has strong mechanisms worth adapting:

- one worker per root session tree;
- process-safe session leases;
- supervisor and worker recovery;
- generation-aware event cursors and recovery snapshots;
- append-only command recovery journals;
- explicit uncertain-mutation handling without blind replay;
- persistent goals, schedules, heartbeat prompts, messages, and restart manifests;
- separate refinement proposal and application mechanics.

Its bounded future role is an optional supervised local or hosted-Linux continuity sidecar for
approved long-running work. SF-204 may implement an adapter only if SF-006 ratifies that role and
the later task proves Windows or hosted-Linux operation, credential isolation, event translation,
lease binding, and refinement interception.

Prime must not own canonical work items, legal transitions, Elder leases, authority, credentials,
evidence, trusted memory, learning promotion, or release decisions.

## Codex Interface Findings

### Stable Batch Surface

`codex exec` supports:

```text
codex exec --json -C <workspace> <prompt>
codex exec resume <session-id> --json <follow-up>
```

Useful controls include `--output-schema`, `--output-last-message`, `--ephemeral`,
`--ignore-user-config`, explicit sandbox selection, and explicit approval selection.

The adapter must not use `--ephemeral` when restart recovery is required.

JSONL output is an observation stream. A closed pipe, killed process, or missing final event does
not prove whether a provider-side effect occurred. A lost response therefore maps to
`command.uncertain`, and the factory must reconcile the persisted session, turn, item, diff,
workspace, and evidence before any retry.

### Interactive Control Surface

The generated app-server v2 schemas expose the control primitives needed by the worker contract:

| Worker need | Codex app-server surface |
|---|---|
| start session | `thread/start` |
| prompt/follow-up | `turn/start` |
| live steering | `turn/steer` |
| interrupt active work | `turn/interrupt` |
| reattach | `thread/resume` |
| inspect state | thread read/list/turn and item notifications |
| workspace binding | `cwd` and workspace roots |
| approval and sandbox binding | per-thread and per-turn policy fields |

The app-server protocol is experimental and must be isolated behind a versioned translation
adapter. The installed Windows build can run the app server, but managed app-server daemon
lifecycle reports Unix-only support. Phase 1 must therefore own the Windows process lifecycle or
run the worker in a separately validated hosted-Linux environment.

### Effective Policy Binding

The repository project config declares:

```toml
approval_policy = "on-request"
sandbox_mode = "workspace-write"

[sandbox_workspace_write]
network_access = false
```

The machine-level config and historical thread rows can contain weaker settings. A worker adapter
must therefore:

1. pass the approved workspace, approval policy, sandbox policy, network policy, and additional
   roots explicitly;
2. reject dangerous bypass flags;
3. inspect the started or resumed thread's effective settings;
4. fail closed when the effective settings differ from the authorized packet;
5. record the verified settings in evidence.

Reading one config file is not proof of effective runtime policy.

### Codex Gaps Owned By The Factory

The inspected public CLI does not expose a factory idempotency key, durable command
acknowledgement, provider-independent checkpoint operation, or exactly-once replay guarantee.

The factory must supply:

- durable command acceptance before invocation;
- idempotency scoped by contract, operation, project, and key;
- normalized event IDs and cursors;
- transcript and diff evidence;
- explicit uncertain state and reconciliation;
- restart generation and fencing;
- owner-visible cancellation and waiting state;
- session-to-work-item and workspace binding.

The spike enforces the approved workspace, `on-request` approval, `workspace-write` sandbox, no
network, no additional roots, opaque credential reference, and disabled provider refinement
before creating a prepared run. It rejects policy drift before provider translation. A production
adapter must additionally read back and verify the effective Codex thread settings.

## Prime Interface Findings

The inspected snapshot is commit `b9a4461149419156599d60174dddf15458e2b9ee`, package version
`0.7.0`, under the MIT license. It requires Node `>=22.8.0`; the machine has Node `v24.14.0`.
Snapshot dependencies were not installed and the runtime was not started.

### Continuity Strengths

Prime's daemon protocol records mutating commands by `clientId + commandId` before dispatch.
Completed duplicates return the recorded result. A received command without a durable result is
reported as uncertain and is not replayed.

Worker event streams use generation-plus-sequence cursors and recovery snapshots. A generation
change invalidates direct sequence comparison, so a client must reconcile from the snapshot.

Session leases bind the canonical session-file path to process and token information. Goals,
schedules, heartbeat prompts, messages, restart manifests, and recovery journals provide useful
long-running execution continuity.

### Prime Boundaries

Prime concepts that remain provider-local:

- JSONL conversation trees;
- daemon `activeSessionId`;
- client and command IDs;
- worker generations and lower-level RPC events;
- goals, schedules, heartbeats, and messages;
- local `auth.json`;
- continual-harness entries and global refinement scope.

Lower-level RPC events do not provide the canonical event identity and replay guarantees required
by SF-003. Prime events are adapter observations and must be re-identified, normalized, persisted,
and correlated by the factory.

Prime process separation is same-OS-user coordination, not a tenant or security boundary.
Credentials are host-local application credentials, not an Elder secret broker.

Prime refinement can target local or global state. Even though proposal and application are
separate internally, that mechanism is not Elder approval. The adapter must redirect every
refinement into an immutable Elder learning candidate and forbid direct local or global
application.

### Windows Boundary

Prime requires a Bash-compatible shell on Windows and searches a configured path, Git Bash,
Cygwin/MSYS2, or WSL. Native PowerShell execution is not established by the inspected source.

A future Prime adapter must select and verify one of:

- a supported Git Bash boundary with exact path and process behavior;
- WSL with explicit workspace and credential mapping;
- a hosted-Linux worker.

Until that verification exists, Prime is not a Phase 1 worker.

## Worker Contract Mapping

| SF-003 operation | Codex translation | Prime translation | Factory-owned control |
|---|---|---|---|
| `prepare` | validate workspace and effective config inputs | validate session/workspace and shell inputs | authority, context digest, run identity |
| `start` | app-server `thread/start` and `turn/start` | daemon/RPC session start | durable acceptance and idempotency |
| `send` | `turn/start` or `turn/steer` | journaled daemon command | command identity and duplicate suppression |
| `observe` | normalize app-server notifications or JSONL | normalize daemon snapshot and events | canonical event IDs, sequence, cursor |
| `checkpoint` | factory snapshot of thread, turn, diff, and evidence refs | factory snapshot of Prime session and cursor | checkpoint digest and generation |
| `cancel` | `turn/interrupt`, then owned-process termination if needed | RPC abort/cancel and lease reconciliation | cancellation disposition and side-effect review |
| `recover` | `thread/resume` plus evidence reconciliation | snapshot attach plus journal/lease recovery | generation fencing and uncertainty resolution |
| `collect-evidence` | transcript, events, diff, tests, config, exit state | session, journal, events, artifacts, exit state | evidence bundle and verdict |

Neither provider receives canonical write authority.

## Conformance Spike

Disposable implementation:

- `.tmp/software-factory/sf005_worker_spike.py`
- `.tmp/software-factory/test_sf005_worker_spike.py`
- `.tmp/software-factory/sf005-runtime-probe.json`
- `.tmp/software-factory/sf005-conformance-report.json`
- `.tmp/software-factory/sf005-process-stage-one.json`
- `.tmp/software-factory/sf005-process-stage-two.json`
- `.tmp/software-factory/codex-app-server-schema-v01461/`

The harness persists provider-neutral session, command, event, checkpoint, and idempotency state
before acknowledging mutations. It creates a deterministic provider receipt, injects a lost
response, restarts the adapter, reconciles the receipt, and verifies that the provider effect
count remains one.

A separate integration check executes stage one and stage two in different Python processes. The
second process recovers generation 2 from the durable state, resolves the original uncertain
command as a duplicate, and confirms that its provider effect count remains one. Recovery accepts
only the persisted checkpoint cursor, rotates the event stream to generation 2, and emits the
recovery event in that new generation. An old-generation observer receives the canonical
`stale-cursor` disposition with a generation-2 refresh cursor rather than an untyped failure.
Same-generation cursors beyond the durable sequence are rejected, and mutation identity is stored
under the SF-003 scope of contract, operation, project, and idempotency key.

The normalized journal includes `command.uncertain` before reconciliation and
`command.cancelled` when the deferred steering command is cancelled. Codex translation uses
`thread/start`, `turn/start`, `turn/steer`, `thread/resume`, and `turn/interrupt`; Prime
translation uses separate daemon session, command, attach, and abort requests. Direct Prime
refinement application and weaker workspace or sandbox policy are rejected by focused tests.

This proves contract representability and adapter recovery logic. It does not prove real model
execution, hosted process durability, provider-side exactly-once behavior, production credential
isolation, or multi-worker safety.

## Architecture Ratification Record

ADR 0021 ratified these recommendations on 2026-08-08:

1. Codex is the primary Phase 1 worker.
2. The production adapter is factory-owned and version-pinned.
3. App-server v2 is the preferred interactive control surface; `exec --json` is a batch fallback.
4. The factory owns commands, idempotency, checkpoints, event normalization, evidence, and
   uncertainty.
5. Codex effective workspace, approval, sandbox, and network settings are explicitly supplied and
   verified.
6. Prime is deferred to SF-204 as an optional supervised continuity sidecar.
7. Prime refinement can only produce Elder learning candidates.
8. Prime Windows or hosted-Linux execution requires a separate operational and security proof.

## Limitations

- No model-provider request was made.
- No credential value was read, copied, or serialized.
- Prime dependencies were not installed and Prime was not executed.
- Codex app-server schemas prove an installed protocol surface, not its production stability.
- Windows managed app-server daemon lifecycle is unsupported in the installed Codex build.
- The adapter code is disposable and must not be promoted directly into production.
- No architecture approval, maturity increase, qualification, deployment, or release authority is
  created.
