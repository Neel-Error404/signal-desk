# SF-606 Institutional L2 Qualification Design

**Status:** IMPLEMENTED

**Date:** 2026-08-15

## Composition

```text
ratified ADR-0022 institutional standard
+ current signed cumulative hosted bundle
+ asserted exact-revision hosted work history
+ current control and failure-exercise evidence
+ eight mandatory dimension assessments
+ asserted independent review, ratification, and contradiction set
-> deterministic advisory institutional report
-> explicit blockers and future authority checklist
```

P4.7 remains the cryptographic cumulative evidence evaluator. SF-606 does not
replace or reinterpret its signatures. It replays that bundle, compares its
source revision, project, and environment to the institutional packet, then
evaluates the additional ADR-0022 thresholds. Packet work history, controls,
exercises, dimensions, review, ratification, and contradiction entries are
classified as unverified caller assertions. They are useful for deterministic
diagnosis but cannot qualify L2.

## Derived Metrics

The evaluator derives, rather than accepts, these values:

- observation days from packet timestamps;
- real hosted work-item count from raw item records;
- reviewable-PR basis points from hosted, authenticated, bounded work that
  reached a pull request without internal inspection;
- identity, trace, ordered-test, and provenance coverage basis points;
- authority-escape and secret-exposure counts.

Empty history produces zero coverage and zero reviewable-PR basis points.

## Fail-Closed Layers

The future authority-capable qualification requires every layer:

1. current exact-revision cumulative L0-L2 bundle;
2. six quantitative thresholds;
3. ten required controls;
4. five required failure exercises;
5. all eight mandatory dimensions verified at L2;
6. six promotion-evidence requirements;
7. no active contradictions;
8. explicit human ratification.

No average score can offset a failed layer.

SF-606 intentionally does not implement the provider evidence format needed
to prove those layers. Its evaluator always adds
`institutional-qualification:provider-bound-evidence-not-implemented`, always
returns `qualified: false` and `ready_for_human_ratification: false`, and
reports the current canonical level.

## Authority Boundary

The report is diagnostic-only and always returns false for qualification,
ratification readiness, merge, release, deployment, certification renewal,
maturity mutation, and authority grant. Caller-supplied status fields,
signatures, history, or contradictions cannot change that boundary. Canonical
L2 promotion and project-specific L2 supervised-PR activation require
separate future mechanisms and accountable actions described in the
checklist.

Canonical Elder maturity remains L1.

## Current Exercise

The checked-in exercise uses the current exact SF-605 revision and the only
available signed L2 bundle. That bundle is valid but historical. Current
controls and exercises remain blocked because no exact-revision hosted
production run or 30-day work history exists.

The exact current report contains 42 blockers. Its historical bundle replay
is valid, but that replay is advisory, revision-mismatched, and insufficient
for institutional authority.

Do not begin Phase 7.
