# Gate E Governed Local Factory Qualification Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Boundary

Gate E composes verified Phase 4 services. It does not add another context,
authority, evidence, qualification, autonomy, or delivery implementation.

```text
accepted local issue
-> SF-400 exact work-item classification
-> SF-400 boundary-backed SF-401 context packet
-> SF-402 assigned-child authority and lease
-> SF-403 ordered test, artifact, and evaluation completion
-> SF-404 existing P5.2 lease and exact delivery packet
-> durable product-owner submit decision
-> exact supervised pull-request response
```

## Durable Reconstruction

The workflow reconstructs these service objects from their existing durable
stores:

- `GovernedContextAssembly`;
- `AuthorityDelegationIntegration`;
- `EvidenceTestPipeline`;
- `SupervisedDeliveryService`.

Reconstruction occurs before packet creation, before owner submission, and
after the accepted provider response. The owner trace is rebuilt only through
public verification and owner-view methods. Test setup may construct the
isolated fixture, but the proof does not query raw database rows.

## Owner Trace

The trace records:

- work-item objective and project;
- SF-400 classification result and decision digest;
- context packet identity and digest;
- current authority request, condition, and decision digest;
- evidence plan, completion condition, and completion digest;
- delivery status, reason, packet digest, and response digest;
- explicit false merge, deploy, and maturity-mutation capabilities.

The trace has one canonical digest so concurrent post-restart reads can be
compared semantically.

## Required Failure Matrix

### Expired Authority

Advance the delivery clock beyond the assigned-child lease, then request packet
creation. SF-402 revalidation must stop the flow and SF-404 must persist a
blocked attention state containing the expiry reason.

### Stale Context

Change one required repository source after authorization. SF-401 use-time
verification must stop SF-402 execution revalidation, and SF-404 must persist
the source-change reason.

### Missing Evidence

Remove one exact artifact after SF-403 completion. Completion revalidation must
stop packet creation and expose the missing artifact in the owner delivery
view.

### Unauthorized Transition

Submit an SF-402 start request from an identity other than the declared parent.
The durable SF-402 owner view must expose a rejected, attention-required,
owner-visible reason.

## Limits

- current hosted qualification, branch controls, and provider identity are
  signed fixtures, not live hosted operation;
- restart means reconstruction of all local service objects over the same
  stores, not host failure;
- no merge, release, deployment, learning, production telemetry, or Phase 5
  behavior is included;
- Canonical Elder maturity remains L1.
