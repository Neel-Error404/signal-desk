# Gate D Qualification Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Scope

This runbook qualifies one authenticated local owner workflow across the
visible inbox, portfolio, Work Room, audit, and metrics surfaces. It records
one exact follow-up, restarts the operations API, and verifies durable
reconstruction without owner database or terminal inspection.

## Ordered Test Ladder

Run one level at a time:

1. Foundation contract and static composition.
2. Component read-model composition.
3. Integration authenticated action and API restart.
4. Workflow real Chrome desktop/mobile and API process restart.
5. Stress deterministic post-restart concurrent reads.

When a level fails, record the root cause, correct it, and rerun that same
level before advancing.

## Commands

### Foundation

```powershell
py -m unittest tests.foundation.test_gate_d_qualification_contract -v
```

### Component

```powershell
py -m unittest tests.component.test_gate_d_qualification -v
```

### Integration

```powershell
py -m unittest tests.integration.test_gate_d_qualification -v
```

### Workflow

```powershell
py scripts/qualify_gate_d_browser.py
```

### Stress

```powershell
py -m unittest tests.stress.test_gate_d_qualification_concurrency -v
```

## Expected Browser Assertions

- authenticated owner inbox shows a high-severity owner-decision item;
- the item states that execution is waiting and the workflow cannot continue
  without owner input;
- owner opens the exact Work Room from the portfolio;
- objective, running work-item state, waiting run state, activity, audit,
  metrics, and unavailable
  cost/learning data are visible;
- owner submits one follow-up and observes one pending durable owner control;
- the first API process exits and a second process starts on the same port;
- process identifiers differ and runtime generation increments;
- after reload and reauthentication, the follow-up remains visible;
- audit replay remains verified and metrics show the added intervention;
- desktop `1280x800` and mobile `390x844` have no page-level or descendant
  overflow;
- no console warning/error, page error, or failed API response is recorded.

## Results

- Foundation: `2 passed`; JavaScript syntax and Python compilation passed.
- Component: `1 passed`.
- Integration: `1 passed`.
- Workflow: real Chrome passed with `14` successful API responses, process IDs
  `27584 -> 27968`, runtime generation `1 -> 2`, audit
  `journal 56 / replay verified`, owner interventions `0 -> 1`, no console,
  page, or API errors, and zero desktop/mobile overflow.
- Stress: `1 passed` across eight concurrent post-restart semantic reads.
- Retained SF-302 static workflow regression: `1 passed`.
- Elder protocol validation, Python compilation, JavaScript syntax, and
  `git diff --check` passed.
- The final wheel and source archive built successfully. The wheel installed
  into a fresh target and, from outside the checkout, exposed the control-room
  inbox assets, Gate D documents, and Gate D focused tests.
- Wheel SHA-256:
  `a111fca6bc92b7df7a224aaaf27a3b11dfbe912df5e508c2fc3214eebbd9e06f`.
- Source archive SHA-256:
  `486108d668a613101c38d67bc1d70be349c50a87216d7c5d227f5f6e970223b2`.

## Corrections

Prequalification finding:

- the SF-300 owner inbox route existed but the control room did not request or
  render it;
- the correction adds a read-only inbox band over the existing route and links
  attention to the existing Work Room.

No SF-400, hosted, billing, learning, deployment, or protected-protocol change
is included.
