# Gate D Supervised Local Factory Qualification Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Boundary

Gate D composes the verified Phase 3 capabilities. It does not create another
work-item lifecycle, decision store, audit journal, metrics source, or command
path.

```text
owner inbox attention
        |
        v
portfolio -> Work Room -> existing SF-203 follow-up admission
                 |                    |
                 +-> approvals        +-> durable session control
                 +-> audit
                 +-> metrics
                 |
          operations API restart
                 |
                 v
        same owner-visible reconstruction
```

## Qualification Fixture

The bounded fixture creates one existing SF-203 running run, then applies the
existing `wait` control so the run becomes `waiting` while the canonical work
item remains `running`, as defined by the existing contract. The resulting
inbox item has the canonical `owner-decision` reason, consequence, evidence,
and action policy. The Work Room displays both the work-item and run states.

The fixture uses:

- one operations store;
- one session-control store;
- one recovery store;
- one current workspace binding;
- one exact project-scoped owner identity;
- the existing owner inbox, portfolio, Work Room, audit, and metrics routes.

No fixture record is canonical outside the qualification workspace.

## Control-Room Correction

The prequalification review found that SF-300 exposed attention only through
its authenticated JSON route. The control room did not request or render that
data, so the composed Gate D owner experience was incomplete.

The correction adds one read-only inbox band to the existing control room:

- it calls the existing `owner-inbox-get` route;
- it renders canonical reason, consequence, severity, age, evidence count,
  and allowed action identifiers;
- it links an attention item with a work-item identity to the existing Work
  Room;
- route or source failure is shown explicitly as unavailable;
- it performs no mutation and grants no action authority.

## Owner Action

The owner opens the waiting work item and submits one `follow-up` through the
existing Work Room form. The request binds:

- project and work-item identity;
- exact current run and worker session;
- current workspace binding;
- the visible waiting control as `continuation_of`;
- authenticated owner identity;
- one idempotency key and payload digest.

The qualification requires the resulting session-control record to be visible
after refresh and after API restart. Worker execution of the pending follow-up
is not required to prove owner control admission and durability.

## Restart Boundary

The browser workflow launches the operations API in one operating-system
process on a fixed numeric-loopback port, submits the owner action, terminates
that process cleanly, and launches a second process over the same durable
stores and port.

The proof requires:

- different process identifiers;
- runtime generation increment by one;
- the same project, work item, run, waiting control, and owner follow-up;
- successful authenticated reads after restart;
- valid audit replay and metrics reconciliation.

## Owner-Only Evidence

The recorded owner journey uses only:

- the authentication dialog;
- owner inbox and portfolio;
- Work Room controls;
- refresh;
- audit and metrics panels.

The harness may create and verify the isolated fixture, but the owner-facing
proof does not expose or require database queries, internal runtime files, or
background terminal history.

## Limits

- local single-owner qualification only;
- no hosted durability, remote identity, tenant isolation, production
  telemetry, billing, priced cost, or learning impact;
- restart is an operations API process restart, not host failure;
- the accepted follow-up is durable but remains pending until a worker
  controller executes it;
- Gate D does not start SF-400 and does not alter canonical L1 maturity.
