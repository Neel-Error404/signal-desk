# SF-107 Test Reproduction

**Current status:** VERIFIED - local Gate B passes for the numeric-loopback,
single-active-process Phase 1 contract.

## Purpose

Reproduce SF-107 Factory API And Health and the Gate B process-restart proof in this order:

```text
Foundation -> Component -> Integration -> Workflow -> Stress
```

Stop at the first failure or timeout. Record the root cause, fix it, and rerun the same level
before advancing.

## Pinned Environment

```text
Date: 2026-08-12
Interpreter: Python 3.13.5
Branch: work/sf-107-factory-api-health
Base revision: 03d8a2e9152118e0ee9fb943e3f0ebb5c064b603
Route registry: 5111f8a7c068a38a08d156a6e3c566824654043deda907eeda79098eff6f44f6
Binding registry: 6eadfa070629eb99d7e699e4da52c25fbe591ddbdc710ddc01d819c5ae8b49b8
```

Use `py` from the repository environment.

## Runtime Ceilings

| Level | Failure ceiling |
|---|---:|
| Foundation | 15 minutes |
| Component | 45 minutes |
| Integration | 30 minutes |
| Workflow | 30 minutes |
| Stress | 60 minutes |
| Build and installed wheel | 45 minutes |

## Complete Ordered Ladder

Run each command separately:

```powershell
py -m unittest discover -s tests/foundation -v
py -m unittest discover -s tests/component -v
py -m unittest discover -s tests/integration -v
py -m unittest discover -s tests/workflow -v
py -W error::ResourceWarning -m unittest discover -s tests/stress -v
```

The one known Integration skip is the opt-in live Azure Mem0/Luna check. It requires
`ELDER_RUN_LIVE_MEMORY_TESTS=1` and is outside the local SF-107 contract.

## Focused SF-107 Commands

```powershell
py -m unittest tests.foundation.test_operations_api_design -v

py -m unittest tests.component.test_operations_api_auth -v
py -m unittest tests.component.test_operations_api_contracts -v
py -m unittest tests.component.test_operations_api_design_compatibility -v
py -m unittest tests.component.test_operations_api_health -v
py -m unittest tests.component.test_operations_api_projection_validation -v
py -m unittest tests.component.test_operations_api_reconciliation -v
py -m unittest tests.component.test_operations_api_server -v
py -m unittest tests.component.test_operations_api_store -v

py -m unittest tests.integration.test_operations_api_lifecycle -v
py -m unittest tests.integration.test_operations_api_mutations -v
py -m unittest tests.integration.test_operations_api_queries -v

py -m unittest tests.workflow.test_sf107_gate_b -v
py -W error::ResourceWarning -m unittest tests.stress.test_operations_api_concurrency -v
```

## Required Gate B Scenarios

The Workflow level must prove:

1. queued API dispatch survives hard API termination and restart;
2. claimant ownership survives API restart, expires deterministically after claimant loss, and
   fences stale ownership;
3. canonical commit followed by response loss reconciles exactly once;
4. offline projection rebuild reproduces all seven digests and rejects a stale token.

## Required Transport Regressions

The Component level must prove:

- unauthenticated, unauthorized, malformed, unknown-route, and wrong-method requests do not
  acquire scarce long-poll capacity;
- a request admitted before drain can finish;
- a fresh socket after drain receives `503 service-draining`;
- a second request on an existing HTTP/1.1 keep-alive connection after drain receives
  `503 service-draining` and `Connection: close`;
- runtime and health lease checks remain current during bounded waits.

## Stress Proof

Run Stress with `ResourceWarning` promoted to an error. The SF-107 slice covers:

- concurrent exact mutation replay;
- concurrent changed-key collision with one canonical winner;
- concurrent client and project isolation;
- bounded authenticated long-poll admission;
- append-driven event wake-up and cursor advance;
- monotonic runtime generations;
- slow-client isolation and oversized request handling;
- auth-policy drift and journal corruption.

## Closure Commands

```powershell
py -m elder_protocol.cli validate
py -m elder_protocol.cli skills validate
py -m compileall -q elder_protocol tests scripts
git diff --check
py -m build --no-isolation
py scripts/verify_installed_wheel.py
```

Record package hashes outside packaged documentation:

```powershell
Get-FileHash dist\elder_protocol-0.5.1-py3-none-any.whl -Algorithm SHA256
Get-FileHash dist\elder_protocol-0.5.1.tar.gz -Algorithm SHA256
```

## Verified 2026-08-12 Record

Complete pre-final ladder:

```text
Foundation: 112 passed in 34.611s
Component: 284 passed across complete bounded batches
Integration: 50 run in 822.680s; 49 passed, 1 explicit live-Azure skip
Workflow: 22 passed in 399.214s
Stress: 32 passed in 809.936s; ResourceWarning fatal
```

Post-review transport delta:

```text
Focused keep-alive regression: passed in 23.142s
SF-107 Component: 36 passed in 308.152s
Workflow: 22 passed in 386.462s
SF-107 Stress: 8 passed in 286.975s; ResourceWarning fatal
Independent review: no current-scope BLOCKER or REQUIRED code finding
```

The worktree is intentionally unstaged and uncommitted. Staging and commit require explicit
human authorization.
