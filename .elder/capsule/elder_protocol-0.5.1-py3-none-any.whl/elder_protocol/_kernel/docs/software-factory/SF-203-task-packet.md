# SF-203 - Durable Session Control

**Status:** VERIFIED

**Change class:** bounded local worker-runtime implementation

**Owner:** factory operations

**Approver:** human repository owner

**Dependencies:** SF-105, SF-200, SF-201, SF-202

**Source revision:** `7b560e160ab3b0e61a39389d3f0eb82779705495`

## Outcome

One local owner or bound executor can durably submit, resume, pause, continue,
checkpoint, steer, and cancel a worker session. Accepted control survives an
operations-process restart, exact duplicates do not repeat effects, cursor
ordering is enforced, and uncertain external effects stop for later
reconciliation.

## Non-Goals

- goals, schedules, heartbeats, continuation budgets, or autonomous re-entry;
- automatic reconciliation of ambiguous provider effects;
- multiple concurrent workers or hosted brokers;
- owner control-room HTTP or UI routes;
- canonical checkpoint creation without Elder checkpoint evidence;
- changing SF-105 lifecycle authority or the SF-200 adapter contract;
- merge, release, deployment, or maturity changes.

## Required Reading

- `docs/software-factory/03-target-architecture.md`
- `docs/software-factory/05-task-execution-contract.md`
- `docs/software-factory/16-phase-proportional-delivery-rule.md`
- `docs/software-factory/SF-200-implementation-directive.md`
- `docs/software-factory/SF-201-design.md`
- `docs/software-factory/SF-202-design.md`
- `docs/software-factory/evidence/SF-202.md`
- `factory/factory-domain.json`
- `factory/factory-contracts.json`
- `factory/operations/run-lifecycle-authority-mapping.json`
- `elder_protocol/factory_operations/run_controller.py`
- `elder_protocol/factory_operations/durable_dispatcher.py`
- `elder_protocol/factory_operations/workspace_lifecycle.py`
- `elder_protocol/factory_workers/adapter.py`
- `elder_protocol/factory_workers/codex_worker.py`

## Current-State Inspection

The repository was clean at SF-202 commit `7b560e1`. Elder activation
`activation-elder-protocol-e9c211d24c034799` succeeded with L1 autonomy,
workspace-write isolation, on-request approval, and no sandbox network access.

Existing implementation already provides:

- SF-104 durable idempotent send delivery and uncertainty handling;
- SF-105 canonical run, worker-session, workspace, waiting, pause, cancel,
  checkpoint-reference, and generation transitions;
- SF-200 provider-neutral requests, responses, cursors, and command forms;
- SF-201 durable Codex thread and receipt observations;
- SF-202 exact leased workspace and sandbox binding.

The missing current-scope component is a durable coordinator that serializes
owner/executor session-control intent across those boundaries.

Baseline Foundation result:

```text
19 tests passed in 3.773s
```

No pre-existing failure was observed.

## Boundaries And Authority

- SF-105 remains the only canonical run/session/workspace authority.
- The session-control queue records execution intent and observations only.
- Worker responses remain evidence and cannot mutate canonical state directly.
- Product owners may request bounded session controls; the current delegated
  executor identity performs lifecycle transitions.
- The coordinator may call only the already-ratified SF-200 operations.
- External-effect ambiguity becomes `uncertain`; it is not blindly replayed.
- Protected protocol surfaces and accepted ADRs are outside the write set.

## Claim And Failure Conditions

Claim:

> A single local operations process can durably control one SF-105-bound worker
> session through exact SF-200 adapter operations and survive restart without
> losing accepted control or duplicating known effects.

Failure conditions:

- a duplicate control repeats an adapter effect;
- a stale session generation or mismatched run/workspace is accepted;
- an out-of-order event advances the durable cursor;
- an interrupted external step is replayed without reconciliation;
- pause, wait, resume, or cancel bypasses SF-105 transitions;
- a checkpoint cursor is fabricated or confused with canonical Elder evidence;
- cancellation silently discards an executing command;
- secrets or provider-specific authority enter the control record.

## Phase Proportionality

Current phase and gate: Phase 2 Worker Runtime, progressing toward Gate C.

Declared runtime: Windows local loopback, SQLite, one operations process, one
active worker command, one leased SF-202 workspace, one Codex worker.

Required guarantees: durable accepted controls, exact idempotency, serialized
execution, restart inspection, fail-closed uncertainty, bounded event cursor,
waiting continuation, and cancellation ordering.

Deferred guarantees: background scheduling and heartbeats to SF-205; automatic
effect reconciliation and worker reconciliation to SF-206; hosted concurrency
and identity to Phase 6.

Stop condition: do not introduce a broker, scheduler, background daemon, new
public adapter operation, or protected protocol change.

## Implementation Plan

1. Add closed schemas for the submitted control and durable record.
2. Add a local `DurableSessionController` with immutable history and one-command
   lease serialization.
3. Translate bounded controls into existing SF-105 lifecycle commands and
   SF-200 adapter requests.
4. Persist waiting reason, checkpoint observation, and ordered event cursor.
5. Recover interrupted local steps and fail interrupted external steps closed.
6. Add focused Foundation, Component, Integration, Workflow, and Stress proof.

## Test Plan

### Foundation

- schemas, exports, operation matrix, secret rejection, and dependency boundary.

### Component

- submit, exact duplicate, collision, claim, execution, waiting continuation,
  checkpoint cursor, stale generation, event order, restart, and cancellation.

### Integration

- SF-105 aggregate plus SF-200 fake worker plus SF-202 workspace binding;
- Codex adapter thread reattachment through a reopened controller.

### Workflow

- start, prompt, wait for owner, follow-up continuation, checkpoint, pause,
  resume, steer, cancel, restart, and retained evidence.

### Stress

- concurrent claims and cancel-versus-active-command ordering with spawned
  processes where practical.

## Rollback

The implementation is additive. Rollback removes the coordinator module,
schemas, tests, and documentation. Existing SF-105 through SF-202 stores and
contracts remain valid and unchanged.

## Completion Verdict

`VERIFIED`

Reason: the ordered test ladder, installed-wheel execution, package build,
protocol validation, and independent review pass for the declared local
scope. No current-scope `BLOCKER` or `REQUIRED` finding remains.
