# SF-302 - Work Room

**Status:** VERIFIED

**Date:** 2026-08-14

**Change class:** bounded local owner read model and durable owner input

**Owner:** factory operations

**Approver:** human repository owner

**Depends on:** verified SF-301 commit
`c3f684b0b2e9ec6c4b78358f1cd4e6a03fe14abc`

## Outcome

An authenticated owner can open one work item and inspect its plan, correlated
operational timeline, worker-session controls, checkpoints, test and diff
evidence, and artifacts. The owner can add a durable note or submit a bounded
SF-203 steering command without using a database or terminal.

## Non-Goals

- SF-303 approvals, escalation requests, decision expiry, or downstream
  approval transitions;
- a second run, session, workspace, checkpoint, artifact, or authority store;
- arbitrary shell, terminal, file-edit, merge, release, or deployment controls;
- hosted access, tenant routing, push notifications, or collaborative editing;
- storing browser credentials or exposing raw secret-shaped worker output.

## Required Guarantees

- the work item and every included run are bound to the authenticated project;
- the room is reconstructed from validated current operations and session
  records after refresh and process restart;
- owner notes are append-only, digest-bound, correlated, and exactly
  idempotent;
- steering commands become the existing durable SF-203 session-control record;
- command admission reuses the exact current SF-105 run and SF-202 workspace
  binding and never invents weaker authority;
- concurrent owner inputs create one record per exact idempotency identity;
- redaction rejects secret-shaped request and response material;
- missing or conflicting run/session/workspace context fails explicitly;
- the UI exposes only note, steer, follow-up, pause, resume, and cancel inputs.

## Test Plan

1. Foundation: closed schemas, digest checks, allowed operations, secret
   rejection, and route/binding contracts.
2. Component: room composition, exact note replay/collision, SF-203 command
   construction, correlation, ordering, and authorization failures.
3. Integration: authenticated API reads and mutation replay across restart.
4. Workflow: owner opens a room, adds a note, steers a run, refreshes, and sees
   the same durable context.
5. Stress: concurrent exact and distinct owner inputs remain complete and
   non-duplicated.

## Completion Gate

SF-302 closes only after the invalidated test ladder, desktop and mobile
browser checks, focused implementation review, package verification, evidence
update, Obsidian milestone update, and a separate commit. Gate D remains open.
