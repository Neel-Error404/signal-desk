# Third-Party Attribution Record

Create one section per approved external source use. Do not create an attribution record as a
substitute for license compatibility or owner approval.

## Source

- Source name:
- Upstream repository:
- Pinned commit:
- Exact upstream paths used:
- Package name and version, when applicable:
- License identifier:
- License evidence path:
- License evidence SHA-256:

## Approved Use

- Work item:
- Reuse method:
- Approval owner:
- Approval evidence:
- Files copied or extracted: none
- Dependency or fork:
- Independently implemented behavior:

## Obligations

- Copyright notices to preserve:
- License text or notice to distribute:
- Modification notices:
- Patent or trademark review:
- Path-specific or transitive-license review:

## Local Evidence

- Elder destination paths:
- Tests:
- Diff or artifact digest:
- Limitations:
- Revalidation trigger:
