# SF-XXX - Task Title

**Status:** PLANNED

**Change class:** ...

**Owner:** ...

**Approver:** ...

**Dependencies:** ...

**Source revision:** ...

## Outcome

State one observable result.

## Non-Goals

- ...

## Required Reading

- Elder files:
- Reference files and pinned commits:
- Prior task evidence:

## Current-State Inspection

Commands:

```powershell
git status --short --branch
py -m elder_protocol.cli session activate --project-root . --task "SF-XXX ..." --output .tmp/session-activation-SF-XXX.json
```

Observed implementation:

Observed tests:

Pre-existing failures:

## Boundaries And Authority

- Affected components:
- Protected surfaces:
- Allowed side effects:
- Forbidden side effects:
- Required approvals:

## Claim And Failure Conditions

Claim:

Failure conditions:

- ...

## Phase Proportionality

Current phase and gate:

Declared runtime and threat model:

Required current-scope guarantees:

Explicitly deferred later-phase guarantees:

Stop conditions for this task:

## Finding Disposition

| Finding | Acceptance clause | Reproduction or invariant | Disposition | Current action or later owner |
|---|---|---|---|---|
| ... | ... | ... | `BLOCKER`, `REQUIRED`, `DEFERRED`, `LIMITATION`, or `SPECULATIVE` | ... |

## Implementation Plan

1. ...

## Test Plan

### Foundation

- ...

### Component

- ...

### Integration

- ...

### Workflow

- ...

### Stress

- ...

## Evidence

- Changed files:
- Commands and results:
- Work item/run:
- Diff/artifact:
- Tests:
- Approvals:
- Limitations:

## Rollback

- ...

## Documentation And Handoff

- Docs updated:
- Operational runbook:
- Next task inputs:

## Completion Verdict

`PASS`, `PARTIAL`, `FAIL`, or `BLOCKED`

Reason:
