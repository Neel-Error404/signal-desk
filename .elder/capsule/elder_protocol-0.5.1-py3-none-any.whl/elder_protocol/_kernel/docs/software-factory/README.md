# Software Factory Operationalization Dossier

**Status:** ACTIVE IMPLEMENTATION GUIDANCE - Phase 0 ratified by ADR 0021

**Date:** 2026-08-07

**Authority:** This dossier does not amend Elder's constitution, maturity, authority, or accepted
ADRs. ADR 0021 separately ratified the Phase 1 operational architecture on 2026-08-08. Later
phase, infrastructure, maturity, autonomy, release, and deployment decisions remain separately
governed.

## Purpose

This dossier converts the current Elder Protocol into a buildable path toward an operational
software factory. It answers five questions:

1. Which capabilities already exist in Elder?
2. Which reference implementations should be reused, adapted, or rejected?
3. What operational components are still missing?
4. How should Prime Agent-style continual learning be combined with Elder's quarantined learning?
5. In what order should an agent implement the factory without losing control, evidence, or owner
   visibility?

The intended operating model is:

```text
owner intent and feedback
        |
        v
factory operations plane
        |
        +--> governed context and authority from Elder
        |
        +--> Codex or another worker through a worker adapter
        |
        +--> evidence, outcomes, and learning candidates
        |
        v
owner-visible result, approval, delivery, and measured learning
```

Elder is not the universal executor. Codex and other coding harnesses execute work. Elder supplies
the contracts, authority boundaries, context, memory, evidence requirements, evaluation, and
learning-promotion controls used at the points where those controls matter.

## Current Roadmap Position

SF-100 through SF-106 are implemented and verified for their declared local scopes. SF-106
provides the append-only operations journal, separate public-event stream,
seven rebuildable projections, stable queries and continuation tokens, integrity verification,
and operations-store backup/restore. SF-107 closes the local numeric-loopback operations API,
authentication, authorization, idempotency, reconciliation, event, health, readiness, backup,
and process-restart boundary.

Local Gate B passes. SF-200 is verified for the provider-neutral Worker Adapter Conformance
Suite. SF-201 is verified for one bounded real Codex worker adapter. SF-202 is verified for the
local Git worktree and sandbox lifecycle. SF-203 is verified for local durable session control.
SF-204 is verified for the optional bounded Prime Agent adapter. SF-205 is verified for durable
factory-owned goals, schedules, heartbeats, bounded re-entry, and fail-closed result accounting.
SF-206 is verified for exact worker recovery, safe effect reconciliation, cross-store restart,
SF-205 fail-closed propagation, and durable orphan findings. All mandatory Phase 2 task
implementations are verified. Gate C passed on 2026-08-13 through one composed real-Codex
issue-to-evidence workflow that survived hard process restart without duplicating the prompt
effect. SF-300 is verified for its deterministic owner-attention read model,
fail-closed source integrity, project-authorized owner API, restart proof,
concurrent stable-read scope, and installed-package boundary. SF-301 is the
verified for its exact-grant product portfolio, current projection binding,
deterministic board state, bounded paging, and responsive local control room.
SF-302 through SF-305 and Gate D are verified for the Work Room, accountable
decisions, audit reconstruction, metrics, and one authenticated owner workflow
through API restart. SF-400 through SF-404 are verified for the Elder boundary,
governed context, assigned-child authority, ordered evidence, and supervised
delivery. Gate E is verified for one classified issue-to-supervised-delivery
workflow reconstructed through every Phase 4 store, with owner-visible stops
for expired authority, stale context, missing evidence, and unauthorized
transition. Phase 4 is complete for its bounded local claim. Canonical Elder
maturity remains L1. SF-500 now implements the bounded read-only learning
trajectory input with exact bindings, opaque references, free-text and secret
redaction, deterministic sampling, explicit missing links, and complete
expected-outcome attachment. SF-500 is verified through independent review,
package build, and outside-checkout installed-wheel execution. SF-501 through
SF-507 and Gate F have not started.

SF-107 evidence:
[verification](SF-107-evidence.md), [design](SF-107-design.md), and
[test reproduction](SF-107-test-reproduction.md).

SF-200 evidence:
[verification](evidence/SF-200.md), [design](SF-200-design.md), and
[test reproduction](SF-200-test-reproduction.md).

SF-201 evidence:
[verification](evidence/SF-201.md), [design](SF-201-design.md), and
[test reproduction](SF-201-test-reproduction.md).

SF-202 evidence:
[verification](evidence/SF-202.md), [design](SF-202-design.md), and
[test reproduction](SF-202-test-reproduction.md).

SF-203 evidence:
[verification](evidence/SF-203.md), [design](SF-203-design.md), and
[test reproduction](SF-203-test-reproduction.md).

SF-204 evidence:
[verification](evidence/SF-204.md), [design](SF-204-design.md), and
[test reproduction](SF-204-test-reproduction.md).

SF-205 evidence:
[verification](evidence/SF-205.md), [design](SF-205-design.md), and
[test reproduction](SF-205-test-reproduction.md).

SF-206 evidence:
[verification](evidence/SF-206.md), [design](SF-206-design.md), and
[test reproduction](SF-206-test-reproduction.md).

SF-300 evidence:
[verification](evidence/SF-300.md), [design](SF-300-design.md), and
[test reproduction](SF-300-test-reproduction.md).

SF-301 evidence:
[verification](evidence/SF-301.md), [design](SF-301-design.md), and
[test reproduction](SF-301-test-reproduction.md).

SF-302 evidence:
[verification](evidence/SF-302.md), [design](SF-302-design.md), and
[test reproduction](SF-302-test-reproduction.md).

SF-303 evidence:
[verification](evidence/SF-303.md), [design](SF-303-design.md), and
[test reproduction](SF-303-test-reproduction.md).

## Reading Order

1. [Reference System Analysis](01-reference-system-analysis.md)
2. [Capability Selection Matrix](02-capability-selection-matrix.md)
3. [Target Architecture](03-target-architecture.md)
4. [Governed Continual Learning](04-governed-continual-learning.md)
5. [Task Execution Contract](05-task-execution-contract.md)
6. [Roadmap And Gates](06-roadmap-and-gates.md)
7. [Reference Reading Map](07-reference-reading-map.md)
8. [New Session Implementation Prompt](08-new-session-implementation-prompt.md)
9. [Source Licensing And Provenance Decision](09-source-licensing-and-provenance.md)
10. [Current Operational Baseline](10-current-operational-baseline.md)
11. [Canonical Factory Domain](11-canonical-factory-domain.md)
12. [Stable Factory Contracts And Events](12-stable-contracts-and-events.md)
13. [Mastra Operations Spike](13-mastra-operations-spike.md)
14. [Codex And Prime Worker Spike](14-codex-prime-worker-spike.md)
15. [Operational Architecture Ratification](15-operational-architecture-ratification.md)
16. [Phase-Proportional Delivery Rule](16-phase-proportional-delivery-rule.md)
17. [SF-200 Completion And Implementation Directive](SF-200-implementation-directive.md)
18. [Task Packet Template](templates/task-packet.md)
19. Phase task catalogs under [tasks](tasks/)

## Source Snapshots

The analysis used local, pinned source snapshots rather than product descriptions alone.

| Reference | Snapshot | Primary contribution |
|---|---|---|
| Elder Protocol | current worktree at analysis time | Governance, authority, context, evidence, qualification, quarantined learning |
| Prime Agent | `b9a4461149419156599d60174dddf15458e2b9ee` | Continual harness, durable sessions, goals, schedules, heartbeats, worker continuity |
| Mastra Factory monorepo | `d81fe95420e4a001a2850c56b9193106bf400682` | Work-item ledger, transitions, dispatcher, leases, integrations, owner UI |
| Mastra Factory template | `ebcf8889fddde238f016ddc7468e45f195c440a4` | Deployable factory composition and infrastructure choices |
| HumanLayer | `99abe673498cf8bdcd5f989aebe9406a27185b3b` | Human approval, contact, waiting-state, and session interaction semantics |
| Factory.ai | no public source commit was available in the cloned repository | Product and control-room interaction reference only |

The snapshots under `.tmp/factory-research/` are research inputs, not vendored dependencies.

The reproducible pin, license, package, attribution, limitation, and reuse-decision record is
[`research-sources.json`](research-sources.json). Its schema is
[`research-sources.schema.json`](research-sources.schema.json), and the refresh workflow is
[`source-update-procedure.md`](source-update-procedure.md). The approved policy permits reference
use and later task-specific independent reimplementation, but it does not authorize copying,
vendoring, forking, or package integration.

## Non-Negotiable Boundaries

- Do not route every shell command, edit, or model call through Elder.
- Do not allow a learning model to directly rewrite trusted memory, skills, policy, evaluators,
  architecture, or production.
- Do not treat session context as the canonical work ledger.
- Do not claim L2 or L3 from local fixtures or documentation.
- Do not choose a reference implementation as a dependency before the relevant spike, license
  decision, and failure-mode test.
- Do not implement the control-room UI before the ledger, event journal, and lifecycle semantics
  are stable.
- Do not begin autonomous production deployment before hosted identity, secret brokering,
  telemetry, branch protection, and automatic rollback are verified.

## First Deliverable

The first useful factory milestone is not "multiple agents." It is one restart-safe flow:

```text
owner creates work item
-> factory validates and queues it
-> Codex worker starts in an isolated workspace
-> owner can observe, steer, pause, approve, and resume
-> tests and evidence are linked to the run
-> a supervised pull request packet is produced
-> restart does not lose the work item, run, or decision history
```

Only after that flow is reliable should the implementation add multiple workers, automatic
learning promotion, or L3 canary execution.

## Current Implementation

Gate A is closed by ADR 0021. Local Phase 1 Gate B is closed by SF-107.

- SF-100 Product Factory Registry, SF-101 Signal Intake, SF-102 Work-Item Ledger, SF-103
  Transition And Rule Engine, and SF-104 Durable Dispatcher are verified on their stacked
  implementation branches.
- The local registry provides SQLite persistence, ratified profile and Git repository binding,
  optimistic concurrency, immutable lifecycle history, terminal archive behavior, and
  secret-reference rejection.
- Signal intake provides provider-neutral normalization, source-authentication evidence,
  idempotent retry and duplicate handling, quarantine outcomes, source-order fencing, immutable
  revisions, and a digest-bound SF-102 work-item candidate.
- The work-item ledger provides canonical draft backlog records, immutable intent revisions,
  optimistic concurrency, dependencies, source lineage, queries, and atomic signal conversion.
- The transition engine is the only implemented stage-mutation boundary. It records accepted and
  rejected commands, enforces the canonical role, authority-mode, field, evidence, concurrency,
  and terminal rules, appends atomic history, and emits durable terminal hooks.
- The durable dispatcher persists exact accepted start commands and adapter requests above queued
  work, enforces one local lease with monotonic generation fencing, renews or recovers claims,
  retries only proven non-applied failures, quarantines uncertain delivery for reconciliation,
  rejects expired work before invocation, and preserves immutable history and dead letters.
- SF-105 binds the local canonical P4.5 delegated lease and immutable run lineage through a
  read-only runtime adapter. External hosted identity authentication and hosted governance
  authorization remain blocked.
- SF-105 is verified for local run, session, workspace, lifecycle, checkpoint, artifact, recovery,
  and reconciliation scope.
- SF-106 is verified for local journal, projection, query, public-event read, integrity, backup,
  and restore scope.
- SF-107 is verified for the local numeric-loopback API, authenticated long-poll admission,
  current readiness checks, graceful drain, restart recovery, and deterministic Gate B proof.
- SF-200 is verified for the exact eight provider-neutral worker operations, deterministic fake
  effects and recovery, SF-105 identity bindings, replay-safe projections, checkpoint authority
  separation, and installed-wheel conformance.
- SF-201 is verified for a real local Codex worker adapter with exact policy enforcement,
  protected durable state, bounded first-turn persistence, post-turn recovery, fail-closed
  terminal outcomes, digest-only diagnostics, and one real disposable-repository workflow.
- SF-202 is verified for exact Git worktree materialization, trusted-instruction and reparse
  checks, canonical-state-fenced local leases, complete secretless sandbox binding, stable
  inspection/quarantine/release/recovery, subprocess contention, and one real Codex workflow.
- SF-203 is verified for durable exact-idempotent session controls, validated SF-202 binding,
  canonical checkpoint identity, restart-safe waiting continuation, fail-closed incomplete
  effects, monotonic event cursors, and spawned-process command contention.
- SF-204 is verified for an optional Prime 0.7.0 adapter with exact SF-200 conformance, isolated
  provider state, stable journal identity, restart attachment, typed lease conflict, default-on
  refinement disablement, candidate quarantine, fail-closed direct-application detection, and a
  packaged Windows JSONL bridge.
- SF-205 is verified for exact-bound durable goals, fixed-interval schedules, deterministic
  ticks, append-only heartbeats, current Elder authority, bounded result acceptance, waiting and
  pause suppression, restart reopening, and duplicate-safe dispatch and accounting.
- SF-206 is verified for exact recovery episodes, proved-not-applied requeue, no-replay
  convergence, cross-store restart, unresolved dependency propagation, orphan discovery, and
  one-recover concurrent sweep behavior.
- All mandatory Phase 2 implementations are verified. Gate C is verified by one composed
  real-Codex issue-to-evidence-through-restart proof.
- SF-300 through SF-305 are verified for owner attention, portfolio, Work
  Room, exact approvals and escalations, audit replay, and definition-bound
  metrics and outcomes. Phase 3 and Gate D are verified.
- SF-400 through SF-404 and Gate E are verified for the bounded local Elder
  lifecycle integration claim. The complete workflow retains human merge and
  release, uses signed hosted fixtures only, and does not raise maturity.
- Canonical maturity remains L1.

Evidence:

- [SF-100 Product Factory Registry](evidence/SF-100.md)
- [SF-101 Signal Intake](evidence/SF-101.md)
- [SF-102 Work-Item Ledger](evidence/SF-102.md)
- [SF-103 Transition And Rule Engine](evidence/SF-103.md)
- [SF-103 Test Reproduction](SF-103-test-reproduction.md)
- [SF-104 Durable Dispatcher](evidence/SF-104.md)
- [SF-104 Design](SF-104-design.md)
- [SF-104 Test Reproduction](SF-104-test-reproduction.md)
- [SF-105 Run, Session, And Workspace Binding](evidence/SF-105.md)
- [SF-105 Design](SF-105-design.md)
- [SF-105 Test Reproduction](SF-105-test-reproduction.md)
- [SF-106 Event Journal And Projections](evidence/SF-106.md)
- [SF-106 Design](SF-106-design.md)
- [SF-106 Test Reproduction](SF-106-test-reproduction.md)
- [SF-107 Factory API And Health Evidence](SF-107-evidence.md)
- [SF-107 Design](SF-107-design.md)
- [SF-107 Test Reproduction](SF-107-test-reproduction.md)
- [SF-200 Worker Adapter Conformance Evidence](evidence/SF-200.md)
- [SF-200 Design](SF-200-design.md)
- [SF-200 Test Reproduction](SF-200-test-reproduction.md)
- [SF-201 Codex Worker Adapter Evidence](evidence/SF-201.md)
- [SF-201 Design](SF-201-design.md)
- [SF-201 Test Reproduction](SF-201-test-reproduction.md)
- [SF-202 Workspace And Sandbox Lifecycle Evidence](evidence/SF-202.md)
- [SF-202 Design](SF-202-design.md)
- [SF-202 Test Reproduction](SF-202-test-reproduction.md)
- [SF-203 Durable Session Control Evidence](evidence/SF-203.md)
- [SF-203 Design](SF-203-design.md)
- [SF-203 Test Reproduction](SF-203-test-reproduction.md)
- [SF-204 Prime Agent Adapter Evidence](evidence/SF-204.md)
- [SF-204 Design](SF-204-design.md)
- [SF-204 Test Reproduction](SF-204-test-reproduction.md)
- [SF-205 Goals, Schedules, And Heartbeats Evidence](evidence/SF-205.md)
- [SF-205 Design](SF-205-design.md)
- [SF-205 Test Reproduction](SF-205-test-reproduction.md)
- [SF-206 Worker Recovery And Reconciliation Evidence](evidence/SF-206.md)
- [SF-206 Design](SF-206-design.md)
- [SF-206 Test Reproduction](SF-206-test-reproduction.md)
- [SF-300 Owner Inbox And Attention Evidence](evidence/SF-300.md)
- [SF-300 Design](SF-300-design.md)
- [SF-300 Test Reproduction](SF-300-test-reproduction.md)
- [SF-301 Product Portfolio And Work Board Evidence](evidence/SF-301.md)
- [SF-301 Design](SF-301-design.md)
- [SF-301 Test Reproduction](SF-301-test-reproduction.md)
- [SF-302 Work Room Evidence](evidence/SF-302.md)
- [SF-302 Design](SF-302-design.md)
- [SF-302 Test Reproduction](SF-302-test-reproduction.md)
- [SF-303 Approvals And Escalations Evidence](evidence/SF-303.md)
- [SF-303 Design](SF-303-design.md)
- [SF-303 Test Reproduction](SF-303-test-reproduction.md)
- [SF-304 Audit And Replay Evidence](evidence/SF-304.md)
- [SF-305 Metrics And Outcomes Evidence](evidence/SF-305.md)
- [Gate D Qualification Evidence](evidence/Gate-D.md)
- [SF-400 Elder Boundary Evidence](evidence/SF-400.md)
- [SF-401 Governed Context Evidence](evidence/SF-401.md)
- [SF-402 Authority And Delegation Evidence](evidence/SF-402.md)
- [SF-403 Evidence And Test Pipeline](evidence/SF-403.md)
- [SF-404 Supervised Delivery](evidence/SF-404.md)
- [Gate E Qualification Evidence](evidence/Gate-E.md)
- [SF-500 Learning Trajectory Evidence](evidence/SF-500.md)
- [SF-500 Design](SF-500-design.md)
- [SF-500 Test Reproduction](SF-500-test-reproduction.md)
