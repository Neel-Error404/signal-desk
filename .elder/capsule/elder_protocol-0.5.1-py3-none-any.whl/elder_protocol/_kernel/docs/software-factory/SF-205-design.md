# SF-205 Goals, Schedules, And Heartbeats Design

**Status:** VERIFIED

**Date:** 2026-08-13

## Boundary

SF-205 adds a deterministic local continuation scheduler above SF-203. It owns
continuation intent and accounting, not canonical run lifecycle or worker
truth.

```text
current Elder lineage and budgets
              |
              v
DurableContinuationScheduler
   goal -> schedule -> tick -> heartbeat
              |
              v
DurableSessionController.submit(prompt)
              |
              v
existing SF-105 lifecycle and SF-200 worker
```

The scheduler has no background thread requirement. The local operations
process calls `run_due()` with an explicit observed time. This keeps clock
behavior deterministic and makes duplicate and missed ticks directly testable.

## Durable Records

- **Goal:** objective, exact factory and Elder bindings, requested budgets,
  usage, status, and terminal stop reason.
- **Schedule:** one bounded fixed interval, next due time, misfire grace, and
  last scheduled instant.
- **Tick:** deterministic identity from schedule plus scheduled instant,
  bounded claim lease, immutable SF-203 command digest, outcome, and usage.
- **Heartbeat:** immutable ordered observation of creation, dispatch, result,
  skip, stop, or uncertainty.

Goal, schedule, and tick transitions preserve immutable history. Heartbeats are
append-only.

## Authority And Budget

`RunController.continuation_authority()` reconstructs the current immutable
lineage and returns the minimum effective deadline across delegation, child
run, and runtime lease plus the minimum Elder token and elapsed-time budgets.

The scheduler rejects a requested budget that expands Elder limits. Every due
tick re-reads current lineage and stops if any bound digest, identity, status,
lease, or expiry is invalid.

The following stop reasons are explicit:

- goal completion or cancellation;
- goal deadline or authority expiry;
- invalid authority;
- token, elapsed-time, or continuation budget exhaustion;
- terminal work;
- rejected or cancelled SF-203 control;
- uncertain tick.

## Tick Semantics

One schedule instant has one deterministic tick ID. A due runnable tick:

1. is durably claimed with a short local claim lease;
2. advances the recurring schedule to the first future instant;
3. submits one deterministic SF-203 prompt control;
4. stores the immutable accepted command digest;
5. waits for explicit completion accounting.

A claimed tick whose lease expires before submission is marked uncertain and
stops the goal. A submitted tick is never redispatched. SF-206 may later add
automatic reconciliation; SF-205 does not.

Result recording rechecks the submitted tick under the scheduler write
transaction. Exact duplicate results replay the terminal tick without changing
goal usage. A successful SF-203 control is accepted as an SF-205 success only
while current authority remains valid and reported usage fits the remaining
goal budget. Otherwise the tick and goal stop as uncertain with the exact
authority or budget reason.

Manual goal completion is rejected while a claimed or submitted tick remains.
A late result may close its tick after cancellation, but it cannot rewrite the
already terminal goal outcome.

## Missed, Paused, And Waiting Work

Ticks later than their misfire grace are recorded once as coalesced misses and
the schedule advances directly to the next future instant. No catch-up burst is
created.

Canonical paused or owner-waiting runs produce a skipped heartbeat and no
session control. Explicit goal pause disables the schedule; resume revalidates
authority and budgets before scheduling the next interval.

## Security

- all accepted and persisted values are recursively secret-scanned;
- provider credentials and provider-local scheduling state are forbidden;
- the worker never owns goal, schedule, heartbeat, budget, or stop truth;
- SF-203 remains the only path from a due tick to a worker control;
- no merge, release, deployment, promotion, or maturity authority is added.

## Integrity

Goal, schedule, and tick histories bind identity, version, operation, complete
snapshot, and observation time in an immutable history-entry digest.
Heartbeats are append-only, contiguous per goal, scalar-to-JSON checked, and
bound to a tick from the same goal when a tick is present.
