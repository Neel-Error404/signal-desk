# Gate C Qualification Implementation Plan

**Status:** IMPLEMENTED

**Source revision:** `d907ad5a066f2e4ed69054762fed701de3f767a5`

## Implementation Point Of View

Gate C is a composition and qualification problem. SF-100 through SF-206
already own the runtime behavior. The implementation must expose and verify
their complete path without duplicating their stores, transitions, or worker
semantics.

The smallest coherent change is:

1. add a closed Gate C qualification packet schema and validator;
2. add one local qualification runner with explicit phase-one and phase-two
   process entry points;
3. use dependency injection only for deterministic lower-level tests;
4. use the real Codex adapter for the closure workflow;
5. persist restart state as identifiers and digests, never copied mutable
   aggregates;
6. generate evidence from reopened durable state after process restart.

## Work Breakdown

### 1. Contract

- define packet, restart manifest, Git evidence, test evidence, and limitation
  fields;
- require exact content digests and closed additional properties;
- reject secrets and broader authority claims.

### 2. Fixture And Intake

- create a disposable Git repository and deterministic task;
- register the bounded product factory;
- accept one synthetic manual signal;
- create and queue one canonical work item;
- create one durable dispatch.

### 3. Run And Workspace

- bind the existing Elder delegation/context/runtime lease chain;
- prepare and lease one SF-202 worktree;
- create the real Codex adapter and SF-203 session controller;
- start the worker session and canonical run.

### 4. Pre-Restart Execution

- submit one bounded prompt;
- verify the exact requested workspace change;
- persist the successful control result;
- write the restart manifest;
- signal the parent and wait for hard termination.

### 5. Post-Restart Evidence

- reopen every store in a new process;
- validate identities and digests from the restart manifest;
- resume the same Codex thread without replay;
- run the declared test and collect the Git diff;
- record the canonical checkpoint and worker evidence bundle;
- validate and complete the run;
- emit the Gate C packet.

### 6. Verification And Closure

- run Foundation, Component, Integration, Workflow, and Stress in order;
- rerun only a failed or invalidated level after root-cause correction;
- perform independent implementation review;
- build and install the wheel and verify installed schema/validator behavior;
- update roadmap, README, evidence, test reproduction, and Obsidian;
- commit Gate C separately before activating SF-300.

## Stop Conditions

Stop and do not claim Gate C when:

- live Codex execution is unavailable;
- a process restart is simulated only in memory;
- the provider thread or worker effect is duplicated;
- tests, diff, checkpoint, or evidence cannot be bound exactly;
- a lower test level is failing;
- the final packet requires authority not present at L1.

## Closure

Implemented and verified on 2026-08-13. The composed live workflow passed
without changing protected protocol manifests, accepted ADRs, or canonical
maturity.
