# Canonical Factory Domain

**Status:** RATIFIED for Phase 1 by ADR 0021 on 2026-08-08

**Version:** `0.1.0`

**Date:** 2026-08-07

**Machine-readable source:** `factory/factory-domain.json`

**Schemas:** `factory/factory-domain.schema.json` and
`factory/factory-entity.schema.json`

## Authority Boundary

This document defines the SF-002 provider-neutral factory vocabulary. It does not amend the Elder
ontology, meta-architecture, invariants, authority matrix, maturity, autonomy, or accepted ADRs.
It does not activate a runtime or authorize a provider operation. Gate A / SF-006 ratified these
domain bytes and boundaries through ADR 0021.

The model reuses Elder identifiers and schemas where semantics match. Factory-specific records
compose those governed primitives into an operations-wide vocabulary without claiming that the
new names already exist in the constitutional ontology.

## Common Record Envelope

Every canonical factory record requires:

- `version`, stable `id`, and `entity_type`;
- explicit `project_id` and `actor_identity_id`;
- entity-specific `status`;
- optimistic `record_version`;
- `created_at` and `updated_at`;
- conditional `correlation_id`, `causation_id`, and `content_sha256`;
- an entity-specific `payload`.

Project binding is required for all 21 entities. A filesystem path, provider session, process,
branch, display name, or client connection is not project identity or authority.

The JSON Schema validates the structural envelope. The semantic validator additionally binds
`entity_type` and `status` to this registry, requires exactly the declared payload fields,
rejects undeclared provider fields, checks timestamp ordering, and requires a digest for records
that are immutable at creation.

When `content_sha256` is present, it is the lowercase SHA-256 of compact, ASCII JSON with sorted
keys over the complete record except the `content_sha256` field itself. Equality between supplied
digest strings is never treated as content binding without this recomputation.

## Authority Planes

| Plane | Canonical state | Responsibility |
|---|---:|---|
| `product-owner` | Yes | Product intent, acceptance criteria, outcomes, and owner-visible decisions |
| `factory-operations` | Yes | Work ledger, transitions, runs, sessions, workspaces, commands, schedules, and incidents |
| `worker` | No | Execute bounded commands and report normalized events, checkpoints, artifacts, and evidence |
| `elder-governance-learning` | Yes | Authority, evidence validation, accountable decisions, evaluation, learning, and promotion gates |

The worker plane is deliberately non-authoritative. Worker output can propose or evidence a
transition, but only the entity's declared authoritative plane can persist canonical state.

## Entity And Ownership Model

The accountable owner is responsible for the entity contract. Allowed writers are narrower
roles permitted to request or record declared transitions; ownership does not imply direct write
permission.

`allowed_writer_roles` and transition `authorized_roles` are eligibility constraints, not
standalone authority grants. A runtime must additionally verify the authenticated project role
binding, map the transition to an allowed Elder action and resource, bind the current accountable
command or delegation, require the active assigned-identity runtime lease for delegated
execution, and consume a governance-adapter authorization result bound to the exact transition.
An unmapped transition or missing authority evidence fails closed.

| Entity | Canonical plane | Accountable owner | Elder semantic reference |
|---|---|---|---|
| `ProductFactory` | product-owner | human-owner | `project` |
| `Signal` | factory-operations | product-owner | new factory term |
| `WorkItem` | factory-operations | product-owner | `work-item` schema through an adapter |
| `WorkItemRevision` | factory-operations | product-owner | new immutable revision term |
| `StageTransition` | factory-operations | architecture-owner | new append-only transition term |
| `Run` | factory-operations | code-owner | `agent-run` schema through an adapter |
| `WorkerSession` | factory-operations | code-owner | new adapter-neutral session term |
| `Workspace` | factory-operations | code-owner | new isolated-workspace term |
| `Command` | factory-operations | code-owner | `agent-action` semantics |
| `Event` | factory-operations | architecture-owner | `telemetry-event` schema through an adapter |
| `Checkpoint` | elder-governance-learning | code-owner | `checkpoint` schema through an adapter |
| `Artifact` | factory-operations | release-owner | `artifact` |
| `EvidenceRecord` | elder-governance-learning | evaluator | `evidence` and evidence-bundle semantics |
| `DecisionRequest` | factory-operations | product-owner | `escalation` semantics |
| `Decision` | elder-governance-learning | human-owner | `approval-decision` schema through an adapter |
| `Schedule` | factory-operations | product-owner | `deadline` semantics |
| `Outcome` | product-owner | product-owner | `outcome` |
| `LearningCandidate` | elder-governance-learning | architecture-owner | `learning-candidate` schema through an adapter |
| `LearningEvaluation` | elder-governance-learning | architecture-owner | `learning-evaluation` schema through an adapter |
| `Promotion` | elder-governance-learning | human-owner | `learning-promotion` schema through an adapter |
| `Incident` | factory-operations | release-owner | `incident-budget` semantics |

The complete allowed-writer sets and mutation policies are in the machine-readable registry.
Ten machine-readable Elder reuse contracts classify all schema links as `semantic-reference`
with `direct_validation: false`. Status and payload differences must be handled by a verified
adapter in SF-003; file existence is not treated as schema compatibility.

Evaluators may write only checkpoint, evidence-record, and learning-evaluation state. They cannot
directly complete or fail runs, mutate work items or artifacts, assess product outcomes, or
approve or promote learning.

## Lifecycle Rules

Each entity has its own status vocabulary. There is no universal factory status enum. Status
changes are accepted only through the declared transition table, against the current record
version, with one matching ownership rule and bounded role authority.

### Work Delivery

```text
draft -> ready -> queued -> running -> validation -> completed
                    |          |          |
                    |          +-> waiting -> running
                    |          +-> blocked
                    |          +-> failed
                    +-----------------------> cancelled

validation -> running is explicit rework, not history replacement.
completed, failed, and cancelled are terminal.
```

### Run And Worker Recovery

```text
prepared -> queued -> starting -> running -> validating -> completed
                                  |   |
                                  |   +-> waiting / paused -> running
                                  +-> cancelling -> cancelled
                                  +-> failed
                                  +-> lost

WorkerSession separately records active, detached, recovering, waiting, paused,
cancelling, completed, failed, cancelled, or lost adapter state.
Client detachment does not transfer ownership or erase durable run state.
Recovery must bind the current lease reference and token digest, session generation, recovery
attempt, and checkpoint cursor. A stale session generation cannot be treated as the active
writer.
```

### Commands And Decisions

```text
Command:
pending -> accepted -> delivered -> acknowledged -> succeeded
   |          |           |              |
   +-> rejected / cancelled              +-> failed / uncertain

DecisionRequest:
open -> waiting -> resolved
  +-------------> cancelled
  +-------------> expired

Decision:
approved | rejected | changes-requested
```

Command acceptance is not completion. `uncertain` is nonterminal so reconciliation can establish
the durable result without blindly repeating a side effect. A `Decision` is immutable and
terminal at creation. A replacement decision carries `supersedes_decision_id`; the prior record
is never rewritten into a new status. Supersession validation requires the same project,
decision request, and subject digest, a later timestamp, and two content-bound records.

### Schedules And Learning

```text
Schedule:
draft -> active -> triggered -> active
          |          +-> completed / failed
          +-> paused -> active
          +-> cancelled / expired

LearningCandidate:
candidate -> replay -> shadow -> approved -> promoted -> rolled-back
    +----------+----------+-> rejected

Promotion:
proposed -> approved -> executing -> applied -> rolling-back -> rolled-back
    +-> rejected              +-> failed          +-> failed
```

Schedule intent and dispatch claims remain separate. Learning proposal, replay, evaluation,
approval, promotion, application, and rollback remain distinct records and authorities. Candidate
approval binds evaluation and approval records. Candidate promotion and rollback bind an
immutable promotion packet. The promotion packet binds candidate and evaluation IDs and digests,
approval IDs, digests, and approver identities, promoter identity, action, target, artifact, and
`applies_target_mutation: false`.

## Canonical Invariants

| ID | Rule |
|---|---|
| `FD-001` | Every record has stable identity, project binding, actor identity, timestamps, and optimistic version. |
| `FD-002` | Every entity has exactly one authoritative plane and one accountable owner role. |
| `FD-003` | Canonical status changes occur only through declared transitions with bounded authority. |
| `FD-004` | Terminal states have no outgoing transitions and cannot be silently reopened. |
| `FD-005` | Duplicate signals and mutating commands reconcile by durable idempotency identity. |
| `FD-006` | Workers report evidence but never own product, authority, decision, or promotion state. |
| `FD-007` | Decisions are immutable, digest-bound, and accepted only from authenticated accountable roles. |
| `FD-008` | Live events are projections; durable journals and immutable records are source of truth. |
| `FD-009` | Completion requires linked outcome, run, artifact or diff, ordered tests, evidence, decisions, and delivery state. |
| `FD-010` | Learning candidates and evaluators cannot approve, promote, apply, or roll back their own target. |

## Reference-Derived Decisions

### Adapted

- From Mastra: project-scoped work items, durable ingress identity, explicit transition service,
  optimistic revision, effect idempotency, owner-fenced leases, and append-only audit.
- From Prime Agent: entity-specific statuses, explicit transition tables, durable session
  history, command acceptance versus completion, generation-aware recovery, uncertain-result
  reconciliation, schedule claim-before-effect, and proposal/application separation.
- From HumanLayer: durable decision requests, explicit waiting and resume, correlation to the
  exact subject, and exactly one terminal decision.

These are behavioral requirements behind Elder-owned contracts, not dependencies or copied
provider schemas.

### Rejected Or Kept Adapter-Specific

- Mastra's provider-specific stage enum, infrastructure concepts, and lower-level write paths
  that bypass one canonical transition boundary.
- Prime's RLM/IPython ABI, daemon or filesystem identity as authority, direct self-modifying
  harness state, provider/model settings as domain identity, and silent corrupt-state fallback.
- HumanLayer's unauthenticated or insufficiently provenance-bound approval assumptions and lossy
  live events as authority.
- Any lease treated as approval, identity proof, or authority merely because it prevents a local
  concurrent writer.

## Validation And Failure Conditions

`elder_protocol.factory_domain` validates the schema catalog and registry, then fails closed on:

- missing or duplicate canonical identities;
- non-required project binding;
- missing or ambiguous ownership;
- canonical ownership assigned to the worker plane;
- unknown Elder entity, schema, role, status, field, or entity references;
- an Elder schema reference without a semantic reuse contract;
- a transition leaving a terminal status;
- ambiguous same-entity, same-source, same-trigger transitions;
- unreachable lifecycle statuses;
- transition authority outside the entity's allowed writers;
- advisory evaluator mutation outside checkpoint and evaluation evidence;
- nonterminal statuses with no declared outgoing transition.

Entity instances separately fail closed on unknown types or statuses, missing or undeclared
payload fields, reversed or timezone-free timestamps, missing immutable-record digests, and a
promotion packet that claims direct target mutation.

`validate_learning_chain_data` then checks an actual candidate, evaluation, and promotion set:
candidate and evaluation IDs and digests must match in both directions, the candidate must bind
the promotion packet, a promotion can consume only a qualified evaluation, lifecycle statuses
and actions must agree, target and artifact references cannot drift, approval triples must be
unique and digest-valid against actual content-bound `Decision` records, approval roles must
carry canonical approval capability, and creator, evaluator, promoter, and approver identities
must remain separate.

SF-002 defines the canonical payload field names and enforces the high-risk values above. SF-003
owns the per-entity language-neutral value schemas for the remaining fields, including objective,
scope, command payload, event payload, evidence details, and adapter-normalized values. Until
those contracts exist, these records are domain drafts rather than runtime acceptance contracts.

Foundation fixtures independently exercise duplicate entity identity, illegal terminal-state
transition, missing project binding, and ambiguous authority.

## SF-003 Handoff

SF-003 may define stable commands, events, worker adapter contracts, governance adapter contracts,
and integration envelopes using these exact entity names and lifecycle meanings. It must not
reinterpret command acceptance as completion, event delivery as canonical state, session
identity as authority, or learning evaluation as promotion authority.
