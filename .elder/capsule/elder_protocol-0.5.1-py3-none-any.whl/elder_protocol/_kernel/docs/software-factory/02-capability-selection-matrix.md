# Capability Selection Matrix

**Status:** RATIFIED FOR PHASE 1 by ADR 0021 - later-gate decisions remain provisional

## Decision Labels

- **KEEP:** Use an existing Elder capability as canonical.
- **INTEGRATE:** Call a maintained external component through an adapter.
- **ADAPT:** Reimplement or extract a pattern behind Elder-owned contracts.
- **REFERENCE:** Use behavior or UX as inspiration without code dependency.
- **DEFER:** Do not build until a later maturity gate.
- **REJECT:** Explicitly avoid the mechanism.

## Matrix

| Capability | Decision | Source | Reason | Proof before adoption |
|---|---|---|---|---|
| Protocol compiler and project profile | KEEP | Elder | Existing canonical project contract | Current validation remains green |
| Authority, change classes, delegation | KEEP | Elder | Required fail-closed boundary | Integration cannot widen authority |
| Context and trusted memory retrieval | KEEP | Elder | Digest-bound, scoped, freshness-aware | Retrieval latency and relevance tests |
| Work-item ledger | ADAPT | Mastra | Strong lifecycle and revision model | Restart and concurrency workflow |
| Transition and rules engine | ADAPT | Mastra | Separates lifecycle policy from workers | Deterministic transition tests |
| Durable dispatch queue | ADAPT or INTEGRATE | Mastra | Leases, retries, pending starts | Crash, duplicate, and lease-loss tests |
| Event journal and projections | ADAPT | Mastra + Prime | Needed for replay and owner UI | Rebuild projections from journal |
| Worker adapter contract | BUILD | Factory-owned | Prevents runtime lock-in | Codex and fake adapter conformance |
| Codex worker | INTEGRATE | Codex | Primary coding executor | Start, steer, resume, cancel, evidence |
| Prime Agent worker | DEFER then INTEGRATE | Prime Agent | Valuable optional runtime | Bounded adapter spike and security review |
| Durable session concepts | ADAPT | Prime Agent | Goals, leases, journals, schedules | Restart and uncertain-command tests |
| Human approvals | ADAPT | HumanLayer | Clear waiting/contact semantics | Durable request/response correlation |
| Control-room UI | ADAPT/REFERENCE | Mastra + Factory.ai | Owner visibility and interaction | Workflow usability test |
| Telemetry and evidence schema | KEEP | Elder | Existing correlation and safety rules | End-to-end trace completeness |
| Continual-learning trigger | ADAPT | Prime Agent | Missing automatic proposal loop | Precision and noise evaluation |
| Typed learning proposal | ADAPT | Prime Agent | Small scoped versioned change | Schema and conflict tests |
| Learning quarantine | KEEP | Elder | Independent checks and authority split | Existing P4.6 tests plus integration |
| Target learning application | BUILD | Factory-owned | P4.6 deliberately stops before mutation | Per-target adapter and rollback tests |
| Promotion and rollback authority | KEEP | Elder | Prevents self-ratifying learning | Separation-of-duty tests |
| Hosted qualification | KEEP | Elder | Evidence-bound maturity | Current signed-bundle re-evaluation |
| General autonomous production rollout | REJECT now | None | Exceeds current evidence and authority | L3 class certification required |
| Multi-tenant distributed operation | DEFER | Mastra patterns | Not required for local proof | Hosted L2 gate first |

## Reuse Rules

1. External source code may not be copied before its license and attribution path are documented.
2. The Elder repository currently needs an explicit project license decision before substantial
   third-party code is incorporated.
3. Prefer adapter integration for fast-moving alpha dependencies.
4. Prefer clean contracts and conformance tests over importing another system's internal domain
   objects into Elder.
5. Preserve source snapshot, commit, file path, and adopted behavior in the implementation task.
6. A reference behavior is not evidence that the local implementation works.

## Build Versus Integrate Decision

The Phase 0 spikes must score each candidate against:

- contract fit;
- restart and failure semantics;
- Windows and hosted Linux operation;
- provider neutrality;
- security boundary;
- observability;
- migration cost;
- testability;
- dependency stability;
- license compatibility;
- expected maintenance over two years.

No package becomes foundational solely because its demo is more complete.
