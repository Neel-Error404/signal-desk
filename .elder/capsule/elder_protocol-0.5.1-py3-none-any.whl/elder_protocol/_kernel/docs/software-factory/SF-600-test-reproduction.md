# SF-600 Test Reproduction

**Status:** VERIFIED on 2026-08-14

## Foundation

```powershell
py -m unittest tests.foundation.test_sf600_hosted_store_contract -v
```

Proves the versioned PostgreSQL schema, exact seven-table inventory,
PostgreSQL-native competing-consumer and lease fences, inactive hosted
binding, L1 preservation, and SF-601 through SF-606 exclusion.

## Component

```powershell
py -m unittest tests.component.test_sf600_hosted_store -v
```

Proves ordered migration history, migration drift rejection, transactional
publish, changed-duplicate rejection, claim SQL, fenced acknowledgement,
duplicate inbox handling, explicit database outage, secret rejection,
quiesced deterministic SQLite export, backup tamper rejection, and exact
restore reconstruction.

## Integration

```powershell
py -m unittest tests.integration.test_sf600_hosted_store -v
```

Proves cutover import, row-digest verification, and activation remain three
separate durable fences.

## Workflow

```powershell
py -m unittest tests.workflow.test_sf600_hosted_store -v
```

Proves expired delivery recovery increments the lease generation, stale
projection completion fails, and projection reset creates a separately fenced
generation without deleting canonical records.

## Stress

```powershell
py -m unittest tests.stress.test_sf600_hosted_store_determinism -v
```

Proves 24 concurrent exports of a 500-row quiesced SQLite checkpoint produce
one record and manifest digest.

## PostgreSQL Engine Check

The migration SQL was applied directly to a local PostgreSQL 17 WASM engine,
without the Python adapter or a compatibility rewrite. The engine created all
seven hosted tables and the declared primary, unique, claim, lookup, and
single-active-cutover indexes.

This check validates PostgreSQL DDL semantics only. It is not managed
infrastructure, multi-host contention, managed failover, or Gate G evidence.

## Additional

```powershell
py -m compileall -q elder_protocol tests
py -m elder_protocol.cli validate
git diff --check
```

## Package Verification

The clean package build produced:

- wheel SHA-256
  `FFC1BBD4492DD74FBC1EAF4C028ACA6D11E3CB974A7DFC0639AED81C9696BC2A`
  (`2393449` bytes);
- source archive SHA-256
  `7BFA2AF64E139AF45CA56DC27DBD3973908E6E27E5A817DA82EAF73AD33FB3D7`
  (`1849075` bytes).

The wheel was installed with `--no-deps` into a fresh target outside the
checkout. From `C:\Users\neela`, the installed package imported from that
target and produced a one-record, typed, digest-bound SQLite cutover manifest
through the public SF-600 API.

## Corrected Ladder Results

| Level | Result |
|---|---|
| Foundation | 3 passed |
| Component | 13 passed |
| Integration | 1 passed |
| Workflow | 3 passed |
| Stress | 1 passed |

Total focused qualification: 21 passed.

## Limitations

- No Azure, hosted PostgreSQL, Redis, identity, secret, workspace, Git, or
  telemetry resource was created.
- The local PGlite TCP gateway accepted a simple client query but failed on a
  second session and multi-statement migration protocol. It was rejected as
  acceptance evidence.
- Multi-process and managed database failover remain deployment-level proof
  for SF-606. SF-600 proves the PostgreSQL locking, lease, rebind, recovery,
  and fail-closed mechanisms without claiming hosted qualification.
