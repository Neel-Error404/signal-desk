# Current Operational Baseline

**Task:** SF-001 - Establish Current Operational Baseline

**Status:** VERIFIED

**Assessment date:** 2026-08-07

**Source revision:** `87df2d6f4a1f5d98e0f67c6d63a9775e4d36264e`

**Branch:** `main`, two commits ahead of `origin/main`

**Activation:** `activation-elder-protocol-2bb973329496de46`

**Source worktree:** clean before SF-001 documentation edits

**Destination worktree:** uncommitted SF-001 documentation delta listed below

## Baseline Verdict

Elder is a verified local governance, assurance, reference-runtime, and bounded-autonomy
mechanism at canonical maturity L1. It is not a general operational software factory.

The repository has substantial local mechanisms for compilation, clean builds, evidence,
knowledge, bounded coordination, quarantined learning, qualification, supervised pull-request
packets, and fail-closed canary control. Those mechanisms do not establish a durable work-item
operations plane, hosted workers, protected delivery, external secret brokering, central
telemetry, active autonomy certification, production deployment, or automatic rollback.

An independently signed hosted bundle still qualifies at advisory L2 for exact historical
commit `d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`. It is not qualification for the current source
revision, does not mutate canonical maturity, and grants no current P5 authority.

## Evidence Classes

| Evidence class | What it can prove | What it cannot prove |
|---|---|---|
| Current command output | Current protocol, policy, store, Git, and readiness state | Hosted controls that were not contacted or reissued |
| Current ordered tests | Local implementation, composition, workflows, replay, and stress behavior | Production scale, external identity, or hosted durability |
| Disposable SQLite fixtures | Local initialization, integrity, policy binding, and empty-state status | Canonical runtime activity, production data, or tenant isolation |
| Signed P4.8A bundle | Advisory hosted L2 qualification for its exact commit and evidence window | Current-HEAD qualification, maturity mutation, or P5 activation |
| Historical phase evidence | Behavior verified at the recorded revision and scope | Automatic applicability to the current revision |

## Capability Baseline

| Capability | State | Current evidence | Boundary or missing proof |
|---|---|---|---|
| Protocol compiler and validation | VERIFIED | Protocol, schema, graph, skill, and profile validation pass | Does not govern arbitrary direct shell or edit calls |
| P3 local factory substrate | VERIFIED | Factory contract passes; clean-build, artifact, provenance, worktree, promotion, and rollback tests pass | No canonical durable work ledger or hosted worker fleet |
| Assurance and maturity reporting | VERIFIED | `elder assurance` reports 66 controls, 26 recommendations, L1, and `general_factory_operational: false` | Evidence above L1 remains qualification-bound and advisory |
| Evaluation and telemetry | VERIFIED | Local calibrated evaluation, correlation, cost, cardinality, and secret-field tests pass | No live provider evaluation, hosted evaluator isolation, collector, retention, or alerts |
| P4.4 knowledge and memory | VERIFIED | Local SQLite mechanism and tests pass; current repository store has integrity `ok` | Current store is empty; no hosted durability, access control, backup, or autonomous promotion |
| P4.5A authority and delegation | VERIFIED | Roles, identities, obligations, delegation, checkpoints, and fail-closed fixtures pass | No external identity authentication or hosted coordination |
| P4.5B coordinator | VERIFIED | Local SQLite leases, journals, messages, cancellation, expiry, replay, and concurrency tests pass | No canonical runtime store is active; no broker, remote worker, scheduler, or hosted checkpoints |
| P4.6 learning runtime | VERIFIED | Local immutable candidates, observations, evaluation, approvals, promotion packets, rollback packets, and replay pass | No canonical learning store is active; no target mutation, hosted shadow traffic, or production self-learning |
| P4.7/P4.8A qualification | VERIFIED | Policy has two trust anchors; historical signed bundle replays as advisory L2 | Current source revision is not hosted-qualified; canonical level remains L1 |
| P5.0/P5.1 autonomy contracts | VERIFIED | Five classes, exact matching, side-effect-free simulation, lifecycle replay, and incident accounting pass | No active certification or operational autonomy |
| P5.2 supervised PR mechanism | IMPLEMENTED | Packet, lease, signed-control, provider-response, and negative-path tests pass | Readiness is false; no authority source, L2 consumption, certification, protected branch, or external identity |
| P5.3 canary mechanism | IMPLEMENTED | Exact-plan authority, one-shot execution, observation, watchdog, rollback, crash recovery, and concurrency tests pass | Readiness is false; no L3 consumption, L3 class certification, secret broker, central telemetry, or real rollback evidence |
| Portable capsule and build memory | VERIFIED | Current capsule and ledger tests pass; generated projects use tracked `.elder` ledgers while the central kernel uses a local `.factory` fallback | Hosted capsule evidence is historical and commit-bound; recall-quality evidence remains limited |
| Repository dreaming | VERIFIED | Candidate-only local mechanism and provider adapters are tested | Live provider evidence is historical and was not rerun in this baseline; proposals cannot promote themselves |
| Git and CI | VERIFIED | Private remote exists and historical hosted CI evidence is commit-bound | Current HEAD has no hosted rerun; branch protection and merge queue remain unverified or plan-blocked |

## Current Store State

| Store | Current state | Classification |
|---|---|---|
| `.factory/runtime/knowledge.db` | Exists, schema version 1, integrity `ok`, zero nodes, edges, memories, and audit events | Current local derived store, empty |
| `.factory/runtime/runtime.db` | Missing | No canonical coordinator state |
| `.factory/runtime/learning.db` | Missing | No canonical learning state |
| `.tmp/software-factory/SF-001/runtime.db` | Fresh schema version 2 store, integrity `ok`, all counts zero | Disposable local fixture only |
| `.tmp/software-factory/SF-001/learning.db` | Fresh integrity-valid store bound to `example-agentic-product`, all counts zero | Disposable foreign-project fixture only |

Status commands can create parent directories or SQLite WAL state. They are inspection commands,
not guaranteed byte-for-byte read-only operations. Missing canonical stores were checked through
SQLite URI read-only probes rather than silently initialized.

## Allowed Claims

- Elder's canonical operational maturity is L1.
- The P3 through P5.3 mechanisms listed above are implemented or verified within their declared
  local, contract, fixture, or advisory-hosted scopes.
- The exact historical P4.8A bundle is independently signed and qualifies at advisory L2 when
  evaluated against its pinned policy and evidence window.
- P5.2 and P5.3 readiness currently fail closed.
- Humans retain merge, release, promotion, maturity, and certification-renewal authority.

## Prohibited Claims

- Elder is a general operational or production software factory.
- The current source revision is hosted-qualified at L2.
- Canonical maturity is L2 or L3.
- Supervised pull-request or canary authority is currently active.
- Synthetic or local fixture evidence proves hosted durability, tenant isolation, protected
  delivery, production telemetry, deployment, or automatic rollback.
- The empty local stores demonstrate an active work-item, coordinator, or learning workflow.

## Current Blockers

1. No canonical durable work-item ledger, transition service, queue, or owner-facing operations
   plane exists.
2. Protected branch rules, merge queue, and required checks are not verified for the private
   repository.
3. No active canonical project authority source, qualification consumption, or autonomy
   certification exists.
4. No external secret broker is configured.
5. No central production telemetry, retention, alerting, or remote canary observation exists.
6. No canonical hosted coordinator, remote worker, distributed scheduler, or external runtime
   identity exists.
7. No canonical hosted knowledge or learning durability, backup, recovery, or tenant isolation
   exists.
8. No real target deployment and automatic rollback exercise exists.
9. Live Mem0/Luna integration was not exercised in this baseline because the opt-in environment
   flag and network/provider execution were outside the task boundary.

## Documentation Drift Found

- `docs/p4-7-hosted-production-qualification.md` still described the pre-P4.8A state with no
  trust anchors. SF-001 updates its current-state section while preserving ADR 0013 as a
  historical decision snapshot.
- `docs/operational-readiness.md` described deployment and rollback evidence as a real approved
  canary. SF-001 narrows that row to local fixture mechanism tests.
- Hosted capsule, CI, reproducible-build, and live Mem0/Luna rows did not distinguish historical
  exact-commit evidence from the current revision. SF-001 now scopes those claims explicitly.
- The build-memory row did not distinguish generated projects' tracked `.elder` authority ledger
  from the central factory kernel's local `.factory` fallback. SF-001 now records both scopes.
- Older ADRs may state limitations that were true when accepted and later superseded. Factory
  work must use current executable behavior and machine-readable policy before historical prose.

## Destination Worktree

The source revision was clean when the baseline commands and full test ladder began. Completing
SF-001 intentionally leaves this uncommitted documentation-only delta:

- `docs/operational-readiness.md`
- `docs/p4-7-hosted-production-qualification.md`
- `docs/software-factory/README.md`
- `docs/software-factory/10-current-operational-baseline.md`
- `docs/software-factory/evidence/SF-001.md`

`git diff --check` passes. The destination is not represented as a clean committed revision; a
later explicit commit decision must bind these files to a new Git object.

## Acceptance Scenarios

| ID | Scenario | Acceptance condition | Result |
|---|---|---|---|
| SF001-A | Revision-bound baseline | Clean source revision and exact uncommitted destination file set are recorded | PASS |
| SF001-B | Machine truth agrees | Protocol, skills, factory, qualification, and autonomy validation pass | PASS |
| SF001-C | Authority remains fail-closed | P5.2 and P5.3 readiness are false with explicit blockers | PASS |
| SF001-D | Local and hosted evidence are separated | Every store and signed bundle is classified by scope | PASS |
| SF001-E | Stores fail closed or are explicitly fixtures | Missing canonical stores are not silently counted; fixture stores are labeled | PASS |
| SF001-F | Complete verification | Foundation through Stress run in order without unresolved failures | PASS |
| SF001-G | Handoff is assumption-free | SF-002 receives explicit available mechanisms, non-claims, and blockers | PASS |

## Reproduction Commands

Run from the repository root:

```powershell
git status --short --branch
git rev-parse HEAD
git rev-parse origin/main
git diff --check

.\.venv\Scripts\python.exe -m elder_protocol.cli validate
.\.venv\Scripts\python.exe -m elder_protocol.cli skills validate
.\.venv\Scripts\python.exe -m elder_protocol.cli factory validate --contract .\factory\factory-contract.json
.\.venv\Scripts\python.exe -m elder_protocol.cli factory status
.\.venv\Scripts\python.exe -m elder_protocol.cli assurance
.\.venv\Scripts\python.exe -m elder_protocol.cli knowledge status --store .factory\runtime\knowledge.db
.\.venv\Scripts\python.exe -m elder_protocol.cli qualification validate
.\.venv\Scripts\python.exe -m elder_protocol.cli autonomy validate
.\.venv\Scripts\python.exe -m elder_protocol.cli autonomy readiness
.\.venv\Scripts\python.exe -m elder_protocol.cli autonomy canary-readiness

.\.venv\Scripts\python.exe -m unittest discover -s tests\foundation -v
.\.venv\Scripts\python.exe -m unittest discover -s tests\component -v
.\.venv\Scripts\python.exe -m unittest discover -s tests\integration -v
.\.venv\Scripts\python.exe -m unittest discover -s tests\workflow -v
.\.venv\Scripts\python.exe -m unittest discover -s tests\stress -v
```

The historical bundle check is:

```powershell
.\.venv\Scripts\python.exe -m elder_protocol.cli qualification evaluate `
  --bundle .\docs\evidence\artifacts\p4-8a-run-31088377331\bundle.json `
  --at 2026-08-07T00:00:00+00:00
```

It must report advisory L2 for its exact historical revision and canonical L1.

## Test Results

| Level | Result |
|---|---|
| Foundation | 28 passed |
| Component | 167 passed |
| Integration | 29 run: 28 passed, 1 opt-in live-provider test skipped |
| Workflow | 15 passed |
| Stress | 14 passed |
| Total | 253 run: 252 passed, 1 skipped |

Protocol, skill registry, factory contract, qualification policy, autonomy policy, Git diff, and
store-integrity checks also passed.

## Handoff To SF-002

SF-002 may define a provider-neutral factory domain using the verified local contracts and
mechanisms above. It must not assume that a canonical work ledger, queue, hosted worker,
protected delivery path, active autonomy authority, or production deployment already exists.

The exact next task is `SF-002 - Define Canonical Factory Domain`.
