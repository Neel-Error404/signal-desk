# Phase 0 - Decisions And Spikes

## SF-000 - Pin Sources, Licensing, And Provenance

**Outcome:** Reproducible reference manifest and a human-approved code-reuse policy.

**Read:** Reference licenses and package manifests; `protocol/design-registry.json`;
`docs/design-governance.md`; dossier source snapshot table.

**Inspect:** Current Elder license state, each reference commit, dependency versions, and whether
code will be integrated, forked, or clean-room adapted.

**Implement:** A machine-readable research-source manifest, attribution format, license decision
record, and update procedure. Do not vendor code.

**Verify:** Foundation validation rejects missing commit, license, path, or decision. Manually
re-clone one source at the pinned commit.

**Exit:** Every later reuse task can identify exactly what may be copied or integrated.

## SF-001 - Establish Current Operational Baseline

**Outcome:** One evidence-bound baseline of what Elder can and cannot do before factory work.

**Read:** `README.md`, `docs/operational-readiness.md`, P4.4-P4.7 and P5.0-P5.3 docs and ADRs.

**Inspect:** Protocol validation, assurance report, factory status, knowledge store, coordinator,
learning store, qualification, autonomy readiness, Git state, and existing tests.

**Implement:** Baseline report with allowed claims, missing capabilities, current failures,
external blockers, and acceptance scenarios.

**Verify:** Re-run the commands recorded in the report. Separate local fixture evidence from
hosted evidence.

**Exit:** No roadmap task relies on an assumed capability.

## SF-002 - Define Canonical Factory Domain

**Outcome:** A provider-neutral entity, status, transition, and invariant model.

**Read:** Elder ontology and meta-architecture; Mastra work-item storage and transition service;
Prime session, goal, schedule, and messaging docs; HumanLayer approval/session models.

**Inspect:** Existing Elder work-item, run, delegation, checkpoint, evidence, and learning schemas
for overlap and naming conflicts.

**Implement:** Draft schemas for the entities listed in `03-target-architecture.md`, lifecycle
diagrams, invariants, and ownership. Reuse Elder identifiers where semantics match.

**Verify:** Foundation schema tests and invalid fixtures for duplicate identity, illegal
transition, missing project binding, and ambiguous authority.

**Exit:** One vocabulary supports operations, workers, owner UI, and learning.

## SF-003 - Define Stable Contracts And Events

**Outcome:** Versioned worker, governance, integration, and event contracts.

**Read:** Prime RPC/event interfaces and command journal; Mastra dispatcher and pending-start
records; Elder telemetry, context, delegation, and evidence schemas.

**Inspect:** Which existing Elder types can be referenced without coupling operations to internal
Python objects.

**Implement:** Language-neutral schemas, error taxonomy, idempotency rules, cursor semantics,
redaction rules, and conformance fixtures.

**Verify:** Foundation schema tests plus fake-adapter Component tests for success, rejection,
timeout, duplicate, stale cursor, and uncertain mutation.

**Exit:** A worker or operations implementation can be replaced without changing product truth.

## SF-004 - Mastra Operations Spike

**Outcome:** Evidence-based choice among package integration, selective fork, or local adaptation.

**Read:** Mastra `factory.ts`, dispatcher, start coordinator, transition service, work-item
storage, audit, metrics, package manifest, and template composition.

**Inspect:** Node requirements, Windows behavior, database needs, extension points, auth
assumptions, source-control integration, and package stability.

**Implement:** A throwaway vertical slice for intake, work item, transition, queued start, lease,
restart, and event query. Keep it outside canonical implementation.

**Verify:** Duplicate intake, process kill during dispatch, lease loss, retry exhaustion, and
restart. Record code size and maintenance delta for each option.

**Exit:** Human architecture decision with a scored build/integrate recommendation.

## SF-005 - Codex And Prime Worker Spike

**Outcome:** Proven worker contract feasibility and a primary/optional runtime decision.

**Read:** Codex invocation and local configuration used by Elder; Prime daemon architecture,
sessions, leases, RPC, schedules, goals, heartbeats, messaging, and refinement.

**Inspect:** Available machine interfaces, event fidelity, cancellation, resume identity,
workspace binding, credentials, and unsupported Windows behavior.

**Implement:** Fake adapter plus minimal Codex adapter. Add a separate experimental Prime adapter
only far enough to test the same conformance workflow.

**Verify:** Start, prompt, steer, checkpoint, detach, restart, reattach, cancel, duplicate command,
lost response, and evidence collection.

**Exit:** Codex is confirmed as primary or a blocker is documented; Prime has a bounded role.

## SF-006 - Ratify Operational Architecture

**Outcome:** Human-approved ADR selecting components, dependency direction, stores, and rollout.

**Read:** Outputs of SF-000 through SF-005; all accepted architecture ADRs; protected-surface
rules.

**Inspect:** Conflicts with current meta-architecture, authority, maturity, and repository
ownership.

**Implement:** Draft ADR and intentional protocol diffs. The authoring agent must not treat its
draft as approval.

**Verify:** Architecture fitness-function plan, threat review, migration/rollback plan, design
registry digest update plan, and Foundation validation in a review branch.

**Exit:** Explicit human ratification. Phase 1 may not begin on an unratified foundational choice.
