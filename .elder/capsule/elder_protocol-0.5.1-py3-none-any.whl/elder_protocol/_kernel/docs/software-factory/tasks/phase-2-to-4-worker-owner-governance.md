# Phases 2-4 - Worker, Owner, And Governance

## Phase 2 - Worker Runtime

### SF-200 - Worker Adapter Conformance Suite

**Status:** VERIFIED

**Outcome:** One executable contract all workers must pass.

**Entry:** Gate B is truthfully closed for its local scope. SF-107 has no unresolved Phase 1
`BLOCKER` or `REQUIRED` finding.

**Read:** SF-003 contracts; SF-005 worker spike and evidence; SF-105 run/session/workspace
binding; existing factory-contract validators and fake-adapter tests; the phase-proportional
delivery rule.

**Non-goals:** Real Codex execution, process management, workspace provisioning, owner UI, full
Elder lifecycle integration, Prime integration, hosted execution, multiple workers, or changing
the ratified SF-003 operation set. SF-200 also does not implement a process supervisor,
owner/scheduler command queue, pause/resume/waiting lifecycle, session leases, detach/reattach,
or a shared durable session-control service.

**Design:**

- pin the exact eight operations: `prepare`, `start`, `send`, `observe`, `checkpoint`, `cancel`,
  `recover`, and `collect-evidence`;
- define one provider-neutral adapter interface and reusable conformance runner;
- define capability discovery as validated adapter metadata, not new authority or a new public
  operation;
- bind `start` to the exact factory-owned SF-105 worker-session identity and generation, keeping
  any provider session ID as a separate opaque reference;
- define deterministic fake prepared-run receipts, adapter-private effect receipts, observed
  events, checkpoint observations, cancellation, recovery, and evidence state;
- reuse SF-003 request, response, command, event, cursor, error, idempotency, and redaction
  validators;
- require `validate_idempotent_replay()` and reject drift in every replay-bound work-item, run,
  session, correlation, causation, redaction, extension, payload-mode, payload-digest, and
  generation field;
- map prompt, follow-up, and steer through `send`; map inspection through existing observation,
  session, capability, and evidence surfaces rather than inventing operations;
- define exact duplicate, changed-payload, timeout, unsupported-capability, stale-cursor, lost
  response, uncertain mutation, and recovery behavior.

**Implement:** Production-quality adapter interface, validated capability manifest, deterministic
fake worker, minimal adapter-private receipt/effect ledger sufficient for restart tests,
normalized event observations and cursors, checkpoint observations, recovery, evidence bundles,
and one reusable conformance runner. The factory retains canonical session lifecycle and event
journal authority.

**Verify:**

- Foundation: exact operation set, unchanged field contracts, observation-only authority,
  capability validation, secret rejection, package inclusion;
- Component: all eight operations, prompt/follow-up/steer command forms, duplicate suppression,
  changed-payload and changed-context conflicts, exact SF-105 session identity/generation,
  timeout, uncertainty, stale cursor, unsupported capability, evidence;
- Integration: fresh-instance and process restart, one-effect reconciliation, normalized event
  validation, and agreement with SF-105 run/session/workspace references. Any subprocess is
  deterministic and test-owned rather than a reusable supervisor;
- Workflow: prepare through evidence with restart, steering, checkpoint, observation, cancellation,
  recovery, and one deterministic history;
- Stress only when the implementation introduces concurrent access, limited to duplicate-effect,
  cursor-order, and local-journal integrity.

**Completion:** The same runner can be applied unchanged to SF-201. The fake adapter passes all
required scenarios; no real provider claim is made; every finding is classified; no
current-scope `BLOCKER` or `REQUIRED` finding remains; and an independent implementation review
is reconciled against executable evidence.

**Directive:** See
[`../SF-200-implementation-directive.md`](../SF-200-implementation-directive.md).

### SF-201 - Codex Worker Adapter

**Status:** VERIFIED

**Outcome:** Codex executes a bounded work item through the factory.

**Read:** Codex project activation, local config, Elder session packet, and evidence contracts.

**Inspect:** Process invocation, prompts, session identity, output/events, interruption, and usage.

**Implement:** Adapter translation, bounded process lifecycle, protected adapter state, event
normalization, command correlation, terminal-turn validation, and sanitized actionable errors.

**Verify:** The unchanged SF-200 conformance suite passes. One real Codex task in a disposable Git
repository creates only the expected untracked artifact while HEAD, branch, refs, commit count,
and index remain unchanged. Failed and interrupted turns remain uncertain; pending-process
liveness, expiry, and timer races fail closed.

**Completion:** Exact `codex-cli 0.146.1` policy verification, protected store placement, bounded
first-turn persistence, restartable post-turn identity, digest-only diagnostics, installed-wheel
conformance, and independent review are verified. No current-scope `BLOCKER` or `REQUIRED`
finding remains. See [design](../SF-201-design.md),
[test reproduction](../SF-201-test-reproduction.md), and
[evidence](../evidence/SF-201.md).

### SF-202 - Workspace And Sandbox Lifecycle

**Status:** VERIFIED

**Outcome:** Each run receives a controlled, attributable workspace.

**Read:** Elder P3 worktree substrate; Mastra sandbox binding; Prime sandbox warning.

**Inspect:** Git state, ignored files, secrets, untrusted instructions, dependency caches,
cleanup, and platform behavior.

**Implement:** Prepare, validate, lease, inspect, quarantine, release, and recover operations.

**Verify:** Dirty source, hostile repository instructions, leaked secret attempt, crash cleanup,
concurrent work, and retained failed workspace.

**Completion:** Exact SF-105 binding, clean materialization, filtered-byte instruction trust,
Windows reparse protection, canonical-state-fenced local leases, durable secretless sandbox
handoff to real Codex, nested ignored-secret detection, stable quarantine and clean release,
restart reconstruction, spawned-process contention, installed-wheel execution, and independent
review are verified. No current-scope `BLOCKER` or `REQUIRED` finding remains. See
[design](../SF-202-design.md), [test reproduction](../SF-202-test-reproduction.md), and
[evidence](../evidence/SF-202.md).

### SF-203 - Durable Session Control

**Status:** VERIFIED

**Outcome:** Owner and scheduler can start, steer, pause, resume, cancel, and checkpoint.

**Read:** Prime goals, heartbeats, schedules, leases, message delivery, and crash recovery;
HumanLayer waiting states.

**Implement:** Command queue, session state machine, checkpoint cursor, waiting reason, follow-up,
and reconciliation.

**Verify:** Detach/reattach, restart, duplicate command, out-of-order event, cancel race, and
waiting-for-owner continuation.

Exact duplicates replay from the durable record before lifecycle validation.
Incomplete adapter acceptance and duplicate effects without the original
exchange fail closed as uncertain. Canonical Elder checkpoint identity,
SF-200 responses, event aggregate identity, and the issued SF-202 binding are
validated. Foundation through Stress, installed-wheel execution, and
independent re-review pass with no current-scope `BLOCKER` or `REQUIRED`
finding. See [design](../SF-203-design.md),
[test reproduction](../SF-203-test-reproduction.md), and
[evidence](../evidence/SF-203.md).

### SF-204 - Optional Prime Agent Adapter

**Status:** OPTIONAL - VERIFIED

**Outcome:** Prime Agent can be selected for an approved task without becoming factory authority.

**Read:** Prime SDK/RPC, daemon, worker architecture, messaging, schedules, and refinement.

**Implement:** Adapter only if SF-005 and architecture ratification selected integration. Redirect
governed refinements into learning candidates.

**Verify:** Conformance, daemon restart, session lease conflict, command journal replay, and direct
global-refinement prevention.

**Evidence:** The unchanged SF-200 contract, deterministic provider recovery, real Node
named-pipe bridge, package install, and focused Foundation through Stress ladder pass. Prime
automatic refinement is disabled in the dedicated agent state, conflicting project overrides
fail before dispatch, and any recorded provider-local refinement application stops delivery as
uncertain. No live credentialed model execution is claimed. See
[design](../SF-204-design.md), [test reproduction](../SF-204-test-reproduction.md), and
[evidence](../evidence/SF-204.md).

### SF-205 - Goals, Schedules, And Heartbeats

**Status:** VERIFIED

**Outcome:** Long tasks re-enter for explicit reasons under budgets.

**Read:** Prime persistent goals, schedules, heartbeats, autonomous limits; Elder budgets and
delegation expiry.

**Implement:** Factory-owned goal, schedule, heartbeat, continuation budget, and stop reason.

**Verify:** Deadline, token/time budget, duplicate tick, missed tick, paused work, and expired
authority. Uncertain ticks are not replayed blindly.

**Completion:** Durable exact-bound goals, fixed-interval schedules,
deterministic ticks, append-only heartbeats, current active Elder authority,
pre-acceptance result-budget enforcement, owner-waiting suppression, restart
behavior, storage tamper detection, and spawned duplicate dispatch and result
contention are verified. See [design](../SF-205-design.md),
[test reproduction](../SF-205-test-reproduction.md), and
[evidence](../evidence/SF-205.md).

### SF-206 - Worker Recovery And Reconciliation

**Status:** VERIFIED

**Outcome:** Worker and operations state converge after failures.

**Read:** Prime adoption/recovery and Mastra dispatch reconciliation.

**Implement:** Recovery sweep, worker inspect, command outcome reconciliation, orphan detection,
and owner-visible terminal states.

**Verify:** Kill before acknowledgement, after side effect, during checkpoint, and during cancel.

**Completion:** Exact recovery episodes, durable accepted recovery requests,
single-session observation reuse, safe requeue, cross-store convergence,
start/checkpoint/cancel fail-closed behavior, SF-205 uncertainty propagation,
orphan discovery, and concurrent sweep admission are verified. See
[design](../SF-206-design.md),
[test reproduction](../SF-206-test-reproduction.md), and
[evidence](../evidence/SF-206.md).

## Phase 3 - Owner Control Room

### SF-300 - Owner Inbox And Attention Model

**Outcome:** One queue for decisions, failures, approvals, and material changes.

**Read:** HumanLayer approvals and Factory.ai automation visibility patterns.

**Implement:** Prioritized inbox with reason, age, consequence, evidence, and allowed actions.

**Verify:** No hidden waiting state; duplicate requests coalesce without losing evidence.

### SF-301 - Product Portfolio And Work Board

**Status:** VERIFIED

**Outcome:** Owner sees each factory and work item by real operational state.

**Read:** Mastra factory board and metrics.

**Implement:** Product switcher, stage board/list, filters, dependency/blocker state, and live
projection updates.

**Verify:** Projection replay, stale indicator, large backlog, and mobile/desktop usability.

**Completion:** Exact project-grant scoping, current product and work-item
projection binding, deterministic counts and dependency state, stale cursor
rejection, bounded backlog paging, same-origin loopback presentation,
desktop/mobile usability, package installation, and a clean browser console
are verified. See [design](../SF-301-design.md),
[test reproduction](../SF-301-test-reproduction.md), and
[evidence](../evidence/SF-301.md).

### SF-302 - Work Room

**Status:** VERIFIED

**Outcome:** Discussion, steering, events, artifacts, and decisions share one durable context.

**Implement:** Timeline, owner messages, agent summaries, plan, checkpoints, diff/test evidence,
artifacts, and command controls.

**Verify:** Refresh/restart continuity, message correlation, redaction, and concurrent owner input.

**Completion:** Exact project/work-item/run binding, source-stable room
composition, append-only owner notes, request-time-bound source replay,
existing SF-203 control admission, API restart continuity, concurrent input
deduplication, responsive desktop/mobile presentation, package installation,
and a clean browser console are verified. See
[design](../SF-302-design.md),
[test reproduction](../SF-302-test-reproduction.md), and
[evidence](../evidence/SF-302.md).

### SF-303 - Approvals And Escalations

**Status:** VERIFIED

**Outcome:** Human decisions are explicit, scoped, expiring, and replayable.

**Read:** HumanLayer approval correlation; Elder authority and P5 controls.

**Implement:** Decision request, choices, impact, expiry, approver identity, response, and
downstream transition.

**Verify:** Wrong approver, expired decision, duplicate response, changed underlying digest, and
cancelled work.

**Completion:** Exact work-item digest and role binding, immutable decisions,
append-only request and effect histories, expiry and cancellation,
response-loss reconciliation, authenticated API replay, downstream transition
effects, concurrent response exclusion, responsive desktop/mobile operation,
and installed-package availability are verified. See
[design](../SF-303-design.md),
[test reproduction](../SF-303-test-reproduction.md), and
[evidence](../evidence/SF-303.md).

### SF-304 - Audit And Replay View

**Status:** VERIFIED

**Outcome:** Owner can answer who did what, why, with which authority and evidence.

**Implement:** Correlated event timeline and replay-safe projections linking intent through
outcome.

**Verify:** Rebuild view from journal and expose limitations rather than inventing missing links.

**Completion:** Exact journal order and chain data, explicit missing-link
limitations, digest-bound non-journal owner records, deterministic projection
rebuild, authenticated restart continuity, concurrent read stability,
responsive desktop/mobile presentation, and installed-package availability
are verified. See [design](../SF-304-design.md),
[test reproduction](../SF-304-test-reproduction.md), and
[evidence](../evidence/SF-304.md).

### SF-305 - Metrics, Cost, And Outcomes

**Status:** VERIFIED

**Outcome:** Factory quality is measured by delivery and control outcomes.

**Read:** Elder telemetry/economics; Mastra metrics.

**Implement:** Cycle time, wait time, retry, failure, owner intervention, test quality, cost,
learning impact, and outcome status.

**Verify:** Metric definitions, cardinality, redaction, missing data, and reconciliation.

**Completion:** Closed metric definitions, exact outcome and intervention
counts, duration summaries, recorded test-evidence coverage, explicit
unavailable cost and learning impact, cross-store source reconciliation,
authenticated restart continuity, deterministic concurrent reads, responsive
desktop/mobile presentation, and installed-package availability are verified.
See [design](../SF-305-design.md),
[test reproduction](../SF-305-test-reproduction.md), and
[evidence](../evidence/SF-305.md).

All Phase 3 implementation tasks and the separate Gate D qualification are
verified. SF-400 through SF-404 and the separate Gate E qualification are
verified. Phase 4 is complete for its bounded local claim.

## Phase 4 - Elder Lifecycle Integration

### SF-400 - Elder Boundary Service

**Status:** `VERIFIED` on 2026-08-14.

**Outcome:** Operations can call Elder through stable, versioned decisions.

**Implement:** Adapter or service for classify, context, delegation, evidence, evaluation,
qualification, autonomy, and learning.

**Verify:** Protocol digest mismatch, stale policy, unavailable service, and fail-closed response.

The unchanged SF-003 governance adapter now has one concrete local gateway.
It binds calls to current protocol and operation-policy digests, routes all
eight operations to explicit Elder handlers, returns canonical records by
identity and digest, and durably prevents duplicate or uncertain learning
effects. See [design](../SF-400-design.md),
[test reproduction](../SF-400-test-reproduction.md), and
[evidence](../evidence/SF-400.md).

### SF-401 - Governed Context Assembly

**Status:** `VERIFIED` on 2026-08-14.

**Outcome:** Worker starts with task-specific, authorized, budgeted context.

**Read:** P4.4 context and memory policy; project activation packet.

**Implement:** Context request from work item/run, packet persistence, digest binding, and refresh
rules.

**Verify:** Empty/wildcard retrieval, stale source, unauthorized memory, budget overflow, and
changed packet after authorization.

The local implementation derives query, identity, delegated scope, and token
ceiling from the queued Work Item Ledger record, generated-project activation,
and validated P4.5A child-run chain. It calls the unchanged SF-400 boundary by
safe request reference, persists the full P4.4 request and packet in an
Elder-owned immutable store, replays exact duplicates, requires a new child run
and packet identity for refresh, and revalidates activation, work, run, source,
and authorized packet digests before use. See
[design](../SF-401-design.md),
[test reproduction](../SF-401-test-reproduction.md), and
[evidence](../evidence/SF-401.md).

### SF-402 - Authority And Delegation Integration

**Status:** `VERIFIED` on 2026-08-14.

**Outcome:** Run and child work cannot exceed product or parent authority.

**Read:** P4.5A/B and P5 autonomy contracts.

**Implement:** Start gate, child delegation gate, lease binding, expiry, cancellation propagation,
and owner-visible rejection.

**Verify:** Scope/tool/budget/deadline/identity expansion and missing assigned-child lease.

The local integration composes the current queued work item, immutable SF-401
packet, generated-project authority, P4.5A run chain, and P4.5B coordinator.
It issues only the assigned child's short-lived lease, rechecks context and
lease before execution, propagates cancellation, and persists accepted and
rejected decisions without the raw lease token. Scope, tool, budget, deadline,
identity, context, lease, expiry, cancellation, restart, replay, and concurrent
retry behavior are verified. See [design](../SF-402-design.md),
[test reproduction](../SF-402-test-reproduction.md), and
[evidence](../evidence/SF-402.md).

### SF-403 - Evidence And Test Pipeline

**Status:** `VERIFIED` on 2026-08-14.

**Outcome:** Completion depends on ordered, linked proof.

**Implement:** Test plan, result ingestion, diff/artifact digest, independent evaluation request,
and completion guard.

**Verify:** Failed lower level, stale result, changed diff after test, missing evaluator, and
secret-shaped trace.

The local pipeline derives the ordered levels from the current work item,
requires an active SF-402 child lease and context at plan creation, binds all
results to one immutable Git fingerprint and exact artifact bytes, and requires
an independent advisory evaluation before emitting completion evidence.
Failed lower levels, stale results, changed diff or artifacts, secret-shaped
traces, missing or non-independent evaluation, conflicting concurrent replay,
and tampered durable rows fail closed. The existing product-owner transition
retains outcome acceptance. See [design](../SF-403-design.md),
[test reproduction](../SF-403-test-reproduction.md), and
[evidence](../evidence/SF-403.md).

### SF-404 - Supervised Delivery

**Status:** `VERIFIED` on 2026-08-14.

**Outcome:** Eligible work produces an exact P5.2 supervised pull-request packet.

**Read:** P4.7 qualification and P5.0-P5.2.

**Implement:** Trusted-source assembly, current hard-stop recheck, provider call boundary, response
verification, and owner delivery decision.

**Verify:** Expired qualification, inactive certification, unprotected branch, changed diff,
provider mismatch, and URL mismatch.

The local integration composes current SF-402 execution authority and SF-403
ordered completion with the existing signed P4.7/P5.2 authority gates. It
persists the product-owner submit or reject decision before provider
invocation, accepts only an exact packet-bound response, exposes durable
authorized, ready, blocked, rejected, submitting, open, and
reconciliation-required states, and prevents blind provider retry. Expired
qualification, inactive certification, unprotected hosted controls, changed
proof, unauthorized owners, provider or URL mismatch, concurrent retry, and
tampered durable rows fail closed. See [design](../SF-404-design.md),
[test reproduction](../SF-404-test-reproduction.md), and
[evidence](../evidence/SF-404.md).

**Phase Exit:** One owner-visible issue-to-supervised-delivery workflow survives restart and fails
closed on stale authority, stale context, missing evidence, and unauthorized transition.

**Qualification:** `VERIFIED` on 2026-08-14. The exact ledger work item was
classified through SF-400 and reconstructed through SF-401, SF-402, SF-403,
and SF-404 before and after one owner-approved supervised response. Expired
authority, stale context, missing evidence, and unauthorized transition
stopped with owner-visible reasons. See
[task packet](../Gate-E-qualification-task-packet.md),
[design](../Gate-E-qualification-design.md),
[test reproduction](../Gate-E-qualification-test-reproduction.md), and
[evidence](../evidence/Gate-E.md).
