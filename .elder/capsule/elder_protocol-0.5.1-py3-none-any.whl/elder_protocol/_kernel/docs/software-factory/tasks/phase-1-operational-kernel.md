# Phase 1 - Operational Kernel

## SF-100 - Product Factory Registry

**Outcome:** Durable per-product factory configuration and lifecycle.

**Read:** Elder project profile/compiler; Mastra project storage and configuration.

**Inspect:** Which product facts are canonical, generated, secret, or environment-specific.

**Implement:** Registry, profile version binding, status, repository binding, worker policy,
integration references, and validation.

**Verify:** Foundation schemas; Component create/update/conflict/archive; no secret persistence.

## SF-101 - Signal Intake

**Outcome:** External and owner signals become idempotent, reviewable intake records.

**Read:** Mastra intake/integration routes and idempotency; Elder work-item and telemetry schemas.

**Inspect:** Manual, GitHub, Linear, schedule, incident, and learning signal requirements.

**Implement:** Signal envelope, source authentication result, dedupe key, quarantine state,
normalization, and work-item creation boundary.

**Verify:** Duplicate, replayed, malformed, unauthorized, and out-of-order signals.

## SF-102 - Work-Item Ledger

**Outcome:** Canonical versioned backlog independent of sessions and issue providers.

**Read:** Mastra work-item base storage and metrics; Elder autonomy work-item schema.

**Inspect:** Required fields for product intent, acceptance, authority, dependencies, source,
priority, class, and evidence.

**Implement:** Transactional ledger, revisions, exclusive stage, history, source links, optimistic
concurrency, and queries.

**Verify:** Component CRUD/conflict/history; Integration intake-to-ledger; restart durability.

## SF-103 - Transition And Rule Engine

**Outcome:** Deterministic lifecycle changes with explicit actors and reasons.

**Read:** Mastra transition service and default rules; Elder authority and change classes.

**Inspect:** Which transitions require owner decisions, worker evidence, or Elder authorization.

**Implement:** Transition command, guard evaluation, atomic history, rejection record, and
terminal hooks.

**Verify:** Legal/illegal transitions, duplicate ingress, version conflicts, unauthorized actor,
and terminal idempotency.

## SF-104 - Durable Dispatcher

**Outcome:** Queued decisions and starts survive restart and execute once within defined semantics.

**Read:** Mastra dispatcher, leases, retry and pending-start storage; Prime command journal and
schedule claim behavior.

**Inspect:** Concurrency, capacity, lease timing, backoff, cancellation, dead-letter, and uncertain
delivery requirements.

**Implement:** Claim, renew, execute, reconcile, complete, retry, fail, and dead-letter states with
bounded attempts.

**Verify:** Lease loss, process kill, duplicate claim, worker unavailable, uncertain delivery,
backlog, and graceful shutdown.

## SF-105 - Run, Session, And Workspace Binding

**Status:** VERIFIED.

**Outcome:** Every execution has durable bindings from work item to authority, context, worker,
workspace, session, and artifact.

**Read:** Elder runs/delegations/checkpoints; Mastra start coordinator; Prime session tree and
lease model.

**Inspect:** Reuse rules, cleanup, source revision, untrusted instructions, and concurrent work.

**Implement:** Run creation, immutable initial bindings, mutable lifecycle state, checkpoint
references, cleanup intent, and recovery metadata.

**Verify:** Wrong repository/session binding, stale source revision, duplicate start, recovery,
and terminal cleanup.

**Evidence:** [SF-105 evidence](../evidence/SF-105.md), [design](../SF-105-design.md), and
[test reproduction](../SF-105-test-reproduction.md).

## SF-106 - Event Journal And Projections

**Outcome:** Append-only operational truth with rebuildable read models.

**Read:** Elder orchestration replay and telemetry; Prime JSONL sessions; Mastra audit domain.

**Inspect:** Required event ordering, causation, redaction, retention, and projection queries.

**Implement:** Transactional append, cursor, schema version, projection workers, replay, and
projection reset.

**Verify:** Rebuild equality, duplicate event rejection, partial projection recovery, corrupted
event failure, and secret-shaped payload rejection.

## SF-107 - Operations API And Health

**Status:** VERIFIED - local Gate B passes.

**Outcome:** Stable API for owner UI, integrations, and workers.

**Read:** Contracts from SF-003 and Elder runtime health conventions.

**Inspect:** Authentication boundary, pagination, command status, long-poll/event transport, and
health dependencies.

**Implement:** APIs for products, signals, work items, transitions, commands, runs, events,
decisions, and health/readiness.

**Verify:** Contract tests, authorization tests, error bodies, pagination, event cursor resume,
and dependency degradation.

**Phase Exit:** Kill and restart the operations process during queued and leased work. The ledger,
event history, and accepted commands remain correct, and projections rebuild deterministically.
