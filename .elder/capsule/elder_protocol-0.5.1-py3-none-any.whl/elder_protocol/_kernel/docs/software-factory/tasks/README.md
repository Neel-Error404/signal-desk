# Software Factory Task Catalog

Execute tasks in phase order and obey
[`../05-task-execution-contract.md`](../05-task-execution-contract.md).

| File | Scope |
|---|---|
| [Phase 0](phase-0-decisions-and-spikes.md) | Source, domain, contract, and architecture decisions |
| [Phase 1](phase-1-operational-kernel.md) | Durable operations control plane |
| [Phases 2-4](phase-2-to-4-worker-owner-governance.md) | Workers, owner control room, and Elder integration |
| [Phase 5](phase-5-continual-learning.md) | Prime-style proposals plus Elder promotion |
| [Phases 6-7](phase-6-to-7-hosted-autonomy.md) | Hosted L2 and narrow L3 |

Each task entry specifies the additional reading, implementation target, and proof beyond the
universal task contract. A task id is a stable planning identifier, not proof of implementation.
