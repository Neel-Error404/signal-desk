# Phases 6-7 - Hosted Operation And Narrow Autonomy

## Phase 6 - Hosted L2

### SF-600 - Hosted Durable Stores And Broker

**Outcome:** Postgres-backed truth and durable multi-process delivery.

**Read:** Local kernel contracts; Mastra Postgres and Redis-stream composition.

**Implement:** Migrations, broker adapter, outbox/inbox, leases, projection workers, backup, and
restore.

**Verify:** Multi-process contention, duplicate delivery, broker outage, database failover,
restore, and projection rebuild.

### SF-601 - External Identity And Secret Broker

**Outcome:** Every service and worker has verified workload identity and scoped secret access.

**Read:** Elder trust anchors, authority source, hosted qualification, and canary requirements.

**Implement:** Identity verification, secret references, short-lived credentials, rotation,
revocation, and audit.

**Verify:** Wrong subject, expired token, cross-product access, secret telemetry, and broker
outage.

### SF-602 - Hardened Hosted Workspaces

**Outcome:** Remote workers execute in isolated, disposable environments.

**Implement:** Image/artifact pinning, network/tool policy, resource budgets, secret injection,
egress records, retention, and destruction.

**Verify:** Escape attempts, unauthorized network, resource exhaustion, hostile repository,
image mismatch, and cleanup failure.

### SF-603 - Production Integrations

**Outcome:** GitHub, issue tracker, chat, CI, and notifications use authenticated idempotent
adapters.

**Implement:** One integration at a time with source identity, signature verification, pagination,
rate limits, reconciliation, and dead-letter handling.

**Verify:** Forged webhook, duplicate event, provider outage, rate limit, changed external record,
and replay.

### SF-604 - Hosted Git And Review Controls

**Outcome:** Protected branches, independent review, provenance, and exact PR delivery are active.

**Read:** P4.8A and P5.2.

**Implement:** Required checks, branch rules, trusted provider statements, independent signer,
artifact provenance, and evidence retention.

**Verify:** Attempted bypass, stale statement, changed commit, untrusted URL, and missing check.

### SF-605 - Multi-Product Boundaries And Recovery

**Outcome:** Multiple product factories cannot read or mutate one another.

**Implement:** Tenant/product authorization, storage partitioning, quotas, audit export, backup,
restore, and disaster runbook.

**Verify:** Cross-product identifiers, cache leakage, worker reuse, backup restore isolation, and
operator error.

### SF-606 - Hosted L2 Qualification Exercise

**Outcome:** Current signed evidence supports a human-ratified L2 claim for the exact revision.

**Implement:** Complete evidence bundle, independent issuance/review, canonical re-evaluation,
contradiction checks, and ratification packet.

**Verify:** Freshness, signer trust, payload bytes, source host, project/environment/artifact,
contradictions, and cumulative gates.

## Phase 7 - Narrow L3

### SF-700 - Select And Certify One L3 Class

**Outcome:** One reversible low-risk class has exact paths, tools, rules, checks, budgets, and
incident policy.

**Verify:** Exact matching, simulation, lifecycle replay, suspension, revocation, and zero
ambiguity.

### SF-701 - Production Signal And Deployment Adapter

**Outcome:** A qualified signal can create one exactly bound canary plan and provider command.

**Implement:** Signal-to-work binding, immutable artifacts, target identity, packet reconstruction,
one-shot consumption, and exact provider response.

**Verify:** Replay, changed artifact, target mismatch, uncertain provider response, and timeout.

### SF-702 - Central Telemetry And SLO Evaluation

**Outcome:** Canary health is evaluated from trusted central observations.

**Implement:** Signed observation ingestion, sample thresholds, health windows, missing-data
deadline, cardinality controls, and alerting.

**Verify:** Forged observation, wrong deployment, insufficient samples, missing telemetry, stale
time, and collector outage.

### SF-703 - Automatic Rollback

**Outcome:** Any declared breach produces and executes one exact rollback within its authority
window.

**Read:** P5.3 runtime and canary policy.

**Implement:** Durable deadline, atomic claim, provider invocation, exact response validation,
recovery sweep, and terminal state.

**Verify:** Injected health breach, timer failure, restart during rollback, expired authority,
duplicate executor, and provider uncertainty.

### SF-704 - Dynamic Risk And Incident Control

**Outcome:** Incidents, rollbacks, drift, and budget consumption suspend future automation.

**Implement:** Incident ledger, rolling budgets, escalation, certification suspension, recovery
criteria, and owner review.

**Verify:** First incident under zero tolerance, window boundary, delayed incident, concurrent
events, and manual revocation.

### SF-705 - L3 Qualification Exercise

**Outcome:** One real canary class is qualified at L3 without expanding authority.

**Verify:** Real threshold breach rolls back automatically. Healthy evidence only continues
observation. Merge, full rollout, maturity mutation, and auto-renewal remain human controlled.

## Final Boundary

Completion of these tasks does not establish L4 or L5. Those levels require separately defined
evidence for broader self-directed planning, portfolio optimization, and strategic autonomy.
