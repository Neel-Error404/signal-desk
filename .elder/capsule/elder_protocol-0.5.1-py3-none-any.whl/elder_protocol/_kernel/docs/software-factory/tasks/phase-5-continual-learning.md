# Phase 5 - Continual Learning

## SF-500 - Normalize Learning Trajectories

**Current status:** `VERIFIED` on 2026-08-14 through independent review,
package build, and outside-checkout installed-wheel execution. Canonical Elder
maturity remains L1 and Gate F is not qualified.

**Outcome:** Worker actions, owner corrections, tests, outcomes, retrieval, and incidents form a
bounded learning input.

**Read:** Elder telemetry/evidence/learning schemas; Prime refinement trajectory construction.

**Inspect:** Available events, redaction needs, context size, source trust, and outcome delay.

**Implement:** Versioned trajectory view with evidence digests, exclusions, and deterministic
sampling.

**Verify:** Missing links, secret redaction, oversized trajectory, duplicate events, and delayed
outcome attachment.

Current implementation also fails closed on changed run/event bindings,
free-form references, raw source files above 2 MiB, source/output aliases,
forged event time or anchor data, incomplete expected outcomes, and
non-deterministic source or evidence ordering. See
[design](../SF-500-design.md),
[test reproduction](../SF-500-test-reproduction.md), and
[evidence](../evidence/SF-500.md).

## SF-501 - Refinement Trigger And Review Gate

**Outcome:** The factory detects plausible reusable lessons without flooding the queue.

**Read:** Prime auto-refine interval, compaction trigger, review gate, and explicit refine path.

**Implement:** Explicit and automatic triggers, recurrence rules, rate limits, scope default,
model review, and no-proposal outcome.

**Verify:** One-off event, repeated correction, severe incident, compaction, noisy trajectory,
rate limit, and model failure.

## SF-502 - Typed Learning Proposal

**Outcome:** Review output becomes a narrow, versioned proposal with evidence and rollback data.

**Read:** Prime harness entry/refinement types and baseline conflict checks; Elder candidate
schema and policy.

**Implement:** Candidate schema from `04-governed-continual-learning.md`, Prime translation,
before/after snapshots, conflict key, expiry, and protected-target routing.

**Verify:** Invalid kind, missing evidence, stale base, concurrent target change, over-broad scope,
and constitutional target.

## SF-503 - Replay And Shadow Runner

**Outcome:** Candidates are tested against positive, negative, and live-shadow cases without
governed side effects.

**Read:** P4.6 runtime and policy; worker adapter and evidence pipeline.

**Implement:** Historical case selector, isolated context injection, baseline/candidate pairing,
shadow command, observations, and cost controls.

**Verify:** Minimum case counts, no side effects, case leakage, worker failure, critical
regression, and reproducibility.

## SF-504 - Independent Evaluation And Approval

**Outcome:** Proposal, execution, evaluation, approval, and promotion identities remain separate.

**Implement:** Evaluator assignment, calibrated rubric, disagreement/abstention, required roles,
approval digest, expiry, and immutable decision record.

**Verify:** Self-evaluation, self-approval, missing role, changed candidate, expired approval,
worse case, and critical regression.

## SF-505 - Governed Target Application

**Outcome:** One approved low-risk target can actually be updated through a separate adapter.

**Initial target:** Project-scoped trusted memory or supplemental prompt. Do not start with policy,
evaluator, architecture, or production.

**Read:** P4.6 promotion packet, target storage/versioning, and repository ownership.

**Implement:** Packet revalidation, target compare-and-swap, revision, audit event, activation,
and rollback pointer.

**Verify:** Wrong promoter, stale target, reused packet, expired packet, partial write, and restart.

## SF-506 - Outcome Monitor, Suspension, And Rollback

**Outcome:** Promoted learning remains accountable to measured downstream behavior.

**Implement:** Usage linkage, expected metrics, observation window, regression thresholds,
automatic suspension, rollback command, and owner notification.

**Verify:** No usage, ineffective entry, cost regression, correctness regression, delayed outcome,
rollback failure, and recovery.

## SF-507 - Retrieval Reachability And Learning Quality

**Outcome:** Promoted entries are retrieved only where useful and their effect is measurable.

**Read:** Elder context policy and Prime harness overview/injection behavior.

**Implement:** Positive/negative retrieval cases, budget fit, usage acknowledgement, outcome
attribution, retirement, and revision workflow.

**Verify:** Unreachable entry, unrelated retrieval, context crowding, stale memory, conflicting
entries, and no measurable effect.

## Phase Exit

Demonstrate three cases:

1. A repeated owner correction produces a valid candidate.
2. An independently evaluated bad candidate is rejected and never reaches the target.
3. An approved project-scoped candidate improves held-out work, is retrieved correctly, and can
   be suspended and rolled back.

No phase result may claim autonomous policy, evaluator, architecture, or production self-editing.
