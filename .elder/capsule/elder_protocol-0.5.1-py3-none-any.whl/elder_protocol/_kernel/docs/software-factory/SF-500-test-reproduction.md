# SF-500 Test Reproduction

**Status:** VERIFIED on 2026-08-14

## Foundation

```powershell
py -m unittest tests.foundation.test_sf500_learning_trajectory_contract -v
```

Proves exported contracts, closed schemas, source and manifest digest binding,
L1 preservation, and the exclusion of SF-501 through SF-507 and Gate F.

## Component

```powershell
py -m unittest tests.component.test_sf500_learning_trajectory -v
```

Proves all trajectory categories, safe token metrics, plural and singular raw
content redaction, opaque source references, exact run bindings, missing links,
complete multi-outcome attachment, delayed, unknown, and mismatched outcomes,
oversize handling, duplicate collision handling, forged-artifact rejection,
absolute timestamp ordering, deterministic sampling, anchor preservation, and
changed-source digest propagation.

## Integration

```powershell
py -m unittest tests.integration.test_sf500_learning_trajectory -v
```

Proves current operational source classes form one evidence-bound trajectory
without creating or mutating P4.6 candidates, observations, evaluations,
approvals, promotions, journals, or any learning-store byte.

## Workflow

```powershell
py -m unittest tests.workflow.test_sf500_learning_trajectory -v
```

Proves the read-only CLI writes a validated pending trajectory without
requiring or creating a learning database, rejects source/output aliasing, and
rejects an oversized source before JSON parsing.

## Stress

```powershell
py -m unittest tests.stress.test_sf500_learning_trajectory_determinism -v
```

Proves concurrent normalization of large source permutations produces one
bounded digest while retaining every anchor.

## Additional

```powershell
py -m unittest tests.foundation.test_product_factory_registry -v
py -m compileall -q elder_protocol tests scripts
py -m elder_protocol.cli validate
git diff --check
```

## Corrected Ladder Results

| Level | Result |
|---|---|
| Foundation | 3 passed |
| Component | 12 passed |
| Integration | 1 passed |
| Workflow | 2 passed |
| Stress | 1 passed |

Additional focused regressions passed: product-factory schema catalog `6/6`,
operational architecture `8/8`, and existing P4.6 CLI workflow `1/1`.
Compilation, protocol validation, and `git diff --check` passed.

Independent review found no remaining current-scope `BLOCKER` or `REQUIRED`
finding. The package built in a fresh output directory, and the installed
wheel passed direct normalization and CLI reproduction from outside the
checkout.
