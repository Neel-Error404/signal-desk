# SF-401 Governed Context Assembly Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Ordered Ladder

### Foundation

```powershell
py -m unittest tests.foundation.test_sf401_governed_context_contract -v
```

Final result: `3 passed`.

The first run had one failure because the implementation plan omitted the
explicit L1 maturity ceiling. The same level was rerun and exposed the same
scope marker missing from this reproduction document. Both documents now
state that SF-402 has not started and canonical maturity remains L1. The third
Foundation run passed.

### Component

```powershell
py -m unittest tests.component.test_sf401_governed_context -v
```

Final result: `4 passed`.

Before the formal level, the first executable smoke rejected the new
`requested_token_budget` field through the existing secret-shaped-field
guard. The internal submission now uses the repository-approved non-secret
`token_budget` name.

Focused review then found that an exact replay returned a persisted packet
before rechecking current source bytes. The handler now validates current
activation, work, run lineage, and packet source bytes before replay. A second
review found that a concurrent losing assembler needed one final validation
of the winning stored packet before response. Both corrections added
Component regressions, and the same Component command passed after each
change.

### Integration

```powershell
py -m unittest tests.integration.test_sf401_governed_context -v
```

Final result: `1 passed`.

### Workflow

```powershell
py -m unittest tests.workflow.test_sf401_governed_context -v
```

Final result: `1 passed`.

### Stress

```powershell
py -m unittest tests.stress.test_sf401_governed_context_concurrency -v
```

Final result: `1 passed`.

## Required Scenarios

- empty and caller-supplied wildcard retrieval;
- stale required repository source;
- unauthorized delegated memory retrieval;
- token-budget expansion and required-source budget overflow;
- packet digest changed after later authorization;
- exact duplicate replay;
- process restart and new-child-run refresh;
- concurrent duplicate convergence.

The final Stress run submitted 24 concurrent duplicate assemblies through 12
workers. All callers received the same packet id and digest, while the
repository retained exactly one request and one packet.

## Validation

```powershell
py -m compileall -q elder_protocol tests scripts
py -m elder_protocol.cli validate
git diff --check
```

Compilation and protocol validation passed. Final package and isolated-install
evidence are recorded in the SF-401 evidence file.

SF-402 has not started. Canonical Elder maturity remains L1.
