# SF-303 Approvals And Escalations Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Architectural Boundary

SF-303 implements the existing factory-domain `DecisionRequest` and `Decision`
semantics through an operations adapter. It does not edit Elder's protected
authority matrix or treat an operations record as new constitutional
authority.

```text
authenticated requester
  -> exact work-item subject
  -> waiting DecisionRequest
  -> exact accountable role
  -> immutable Decision
  -> pending DecisionEffect
  -> existing WorkItemTransitionEngine
  -> applied or rejected effect
```

`DecisionRequest` remains factory-operations state. `Decision` is an immutable
local adapter record for the Elder `approval-decision` semantic. The pinned
authority matrix remains the source of role capability, and the active product
profile remains the source of identity-role binding.

## Supported Subject And Effects

SF-303 supports a work item as the decision subject. The request binds the
current work-item content digest and record version.

Choices are closed:

| Decision | Optional transition |
|---|---|
| `approved` | `accept-outcome` or `cancel` |
| `changes-requested` | `request-rework` |
| `rejected` | none |

The transition must already be legal for the subject's current status and
required role. SF-303 cannot add a transition, widen a role, or bypass the
existing transition authority mapping.

## Durable Records

The operations database adds:

- current decision requests plus immutable request history;
- immutable decisions;
- current decision effects plus immutable effect history.

A request is created as `open` history version 1 and dispatched to `waiting`
history version 2 in one transaction. A decision is terminal at creation. The
request moves to `resolved` and one pending effect is created in the same
transaction.

Request and effect current rows may advance only through validated lifecycle
operations. History rows and decisions cannot be updated or deleted.

## Authority

Request creation requires one of the factory-domain decision-request writer
roles. Decision submission requires:

1. the authenticated identity matches the submitted deciding identity;
2. the identity currently holds the request's exact required role;
3. that role currently has `approve` permission on `approval-decision`;
4. the request remains waiting and unexpired;
5. the exact subject digest and version are still current.

Inbox visibility, ownership labels, worker identity, session leases, or prior
roles do not satisfy these checks.

## Expiry And Cancellation

Expiry is an explicit executor operation over a due waiting request.
Cancellation is an explicit accountable human operation with a reason.
Neither creates a decision or downstream transition.

A decision submitted at or after `expires_at` is rejected even when the
expiry operation has not yet persisted the terminal `expired` state.

## Effect Reconciliation

The immutable decision and pending effect are committed before invoking the
existing transition engine. The effect uses a deterministic transition command
identity derived from the decision.

If the process stops after decision persistence:

- exact retry finds the immutable decision and pending effect;
- the same transition command is submitted;
- the transition engine's existing idempotency returns the prior result or
  applies it once;
- the effect advances to `applied` or `rejected`.

An effect never makes the decision mutable. A rejected effect remains visible
and cannot be disguised as an applied approval.

## API

SF-303 activates the reserved decision reads and adds:

- list/get decision requests;
- create decision request;
- submit one decision;
- cancel request;
- expire request.

Mutations use the existing source-record replay family. Read and mutation
routes remain numeric-loopback, bearer-authenticated, exact-project scoped, and
active-runtime fenced.

## Work Room

The Work Room renders correlated requests, immutable decisions, and effect
status. It adds controls for creating a bounded work-item request and deciding
an eligible waiting request. It does not expose arbitrary authority, shell,
merge, release, or deployment actions.

## Failure Conditions

The service fails explicitly for:

- wrong project, subject, run, requester, approver, or role;
- role absent from the current profile or authority matrix;
- malformed, secret-shaped, duplicate, or changed idempotency input;
- unsupported decision/transition pairing;
- request already resolved, cancelled, or expired;
- decision at or after expiry;
- changed work-item digest or record version;
- transition rejection or uncertain effect reconciliation;
- durable row, history, digest, or binding corruption.

## Evidence

Completion requires request/decision/effect replay, restart reconstruction,
wrong-approver and stale-subject rejection, expiry and cancellation, concurrent
response proof, actual downstream transition, responsive browser operation,
and isolated installed-package availability.
