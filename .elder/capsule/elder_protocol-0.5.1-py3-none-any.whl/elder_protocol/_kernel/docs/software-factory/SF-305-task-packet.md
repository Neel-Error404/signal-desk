# SF-305 - Metrics, Cost, And Outcomes

**Status:** VERIFIED

**Date:** 2026-08-14

**Change class:** read-only operational measurement

**Owner:** factory operations

**Approver:** human repository owner

**Depends on:** verified SF-304 commit
`fb10990d9e47b0c3c637fc3727e32f2ac5d9fc21`

## Outcome

An authenticated owner can inspect definition-bound delivery and control
metrics for one project and distinguish measured values from unavailable data.

## In Scope

- work-item cycle time and waiting time;
- dispatch retry and failure counts;
- explicit owner intervention counts;
- test-evidence coverage, not inferred test correctness;
- current and terminal outcome counts;
- cost and learning-impact availability status;
- metric definitions, units, populations, exclusions, and source digests;
- bounded low-cardinality API and control-room presentation.

## Non-Goals

- estimated model cost without recorded usage and rates;
- inferred learning benefit without a linked approved learning evaluation;
- prompts, outputs, secrets, trace ids, work-item ids, or run ids as metric
  dimensions;
- billing, forecasting, alerting, hosted retention, or autonomous decisions;
- SF-400 Elder lifecycle integration.

## Required Guarantees

- every numeric metric declares its formula, unit, population, and exclusions;
- missing source data produces `unavailable` or `partial`, never zero by
  assumption;
- cost remains unavailable unless explicit amount or usage records exist;
- test quality is represented only by recorded evidence coverage;
- metrics are advisory and grant no authority;
- source changes during assembly retry within a bound and then fail closed;
- dimensions stay within the pinned telemetry cardinality and privacy policy;
- reconciliation binds the report to current journal/projection/source digests.

## Test Plan

1. Foundation: closed schema, exact definitions, route/binding, privacy, and
   cardinality contract.
2. Component: duration math, retry/failure/intervention counts, percentiles,
   missing data, redaction, and digest validation.
3. Integration: authenticated API, restart, and reconciliation stability.
4. Workflow: owner reads project outcomes without database or terminal access.
5. Stress: bounded high-volume aggregation and concurrent deterministic reads.

## Completion Gate

SF-305 closes only after the ordered invalidated ladder, desktop/mobile browser
proof, focused review, package verification, evidence and Obsidian updates,
and a separate commit. SF-400 must not begin in this stage.
