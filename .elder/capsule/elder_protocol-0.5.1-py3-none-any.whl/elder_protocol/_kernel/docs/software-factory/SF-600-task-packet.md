# SF-600 Task Packet

**Status:** VERIFIED

## Outcome

Factory Operations has an inactive PostgreSQL-hosted storage boundary for
canonical imported records, durable multi-process delivery, fenced projection
work, and digest-bound recovery.

## Bounded Scope

- versioned PostgreSQL migrations;
- one PostgreSQL durable broker adapter using transactional outbox and inbox
  records;
- competing-consumer claims with `FOR UPDATE SKIP LOCKED`;
- lease owner and generation fencing for delivery and projection workers;
- duplicate delivery suppression without suppressing changed payloads;
- quiesced, single-writer SQLite export and PostgreSQL import;
- exact record-count and digest verification before hosted binding activation;
- logical backup, restore, and projection-checkpoint reconstruction;
- explicit outage and failover/rebind handling without blind retry.

SF-601 through SF-606 are outside this task. SF-600 does not add workload
identity, secret brokering, hardened remote workspaces, production
integrations, hosted Git controls, tenant isolation, managed database
failover, cloud deployment, or hosted qualification.

## Acceptance

1. PostgreSQL schema migration is ordered, repeatable, and drift rejecting.
2. Publishing and canonical mutation can share one database transaction.
3. Competing consumers cannot own the same current lease.
4. Stale owner or generation completion fails closed.
5. Exact duplicate delivery is acknowledged once; changed duplicate payloads
   fail closed.
6. Broker unavailability leaves accepted outbox work durable and unacknowledged.
7. SQLite cutover requires maintenance mode, zero uncertain commands, zero
   active leases, a bound backup digest, and a source journal tip.
8. Hosted activation is impossible before imported record counts and digests,
   journal tip, and projection digests match the source checkpoint.
9. Backup restore to an empty target reproduces exact table and aggregate
   digests.
10. Projection checkpoints can be reset and rebuilt without weakening
    canonical source records.

## Failure Conditions

- migration history or SQL digest drift;
- changed payload under a reused message identity;
- stale or expired delivery/projection lease;
- split-brain cutover or non-empty restore target;
- changed source backup, imported record, journal tip, projection digest, or
  backup manifest;
- database or broker uncertainty represented as successful completion.

## Authority And Maturity

The hosted binding is inactive by default. Activation records are operational
evidence only and do not qualify Gate G or ratify L2.

Canonical Elder maturity remains L1.
