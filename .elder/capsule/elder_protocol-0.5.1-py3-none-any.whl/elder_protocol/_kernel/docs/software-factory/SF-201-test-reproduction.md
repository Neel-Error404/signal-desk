# SF-201 Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

**Runtime:** `codex-cli 0.146.1`

**Python:** `C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe`

## Scope

This record covers the real Codex worker adapter only. SF-202 workspace provisioning, SF-203
durable queued session control, and SF-206 automatic provider-effect reconciliation remain out of
scope.

## Foundation

Complete repository level:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m unittest discover -s tests/foundation -v
```

Result: `122 passed in 44.190s`.

Post-persistence-fix SF-201 regression:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.foundation.test_codex_worker_contract -v
```

Initial post-persistence result: `4 passed in 0.045s`.

Final post-review-remediation result: `4 passed in 0.034s`.

## Component

Complete repository level:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest discover -s tests/component -v
```

Result: `299 passed in 1754.770s`.

Post-persistence-fix SF-201 regression:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.component.test_codex_worker_adapter -v
```

Initial post-persistence result: `4 passed in 10.972s`.

First post-review-remediation result: `6 passed in 18.915s`.

Final race-remediation result: `7 passed in 16.415s`.

The test-owned app-server covers exact version and policy verification, malformed JSON, timeout,
process exit, interactive request rejection, pending first-turn process death and expiry,
secret-shaped stderr sanitization, turn completion, duplicate suppression, failed/interrupted
turn uncertainty, and uncertain dispatched effects.

## Integration

The aggregate Integration process exceeded the command wrapper's 30-minute limit after every
module through `test_signal_to_work_item_ledger.py` had passed. The unreached module and the one
subsequently corrected package-verifier test were run separately instead of replaying the
already-green inventory.

Unreached recovery module:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.integration.test_worker_adapter_recovery -v
```

Result: `2 passed in 187.029s`.

Installed-wheel verification after correcting the readiness poller:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.integration.test_installed_wheel -v
```

Result: `1 passed in 347.499s`.

Post-persistence-fix SF-201 regression:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.integration.test_codex_worker_adapter -v
```

Initial post-persistence result: `2 passed in 12.760s`.

Final post-review-remediation result: `2 passed in 15.090s`.

The unchanged SF-200 conformance runner passes against `CodexWorkerAdapter`, and a fresh adapter
using the deterministic provider runtime reattaches to the same opaque provider thread identity.

## Workflow

The normal Workflow inventory initially reported four Gate B readiness timeouts and one expected
live-Codex skip. The other workflow tests passed. The Gate B helper used one-second readiness
requests and a 20-second total startup budget; on slower fresh databases this created overlapping
timed-out health requests and then attempted to collect still-running child processes.

The helper now uses a bounded ten-second per-request window, a 60-second total startup bound, and
terminate/kill cleanup before collecting output. The four scenarios then passed individually:

| Scenario | Result |
|---|---:|
| A - queued work survives API kill | `passed in 116.540s` |
| B - stale claimant is fenced | `passed in 71.434s` |
| C - post-commit response loss reconciles once | `passed in 69.176s` |
| D - offline rebuild rejects old token | `passed in 116.128s` |

Run the real Codex workflow explicitly:

```powershell
$env:ELDER_RUN_LIVE_CODEX = "1"
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -W error::ResourceWarning `
  -m unittest tests.workflow.test_sf201_codex_worker_live -v
Remove-Item Env:ELDER_RUN_LIVE_CODEX
```

Initial persistence-fix result: `1 passed in 51.528s`.

Final post-review-remediation result: `1 passed in 67.069s`.

The workflow initializes and commits a baseline in a disposable Git repository, creates
`RESULT.txt` containing exactly `SF-201-LIVE-PASS` plus one newline, verifies unchanged HEAD,
branch, refs, commit count, and index, and verifies that the only worktree delta is the expected
untracked result. It then records one projected event, checkpoints, cancels, recovers, and
collects a passing evidence bundle bound to `codex-cli 0.146.1`.

## Root-Cause Corrections

### Empty thread was not resumable

The first live run failed because `thread/start` returned an ID, but the adapter immediately
terminated the app-server. Codex 0.146.1 does not materialize an empty rollout that another
process can resume, so `thread/resume` returned `no rollout found`.

The adapter now retains the owned app-server only from `start` through the first `send`. The first
completed turn materializes the rollout; later operations resume it by exact thread ID. Closing
stdin now also allows bounded graceful shutdown before terminate/kill fallback.

The pending bridge has a 120-second default lifetime and closes itself through a daemon timer.
Dead and expired pending processes fail closed instead of returning cached liveness.

### Durable store was provider-writable

The first live workflow placed the adapter-private SQLite store inside the Codex workspace.
Because prompt restrictions are advisory, that allowed the provider to alter receipts, sessions,
and evidence.

The adapter now rejects any store equal to or nested under a provider-writable workspace. The live
and deterministic tests use a sibling protected store outside the repository.

### Terminal provider failures were acknowledged

The first implementation stored every terminal turn observation as an acknowledged command,
including failed or interrupted turns.

The adapter now acknowledges only an exact `completed` status with no terminal error. Failed,
interrupted, malformed, or error-bearing terminal observations return an uncertain mutation
because provider-side file effects cannot be excluded.

### Provider diagnostics could expose raw content

Raw app-server stderr, JSON-RPC error messages, and terminal turn errors could enter adapter
responses or durable observations.

The runtime now retains only diagnostic hashes for stderr and provider errors. Adapter responses
contain a stable generic message, typed reason, effect identity, and optional diagnostic digest.

### Installed-wheel readiness conditions contradicted restore state

The installed-wheel verifier required `ready=true` before returning a restored readiness
document, then immediately asserted that the restored API was intentionally
`mutation_ready=false`. It now distinguishes a responding readiness endpoint from full mutation
readiness for the restored reconciliation-required state.

The poller's per-request timeout was also increased from one second to a bounded ten seconds while
preserving the 60-second overall startup limit.

## Installed Package

The installed-wheel integration now imports the SF-201 module and executes
`CodexWorkerAdapter` through the unchanged eight-operation SF-200 conformance runner using a
test-owned provider runtime outside the checkout.

Final result:

```text
1 passed in 161.306s
```

## Stress

No SF-201 stress level is required. SF-201 introduces one synchronous adapter owner and no
concurrent worker supervisor, shared worker queue, or multi-worker scheduling policy. Concurrent
durable session control belongs to SF-203.

## Closure Checks

The following checks passed before independent review:

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m elder_protocol.cli validate
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m compileall -q elder_protocol tests
git diff --check
```

Final package build, installed-wheel verification against the complete SF-201 documentation set,
artifact hashes, and independent-review disposition are recorded in the SF-201 evidence file.
