# SF-400 Elder Boundary Service Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Ordered Test Ladder

### Foundation

```powershell
py -m unittest tests.foundation.test_sf400_elder_boundary_contract -v
```

Final result: `3 passed`.

The first run had one documentation assertion failure because the design
described the later context phase without naming SF-401. The design now records
that ownership explicitly, and the same Foundation command passed.

### Component

```powershell
py -m unittest tests.component.test_sf400_elder_boundary -v
```

Final result: `4 passed`.

The first run completed the assertions but reported four cleanup errors on
Windows because SQLite's connection context manager does not close the
connection. The boundary now closes every connection in `finally`; the same
Component command passed without resource warnings or locked files.

The final component proof covers all eight operations, protocol digest
mismatch, stale policy, elapsed deadline, unavailable service, deterministic
handler rejection, invalid output, durable duplicate replay, idempotency
conflict, and uncertain mutation without a repeated effect.

### Integration

```powershell
py -m unittest tests.integration.test_sf400_elder_boundary -v
```

Final result: `1 passed`.

Integration exposed and corrected the required translation between the
ratified SF-003 envelope and existing Elder records:

- full context packets contain `token_budget`, which the generic adapter
  secret-field guard rejects, so the boundary returns only packet identity and
  digest;
- full delegations contain `token_limit`, so the adapter carries delegation
  identity and digest and resolves the canonical record behind Elder;
- SF-003 requires `context_request.project_id`, while non-delegated P4.4
  context assembly reserves that inner field for delegated identity, so the
  adapter verifies the transport project against the outer request and removes
  it before invoking P4.4.

The final run called real protocol data, context assembly, authority
resolution, delegation validation, evidence schema validation, qualification
policy validation, and learning artifact validation through one boundary.

### Workflow

```powershell
py -m unittest tests.workflow.test_sf400_elder_boundary -v
```

Final result: `1 passed`.

One ordered local decision sequence classified, authorized, assembled context,
validated delegation, evaluated evidence, qualified, and proposed learning.
A new boundary service instance opened the same SQLite store, returned the
learning proposal as a duplicate, and completed the promotion decision.

### Stress

```powershell
py -m unittest tests.stress.test_sf400_elder_boundary_concurrency -v
```

Final result: `1 passed`.

Twenty-four concurrent requests reused one learning idempotency identity.
Exactly one handler effect occurred. Other observations were bounded to
`duplicate` or `uncertain`, and the final replay was `duplicate`.

## Validation

```powershell
py -m compileall -q elder_protocol tests scripts
py -m elder_protocol.cli validate
git diff --check
```

All commands passed. Package build and isolated installation evidence are
recorded in the SF-400 evidence file.

## Focused Review

The focused review corrected one additional authority-binding defect after the
first green ladder: boundary construction accepted a caller-supplied snapshot
that could be self-consistent without matching current canonical protocol
truth. Snapshot construction now always runs `validate_protocol()`, and every
service instance rejects a supplied snapshot that differs from the recomputed
canonical value. The full focused ladder was rerun after this correction.

## Limits

The proof is local and in-process. The boundary does not persist context
packets, gate run lifecycle transitions, enforce evidence completion, invoke a
supervised pull-request provider, or create hosted service guarantees. Those
remain SF-401 through SF-404.
