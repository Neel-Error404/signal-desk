# SF-105 Test Reproduction

## Purpose

This runbook reproduces SF-105 in the required order:

```text
Foundation -> Component -> Integration -> Workflow -> Stress
```

Stop at the first failure or timeout. Fix the root cause and rerun that same level before
advancing.

## Interpreter

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'
& $python --version
```

Verified interpreter: Python 3.13.5.

## Runtime Budget

| Level | Timeout | Final unittest runtime | Final wall time | Final result |
|---|---:|---:|---:|---|
| Foundation | 10 minutes | 60.493s | 61.627s | 82 passed |
| Component | 30 minutes | 868.914s | 869.675s | 225 passed |
| Integration | 25 minutes | 379.963s | 380.709s | 37 run; 36 passed; 1 skipped |
| Workflow | 15 minutes | 83.558s | 84.068s | 16 passed |
| Stress | 25 minutes | 243.815s | 244.343s | 21 passed |

Final total: 381 tests run, 380 passed, and 1 existing opt-in live Integration test skipped.
Combined unittest runtime was 1636.743 seconds; combined wall time was 1640.422 seconds. Every
level completed inside its declared timeout.

Do not infer success from silence. A level is complete only when unittest prints its summary and
the process exits zero.

## Complete Ladder

Run each command separately from the repository root:

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'

& $python -m unittest discover -s tests/foundation -v
& $python -m unittest discover -s tests/component -v
& $python -m unittest discover -s tests/integration -v
& $python -m unittest discover -s tests/workflow -v
& $python -W error::ResourceWarning -m unittest discover -s tests/stress -v
```

The existing Integration skip is the opt-in live Azure Mem0/Luna test. It is unrelated to this
local SQLite controller and is enabled only with `ELDER_RUN_LIVE_MEMORY_TESTS=1`.

## Focused Commands

```powershell
& $python -m unittest tests.foundation.test_run_controller -v
& $python -m unittest tests.component.test_run_controller -v
& $python -m unittest tests.integration.test_sf105_run_controller -v
& $python -m unittest tests.workflow.test_sf105_factory_lifecycle -v
& $python -W error::ResourceWarning -m unittest `
  tests.stress.test_sf105_run_controller_concurrency -v
```

## Coverage

| Requirement | Primary reproducing test |
|---|---|
| Schemas, secret rejection, mapping, deterministic IDs | `tests/foundation/test_run_controller.py` |
| Exact binding/replay/restart and changed collision | `tests/component/test_run_controller.py` |
| Commit-time repository and lease race rollback | `tests/component/test_run_controller.py` |
| Factory, work, authority, context, P4.5 rejection matrix | `tests/component/test_run_controller.py` |
| All 29 lifecycle transitions and cleanup states | `tests/component/test_run_controller.py` |
| Initial SF-103 bypass rejection | `tests/component/test_run_controller.py` |
| Checkpoint, artifact, detach, and recovery fencing | `tests/component/test_run_controller.py` |
| Canonical P4.5 runtime adapter | `tests/component/test_run_controller.py` |
| Backup, restore, wrong schema, tamper, rebuild | `tests/component/test_run_controller.py` |
| Accepted SF-103 restart reconciliation | `tests/integration/test_sf105_run_controller.py` |
| Uncertain exact-command reconciliation | `tests/integration/test_sf105_run_controller.py` |
| Rejected compensation and expired lease | `tests/integration/test_sf105_run_controller.py` |
| Owner-visible SF-100 through SF-105 local flow | `tests/workflow/test_sf105_factory_lifecycle.py` |
| Concurrent replay, collision, references, and capacity | `tests/stress/test_sf105_run_controller_concurrency.py` |
| Existing-system regression safety | Every complete ladder level |

## Additional Verification

```powershell
& $python -m elder_protocol.cli validate
& $python -m elder_protocol.cli skills validate
& $python -m compileall -q elder_protocol tests
git diff --check
& $python -m build --no-isolation
```

Install the wheel into a fresh target outside the checkout import path and verify:

1. `elder_protocol.constants.ROOT` resolves under installed `_kernel`;
2. `RunController` and `RuntimeCoordinationInspector` import;
3. the installed operation-schema catalog contains all SF-100 through SF-105 schemas;
4. the installed authority mapping validates;
5. SF-105 design, evidence, and reproduction documents are packaged.

Final result:

```text
Build: elder_protocol-0.5.1-py3-none-any.whl and elder_protocol-0.5.1.tar.gz created
Import root: isolated installed elder_protocol/_kernel, not the source checkout
Operation schemas: 23 packaged
SF-105 documents: 3 packaged
Lifecycle authority mapping: valid
Installed-wheel protocol validation: passed
```

## Observed Development Failures

The exact implementation and test failures, root causes, and same-level reruns are recorded in
[`evidence/SF-105.md`](evidence/SF-105.md).

## Next Task

The test, evidence, and package prerequisites are complete. Do not implement SF-106 on this
branch. After explicit SF-105 closure and commit permission, create the SF-106 branch and perform
design and independent review before implementation.
