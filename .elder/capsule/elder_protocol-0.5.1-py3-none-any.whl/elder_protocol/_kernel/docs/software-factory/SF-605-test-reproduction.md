# SF-605 Test Reproduction

**Status:** VERIFIED on 2026-08-15

## Foundation

```powershell
py -m unittest `
  tests.foundation.test_sf605_multi_product_boundary_contract -v
```

Result: 4 passed.

## Component

```powershell
py -m unittest `
  tests.component.test_sf605_multi_product_boundary -v
```

Result: 25 passed.

## Integration

```powershell
py -m unittest `
  tests.integration.test_sf605_multi_product_boundary -v
```

Result: 1 passed.

## Workflow

```powershell
py -m unittest `
  tests.workflow.test_sf605_multi_product_boundary -v
```

Result: 1 passed.

## Stress

```powershell
py -m unittest `
  tests.stress.test_sf605_multi_product_boundary_concurrency -v
```

Result: 3 passed.

Total focused SF-605 qualification: 34 passed.

## Affected Phase 6 Regression

```powershell
py -m unittest `
  tests.component.test_sf600_hosted_store `
  tests.foundation.test_sf601_hosted_identity_contract `
  tests.foundation.test_sf602_hosted_workspace_contract `
  tests.foundation.test_sf603_production_integration_contract `
  tests.foundation.test_sf604_hosted_git_controls_contract -v
```

Result: 27 passed.

## Static And Protocol Checks

```powershell
py -m ruff check `
  elder_protocol/factory_operations/multi_product_boundary.py `
  elder_protocol/factory_operations/__init__.py `
  tests/_sf605_support.py `
  tests/foundation/test_sf605_multi_product_boundary_contract.py `
  tests/component/test_sf605_multi_product_boundary.py `
  tests/integration/test_sf605_multi_product_boundary.py `
  tests/workflow/test_sf605_multi_product_boundary.py `
  tests/stress/test_sf605_multi_product_boundary_concurrency.py
py -m compileall -q elder_protocol tests
py -m elder_protocol.cli validate
git diff --check
```

All scoped static and protocol checks passed.

## Failure And Correction Record

1. Foundation initially compared a tampered document's retained digest with
   the original digest instead of recomputing the changed body. The test was
   corrected and Foundation passed 4/4.
2. Component initially left SQLite connections open on Windows because a
   SQLite transaction context does not close its connection. Every boundary
   connection now closes explicitly; Component was rerun.
3. The audit truncation test exposed that hash links alone cannot detect
   deletion of the only or final record. Immutable per-event product
   checkpoints now bind every sequence and tip; Component passed.
4. The corruption fixture initially omitted its commit after moving to
   explicit connection closure. The fixture now commits the injected deletion,
   and the same Component level proves detection.
5. Focused review found generic reservations could double-account
   `active-workers`, expired workers could retain the unique active slot, and
   exact quota or backup retries were not idempotent. Worker capacity is now
   binding-owned, expiry moves the old generation to `recovery-required`, and
   exact reservation and backup retries return the original record.
   Component, Integration, Workflow, and Stress were rerun and passed.
6. Independent review reproduced a forged worker-scope release/cache bypass
   and acceptance of internally invalid but top-level-rehashed backup state.
   Worker bindings now compare immutable issued fields to the stored row, and
   restore validates exact quota, worker, and audit schemas, record digests,
   limits, chronology, uniqueness, and chain integrity before opening the
   restore transaction.
7. Independent review also found expired capacity could remain occupied,
   event IDs were global across products, backup file creation raced outside
   the fence, and mutable audit heads weakened truncation claims. Binding now
   reconciles all expired target-product workers, event IDs are product-local,
   backup verification and replacement are serialized, and audit checkpoints
   are append-only. Component and downstream levels passed again.
8. Re-review found boolean/float audit sequences could be coerced by SQLite,
   restore accepted caller-authored manifests, audit payloads were not
   object-only, and concurrent partition-marker creation raced on Windows.
   Backup validation now requires strict integer sequences, object payloads,
   non-empty history ending in the matching creation event, the exact
   partition file, and an immutable read-only source-store catalog record.
   Partition initialization has a separate cross-process fence. Component,
   Workflow, and Stress passed again.
9. Final review found the catalog relative path was not physically bound to
   the source store. Source metadata now persists the resolved storage root,
   and restore requires the supplied file to equal the exact
   storage-root-plus-catalog path. The copied-file probe is rejected before
   target mutation; Component and downstream levels passed.

Final independent read-only disposition:

```text
BLOCKER: None
REQUIRED: None
OPTIONAL: None
DISPOSITION: CLEAN
```

## Package And Installed Verification

Clean package build:

```powershell
py -m build --outdir .tmp/dist-sf605-20260815-final
```

Exact artifact bytes and SHA-256 values are retained in the generated closure
sidecar and reported with the commit. This avoids embedding a package's own
hash in evidence that is itself included in that package.

The wheel was installed without dependencies outside the checkout at:

```text
C:\Users\neela\AppData\Local\Temp\elder-sf605-installed-final-20260815-3
```

An external-working-directory reproduction loaded:

```text
C:\Users\neela\AppData\Local\Temp\elder-sf605-installed-final-20260815-3\
elder_protocol\factory_operations\multi_product_boundary.py
```

The installed package then:

- restored the exact source-store-registered product-A backup;
- reported one restored active worker as `recovery-required`;
- left product B with zero audit records;
- rejected a byte-identical backup copied outside the persisted source
  storage root with `Product backup is not registered by the trusted source
  store.`; and
- left the rejected target with zero audit records.

## Limitations

- No cloud tenant, hosted database, object store, encryption key, or provider
  backup was provisioned.
- Component snapshots are verified and returned to their owning restore
  procedures; SF-605 does not reinterpret or directly restore another
  component's private store.
- The recovery runbook is local implementation guidance until SF-606 exercises
  it in the exact hosted environment.
- Quotas prove reservation accounting, not provider-measured physical bytes.
- Resolved storage paths rely on the SF-602 provider boundary for no-follow
  opening and junction resistance.
- Audit checkpoints are not an external anchor against replacement of the
  entire database by a fully privileged host.
- SF-605 does not qualify Gate G, ratify L2, or activate any autonomy.
