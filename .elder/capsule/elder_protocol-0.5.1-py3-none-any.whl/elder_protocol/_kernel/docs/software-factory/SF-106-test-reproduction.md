# SF-106 Test Reproduction

## Purpose

This runbook reproduces SF-106 in the required order:

```text
Foundation -> Component -> Integration -> Workflow -> Stress
```

Stop at the first failure or timeout. Fix the root cause and rerun that same level before
advancing. Do not combine the levels into one opaque command.

## Interpreter

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'
& $python --version
```

Verified interpreter: Python 3.13.5.

## Runtime Ceilings

| Level | Timeout | Final result |
|---|---:|---|
| Foundation | 15 minutes | 89 passed in 31.262s |
| Component | 45 minutes | 249 passed in 1298.821s |
| Integration | 30 minutes | 39 run, 38 passed, 1 expected opt-in skip in 344.242s |
| Workflow | 30 minutes | 18 passed in 141.627s |
| Stress | 60 minutes | 24 passed in 347.672s |
| Protocol/build/isolated wheel | 45 minutes | Passed after one same-level verifier correction |

These are failure ceilings, not expected runtimes. A timeout is a failed level and requires root
cause analysis before the same level is rerun.

## Complete Ladder

Run each command separately from the repository root:

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'

& $python -m unittest discover -s tests/foundation -v
& $python -m unittest discover -s tests/component -v
& $python -m unittest discover -s tests/integration -v
& $python -m unittest discover -s tests/workflow -v
& $python -W error::ResourceWarning -m unittest discover -s tests/stress -v
```

The known Integration skip is the opt-in live Azure Mem0/Luna test. It is enabled only with
`ELDER_RUN_LIVE_MEMORY_TESTS=1` and is outside the local SQLite SF-106 scope.

## Focused SF-106 Commands

```powershell
& $python -m unittest tests.foundation.test_event_journal -v
& $python -m unittest tests.component.test_event_journal -v
& $python -m unittest tests.component.test_sf106_golden_oracle -v
& $python -m unittest tests.integration.test_sf106_event_journal -v
& $python -m unittest tests.workflow.test_sf106_cli -v
& $python -m unittest tests.workflow.test_sf106_owner_views -v
& $python -W error::ResourceWarning -m unittest `
  tests.stress.test_sf106_event_journal_concurrency -v
```

## Closure Commands

```powershell
& $python -m elder_protocol.cli validate
& $python -m elder_protocol.cli skills validate
& $python -m compileall -q elder_protocol tests scripts
git diff --check
& $python -m build --no-isolation
& $python scripts/verify_installed_wheel.py
```

The installed-wheel verifier must run outside the checkout import path and prove:

- the seven SF-106 implementation modules are installed from the wheel;
- all four registries, eleven schemas, and three SF-106 documents are packaged;
- the mutation implementation inventory contains exactly 35 live branches, 32 derived SQLite
  tables, and 76 concrete SQL writes;
- all 19 source-family normalizers and referenced actor, correlation, causation, and idempotency
  extractors resolve to installed executable callables;
- protocol validation passes from the installed kernel;
- operations initialization, seven-projection rebuild, status, integrity verification, public
  event read, backup, backup verification, restore, and restored integrity verification execute
  through the installed CLI;
- restored journal cursor identity equals the source cursor identity.

## Required Run Record

For each final level, record:

- exact Python executable and version;
- branch and base revision;
- start and end timestamps;
- command and timeout;
- unittest runtime and wall time;
- test count, pass count, failure count, error count, and skips with reasons;
- warnings policy;
- exit code;
- retained failure artifact path when a failure requires a database or manifest reproducer.

## Current Focused Evidence

The following focused checks passed before the final ordered ladder:

```text
SF-106 Foundation module: 7 passed in 4.854s
SF-106 event-journal Component module: 20 passed in 250.788s
Independent golden-oracle Component module: 4 passed in 8.933s
Cross-process hash-seed replay: 1 passed in 9.758s
```

The checked-in golden corpus contains 37 immutable entries across 19 source families, nine
concrete composite scenarios, all seven projections, 133 reducer/no-op classifications, exact
expected rows and digests, one public event, and distinct fixture author and reviewer identities.
The hash-seed check runs the production projection runtime in three fresh Python processes with
`PYTHONHASHSEED` values `1`, `271828`, and `314159`.

## Final Ordered Run

Interpreter:

```text
Python 3.13.5
```

Branch and base:

```text
work/sf-106-event-journal-projections
b4f9cee5d03f23a3d3bb8d9c79375d2cd853f9fd
```

| Level | Started UTC | Ended UTC | unittest | Wall | Result |
|---|---|---|---:|---:|---|
| Foundation | 2026-08-11T18:40:56.3675765Z | 2026-08-11T18:41:28.0519779Z | 31.262s | 31.667s | 89 passed |
| Component | 2026-08-11T19:05:15.8995789Z | 2026-08-11T19:26:55.2702147Z | 1298.821s | 1299.371s | 249 passed |
| Integration | 2026-08-11T19:27:22.1310103Z | 2026-08-11T19:33:06.8417164Z | 344.242s | 344.711s | 39 run, 38 passed, 1 skipped |
| Workflow | 2026-08-11T19:33:22.0108095Z | 2026-08-11T19:35:44.0724425Z | 141.627s | 142.062s | 18 passed |
| Stress | 2026-08-11T19:35:52.7767151Z | 2026-08-11T19:41:40.8859496Z | 347.672s | 348.109s | 24 passed |

The final repository ladder ran 419 tests: 418 passed, one was skipped, and none failed or
errored. The Integration skip was:

```text
Set ELDER_RUN_LIVE_MEMORY_TESTS=1 to exercise Azure Mem0 and Luna.
```

Stress ran with `ResourceWarning` promoted to an error. Every level exited `0` within its
declared ceiling.

## Final Closure Run

| Check | Wall | Exit |
|---|---:|---:|
| `py -m elder_protocol.cli validate` | 1.836s | 0 |
| `py -m elder_protocol.cli skills validate` | 0.499s | 0 |
| `py -m compileall -q elder_protocol tests scripts` | 0.191s | 0 |
| `git diff --check` | 0.142s | 0 |
| `py -m build --no-isolation` | 17.087s | 0 |
| `py scripts/verify_installed_wheel.py` | 47.044s | 0 |

`git diff --check` emitted only line-ending conversion warnings and no whitespace errors. The
build produced `elder_protocol-0.5.1.tar.gz` and
`elder_protocol-0.5.1-py3-none-any.whl`.

## Development Failures

Material failures were retained rather than hidden by broader reruns:

- the first full Component closure run exposed two legacy-backfill fixtures that fabricated
  pre-SF-106 rows through the guarded production connection; the fixtures were corrected to use
  raw SQLite only for their explicit historical-store setup, and Component was rerun;
- runtime inverse-write coverage exposed omitted `factory_runs` updates in
  `run.elder-observation` and `run.checkpoint-reference`; both sites were registered and
  AST-validated, then the event-journal Component module and full Component level were rerun;
- the first installed-wheel closure attempt failed because the verifier incorrectly assumed the
  reusable extractor registries were keyed by source ID; the verifier was corrected to resolve
  every source's declared extractor contract ID to a callable, and the same installed-wheel
  level passed in 47.044s.

No timeout or broader rerun was used to bypass a failed level.

## Closure Rule

SF-106 is closed for its declared local SQLite and single-process scope. The complete ordered
ladder, closure commands, isolated-wheel verification, and independent implementation/test
reviews passed with no unresolved Critical or High finding.

SF-107 remains a separate task. It must begin with an explicit design and review gate before
implementation; no SF-107 implementation was started as part of this closure.
