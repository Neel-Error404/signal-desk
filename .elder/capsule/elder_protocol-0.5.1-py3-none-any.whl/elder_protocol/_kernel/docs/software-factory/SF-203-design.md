# SF-203 Durable Session Control Design

**Status:** VERIFIED

**Date:** 2026-08-13

## Boundary

SF-203 adds one local durable coordinator between owner/executor intent,
SF-105 canonical lifecycle state, the SF-200 worker adapter, and the SF-202
workspace binding.

The coordinator owns:

- durable control acceptance and exact idempotent replay;
- one-command local leasing and serialized execution;
- start, prompt, follow-up, steer, wait, pause, resume, checkpoint, and cancel;
- restart inspection of pending, leased, and executing controls;
- a durable waiting reason and continuation link;
- adapter checkpoint observations and ordered worker-event cursors;
- explicit rejection, cancellation, or uncertainty records.

It does not own canonical run, worker-session, workspace, authority, Elder
checkpoint, work-item, or delivery state.

## Composition

```text
owner or executor intent
        |
        v
DurableSessionController
        |
        +--> RunController.apply()             canonical lifecycle
        |
        +--> WorkspaceLifecycleManager         exact leased sandbox binding
        |
        +--> WorkerAdapter.execute()            provider observation/effect
```

The controller uses a separate local SQLite store. Cross-store steps cannot be
made atomically. It therefore persists the current step before invocation,
uses exact idempotency for deterministic replay, and stops on an interrupted
external-effect step. SF-206, not SF-203, owns automatic reconciliation of that
uncertainty.

The controller accepts only an SF-202 binding that
`WorkspaceLifecycleManager.validate_workspace_binding()` confirms against the
current canonical workspace state, runtime manifest, active lease, path,
sandbox, and original safe inspection evidence.

## Control Operations

| Control | Canonical transition | Adapter operation |
|---|---|---|
| `start` | session start, then activate | prepare, then start |
| `prompt` | none | send `worker.prompt` |
| `follow-up` | resume first when waiting or paused | send `worker.follow-up` |
| `steer` | none | send `worker.steer` |
| `wait` | run and session wait | none |
| `pause` | run and session pause | none |
| `resume` | run start and session activate | none |
| `checkpoint` | none without canonical Elder checkpoint evidence | checkpoint, then observe cursor |
| `cancel` | run/session cancel request, then confirmation | cancel |

`checkpoint` stores an adapter observation and factory cursor. It does not
write SF-105's canonical checkpoint cursor. That cursor advances only through
`RunController.record_checkpoint_reference()` with a valid Elder checkpoint.
The requested checkpoint ID and digest must already resolve to the canonical
Elder child run.

## Durable States

```text
pending -> leased -> executing
executing -> succeeded
executing -> waiting-owner
executing -> rejected
executing -> uncertain
pending/leased -> cancelled
```

An exact duplicate returns the original durable record. Reuse of either the
control ID or scoped idempotency key with changed bytes is rejected.

Every adapter response is validated against the SF-200 worker contract.
`accepted` is not completion, and duplicate provider effects without the
original exchange become `uncertain` for SF-206 reconciliation.

Only one live control lease exists for a worker session. Cancellation receives
claim priority but does not erase or reinterpret a command already executing.

## Restart Rules

- expired `leased` controls return to `pending`;
- interrupted canonical-only controls return to `pending` because SF-105 apply
  is exact and idempotent;
- interrupted controls that crossed or may have crossed an adapter mutation
  become `uncertain`;
- completed, rejected, waiting, cancelled, and uncertain records are stable;
- no uncertain effect is retried automatically.

## Waiting And Continuation

`wait` records the exact canonical waiting reason and enters
`waiting-owner`. A `follow-up` submitted against that waiting control must bind
the same run, session, and generation. It resumes canonical state before
delivery and records the continuation link.

## Event Cursor

Worker events are projections, not canonical truth. The coordinator stores
only validated events for the exact session generation and requires contiguous
cursor sequence. Exact duplicate ingestion is idempotent; gaps, future
generations, aggregate-identity drift, regression, skipped durable events, and
same-sequence content drift fail closed.

## Security And Data Handling

- submitted controls and persisted observations are recursively secret-scanned;
- only sandbox bindings, opaque references, digests, and approved inline worker
  instructions are stored;
- worker responses cannot claim canonical writes;
- no environment values, credentials, or provider tokens enter the store;
- the controller has no merge, release, deploy, promotion, or maturity authority.

## Completion

SF-203 is complete only when the focused ordered test ladder passes, installed
package execution is verified, independent review has no current-scope
`BLOCKER` or `REQUIRED` finding, closure evidence is recorded, and the task is
committed separately before SF-204 or SF-205 begins.
