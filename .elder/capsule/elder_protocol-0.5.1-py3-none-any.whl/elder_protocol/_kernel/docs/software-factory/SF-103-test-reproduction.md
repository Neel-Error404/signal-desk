# SF-103 Test Reproduction

## Purpose

This runbook reproduces the complete evidence required to close SF-103 without collapsing the
test ladder into one opaque command.

The required order comes from the governed session activation packet:

```text
Foundation -> Component -> Integration -> Workflow -> Stress
```

If one level fails or times out, do not advance. Diagnose the root cause and rerun the same level
until it reports a complete result.

## Interpreter

Use the exact installed interpreter rather than relying on launcher discovery:

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'
& $python --version
```

The final Stress rerun used the explicit interpreter because the Windows `py` launcher
temporarily reported `No installed Python found!` even though Python 3.13 remained installed at
the path above. That launcher error occurred before test discovery and was not a test failure.

## Runtime Budget

These timeout budgets are intentionally larger than the final observed runtime. They provide
room for Windows filesystem variance, clean package builds, SQLite contention tests, and slower
CI workers without hiding a genuinely hung suite.

| Level | Final observed runtime | Recommended command timeout | Final expected result |
|---|---:|---:|---|
| Foundation | 67.467 seconds | 10 minutes | 74 passed |
| Component | 508.062 seconds | 20 minutes | 203 passed |
| Integration | 405.414 seconds | 15 minutes | 32 run, 31 passed, 1 skipped |
| Workflow | 141.623 seconds | 10 minutes | 15 passed |
| Stress | 94.238 seconds | 15 minutes | 16 passed |

Do not interpret silence before the timeout as success. A level is complete only when unittest
prints its final `Ran ...` and `OK` summary and the process exits with code zero.

## Commands

Run each command separately from the repository root:

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'

& $python -m unittest discover -s tests/foundation -v
& $python -m unittest discover -s tests/component -v
& $python -m unittest discover -s tests/integration -v
& $python -m unittest discover -s tests/workflow -v
& $python -m unittest discover -s tests/stress -v
```

The Integration skip is the existing opt-in Azure Mem0 and Luna test:

```text
Set ELDER_RUN_LIVE_MEMORY_TESTS=1 to exercise Azure Mem0 and Luna.
```

It is not required to prove SF-103 because the transition engine is local, provider-neutral, and
does not call Azure Mem0 or Luna. Enabling that test requires external credentials and network
access and must remain an explicit live-test decision.

## SF-103 Coverage

| Requirement | Primary reproducing test |
|---|---|
| Complete canonical trigger and role mapping | `tests/foundation/test_transition_engine.py` |
| Authority-matrix digest pinning | `tests/foundation/test_transition_engine.py` |
| Exact command and governance digest binding | `tests/foundation/test_transition_engine.py` |
| Secret rejection before storage | `tests/foundation/test_transition_engine.py` |
| Legal lifecycle transitions | `tests/component/test_transition_engine.py` |
| Illegal transition rejection | `tests/component/test_transition_engine.py` |
| Version-conflict rejection | `tests/component/test_transition_engine.py` |
| Unauthorized actor and role rejection | `tests/component/test_transition_engine.py` |
| Required evidence and field bindings | `tests/component/test_transition_engine.py` |
| Governance denial and digest mismatch | `tests/component/test_transition_engine.py` |
| Agent/service delegated lease reference | `tests/component/test_transition_engine.py` |
| Exact command replay idempotency | `tests/component/test_transition_engine.py` |
| Changed-content command-id collision | `tests/component/test_transition_engine.py` |
| Atomic work-item and transition history | `tests/component/test_transition_engine.py` |
| SF-102 database migration | `tests/component/test_transition_engine.py` |
| Terminal hook and terminal re-entry | `tests/component/test_transition_engine.py` |
| Signal-to-ledger-to-ready integration | `tests/integration/test_signal_to_work_item_ledger.py` |
| Concurrent exact duplicate applies once | `tests/stress/test_transition_engine_concurrency.py` |
| Competing commands accept once and record conflict | `tests/stress/test_transition_engine_concurrency.py` |
| Existing system regression safety | Every complete ladder level above |

## Additional Verification

After the ladder is clean:

```powershell
& $python -m elder_protocol.cli validate
& $python -m elder_protocol.cli skills validate
& $python -m py_compile `
  elder_protocol/factory_operations/transition_engine.py `
  elder_protocol/factory_operations/work_item_ledger.py
& $python -m build --no-isolation
git diff --check
```

The final package build used `--no-isolation` because the isolated build environment attempted
to download its build dependency while sandbox network access was unavailable. The repository
environment already contained the declared build tooling, and both the source distribution and
wheel completed successfully. A network-enabled reproducer may also run `& $python -m build`;
that path is not required to prove SF-103 behavior.

For packaged-kernel verification, install the wheel into a fresh target outside the checkout's
import path and verify:

1. `elder_protocol.constants.ROOT` resolves under the installed package's `_kernel`;
2. `WorkItemTransitionEngine` imports;
3. the packaged operations catalog contains nine schemas;
4. the packaged authority mapping contains fourteen trigger/role mappings.

## Forward Test Discipline

SF-104 and later tasks must preserve this structure:

1. Add focused Foundation tests for new contracts and static dependency truth.
2. Add focused Component tests for state machines, persistence, replay, and failure behavior.
3. Add Integration tests for boundaries with the preceding completed task.
4. Run the complete existing Workflow suite even when no new CLI is introduced.
5. Add Stress coverage for the new task's primary concurrency or restart risk.
6. Run the full ladder in order with explicit per-level timeouts.
7. Record exact counts, skips, observed runtimes, and initial failures in the task evidence.
8. Do not claim the next gate until every task named by that gate is separately closed.
