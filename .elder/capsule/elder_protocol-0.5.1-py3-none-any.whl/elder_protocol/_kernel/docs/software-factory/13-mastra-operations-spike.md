# Mastra Operations Spike

**Status:** VERIFIED - local-adaptation recommendation ratified by ADR 0021

**Task:** SF-004 - Mastra Operations Spike

**Date:** 2026-08-07

**Authority:** ADR 0021 approves the independent local-adaptation architecture. It does not
approve package integration, code copying, a fork, or a repository-license change.

## Outcome

Use an independently implemented local adaptation for the Phase 1 operations kernel, with
SF-003 as its required boundary. Keep the pinned Mastra Factory source as a behavioral and test
reference.

Do not directly integrate or selectively fork `@mastra/factory` for the initial Elder kernel.
Reconsider direct package integration for later hosted composition only after the package has a
stable operations API, a compatible release set, explicit Windows or Linux-only deployment
policy, and an adapter proof against the ratified Elder contracts.

This is a scored recommendation. The human architecture owner retains the decision.

## Pinned Inputs

| Source | Revision | Use |
|---|---|---|
| Mastra Factory monorepo | `d81fe95420e4a001a2850c56b9193106bf400682` | operations behavior, storage, dispatcher, transitions, starts, audit, metrics |
| Mastra Factory template | `ebcf8889fddde238f016ddc7468e45f195c440a4` | package, runtime, database, auth, pubsub, sandbox, and deployment composition |
| Elder factory domain | uncommitted SF-002 draft | canonical entity and lifecycle vocabulary |
| Elder factory contracts | uncommitted SF-003 draft, version `1.0.0` | adapter and event boundary |

No source was copied, vendored, forked, installed, or added as a dependency.

## Source Findings

### Strong Operations Behavior

The pinned Mastra source demonstrates:

- project-scoped external-source deduplication;
- optimistic work-item revision checks;
- one transition commit boundary with ingress replay;
- durable deferred decisions and pending starts;
- owner-fenced leases with renewal and expired-lease recovery;
- exponential retry with a five-attempt terminal bound;
- restart reconciliation for bindings, tool results, and pending starts;
- append-only audit and operational metrics;
- optional local libSQL and hosted Postgres composition;
- optional Redis Streams for multi-process events and leases.

These are the reference semantics the local implementation should preserve.

### Public And Internal Boundaries

The package root publicly exports `MastraFactory`, project and work-item storage classes, state
signing, route auth, and the integration interface. The wildcard package export makes deep
modules importable, but the dispatcher, start coordinator, and transition service are not
declared as the stable operations seam in the package root or `rules/index.ts`.

The useful queue behavior is coupled to:

- Mastra `FactoryStorage` and storage-domain registration;
- Mastra agent-controller sessions and thread signaling;
- Mastra rules, work-item stages, source-control bindings, and sandbox lifecycle;
- provider authentication and tenant conventions;
- package-internal records for deferred decisions and pending starts.

Canonical Elder domain and event ownership is not available through the documented stable root
extension points. A direct dependency would therefore require deep imports or a substantial
translation layer over provider-owned state, both of which carry compatibility risk.

### Runtime And Deployment

| Observation | Evidence |
|---|---|
| Package version | `@mastra/factory` `0.6.0-alpha.1` |
| Runtime requirement | Node.js `>=22.19.0` |
| Current machine | Node.js `24.14.0`, npm `11.9.0`, pnpm unavailable |
| Package runtime dependencies | 10 direct, including 5 Mastra workspace dependencies |
| Template dependencies | 9 runtime and 4 development dependencies |
| Template reproducibility | no lockfile |
| Local storage | libSQL supported |
| Hosted storage | Postgres; pgvector used by the template |
| Multi-process delivery | Redis Streams optional |
| Hosted authentication | Mastra platform auth or configured WorkOS-style provider |
| Source-control integration | GitHub App credentials and provider storage |
| Local sandbox | shared-host filesystem, explicitly not tenant isolated |

The current Node runtime satisfies the version constraint. A package execution test was not
performed because pnpm is unavailable, the sparse monorepo relies on workspace packages, network
access is disabled by the activated session, and package integration is not approved.

### Windows

The package uses platform-neutral path checks in several places, but workspace rendering and
GitHub sandbox operations invoke POSIX `sh`, `find`, and POSIX shell quoting. The pinned source
contains no explicit Windows execution policy or Windows-specific operations test. Git Bash or
WSL may make some local paths work, but native Windows behavior is not proven by this spike.

### Package Stability

The pinned package is alpha. Its changelog shows recent changes to integration contracts,
restart recovery, dispatch concurrency, transition approval, sandbox cleanup, instruction
loading, model selection, and reconciliation. Those are precisely the surfaces Elder would
depend on. The standalone template also uses an older Factory alpha version than the pinned
monorepo and has no lockfile.

## Disposable Vertical Slice

The independent spike implementation is:

```text
.tmp/software-factory/sf004_local_adaptation_spike.py
.tmp/software-factory/test_sf004_local_adaptation_spike.py
```

It uses Python standard-library SQLite with WAL and full synchronous commits. It proves:

```text
idempotent signal intake
-> canonical work item
-> optimistic transitions
-> durable queued start
-> owner and generation fenced lease
-> provider-effect reconciliation before retry
-> delivery, uncertainty, or bounded failure
-> stream-bound restart-safe event query
```

Operational lease state is separate from canonical command state. The proof constructs and
validates SF-003 command and worker `send` request documents, validates the uncertain adapter
response, and emits full SF-003 event envelopes. It does not prove every worker operation,
response disposition, cursor-generation migration, or hosted adapter behavior.

The spike is intentionally disposable. It has no API server, migrations, worker integration,
hosted database, distributed broker, auth, UI, or production claim.

## Failure Verification

| Scenario | Result | Proven behavior |
|---|---|---|
| Duplicate intake and start | PASS | payload or request drift conflicts; exact replay returns the original durable result |
| Process kill after provider effect | PASS | subprocess records the provider receipt and exits; restart reconciles without duplicate delivery |
| Lease loss before provider effect | PASS | generation and owner fencing reject stale completion while the next owner reclaims safely |
| Uncertain provider mutation | PASS | started-but-unobserved effect enters `uncertain`; no retry occurs before reconciliation |
| Receipt isolation | PASS | receipts are command, project, idempotency, owner, and lease-generation bound |
| Retry exhaustion | PASS | internal attempts advance while the original SF-003 request stays stable; terminal failure closes command, run, and work item |
| Attempt-budget exhaustion | PASS | lease expiry and uncertain reconciliation cannot exceed `max_attempts` |
| Restart and event query | PASS | full cursor resumes only its stream; cross-stream and future cursors fail closed |

Eight focused tests passed. The process-kill test used a real child process exit code `91`, not an
in-memory exception.

## Code And Maintenance Delta

### Measured Surfaces

| Surface | Production physical (nonblank) | Test physical (nonblank) | Total physical (nonblank) |
|---|---:|---:|---:|
| Mastra files named by SF-004 | 5,612 (5,234) | 5,586 (5,071) | 11,198 (10,305) |
| Complete pinned Factory `src/` | 31,259 (29,067) | 30,350 (27,096) | 61,609 (56,163) |
| Standalone composition template | 839 | not present | 839 |
| Disposable local spike | 1,230 (1,170) | 447 (417) | 1,677 (1,587) |

Counts use PowerShell `Get-Content` physical lines and a second count of nonblank lines. Complete
Factory counts include all 160 `*.ts` files under `mastracode/factory/src`, classifying
`*.test.ts` as tests. The SF-004 subset is the ten production paths in the reading map plus the
nine adjacent test files that exist. These are comparison evidence, not delivery estimates.

The exact production subset is:

```text
src/factory.ts
src/rules/dispatcher.ts
src/rules/start-coordinator.ts
src/rules/transition-service.ts
src/rules/defaults.ts
src/rules/types.ts
src/storage/domains/work-items/base.ts
src/storage/domains/work-items/metrics.ts
src/storage/domains/audit/base.ts
src/storage/domains/audit/domain.ts
```

Each corresponding `.test.ts` file was counted where present; `src/rules/types.test.ts` does not
exist in the pinned checkout.

### Option Delta

| Option | Local code delta | Ongoing maintenance delta |
|---|---|---|
| Package integration | 839-line template is the observed composition baseline; an Elder translation layer remains additional and unmeasured | coordinate alpha upgrades across 10 package dependencies, maintain deep-import compatibility or upstream seams, and reconcile Mastra state with SF-003 |
| Selective fork | at least 11,198 relevant production and test lines before transitive storage, session, auth, and sandbox dependencies | own security and correctness fixes, merge upstream behavior, preserve attribution, and continually remove provider-specific domain assumptions |
| Local adaptation | 1,677-line proof; a production kernel will be larger after migrations, APIs, observability, and broader tests | own a smaller Elder-specific kernel while selectively replaying upstream failure tests and reviewing pinned source changes |

The package option minimizes copied code but does not minimize integration ownership. The fork
option imports the largest code and upgrade burden. The local option owns more implementation
than a clean package seam would, but it keeps the canonical state and runtime dependencies
bounded.

## Scorecard

Scores are `1` weak through `5` strong. Weighted totals are out of `100`.

| Criterion | Weight | Package | Selective fork | Local adaptation |
|---|---:|---:|---:|---:|
| SF-003 contract and authority fit | 25 | 2 | 3 | 4 |
| Proven failure semantics | 20 | 4 | 4 | 4 |
| Runtime and dependency isolation | 15 | 1 | 2 | 5 |
| Windows/local operability | 10 | 2 | 2 | 5 |
| Release stability | 15 | 2 | 3 | 4 |
| Maintenance ownership | 10 | 4 | 1 | 3 |
| License and provenance simplicity | 5 | 3 | 2 | 5 |
| **Weighted total** | **100** | **50** | **54** | **84** |

Score rationale:

- Contract fit: package root seams do not expose the complete operations boundary; a fork can
  change internals but retains provider state; the local proof validates representative SF-003
  commands, requests, uncertain responses, events, and cursors but is not full conformance.
- Failure semantics: Mastra and a fork receive `4`, not `5`, because strong source tests were
  inspected but not executed; the local proof receives `4` for eight passing bounded scenarios.
- Dependency isolation: direct integration imports the Mastra runtime set, a fork retains much
  of it, and the local proof uses only the project runtime and standard-library SQLite.
- Windows: package and fork paths use POSIX commands without a native Windows proof; the local
  proof executed natively on the current Windows machine.
- Stability: package is alpha, a fork can pin but must merge, and local contracts can remain
  stable while reference updates are reviewed deliberately.
- Maintenance: package has the lowest source ownership, the fork the highest, and local
  adaptation a bounded but real implementation burden.
- License: direct and fork options require unresolved compatibility and attribution decisions;
  independent local implementation has the simplest provenance.

The local option's overall lead comes from stronger Elder contract ownership, minimal dependency
coupling, native current-machine operation, and simpler provenance. The score does not assert
production breadth or complete SF-003 conformance.

## Recommended Decision

**Recommend:** `LOCAL ADAPTATION`

Conditions:

1. Implement only the Phase 1 local operations kernel behind SF-003.
2. Preserve Mastra's proven dedupe, revision, lease, retry, pending-start, reconciliation,
   audit, and metrics scenarios as required behavioral tests.
3. Keep provider stages, identities, sessions, retries, and storage rows outside canonical Elder
   truth.
4. Reassess `@mastra/factory` at the hosted-storage gate if stable operations interfaces become
   public and conformance can be proven without deep imports.
5. Do not copy source or create a fork without a separate human reuse and license decision.

## Human Decision Record

The human owner ratified `APPROVE LOCAL ADAPTATION` through ADR 0021 on 2026-08-08.

```text
APPROVE LOCAL ADAPTATION
```

Mastra remains a pinned behavioral and failure-test reference. Package integration, copied code,
selective extraction, vendoring, and a fork remain prohibited.

## Limitations

- Mastra package tests were inspected but not executed locally.
- No external package was installed.
- No network, Postgres, Redis, GitHub App, WorkOS, hosted sandbox, or multi-process test ran.
- The local proof is single-process SQLite, not a production kernel.
- Only representative command, request, uncertain-response, event, and cursor contracts were
  exercised; full adapter conformance remains a later implementation gate.
- Cursor retention, generation rollover, and snapshot refresh were not implemented.
- The scoring is an architecture aid, not constitutional or release authority.
- SF-005 must separately prove the worker contract and Codex/Prime runtime choice.
