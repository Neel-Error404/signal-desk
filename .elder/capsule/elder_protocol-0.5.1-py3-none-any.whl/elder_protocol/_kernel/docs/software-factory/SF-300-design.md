# SF-300 Owner Inbox And Attention Model Design

**Status:** VERIFIED

**Date:** 2026-08-13

## Design Position

The owner inbox is a derived operational view, not a new source of truth.
Canonical work-item, session-control, and recovery records retain lifecycle and
authority ownership. The inbox explains why the owner is needed and links the
supporting evidence.

```text
work-item ledger ----+
session controls ----+--> deterministic attention reducer --> owner inbox
recovery cases ------+              |
recovery orphans ----+              +--> reason, consequence, age
                                     +--> evidence references
                                     +--> applicable owner intents
```

The reducer does not write to any source store.

## Reference Observations

HumanLayer's outer-loop pattern treats human help, feedback, and approval as
explicit interruption points rather than hidden agent stalls. Factory's
official autonomy and software-factory documentation separates interaction
mode from autonomy and makes pending approvals and release gates visible.

Elder adopts the useful product pattern, not either provider's authority
model: one visible queue, explicit reason and consequence, and stable evidence
correlation. Elder's existing authority, transition, session, and recovery
contracts remain controlling.

## Attention Item

An item contains:

- stable `attention_id`;
- project, work-item, run, session, and workspace references when known;
- `kind`: decision, approval, failure, recovery, or orphan;
- `reason_family` and owner-readable `reason`;
- `consequence`;
- severity and deterministic priority rank;
- first observed, last updated, observation time, and age seconds;
- exact source evidence references with record digests;
- applicable owner intents;
- coalesced source count and content digest.

Suggested actions are descriptive intents. They do not grant authority and do
not execute mutations. Each action declares its authority mode and whether an
existing local command path is currently available.

## Source Mapping

| Source state | Kind | Severity | Owner intents |
|---|---|---|---|
| work item `validation` | approval | high | accept outcome, request rework, cancel |
| work item `waiting` | decision | high | inspect evidence, resume, cancel |
| work item `blocked` | failure | high | inspect evidence, cancel |
| work item `failed` | failure | urgent | inspect evidence |
| session `waiting-owner` | decision | high | inspect evidence, resume, cancel |
| session `uncertain` | recovery | urgent | inspect evidence, reconcile, cancel |
| session `rejected` | failure | high | inspect evidence, revise request |
| recovery `owner-required` | recovery | urgent | inspect evidence, cancel |
| recovery `contradictory` | recovery | urgent | inspect evidence, cancel |
| recovery orphan | orphan | urgent | inspect evidence |

Mappings are code-owned deterministic policy for SF-300. They do not amend the
canonical authority matrix or transition rules.

## Coalescing

The coalescing key is:

```text
(project_id or unknown) + primary subject + reason_family
```

The primary subject is the work item when available, otherwise the run,
session, workspace, control, recovery case, or orphan identity in that order.

Records sharing a key produce one item. Evidence references are unique and
sorted by source kind and identifier. First observation is the earliest source
timestamp; last update is the latest. Severity is the maximum source severity.
No source is discarded.

## Ordering

Items sort by:

1. severity rank descending;
2. age seconds descending;
3. attention identifier ascending.

The caller supplies `observed_at`, making age and ordering reproducible.

## Store Boundary

The read model receives explicit paths for:

- operations/work-item store;
- session-control store;
- worker-recovery store.

Paths may identify the same SQLite database in the normal local deployment or
separate databases in qualification and recovery tests. Every required store
must pass its own integrity and schema checks. A missing table or invalid row
fails the query explicitly.

## API Boundary

SF-300 adds:

```text
GET /v1/owner-inbox[?project_id={project_id}]
```

The route is authenticated, restricted to explicitly provisioned `owner-ui`
clients, and readiness-gated. A supplied project filter must be included in
the client's exact project grants. An unfiltered request requires the route to
appear in the client's separate `global_route_ids` grant. This prevents an
ordinary project-scoped owner token from reading another project's inbox while
keeping projectless recovery-orphan attention visible to a deliberately
provisioned global owner. The route returns the exact validated snapshot
produced by the read model.

The operations runtime receives explicit session and recovery store paths.
When either store is unavailable, corrupt, identity-drifted, or changing
through all three bounded read attempts, the API returns a retryable
source-unavailable result. It never publishes a partial snapshot as complete.

The JSON snapshot is the owner-facing SF-300 representation: prioritized
items, reason, consequence, age, evidence, and available intents. SF-301 owns
the visual control-room shell, portfolio navigation, and board presentation.

## Security And Authority

- recursively reject secret-shaped fields;
- return record references and digests, not provider diagnostics or secrets;
- never infer approval from inbox visibility;
- never mutate source records;
- never expose an action as available when no corresponding bounded local
  command path exists;
- preserve the L1 maturity ceiling.

## Phase Boundaries

SF-301 owns portfolio and board navigation. SF-302 owns the work-room detail
experience. SF-303 owns durable approval and escalation decisions. SF-300 owns
attention discovery, explanation, priority, evidence correlation, and action
intent only.

## Implementation Corrections

Focused review identified and corrected:

- durable SQLite indexed-column and history binding gaps;
- chronology not independently bound to evidence and snapshot time;
- per-source count drift;
- a public reducer trust boundary that accepted unvalidated dictionaries;
- cross-store reads without a bounded stability check;
- an over-broad SQLite generation check that treated API heartbeats as source
  changes;
- an HTTP project filter that was not bound to the authenticated client's
  project grants;
- an initial authorization remediation that protected projects but made
  projectless orphan attention unreachable through the API;
- recovery-case identity that was not cross-checked against its current
  session control;
- an existing route-resolution regression that still pinned 45 routes.

The final implementation uses source-table fingerprints rather than whole
database generation. Unrelated API bookkeeping may continue while work-item,
session-control, and recovery source rows must remain stable for one bounded
read attempt. Work-item fingerprints cover current rows, revisions,
dependencies, source links, and history. Recovery cases must match their
linked current session control on project, run, worker-session, and workspace
identity.
