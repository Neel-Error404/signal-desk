# SF-206 Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

**Python:** `C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe`

## Scope

This record covers exact worker-effect reconciliation, safe requeue,
cross-store restart, multi-control recovery reuse, start/checkpoint/cancel
failure boundaries, SF-205 propagation, orphan discovery, storage integrity,
and concurrent sweep admission.

## Ordered Results

### Foundation

The final SF-206 contract set passed:

```text
4 tests passed in 0.444 seconds
```

The affected SF-203 and SF-205 contract regressions also passed:

```text
6 tests passed in 1.171 seconds
```

### Component

All seven SF-206 Component cases passed across root-cause-only reruns:

- kill before effect, requeue, then reconcile the next uncertain attempt;
- kill after send effect without replay;
- checkpoint response loss remains owner-required;
- cancellation completes canonical cancellation;
- start response loss remains owner-required;
- one recovery observation serves two exact controls once;
- missing control and workspace-manifest orphans persist.

The existing SF-203 interrupted-external-effect regression also passed:

```text
1 test passed in 62.925 seconds
```

### Integration

```text
2 tests passed in 63.402 seconds
```

The proofs reopen the controller and recovery stores, preserve one effect, and
converge when SF-203 commits before the SF-206 case.

### Workflow

```text
2 tests passed in 63.878 seconds
```

One scheduled continuation recovers and reaches explicit usage accounting. A
lost recovery response becomes owner-required and moves its dependent tick and
goal to durable uncertainty.

### Stress

```text
1 test passed in 32.834 seconds
```

Concurrent sweeps produce one worker recovery receipt and one terminal case.

## Root-Cause Corrections

1. A safely retried send embedded the retry timestamp in the worker command,
   changing the payload under the same idempotency key. Worker commands now use
   the accepted control timestamp.
2. Tick lookup initially queried a JSON-only field as a SQLite column. The
   scheduler now loads validated tick records before filtering.
3. Recovery cases were initially unique only by control ID. They now bind the
   exact uncertain record version and attempt episode.
4. Shared observations initially used a timestamp cutoff. Completed attempts
   now list exact eligible control versions.
5. Cross-store commit order could strand a case. Restart now converges from the
   terminal SF-203 reconciliation evidence.
6. Recovery attempt scalar rows were not fully checked against JSON. All reads
   and status validation now enforce exact row binding.
7. Missing scheduled controls and manifest-only workspaces were absent from
   sweep discovery. They now create append-only orphan findings.
8. Unresolved recovery did not stop dependent scheduled work. SF-205 now
   propagates owner-required and contradictory cases to uncertainty without
   inventing successful usage.

## Independent Review

The first independent review reported six findings covering cross-store
restart, duplicate recovery, discovery, SF-205 propagation, stale observation
reuse, and attempt-row integrity.

The re-review marked five resolved and accepted the duplicate-recovery path as
correctly fail-closed. Its final conditional workspace-enumeration requirement
was then implemented through SF-202 manifest inventory.

Final re-review result: no current-scope blocker remains.

## Package And Static Checks

- Python compilation: passed.
- JSON schema catalog validation: passed.
- `git diff --check`: passed, with repository line-ending warnings only.
- Elder protocol validation: recorded in closure verification.
- Wheel build and fresh isolated installation: recorded in closure
  verification.

## Deliberate Limits

SF-206 is local SQLite recovery. It does not add hosted workers, distributed
leases, force cleanup, owner UI, or an independently qualified Gate C proof.
At SF-206 closure, formal Gate C remained unclaimed pending one composed
real-Codex issue-to-evidence workflow through restart. That separate proof
later passed on 2026-08-13; see [Gate C evidence](evidence/Gate-C.md).
