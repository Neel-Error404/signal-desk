# Governed Continual Learning

**Status:** SPECIFIED - target design

## Objective

Combine Prime Agent's continuous, trajectory-driven refinement with Elder's independent,
fail-closed learning controls.

Prime Agent supplies the reflex to notice and formulate a lesson. Elder decides whether that
lesson is trustworthy and whether it may alter a governed target.

## The Missing Join

Prime Agent currently provides:

```text
trajectory -> review -> edit proposal -> harness mutation -> history/rollback
```

Elder P4.6 currently provides:

```text
candidate -> replay -> shadow -> independent evaluation
-> accountable approval -> separate promotion packet
```

The factory must provide:

```text
trajectory and outcome
-> refinement trigger
-> typed proposal
-> immutable Elder candidate
-> counterfactual replay
-> shadow execution
-> independent evaluation
-> kind-specific approval
-> separate target adapter
-> monitored application
-> suspend or rollback on regression
```

## Learning Entry Kinds

Initial kinds:

| Kind | Example target | Approval |
|---|---|---|
| `memory` | project fact, verified preference, incident lesson | human owner |
| `skill` | reusable workflow or tool instruction | architecture owner |
| `prompt` | supplemental worker instruction | architecture owner |
| `worker-profile` | model, budget, or tool-routing preference | human and architecture owner |
| `evaluator` | grading rule or calibration change | human and architecture owner |
| `policy` | authority or governance behavior | constitutional workflow |
| `architecture` | dependency or component boundary | constitutional workflow |

Prime's `subagent` entry should initially map to a versioned worker profile or skill. It must not
create a new authority-bearing identity by itself.

## Candidate Schema

Each proposal must bind:

- candidate id, kind, scope, target, and base version;
- title, hypothesis, and proposed content;
- triggering trajectories, outcomes, incidents, and evidence digests;
- expected benefit and measurable success condition;
- known counterexamples and excluded situations;
- before and after snapshots;
- conflict key and expiry;
- proposer identity and model/runtime metadata;
- prohibited effects;
- required replay, shadow, evaluator, approver, and promoter identities.

The proposal engine cannot omit evidence by summarizing it only in prose.

## Trigger Policy

Triggers may be:

- explicit owner request;
- repeated correction;
- repeated tool or test failure;
- successful novel workflow repeated across tasks;
- compaction boundary;
- work-item completion retrospective;
- incident closure;
- cost or latency regression;
- retrieval miss or unused promoted memory.

Automatic triggers should first create proposals in local product scope. Global proposals require
explicit owner intent or repeated evidence across independent products.

## Noise Controls

- Prefer no proposal over a one-off speculative lesson.
- Require a recurrence threshold unless the event is a severe incident.
- Cluster similar evidence before proposing multiple entries.
- Limit proposals per work item and per time window.
- Reject proposals that merely restate the current task.
- Reject facts without source and freshness.
- Reject broad instructions when a narrow conditional instruction is sufficient.
- Reject candidates that conflict with protected surfaces unless routed to the constitutional
  workflow.

## Replay And Shadow

Counterfactual replay compares the candidate against historical tasks where the entry should and
should not apply.

Shadow mode injects the candidate into an isolated worker context while preserving the production
decision. It measures:

- task success and critical regressions;
- test outcomes;
- tool errors and retries;
- owner corrections;
- cost, tokens, and latency;
- retrieval precision;
- rule violations;
- evaluator disagreement.

The evaluator must not be the proposal model or the worker that generated the evidence.

## Promotion

Promotion is target-specific:

- memory adapter writes a new trusted-memory revision;
- skill adapter creates a reviewable skill revision;
- prompt adapter updates a supplemental profile;
- worker-profile adapter updates a factory-owned profile;
- policy, evaluator, and architecture candidates enter their existing governed change workflows.

The P4.6 promotion packet remains evidence and routed authority. A separate adapter performs the
actual change only after revalidating packet digest, approvals, target version, and expiry.

## Outcome Monitoring

Every promoted entry has:

- an activation version and time;
- expected outcome metrics;
- observation window;
- linked subsequent uses;
- health status: `observing`, `effective`, `ineffective`, `regressing`, `suspended`, `rolled-back`;
- automatic suspension thresholds;
- a rollback target.

Learning quality is measured by downstream outcomes, not by the number of stored memories.

## Retrieval Reachability

A learning system fails when a correct entry is never retrieved. The factory must test:

- whether the entry is indexed;
- whether the right task queries retrieve it;
- whether unrelated tasks do not retrieve it;
- whether it fits the context budget;
- whether the worker acknowledges or uses it;
- whether usage changes the outcome.

Promoted but unreachable entries are operationally ineffective and should be revised or retired.

## Prime Agent Integration Boundary

If Prime Agent is used as a worker:

- disable or redirect direct global refinement for governed projects;
- capture its proposed refinement event;
- translate the proposal into the factory candidate schema;
- append the source trajectory and snapshots;
- submit to Elder P4.6;
- return promotion outcomes to the worker as normal context, not hidden state.

If Prime Agent is not used as a worker, implement the same proposal protocol in the factory
observer so Codex trajectories can benefit from the learning loop.
