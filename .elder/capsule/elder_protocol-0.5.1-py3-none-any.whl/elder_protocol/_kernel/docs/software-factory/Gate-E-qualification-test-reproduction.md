# Gate E Qualification Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Scope

This runbook qualifies one local issue-to-supervised-delivery workflow across
current SF-400 through SF-404 lifecycle gates. It reconstructs every Phase 4
service and proves the required owner-visible fail-closed matrix. Phase 5 is
not started. Canonical Elder maturity remains L1.

## Ordered Test Ladder

Run one level at a time. When a level fails, record the root cause, correct it,
and rerun the same level before advancing.

### Foundation

```powershell
py -m unittest tests.foundation.test_gate_e_qualification_contract -v
```

### Component

```powershell
py -m unittest tests.component.test_gate_e_qualification -v
```

### Integration

```powershell
py -m unittest tests.integration.test_gate_e_qualification -v
```

### Workflow

```powershell
py -m unittest tests.workflow.test_gate_e_qualification -v
```

### Stress

```powershell
py -m unittest tests.stress.test_gate_e_qualification_concurrency -v
```

## Expected Assertions

- current context packet is authorized for the exact child run;
- SF-400 classification matches the ledger work-item change class;
- authority owner view is authorized and not attention-required;
- ordered evidence owner view is complete;
- delivery progresses authorized -> ready -> open;
- the exact packet, owner decision, provider response, and false merge/deploy
  capabilities survive reconstruction;
- provider invocation count remains one;
- expired authority, stale context, and missing evidence persist blocked
  attention states;
- unauthorized transition persists a rejected SF-402 owner entry;
- concurrent post-restart owner traces are identical.

## Additional Verification

```powershell
py -m unittest tests.foundation.test_operational_architecture -v
py -m unittest tests.workflow.test_sf400_elder_boundary -v
py -m unittest tests.workflow.test_sf401_governed_context -v
py -m unittest tests.workflow.test_sf402_authority_delegation -v
py -m unittest tests.workflow.test_sf403_evidence_pipeline -v
py -m unittest tests.workflow.test_sf404_supervised_delivery -v
py -m compileall -q elder_protocol tests scripts
py -m elder_protocol.cli validate
git diff --check
```

## Results

- Foundation: `2 passed`.
- Component: `1 passed`, covering all four required fail-closed cases.
- Integration: `1 passed`.
- Workflow: `1 passed`.
- Stress: `1 passed` across eight concurrent post-restart traces.
- Operational architecture: `8 passed`.
- Existing SF-400 through SF-404 Workflow regressions: `5 passed`.
- Python compilation, protocol validation, and diff checks passed.

## Corrections

1. The unauthorized-transition fixture expected SF-402 to return its rejected
   decision, but the contract raises the rejection after persisting it. The
   test now asserts the exception and the durable owner view.
2. The owner trace initially read the objective from the top-level work entity
   instead of its canonical payload.
3. The trace expected a provider response to carry `content_sha256`; it now
   digests the exact validated response.
4. Focused review found that the positive trace had not explicitly invoked
   SF-400 classification. The exact ledger work item is now classified through
   the existing boundary, and the entire ordered ladder was rerun.

No product correction or protected protocol change was required.

Package and installed-package commands and hashes are recorded in the evidence
file and external closure record.
