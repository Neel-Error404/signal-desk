# L2 Qualification And Authority Checklist

**Standard:** `elder-factory-maturity-standard` version `1.0.0`

**Current verdict:** BLOCKED

**Current canonical level:** L1

This checklist separates institutional maturity from active bounded authority.
Both must be explicit. Neither a roadmap percentage nor a qualification report
can grant authority.

## A. Canonical Bindings

- [x] Ratified ADR-0022 standard is version-pinned.
- [x] Eight mandatory dimensions are canonical and graph-connected.
- [x] P4.7 policy remains cumulative, signed, time-bound, contradiction-aware,
  and advisory.
- [x] SF-606 diagnostic replay loads canonical policy and maturity internally.
- [x] Canonical policy, maturity-standard, and trust-anchor digests are
  emitted in the diagnostic report.
- [ ] Candidate promotion revision is the exact deployed hosted revision.
- [ ] Repository identity, full Git object, artifact digest, deployment ID,
  hosted run ID, bundle ID, and bundle digest are bound together.
- [ ] Production environment identity is exact and immutable.
- [ ] Current evidence sources are independently signed and within freshness.
- [ ] The authority-capable evaluator accepts no caller-overridable policy,
  maturity model, trust root, benchmark, or repository.

## B. Quantitative Institutional Evidence

- [ ] At least 30 days of continuous observation.
- [ ] At least 20 real hosted work items.
- [ ] At least 90 percent reach a reviewable pull request without raw database,
  runtime-file, or background-terminal inspection.
- [ ] 100 percent external identity coverage.
- [ ] 100 percent durable trace coverage.
- [ ] 100 percent ordered-test evidence coverage.
- [ ] 100 percent signed provenance coverage.
- [ ] Zero authority escapes across the complete qualifying sample.
- [ ] Zero secret exposures across the complete qualifying sample.

Zero incidents in an empty sample do not satisfy the work-history gates.

Every qualifying work-item record must also have:

- [ ] Immutable provider event and hosted run identifiers.
- [ ] Canonical repository and unique pull-request identity.
- [ ] Exact source revision, artifact, deployment, and environment bindings.
- [ ] Signed payload bytes and a per-record content digest.
- [ ] An observation timestamp inside the signed qualification window.
- [ ] Verifiable links to identity, trace, ordered tests, provenance, control,
  exercise, and incident evidence.
- [ ] Cross-record duplicate detection for work items, pull requests, runs,
  and evidence identifiers.

## C. Required Hosted Controls

- [ ] External workload identity active for every hosted worker.
- [ ] Scoped secret broker active with opaque references and revocation.
- [ ] Isolated ephemeral hosted workspace active with exact image, repository,
  tools, egress, resource, and retention boundaries.
- [ ] Reproducible hosted build for the exact revision.
- [ ] Hosted CI for the exact revision.
- [ ] Protected base branch.
- [ ] Required checks enforced and bypass restricted.
- [ ] Signed artifact and source provenance.
- [ ] Independent evaluation separated from the authoring worker.
- [ ] Durable owner-visible trace requiring no internal inspection.

Current hard blocker: GitHub returned HTTP 403 for branch protection on the
private repository under the current account plan.

## D. Required Failure Exercises

- [ ] Hosted worker crash and recovery.
- [ ] Duplicate intake idempotency.
- [ ] Durable broker or hosted CI outage and reconciliation.
- [ ] Provider-response uncertainty with safe replay or reconciliation.
- [ ] Hosted backup and restore with product isolation and operator procedure.

Local mechanisms do not satisfy a hosted production exercise.

## E. Mandatory Dimensions At L2

- [ ] Product intake and planning.
- [ ] Worker execution and isolation.
- [ ] Security and supply-chain integrity.
- [ ] Testing, evidence, and evaluation.
- [ ] Delivery and production authority.
- [ ] Reliability, recovery, and incidents.
- [ ] Owner visibility, outcomes, and economics.
- [ ] Learning and long-term quality.

Whole-factory maturity is the minimum verified dimension. No averaging is
allowed.

## F. Promotion Evidence

- [ ] Current signed cumulative L0-L2 bundle for the exact revision.
- [ ] Separately signed provider-produced exact-revision hosted work history.
- [ ] Required-check enforcement evidence.
- [ ] Artifact provenance evidence.
- [ ] Separate signed independent-review record with reviewer identity, role,
  scope, decision, packet digest, evidence digest, and decision timestamp.
- [ ] Separate signed human-ratification record with accountable human
  identity, role, scope, decision, report digest, and decision timestamp.
- [ ] Packet author, evidence producer, independent reviewer, ratifier, and
  promoter satisfy required separation of duties.
- [ ] Current signed provider-state and contradiction snapshot is complete.
- [ ] No newer active contradiction, revocation, failed hosted run, or policy
  conflict exists.
- [ ] Every resolved contradiction has signed resolution evidence ordered
  after the contradiction.
- [ ] Attestations are issued after their evidence snapshot and remain inside
  policy freshness and trust windows.
- [ ] Qualification IDs are unique, replay controlled, and linked to
  supersession or revocation state.
- [ ] Separate promoter verifies packet, report, signatures, and source bytes.
- [ ] Promotion re-verifies current provider state immediately before the
  maturity change to limit time-of-check/time-of-use drift.
- [ ] Protected `protocol/operational-maturity.json` update is explicitly
  approved and independently reviewed.
- [ ] Protocol graph is regenerated and the intentional diff reviewed.
- [ ] Canonical L2 promotion is committed separately.

The historical advisory bundle for `d8c8eb3...` cannot promote `6962d34...`.

## G. Activate Bounded L2 Authority

Canonical maturity L2 still does not activate P5.2. To authorize bounded
supervised pull-request creation for one project and class:

- [ ] Canonical maturity is already human-ratified L2.
- [ ] Repository-owned project authority source is active and exact.
- [ ] Project autonomy ceiling permits L2.
- [ ] Change class is explicitly L2-capable and exact-match rules pass.
- [ ] Active certification is independently issued for that project and class.
- [ ] Current L2 qualification consumption is valid and unexpired.
- [ ] Incident budget is available; certification is not suspended or revoked.
- [ ] Protected branch and required checks are live at use time.
- [ ] Current signed governance statement matches the canonical authority
  source.
- [ ] Current signed workspace, execution, test, evaluator, provenance, and Git
  evidence bind the exact packet, branches, objects, and diff.
- [ ] Short-lived PR-scoped lease is issued without scope expansion.
- [ ] Provider response exactly echoes packet digest, repository, branches,
  Git objects, diff, pull-request identity, and trusted URL prefix.
- [ ] Humans retain merge, release, deployment, certification renewal, and
  maturity authority.

Only after these checks may the system create an exact reviewable pull
request. L2 never permits autonomous merge, release, or deployment.

## Current Next Actions

1. Upgrade the GitHub account plan, make the repository public, or move to an
   eligible organization repository so protected branches and required checks
   can be enforced.
2. Deploy the Phase 6 boundaries to one exact hosted production environment.
3. Issue a new signed cumulative bundle for the deployed revision.
4. Implement the signed provider work-history, provider-state,
   contradiction-ledger, independent-review, ratification, and replay formats.
5. Run at least 20 real hosted work items over at least 30 days.
6. Execute all five hosted failure exercises.
7. Obtain separate signed independent review, clear contradictions, and
   request accountable human ratification.
8. Implement and independently review an authority-capable evaluator as a
   separate governed change.
9. Promote canonical maturity separately, then configure project authority
   source and certification separately.

Canonical Elder maturity remains L1. This checklist does not grant authority.
Do not begin Phase 7.
