# SF-606 Test Reproduction

**Status:** VERIFIED IMPLEMENTATION; QUALIFICATION BLOCKED

**Date:** 2026-08-15

## Live Checks

```powershell
gh repo view Neel-Error404/elder-protocol `
  --json nameWithOwner,isPrivate,defaultBranchRef,viewerPermission
gh api repos/Neel-Error404/elder-protocol/branches/main/protection
gh run list --repo Neel-Error404/elder-protocol --limit 20
gh pr list --repo Neel-Error404/elder-protocol --state all --limit 100
```

Observed:

- repository is private and the authenticated owner has admin permission;
- `main` branch-protection lookup returns HTTP 403 with an account-plan
  upgrade/public-repository requirement;
- no hosted run exists for SF-605 revision `6962d34...`;
- one historical pull request exists and does not establish the required
  20-item, 30-day exact-revision history.

## Historical Bundle Replay

```powershell
py -m elder_protocol.cli qualification validate
py -m elder_protocol.cli qualification evaluate `
  --bundle docs/evidence/artifacts/p4-8a-run-31088377331/bundle.json `
  --output .tmp/sf606-historical-recheck.json `
  --at 2026-08-15T14:15:00+00:00
```

The bundle remains cryptographically qualified at advisory L2, but its source
revision is `d8c8eb3...`, not SF-605 `6962d34...`.

## Ordered Ladder

### Foundation

```powershell
py -m unittest `
  tests.foundation.test_sf606_institutional_l2_contract -v
```

### Component

```powershell
py -m unittest `
  tests.component.test_sf606_institutional_l2_qualification -v
```

### Integration

```powershell
py -m unittest `
  tests.integration.test_sf606_institutional_l2_qualification -v
```

### Workflow

```powershell
py -m unittest `
  tests.workflow.test_sf606_institutional_l2_cli -v
```

### Stress

```powershell
py -m unittest `
  tests.stress.test_sf606_institutional_l2_determinism -v
```

Results:

- Foundation: 2 passed.
- Component: 8 passed.
- Integration: 2 passed.
- Workflow: 1 passed.
- Stress: 1 passed.
- Focused SF-606 total: 14 passed, 0 failed.

## Current Exercise

```powershell
py -m elder_protocol.cli qualification institutional-l2 `
  --packet docs/software-factory/evidence/SF-606-institutional-input.json `
  --bundle docs/evidence/artifacts/p4-8a-run-31088377331/bundle.json `
  --output docs/software-factory/evidence/SF-606-institutional-report.json `
  --at 2026-08-15T14:15:00+00:00
```

The expected exit code is `1` because the report is deliberately blocked.
Canonical Elder maturity remains L1, and the command does not grant authority.
The exact generated report contains 42 blockers and digest
`a4682675c810034f16b070c23589cb03a88d6705c5039413e0a4b56e3c231cdf`.

## Affected Regression

```powershell
py -m unittest `
  tests.foundation.test_institutional_maturity_standard `
  tests.component.test_institutional_maturity_standard `
  tests.component.test_p4_7_qualification `
  tests.integration.test_p4_7_qualification_integration `
  tests.workflow.test_p4_7_cli `
  tests.component.test_hosted_qualification -v
```

Result: 22 passed, 0 failed.

Additional checks:

```powershell
py -m ruff check <SF-606 implementation and tests>
py -m compileall -q elder_protocol tests
py -m elder_protocol.cli validate
py -m elder_protocol.cli qualification validate
git diff --check
```

All passed.

## Failure Record

1. Foundation initially failed because the required SF-606 governance
   documents did not yet exist. The documents were added before rerunning the
   same level.
2. Independent review found a false-positive path through caller-supplied
   policy, maturity, trust anchors, history, controls, review, ratification,
   and contradictions. The evaluator now loads canonical policy and maturity
   internally, pins the canonical trust set, classifies packet evidence as
   unverified, and is diagnostic-only.
3. Independent review found missing target and temporal bindings. Exact
   repository, revision, artifact, deployment, hosted run, bundle ID, bundle
   digest, canonical pull-request identity, observation timestamps, and
   attestation timing checks were added.
4. Independent review found a bundle reread replacement window. The evaluator
   now compares bundle bytes before and after replay and binds the replayed
   report to the manifest digest.
5. The generated report was stale after the corrections. It was regenerated,
   and Integration now compares the checked-in object to a fresh canonical
   replay.
6. Re-review found that canonical policy and maturity digests were reported
   but not compared with the autonomy policy's approved pins. Both comparisons
   now fail closed, with a Component test covering each mismatch.

## Package

The clean package is built only after documentation and independent review are
final. The wheel is then installed outside the checkout, the installed module
path is verified, and the blocked CLI reproduction is repeated against the
installed package. Exact hashes are recorded in
`.tmp/sf606-package-evidence.json`.

Do not begin Phase 7.
