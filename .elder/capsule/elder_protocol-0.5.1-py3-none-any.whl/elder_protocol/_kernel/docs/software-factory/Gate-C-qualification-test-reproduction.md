# Gate C Qualification Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

## Scope

This runbook will reproduce the composed local issue-to-evidence workflow,
including a real Codex turn, hard operations-process termination, restart,
same-thread continuation, exact diff and test evidence, canonical checkpoint,
verified worker evidence, and final Gate C packet.

## Ordered Test Ladder

Run one level at a time:

1. Foundation contract and schema tests.
2. Component packet and runner tests.
3. Integration spawned-process restart test with deterministic Codex runtime.
4. Workflow spawned-process restart test with real Codex.
5. Stress concurrent restart-finalizer test.

When a level fails, record the root cause, correct it, and rerun that level
before advancing.

## Live Workflow Prerequisites

- the pinned Codex CLI version required by SF-201;
- working local Codex authentication;
- `ELDER_RUN_LIVE_CODEX=1`;
- no network requirement inside the synthetic task;
- a clean source worktree;
- output under `.tmp/gate-c/`.

## Expected Live Assertions

- one synthetic signal and one canonical work item;
- one completed run and one verified delivery packet;
- pre-restart and post-restart process identifiers differ;
- the external Codex thread reference is unchanged;
- exactly one prompt effect exists;
- the requested file and only the allowed bounded change exist;
- the declared test exits zero;
- the final packet validates and has verdict `pass`;
- canonical maturity remains L1.

## Results

### Foundation

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m unittest tests.foundation.test_gate_c_qualification_contract -v
```

Result: 4 tests passed.

### Component

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m unittest tests.component.test_gate_c_qualification -v
```

Result: 4 tests passed.

### Integration

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m unittest tests.integration.test_gate_c_qualification -v
```

Final result: 1 test passed in 294.270 seconds.

The spawned deterministic process was killed after the prompt effect became
durable. A new process reopened the stores and completed the same run with one
prompt effect, one bounded diff, a passing test, and no recovery debt.

### Live Workflow

```powershell
$env:ELDER_RUN_LIVE_CODEX = "1"
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m unittest tests.workflow.test_gate_c_qualification_live -v
```

Result: 1 real-Codex workflow passed in 343.055 seconds using
`codex-cli 0.146.1`.

### Stress

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m unittest tests.stress.test_gate_c_finalization_concurrency -v
```

Result: 1 test passed in 288.652 seconds. Two concurrent finalizers returned
the same packet digest and the worker receipt ledger retained one prompt
effect.

### Package And Installed Kernel

```powershell
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe `
  -m build --no-isolation --sdist --wheel --outdir .tmp\gate-c-dist
```

Result: `elder_protocol-0.5.1.tar.gz` and
`elder_protocol-0.5.1-py3-none-any.whl` built successfully.

The wheel was installed into a fresh Python 3.13 environment. From outside the
checkout:

- `elder_protocol.constants.ROOT` resolved under installed
  `site-packages\elder_protocol\_kernel`;
- both Gate C schemas were present;
- both Gate C validators imported from
  `elder_protocol.factory_operations.gate_c_qualification`;
- `python -m elder_protocol.cli validate` passed.

### Static Closure

- focused Foundation and Component rerun: 8 tests passed;
- Python compilation: passed;
- `git diff --check`: passed with line-ending warnings only;
- source-checkout Elder validation: passed.

## Root-Cause Corrections

1. Replaced expired reused governance timestamps with a fresh bounded runtime
   chain for the qualification date.
2. Bound the queue transition to the exact runtime lease rather than a fixture
   placeholder.
3. Corrected run and context lookups to their canonical aggregate locations.
4. Bound the checkpoint reference cursor to the durable observed cursor.
5. Kept the Elder checkpoint non-terminal so factory-run closure did not
   mutate the immutable delegated lineage.
6. Added one atomic finalization claim so concurrent restarted processes
   converge on one packet without replay.
7. Closed subprocess pipes after hard termination; compilation verified the
   cleanup-only change without rerunning the already-passed integration proof.

## Review And Limits

Focused review found no current-scope blocker or broader authority. The
qualification finalization claim is deliberately fail-closed: if its owner
dies before writing the packet, another process times out rather than
replaying worker effects. Gate C does not claim self-recovery of the
qualification harness.
