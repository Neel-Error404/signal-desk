# SF-602 Test Reproduction

**Status:** VERIFIED on 2026-08-14

## Foundation

```powershell
py -m unittest tests.foundation.test_sf602_hosted_workspace_contract -v
```

## Component

```powershell
py -m unittest tests.component.test_sf602_hosted_workspace -v
```

## Integration

```powershell
py -m unittest tests.integration.test_sf602_hosted_workspace -v
```

## Workflow

```powershell
py -m unittest tests.workflow.test_sf602_hosted_workspace -v
```

## Stress

```powershell
py -m unittest tests.stress.test_sf602_hosted_workspace_concurrency -v
```

## Affected SF-601 Regression

```powershell
py -m unittest tests.foundation.test_sf601_hosted_identity_contract -v
py -m unittest tests.component.test_sf601_hosted_identity -v
py -m unittest tests.integration.test_sf601_hosted_identity -v
```

## Static And Protocol Checks

```powershell
py -m ruff check elder_protocol\factory_operations\hosted_identity.py `
  elder_protocol\factory_operations\hosted_workspace.py `
  elder_protocol\factory_operations\__init__.py `
  tests\_sf602_support.py `
  tests\component\test_sf601_hosted_identity.py `
  tests\foundation\test_sf602_hosted_workspace_contract.py `
  tests\component\test_sf602_hosted_workspace.py `
  tests\integration\test_sf602_hosted_workspace.py `
  tests\workflow\test_sf602_hosted_workspace.py `
  tests\stress\test_sf602_hosted_workspace_concurrency.py
py -m compileall -q elder_protocol tests
py -m elder_protocol.cli validate
git diff --check
```

The scoped Ruff command passed. A separate repository-wide
`py -m ruff check elder_protocol tests` baseline reported 56 unrelated
pre-existing findings and was not used to expand SF-602 scope.

## Package And Installed Verification

```powershell
py -m build --outdir .tmp\dist-sf602-20260814-1
py -m pip install --no-deps `
  --target C:\Users\neela\AppData\Local\Temp\elder-sf602-installed-final-20260814 `
  .tmp\dist-sf602-20260814-1\elder_protocol-0.5.1-py3-none-any.whl
```

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `elder_protocol-0.5.1-py3-none-any.whl` | 2,456,657 | `927037AE85708CE5CB596ADDF78CEE20E544EDFAADF903E1F08A92E1232BE444` |
| `elder_protocol-0.5.1.tar.gz` | 1,896,479 | `29078069FB0D0E165FE4384689DAF19D1FD2B4B948F33BC7524DC8CBBBAFE640` |

The wheel was imported from the fresh target while the current directory was
`C:\Users\neela`, outside the checkout. A standalone installed-package
scenario:

- verified a signed workload token;
- issued a live broker credential;
- created and inspected a digest-bound workspace;
- destroyed the workspace and replayed `destroyed` after manager restart;
- confirmed the provider received the credential bytes;
- confirmed neither durable audit database contained the credential value.

## Final Results

| Level | Result |
|---|---:|
| Foundation | 3 passed |
| Component | 19 passed |
| Integration | 1 passed |
| Workflow | 1 passed |
| Stress | 3 passed |

Total focused SF-602 qualification: 27 passed.

Affected SF-601 regressions passed:

- Foundation: 3;
- Component: 16;
- Integration: 1.

Scoped Ruff, compilation, protocol validation, and diff checks passed. The
clean package build and installed-wheel verification passed.

## Failure And Correction Record

1. The first Integration request used a static lease identifier instead of the
   actual SF-601-issued lease. The fixture now binds the issued metadata; the
   same Integration level passed.
2. Local review found separate managers could invoke effects from the same
   state and inspection outage could prevent cleanup. Durable per-state
   operation fences and terminal read-failure quarantine were added.
3. Caller-supplied time could influence credential and retention decisions,
   and retention could outlive an injected lease. Operations now bind to the
   trusted clock and retention fits within every credential lifetime.
4. The policy-expiry fixture initially returned the default policy digest. The
   fake provider now binds the configured digest; Component passed.
5. Provider workspace identity reuse was not durably unique. Created provider
   identities are now single-use before acceptance.
6. Independent review found provider exception leakage, forgeable credential
   objects, and missing creation-policy lifetime binding. Provider exceptions
   are discarded before fixed local errors are raised, live SF-601 broker
   provenance is required, and policy digest drift quarantines before provider
   inspection.
7. The first provenance fixture requested a 300-second credential against the
   existing 120-second SF-601 grant. Workspace retention and the fixture were
   narrowed to the granted 120 seconds; Component passed.
8. Review found credential revocation could race provider injection. Every
   broker instance sharing an audit path now uses one cross-process operation
   fence, held through credential access and provider injection.
9. Review found another manager could recover a live inspection. Intents now
   carry owner and expiry; replay exposes `inspection-pending`, live
   destruction fails, and only expiry-gated unique recovery creates
   quarantine.
10. The final documentation review found the packet summarized inspection
    recovery too broadly. The packet and design now distinguish durable
    provider-failure quarantine, live pending inspection, expiry recovery, and
    uncertain mutating effects.

Final independent read-only disposition:

```text
BLOCKER: None
REQUIRED: None
```

## Limitations

- No cloud workspace, container service, VM service, production repository,
  external credential, or hosted network was created or contacted.
- Provider observations are trusted adapter results, not independently signed
  hosted attestations. Current signed hosted qualification remains SF-606.
- Owner-authenticated multi-product status access belongs to SF-605.
- Production integrations and hosted Git controls belong to SF-603 and SF-604.
- Canonical Elder maturity remains L1.
