# SF-401 Governed Context Assembly Task Packet

**Status:** VERIFIED

**Date:** 2026-08-14

## Objective

Give one queued local factory work item an immutable, task-specific,
authorized, budgeted P4.4 context packet before Factory Run binding.

## Success

- derive packet identity, project, work item, executor, scope, query, and
  budget from current work-item and Elder run-chain records;
- consume the SF-400 governance boundary without changing SF-003;
- persist the full packet in an Elder-owned immutable repository;
- retain only digest-bound packet, activation, work-item, and run references
  in the binding record;
- replay the same request without creating a second packet;
- reject stale activation, changed work, changed run lineage, changed source
  bytes, unauthorized memory, budget expansion, and a packet digest that
  differs from the digest already authorized by a later lifecycle caller.

## Failure

- empty or wildcard context reaches the worker;
- candidate, unscoped, or otherwise unauthorized memory is retrieved;
- a packet exceeds the child-run, delegation, or context-policy budget;
- changed source bytes remain usable under the old packet digest;
- Factory Operations becomes a replacement context authority.

## Constraints

- Canonical Elder maturity remains L1.
- Use P4.4 assembly and P4.5A run/delegation validation as-is.
- Use the unchanged SF-003 governance adapter through SF-400.
- Keep the implementation local and single-host.
- Run tests in Foundation, Component, Integration, Workflow, Stress order.

## Non-Goals

- SF-402 authority or delegation lifecycle integration;
- evidence completion gates, supervised pull requests, hosted context,
  tenant isolation, semantic vector infrastructure, or production services;
- scoped graph or memory provenance for delegated workers.

## Risk And Authority

This is high-risk lifecycle integration because stale or unauthorized context
can create a confused-deputy worker. Elder remains authoritative for packet
assembly. Factory Operations reads current work intent and receives a
digest-bound governance result; it does not grant authority.

## Next Proof Gate

Prove exact replay, restart survival, refresh to a new child-run packet,
concurrent duplicate convergence, and all five SF-401 fail-closed scenarios.
SF-402 must not start during this task.
