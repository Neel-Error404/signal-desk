# SF-604 Hosted Git And Review Controls Design

**Status:** VERIFIED

## Composition

```text
canonical P4.8A trust anchors
-> signed provider branch-governance statement
-> signed exact artifact-provenance statement
-> exact open SF-404/P5.2 supervised delivery record and packet
-> signed exact provider pull-request response
-> independently signed exact review statement
-> retained, restart-safe verification record
```

## Trust Boundary

Trust anchors are derived from the repository-owned P4.8A qualification
policy, not selected by the caller. The verifier requires the canonical
operator and reviewer anchors to be active Ed25519 anchors, currently valid,
assigned their exact roles, and scoped to the configured Git provider host.
The canonical qualification policy is validated against its pinned subjects
and public keys, and its complete trust-anchor digest must equal the approved
digest in the canonical autonomy policy. Validity is rechecked on every live
verification, not only when a verifier instance starts.
Provider signers may attest provider-observed branch rules, provenance, and
the provider response. The independent reviewer may attest review only. The
same signer cannot fill both roles, and no private key enters the verifier or
durable store.

## Exact Bindings

The policy binds one provider, repository, trusted pull-request URL prefix,
protected base branch, full branch-rule set, minimum approving-review count,
required checks, signer identities, statement freshness, and evidence
retention.

Governance must match the policy exactly. The verifier also requires an exact
open SF-404 supervised delivery record whose owner decision is `submit`, whose
packet equals the supplied P5.2 packet, and whose accepted provider response
matches the signed SF-604 response. Before accepting that record, SF-604
revalidates the original request, complete normalized P5.2 source set, current
qualification, SF-402 authority decision, SF-403 completion, exact execution,
active lease, current re-issued authority bindings, and a reconstructed packet.
Provenance and review must match the packet exactly for packet digest,
provider, repository, object format, branches, Git object identifiers, and
diff digest. Provenance additionally binds the artifact, required-check
evidence, exact supervised-delivery record, trusted-source digest, provider
identity, and source URI. The signed provider response must echo the same
values, the current ruleset evidence, and the one exact trusted URL derived
from its pull-request identifier.

Every statement source URI must use the trusted provider host, begin with the
exact repository path, and reject encoded traversal, dot segments, backslashes,
double slashes, query strings, and fragments. The independent review binds the
returned pull-request identifier, URL, signed response digest, and review
artifact to the canonical reviewer identity.

## Required Checks And Review

Every policy check must appear exactly once in signed provenance, must report
`success`, must bind the packet head revision, and must carry a SHA-256 evidence
digest. Extra, missing, duplicated, pending, skipped, or failed checks reject
the proof.

The independent statement must be signed by the one canonical reviewer,
report zero Critical, High, and Medium findings, approve the exact pull
request, and bind both provider statements, the signed response, its review
artifact, and the delivery artifact.

## Freshness And Retention

Policy and statements reject future issuance, stale observation, expiration,
and windows extending beyond policy expiry. A successful verification retains
the complete public signed evidence and an immutable digest-bound record until
the policy retention deadline.

The policy retention period must cover at least the statement freshness
window. Evidence chronology is governance, provenance, returned pull request,
then independent review; a review cannot predate the PR it claims to approve.

Replay checks the metadata record count and tip checkpoint, contiguous
sequence, previous-record digest, record digest, retained evidence digest,
original signatures, canonical trust generation, and exact bindings at the
recorded verification time. Every replay also uses mandatory trusted resolvers
for the request, source set, and execution plus repository loaders for the
SF-402 decision and SF-403 completion; there is no retained-hash-only replay
path. SQLite update and delete triggers reject ordinary record mutation;
metadata and the full hash chain detect tail deletion or truncation on replay.

## Concurrency

SQLite `BEGIN IMMEDIATE`, one unique packet digest, and one unique pull-request
URL serialize separate local verifier instances. An exact duplicate returns
the existing record only after replaying the full retained chain. Reusing the
packet digest with changed evidence fails closed.

## Non-Claims

The implementation does not configure or observe a live Git provider. It does
not create a pull request, activate branch protection, consume L2
qualification, activate P5.2 authority, merge, release, deploy, or change
canonical maturity.
