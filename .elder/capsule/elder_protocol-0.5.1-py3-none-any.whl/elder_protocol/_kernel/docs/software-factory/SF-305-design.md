# SF-305 Metrics, Cost, And Outcomes Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Architectural Boundary

SF-305 is a read-only aggregate over current durable local factory records. It
does not emit canonical telemetry, mutate the telemetry contract, or create a
billing ledger.

```text
work-item history + run history + dispatch history
owner notes + owner decisions + explicit artifact references
  -> definition-bound project metrics snapshot
  -> owner control room
```

## Metric Definitions

| Metric | Formula | Missing-data rule |
|---|---|---|
| Cycle time | terminal work-item timestamp minus initial creation timestamp | unavailable when either endpoint is absent |
| Wait time | sum of intervals beginning with a `waiting` work-item revision and ending at the next revision | open intervals are excluded and reported |
| Retry count | dispatch history records whose durable status is `retry` | zero only when dispatch history is present and contains none |
| Failure count | current failed work items plus failed or lost runs plus dead-letter dispatches | source counts remain separate |
| Owner interventions | explicit owner notes, controls, decision requests, and decisions | unavailable source families are reported |
| Test evidence coverage | runs with at least one explicit `test-evidence` artifact divided by all runs | unavailable when there are no runs |
| Cost | sum of explicit USD cost records | unavailable because the local operations store has no such records today |
| Learning impact | approved learning comparison delta linked to delivered work | unavailable because SF-305 has no governed linkage today |
| Outcome status | current work-item status counts and terminal completion ratio | no inference beyond durable status |

Durations use seconds. Means and percentiles are computed only over measured
samples. Percentiles use nearest-rank over the sorted finite sample.

## Privacy And Cardinality

The snapshot exposes only project-level aggregates and closed source-family
counts. Work-item, run, trace, span, event, artifact, evaluation, and outcome
identities are not metric dimensions. Prompts, outputs, commands, note text,
decision reasons, and secret-shaped values are not copied into the report.

## Availability

Each metric group is `complete`, `partial`, or `unavailable`.

- `complete`: all declared source families required for the value are present;
- `partial`: a value exists but one declared source family or interval is
  missing;
- `unavailable`: no trustworthy value can be computed.

Unavailable cost and learning impact contain `null`, never `0`.

## Consistency And Reconciliation

The service reads one SQLite snapshot for operations sources and one for the
optional session-control source. It fingerprints the journal tip, active
projection digests, relevant table counts/max versions, and optional session
source before and after assembly. Three unstable reads fail with
`OperationsReadUnavailableError`.

The final report binds definitions, values, availability, missing-data codes,
and reconciliation evidence into one content digest.

## API And UI

The route is:

`GET /v1/projects/{project_id}/metrics`

It is numeric-loopback, bearer-authenticated, owner-role restricted,
readiness-gated, and read-only. The control room presents measured outcomes
and clearly labels unavailable cost and learning impact.

## Authority

Metrics are advisory evidence. They cannot approve, promote, merge, release,
deploy, mutate maturity, or override deterministic failures.
