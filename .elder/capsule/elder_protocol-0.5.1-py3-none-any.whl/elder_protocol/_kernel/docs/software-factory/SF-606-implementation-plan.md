# SF-606 Implementation Plan

**Status:** IMPLEMENTED; qualification outcome BLOCKED

1. Activate Elder and pin the SF-605 revision.
2. Re-evaluate the historical signed bundle with current canonical policy.
3. Inspect current GitHub repository, Actions, pull requests, and branch
   protection.
4. Implement a diagnostic-only ADR-0022 institutional packet validator and
   evaluator pinned to canonical policy, maturity, and trust anchors.
5. Add `qualification institutional-l2` with nonzero exit on a blocked result.
6. Exercise a complete synthetic packet to prove caller assertions cannot
   produce qualification, ratification readiness, L2, or authority.
7. Exercise the real current packet and retain an exactly reproducible blocked
   report.
8. Run Foundation, Component, Integration, Workflow, and Stress in order.
9. Obtain independent correctness review and correct all authority-integrity
   findings before closure.
10. Build and verify the installed package outside the checkout.
11. Update evidence, roadmap, README, and the Obsidian project note.
12. Commit and push SF-606 separately.

Do not begin Phase 7.

Canonical Elder maturity remains L1, and this plan does not grant authority.
