# Phase-Proportional Delivery Rule

**Status:** SPECIFIED

**Applies to:** All software-factory roadmap tasks

**Authority:** This rule governs task scope and evidence discipline inside the software-factory
dossier. It does not amend Elder's constitution, protected protocol surfaces, accepted ADRs, or
canonical maturity.

## Purpose

The factory must become useful in the order defined by the roadmap. An implementation task must
not absorb production, hosted, adversarial, or later-phase requirements merely because they can
be imagined or because a narrower fix creates a new theoretical edge case.

The default decision is:

```text
prove the current phase outcome
-> record honest limitations
-> advance to the next value-producing task
-> harden the limitation when its owning phase arrives
```

Correctness remains mandatory. Exhaustiveness is phase-bound.

## Binding Rule

Conditions 1 through 3 determine whether a finding belongs to the current task:

1. The finding violates the current task outcome, a current accepted contract, or the current
   phase-exit proof.
2. The failure is reproduced, mechanically demonstrated, or directly implied by an invariant
   that already applies to the declared runtime.
3. The triggering condition is inside the current declared environment and threat model.

Conditions 4 and 5 determine whether the proposed remediation is ready:

4. The proposed correction is the smallest coherent change that restores the required claim.
5. A bounded test can prove the correction without introducing a stronger unrelated guarantee.

If conditions 1 through 3 are false, classify the finding as `DEFERRED`, `LIMITATION`, or
`SPECULATIVE`; record it without implementing it in the current task.

If conditions 1 through 3 are true but condition 4 or 5 cannot be satisfied, the concern remains
a current-scope blocker. The task must do one of the following:

- remain `BLOCKED`;
- narrow or remove the unsafe claim;
- disable the affected capability fail-closed;
- obtain an explicit contract or phase decision.

Security, authority, secret exposure, irreversible data loss, duplicate canonical mutation, and
false maturity claims remain fail-closed. Phase proportionality cannot waive those boundaries.
Such a defect cannot be downgraded merely because its correction is large or its proof is not yet
bounded.

## Finding Classification

Every material review finding must receive one disposition:

| Disposition | Meaning | Current-task action |
|---|---|---|
| `BLOCKER` | Reproduced violation of the current outcome, contract, authority, or gate proof | Fix and rerun the same test level |
| `REQUIRED` | Reproduced, mechanically demonstrated, or directly invariant-bound current-scope failure with a proportionate correction | Implement before closure |
| `DEFERRED` | Valid concern owned by a later roadmap phase or undeclared environment | Record owner task and continue |
| `LIMITATION` | Known local constraint that narrows the truthful claim without invalidating it | Document in evidence and operations guidance |
| `SPECULATIVE` | No reproduction, invariant breach, or current-scope path | Do not implement |

Severity alone does not determine disposition. A severe production concern can be `DEFERRED`
when the current task is explicitly local and non-production. A small deterministic contract
violation can still be a `BLOCKER`.

## Required Trace

Before editing for a review finding, record this trace in the task packet:

```text
finding
-> current task acceptance clause
-> declared environment or threat
-> reproduction or invariant
-> smallest correction
-> same-level regression test
-> claim after correction
```

Do not implement the finding when the trace cannot be completed.

## Phase Boundaries

### Phase 1 - Local Operational Kernel

Required:

- durable accepted state;
- deterministic transitions;
- idempotent mutation handling;
- bounded local concurrency;
- restart and replay correctness;
- local authentication and project/role scope where an API exists;
- honest liveness, readiness, degradation, and limitations;
- no duplicate canonical effects under the declared kill-and-restart scenarios.

Not required for Gate B unless separately approved:

- hostile public-network clients;
- TLS, remote identity, tenant isolation, or internet exposure;
- operating-system-wide exclusion against arbitrary external database or file tampering;
- zero-race response publication across every possible socket failure;
- production traffic draining, load-balancer semantics, or multi-process fairness;
- hosted secret brokering, central telemetry, retention, alerting, or automatic rollback;
- production-scale latency or throughput guarantees.

The Phase 1 API may be truthfully limited to numeric loopback, one active process, bounded local
clients, and controlled operator-driven configuration changes.

### Phase 2 - Worker Runtime

Required:

- one provider-neutral worker contract;
- a deterministic fake worker that passes the complete conformance suite;
- a real Codex adapter only in SF-201;
- isolated workspace lifecycle only in SF-202;
- durable session control only in SF-203;
- normalized worker observations, command correlation, uncertainty, recovery, and evidence;
- one issue-to-evidence workflow for Gate C.

Not required for SF-200:

- a real model-provider call;
- Codex process management;
- production workspace isolation;
- owner-control-room UI;
- general Elder lifecycle integration;
- Prime Agent integration;
- multiple workers, hosted execution, or production deployment.

### Later Phases

Owner UI belongs to Phase 3. Full Elder lifecycle gates belong to Phase 4. Learning belongs to
Phase 5. Hosted operational controls belong to Phase 6. Narrow production canary authority
belongs to Phase 7. Earlier tasks may preserve extension points, but must not implement those
phases preemptively.

## Anti-Rabbit-Hole Stop Conditions

Stop implementation and return to scope review when any condition occurs:

1. Two consecutive review rounds produce new blockers primarily from guarantees introduced by
   the previous remediation rather than from the original task outcome.
2. A correction requires a new global lock, background service, durable store, protocol version,
   cross-process coordinator, or public contract that the task did not originally require.
3. The proposed proof depends on production traffic, hostile remote clients, arbitrary external
   tampering, or infrastructure that the current phase explicitly does not claim.
4. More code is being added to prove an edge case than to implement the task's observable
   outcome.
5. Sixty minutes pass without advancing an acceptance clause, reproducing a failure, or closing
   a declared test level.
6. A full ordered ladder has already passed and a new finding has no completed required trace.

At a stop condition:

1. Freeze edits.
2. State the current observable capability.
3. List the exact original acceptance clauses still unmet.
4. Classify every open finding using this rule.
5. Narrow any over-strong claim.
6. Ask for a human decision only when narrowing would change an accepted contract, protected
   surface, or ratified gate.

## Review Discipline

Independent review must assess the declared phase and threat model. Reviewers must not silently
upgrade a local task into a hosted or production task.

A review finding is actionable only after the primary orchestrator reconciles it against:

- executable behavior;
- current contracts;
- the current task packet;
- the current phase gate;
- this rule.

The goal is not "no imaginable High finding." The goal is "no unresolved blocker or required
finding inside the truthful current claim."

## Test Proportionality

Run tests in Foundation, Component, Integration, Workflow, and Stress order, but only include a
level when the task changes behavior owned by that level.

- Do not create Stress tests for concurrency or scale that the implementation does not expose.
- Do not create Workflow tests for a later-phase workflow.
- Do not add Integration infrastructure solely to make a design document appear complete.
- A failed relevant lower level still blocks higher levels.
- A deferred risk must name the later task that will own its proof.

## Completion Decision

A task is complete when:

1. Its observable outcome is implemented.
2. Every current-scope acceptance scenario passes.
3. Every open finding is classified.
4. No `BLOCKER` or `REQUIRED` finding remains.
5. Limitations and deferred risks are explicit.
6. The next task can consume stable inputs without assuming later-phase capabilities.

A task does not remain open merely because further hardening is possible.
