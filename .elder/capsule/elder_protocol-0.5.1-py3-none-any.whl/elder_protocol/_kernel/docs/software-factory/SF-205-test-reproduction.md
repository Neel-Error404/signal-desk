# SF-205 Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

**Python:** `C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe`

## Scope

This record covers durable factory-owned goals, fixed-interval schedules,
deterministic ticks, append-only heartbeats, current Elder authority,
continuation budgets, SF-203 dispatch, restart behavior, duplicate suppression,
storage integrity, and fail-closed uncertainty.

## Ordered Results

### Foundation

The final affected Foundation set covered SF-205, the shared SF-105 run
contract, and SF-203 control contracts:

```text
10 tests passed in 1.703 seconds
```

It verifies the five schemas, package exports, closed request and authority
records, exact cross-bindings, secret rejection, and typed budgets.

### Component

The first implementation run exposed one SQL field-name defect in the due-tick
query. After that root cause was fixed, the remaining failures were test
fixture assumptions about a nonexistent fake-adapter status helper and the
required deterministic control binding for an expired claimed tick. Only the
failed cases were rerun.

The initial complete focused suite then passed 6 tests. Independent review
subsequently identified atomic result, terminal-state, authority-admission,
budget, and integrity gaps. The implementation and focused tests were
corrected.

The post-review Component run passed 6 tests and exposed two test-only errors:

- one fixture had destructured the run controller as `_`;
- raw `sqlite3.Connection` context management committed but retained a Windows
  file handle during cleanup.

After correcting those fixtures, only the two failed tests were rerun:

```text
2 tests passed in 96.348 seconds
```

The terminal-goal test was then extended with an explicit in-flight completion
rejection assertion and that one invalidated test passed in 32.355 seconds.
Across the sustainable reruns, all 8 Component tests passed.

### Integration

```text
1 test passed in 36.566 seconds
```

The proof reopens the scheduler and session stores, preserves exact run,
workspace, authority, tick, and control identity, and records one known result
without redispatch.

### Workflow

```text
1 test passed in 39.163 seconds
```

Two bounded re-entries complete with durable usage and heartbeats before an
explicit goal completion. No background thread or hidden continuation is used.

### Stress

An earlier pre-review Stress invocation exited without a traceback or
actionable test output. The immediate same-level rerun passed with no code
change, so it was recorded as an inconclusive process/harness invocation rather
than assigned a speculative product cause.

The final post-review Stress level passed:

```text
2 tests passed in 87.723 seconds
```

Spawned processes prove both one SF-203 control for one due instant and one
usage/accounting transition for duplicate concurrent result recording.

## Review Corrections

Independent implementation review found and the final code corrects:

1. concurrent result recording could account one completion twice;
2. a late failed result could rewrite an already terminal goal;
3. an over-budget successful control could be accepted before the stop check;
4. goal creation could snapshot an inactive or drifted runtime lease;
5. the authority object in the durable goal schema was not structurally closed;
6. history metadata and heartbeat scalar rows were not fully integrity-bound;
7. owner-waiting, authority drift, terminal result, tampering, over-budget, and
   duplicate-result cases were missing focused tests.

## Package And Static Checks

- Python compilation: passed.
- JSON schema parsing and catalog validation: passed.
- `git diff --check`: passed, with repository line-ending warnings only.
- `python -m elder_protocol.cli validate`: passed.
- Wheel build: passed.
- Fresh `pip --target` install: passed.
- Import from the isolated target: passed.
- Installed `_kernel` includes all five SF-205 schemas: passed.

## Deliberate Limits

SF-205 uses one local SQLite scheduler and fixed intervals. It does not add a
distributed broker, cron parser, automatic worker-effect reconciliation,
hosted scheduling, worker-owned accounting, or blind replay. Interrupted or
unverifiable effects stop as uncertain for SF-206 to inspect.
