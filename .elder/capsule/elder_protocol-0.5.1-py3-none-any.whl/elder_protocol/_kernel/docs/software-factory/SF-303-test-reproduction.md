# SF-303 Approvals And Escalations Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Ordered Test Ladder

Only invalidated levels and modules were rerun after corrections.

### Foundation

The first full Foundation pass completed 132 unaffected tests before the two
modules containing stale SF-303 route and Work Room fixtures failed. After
correcting those fixtures, only those modules were rerun:

```powershell
py -m unittest tests.foundation.test_work_room_contract -v
py -m unittest tests.foundation.test_operations_api_design -v
```

Final results: `2 passed` and `23 passed`.

The affected Foundation proof covers all decision schemas, capability truth,
the 55-route API registry, exact bindings and registry digests, mutation
payloads, Work Room composition, and response validation.

### Component

A broad Component discovery run exceeded the bounded 15-minute closure budget
without producing a usable result, so it was not repeated. The affected
modules were run directly:

```powershell
py -m unittest tests.component.test_owner_decisions -v
py -m unittest tests.component.test_operations_api_contracts -v
py -m unittest tests.component.test_operations_api_health -v
py -m unittest tests.component.test_work_room -v
```

Final affected results: `3`, `9`, `5`, and `3` tests passed. After the focused
review correction, `tests.component.test_owner_decisions` was rerun and again
passed all `3` tests in `213.724s`.

The proof covers immutable decisions, exact replay, restart reconstruction,
wrong role, stale subject, expiry, cancellation, pending-effect response-loss
reconciliation, capability readiness, and Work Room decision composition.

### Integration

```powershell
py -m unittest tests.integration.test_owner_decisions_api -v
py -m unittest tests.integration.test_operations_api_lifecycle -v
py -m unittest tests.integration.test_work_room_api -v
py -m unittest tests.integration.test_operations_api_queries -v
```

Final affected results: `1`, `4`, `1`, and `2` tests passed. The decision API
test was rerun after review and passed in `155.848s`.

The real loopback proof covers authenticated create and decide, exact replay,
downstream cancellation, reads, API restart, source-record reconciliation,
and deterministic rejection of an incompatible choice as
`409 source-mutation-conflict` with `mutation_state=not-started`.

### Workflow

```powershell
py -m unittest tests.workflow.test_sf303_approvals -v
py -m unittest tests.workflow.test_sf302_control_room -v
```

Final results: `2 passed` across the SF-303 and retained SF-302 workflows. The
SF-303 workflow was rerun after review and passed in `76.588s`.

The owner moved a real work item to validation, raised an outcome request,
accepted the declared outcome, completed the work through the existing
transition engine, and reconstructed the resolved request, immutable decision,
and applied effect in the Work Room.

Chrome then exercised the real loopback runtime:

1. authenticate as the exact granted local owner;
2. open the current Work Room;
3. raise a cancellation approval request;
4. select the declared non-transition rejection;
5. refresh and confirm the request remains resolved;
6. verify desktop at `1280x800`;
7. verify mobile at `390x844`.

All six API responses were `200` or `201`. The browser reported no console
warning, console error, page error, failed API response, page-level horizontal
overflow, or overflowing descendant. Screenshots and the bounded report are
under `.tmp/evidence/`.

### Stress

```powershell
py -m unittest tests.stress.test_owner_decision_concurrency -v
py -m unittest tests.stress.test_work_room_concurrency -v
```

Final results: `2 passed`.

Thirty-two competing responses produced one accepted immutable decision, one
effect, and 31 deterministic conflicts. Existing concurrent Work Room input
behavior remained green.

## Validation And Package

```powershell
py -m compileall -q elder_protocol tests
node --check elder_protocol/factory_operations/control_room/app.js
py -m elder_protocol.cli validate
py -m build --outdir .tmp\sf303-closure-dist-20260814
```

The clean build produced `elder_protocol-0.5.1.tar.gz` and
`elder_protocol-0.5.1-py3-none-any.whl`. The wheel was installed into a fresh
target outside the checkout import path. The installed package loaded
`OwnerDecisions`, the 55-route registry and all eight SF-303 routes, all eight
owner-decision schemas, the three Work Room decision fields, all five SF-303
closure documents, and all four control-room assets.

The first finalized build hashes were:

- wheel: `efeb15b72ef1c352f22946aebc4df258db1716695d37bca8798e0b0ff430de31`;
- source archive:
  `bca9cc019c06231c7c492c45c312835a4dd3c1d526fd8e761374e87c93d45267`.

## Review Corrections

The focused review corrected:

- exact source-record replay was initially blocked by a shared pre-dispatch
  readiness guard after a committed response was lost;
- moving that guard required confirmation that both source-record and existing
  journal-reconciled mutation families still reject brand-new work while
  `mutation_ready` is false;
- deterministic invalid decision expiry, duplicate choices, incompatible
  decision/transition pairs, and invalid transition evidence could be reported
  as uncertain source mutations;
- the generic source-reconciliation error named Work Room even for decision
  mutations.

Only the directly invalidated Component, Integration, and Workflow tests were
rerun after the final correction. No remaining current-scope blocker or
required correction was found.
