# SF-602 Hardened Hosted Workspaces Design

**Status:** VERIFIED

## Composition

```text
current raw OIDC token
-> SF-601 exact workload verification
-> current scoped brokered credentials
-> digest-bound hosted workspace request
-> durable create intent
-> provider-neutral isolated workspace adapter
-> exact provider response and observation verification
-> quarantine or complete destruction
-> secret-free hash-chained audit replay
```

## Immutable Execution Inputs

Every request binds one provider, project, workload, run, and workspace to:

- one immutable `sha256:` image digest, never a mutable tag;
- one trusted repository artifact digest;
- exact repository URL, Git revision, tree digest, and instruction digest;
- exact tool identifiers, versions, and artifact digests;
- exact resource budgets;
- a default-deny egress allowlist;
- bounded retention;
- exact secret-injection slots containing broker metadata only.

The policy is current and digest-bound. Requests cannot expand provider maxima
or use an image, artifact, tool, or egress destination absent from policy.

## Identity And Secret Boundary

Every provider operation receives the raw workload token and re-verifies it
through `WorkloadIdentityVerifier`. The verified project and workload must
equal the request.

Secret injection accepts `BrokeredCredential` objects issued by SF-601. The
configured live broker verifies object identity against its in-memory issuance
registry and durable active-lease audit before the manager verifies project,
workload, resource, version, issue time, expiry, retention, and exact slot
metadata. A caller-constructed object or an object detached by broker restart
fails closed. Credential bytes are passed only through the provider call and
are excluded from all safe records and exception chains.

## Provider Boundary

The provider adapter owns the actual isolation mechanism. The manager accepts a
created workspace only when the provider echoes:

- the request, policy, image, artifact, tool, network, resource, secret-slot,
  and retention digests;
- the exact provider and workspace identities;
- disposable and network-default-deny controls;
- bounded creation and expiry times.

Provider observations contain only bounded metadata: image and artifact
digests, tool invocations, aggregate resource use, destination-only egress
records, and typed violations. Paths, request bodies, headers, environment
values, and credential bytes are not accepted.

Provider exceptions are untrusted. Create, inspect, and destroy replace them
with fixed local errors using no exception chain.

## Quarantine

The manager quarantines a workspace when any observation shows:

- an escape attempt or isolation violation;
- image, repository artifact, tree, or instruction drift;
- an unapproved tool or tool artifact;
- unauthorized egress;
- a resource budget breach;
- creation-policy digest drift or policy expiry;
- failed or invalid read-only provider observation;
- retention expiry.

Quarantine is evidence, not destruction. A quarantined workspace cannot be
inspected for continued use and can only proceed to an explicit destruction
attempt. A provider failure with a successfully recorded local inspection
terminal is closed as quarantine because no provider mutation was requested.
If that terminal is missing, replay exposes `inspection-pending` with the
original manager owner and expiry. Another manager cannot destroy while the
lease remains live. At expiry, one uniquely fenced recovery event closes the
inspection as quarantine; destruction is allowed only after that recovery. By
contrast, uncertain create or destroy effects retain an open intent and block
further mutation.

## Retention And Destruction

Retention is bounded by policy and provider expiry cannot exceed the requested
deadline. Continued use at or after the deadline fails closed.

Destruction is complete only when the provider binds its proof to the exact
workspace and request and confirms:

- all processes terminated;
- network detached;
- writable storage deleted;
- injected secret material deleted;
- workspace no longer exists.

An incomplete cleanup response is a terminal failed-cleanup state that permits
a later explicit retry. A provider outage after durable intent is uncertain and
blocks later mutation until independently reconciled.

## Audit And Replay

The SQLite proof ledger records contiguous hash-chained events with derived
event identities. Request identities are caller supplied, timestamp
independent, and unique before provider invocation. Every intent records its
manager owner and a bounded operation expiry. A per-workspace state fence
prevents separate manager instances from invoking concurrent effects from the
same durable state, and provider workspace identities are single-use. Replay
verifies every digest and reconstructs workspace state. A create or destroy
intent without a terminal event is durable uncertainty; an inspection intent
without a terminal is live pending until expiry and then recoverable only to
quarantine.

## Non-Claims

SF-603 through SF-606, real cloud provisioning, production integrations,
hosted Git enforcement, multi-product tenant isolation, managed retention,
Gate G, L2 ratification, deployment, and any L3 authority are not implemented.
