# Roadmap And Maturity Gates

**Status:** SPECIFIED - implementation sequence

## Sequence

| Phase | Outcome | Gate |
|---|---|---|
| 0. Decisions and spikes | Ratified domain, contracts, reuse strategy | Gate A: architecture decision |
| 1. Operational kernel | Restart-safe ledger, transitions, queue, journal | Gate B: local control plane |
| 2. Worker runtime | Codex can start, steer, resume, cancel, and recover | Gate C: issue-to-evidence flow |
| 3. Owner control room | Owner can see and govern the flow | Gate D: supervised local factory |
| 4. Elder integration | Authority, context, evidence, and qualification are lifecycle gates | Gate E: governed local factory |
| 5. Continual learning | Trajectories create governed, measurable learning | Gate F: learning pilot |
| 6. Hosted L2 | Multiple hosted workers with operational controls | Gate G: qualified hosted L2 |
| 7. Narrow L3 | One certified class reaches observed canary with rollback | Gate H: qualified narrow L3 |

## Critical Path

```text
SF-000 -> SF-001 -> SF-002 -> SF-003
                         |
              +----------+----------+
              v                     v
           SF-004                 SF-005
              +----------+----------+
                         v
                      SF-006
                         v
       SF-100 -> SF-101 -> SF-102 -> SF-103
                         v
       SF-104 -> SF-105 -> SF-106 -> SF-107
                         v
       SF-200 -> SF-201 -> SF-202 -> SF-203 -> SF-205 -> SF-206
                         v
                   local workflow
                         v
       owner plane + Elder integration + learning pilot
                         v
                      hosted L2
                         v
                      narrow L3
```

## Gate A - Architecture Decision

Required:

- pinned source and license record;
- accepted canonical domain model;
- language-neutral event and worker contracts;
- Mastra build/fork/integrate spike;
- Codex/Prime adapter spike;
- human-approved ADR.

Forbidden claim: operational factory.

## Gate B - Local Control Plane

Required:

- work-item ledger;
- deterministic stages and transitions;
- durable dispatch with lease and retry;
- event replay;
- restart-safe run binding;
- local API and health.

Proof: terminate and restart the operations process during queued and running work without losing
accepted state or duplicating effects.

## Gate C - Issue To Evidence

Required:

- Codex worker adapter;
- isolated workspace;
- session start, steer, resume, cancel, and checkpoint;
- normalized events;
- tests and diff collected as evidence.

Proof: one synthetic issue reaches a supervised delivery packet through restart.

Current qualification: `VERIFIED` on 2026-08-13. All mandatory Phase 2 tasks
through SF-206 are verified, and one composed real-Codex workflow reached a
validated supervised delivery packet through hard process restart without
duplicating the prompt effect. Canonical maturity remains L1.

## Gate D - Supervised Local Factory

Required:

- owner inbox and board;
- work room and decision queue;
- approvals and escalation;
- audit replay;
- costs, outcomes, and health.

Proof: an owner can understand and control a run without reading raw database rows or terminal
session history.

Current qualification: `VERIFIED` on 2026-08-14. One authenticated owner
discovered a waiting run, opened its Work Room, submitted one exact follow-up,
and reconstructed the action, audit, and metrics after an API process restart
without database or terminal inspection. Canonical maturity remains L1.

## Gate E - Governed Local Factory

Required:

- Elder classification and authority at intake/start;
- digest-bound context assembly;
- delegated run binding;
- ordered test and evidence policy;
- supervised PR packet integration;
- explicit fail-closed behavior.

Proof: expired authority, stale context, missing evidence, and unauthorized transition all stop
the flow with an owner-visible reason.

Current implementation: SF-400 through SF-404 are `VERIFIED` on 2026-08-14.
Factory Operations has one concrete digest-bound governance adapter and one
persisted immutable context path derived from the current work item, project
activation, and Elder child run. The authority integration submits that exact
chain through P4.5B, issues only the assigned child's bounded lease, rechecks
context and lease before execution, propagates cancellation, and persists
owner-readable acceptance or rejection. Stale activation, work, run lineage,
source bytes, budget or authority expansion, unauthorized memory, changed
packet digests, missing leases, and expiry fail closed. SF-403 binds an
authorized work item to an immutable ordered test plan, one exact local diff
and artifact set, independent advisory evaluation, and a completion evidence
packet while leaving outcome acceptance with the product owner. Failed lower
levels, stale results, changed evidence, secret-shaped traces, concurrent
replay conflicts, and tampered durable rows fail closed. SF-404 composes that
current authority and proof with the existing signed P4.7 and P5.2 gates,
persists the product-owner submit or reject decision before provider
invocation, accepts only an exact supervised pull-request response, and fences
uncertain or concurrent retries without granting merge, release, deployment,
or maturity authority.

Current qualification: `VERIFIED` on 2026-08-14. One exact ledger work item was
classified through SF-400, reconstructed through current SF-401 context,
SF-402 authority, SF-403 evidence, and SF-404 delivery stores, and reached one
owner-approved exact supervised pull-request response with a single provider
invocation. Expired authority, stale context, missing evidence, and an
unauthorized transition each stopped with an owner-visible reason. Canonical
maturity remains L1.

Roadmap progress at Gate E closure: Gate E product-complete mandatory work is
`18/18` (`100%`); Gate H narrow-L3 mandatory work is `18/39` (`46.2%`).

Institutional maturity uses ADR 0022 and
`elder-factory-maturity-standard` version `1.0.0`. L2 requires real hosted
supervised delivery to exact reviewable pull requests while humans retain
merge, release, and deployment. L3 requires one certified reversible class
to reach bounded canary and automatic rollback while humans retain full
rollout and class expansion. The whole-factory level is the minimum verified
mandatory dimension; roadmap completion percentages do not grant maturity.

## Gate F - Continual Learning Pilot

Required:

- trajectory normalization;
- automatic but bounded proposal trigger;
- typed candidates;
- P4.6 replay, shadow, independent evaluation, and approval;
- target application for one low-risk target, initially project memory or supplemental prompt;
- outcome monitoring and rollback;
- retrieval reachability tests.

Proof: one repeated correction produces a candidate, one independent evaluation rejects a bad
candidate, and one approved candidate improves held-out work without regression.

Current implementation: SF-500 is `VERIFIED` on 2026-08-14. It provides only
the bounded read-only trajectory input: exact source/evidence bindings, opaque
references, free-text and secret redaction, deterministic sampling, explicit
exclusions and missing links, and complete expected-outcome attachment.
Independent review, package build, and outside-checkout installed-wheel
execution passed. SF-501 through SF-507 have not started. Gate F remains
unqualified, Phase 5 is `1/8` (`12.5%`) complete, and canonical Elder maturity
remains L1.

Roadmap progress after SF-500: Gate F mandatory work is `19/26` (`73.1%`);
Gate G mandatory work is `19/33` (`57.6%`); Gate H narrow-L3 mandatory work is
`19/39` (`48.7%`).

## Gate G - Hosted L2

Required:

- Postgres and durable broker;
- multiple workers;
- external workload identity;
- secret broker;
- hardened workspace isolation;
- branch protection and independent review;
- central telemetry, alerts, backup, and recovery;
- current signed qualification.

Proof: hosted issue-to-PR flow under failure injection and independent evidence review.

Current implementation: SF-600 is `VERIFIED` on 2026-08-14 for its inactive
implementation scope. It adds PostgreSQL migrations, canonical SQLite
checkpoint import, transactional outbox/inbox delivery, competing-consumer
claims, fenced delivery and projection leases, projection generation reset,
and digest-bound backup/restore. The PostgreSQL DDL executed on a local
PostgreSQL engine. No hosted resource was provisioned, the active local
binding was not changed, and managed multi-process/failover qualification is
deferred to SF-606. SF-601 through SF-606 were not part of SF-600. Gate G
remains unqualified and canonical Elder maturity remains L1.

Roadmap progress after SF-600: Gate F mandatory work remains `19/26`
(`73.1%`); Gate G mandatory work is `20/33` (`60.6%`); Gate H narrow-L3
mandatory work is `20/39` (`51.3%`). Phase 6 is `1/7` (`14.3%`) complete.

SF-601 is `VERIFIED` on 2026-08-14 for its inactive implementation scope. It
adds a provider-neutral OIDC/JWKS workload identity verifier, exact project and
workload bindings, opaque scoped broker references, short-lived credential
leases, timestamp-independent single-use request identities, atomic rotation,
revocation, and secret-free hash-chained audit with uncertain-operation
recovery fences. No external identity provider, vault, production credential,
hosted binding, or authority activation is claimed. SF-602 through SF-606
remain unstarted, Gate G remains unqualified, and canonical Elder maturity
remains L1.

Roadmap progress after SF-601: Gate F mandatory work remains `19/26`
(`73.1%`); Gate G mandatory work is `21/33` (`63.6%`); Gate H narrow-L3
mandatory work is `21/39` (`53.8%`). Phase 6 is `2/7` (`28.6%`) complete.

SF-602 is `VERIFIED` on 2026-08-14 for its inactive implementation scope. It
adds immutable image and repository artifact binding, exact tools,
default-deny egress, resource and retention budgets, live SF-601 broker
credential provenance, provider-error redaction, quarantine, complete
destruction proof, cross-instance broker and workspace operation fences, and
owner-expiring inspection recovery. No cloud workspace, production
repository, hosted network, signed provider observation, or authority
activation is claimed. SF-603 through SF-606 remain unstarted, Gate G remains
unqualified, and canonical Elder maturity remains L1.

Roadmap progress after SF-602: Gate F mandatory work remains `19/26`
(`73.1%`); Gate G mandatory work is `22/33` (`66.7%`); Gate H narrow-L3
mandatory work is `22/39` (`56.4%`). Phase 6 is `3/7` (`42.9%`) complete.

SF-603 is `VERIFIED` on 2026-08-15 for its inactive implementation scope. It
adds one provider-neutral authenticated adapter boundary for GitHub, issue
tracker, chat, CI, and notification classes; canonical signed webhook intake;
current workload and broker credential checks; exact outbound idempotency;
bounded cursor pagination; explicit rate limits; record reconciliation and
drift; durable dead letters; explicit replay; policy-generation binding; and
cross-manager operation fences. No external provider, production account,
hosted retention, branch enforcement, pull request, or authority activation is
claimed. SF-604 through SF-606 remain unstarted, Gate G remains unqualified,
and canonical Elder maturity remains L1.

Roadmap progress after SF-603: Gate F mandatory work remains `19/26`
(`73.1%`); Gate G mandatory work is `23/33` (`69.7%`); Gate H narrow-L3
mandatory work is `23/39` (`59.0%`). Phase 6 is `4/7` (`57.1%`) complete.

SF-604 is `VERIFIED` on 2026-08-15 for its inactive implementation scope. It
adds repository-owned canonical P4.8A trust anchors, exact protected-branch
and required-check policy, signed current governance, provenance, and provider
response, exact open SF-404/P5.2 delivery binding, canonical independent
review, and append-only restart-safe retained evidence. No live Git provider,
repository rule, hosted retention service, pull-request creation, merge,
release, deployment, or authority activation is claimed. SF-605 and SF-606
remain unstarted, Gate G remains unqualified, and canonical Elder maturity
remains L1.

Roadmap progress after SF-604: Gate F mandatory work remains `19/26`
(`73.1%`); Gate G mandatory work is `24/33` (`72.7%`); Gate H narrow-L3
mandatory work is `24/39` (`61.5%`). Phase 6 is `5/7` (`71.4%`) complete.

SF-605 is `VERIFIED` on 2026-08-15 for its inactive implementation scope. It
adds exact tenant/product/principal authorization, digest-derived storage
partitions, bounded quota-reservation accounting, generation-fenced worker
reuse, binding-scoped cache isolation, product-local audit export, immutable
per-event checkpoints, a registered source-store backup catalog, exact
source-path recovery, and an operator disaster runbook. No cloud tenant,
provider-native storage isolation, managed backup, current signed
qualification, L2 ratification, release, deployment, or authority activation
is claimed. SF-606 remains unstarted, Gate G remains unqualified, and
canonical Elder maturity remains L1.

Roadmap progress after SF-605: Gate F mandatory work remains `19/26`
(`73.1%`); Gate G mandatory work is `25/33` (`75.8%`); Gate H narrow-L3
mandatory work is `25/39` (`64.1%`). Phase 6 is `6/7` (`85.7%`) complete.

SF-606 is `BLOCKED` on 2026-08-15 after executing the institutional L2
qualification for exact SF-605 revision
`6962d34c1423f44e064c435f14a79320192f7da2`. The deterministic evaluator
replays signed cumulative evidence, derives ADR-0022 diagnostic metrics from
asserted work history, checks all controls, exercises, dimensions, promotion
evidence, and contradictions, and never qualifies or grants authority. It is
pinned to canonical policy, maturity, standard, and trust anchors, but
provider-bound work history, provider-state and contradiction evidence,
separate independent review, separate human ratification, and replay state
remain unimplemented. The historical advisory L2 bundle remains valid only
for `d8c8eb3...`; GitHub still rejects branch protection for the current
private-repository account plan; no exact-revision hosted run, 30-day
observation window, 20-item history, or hosted failure exercise set exists.
The exact report contains 42 blockers. Gate G remains unqualified and
canonical Elder maturity remains L1. Do not begin Phase 7.

Because SF-606's required L2 outcome is blocked rather than verified, roadmap
progress remains: Gate F `19/26` (`73.1%`), Gate G `25/33` (`75.8%`), Gate H
`25/39` (`64.1%`), and Phase 6 `6/7` (`85.7%`).

## Gate H - Narrow L3

Required:

- one L3-capable certified class;
- production event source;
- immutable artifact and deployment adapter;
- central health telemetry;
- bounded canary;
- automatic rollback;
- incident accounting and suspension.

Proof: a real canary is automatically rolled back under an injected threshold breach. Healthy
canary evidence does not authorize full rollout.

## Stop Conditions

Stop phase advancement when:

- a lower test level is failing;
- the operational projection cannot be rebuilt;
- ownership or authority is ambiguous;
- a dependency spike cannot demonstrate restart and failure behavior;
- a worker can bypass the work ledger or trusted-state controls;
- learning can mutate a target without independent approval;
- an owner cannot see why work is waiting, blocked, failed, or running;
- evidence supports only a narrower claim than the phase gate.
