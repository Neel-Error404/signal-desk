# Reference Reading Map

**Status:** SPECIFIED - pinned source guide

Use the commit listed in `README.md` for each repository. Paths below are relative to the reference
repository root. The local research copies under `.tmp/factory-research/` may be deleted and
recreated; tasks should preserve the commit and upstream path in their evidence.

## Elder Protocol

### Operational Truth And Boundaries

| Read | Extract |
|---|---|
| `AGENTS.md` | Current phase, protected surfaces, activation, test order, claim limits |
| `README.md` | Product boundary and non-operational claims |
| `docs/operational-readiness.md` | Verified capabilities and missing hosted/runtime capabilities |
| `protocol/operational-maturity.json` | Exact L0-L5 definitions and prohibited claims |
| `protocol/meta-architecture.json` | Existing layers, dependency direction, and ownership |
| `protocol/ontology.json` | Canonical entity and relation vocabulary |

### Context, Runtime, Learning, And Autonomy

| Read | Extract |
|---|---|
| `docs/p4-4-governed-knowledge-runtime.md` | Trusted/candidate memory and context boundary |
| `docs/p4-5a-multi-agent-entry-gate.md` | Roles, identities, delegation, and contract-only limits |
| `docs/p4-5b-bounded-multi-agent-runtime.md` | Local coordinator, leases, journals, replay, and gaps |
| `docs/p4-6-quarantined-learning-runtime.md` | Candidate-to-promotion lifecycle |
| `docs/p4-7-hosted-production-qualification.md` | Signed hosted evidence and advisory qualification |
| `docs/p5-1-certification-simulation.md` | Exact class matching and simulation |
| `docs/p5-2-supervised-autonomous-prs.md` | Supervised delivery authority chain |
| `docs/p5-3-fail-closed-canary.md` | L3 canary and rollback boundary |
| `protocol/context-policy.json` | Retrieval, authority, freshness, and budget rules |
| `protocol/memory-policy.json` | Candidate and trusted-memory behavior |
| `protocol/learning-policy.json` | Replay, shadow, evaluator, approval, and promoter rules |
| `elder_protocol/orchestration.py` | Current local runtime implementation and replay |
| `elder_protocol/learning.py` | Current quarantined learning implementation |
| `elder_protocol/autonomy_runtime.py` | P5 authority and execution packet behavior |

## Prime Agent

### Architecture And Long-Running Work

| Read | Extract |
|---|---|
| `README.md` | Product mechanisms and explicit sandbox warning |
| `packages/coding-agent/docs/architecture.md` | Client, supervisor, worker, runtime, and child topology |
| `packages/coding-agent/docs/daemon.md` | Daemon lifecycle and continuity |
| `packages/coding-agent/docs/agent-connection.md` | Client connection and routing model |
| `packages/coding-agent/docs/sessions.md` | Session lifecycle and branching |
| `packages/coding-agent/docs/session-format.md` | Persistent JSONL records |
| `packages/coding-agent/docs/long-running-agents.md` | Goals, heartbeats, schedules, and autonomous continuation |
| `packages/coding-agent/docs/rpc.md` | Machine command surface |
| `packages/coding-agent/docs/json.md` | Event stream surface |
| `packages/coding-agent/docs/acp.md` | ACP integration boundary |
| `packages/coding-agent/docs/windows.md` | Windows-specific support and limitations |

### Runtime Source

| Read | Extract |
|---|---|
| `packages/coding-agent/src/core/agent-session.ts` | Goals, auto-refine lifecycle, commands, and events |
| `packages/coding-agent/src/core/agent-session-runtime.ts` | Session replacement, leases, teardown, and recovery |
| `packages/coding-agent/src/core/session-lease.ts` | Concurrent writer exclusion |
| `packages/coding-agent/src/core/goals.ts` | Persistent goal states and accounting |
| `packages/coding-agent/src/core/agent-messages.ts` | Message identity and delivery |
| `packages/coding-agent/src/core/refinement/refinement.ts` | Proposal generation, conflict checks, apply, and rollback |
| `packages/coding-agent/src/core/refinement/index.ts` | Refinement public surface |
| `packages/coding-agent/src/core/settings-manager.ts` | Persistent settings and refinement configuration |

### Continual Harness

| Read | Extract |
|---|---|
| `packages/coding-agent/src/core/refinement/refinement.ts` | Typed edits, baseline state, history, and application |
| `packages/coding-agent/src/core/agent-session.ts` | Trigger/review/apply timing and prompt construction |
| `packages/coding-agent/src/core/settings-manager.ts` | Local/global stores and persistence behavior |
| `prime-agent-runtime/src/rlm/harness.py` | Python-side harness access |
| `packages/coding-agent/skills/refine/SKILL.md` | Intended evidence and scope policy |
| `packages/coding-agent/skills/goal/SKILL.md` | Goal lifecycle exposed to the agent |
| `packages/coding-agent/skills/rlm-heartbeat/SKILL.md` | Scheduled RLM re-entry |
| `packages/coding-agent/skills/agent-message/SKILL.md` | Inter-agent interaction |

Questions to answer during use:

- Can direct global refinement be disabled or intercepted?
- Can proposal generation be separated from application?
- Is every mutating RPC command idempotent or journaled?
- What state is lost when a process, worker, or machine dies?
- Which Windows paths require WSL or hosted Linux?

## Mastra Factory Monorepo

The relevant package root is `mastracode/factory/`.

| Read | Extract |
|---|---|
| `src/factory.ts` | Composition root, domains, dispatcher lifecycle, routes, integrations |
| `src/rules/dispatcher.ts` | Claims, leases, retries, pending starts, reconciliation |
| `src/rules/start-coordinator.ts` | Session, source-control, workspace, and kickoff binding |
| `src/rules/transition-service.ts` | Atomic transition behavior and terminal hooks |
| `src/rules/defaults.ts` | Default stage and rule semantics |
| `src/rules/types.ts` | Rule and decision contracts |
| `src/storage/domains/work-items/base.ts` | Work-item records, revisions, history, dispatch state |
| `src/storage/domains/work-items/metrics.ts` | Operational measurement |
| `src/storage/domains/audit/` | Audit storage and views |
| `src/integrations/github/` | Source-control and sandbox lifecycle |
| adjacent tests for every file above | Failure semantics actually enforced |

Questions to answer during the spike:

- Which storage and dispatcher interfaces are stable public extension points?
- Can Elder own the domain schema without forking Mastra internals?
- How does a delivery reconcile after a lost acknowledgement?
- Which assumptions require Redis, Postgres, Mastra sessions, or hosted auth?
- Can untrusted repository instructions be kept out of startup context?

## Mastra Factory Template

| Read | Extract |
|---|---|
| `package.json` | Exact alpha dependencies and Node requirement |
| `docker-compose.yml` | Local infrastructure composition |
| `src/mastra/` | Project wiring, integrations, storage, and runtime configuration |
| environment examples and deployment docs | Required external services and secrets |

Use the template to estimate integration and deployment cost, not as proof that the Elder
contracts are satisfied.

## HumanLayer

| Read | Extract |
|---|---|
| `humanlayer.md` | Approval and human-as-tool intent |
| `hld/approval/manager.go` | Durable approval correlation and session state changes |
| `hld/approval/types.go` | Approval records and states |
| `hld/api/handlers/approvals.go` | API behavior |
| `hld/api/handlers/sessions.go` | Session continuation and state |
| `hld/api/handlers/sse.go` | Live event delivery |
| `hld/bus/events.go` | Subscriber buffering and loss behavior |
| `hld/daemon/daemon_*integration_test.go` | Real waiting, resume, orphan, and approval scenarios |

Adopt semantics only after checking whether a newer Prime or Mastra mechanism already supplies
the runtime behavior.

## Factory.ai

No reusable public source was present in the inspected clone. Use official product material only
to define:

- automation creation and visibility;
- owner dashboard and run views;
- pause, resume, retry, and fork;
- triggers, instructions, targets, and outcomes.

Record these as product requirements, not imported implementation.
