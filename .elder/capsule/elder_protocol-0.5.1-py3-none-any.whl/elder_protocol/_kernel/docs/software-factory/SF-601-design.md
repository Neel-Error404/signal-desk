# SF-601 External Identity And Secret Broker Design

**Status:** VERIFIED

## Composition

```text
raw short-lived OIDC token
-> trusted issuer policy and digest-pinned JWKS
-> signature, time, audience, subject, project, workload verification
-> safe verified identity containing token and claims digests only
-> exact broker resource grant
-> provider-issued short-lived credential lease
-> secret-free append-only audit
```

## Identity Boundary

`WorkloadIdentityVerifier` accepts one raw JWT only at verification time. It
requires RS256, one exact trusted key, a current policy, a bounded token TTL,
an accepted audience, and one exact issuer/subject binding. Custom project and
workload claims must match that binding.

The returned identity contains the token SHA-256 and a digest of selected safe
claims. It never returns the token or signing material. Revoked token digests
fail before provider access.

## Broker Boundary

`ExternalSecretBroker` accepts structured opaque references rather than secret
values or provider URIs. Access is the exact intersection of:

- verified project and workload;
- broker and resource;
- resource version;
- action;
- maximum credential lifetime;
- remaining workload-token lifetime.

The provider adapter returns bytes only inside `BrokeredCredential`, whose
representation and metadata exclude those bytes. Broker failure is explicit;
there is no local credential fallback.

## Rotation And Revocation

Every broker mutation requires a caller-supplied request identity. Its durable
operation identity excludes timestamps, is unique before provider invocation,
and cannot be replayed by changing the request time.

The audit records a safe request intent before provider access and a terminal
result after provider success. Local reconstructed state changes only after the
terminal record. A missing terminal result is durable uncertainty and blocks
restart and later mutation.

Rotation must atomically advance the provider resource version and revoke the
exact active lease set supplied by the broker for that project, broker,
resource, and prior version. This includes leases issued to other workloads in
the same project. Revocation outside rotation requires the same workload that
received the lease and an explicit revoke grant.

## Audit

`IdentitySecretAuditLedger` stores a local proof implementation of the hosted
audit contract. Each SQLite row binds its contiguous sequence, derived event
identity, prior digest, event type, time, and safe payload. Generic
secret-shape rejection runs before persistence, and replay recomputes every
digest and chain link.

The active hosted persistence binding remains deferred. SF-601 proves the
provider-neutral mechanism without claiming a configured identity provider,
external vault, or production retention.

## Non-Claims

SF-602 through SF-606, remote workspace injection, production integrations,
hosted Git enforcement, central telemetry, multi-product isolation, Gate G,
L2 ratification, deployment, and any L3 authority are not implemented.
