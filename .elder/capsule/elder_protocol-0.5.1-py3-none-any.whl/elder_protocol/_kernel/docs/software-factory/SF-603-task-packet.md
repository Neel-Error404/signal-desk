# SF-603 Production Integrations Task Packet

**Status:** VERIFIED

**Date:** 2026-08-15

**Base revision:** `a4d6bd08e4c3e4bed0773088d562a29d95de6945`

## Outcome

Provide one provider-neutral governed boundary for GitHub, issue tracker, chat,
CI, and notification adapters with authenticated source intake, authenticated
outbound access, deterministic idempotency, bounded pagination, explicit rate
limits, reconciliation, durable dead letters, and replay.

## Change Class

High-risk hosted-boundary implementation. This work does not change protected
protocol surfaces and does not activate external authority.

## In Scope

- exact policy bindings for the five declared integration kinds;
- HMAC-SHA256 webhook source verification using a live SF-601 credential;
- current workload identity and broker provenance for outbound and
  reconciliation calls;
- exact command and provider-response idempotency;
- cursor-bound one-page reconciliation;
- explicit rate-limit state and retry times;
- external record version and digest drift detection;
- bounded failed-attempt accounting, durable dead letters, and explicit replay;
- secret-free, hash-chained local audit and restart reconstruction;
- provider exception sanitization and cross-manager operation fencing.

## Out Of Scope

- real GitHub, issue tracker, chat, CI, or notification accounts;
- branch protection, required checks, merge queues, reviewer enforcement, or
  provenance activation, which belong to SF-604;
- multi-product isolation, which belongs to SF-605;
- hosted qualification or L2 ratification, which belongs to SF-606;
- deployment, release, or any L3 authority.

## Required Proof

1. A correctly signed webhook is normalized once and survives restart.
2. A forged, stale, or changed duplicate webhook fails closed.
3. An outbound command uses verified workload identity and a live broker
   credential, and exact replay does not repeat the provider effect.
4. Provider outage increments bounded attempts and eventually creates a
   durable dead letter.
5. A declared rate limit prevents provider invocation until its retry time.
6. Pagination binds the requested cursor and advances one deterministic page.
7. Same-version external record drift is quarantined.
8. Dead-letter replay is explicit, idempotent, and restart-safe.
9. Secrets, signatures, credential bytes, and untrusted provider exceptions
   are absent from durable records and local error chains.
10. Concurrent managers cannot invoke the same logical operation twice.

## Stop Boundary

Close SF-603 separately. Do not begin SF-604 until SF-603 is verified,
documented, committed, and pushed.
