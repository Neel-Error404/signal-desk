# SF-404 Supervised Delivery Design

**Status:** VERIFIED

## Composition

```text
current SF-402 execution authority
-> current SF-403 ordered completion
-> signed P4.7 qualification and P5 certification sources
-> existing P5.2 authority lease
-> exact hosted execution
-> existing P5.2 supervised PR packet
-> durable product-owner submit or reject decision
-> existing P5.2 provider invocation and response verification
-> owner-visible open or reconciliation-required state
```

SF-404 does not implement a second qualification, certification, autonomy,
packet, or provider-response validator.

## Durable Boundary

One SQLite WAL store persists the current delivery record. Every read validates
the canonical record digest and exact row bindings. Updates use compare-and-set
on the prior content digest.

The raw SF-402 lease token is request-only and is represented durably only by
the safe request digest. Signed trusted sources are caller-held and represented
by one canonical digest. The P5.2 lease and packet contain no raw secret.

## Provider Uncertainty

The owner decision and `submitting` state are durable before provider
invocation. Any provider exception or response-validation failure moves the
delivery to `reconciliation-required`. Exact retries do not invoke the provider
again.

## Authority

The product owner can choose `submit` or `reject`. P5.2 may create a supervised
pull request only when its complete existing gate passes. Humans retain merge
and release. Deployment and maturity mutation remain forbidden.

## Non-Claims

No canonical P5.2 activation, hosted branch protection, hosted credential,
network provider call, merge, release, deployment, Gate E qualification, or
higher maturity is claimed.
