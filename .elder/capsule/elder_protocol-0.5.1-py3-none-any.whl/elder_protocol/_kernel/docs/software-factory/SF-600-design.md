# SF-600 Hosted Durable Stores And Broker Design

**Status:** VERIFIED

## Composition

```text
local SQLite operations snapshot
-> quiesced source checkpoint and backup digest
-> immutable canonical-record import into PostgreSQL
-> count, row-digest, journal-tip, and projection-digest comparison
-> separately recorded inactive/verified/active hosted binding

canonical transaction
-> canonical hosted record and PostgreSQL outbox
-> competing-consumer claim with row lock and lease generation
-> side effect
-> PostgreSQL inbox dedupe and fenced outbox acknowledgement
```

## Storage Boundary

The hosted schema owns:

- migration history;
- imported canonical records with original table, key, value type, ordinal,
  canonical row bytes, and row digest;
- cutover checkpoints and activation state;
- outbox and inbox delivery state;
- projection-worker checkpoints and leases;
- backup catalog records.

The current SQLite runtime remains the active local binding during SF-600.
There is no dual writable primary. A hosted binding can be marked active only
after exact verification, and this implementation does not automatically
change the application configuration.

## Durable Delivery

`PostgresDurableBroker` stores accepted messages before delivery. Claims use a
single PostgreSQL statement with `FOR UPDATE SKIP LOCKED`, increment a lease
generation, and return the exact payload digest. Acknowledgement inserts the
consumer inbox record and updates the outbox in one transaction while
rechecking owner, generation, expiry, and payload digest.

An exact duplicate inbox message is a no-op. A reused identity with a changed
payload is corruption. Database disconnection or downstream outage cannot be
translated into acknowledgement.

## Projection Workers

Each projection has one checkpoint row. Claims are fenced by owner,
generation, and expiry. Advancement is monotonic and binds the source journal
sequence, journal entry digest, and resulting projection digest. Reset creates
a new generation; it never deletes canonical imported source records.

## Migration And Recovery

SQLite export is accepted only with explicit maintenance, no uncertain
commands, and no active leases. The export binds:

- source path and byte digest;
- SQLite schema version and logical snapshot digest;
- source journal generation, sequence, and entry digest;
- per-table row counts and aggregate digests;
- active projection generations and digests.

Import writes to a fresh cutover identifier. Verification compares every
declared count and digest before activation. Backup exports only the SF-600
hosted tables in deterministic order and binds every row plus the complete
manifest. Restore requires an empty hosted target and re-verifies the restored
snapshot.

## Verification Boundary

Repository tests prove SQL shape, transactional behavior, fencing, duplicate
handling, cutover comparison, backup/restore, and deterministic reconstruction.
A local PostgreSQL engine can be used for mechanism reproduction, but SF-600
does not claim a managed hosted database, real infrastructure failover, or
Gate G qualification. Those require current independently reviewed hosted
evidence in SF-606.

## Non-Claims

SF-601 through SF-606, external workload identity, secret access, remote
workspace isolation, production integrations, protected hosted Git rules,
tenant isolation, managed high availability, deployment, Gate G, L2
ratification, and any L3 authority are not implemented.
