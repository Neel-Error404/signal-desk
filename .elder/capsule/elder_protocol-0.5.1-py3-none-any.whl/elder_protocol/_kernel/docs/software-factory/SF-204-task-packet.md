# SF-204 - Optional Prime Agent Adapter

**Status:** VERIFIED

**Change class:** bounded local worker-runtime implementation

**Owner:** factory operations

**Approver:** human repository owner

**Dependencies:** SF-005, SF-006, SF-200, SF-202, SF-203

**Source revision:** `483c38152867b6fb9c81d5f40545d834291fdff8`

## Outcome

An approved local task can select the pinned Prime Agent daemon through the
unchanged SF-200 worker contract. Prime remains an optional execution
continuity sidecar with no canonical write authority, and any refinement
proposal is redirected to an Elder candidate sink rather than applied directly.

## Non-Goals

- making Prime a required project dependency or the default worker;
- goals, schedules, heartbeats, continuation budgets, or autonomous re-entry;
- provider credential creation, copying, or serialization;
- factory-wide worker recovery or automatic reconciliation beyond Prime's
  stable command journal;
- trusting Prime sessions, messages, events, checkpoints, or refinements as
  canonical Elder state;
- merge, release, deployment, maturity, approval, or promotion authority;
- claiming live model execution without a separately enabled credentialed
  workflow.

## Required Reading

- `docs/adr/0021-software-factory-operational-architecture.md`
- `docs/software-factory/14-codex-prime-worker-spike.md`
- `docs/software-factory/15-operational-architecture-ratification.md`
- `docs/software-factory/SF-200-implementation-directive.md`
- `docs/software-factory/SF-202-design.md`
- `docs/software-factory/SF-203-design.md`
- `docs/software-factory/tasks/phase-2-to-4-worker-owner-governance.md`
- pinned Prime source commit
  `b9a4461149419156599d60174dddf15458e2b9ee`

## Current-State Inspection

Elder activation `activation-elder-protocol-72a1ca1c89317176` succeeded for the
SF-204 task. The repository was clean on
`work/sf-204-prime-agent-adapter` at source revision `483c381`.

The pinned Prime source is present under
`.tmp/factory-research/prime-agent`, its exact Git revision and package version
match SF-005, Node is `v24.14.0`, and Git Bash exists at
`C:\Program Files\Git\bin\bash.exe`. Prime dependencies are not installed in
the repository and Prime is not added to Elder's package dependencies.

Existing implementation already supplies:

- the provider-neutral SF-200 request, response, cursor, and evidence contract;
- durable adapter receipts and uncertainty behavior;
- the SF-202 exact workspace and sandbox binding;
- the SF-203 durable session-control coordinator;
- the P4.6 independently governed learning runtime.

The missing bounded component is a Prime-specific translation and recovery
adapter that preserves those boundaries.

## Boundaries And Authority

- SF-105 remains canonical run, session, workspace, and transition authority.
- SF-202 remains physical workspace and sandbox authority.
- SF-203 remains durable owner/executor session-control intent.
- Prime daemon sessions, command journals, snapshots, and events are provider
  observations only.
- Prime `clientId + commandId` provides provider idempotency, not authority.
- Prime session-path leases provide same-host concurrency exclusion, not Elder
  authorization.
- A refinement sink may create or route a candidate under separate P4.6
  authority. The worker adapter cannot approve, promote, or apply it.
- Protected protocol surfaces and accepted ADRs are outside the write set.

## Claim And Failure Conditions

Claim:

> The pinned Prime daemon can be selected behind the SF-200 adapter boundary
> for one approved local workspace, recover across daemon replacement, replay
> known command results without repeating effects, reject lease conflicts, and
> disable automatic refinement, quarantine refinement proposals, and fail
> closed if Prime records a direct refinement application.

Failure conditions:

- Prime changes or replaces factory work-item, run, session, workspace,
  generation, authority, or command identity;
- a provider store or credential directory is writable by the worker;
- a lost command response is blindly repeated with a new provider identity;
- an uncertain Prime command is reported as completed;
- two workers write the same Prime session path;
- a daemon restart changes the bound provider session;
- local or global Prime refinement is applied directly;
- a proposal is accepted without an Elder candidate sink;
- secrets, credential values, raw auth files, or unrestricted inherited
  environment enter adapter evidence;
- Prime becomes a canonical dependency or default worker.

## Phase Proportionality

Current phase and gate: Phase 2 Worker Runtime, progressing toward Gate C.

Declared runtime: local Windows, one operations process, one SF-202 workspace,
one optional Prime daemon, isolated Prime agent directory, Git Bash boundary,
and provider-local daemon command journal.

Required current-scope guarantees: exact SF-200 conformance, pinned runtime
identity, stable command identity, provider session reattachment, explicit
lease conflict, refinement quarantine, secretless adapter state, and
fail-closed uncertainty.

Deferred guarantees: SF-205 scheduling and heartbeat semantics, SF-206
factory-wide recovery, hosted workload identity and secret brokering, multiple
workers, central telemetry, and production qualification.

Stop condition: do not introduce a scheduler, broker, new SF-200 operation,
Prime package dependency, protected-surface change, or autonomous learning
application.

## Implementation Plan

1. Add a pinned Prime runtime configuration and local daemon JSONL bridge.
2. Add a durable Prime adapter using the unchanged SF-200 operations.
3. Bind one isolated agent directory, session path, workspace, client ID, and
   factory generation.
4. Replay incomplete sends with the same provider command identity.
5. Reject direct refinement application and route proposals through a narrow
   candidate sink.
6. Add focused ordered proof and package the bridge with the Python wheel.

## Test Plan

### Foundation

- pinned version, source revision, daemon protocol, schema, Bash boundary,
  package files, capabilities, and no canonical authority.

### Component

- session start and restart attach, lease conflict, candidate redirection,
  direct refinement prevention, and command-journal recovery.

### Integration

- unchanged SF-200 conformance and fresh-adapter reattachment.

### Workflow

- one approved Prime-backed task reaches passing evidence without authority.

### Stress

- concurrent duplicate command delivery produces one provider effect.

## Rollback

The change is additive. Rollback removes the Prime adapter, packaged bridge,
tests, and SF-204 documents. SF-200 through SF-203 stores and contracts remain
valid and unchanged.

## Completion Verdict

`VERIFIED`

Reason: the unchanged SF-200 conformance suite, focused restart, lease,
journal, refinement, workflow, concurrency, package, and validation evidence
pass for the declared local optional-adapter scope. Prime remains non-default
and has no canonical authority. No live credentialed model execution is
claimed.
