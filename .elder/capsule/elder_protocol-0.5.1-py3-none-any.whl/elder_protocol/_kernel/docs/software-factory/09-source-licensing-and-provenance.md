# Source Licensing And Provenance Decision

**Status:** APPROVED

**Work item:** SF-000

**Decision owner:** human-owner

## Current Evidence

Elder has no declared repository license. There is no root `LICENSE`, `LICENCE`, `NOTICE`, or
`COPYING` file, and `pyproject.toml` does not declare a project license. Absence of a license is
not permission to copy, redistribute, fork, or incorporate third-party code.

The pinned research repositories are analysis inputs under `.tmp/factory-research/`; they are not
vendored dependencies. Exact source, revision, license, package, path, attribution, limitation,
and reuse records belong in `research-sources.json`.

## Decision Options

### Option A - Reference And Independent Reimplementation

**Recommendation**

- Permit reading pinned sources for architecture, behavior, testing, and product requirements.
- Permit independently written implementations only within a later ratified task that records
  the exact referenced paths, behavior adopted, test evidence, and confirmation that no source
  implementation was copied.
- Prohibit code copying, selective extraction, vendoring, forks, and direct or optional package
  dependencies until the applicable spike and a separate explicit owner decision.
- Keep Elder's repository license unresolved for now. This blocks compatibility claims and all
  third-party code incorporation.

This option lets SF-001 through SF-003 use the references as evidence without pre-deciding the
Mastra or Prime integration choices owned by SF-004 and SF-005.

### Option B - Reference Only

- Permit reading pinned sources only.
- Prohibit independent implementation derived from inspected implementation details.
- Require a new human decision before any external behavior or contract is adapted.

This is the most restrictive option and creates additional decision gates during Phase 0.

### Option C - Select Elder License And Reuse Method Now

- Select Elder's distribution model and repository license.
- Perform license compatibility review for every selected external path and transitive package.
- Decide direct dependency, fork, selective extraction, or independent implementation per source.

This is not recommended in SF-000 because the Mastra and worker spikes have not produced the
failure, maintenance, or contract-fit evidence needed for those commitments.

## Proposed Policy

Until a later task and explicit human approval state otherwise:

- no third-party source code may be copied, extracted, vendored, or forked;
- no third-party package may become a direct or optional Elder dependency;
- product pages, screenshots, text, branding, and visual assets may not be copied;
- Factory.ai is product-behavior and UX-requirements reference only;
- Prime Agent may inform runtime and learning-proposal patterns, with integration pending SF-005;
- Mastra may inform operations-plane contracts, with dependency/fork/adaptation pending SF-004;
- HumanLayer may inform human-interaction semantics, without whole-repository integration;
- every later reuse proposal must cite exact source paths and the pinned commit;
- any license, source, package, or upstream-path change reopens the owner decision;
- attribution and license obligations must be preserved when a later approved action requires
  them.

This record is not legal advice and does not resolve patent, trademark, redistribution, or
path-specific licensing questions.

## Approval

The human owner approved **Option A - Reference And Independent Reimplementation** on
2026-08-07 in the active SF-000 Codex session.

This approval:

- does not select or change Elder's repository license;
- does not approve code copying, selective extraction, vendoring, forks, or dependencies;
- does not approve a Mastra build-versus-integrate choice;
- does not make Prime Agent a runtime dependency;
- permits later independently written implementations only with task-specific source paths,
  evidence, tests, and the required task or architecture approval.
