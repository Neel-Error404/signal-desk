# SF-605 Multi-Product Boundaries And Recovery Design

**Status:** VERIFIED

## Boundary

```text
current repository-owned product policy
-> exact principal and action authorization
-> derived tenant/product/project partition
-> quota and worker-generation fences
-> product-scoped cache, audit, backup, and restore
```

The caller never supplies a filesystem partition. A partition ID is the
digest-derived identity of one exact tenant, product, and project. Every
storage path is resolved beneath that partition, and its marker binds the
active policy and scope. The returned pathname is an identity for the existing
SF-602 workspace/provider boundary; SF-605 does not replace provider-side
no-follow file opening or junction protection.

## Authorization

The policy contains no wildcard tenant, product, project, principal, or
action. It must define at least two unique products and exact grants. Every
operation revalidates policy currency and resolves one exact scope before
reading or mutating state.

## Quotas And Worker Reuse

Quota reservation accounting serializes through a cross-process fence and
SQLite `BEGIN IMMEDIATE`. Physical byte measurement remains the responsibility
of the component that creates storage or retained evidence. Active-worker
capacity is enforced from durable bindings.
A worker has at most one active binding across all products. Reuse requires
release and increments the worker generation; stale generations fail.

`ProductScopedCache` keys data by tenant, product, and exact live binding
digest. Rebinding the same worker cannot expose a prior product's cache.

## Audit

Every state-changing boundary operation appends to an immutable hash chain
and immutable per-event checkpoint owned by one tenant and product. Export
first records the accountable export, then returns only that product's
replayed chain and tip digest. This detects ordinary row mutation and
record/checkpoint mismatch; it does not claim an external cryptographic anchor
against a fully privileged host that can replace both the database and its
storage.

## Backup And Restore

A backup includes:

- the exact scope and active policy digest;
- quota reservations;
- worker-binding history;
- the complete product audit chain;
- caller-supplied component snapshots whose scope and digest are verified.

The backup is stored only inside the product partition and registered in an
immutable source-store catalog. Restore requires both that exact partition file
and the read-only source store whose catalog binds its digest and relative
path. Caller-authored manifests are not accepted. The backup audit must
terminate in its own `product.backup.created` event.

Restore also requires an empty target for the exact same tenant, product,
project, and policy. It cannot overwrite or merge state. Any source worker
marked active becomes `recovery-required`; no restored lease resumes authority
automatically. Component snapshots are returned to the recovery coordinator
for explicit component-specific restore.

## Non-Claims

This implementation does not prove provider-native tenancy, encryption,
managed backup, a live disaster exercise, or hosted L2 qualification. Those
claims require SF-606 evidence for the exact deployed environment.
