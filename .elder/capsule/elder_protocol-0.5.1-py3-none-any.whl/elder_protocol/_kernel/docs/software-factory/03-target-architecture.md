# Target Operational Architecture

**Status:** RATIFIED FOR PHASE 1 by ADR 0021 on 2026-08-08

## Architecture Shape

The factory has four planes and one shared event spine.

```text
                    +-----------------------------+
                    | Product And Owner Plane     |
                    | inbox, board, work room,    |
                    | decisions, approvals, cost  |
                    +--------------+--------------+
                                   |
                                   v
                    +-----------------------------+
                    | Factory Operations Plane    |
signals ----------> | ledger, rules, dispatcher,  |
                    | scheduler, run controller,  |
                    | integrations, projections   |
                    +---+---------------------+---+
                        |                     |
          policy checks |                     | worker commands/events
                        v                     v
             +------------------+   +--------------------------+
             | Elder Governance |   | Worker Plane             |
             | And Learning     |   | Codex, optional Prime,   |
             | authority,       |   | workspaces, sessions,    |
             | context, eval,   |   | tools, checkpoints       |
             | qualification    |   +--------------------------+
             +--------+---------+
                      |
                      v
             +------------------+
             | Governed Learning|
             | proposal, replay,|
             | shadow, promote  |
             +------------------+

All planes append correlated facts to the event journal.
Read models and UI projections are rebuilt from those facts.
```

## Plane Responsibilities

### Product And Owner Plane

Owns:

- product factory registry;
- owner inbox;
- work-item board;
- work room for discussion and steering;
- approval, clarification, and escalation queues;
- run timeline, evidence, cost, and outcome views;
- pause, resume, cancel, retry, and fork commands.

It never mutates worker or governance state directly. It submits commands to the operations plane.

### Factory Operations Plane

Owns:

- signals and idempotent intake;
- work items, stages, revisions, priorities, dependencies, and source references;
- deterministic transition rules;
- durable dispatch, leases, retries, dead letters, and schedules;
- run, session, workspace, and artifact bindings;
- worker command delivery and event ingestion;
- integrations with source control, issue trackers, chat, and CI;
- the canonical operational event journal and projections.

This is the missing operational loop.

### Worker Plane

Owns:

- one provider-neutral worker contract;
- Codex as the primary implementation adapter;
- optional Prime Agent adapter after the spike;
- isolated workspaces and process boundaries;
- start, steer, follow-up, pause, resume, cancel, checkpoint, and inspect;
- normalized worker events and evidence.

Workers do not own product state, authority, trusted memory, or promotion.

### Elder Governance And Learning Plane

Owns:

- project profile, ontology, invariants, and protocol digests;
- authority, roles, delegation, and change classification;
- context and trusted-memory assembly;
- evidence and test requirements;
- evaluation, qualification, certification, and autonomy resolution;
- immutable learning candidates, replay, shadow, approvals, promotion packets, and rollback packets.

Elder is invoked at explicit lifecycle gates rather than every low-level action.

## Canonical Entities

The Phase 0 domain model must define at least:

- `ProductFactory`
- `Signal`
- `WorkItem`
- `WorkItemRevision`
- `StageTransition`
- `Run`
- `WorkerSession`
- `Workspace`
- `Command`
- `Event`
- `Checkpoint`
- `Artifact`
- `EvidenceRecord`
- `DecisionRequest`
- `Decision`
- `Schedule`
- `Outcome`
- `LearningCandidate`
- `LearningEvaluation`
- `Promotion`
- `Incident`

Every entity must have a stable identifier, project binding, timestamps, actor identity, status,
version or digest, and correlation identifiers where relevant.

## Required Contracts

### Worker Adapter

```text
prepare(work_item, authority, context) -> prepared_run
start(prepared_run) -> worker_session
send(command) -> accepted_command
observe(cursor) -> normalized_events
checkpoint(session) -> checkpoint
cancel(session, reason) -> cancellation_result
recover(session) -> recovery_result
collect_evidence(session) -> evidence_bundle
```

Mutating commands require idempotency identifiers. An uncertain result may be reconciled but must
not be blindly repeated.

### Governance Adapter

```text
classify(work_item) -> change_class
assemble_context(request) -> context_packet
authorize(action) -> authority_result
validate_delegation(delegation) -> validation_result
evaluate(evidence) -> evaluation_result
qualify(bundle) -> qualification_report
propose_learning(trajectory) -> candidate
promote(packet) -> governed_target_result
```

The final `promote` operation is target-specific and must preserve the P4.6 separation of duties.

### Event Contract

Every event contains:

- event id and type;
- schema version;
- occurred-at and recorded-at timestamps;
- product, work-item, run, and session correlation where applicable;
- actor and source;
- causation and correlation ids;
- idempotency key for accepted external input;
- payload digest;
- redaction classification.

## Dependency Direction

Allowed:

```text
owner UI -> operations API
operations -> worker adapter
operations -> Elder adapter
worker adapter -> external worker runtime
projections -> event journal
learning proposal -> Elder learning runtime
```

Forbidden:

```text
worker -> direct trusted-memory mutation
worker -> direct work-item stage mutation
UI -> direct database mutation
learning model -> direct policy or production mutation
external integration -> direct worker execution
Elder protocol files -> dependency on one worker provider
```

## Deployment Evolution

### Local Kernel

- SQLite or equivalent transactional store.
- One operations process.
- One Codex worker at a time.
- Local event journal and projections.
- Restart-safe behavior.

### Hosted L2

- Postgres.
- Durable broker or streams.
- Multiple workers.
- External workload identity and secret broker.
- Hardened workspaces.
- Central telemetry, backups, alerts, and owner authentication.

### Narrow L3

- One certified low-risk class.
- Production signal integration.
- Immutable artifacts.
- Canary deployment.
- Central health observation.
- Verified automatic rollback.
- Human remains release and expansion authority.

## Architecture Fitness Functions

- Replaying the journal rebuilds the same work-item and run projections.
- Duplicate intake does not create duplicate work.
- Duplicate mutating worker commands do not create duplicate side effects.
- A worker crash does not lose accepted commands or owner decisions.
- A direct worker attempt to change trusted memory is rejected.
- An unauthorized transition is rejected.
- A stale or invalid context packet is rejected.
- A learning candidate cannot apply itself.
- Every completed work item links outcome, run, diff, tests, evidence, approvals, and delivery.
