# SF-403 Implementation Plan

**Status:** VERIFIED

1. Activate SF-403 from the pushed SF-402 closure.
2. Read the execution contract, transition rules, artifact references,
   evaluation boundary, and proportional delivery rule.
3. Define immutable plan, result, evaluation, completion, and owner-view
   records.
4. Bind plan creation to current SF-402 execution authority.
5. Implement exact Git diff and artifact-byte verification.
6. Enforce ordered results, freshness, secret rejection, and lower-level
   failure blocking.
7. Require independent advisory evaluation before completion.
8. Prove the completion packet through the existing work-item transition
   engine.
9. Run Foundation through Stress in order.
10. Review, validate, package, install, document, commit, and push separately.
