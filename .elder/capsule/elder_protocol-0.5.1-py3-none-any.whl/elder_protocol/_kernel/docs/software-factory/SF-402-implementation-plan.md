# SF-402 Implementation Plan

**Status:** VERIFIED

1. Reconfirm the clean pushed SF-401 baseline and activate Elder for SF-402.
2. Read P4.5A, P4.5B, P5 autonomy boundaries, Gate E, and the proportional
   delivery rule.
3. Define exact start, decision, owner-view, cancellation, and execution-recheck
   contracts.
4. Compose SF-401 and P4.5B without changing protected protocol surfaces.
5. Persist accepted and rejected decisions without raw lease tokens.
6. Prove scope, tool, budget, deadline, and identity expansion failures.
7. Prove missing lease, expiry, cancellation propagation, restart, replay, and
   concurrent exact retry behavior.
8. Run Foundation, Component, Integration, Workflow, and Stress in order.
9. Complete focused correctness review, protocol validation, package build,
   installed-package proof, roadmap updates, and vault checkpoint.
10. Commit and push SF-402 separately; do not begin SF-403 until closure.
