# Gate E - Governed Local Factory Qualification

**Status:** VERIFIED

**Change class:** bounded local qualification

**Owner:** factory operations

**Approver:** human repository owner

**Dependencies:** SF-400, SF-401, SF-402, SF-403, SF-404

**Source revision:** `95ed91d21004efbe4bfcc0f0515caf03ed1d126e`

## Objective

Prove that one realistic local issue reaches an exact owner-visible supervised
delivery state through current Elder classification and authority, governed
context, assigned-child delegation, ordered evidence, and P5.2 delivery gates.
The complete owner trace must survive service reconstruction from durable
stores.

## Success

- the accepted work item exposes its objective and project identity;
- SF-400 classifies that exact ledger work item under the current
  change-class policy;
- the exact SF-401 packet is current and authorized for the assigned child;
- the SF-402 owner view exposes an authorized current child lease;
- the SF-403 owner view exposes complete ordered tests and independent
  evaluation;
- the SF-404 owner view progresses from authorized to ready to open;
- context, authority, evidence, packet, decision, and provider response survive
  reconstruction of all four service objects;
- one provider invocation is accepted and humans retain merge and release;
- expired authority, stale context, missing evidence, and unauthorized
  transition each stop their isolated flow with an actionable owner-visible
  reason;
- Canonical Elder maturity remains L1.

## Failure

- the proof bypasses SF-400 through SF-404 or creates another authority engine;
- any stage depends on direct SQLite inspection for the owner decision;
- restart is represented only by re-reading an existing service object;
- a stale or unauthorized flow reaches provider invocation;
- missing evidence can still create a packet;
- a failure is silent, generic, or absent from the responsible owner view;
- the proof starts Phase 5 learning behavior or implies maturity above L1.

## Scope

- local Windows filesystem and SQLite stores;
- one generated project, work item, parent-child run chain, and product owner;
- current signed qualification and autonomy fixtures only;
- deterministic fake provider response;
- no hosted service, real credential, merge, release, deployment, learning,
  tenant isolation, or production telemetry;
- no protected protocol-surface change.

## Authority

The qualification grants no authority. SF-401 remains the context binding,
SF-402 remains the assigned-child execution gate, SF-403 remains the ordered
proof gate, and P5.2 remains the lease, packet, provider-response, and hard-stop
authority. The product owner can submit or reject the exact packet only.

## Test Plan

1. Foundation: document and composition contract.
2. Component: four required owner-visible fail-closed cases.
3. Integration: exact issue, context, authority, evidence, execution, and
   delivery bindings after stack reconstruction.
4. Workflow: owner-visible authorized, ready, and open states through three
   complete service reconstructions.
5. Stress: concurrent post-restart owner traces remain deterministic with one
   provider invocation.

## Completion Gate

Gate E may be marked `VERIFIED` only after the ordered ladder, focused
correctness review, protocol validation, final package build, isolated
installed-package verification, roadmap and README updates, vault update, and
separate authorized commit and push. Stop before Phase 5.
