# SF-200 Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

## Scope

These commands verify only the provider-neutral Worker Adapter Conformance Suite. They do not
invoke Codex, Prime, a model provider, a reusable worker supervisor, or hosted infrastructure.

The canonical project command form uses `py`. In the managed verification sandbox used on
2026-08-13, the Windows launcher registry was unavailable, so the same commands were run with:

```text
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe
```

## Ordered Focused Ladder

Foundation:

```powershell
py -m unittest tests.foundation.test_worker_adapter_conformance_contract -v
```

Expected: 6 tests pass.

Component:

```powershell
py -m unittest `
  tests.component.test_fake_worker_adapter `
  tests.component.test_worker_adapter_conformance -v
```

Expected: 10 tests pass.

Integration:

```powershell
py -m unittest tests.integration.test_worker_adapter_recovery -v
```

Expected: 2 tests pass. The restart test launches two deterministic, test-owned Python child
processes. It does not install or expose a reusable supervisor.

Workflow:

```powershell
py -m unittest tests.workflow.test_sf200_worker_conformance -v
```

Expected: 1 test passes.

Stress is not applicable to SF-200 because the implementation adds no concurrent worker-access
contract. SQLite is used only as a test-scoped durable private ledger. Concurrent scheduling and
worker ownership remain deferred to later tasks.

## Package And Protocol Verification

```powershell
py -m elder_protocol.cli validate
py -m elder_protocol.cli skills validate
py -m compileall -q elder_protocol tests
py -m build --no-isolation
py scripts/verify_installed_wheel.py
git diff --check
```

Installed-wheel verification must import `elder_protocol.factory_workers`, execute the reusable
runner against a fake adapter outside the checkout, verify all eight operations, and confirm the
SF-200 design, evidence, and test files are package-visible.

## Verified Failure Cases

- unknown operation and unsupported command capability reject before effect;
- secret-shaped and provider-specific canonical fields reject;
- canonical write claims reject;
- changed idempotent replay bindings reject;
- stale and future cursors return exact fail-closed outcomes;
- changed or out-of-order factory projections reject;
- timeout before effect permits exact same-key retry;
- response loss after effect becomes uncertain;
- recovery with another stream generation rejects;
- fresh-process recovery reconciles one effect without executing it twice;
- checkpoint output cannot invent or replace canonical Elder checkpoint authority.
