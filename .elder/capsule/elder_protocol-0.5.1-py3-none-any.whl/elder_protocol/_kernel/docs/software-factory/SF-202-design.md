# SF-202 Workspace And Sandbox Lifecycle Design

**Status:** VERIFIED

**Date:** 2026-08-13

**Base revision:** `db9f47c4a16ea9c341af94345bfdf44cd736c88c`

## Outcome

Each SF-105 run can receive one exact physical Git worktree and one exact local
workspace-write sandbox binding. The workspace is attributable to the immutable
run binding, can be inspected and recovered after process loss, and cannot be
silently released when its contents are unsafe or uncollected.

## Scope

SF-202 implements:

- exact worktree materialization from the SF-105 repository, branch, path, and
  source revision;
- source cleanliness and current-revision checks before materialization;
- trusted instruction verification before a worker may use the workspace;
- secretless local environment and sandbox specifications;
- a short-lived workspace-use lease for concurrent local ownership;
- deterministic workspace inspection without persisting file contents;
- quarantine and retention of unsafe or failed workspaces;
- clean Git worktree release without forced deletion or branch deletion;
- recovery from a missing or stale runtime manifest, expired lease, or process
  loss during materialization or cleanup.

SF-202 does not implement:

- the SF-203 owner/scheduler command queue or worker-session state machine;
- provider-session leases, follow-up delivery, pause/resume, or checkpoints;
- workspace pooling or reuse;
- hosted sandboxes, containers, VMs, tenant isolation, workload identity, or a
  secret broker;
- staging, committing, pushing, merging, deployment, or release;
- forced deletion of dirty workspaces or automatic deletion of work branches;
- changes to SF-105 canonical workspace identities, transitions, or authority.

## Ownership Boundary

SF-105 remains the canonical lifecycle authority for `requested`,
`provisioning`, `ready`, `in-use`, `quarantined`, `releasing`, `released`, and
`failed`.

SF-202 owns only physical effects and observations:

```text
SF-105 immutable run binding
-> SF-105 workspace-provision authorization
-> SF-202 materialize and verify exact worktree
-> digest-bound workspace verification observation
-> SF-105 workspace-ready authorization
-> SF-202 short workspace-use lease
-> worker adapter receives the verified path and sandbox specification
```

SF-202 never fabricates an SF-105 lifecycle command or authorization. Its
evidence can be consumed by an authorized command, but evidence is not
authority.

## Durable Runtime State

Runtime state is stored beneath the existing P3 verification area:

```text
<repository>/<state_root>/<verifications>/workspaces/<workspace-id>.json
<repository>/<state_root>/<verifications>/workspaces/<workspace-id>.lock
```

The JSON manifest is atomically replaced and digest-bound. The lock file uses a
cross-process operating-system file lock. The manifest is runtime evidence, not
canonical workspace state.

The manifest records:

- exact run, workspace, binding, repository, branch, path, and revisions;
- physical state: `ready`, `retained`, `released`, or `uncertain`;
- latest inspection and sandbox digests;
- workspace-use lease owner, generation, and expiry, without a bearer token;
- last operation, timestamps, and content digest.

The workspace lease is a local concurrency fence only. It grants no Elder,
worker, Git, merge, release, or deployment authority.

## Source And Git Controls

Before materialization:

1. the repository resolves to the exact SF-105 repository root;
2. current `HEAD` equals the bound base revision;
3. the source checkout has no tracked or untracked delta;
4. the derived branch and path equal the immutable binding;
5. the target path is absent and contained under the configured worktree root;
6. the bound P3 Git and workspace policy digests still match;
7. tracked secret-file paths and tracked symbolic links are rejected.

Materialization uses:

```text
git worktree add -b <bound-branch> <bound-path> <bound-base-revision>
```

Git receives only the P3 allowlisted environment plus fixed noninteractive
flags. Git stderr and stdout are represented by digests in failures rather than
persisted raw.

## Instruction Trust

Instruction-bearing paths include:

- root or nested `AGENTS.md`, `CLAUDE.md`, and `GEMINI.md`;
- `.codex/config.toml`;
- `.github/copilot-instructions.md`;
- `.cursorrules`;
- files under `.cursor/rules/`.

For `trusted-source-revision`, the trusted instruction revision must equal the
workspace source revision and the materialized bytes must match that revision.

For `trusted-base-only`, the complete instruction manifest at the source
revision must equal the complete instruction manifest at the trusted revision.
Any added, removed, or changed instruction path fails closed before worker use.
SF-202 does not attempt to rewrite or mask hostile instructions.

Instruction changes introduced after worker start make inspection unsafe and
require quarantine before further use.

## Sandbox Binding

The sandbox specification fixes:

- one writable root: the exact workspace;
- `workspace-write`;
- `on-request` approval with user review;
- network disabled;
- no additional roots;
- environment variable names limited to the P3 allowlist;
- no inherited secret-shaped environment variable names;
- exact instruction-manifest digest.

The specification contains no environment values or credentials.

## Inspection

Inspection records only bounded counts, Git identifiers, and digests:

- current `HEAD`, branch, tree, and worktree-registration state;
- tracked, untracked, ignored, and cache-entry counts;
- status and ignored-inventory digests;
- instruction-manifest digest and whether it changed;
- unsafe-path, symbolic-link, or reparse-point counts;
- clean and safe decisions.

File contents and raw Git diagnostic output are not persisted.

Ignored dependency caches may exist inside the isolated worktree. They are
counted and excluded from delivery evidence. A cache that is a symbolic link,
junction, or other reparse point is unsafe.

## Quarantine And Release

Quarantine retains the exact worktree and asks Git to lock it against pruning.
It clears the workspace-use lease and records a reason digest.

Release requires:

- canonical SF-105 workspace status `releasing`;
- no active workspace-use lease;
- exact registered worktree identity;
- a clean and safe inspection.

Release uses normal `git worktree remove`. It never uses `--force`, deletes a
dirty worktree, discards changes, or deletes the work branch. A dirty or unsafe
workspace remains retained for evidence and requires an explicit later
decision.

This is the Phase 2 interpretation of SF-105 `physical_delete: false`: no forced
destruction or silent evidence loss.

## Recovery

Recovery recomputes truth from SF-105 plus Git:

- a valid worktree with a missing manifest is reconstructed;
- a valid worktree left by a crashed prepare becomes `ready`;
- a dirty or unsafe worktree becomes `retained`;
- an expired workspace-use lease is cleared;
- an absent worktree is `released` only when SF-105 is already `releasing` or
  `released`;
- branch, path, revision, registration, or instruction ambiguity becomes
  `uncertain` and fails closed.

## Test Ladder

Foundation:

- schemas and package visibility;
- immutable binding and policy validation;
- instruction and secret-path classification;
- sandbox specification contains no environment values.

Component:

- prepare, validate, lease, renew, inspect, quarantine, release, and recover;
- dirty source;
- hostile trusted-base-only instructions;
- tracked or generated secret-file attempts;
- cache and link handling;
- expired and conflicting leases;
- retained dirty workspace.

Integration:

- SF-105 `workspace-provision` -> SF-202 prepare -> SF-105
  `workspace-ready`;
- SF-202 lease -> SF-201 workspace binding;
- crash reconstruction from real Git worktree state;
- clean release confirmation path.

Workflow:

- one real local run obtains an isolated workspace, executes a bounded Codex
  task, is inspected, and remains retained with exact evidence.

Stress:

- concurrent acquisition for one workspace has one winner;
- concurrent preparation for distinct runs does not cross-bind paths;
- crash and expired-lease recovery remain deterministic.

## Completion

SF-202 is complete only when:

1. all current-scope tests pass in ordered relevant levels;
2. no current-scope `BLOCKER` or `REQUIRED` review finding remains;
3. evidence documents exact commands, results, limitations, and retained
   artifacts;
4. the implementation is committed separately before SF-203 begins.
