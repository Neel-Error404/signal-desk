# SF-602 Hardened Hosted Workspaces Task Packet

**Status:** VERIFIED

**Date:** 2026-08-14

**Base revision:** `96415ddc098194edcd50d3bdf0b0b16c34bf6558`

## Outcome

Remote worker execution can be bound to one isolated, disposable hosted
workspace without trusting mutable image tags, unpinned repository state,
unbounded tools or network, ambient credentials, or unverifiable cleanup.

## Change Class

High-risk hosted execution boundary. The implementation is provider-neutral
and inactive: no cloud resource is provisioned and no production authority is
activated.

## Scope

SF-602 implements:

- digest-pinned execution images and repository artifacts;
- exact workload, project, provider, run, and workspace binding;
- default-deny network policy with exact egress destinations;
- exact tool identities and artifact digests;
- CPU, memory, disk, process, and duration budgets;
- scoped SF-601 brokered-credential injection without audit persistence of
  credential bytes;
- safe resource, tool, egress, and violation observations;
- quarantine on escape attempts, policy drift, unauthorized egress, hostile
  repository drift, or resource exhaustion;
- bounded retention and complete destruction proof;
- durable request intent, terminal result, restart replay, and uncertainty
  fences.

SF-603 through SF-606 are outside this task. SF-602 does not provision a cloud
workspace provider, add GitHub or issue-tracker integrations, activate hosted
Git rules, qualify Gate G, ratify L2, deploy, or grant L3 authority.

## Acceptance

1. Mutable image tags, untrusted image digests, untrusted repository artifacts,
   provider URIs with embedded credentials, or changed repository identity fail
   before provider access.
2. Workload identity, project, workload, run, and workspace bindings are exact.
3. Only current credential objects proven by the configured live SF-601
   issuing broker and named by exact injection slots reach the provider;
   caller-constructed or restart-detached objects fail closed, and credential
   bytes never enter requests, responses, audit, errors, exception chains, or
   representations.
4. Network is default deny; every egress record is bounded and checked against
   the exact allowlist.
5. Tool invocations and resource use are checked against exact identities and
   budgets.
6. Escape attempts, unauthorized egress, resource exhaustion, image mismatch,
   artifact drift, hostile instruction drift, or creation-policy digest drift
   quarantine the workspace.
7. Retention expiry blocks continued use and requires destruction.
8. Destruction succeeds only with complete provider proof for process,
   network, storage, and injected-secret cleanup.
9. Provider outage or missing terminal audit around create or destroy leaves
   durable uncertainty and blocks further mutation. A read-only provider
   failure with a durable local terminal becomes quarantine and permits
   destruction. A missing inspection terminal remains `inspection-pending`
   while its operation-owner lease is live; only expiry-gated recovery may
   write terminal quarantine, after which destruction is permitted.
10. Restart replay reconstructs active, quarantined, failed-cleanup, destroyed,
    and uncertain workspaces deterministically.
11. Concurrent reuse of one request identity invokes the provider at most once.
12. The ordered Foundation, Component, Integration, Workflow, and Stress ladder
    passes with no unresolved current-scope blocker or required finding.

## Finding Trace

Every correction must trace:

```text
finding
-> SF-602 acceptance clause
-> hosted-workspace threat or declared provider boundary
-> reproduction or invariant
-> smallest coherent correction
-> same-level regression
-> truthful claim after correction
```

## Stop Boundary

Close and push SF-602 separately. Do not begin SF-603 in this work item.
