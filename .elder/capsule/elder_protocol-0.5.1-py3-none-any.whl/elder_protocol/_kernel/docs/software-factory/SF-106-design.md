# SF-106 Event Journal And Projections Design

**Status:** VERIFIED

**Implementation:** VERIFIED FOR DECLARED LOCAL SCOPE

**Design review:** ACCEPTED - THREE INDEPENDENT READY VERDICTS

**Implementation review:** ACCEPTED - TWO INDEPENDENT READY VERDICTS

**Design date:** 2026-08-11

**Implementation branch:** `work/sf-106-event-journal-projections`

**Base revision:** `b4f9cee5d03f23a3d3bb8d9c79375d2cd853f9fd`

**Activation:** `activation-elder-protocol-2e4c5cb5b5fbc991`

**Change class:** `internal-code`

## Outcome

SF-106 adds one append-only, globally ordered operations journal and rebuildable owner/API read
models over the durable SF-100 through SF-105 operations store.

The journal must:

- append the exact normalized source fact in the same SQLite transaction as the canonical
  operations-store mutation;
- retain one store-global internal sequence, cursor generation, previous-entry digest, and
  current tip;
- reject a duplicate source identity whose bytes, digest, or semantic bindings changed;
- preserve actor, source, correlation, causation, idempotency, redaction, and source-record
  provenance;
- expose a separate contiguous SF-003 public-event stream only where a ratified public event
  type and all required payload fields exist;
- retain internal source facts for projection replay without silently extending SF-003;
- reject secret-shaped fields, common secret values, and forbidden secret references before
  storage;
- fail closed on a gap, changed entry, broken hash link, invalid source record, incompatible
  schema version, or cursor from the future.

The projection runtime must:

- consume the journal in global sequence order;
- update owner/API read models and the projection checkpoint atomically;
- recover after interruption without skipping or applying one entry twice;
- rebuild into a separate projection generation;
- compare record counts and deterministic projection digests before activation;
- leave the current active generation available while a replacement generation is rebuilding;
- stop at the first corrupt or unsupported entry and expose the exact failure position;
- never mutate canonical source records, Elder authority, worker state, maturity, or release
  state.

The maximum truthful claim is a restart-safe local single-process mechanism using the existing
SQLite operations store. SF-106 does not create a hosted stream, broker, distributed consumer,
multi-tenant event service, owner API, UI, authentication layer, external event delivery,
production retention policy, or Postgres implementation.

## Governed Intake

```text
Objective:
  Add append-only operational truth and rebuildable read models for the local Phase 1 kernel.

Affected users:
  The future SF-107 owner API, local operators, product owners inspecting current work, and
  developers verifying restart and migration behavior.

Success:
  Every supported committed SF-100 through SF-105 mutation has one exact journal source fact;
  projections can be rebuilt deterministically to the same logical rows and digest; duplicate,
  partial, corrupt, secret-bearing, stale-cursor, and future-cursor paths fail closed.

Failure:
  A source mutation commits without its required journal fact; a journal fact exists without
  the source mutation; projection replay skips, duplicates, reorders, or silently repairs a
  fact; public events exceed the ratified SF-003 registry; a projection becomes authority.

Constraints:
  Windows 11, Python standard library, SQLite WAL and FULL synchronous durability, one local
  process, current operations.db, exact SF-002/SF-003/ADR-0021 boundaries, canonical L1.

Non-goals:
  SF-107 HTTP/API transport, hosted pubsub, Postgres, multiple writers, external subscriptions,
  decision/schedule/incident implementations not yet present, provider events as authority,
  journal compaction, event deletion, or public-contract expansion.

Risk:
  High. Journal omission, false atomicity, replay divergence, secret persistence, or cursor
  ambiguity would undermine the operations store and later API/migration claims.

Authority:
  Factory operations owns the journal and projections. Product and Elder source authority does
  not move. Projection checkpoints are internal offsets with no authority effect.

Capability packs:
  core, factory-operations, data, assurance, agentic.

Knowledge sources:
  executable SF-100 through SF-105 stores; factory-domain and factory-contract validators;
  ADR 0021 and accepted operational architecture; SF-003 event and cursor contracts; SF-004
  restart/cursor spike; Elder replay and telemetry patterns.

Open questions:
  None that require a protected-contract change. Internal journal facts remain implementation
  records rather than SF-002 Event entities, and public events retain a separate SF-003 cursor
  stream.

Next proof gate:
  Independent design review with no unresolved Critical or High finding before implementation.
```

## Truth And Authority

Truth order remains:

1. canonical SF-100 through SF-105 source rows and immutable histories;
2. exact transactionally appended journal source facts and their hash chain;
3. rebuildable projections;
4. live/public event delivery.

The journal is authoritative for the fact that a committed operations mutation occurred in a
particular global order. It does not become the authority for product intent, Elder authority,
governed checkpoints, learning, qualification, autonomy, or provider-native state.

Projection rows are disposable read models. A projection row can answer a query but cannot:

- complete or fail a command, run, or work item;
- authorize a transition;
- create a decision or outcome;
- accept a checkpoint into Elder;
- approve or promote learning;
- merge, release, deploy, or change maturity.

No consumer may infer canonical completion from a live event, projection row, projection
checkpoint, or external delivery acknowledgement.

## Contract Layering Decision

SF-002 defines `Event` with `worker-report-only` mutation policy and bounded writer roles.
SF-003 defines 23 exact provider-neutral `factory-event` types for worker, governance,
integration, and later API transport.

Those are related but not identical layers:

- every SF-106 journal entry is an internal operations-store source-fact record, not an SF-002
  Event entity;
- each entry carries one exact projection document and source-row binding;
- only entries with an exact mapping and complete payload in the ratified SF-003 registry create
  a separate public `factory-event` row;
- internal-only fact types are never passed to `validate_factory_event_data()` and are never
  claimed as new SF-003 events;
- public events have their own event ID, project stream, and contiguous public-event sequence;
- every public event binds its internal source entry ID and digest through an implementation
  extension;
- a public cursor never points at an internal-only fact.

This avoids inventing work-item, product, transition, workspace, or artifact event types in the
ratified `1.0.0` SF-003 contract. A future public event expansion requires a side-by-side contract
version, compatibility evidence, ADR refresh, and human approval. SF-106 does not make that
change.

The journal records both:

- the source actor who caused or requested the canonical mutation; and
- the factory-journal recorder identity that normalized and appended the internal fact.

The internal fact does not transfer Event writer authority to the source actor. SF-106 does not
create an SF-002 `Event` entity. Its public rows are SF-003 transport/journal contract documents
only. A future bridge into the SF-002 Event entity model requires separately ratified role,
writer, payload, and semantic-adapter authority.

## Component Topology

```text
SF-100 through SF-105 mutation service
        |
        | same sqlite connection and transaction
        v
journal append port
        |
        +--> immutable source-fact entry
        +--> global stream tip and hash chain
        +--> optional separate SF-003 public-event row and project cursor
        |
        v
projection worker
        |
        +--> owner summary projection
        +--> signal projection
        +--> work-item projection
        +--> transition projection
        +--> command/dispatch projection
        +--> run/session/workspace projection
        +--> correlated timeline projection
        |
        v
SF-107 query and event APIs
```

Dependency direction:

```text
mutation services -> journal append port
projection runtime -> journal reader
projection queries -> active projection generation
SF-107 -> projection queries and journal event reader
```

Forbidden:

```text
journal -> mutation service methods
projection reducer -> canonical source-table mutation
source mutation -> asynchronous best-effort journal write
public event -> canonical command or lifecycle completion
projection reset -> journal reset
provider event -> direct canonical journal append without normalization
```

The low-level append port must not import product registry, signal intake, ledger, transition,
dispatcher, or run-controller classes. This prevents an import cycle and keeps the same-transaction
append path small.

## Journal Source Registry

The implementation adds these machine-readable files under `factory/operations/`:

- `journal-source-registry.schema.json`;
- `journal-source-registry.json`;
- `journal-mutation-coverage.schema.json`;
- `journal-mutation-coverage.json`;
- `operations-journal-entry.schema.json`;
- `operations-journal-cursor.schema.json`;
- `public-event-mapping.schema.json`;
- `public-event-mapping.json`;
- `projection-registry.schema.json`;
- `projection-registry.json`;
- `projection-page-token.schema.json`;
- `projection-query-result.schema.json`;
- `factory-capability-status.schema.json`.

The source registry is a versioned object with `version`, `registry_id`, `sources`, and
`content_sha256`. Each source entry pins:

- source component;
- immutable source kind;
- allowlisted table, exact primary-key columns, source identity and version fields;
- ordering family ID, ordering subject-key extractor, ordering mode, and normalized ordering
  version;
- canonical row extractor and row-digest domain;
- normalizer ID and version;
- within-transaction append order;
- occurred-time extraction;
- normalized projection-document schema;
- internal fact type and supported fact versions;
- source actor, correlation, causation, and idempotency extraction;
- redaction classification;
- optional public-event mapping ID;
- reducer IDs that consume or intentionally ignore the fact.

The registry schema forbids undeclared properties. Registry validation recomputes the canonical
digest, validates every referenced schema and reducer ID, verifies table and key columns against
the live SQLite schema, and rejects a mutable source table.

Every source entry selects exactly one ordering mode:

- `contiguous`: a positive integer version must start at `1` for the ordering subject and increase
  by exactly one;
- `singleton`: the stable source identity is its own ordering subject and normalized ordering
  version is always `1`.

No nullable normalized ordering version exists. Native nullable versions remain source payload
fields but are not used as journal ordering versions.

Phase 1 ordering rules are:

| Source family | Ordering subject | Mode/version |
|---|---|---|
| product revisions | product factory ID | `contiguous` revision number |
| signal revisions | signal ID | `contiguous` record version |
| work-item history | work item ID | `contiguous` record version |
| stage transitions | transition ID | `singleton` / `1` |
| terminal hooks | hook ID | `singleton` / `1` |
| dispatch history | dispatch ID | `contiguous` record version |
| dispatch dead letters | dead-letter ID | `singleton` / `1` |
| product workspace policies | product factory ID | `singleton` / `1` |
| run initial bindings | run ID | `singleton` / `1` |
| run/session/workspace histories | their entity ID | `contiguous` record version |
| lifecycle commands | command ID | `singleton` / `1` |
| lifecycle command results | command ID | `contiguous` result version |
| command authorizations | authorization stable identity | `singleton` / `1` |
| Elder observations | run ID | `contiguous` observation version |
| external-step history | external-step ID | `contiguous` step version |
| checkpoint references | reference ID | `singleton` / `1` |
| artifact references | reference ID | `singleton` / `1` |

Rejected stage transitions can therefore retain nullable observed/resulting work-item versions
without making their own journal ordering version nullable. Work-item version order remains owned
by `work_item_history`.

Required Phase 1 source families:

| Component | Immutable source | Required projection effect |
|---|---|---|
| SF-100 | `product_factory_revisions` | product summary and product history |
| SF-101 | `signal_revisions` | signal summary and correlated timeline |
| SF-102/SF-103 | `work_item_history` | current work-item summary and accepted-intent history |
| SF-103 | `stage_transitions` | accepted/rejected transition history |
| SF-103 | `work_item_terminal_hooks` | terminal dispatch intent |
| SF-104 | `dispatch_history` | command/dispatch status |
| SF-104 | `dispatch_dead_letters` | dead-letter detail |
| SF-105 | `factory_product_workspace_policies` | product workspace-policy view |
| SF-105 | `factory_run_initial_bindings` | immutable run lineage |
| SF-105 | `factory_run_history` | current run summary |
| SF-105 | `factory_worker_session_history` | current session summary |
| SF-105 | `factory_workspace_history` | current workspace summary |
| SF-105 | `factory_run_lifecycle_commands` | lifecycle command identity |
| SF-105 | `factory_run_lifecycle_command_results` | lifecycle command result |
| SF-105 | `factory_run_command_authorizations` | authorization evidence linkage |
| SF-105 | `factory_run_elder_observations` | Elder reconciliation timeline |
| SF-105 | `factory_run_external_step_history` | SF-103 cross-store reconciliation |
| SF-105 | `factory_run_checkpoint_refs` | checkpoint observation timeline |
| SF-105 | `factory_run_artifact_refs` | artifact timeline |

Mutable current tables are not journal sources. `work_item_revisions` is specifically excluded
because its lifecycle fields are updated when a revision is superseded. Its accepted intent and
current-revision state are taken from immutable `work_item_history` snapshots.

The normalized projection document may include a validated snapshot copied from the registered
immutable row so replay never depends on a later mutable current row.

One internal journal fact is appended per registered immutable source row, not per logical
method call. A logical mutation that creates multiple immutable rows appends one ordered fact
batch. Every fact in the batch carries:

- one deterministic transaction ID;
- a one-based transaction position;
- the transaction fact count;
- the source-registry append order.

For example, `bind_start` produces separate facts for its policy, command, authorization,
binding, run history, session history, workspace history, Elder observation, and result rows.
The registry fixes their intra-transaction order.

### Executable mutation coverage

The mutation-coverage registry is independent of the source registry. It is a versioned,
digest-bound inventory of every Phase 1 public mutation boundary and every branch that can commit
new canonical bytes:

| Component | Mutation boundaries |
|---|---|
| SF-100 | `register`, `update`, `activate`, `pause`, `archive` |
| SF-101 | `ingest`, including accepted, rejected, duplicate, and conversion branches |
| SF-102 | `create`, `create_from_signal`, `update` |
| SF-103 | `apply`, including accepted and persisted-rejection branches |
| SF-104 | `submit`, `claim_next`, `claim_reconciliation`, `renew`, `begin_execution`, `record_response`, `mark_uncertain`, `cancel`, `shutdown_owner`, lease recovery, retry, and dead-letter branches |
| SF-105 | `bind_start`, `record_elder_observation`, `apply`, `prepare_work_item_start`, `mark_work_item_start_uncertain`, `confirm_work_item_start`, `record_checkpoint_reference`, and `record_artifact_reference` |

Each coverage row pins:

- module, class, method, branch ID, and change kind;
- each direct or helper-mediated write-site ID;
- current-table writes and immutable source rows created by that branch;
- required source-registry IDs in exact append order;
- conditional cardinality as an exact integer or a bounded expression over validated inputs;
- exact-replay behavior;
- whether the branch commits no new canonical bytes;
- mutation-identity field paths and digest recipe;
- crash-injection labels before source writes, after each source family, after journal append, and
  before commit.

The exact coverage-entry shape is:

```text
branch_id
entrypoint {module, class, method}
predicate_id
write_sites[] {
  site_id
  helper_call_path[]
  sql_operation
  table_expression
  resolved_tables[]
  current_table
  immutable_source_ids[]
  source_cardinality
}
no_new_bytes_predicate
mutation_identity {field_paths[], digest_domains[]}
crash_points[]
```

Dynamic helper writes are never represented by an unresolved wildcard. For example,
`RunController._persist_current_entities -> _history_insert` must enumerate the run, session, and
workspace current/history table pairs, and `RunController._history_insert(table=...)` must list
every allowed resolved table.

The required branch families and source cardinalities are:

| Branch family | Required immutable source receipts |
|---|---|
| `product.register`, `product.update`, `product.activate`, `product.pause`, `product.archive` | exactly one `product_factory_revisions` |
| `signal.ingest.accept`, `signal.ingest.reject`, `signal.ingest.deduplicate` | exactly two `signal_revisions`: `receive`, then final disposition |
| `work-item.create`, `work-item.update` | exactly one `work_item_history` |
| `work-item.create-from-signal` | exactly one `work_item_history` and one `signal_revisions` conversion row |
| `transition.apply.rejected` | exactly one `stage_transitions` |
| `transition.apply.recorded.nonterminal` | one `work_item_history`, then one `stage_transitions` |
| `transition.apply.recorded.terminal` | one `work_item_history`, one `stage_transitions`, and one `work_item_terminal_hooks` |
| `dispatch.*` committing branch | exactly one `dispatch_history`, plus exactly one `dispatch_dead_letters` only for a dead-letter branch |
| `run.bind-start` | one policy when newly created, one initial binding, two run-history rows, one session-history row, one workspace-history row, one lifecycle command, one result, all command authorizations, and one Elder observation |
| `run.lifecycle.*` committing branch | one lifecycle command when new, all command authorizations when new, exactly one result version, and the exact run/session/workspace history rows selected by the validated transition mapping |
| `run.work-item-start.*` committing branch | one external-step history row plus the lifecycle/result/history rows selected by the exact phase branch |
| `run.elder-observation` | exactly one Elder observation |
| `run.checkpoint-reference` | one checkpoint reference plus the exact same-state session-history row |
| `run.artifact-reference` | exactly one artifact reference |

Every operation-specific SF-104 and SF-105 subbranch is a separate registry row even when this
table groups it with `*`. A registry schema rejects wildcard branch IDs and wildcard table names;
the grouping above is explanatory only.

The mutation-coverage registry also contains one reserved non-live branch:

```text
branch_id = journal.backfill.snapshot
change_kind = existing-store-backfill
entrypoint = JournalInitializer.append_backfill_snapshot
canonical_source_writes = none
source_set = complete registered immutable snapshot
```

No live mutation may select this branch.

Foundation validation derives an independent write inventory from the declared SQLite DDL,
known current/history table pairs, an AST call graph, literal SQL, and enumerated dynamic-helper
arguments. Component fixtures execute every coverage branch with SQLite trace capture and compare
the actual current/source table write set and trigger receipts to the registry. Validation fails
when a mutation boundary, helper write site, committing branch, current-table write, immutable
source table, cardinality rule, or source-registry ID is absent. Mutation tests also delete or
alter each coverage row in turn and prove validation fails. The source registry is never the only
completeness oracle.

## Public Event Mapping

The public-event mapping registry is exact and defaults to disabled. Every enabled mapping pins:

- one source-registry ID and source operation;
- required prior-source predicate, if the event represents a state transition;
- exact payload field JSON pointers and value transforms;
- source plane, source component, actor extraction, correlation, causation, and idempotency rules;
- deterministic event identity domain;
- one-to-one uniqueness key;
- the exact SF-003 event type;
- fixtures proving complete payload construction and negative predicates.

The initial enabled mapping is intentionally narrow:

| Source row and exact predicate | Public event | Uniqueness |
|---|---|---|
| `signal_revisions`, operation `accept`, resulting status `accepted` | `integration.signal.accepted` | one event per signal revision identity |

The mapping extracts `signal_id` and the validated opaque source reference directly from the
accepted signal revision. It requires the accepted integration idempotency key and validates the
complete event through `validate_factory_event_data()` before either row commits.

All command, session, and run mappings remain disabled in the initial registry until their exact
source operation, transition predicate, and required payload fields are proven. In particular:

- `dispatch_history` is the only possible command-lifecycle source; `dispatch_dead_letters`
  cannot emit a second event for the same lifecycle outcome;
- a session or run history row may emit only on an allowlisted actual status transition, never
  on checkpoint, artifact, or same-state history;
- SF-104 pre-binding delivery is not canonical `command.delivered`;
- no error code, outcome, worker reference, waiting reason, cancellation reason, checkpoint
  cursor, or reconciliation reference is inferred from unrelated fields.

`decision.requested`, `decision.resolved`, and `integration.decision.accepted` remain reserved
until their canonical source components exist. SF-106 must not synthesize those records.

An additional mapping may be enabled only by changing the implementation-owned mapping registry,
adding positive and negative fixtures, proving one-to-one identity, and rerunning Foundation
through Workflow. If the source does not contain every required field, the state change remains
internal only.

Product, work-item, transition, workspace, policy, checkpoint-reference, artifact-reference, and
reconciliation facts are internal journal entries only. They remain queryable through
projections and the correlated timeline but are not mislabeled as one of the 23 public events.

## Journal Entry Contract

The internal journal-entry document contains:

```text
version
stream_id
generation
sequence
entry_id
previous_entry_sha256
entry_sha256
transaction_id
transaction_position
transaction_fact_count
source_append_order
coverage_branch_id
mutation_identity_sha256
fact_type
project_id
subject_type
subject_id
subject_version
operation
occurred_at
recorded_at
source_actor
recorded_by
source
correlation_id
causation_id
idempotency_key
redaction
source_record
projection_document_sha256
projection_document
extensions
```

`operations-journal-entry.schema.json` is versioned `1.0.0`, uses JSON Schema 2020-12, and
forbids unknown fields. It requires:

- generation and sequence integers of at least `1`;
- `transaction_position` and `transaction_fact_count` as positive integers with position no
  greater than fact count;
- `source_append_order` as a non-negative integer;
- transaction, coverage-branch, and mutation-identity fields as bounded identifiers/digests;
- entry, project, subject, correlation, stream, actor, component, source, and operation IDs as
  bounded non-empty strings with their declared identifier patterns;
- subject/source versions as positive integers;
- `previous_entry_sha256` null only at sequence `1`, otherwise a lowercase 64-hex digest;
- `entry_sha256`, source digests, and projection digest as lowercase 64-hex values;
- `occurred_at` and `recorded_at` as date-time strings;
- nullable causation and idempotency IDs with explicit bounds;
- closed typed `source_actor`, `recorded_by`, `source`, `redaction`, and `source_record` objects;
- a schema-bound `projection_document`;
- only `x-elder-*` namespaced extension keys with JSON values that pass secret scanning.

`source_record` contains the source component, table/kind, stable key, record version, record
digest, and immutable-row digest. It never contains a database path or SQL statement.

The append integration contract is:

```python
begin_mutation(
    connection: sqlite3.Connection,
    *,
    coverage_branch_id: str,
    identity_source: MutationIdentitySource,
) -> JournalMutationContext

append_pending_sources(
    connection: sqlite3.Connection,
    *,
    recorder: JournalRecorder,
    recorded_at: str,
) -> JournalAppendResult
```

Both operations require `connection.in_transaction` and never begin, commit, roll back, close, or
replace the caller's connection. The caller does not supply a mutation ID.

`begin_mutation` validates the typed identity source through the branch's pinned schema and
extractor, re-reads the declared current pre-state through the supplied connection, derives the
expected resulting versions, builds the canonical mutation-identity document, computes its
digest and mutation ID, and creates one transactional mutation-context row before any canonical
write. The returned context supplies the derived mutation ID to the service.

All SF-100 through SF-105 services obtain an `OperationsConnection`, a narrow
`sqlite3.Connection` subclass created by the shared operations-store connection factory. Its
`commit()` method refuses to commit when:

- the connection has an active mutation context;
- any pending-source receipt exists for the connection's mutation ID;
- the connection observed a guarded canonical write but no finalized context for that mutation;
- the finalized context counts/digest do not match the journal batch.

The subclass owns only this commit guard and typed SQLite error translation. Mutation services
still issue their own `BEGIN IMMEDIATE`, but direct raw `sqlite3.connect()` and SQL `COMMIT` are
forbidden by the mutation-coverage/AST checks.

The shared connection factory also installs a SQLite authorizer. It denies direct application SQL
against mutation-context and pending-receipt tables. Receipt insertion is allowed only when the
authorizer reports one exact pinned source-trigger name; receipt deletion and context
create/finalize are allowed only while the journal module holds a private connection-local
operation mode. That mode is not accepted as a public argument and is cleared in `finally`.
Unknown trigger names, direct receipt insertion, receipt update, or deletion outside finalization
are denied by SQLite before execution.

Every registered immutable source table has a table-specific `AFTER INSERT` trigger. The trigger:

- requires one active mutation context;
- derives the registered source ID, primary-key values, source version, operation, and stored row
  digest from `NEW` through a registered deterministic canonical-SHA SQLite function;
- inserts one pending-source receipt bound to the active mutation;
- rejects duplicate receipts;
- aborts an immutable-source insert performed without an active context.

Registered mutable current tables also have table-specific `BEFORE INSERT/UPDATE/DELETE` guard
triggers requiring the active context. They do not create journal receipts because immutable
history/source rows carry the replay truth. A canonical current write before `begin_mutation` or
after finalization aborts.

The canonical-SHA function is installed on every operations-store connection before mutation
SQL. A missing function makes the trigger fail closed. The generated trigger SQL and its digest
are pinned by the source registry and verified at readiness.

The context and pending receipts use ordinary operations-store tables, so they share the source
transaction and disappear on rollback. They are not journal truth. A successful
`append_pending_sources` loads the connection's one active context; the caller cannot select a
mutation ID. It marks the context finalized and consumes every pending receipt before
returning; the finalized context remains only as batch-integrity metadata. No public API exposes
receipt mutation. Caller-supplied source references, source bytes, fact bytes, event payloads,
sequence numbers, mutation IDs, and digests are forbidden.

It:

1. verifies journal readiness, the active mutation context, and connection-bound transaction;
2. reloads and recomputes the canonical mutation-identity document and digest from the stored
   context, current pre-state binding, identity source, and expected resulting versions;
3. rejects any mutation ID or identity-digest mismatch;
4. loads the required source IDs and exact order from the coverage branch;
5. loads the trigger-created pending receipts for the mutation;
6. rejects a missing, extra, duplicate, or out-of-order receipt;
7. resolves every source registry entry;
8. re-reads every exact allowlisted source row through that same connection;
9. verifies each re-read key, version, operation, row digest, actor, and command/request binding
   against its pending receipt and mutation identity;
10. canonicalizes each row through its registered extractor;
11. validates every normalized projection document and per-source secret policy;
12. derives the stable source-fact identities;
13. returns existing entries only when the complete ordered batch is an exact replay;
14. rejects a partial or changed replay;
15. allocates one contiguous global sequence range for the batch;
16. derives each deterministic entry ID and hash-chain link in registry order;
17. evaluates exact enabled public-event predicates and validates separate SF-003 rows;
18. inserts every immutable internal entry and optional public event;
19. compare-and-updates the internal and affected public stream tips;
20. finalizes the mutation context and consumes all pending receipts;
21. returns the complete batch without committing.

A caller cannot append an arbitrary syntactically valid fact for a row that does not exist.

`projection_document` is the reducer input. It is:

- normalized, provider neutral, and schema validated;
- bound to the exact source record and entry;
- sufficient for its declared reducers without reading mutable current rows;
- scanned again for secrets before append;
- inline for current Phase 1 internal facts;
- digest-only only when a future source is explicitly classified confidential or restricted and
  supplies a separately immutable retrievable source.

When a public mapping applies, the same source transaction creates one exact SF-003
`factory-event` journal-entry document. It does not create an SF-002 Event entity.

The public event preserves the initiating source actor in its actor field and binds the internal
entry ID and digest through a namespaced implementation extension. It receives a separate public
event ID and public cursor.

## Identity, Ordering, And Hash Chain

The operations store has one internal source-fact stream:

```text
stream_id = factory-operations-<store-id>
generation = 1
sequence = positive contiguous integer
```

The store ID is created once in journal metadata and is never inferred from a filesystem path.

Append occurs under the source transaction's `BEGIN IMMEDIATE` lock. The mutation service calls
`begin_mutation` before its first canonical write and `append_pending_sources` after all
registered immutable source rows have been inserted and before its final commit. Exact replay
branches that create no new canonical bytes do not create a context or append. Composite
mutations finalize the complete trigger-recorded receipt batch once; they do not append
independently per row.

The stable source-fact identity is:

```text
source_component
source_kind
source_id
source_version
operation
```

The live mutation ID is:

```text
mutation-<first 32 hex characters of SHA-256(canonical mutation identity document)>
```

The mutation identity document contains:

- mutation-coverage branch ID and registry digest;
- project ID and primary subject ID;
- validated command/request/idempotency ID when one exists;
- expected current version and resulting version;
- canonical request or transition digest;
- actor identity;
- deterministic operation reason digest when the reason affects canonical bytes.

The coverage registry pins the exact field paths and digest domains per branch. A branch without
an explicit command ID, including product activate/pause/archive, therefore derives identity from
factory ID, trigger, expected/resulting version, actor, reason digest, and canonical request
digest. Wall-clock time, process ID, random UUIDs, connection identity, and filesystem path are
forbidden mutation-identity inputs. Reuse of a mutation ID with different identity bytes is a
hard conflict.

Existing-store backfill has no live mutation context. Its deterministic backfill ID is:

```text
backfill-<first 32 hex characters of SHA-256(canonical_json({
  store_id,
  source_registry_sha256,
  mutation_coverage_sha256,
  source_snapshot_sha256
}))>
```

All facts adopted by that one initialization transaction carry this backfill ID and their
one-based position/count. The canonical JSON object inside the formula is the backfill identity
document, and:

```text
transaction_id = backfill_id
coverage_branch_id = journal.backfill.snapshot
mutation_identity_sha256 = SHA-256(UTF-8(canonical_json(backfill identity document)))
transaction_position = one-based position in deterministic merge order
transaction_fact_count = complete adopted source-row count
source_append_order = source registry value for that fact
```

The private backfill append path recomputes every field from the complete snapshot and rejects a
caller-supplied override.

Exact replay returns the existing entry and does not allocate a new sequence. Reuse with a
different source digest, projection digest, correlation, causation, actor, redaction, or public
event is a conflict.

The journal validates:

- sequence starts at 1 and is contiguous;
- each entry's previous digest equals the prior entry digest;
- entry ID is deterministic and unique;
- entry digest recomputes;
- stream tip matches the last entry;
- recorded time is not earlier than occurred time;
- source versions do not regress for the same subject and source family.

Canonical encoding is the repository `canonical_json` convention: ASCII JSON, sorted keys,
compact separators, and no NaN.

The exact internal hash-chain preimage is the complete schema-valid journal-entry object with the
`entry_sha256` member omitted. It includes `previous_entry_sha256`, stream/generation/sequence,
identity, transaction ID/position/fact count/source append order, coverage branch, mutation
identity digest, actor/provenance, source binding, projection digest/document, redaction, times,
and extensions:

```text
entry_sha256 = SHA-256(UTF-8(canonical_json(entry without entry_sha256)))
```

Sequence `1` has `previous_entry_sha256 = null`. Every later entry includes the immediately prior
entry's exact `entry_sha256`. No indexed column or canonical document field is outside the
preimage.

Identifiers:

```text
entry_id = journal-entry-<first 32 hex chars of SHA-256(canonical identity document)>
public_event_id = event-<first 32 hex chars of SHA-256(canonical public identity document)>
```

The internal identity document contains stream ID, generation, sequence, stable source-fact
identity, transaction ID, and transaction position. The public identity document contains public
stream ID, generation, public sequence, internal entry ID, and public event type. An existing
derived ID with different canonical identity bytes is a hard collision and fails closed.

The SF-003 event contains its own cursor, so the public digest uses an explicit acyclic normalized
view. Construction is:

1. derive event ID, public sequence, and all event fields;
2. set `cursor.snapshot_sha256 = null`;
3. validate that provisional event through `validate_factory_event_data()`;
4. compute the event document digest over that provisional normalized view;
5. compute the public stream-tip snapshot digest from the event document digest;
6. set the final event cursor snapshot to that stream-tip digest;
7. validate the final event again.

The public event document digest is:

```text
event_document_sha256 =
  SHA-256(UTF-8(canonical_json(
    validate_factory_event_data(event_document)
    with cursor.snapshot_sha256 normalized to null
  )))
```

Verification validates the final event, copies it, normalizes only
`cursor.snapshot_sha256` to null, and recomputes the digest. No other field is excluded. The
public stream stores that digest beside the event ID. The public cursor snapshot digest is:

```text
SHA-256(UTF-8(canonical_json({
  "stream_id": stream_id,
  "generation": generation,
  "sequence": sequence,
  "event_id": event_id,
  "event_document_sha256": event_document_sha256
})))
```

The internal stream-tip snapshot uses the analogous exact object with `entry_id` and
`entry_sha256`.

Projection digest is:

```text
SHA-256(canonical_json([
  {"key": <stable projection key>, "content_sha256": <row digest>},
  ...
]))
```

Rows are sorted by UTF-8/ordinal stable projection key. Checkpoint timestamps, activation times,
failure metadata, and generation numbers are excluded from the logical projection digest.

## Cursor Semantics

SF-106 uses two cursor contracts:

- an internal `operations-journal-cursor` for source-fact replay and projection checkpoints;
- the existing `factory/factory-cursor.schema.json` only for separate SF-003 public-event
  streams.

`operations-journal-cursor.schema.json` is versioned `1.0.0`, forbids unknown fields, and requires:

```text
version
stream_id
generation
sequence
entry_id
entry_sha256
snapshot_sha256
issued_at
```

Sequence `0` requires null entry ID and entry digest. A positive sequence requires both. The
snapshot digest is SHA-256 of the canonical internal stream-tip document containing stream ID,
generation, sequence, entry ID, and entry digest.

Initial cursor:

```text
generation = 1
sequence = 0
entry_id or event_id = null
snapshot_sha256 = canonical internal or public stream-tip digest
```

Sequence `0` is a permanent initial sentinel in retain-all mode. The minimum resumable cursor is
therefore sequence `0`, not the first positive event sequence.

Positive internal cursors bind the exact internal entry ID at that global sequence.

Public streams are project-scoped:

```text
project_key = first 32 hex characters of SHA-256(canonical_json(project_id))
stream_id = factory-public-events-<project_key>
generation = 1
sequence = positive contiguous project event sequence
```

Positive public cursors bind the exact public event ID at that public sequence.
`snapshot_sha256` is the digest of the canonical public stream-tip document containing stream ID,
generation, sequence, event ID, and event document digest. It never uses a projection digest.

Reader behavior:

- future generation: reject;
- future sequence: reject;
- changed entry or event ID at an existing sequence: reject;
- older generation: stale;
- sequence before retained minimum: stale;
- current tip: return no entries and the current cursor;
- available range: return ordered entries after the cursor up to the bounded limit.

The public-event reader reads the dedicated public-event rows and never advances over
internal-only facts.

Projection reset never changes journal generation. A generation change is reserved for a
separately validated storage migration or journal replacement and is not implemented in SF-106.

## Causation And Correlation

Every entry carries:

- `project_id`;
- subject type and ID;
- optional product, work item, run, and session correlations;
- one stable correlation ID;
- optional causation ID;
- optional idempotency key;
- source-actor identity and kind;
- factory-journal recorder identity;
- source plane, component, and exact source reference.

Causation points to the most direct durable cause:

- signal acceptance: source event or intake idempotency identity;
- work-item creation from signal: accepted signal ID;
- transition: transition command ID;
- dispatch state: factory command ID;
- run binding: completed SF-104 dispatch ID;
- run lifecycle result: lifecycle command ID;
- SF-103 activation reconciliation: exact transition command ID;
- checkpoint or artifact reference: exact append command ID.

Backfilled facts retain their original causation fields. A missing historical causation field is
recorded as `null`; it is not fabricated.

## SQLite Data Model

Required tables:

### `factory_journal_metadata`

One immutable configuration row:

- schema version;
- journal version;
- source-registry version and digest;
- mutation-coverage registry version and digest;
- public-event mapping registry version and digest;
- projection-registry version and digest;
- factory-domain version and digest;
- SF-003 contract version and digest;
- store ID;
- stream ID;
- generation;
- retention mode;
- architecture decision;
- created time.

### `factory_journal_stream`

One mutable compare-and-update tip row:

- stream ID and generation;
- current sequence;
- current entry ID;
- current entry digest;
- minimum retained sequence;
- record version;
- updated time.

The initial row has current sequence `0`, null current entry ID/digest, and minimum retained
sequence `0`.

### `factory_journal_entries`

Immutable append-only rows:

- global sequence primary key;
- entry ID unique;
- stable source-fact identity unique;
- transaction ID, position, fact count, source append order, coverage branch ID, and mutation
  identity digest;
- project and subject indexes;
- occurred and recorded time indexes;
- fact type;
- previous and current entry digests;
- canonical entry JSON;
- canonical source-row binding and projection document.

Update and delete triggers abort unconditionally.

### `factory_journal_mutation_contexts`

One row per attempted committing mutation:

- mutation ID primary key;
- mutation-coverage branch ID and registry digest;
- canonical mutation-identity JSON and identity digest;
- canonical pre-state key/version/digest binding;
- validated identity-source schema ID and digest;
- state: `active` or `finalized`;
- expected and actual source count;
- final first/last journal sequence and batch digest;
- created and finalized time.

A partial unique index permits only one `active` context. Table-specific immutable-source insert
triggers require that context and create pending receipts. Finalization compare-and-updates the
context from `active` to `finalized`; any later immutable-source insert in the same transaction
then aborts because no active context exists.

### `factory_journal_pending_sources`

Transactional trigger receipts keyed by mutation ID, source-registry ID, source identity, and
source version. Each receipt stores the exact primary-key document, operation, source append
order, and stored row digest derived from `NEW`. No service method may update a receipt. Receipts
are deleted only by the low-level successful batch append before the surrounding transaction
commits; rollback removes both source inserts and receipts.

### `factory_journal_backfill`

One immutable store-wide completion record:

- source-registry digest;
- per-source counts and digests;
- total source row count;
- first and last sequence;
- backfill snapshot digest;
- completed time.

### `factory_journal_state`

One mutable readiness row:

- state: `initializing`, `ready`, or `failed`;
- active source-registry and mutation-coverage digests;
- backfill ID;
- backfill started time;
- record version;
- failure code and failure-detail digest;
- updated time.

The immutable metadata row never changes. No SF-100 through SF-105 mutation may proceed while
the state row is absent or not `ready`.

### `factory_public_event_streams`

One mutable tip per project public stream, with generation, current sequence, event ID, record
version, and update time.

### `factory_public_events`

Immutable exact SF-003 event rows with unique project stream sequence and a foreign-key binding
to the internal journal entry. A unique mapping key prevents two public events for the same
source mapping and lifecycle outcome.

### `factory_projection_definitions`

Pinned projection ID, reducer version, source-registry digest, schema digest, and query contract.

### `factory_projection_generations`

Projection generation state:

- projection ID and generation;
- status: `building`, `active`, `failed`, `superseded`;
- last journal generation, sequence, entry ID, and entry digest;
- expected and actual row count;
- projection digest;
- failure code and sequence;
- created, updated, and activated times.

Only one active generation exists per projection.

### Projection rows

Each projection uses a dedicated table or one strictly typed table family. Every row includes:

- projection ID and projection generation;
- project ID;
- subject ID and optional parent IDs;
- source subject version;
- last journal sequence;
- normalized record JSON;
- content digest;
- updated time.

Rows are mutable only inside the projection reducer transaction. They carry no source authority.

## Initialization And Backfill

SF-106 must support both fresh and existing operations stores through one store-wide migration
gate.

### Fresh store

The operations bootstrap first initializes all SF-100 through SF-105 schemas. It then runs one
SF-106 journal initialization transaction and records an empty store-wide backfill if no source
rows exist.

### Existing store

Journal initialization performs one store-wide `BEGIN IMMEDIATE` backfill:

1. create or compare-and-update the journal state row to `initializing`;
2. enumerate every registered immutable source row;
3. normalize and validate each source fact through same-connection row resolution;
4. compute the complete immutable source snapshot and deterministic backfill ID;
5. normalize every row to `(ordering_family_id, ordering_subject_key, ordering_version)` and build
   one version-order graph whose edges require each `contiguous` version to follow its immediate
   prior version; `singleton` rows have no predecessor edge;
6. deterministically merge only currently eligible graph heads by source occurred time,
   source-registry append order, source kind, source identity, and source version;
7. append exact facts through the initialization-only backfill path;
8. compute per-source and complete journal-adoption digests;
9. compare every enumerated source count immediately before commit;
10. write the immutable store-wide completion record;
11. set the journal state row to `ready`;
12. commit all source facts and the readiness gate atomically.

The normal live append path requires journal state `ready` and rejects `initializing`.
`append_backfill_snapshot()` is a separate private operation available only while the same
connection owns the initialization transaction and state is `initializing`. It accepts no caller
selected subset: it re-enumerates the complete registered source snapshot, verifies the backfill
ID, order graph, counts, and snapshot digest, then appends that complete set. It cannot be called
after readiness.

The per-subject version edges take precedence over timestamps. A later source version can never
appear before an earlier version even when its stored occurrence timestamp is earlier. An
existing-store fixture must include deliberately out-of-order timestamps.

For `contiguous` families, a missing version `1`, gap, duplicate normalized version, ambiguous
subject key, or non-positive version fails initialization. For `singleton` families, duplicate
stable identity fails. Any graph cycle or unconsumed row after deterministic merge fails
initialization. The normal append validator applies the same normalized ordering rules and
rejects regression or a skipped contiguous version.

The source registry pins two time fields separately:

- `source_occurred_at`: the immutable source's canonical operation timestamp, retained in the
  projection document;
- `entry_occurred_at`: the immutable source-row creation/adoption timestamp used by the journal.

For backfill, each `recorded_at` is
`max(backfill_started_at, entry_occurred_at)`; the one `backfill_started_at` value is stored in
journal state before enumeration and reused on retry from `failed`. For live append,
`recorded_at = max(append_started_at, entry_occurred_at)`. Public event occurrence uses the
canonical factory acceptance/transition time selected by its mapping, not an untrusted external
payload timestamp. This preserves `recorded_at >= occurred_at` without silently replacing the
external source occurrence retained in the projection document.

If the process exits before commit, no partial backfill is visible. Exact rerun is idempotent.
Changed source bytes or changed source-registry bytes fail closed.

On a deterministic initialization failure, the backfill transaction first rolls back. A separate
short transaction then records `failed` with the registry digests, failure code, and detail
digest. If the process exits before that failure record commits, the state remains absent and all
mutations still fail closed; the next initialization attempt starts from a clean store.

Global backfill ordering is independent of operator timing because no component mutation can
start until the one store-wide readiness gate commits. Original `occurred_at` remains available
for historical chronology. Global sequence represents deterministic journal adoption order, not
a fabricated claim that old cross-component writes were observed in that order.

## Same-Transaction Integration

Every supported mutation must call the append port before its transaction commits, passing the
exact current `sqlite3.Connection`. The append port never opens another database connection.

Adding this requirement is an explicit cross-cutting transaction refactor across SF-100 through
SF-105. Each existing mutation path retains ownership of its transaction and passes that
connection to source-row verification and ordered fact append.

Every mutation service receives one `JournalAppendPort` dependency. The default production port
is required after SF-106 schema initialization; tests may inject only a contract-conforming port.
There is no `None`, no-op, exception-swallowing, or post-commit implementation.

Each committing branch follows this exact shape:

```text
BEGIN IMMEDIATE
require journal state == ready
validate command and replay identity
context = begin_mutation(the same connection, coverage branch ID, typed identity source)
write current and immutable source rows
append_pending_sources(the same connection)
optional deterministic crash injection: after-journal-before-commit
COMMIT
```

`COMMIT` above means `OperationsConnection.commit()`. Schema initialization, projection
transactions, backup reads, and restore verification use explicit connection modes whose table
allowlists do not permit SF-100 through SF-105 canonical mutation writes.

Crash-injection labels are test-only hooks that raise a typed exception. They cannot alter source
bytes or journal behavior.

This includes accepted state changes, persisted rejections, duplicate dispositions that create a
new canonical row, dead letters, uncertain states, reconciliation results, checkpoint
references, and artifact references.

It excludes:

- validation failures before a transaction begins;
- exact idempotent replay that returns an existing source record;
- read operations;
- projection updates;
- live delivery acknowledgements that are not canonical operations facts.

If journal validation or insertion fails, the source transaction rolls back. There is no
best-effort fallback, post-commit repair queue, or second database transaction.

## Projection Definitions

Phase 1 requires these active projections:

| Projection | Key | Owner/API use |
|---|---|---|
| `products` | product factory ID | product list, status, repository/profile binding |
| `signals` | signal ID | intake state, source, duplicate/conversion linkage |
| `work-items` | work item ID | owner-visible current stage, revision, priority, blockers |
| `transitions` | transition ID | accepted/rejected stage history and authority references |
| `commands` | command/dispatch ID | durable command, attempts, uncertainty, lease and terminal state |
| `runs` | run ID | run, session, workspace, cleanup, reconciliation, checkpoint and artifact summary |
| `timeline` | journal sequence | correlated ordered facts across all supported subjects |

The source registry declares which fact types reduce into each projection.

Reducers are deterministic pure functions over:

```text
current projection row or null
journal entry
projection definition version
```

They cannot query mutable current source rows. They may validate immutable source references
already embedded in the entry.

## Projection Worker

The local worker is an explicit application service, not a background daemon.

Required operations:

```text
project_once(projection_id, generation, limit)
project_until_current(projection_id, generation, batch_size)
rebuild_projection(projection_id)
verify_projection(projection_id)
activate_projection(projection_id, generation)
```

One batch:

1. opens `BEGIN IMMEDIATE`;
2. loads and validates the generation checkpoint;
3. reads the next bounded contiguous journal range;
4. validates every entry and its hash link;
5. applies each reducer exactly once;
6. recomputes changed row digests;
7. advances checkpoint to the last processed entry;
8. commits rows and checkpoint atomically.

A process exit before commit leaves neither rows nor checkpoint advancement. A rerun starts from
the prior checkpoint.

The worker records a deterministic failure code and failing sequence when it encounters corrupt
or unsupported input. The projection-row/checkpoint batch first rolls back completely. A new
short `BEGIN IMMEDIATE` transaction then compare-and-updates the still-building generation from
its prior record version to `failed`, recording only the failure code, failing sequence, and
detail digest. It does not advance past the failure. If the process exits before that second
transaction commits, the generation remains `building`; the next worker invocation encounters
the same entry, rolls back again, and records the same deterministic failure.

## Rebuild, Reset, And Activation

Rebuild never destroys the active projection generation first.

1. create generation `N + 1` with status `building` and cursor sequence `0`;
2. replay the complete retained journal into generation `N + 1`;
3. verify journal tip, row counts, row digests, projection digest, and reducer version;
4. when the current active generation is at the same journal tip, require digest equality;
5. open `BEGIN IMMEDIATE`, re-read the current journal tip and building checkpoint, and abort if
   either differs from the verified tip;
6. recompute the activation metadata digest inside that transaction;
7. atomically mark the old generation `superseded` and the new generation `active`;
8. retain the superseded generation until a separately explicit cleanup operation.

Initial activation has no old digest to compare, so it requires a second isolated replay
execution against the same immutable journal plus independent expected-output fixtures. The
isolated execution must not import or call the persisted reducer entry points.

Digest equality proves deterministic replay only. Semantic correctness is established separately
by source-family oracle fixtures that state the exact expected projection rows and intentional
no-op reducers for every fact type. Tests compare persisted rows to those fixtures and reconcile
projection keys and source versions directly against the immutable source facts.

Golden oracle files live under `tests/fixtures/sf106/golden/`:

```text
fixture-manifest.schema.json
<fixture-id>/
  manifest.json
  source-rows.json
  journal-entries.json
  expected-products.json
  expected-signals.json
  expected-work-items.json
  expected-transitions.json
  expected-commands.json
  expected-runs.json
  expected-timeline.json
  expected-public-events.json
```

Each manifest pins fixture ID/version, purpose, source-family IDs, coverage branch IDs, input and
expected-file digests, authored-by identity, independently-reviewed-by identity, review date, and
the design revision. Golden expected files are hand-authored review artifacts. Production
normalizers, reducers, query code, fixture generators, and runtime snapshots are forbidden from
writing or regenerating them; tests reject a manifest with matching author/reviewer identity.

Required composite fixtures include:

- accepted signal then work-item conversion;
- accepted and rejected transitions, including terminal hook creation;
- dispatch success, uncertainty, retry exhaustion, and dead-letter ordering;
- run bind-start across policy/binding/run/session/workspace/command/authorization/result and
  Elder observation;
- lifecycle transition across run/session/workspace histories;
- work-item start preparation, uncertainty, and confirmation;
- same-state checkpoint history plus checkpoint reference;
- artifact reference;
- internal-only facts surrounding one public event without moving the public cursor twice.

Projection-specific invariants are checked independently of expected row bytes:

- products: one latest revision per factory and no status/version regression;
- signals: one latest signal state with exact duplicate/conversion linkage;
- work items: one latest accepted history version and exact dependency/source links;
- transitions: one row per transition command and exact terminal-hook relation;
- commands: one latest dispatch history tip, contiguous attempts, and at most one dead letter;
- runs: run/session/workspace versions and cleanup/reconciliation summaries agree;
- timeline: every journal entry appears exactly once in global order;
- public events: every enabled mapping appears exactly once and disabled mappings appear zero
  times.

`reset` means create a new building generation. It never deletes journal entries, rewinds the
global stream, changes the cursor generation, or edits canonical source rows.

## Query Contract

SF-106 exposes Python query methods for SF-107, not HTTP endpoints.

Queries read only the active projection generation and include:

- stable sort order;
- bounded limit;
- opaque continuation token bound to projection ID, projection generation, projection digest,
  journal generation and tip, canonical filter digest, sort definition, page size, and last key;
- project filter;
- optional status, subject, work item, run, and correlation filters;
- projection generation, journal tip, and projection digest in query metadata.

Required methods:

```python
list_products(*, project_id, status=None, limit=100, continuation=None) -> QueryPage
get_product(*, project_id, factory_id) -> QueryRecord
list_signals(*, project_id, status=None, limit=100, continuation=None) -> QueryPage
get_signal(*, project_id, signal_id) -> QueryRecord
signal_history(*, project_id, signal_id, limit=100, continuation=None) -> QueryPage
list_work_items(*, project_id, status=None, limit=100, continuation=None) -> QueryPage
get_work_item(*, project_id, work_item_id) -> QueryRecord
work_item_history(*, project_id, work_item_id, limit=100, continuation=None) -> QueryPage
list_transitions(*, project_id, work_item_id=None, limit=100, continuation=None) -> QueryPage
get_transition(*, project_id, transition_id) -> QueryRecord
list_commands(*, project_id, status=None, limit=100, continuation=None) -> QueryPage
get_command(*, project_id, command_id) -> QueryRecord
command_history(*, project_id, command_id, limit=100, continuation=None) -> QueryPage
list_runs(*, project_id, status=None, limit=100, continuation=None) -> QueryPage
get_run(*, project_id, run_id) -> QueryRecord
run_history(*, project_id, run_id, limit=100, continuation=None) -> QueryPage
timeline(*, project_id, subject_id=None, correlation_id=None, limit=100, continuation=None) -> QueryPage
read_public_events(*, project_id, cursor, limit=100) -> PublicEventPage
get_public_event(*, project_id, event_id) -> QueryRecord
list_decisions(*, project_id, limit=100, continuation=None) -> CapabilityUnavailable
get_decision(*, project_id, decision_id) -> CapabilityUnavailable
get_projection_status(*, projection_id=None) -> ProjectionStatus
get_journal_status() -> JournalStatus
get_capability_status() -> FactoryCapabilityStatus
```

Limits are integers from 1 through 500. Unknown filters and empty required identifiers fail
validation.

Exact ascending sort keys are:

| Query | Sort tuple |
|---|---|
| products | `(project_id, factory_id)` |
| signals | `(project_id, received_at, signal_id)` |
| signal history | `(project_id, signal_id, source_version)` |
| work items | `(project_id, updated_at, work_item_id)` |
| work-item history | `(project_id, work_item_id, source_version)` |
| transitions | `(project_id, recorded_at, command_id)` |
| commands | `(project_id, updated_at, dispatch_id)` |
| command history | `(project_id, dispatch_id, source_version)` |
| runs | `(project_id, updated_at, run_id)` |
| run history | `(project_id, run_id, journal_sequence, source_kind, source_version)` |
| timeline | `(project_id, journal_sequence)` |

The final unique identifier in every tuple is the mandatory tie-breaker.

`projection-page-token.schema.json` is versioned, opaque to callers, base64url-encodes canonical
JSON, and contains projection ID/generation/digest, journal generation/tip, method ID, canonical
filter digest, exact sort ID, page size, and the complete last sort tuple. The token has no expiry
in local Phase 1 but becomes stale on any bound change.

`projection-query-result.schema.json` defines `items`, `continuation`, `projection`, `journal`,
and `query` metadata. A stale token raises typed `StaleProjectionTokenError` with code
`stale-projection-token`, projection ID, expected/actual generation and digest, and
`restart_required=true`. A malformed or cross-method token raises `InvalidProjectionTokenError`;
it is not treated as stale.

Continuation use fails as stale when the active projection generation, projection digest, query
filters, sort definition, or bound journal tip changed. The client must restart from the first
page. SF-106 does not claim snapshot pagination across ongoing writes.

There is no canonical Phase 1 decision source. `list_decisions` and `get_decision` always raise
typed `CapabilityUnavailableError` with code `decision-source-unimplemented`,
`capability=decisions`, `implemented=false`, and `retryable=false`.
`factory-capability-status.schema.json` exposes the same state. SF-107 owns the eventual transport
mapping but must expose that dependency truthfully rather than returning fabricated decision rows
or treating an empty result as implemented capability.

SF-107 owns authentication, authorization, transport pagination, error envelopes, long polling,
and health/readiness policy.

## Integrity And Corruption Behavior

`status()` and `verify()` must check:

- metadata versions and pinned digests;
- required tables, indexes, and immutable triggers;
- source-registry, mutation-coverage, public-mapping, and projection-registry digests;
- store-wide backfill completion and readiness state;
- internal stream sequence, entry identity, and hash-chain continuity;
- public project-stream sequence and event identity;
- entry JSON equality with indexed columns;
- source-record and projection-document digests;
- optional SF-003 event validity;
- checkpoint cursor binding;
- one active generation per projection;
- projection row digests;
- active projection tip not beyond journal tip;
- deterministic projection digest.

Corruption behavior:

- changed or missing journal entry: all replay and readiness fail;
- broken source digest: all replay and readiness fail;
- unsupported fact version: affected projection fails at that sequence;
- corrupt inactive projection generation: that generation fails and cannot activate;
- corrupt active projection: owner queries fail closed until a verified replacement activates;
- projection lag: queries may expose lag metadata, but SF-107 decides readiness requirements;
- no automatic journal repair or event regeneration is allowed.

## Redaction And Secret Safety

The append path runs both source-specific validation and the common recursive secret scan.

Forbidden:

- secret-shaped field names except real digest fields and explicitly non-secret token counters;
- common credential value patterns;
- `secret:`, `vault:`, `keyvault:`, credential, or equivalent references;
- direct personal contact or payment values in stable dimensions;
- provider credentials, environment values, raw prompts, or raw model outputs.

Current Phase 1 source facts use `internal` classification. Public events preserve the exact
SF-003 redaction structure.

Confidential or restricted future facts must be digest-only unless a separately approved
immutable source resolver exists. SF-106 does not introduce that resolver.

## Retention

Phase 1 retention mode is `retain-all`.

- journal entries cannot be deleted or compacted;
- minimum retained sequence remains the permanent sequence-`0` sentinel;
- projections may create and supersede generations but cannot remove the only verified active
  generation;
- explicit cleanup may remove an old superseded projection generation only after another active
  generation is verified;
- backup retention remains an operator policy outside SF-106.

Status reports journal row count, database bytes, WAL bytes, oldest/newest occurrence time,
projection lag, last full replay duration, and last backup size/time. Configurable warning
thresholds affect readiness diagnostics only and never authorize deletion. SQLite `FULL`,
disk-full, I/O, WAL, and backup errors are explicit typed failures; a source transaction rolls
back when its journal append cannot durably complete.

Physical journal retention, legal hold, tiered storage, and compaction require a later hosted
policy and migration design. SF-106 must not imply those controls exist.

## Backup, Restore, And Migration

SF-105 run-controller backup remains unchanged and retains its declared component scope. SF-106
adds a separate operations-store backup coordinator and
`factory/operations/operations-backup-manifest.schema.json` covering:

- journal metadata and stream tip;
- journal state, entries, public streams/events, and store-wide backfill;
- all four implementation-owned registries and their digests;
- projection definitions and generations;
- every projection row table.

The backup manifest must bind:

- schema version;
- journal stream ID, generation, sequence, entry ID, and tip digest;
- source-registry digest;
- mutation-coverage, public-mapping, and projection-registry digests;
- every public project-stream tip;
- active projection generations, row counts, and digests;
- exact SQLite snapshot-file SHA-256;
- logical snapshot SHA-256 over canonical ordered table rows, table names, schemas, indexes, and
  trigger SQL;
- required SQLite settings: `journal_mode`, `synchronous`, `foreign_keys`, `page_size`,
  `application_id`, and `user_version`.

Both digests are computed from the closed temporary SQLite snapshot, never from the changing live
source database. The byte digest proves the backed-up file is unchanged. The logical digest proves
the restored database has the same normalized contents and schema even when a future SQLite copy
has different page layout.

The logical digest enumerates `sqlite_schema` objects by `(type, name)` and normalizes SQL by the
exact stored SQL text. It enumerates each user table by declared primary-key columns in ordinal
SQLite comparison order. A table without a declared primary key is ordered by canonical encoded
full-row bytes plus a one-based duplicate occurrence index. Each value is encoded with an
explicit SQLite storage class (`null`, `integer`, `real`, `text`, or lowercase-hex `blob`) before
canonical JSON hashing. Table names, ordered column definitions, ordered rows, indexes, triggers,
and the required pragma/settings document are all inside one versioned logical-snapshot preimage.

Backup publishes one versioned directory, not two independent files:

```text
<backup-id>.tmp/
  operations.db
  manifest.json
  COMMITTED
```

The coordinator creates the SQLite snapshot, closes and verifies it, computes both digest
domains, writes the manifest, writes `COMMITTED` containing the manifest digest, flushes each
file, and renames the temporary directory to its final name on the same volume. Readers recognize
only a final directory whose commit marker and manifest match. Process interruption therefore
leaves either an ignored temporary directory or one complete recognized backup; SF-106 does not
claim power-loss durability beyond the filesystem and SQLite guarantees.

Restore copies the recognized snapshot into a new temporary database, verifies schema,
registries, source bindings, journal chains, public streams, active projections, and both snapshot
digests, closes it, and only then atomically replaces the target file on the same volume. Any
interruption before replacement leaves the prior target untouched. A restore never writes into an
open operations-store connection.

SQLite-to-Postgres remains unimplemented. SF-106 supplies the local evidence needed by ADR 0021:

- journal-tip and hash equality;
- record-count equality;
- projection-digest equality;
- schema-version equality.

## Concurrency

The current architecture permits one process and one SQLite writer at a time, but multiple
threads or callers may contend.

Required behavior:

- `BEGIN IMMEDIATE` serializes source mutation plus journal append;
- compare-and-update stream tip prevents lost sequence allocation;
- exact concurrent replay creates one entry;
- changed concurrent replay produces one winner and explicit conflict;
- one projection batch owns one projection generation checkpoint at a time;
- two workers cannot both advance the same generation from the same checkpoint;
- journal writes may continue while a projection is behind;
- projection rebuilding never blocks owner queries against the active generation longer than
  the bounded SQLite write transaction.

No distributed lease or broker is claimed.

## Failure Matrix

| Failure | Required result |
|---|---|
| source mutation cannot append journal fact | rollback source mutation |
| exact source-fact replay | return existing entry |
| changed source-fact replay | conflict |
| immutable source insert without active mutation context | trigger aborts source transaction |
| mutable canonical write without active mutation context | guard trigger aborts source transaction |
| existing source row referenced without transaction-local insert receipt | batch mismatch; rollback |
| pending receipts differ from mutation-coverage branch | batch mismatch; rollback |
| caller attempts to provide or substitute mutation ID | validation rejects before canonical write |
| recomputed mutation identity differs from stored context | conflict; rollback |
| direct receipt/context table SQL | SQLite authorizer denies |
| immutable source insert after journal finalization in same transaction | trigger aborts transaction |
| commit attempted with active context or pending receipt | guarded commit rejects and caller rolls back |
| sequence or previous digest mismatch | reject and fail integrity |
| source record digest mismatch | reject and fail integrity |
| secret-shaped projection document | reject before storage |
| unknown source kind or reducer version | reject |
| optional public event violates SF-003 | rollback source mutation |
| process exit before source commit | no source row and no journal row |
| process exit after source commit | source row and journal row both durable |
| projection exit before batch commit | no row or checkpoint advancement |
| projection exit after batch commit | rows and checkpoint both durable |
| projection sees corrupt entry | mark failed at exact sequence; do not advance |
| reset interrupted | old active generation remains queryable |
| rebuilt digest differs at same tip | refuse activation |
| cursor from future | reject |
| cursor from wrong stream | reject |
| stale generation | stale response with snapshot digest |
| public-event cursor at current public tip | empty event list with unchanged current cursor |
| source-registry, mutation-coverage, mapping, or projection digest drift | readiness and mutation fail |
| partial or absent store-wide backfill | readiness and mutation fail |
| entry/event ID collision with different bytes | corruption; rollback |
| duplicate public mapping for one uniqueness key | rollback |
| continuation token after projection change | stale; restart pagination |
| SQLite busy timeout, disk-full, WAL, or journal I/O failure | explicit typed failure; source rollback |
| backup snapshot or manifest publication interrupted | no published partial backup |
| restore verification or replacement interrupted | existing target remains unchanged |
| crash after any source-family write before journal append | whole mutation rolls back |
| crash after complete journal append before commit | source and journal batch both roll back |

## Test Strategy

Run one level at a time with explicit generous timeouts.

Required maximum command runtimes:

| Level | Timeout |
|---|---:|
| Foundation | 15 minutes |
| Component | 45 minutes |
| Integration | 30 minutes |
| Workflow | 30 minutes |
| Stress | 60 minutes |
| protocol/build/isolated-wheel closure | 45 minutes |

These are ceilings, not expected durations. A timeout is a failure with root-cause analysis, not a
skip or implicit retry. Each level's reproduction record captures the exact Python executable
and version, command, commit, branch, start/end timestamps, elapsed seconds, test count, pass/fail
count, every skip and reason, warning policy, timeout, exit code, and failure artifact paths.
Failure artifacts include the smallest retained database/manifest fixture needed to reproduce
the fault and must not contain secrets.

After a failure, only the failed level is rerun after the root cause is fixed. The final evidence
includes both the original failing command/result and the passing reproduction. Levels are not
combined into one opaque command and are not advanced out of order.

### Foundation

- journal-entry, source-registry, projection-definition, projection-checkpoint, and backup schema
  validation;
- exact independent mutation/write inventory coverage for all SF-100 through SF-105 committing
  branches and immutable sources;
- source, mutation-coverage, public-mapping, and projection registry digest and cross-reference
  validation;
- internal cursor, projection page token, query result, and capability-status schema validation;
- exact journal-entry schema, hash-chain preimage, public-event document digest, and stream-tip
  snapshot digest validation;
- transaction batch fields are required in schema/indexed columns/hash preimages;
- public event digest construction proves the cursor snapshot normalization is acyclic and rejects
  any change outside that one normalized field;
- every dynamic helper target and operation-specific branch resolves to a concrete coverage row;
- mutation identity recipes reject random/time/process/path inputs;
- low-level mutation ID derivation recomputes from typed identity source and pre-state rather than
  accepting a caller ID;
- internal/public event boundary;
- deterministic IDs, digests, cursor, and secret rejection;
- immutable trigger and table/index declarations;
- package catalog inclusion.

### Component

- initialize fresh and existing stores;
- deterministic initialization-only backfill and exact backfill replay;
- reserved backfill coverage branch and identity digest populate every required batch field;
- version-preserving backfill with deliberately out-of-order source timestamps;
- contiguous and singleton ordering-family normalization, including nullable native transition
  versions;
- ordering gaps, duplicate versions/identities, ambiguous subjects, and graph cycles fail closed;
- normal append rejects `initializing`, backfill append rejects `ready`, and neither exposes
  partial readiness;
- append, exact replay, changed replay, and hash-chain verification;
- mutation-context and trigger receipts prove transaction-local source inserts;
- missing context, unguarded current write, wrong coverage branch, reused old row, missing/extra
  receipt, post-finalization source insert, and premature commit fail closed;
- direct receipt/context SQL is denied by the connection authorizer;
- all source-family normalizers and public-event mappings;
- internal cursor and public per-project cursor current, available, stale, wrong-stream,
  wrong-event, and future behavior;
- every reducer and query;
- continuation-token binding and stale-on-change behavior;
- exact query sort/tie-breaker behavior and typed decision-capability failures;
- checked-in source-family/composite golden oracles, independent provenance, projection
  invariants, and intentional no-op coverage;
- partial projection batch recovery;
- rebuild, digest comparison, activation, reset, and inactive-generation cleanup;
- journal and active-projection corruption detection;
- operations-store backup, restore, wrong-manifest rejection, interrupted publication, and
  target-preservation behavior;
- physical/logical snapshot digests reject row-order, storage-class, schema SQL, trigger, pragma,
  and manifest drift.

### Integration

- one SF-100 through SF-105 workflow produces transactionally bound source facts;
- source mutation rollback when journal append is rejected;
- direct immutable-source insertion without a mutation context fails;
- direct mutable canonical write and premature guarded commit fail;
- exact multi-source batch ordering and crash injection before and after journal append;
- deterministic live mutation IDs and existing-store backfill IDs survive restart/retry;
- public-event observation on its separate project stream while internal-only facts do not move
  the public cursor;
- process restart resumes projection checkpoints;
- restored database retains identical tip and projection digests.

### Workflow

- signal to work item to transition to dispatch to run/session/workspace produces one owner
  timeline and queryable active projections;
- reset and rebuild returns digest-equivalent owner views.

### Stress

- concurrent exact and changed append;
- concurrent source mutations preserve one global contiguous sequence;
- concurrent projection workers do not double apply;
- append while a full projection generation rebuilds;
- repeated interruption and restart;
- large replay with bounded batches;
- tampered event, source digest, checkpoint, and projection row fail closed;
- `ResourceWarning` promoted to an error.

When a level fails, fix the root cause and rerun that same level before advancing.

## Acceptance Evidence

SF-106 closes only when evidence proves:

1. every immutable source row created by a supported mutation has one exact journal fact;
2. no required source fact can commit without the journal entry;
3. trigger-created transaction-local receipts prove every appended source row was inserted by the
   same mutation transaction;
4. guarded current/source writes and guarded commit prevent an active or incomplete mutation from
   committing;
5. mutation IDs, backfill IDs, sequence, cursor, source binding, and hash chain are deterministic
   and valid;
6. existing-store backfill preserves source-version order despite out-of-order timestamps and
   cannot expose partial readiness;
7. exact duplicates do not append twice and changed duplicates conflict;
8. enabled public mappings are one-to-one, predicate-correct, payload-complete, and limited to the
   ratified 23 SF-003 types;
9. detectable secret-shaped content is rejected and per-source fixtures prove forbidden raw
   prompts, model output, credentials, contact values, and payment values cannot enter normalized
   projection documents;
10. projection batches are atomic and restart safe;
11. all seven required projections reach the journal tip;
12. rebuild produces equal counts and deterministic digests;
13. independently reviewed source-family and composite golden fixtures prove semantic projection
    correctness and complete
    reducer/no-op coverage;
14. every list/history query has stable sort, tie-breaker, token, stale error, and capability
    behavior suitable for SF-107 contract tests;
15. active generation survives interrupted reset/rebuild;
16. corruption fails at the exact sequence without silent repair;
17. operations-store backup and restore preserve journal and projection equality without changing
    the SF-105 component backup contract;
18. the complete ordered repository ladder passes;
19. installed-wheel verification asserts the exact SF-106 implementation, registry, schema,
    design, reproduction, and evidence inventory;
20. an independent implementation/test review has no unresolved Critical or High finding.

## Implementation Sequence

After independent design acceptance:

1. add source, mutation-coverage, public-mapping, projection, internal-cursor, page-token,
   query-result, capability-status, journal, mutation-context, pending-receipt, checkpoint, and
   operations-backup schemas;
2. add and independently validate all four machine-readable registries;
3. implement the guarded `OperationsConnection`, deterministic SQLite digest function,
   current-table guard triggers, source insert receipt triggers, mutation contexts, pending
   receipts, connection-bound batch append, separate internal/public cursors, and integrity
   verification;
4. add the one store-wide initialization gate, private backfill append path, version-preserving
   merge, and deterministic backfill identity;
5. refactor every covered SF-100 through SF-105 committing branch to begin its exact mutation
   context and finalize the trigger-recorded source batch on the same active connection;
6. implement the initially enabled SF-003 mapping and separate public-event reads;
7. check in independently authored source-family and composite golden fixtures, then implement
   projection definitions, reducers, intentional no-ops, generation checkpoints, exact sorted
   queries, typed capability failures, and expected-output oracle checks;
8. implement batch replay, interruption recovery, rebuild, reset, digest comparison, and
   activation;
9. add the separate operations-store backup coordinator, restore, status, and package catalogs;
10. add Foundation tests and run Foundation;
11. add Component tests and run Component;
12. add Integration tests and run Integration;
13. add Workflow tests and run Workflow;
14. add Stress tests and run Stress;
15. run protocol, skill, compilation, diff, build, and isolated-wheel checks;
16. make installed-wheel verification assert the exact SF-106 package inventory;
17. publish reproduction and evidence documents;
18. update the Obsidian project note;
19. request explicit permission before staging or committing SF-106.

## Independent Design Review Record

Three independent reviewers evaluated the first draft and returned `NOT READY`.

The blocking findings were:

- internal facts were incorrectly coupled to the SF-002 Event authority model;
- internal and public cursor semantics were mixed;
- same-transaction source re-read and exact active-connection ownership were under-specified;
- source and mutation-path coverage was not independently executable;
- mutable `work_item_revisions` was incorrectly eligible as a source;
- multi-row mutation cardinality and ordering were ambiguous;
- public mappings lacked exact predicates, payload extraction, and uniqueness;
- projection activation could race the journal tip;
- failure recording could be lost with the failed projection batch;
- rebuild digest equality lacked a semantic oracle;
- mutable-projection pagination was not snapshot safe;
- SF-107 detail, event, decision-capability, backup, restore, packaging, and operational failure
  dependencies were incomplete.

This revision addresses those findings with:

- a distinct internal source-fact envelope and separate SF-003 public project streams;
- no SF-002 Event-entity creation without separately ratified authority;
- one store-wide readiness gate and private, version-preserving immutable-source backfill;
- an explicit `sqlite3.Connection`-bound mutation context, trigger receipt, and ordered batch
  append port;
- independent source, mutation-coverage, public-mapping, and projection registries;
- concrete dynamic write-site coverage, deterministic mutation IDs, one fact per immutable source
  row, and explicit composite-transaction ordering;
- an initially narrow, exact, one-to-one public mapping;
- activation-time tip revalidation under `BEGIN IMMEDIATE`;
- post-rollback deterministic projection failure recording;
- independently authored source-family and composite golden fixtures, projection invariants, and
  reducer/no-op coverage;
- exact sorted queries, versioned stale-on-change continuation tokens, and typed errors;
- explicit SF-107 detail/event/decision-capability methods;
- a single-directory published operations-store backup contract with physical and logical digests;
- bounded test runtimes and exact installed-wheel inventory evidence.

Final independent design re-review on 2026-08-11 returned three `READY` verdicts with no unresolved
Critical or High findings. The accepted design includes the final deterministic backfill batch
binding and acyclic public-event/cursor digest construction.

Implementation then completed under a fresh governed activation. Two independent implementation
reviews returned `READY` with no unresolved Critical or High finding after the executable
normalizer/extractor, statement-level mutation coverage, runtime inverse-write, and rollback
proofs were added. The complete Foundation through Stress ladder and installed-wheel closure
passed. The design and implementation gates are closed for the declared local scope.

## Phase Boundary

SF-106 does not implement the SF-107 operations API or health/readiness surface.

SF-107 will consume:

- active projection queries;
- public-event reads and cursors;
- projection lag and failure metadata;
- journal and projection integrity status;
- existing SF-100 through SF-105 command services.

Gate B remains open until SF-107 is separately designed, implemented, and verified and the
Phase 1 kill-and-restart exit scenario passes.
