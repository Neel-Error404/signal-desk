# SF-300 Owner Inbox Implementation Plan

**Status:** VERIFIED

**Source revision:** `2ecfd6b323cde2fa660b54324aa9dc32a6f1fe5e`

## Implementation Point Of View

SF-300 should begin with one deterministic read-model core. Building a page
before the source coverage and coalescing rules are executable would create a
polished view that can still hide owner-required work.

The implementation order is:

1. closed attention-item and inbox-snapshot schemas;
2. validators and deterministic content digests;
3. explicit source readers for work items, session controls, recovery cases,
   and recovery orphans;
4. one reducer for mapping, coalescing, age, severity, evidence, and actions;
5. Foundation and Component proof;
6. separate-store restart Integration proof;
7. authenticated operations API route;
8. owner-facing presentation and Workflow proof;
9. concurrent-read Stress proof and closure.

## Implemented Scope

The implementation adds:

- `owner-attention-item.schema.json`;
- `owner-inbox-snapshot.schema.json`;
- `elder_protocol.factory_operations.owner_inbox`;
- public read access to validated recovery orphan findings;
- focused Foundation and Component tests;
- specified evidence and reproduction documents;
- one authenticated `/v1/owner-inbox` route with an authorization-bound
  project filter;
- an explicit global-route grant for unfiltered reads so unbound recovery
  orphans remain visible without granting that view implicitly;
- owner-only client-kind admission through the existing digest-bound SF-107
  auth policy;
- exact response semantic validation and the existing four-MiB response bound;
- explicit source-store runtime configuration;
- source-table fingerprint retries and fail-closed source-unavailable results;
- owner-facing structured presentation for the later SF-301 control-room
  shell.

### Closure

- separate-store restart proof: passed;
- authenticated loopback workflow: passed;
- concurrent source-stable reads: passed;
- package build and installed schema verification: passed;
- focused independent implementation review: findings corrected and focused
  regressions passed;
- repository documentation and separate closure commit: complete;
- Obsidian milestone record: updated after the closure commit so it can cite
  the exact revision.

## Stop Conditions

Stop and do not claim SF-300 when:

- an eligible source state is not represented;
- a suggested action grants or bypasses authority;
- partial source failure appears as a complete inbox;
- coalescing loses evidence;
- UI work begins before the read-model coverage proof passes.
