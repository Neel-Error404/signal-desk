# Task Execution Contract

**Status:** SPECIFIED - mandatory process for the roadmap tasks

## One Task, One Verified Delta

Every task in this dossier follows the same cycle:

```text
read -> inspect -> state claim -> plan -> implement
-> Foundation -> Component -> Integration -> Workflow -> Stress
-> validate evidence -> document -> hand off
```

Only the test levels relevant to the task are run, but they are always run in order. A failed level
is fixed and rerun before the next level.

Every task also obeys
[`16-phase-proportional-delivery-rule.md`](16-phase-proportional-delivery-rule.md). Correctness is
mandatory, but the required proof is bounded by the current task, declared environment, and phase
gate. Later-phase hardening is recorded and deferred rather than implemented early.

## Required Task Packet

Before implementation, create a packet from
[`templates/task-packet.md`](templates/task-packet.md) containing:

1. exact outcome and non-goals;
2. current-state evidence;
3. required reading and source snapshots;
4. affected boundaries and change class;
5. authority and approval requirements;
6. implementation plan;
7. failure conditions and rollback;
8. ordered test plan;
9. evidence and documentation outputs;
10. finding dispositions and later-task owners for deferred risks.

## Current-State Inspection

At task start:

- verify branch, HEAD, and worktree status;
- activate the Elder session;
- read the task's specified Elder and reference files;
- inspect existing implementation and tests before designing new abstractions;
- run the lowest relevant existing test level;
- record any pre-existing failures separately;
- confirm no protected surface is being silently changed.

## Implementation Rules

- Implement the smallest coherent contract.
- Prefer an existing local pattern.
- Keep worker-provider objects behind adapters.
- Make accepted commands and external signals idempotent.
- Persist state before acknowledging work that must survive restart.
- Make uncertain side effects reconcilable rather than blindly retryable.
- Emit explicit, actionable failures.
- Do not add fallback behavior unless the contract defines and tests it.
- Do not combine architecture ratification with implementation in the same agent-authored approval.
- Do not implement a review finding until it is traced to a current acceptance clause, current
  environment, reproduction or invariant, smallest correction, and same-level regression test.
- Classify findings as `BLOCKER`, `REQUIRED`, `DEFERRED`, `LIMITATION`, or `SPECULATIVE`.
- Stop and rescope after two review rounds where newly introduced guarantees create the next set
  of blockers.

## Test Expectations

### Foundation

- schemas, types, configuration, static dependency rules, migrations, and protocol validation.

### Component

- one domain or adapter in isolation;
- happy path, invalid input, concurrency/version conflict, and explicit errors.

### Integration

- storage plus service;
- operations plus Elder;
- operations plus worker adapter;
- target application plus P4.6 packet validation.

### Workflow

- complete owner or agent flow;
- restart in the middle of the flow;
- owner steering or approval;
- evidence linked to final outcome.

### Stress

- duplicate delivery;
- worker crash;
- lease expiry;
- lost response or uncertain side effect;
- queue backlog;
- stale authority;
- secret-shaped telemetry;
- hostile or untrusted repository input;
- learning regression and rollback.

## Evidence Minimum

Each completed task records:

- claim;
- source and destination commit or worktree state;
- changed files;
- commands and results;
- tests by level;
- linked work item and run;
- limitations;
- pass, partial, fail, or blocked verdict;
- next dependency.

Documents and configuration alone cannot prove runtime behavior.

## Completion Gate

A task is complete only when:

- its stated outcome is demonstrably true;
- required tests pass at the declared levels;
- replay/restart behavior is verified when durable state changed;
- documentation and task status are updated;
- no broader maturity claim is implied;
- every open finding is classified and no current-scope `BLOCKER` or `REQUIRED` finding remains;
- the next task has all required inputs.

Further hardening possibilities do not keep a task open by themselves. Otherwise mark the task
`BLOCKED` or keep it in progress with the exact missing current-scope proof.
