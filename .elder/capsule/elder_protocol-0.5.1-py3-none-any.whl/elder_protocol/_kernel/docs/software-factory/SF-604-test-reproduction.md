# SF-604 Test Reproduction

**Status:** VERIFIED on 2026-08-15

## Foundation

```powershell
py -m unittest tests.foundation.test_sf604_hosted_git_controls_contract -v
```

## Component

```powershell
py -m unittest tests.component.test_sf604_hosted_git_controls -v
```

## Integration

```powershell
py -m unittest tests.integration.test_sf604_hosted_git_controls -v
```

## Workflow

```powershell
py -m unittest tests.workflow.test_sf604_hosted_git_controls -v
```

## Stress

```powershell
py -m unittest tests.stress.test_sf604_hosted_git_controls_concurrency -v
```

## Static And Protocol Checks

```powershell
py -m ruff check `
  elder_protocol/factory_operations/hosted_git_controls.py `
  elder_protocol/factory_operations/__init__.py `
  tests/_sf604_support.py `
  tests/foundation/test_sf604_hosted_git_controls_contract.py `
  tests/component/test_sf604_hosted_git_controls.py `
  tests/integration/test_sf604_hosted_git_controls.py `
  tests/workflow/test_sf604_hosted_git_controls.py `
  tests/stress/test_sf604_hosted_git_controls_concurrency.py
py -m compileall -q elder_protocol tests
py -m elder_protocol.cli validate
git diff --check
```

## Final Results

| Level | Result |
|---|---:|
| Foundation | 5 passed |
| Component | 20 passed |
| Integration | 1 passed |
| Workflow | 1 passed |
| Stress | 3 passed |

Total focused SF-604 qualification: 30 passed.

## Failure And Correction Record

1. The first integration fixture read the signed response envelope as a plain
   response. The assertion now reads the signed statement and Integration
   passed.
2. Initial trust anchors were caller-selected. SF-604 now derives only the
   canonical P4.8A operator and reviewer anchors and validates active status,
   Ed25519 algorithm, role, validity window, and source host.
3. Verification initially accepted a caller-selected evaluation time. All live
   verification now uses the injected trusted clock; recorded time is used
   only for deterministic replay.
4. Governance was not bound tightly enough to the provider response. The
   signed response now binds the exact policy, governance, provenance,
   ruleset, provider identity, packet, Git objects, diff, artifact, and URL,
   with a bounded governance-to-response interval.
5. Signed source URIs initially allowed ambiguous path forms. Encoded paths,
   traversal, backslashes, dot segments, duplicate separators, query strings,
   fragments, and non-canonical paths now fail closed.
6. Independent review initially accepted caller-provided reviewer identities.
   It now requires the canonical reviewer signer and binds the exact PR,
   signed response, artifact, and review artifact.
7. The P5.2 result was initially represented by the packet alone. SF-604 now
   requires the exact open SF-404 supervised delivery record, owner submit
   decision, accepted provider response, and trusted-source digest.
8. Duplicate return and append paths initially relied on row uniqueness
   without complete chain replay. Every write and duplicate return now checks
   the full chain, append-only triggers, metadata record count, and tip
   checkpoint first.
9. Independent re-review found that canonical anchor IDs alone did not pin the
   approved key bytes. Production derivation now validates the canonical
   qualification policy, pinned subjects and keys, and the autonomy policy's
   approved full trust-anchor-set digest. An unpatched subprocess test proves
   the production loader derives the expected keys and GitHub host.
10. Independent re-review found a long-lived verifier could outlive an anchor.
    Every verification now rechecks canonical anchor validity at the trusted
    evaluation time.
11. Independent re-review found the SF-404 record remained structurally
    self-asserted. SF-604 now requires and revalidates the exact request, full
    normalized P5.2 source set, SF-402 decision, SF-403 completion, execution,
    active lease, current lease authority bindings, and reconstructed packet.
12. The strengthened duplicate test initially advanced the trusted clock,
    which correctly invalidated time-bound P5.2 derived reports before
    duplicate comparison. It now changes a valid review artifact at the same
    decision instant and reaches the intended retained-evidence conflict.
13. Workflow initially retained the old synthetic repository URL after the
    fixture switched to the actual SF-404 packet. The expected owner URL was
    corrected and Workflow passed on rerun before Stress was rerun.
14. Final review found retained replay could omit the live P5.2 inputs.
    Authority resolution is now mandatory at construction: every initial
    verification and replay resolves the trusted request, source set, and
    execution and reloads the SF-402 decision and SF-403 completion from their
    repositories before full authority and packet reconstruction.
15. Final review also required exact SF-402 operation and project binding.
    The decision must be the repository record for the same request, work item,
    and project, with `operation=start` and `disposition=accepted`.

Final independent disposition:

```text
BLOCKER: None
REQUIRED: None
OPTIONAL: None
Disposition: CLEAN
```

## Package And Installed Verification

```powershell
py -m build --outdir .tmp\dist-sf604-20260815-final-3
py -m pip install --no-deps `
  --target C:\Users\neela\AppData\Local\Temp\elder-sf604-installed-final3-20260815 `
  .tmp\dist-sf604-20260815-final-3\elder_protocol-0.5.1-py3-none-any.whl
```

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `elder_protocol-0.5.1-py3-none-any.whl` | 2,527,346 | `4C657B60E42A523B5559D0580D2FBB705FA147E2375A1AFA91FC20212D0A1D22` |
| `elder_protocol-0.5.1.tar.gz` | 1,949,014 | `80C7990202321955E9E0132CDFC4FFBA1B325DDAAA16F68FC19A742BAB228D85` |

The wheel was imported from the fresh target while the current directory was
`C:\Users\neela`, outside the checkout. The installed package composed the
packaged SF-404 fixture into the SF-604 signed governance, provenance,
provider-response, independent-review, and retention workflow, then restarted
the controls and replayed one record with the same chain tip. The returned
record remained unable to merge, deploy, or mutate maturity.

## Limitations

- No live Git provider or repository settings were contacted or changed.
- The proof uses repository-owned canonical public trust anchors, but no
  canonical private signing key is present in the package or checkout.
- The SQLite ledger is a local inactive retention proof, not hosted immutable
  evidence storage.
- SF-604 does not create, merge, release, or deploy a pull request.
- Multi-product isolation belongs to SF-605.
- Signed hosted qualification and human L2 ratification belong to SF-606.
- Canonical Elder maturity remains L1.
