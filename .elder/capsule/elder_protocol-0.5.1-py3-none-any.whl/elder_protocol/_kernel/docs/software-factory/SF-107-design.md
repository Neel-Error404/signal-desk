# SF-107 Factory API And Health Design

**Status:** VERIFIED - LOCAL GATE B PASS

**Implementation:** COMPLETE FOR THE DECLARED PHASE 1 SCOPE

**Design review:** ACCEPTED FOR THE DECLARED PHASE 1 CONTRACT

**Design date:** 2026-08-11

**Implementation branch:** `work/sf-107-factory-api-health`

**Base revision:** `03d8a2e9152118e0ee9fb943e3f0ebb5c064b603`

**Closure activation:** `activation-elder-protocol-c38cfe0db5a475dc`

**Change class:** `internal-code`

## Outcome

SF-107 adds the local authenticated HTTP application boundary over the verified SF-100 through
SF-106 factory operations kernel.

The API must:

- expose stable versioned commands, queries, event cursors, liveness, health, and readiness;
- bind only to numeric loopback in Phase 1;
- authenticate every `/v1` request against a digest-pinned local client policy;
- scope each authenticated client to exact route IDs, project IDs, client kind, identity, and
  canonical role eligibility;
- preserve the existing application-service transaction, authority, idempotency, and journal
  boundaries rather than reimplementing them in HTTP handlers;
- reject any request whose authenticated client identity conflicts with the actor identity or
  role carried by the canonical command;
- keep worker clients observation-only and prevent provider workers from directly mutating
  Product Factory, work-item, transition, run, authority, decision, memory, promotion, release,
  or deployment truth;
- durably bind every accepted mutation request and response to one API idempotency identity;
- survive a process crash before invocation, during invocation, after canonical commit, or before
  HTTP response without blindly repeating an uncertain effect;
- translate SF-106 projection pagination and SF-003 public-event cursor behavior without
  weakening either contract;
- provide bounded long polling without creating a second event authority or unbounded thread
  growth;
- distinguish process liveness, safe request readiness, degraded-but-safe operation, and
  capability availability;
- fail readiness on stale verification, journal corruption, projection corruption or lag,
  route/auth policy drift, store incompatibility, maintenance, or loss of the current API runtime
  lease;
- retain truthful `decisions` endpoints that return an explicit unavailable-capability error
  until a canonical decision source is implemented;
- prove the Gate B kill-and-restart scenarios for queued work, leased work, idempotent mutation
  response loss, and deterministic projection rebuild.

The maximum truthful claim is one local, loopback-only, single-active-process HTTP API over one
SQLite operations store. SF-107 does not add an owner UI, TLS termination, remote access,
multi-tenant isolation, hosted identity, secret brokering, a durable network broker, distributed
workers, a real Codex adapter, hosted checkpoints, production telemetry, deployment, release, or
canonical maturity above L1.

## Governed Intake

```text
Objective:
  Expose the verified local operations kernel through one restart-safe, authenticated,
  provider-neutral HTTP boundary and close the local Gate B control-plane proof.

Affected users:
  Local product owners and operators, integration adapters, factory-owned service clients, future
  owner-control-room code, and read-only worker observers.

Success:
  Every route is versioned, authenticated as required, project scoped, role eligible, bounded,
  schema validated, and mapped to one existing application-service method. Queries preserve
  SF-106 projection and cursor semantics. Mutations preserve canonical authority and replay
  exactly across process death. Readiness fails closed when safe service cannot be proven.

Failure:
  A remote listener starts; an unauthenticated `/v1` request succeeds; a bearer token becomes
  canonical authority; a client crosses project or route scope; a worker mutates canonical state;
  an HTTP retry repeats an effect; a response-loss crash becomes a blind retry; a stale
  projection token silently restarts; an event cursor skips or duplicates; readiness reports
  healthy while journal, projection, policy, runtime lease, or store evidence is stale or invalid.

Constraints:
  Windows 11, Python standard library HTTP server, current Python dependencies only, numeric
  loopback, SQLite WAL/FULL durability, one active API process, one operations store, SF-003
  version 1.0.0, SF-106 active projections and public stream, canonical L1.

Non-goals:
  Browser UI, CORS, cookie sessions, OAuth/OIDC, mTLS, remote clients, TLS, reverse proxy,
  WebSocket or server-sent events, distributed broker, Postgres, external secret broker,
  provider worker callbacks, decision persistence, admin policy mutation endpoints, projection
  reset/rebuild endpoints, backup/restore endpoints, deployment, release, or hosted operation.

Risk:
  High. The API becomes the command and observation boundary for the local factory. Weak
  authentication, authority confusion, retry ambiguity, unbounded long polling, or false
  readiness would invalidate Gate B.

Authority:
  Factory operations owns transport acceptance, API idempotency, runtime lease, and health
  evidence. Existing SF-100 through SF-106 application services remain the only canonical
  mutation boundaries. Elder remains canonical for governance and delegated authority. Product
  owners retain product intent and accountable decisions. Workers remain observation-only.

Capability packs:
  core, factory-operations, agentic, assurance, data, web-product, regulated.

Knowledge sources:
  ADR 0021, factory operational architecture, SF-002 domain, SF-003 contracts, SF-100 through
  SF-106 executable services and evidence, SF-106 query/cursor contracts, Elder role and
  authority registries, and the local Workbench HTTP reference.

Open questions:
  None that require a protected-contract change. Hosted authentication, remote transport,
  decision persistence, and public multi-version compatibility remain later governed tasks.

Next proof gate:
  Foundation validation of the route, authentication, envelope, idempotency, runtime, health,
  and readiness contracts, followed by independent design review with no unresolved Critical or
  High finding. Runtime implementation must not begin before that review passes.
```

## Ratified Inputs

This design implements, but does not amend:

- ADR 0021 and `factory/operational-architecture.json`;
- SF-002 entity ownership, lifecycle, role eligibility, and worker non-authority;
- SF-003 version `1.0.0` error, idempotency, redaction, command, event, and cursor semantics;
- SF-100 Product Factory project, repository, profile, owner, and worker-policy binding;
- SF-101 authenticated signal intake and exact signal idempotency;
- SF-102 canonical work-item intent and optimistic concurrency;
- SF-103 as the sole work-item stage-transition boundary;
- SF-104 durable command acceptance, leases, uncertainty, retry, and dead-letter behavior;
- SF-105 immutable run/session/workspace lineage and governed lifecycle commands;
- SF-106 journal, active projections, query tokens, public event cursors, integrity, status,
  backup, and restore behavior;
- the canonical Elder role registry and authority matrix.

SF-107 does not edit the protected SF-002 or SF-003 public contracts. The HTTP route registry is a
strict local implementation contract under `factory/operations/`. A future remote or hosted API,
new public event type, new decision source, changed SF-003 error behavior, or side-by-side
contract version requires a separately reviewed public-contract change.

## Initial Independent Review

Two independent reviewers returned `NOT READY` on 2026-08-11. Implementation remained blocked.

This revision must resolve the findings before re-review:

- the API boot and runtime generation fence every exposed canonical application transaction,
  not only request admission or response persistence;
- application mutations resolve exact mutation-identity results before duplicate, existence,
  optimistic-version, or terminal-state conflicts;
- a machine-readable binding registry defines path, query, payload, service-argument, equality,
  response, replay, and mutation-scope behavior for every route;
- cancellation remains owner-authorized and carries exact lease owner/generation tokens when
  cancelling leased work;
- unresolved API mutation state stops later mutation admission until reconciliation;
- the auth policy cannot claim canonical roles; current profile bindings determine project role
  eligibility;
- decision routes are explicit terminal `501` routes rather than false `200` routes;
- liveness, readiness, mutation readiness, idempotency states, runtime states, and error tuples
  have cross-field semantic validation;
- restore is offline-only and cannot race an active API runtime;
- Gate B uses separate API, claimant, and operator subprocesses, deterministic test-only
  failpoints, and retained comparison artifacts.

### Second remediation

The first remediation re-review also returned `NOT READY`. This second remediation closes the
remaining contract gaps without starting implementation:

- the 45-route matrix is hardcoded in Foundation evidence and binds method, path, kind,
  authentication, project scope, readiness, service, response validator, and exact query
  parameters;
- every binding source is resolved through the mutation envelope and the selected catalog
  schema, including nested `factory/` and `protocol/` contracts;
- first Product Factory registration uses one explicit candidate-profile bootstrap rather than
  requiring a current registration that cannot yet exist;
- SF-003 factory commands remain actor-free; dispatch authority is checked through the
  authenticated factory-service identity, current profile executor role, command
  `authority_ref`, and application-service validation;
- run lifecycle, checkpoint, and artifact services receive `expected_project_id` and compare it
  with the loaded run aggregate inside the fenced canonical transaction;
- every response-validator family has a closed outer data shape, exact route/validator binding,
  canonical digest verification, and recursive secret rejection;
- readiness, runtime, idempotency, and stale-cursor records have executable freshness,
  monotonic-time, tip-completeness, and required-detail checks.

### Final remediation after second re-review

The second re-review remained `NOT READY`. The final design remediation adds:

- canonical digest pins for the complete route and binding registries, so a validly redigested
  change to any client kind, role, contract, status, idempotency field, member contract, service
  argument, equality, query mapping, or mutation scope fails Foundation until the reviewed pin is
  intentionally updated;
- route-specific mutation-result contracts that bind one exact application record schema,
  canonical record digest, project-bound source proof, contiguous journal proof, and
  result-proof digest;
- canonical nested validation for projection documents, SF-003 events and cursors, capability
  keys, projection/journal status, and route project or subject identity;
- readiness freshness against authoritative current UTC time with one-second clock tolerance,
  rather than trusting self-declared document time;
- reason-specific stale-cursor detail objects and the canonical SF-003 cursor validator instead
  of a weaker duplicated cursor contract;
- a health-to-readiness digest and timestamp binding;
- every known shared implementation and packaging surface in the closure inventory, plus an
  unaccounted-diff failure check.

### Final remediation after final re-review

The final re-review also remained `NOT READY`. This remediation closes the reproduced proof and
response-domain gaps before implementation:

- the binding registry now owns 19 exact response scopes, each binding a route to its project
  source, optional required subject source, and canonical projection domain;
- every mutation result requires the resolved route subject, admitted API request digest, and a
  store-loaded finalized SF-106 mutation context; a response cannot validate from its own proof
  fields alone;
- the store-loaded mutation evidence is checked against the canonical coverage branch, declared
  source-count range, registered source families, append order, fixed sequence where SF-106
  requires one, per-write-site cardinality, mutation identity, entry chain, entry IDs and digests,
  generation, first/last sequence, canonical batch digest, and one unique route-specific primary
  source row;
- the returned application record is project- and subject-bound for all 16 mutations. Run
  artifact records that do not carry project directly use the trusted run aggregate loaded in
  the same fenced transaction;
- `run-bind-start` has one explicit response extraction: omit the service-only `command_result`
  field, validate the remaining aggregate against `run-binding-record.schema.json`, and bind the
  primary source digest to `record.initial_binding.content_sha256`;
- projection pages and records require a store-verified source binding and must use a source
  registry and fact type that canonically reduce into the route's declared projection domain;
- liveness checked time must be within one second of authoritative current UTC in either
  direction, and detailed health status and required dependency summaries must not contradict
  the exact bound readiness snapshot.

## Final Independent Design Acceptance

Two independent reviewers returned `READY` on 2026-08-11 for the exact fourth-remediation
worktree. No unresolved Critical or High design finding remained.

Accepted evidence:

- focused Foundation: 27 of 27 tests passed;
- complete Foundation: 110 of 110 tests passed in 35.732 seconds, exit code zero;
- real SF-105 `RunController.bind_start` compatibility: 1 of 1 Component test passed in
  27.241 seconds, exit code zero;
- protocol validation and skill-registry validation passed;
- route, binding, and cross-registry digests independently recomputed exactly;
- `git diff --check` reported no whitespace error.

The acceptance authorizes SF-107 runtime implementation against this design. It does not claim
that the runtime, Gate B workflow, installed-wheel proof, or Phase 1 closure already exists.

## Implementation Audit Reopening

On 2026-08-12, after the first real HTTP mutation/restart implementation and the complete
Foundation and Component regression levels passed, two independent implementation audits found
that the accepted design fixtures did not match two executable SF-106 boundaries. SF-107 was
therefore reopened until this section was implemented, tested, and independently re-reviewed.

### Projection response correction

SF-106 `ProjectionQueries` returns active-generation aggregate projection rows. A row can combine
multiple source families and contains current aggregate state, ordered history, latest values by
source, parent identities, source version, journal checkpoint, and a canonical row digest. It is
not an `operations-journal-projection-document`, which represents one normalized journal source
fact.

SF-107 must preserve the real SF-106 query boundary:

- record routes return one exact active-generation aggregate row;
- list and timeline routes return exact bounded slices of aggregate rows;
- history routes return exact bounded ordered slices of the `history` member of one independently
  store-verified aggregate row;
- no adapter may collapse a multi-source aggregate into one source document;
- validation independently reloads the active generation and exact `factory_projection_rows`
  bytes, generation, project, subject, `record_json`, indexed digest, and canonical digest;
- page metadata must match the independently verified generation, journal tip, method, filter,
  sort, and page size;
- generation cutover or journal-tip movement during response validation fails closed;
- projection status is built from `verify_projection()` for every requested active generation,
  including row count, projection digest, journal generation, sequence, entry identity, entry
  digest, and lag.

Foundation and Component fixtures must distinguish aggregate-row pages, timeline pages, and
aggregate-history pages. Journal projection documents remain internal SF-106 evidence and are not
substituted for owner-facing aggregate query records.

### Interrupted mutation reconciliation correction

An exact request already in `reconcile-required` is the only mutation request allowed to enter
reconciliation while global `mutation_ready=false`. New keys and changed requests remain blocked.
The service must call `begin_reconciliation()` before attempting recovery.

Recovery derives the exact SF-106 identity source from the authenticated original request and
resolved route. It then requires exactly one finalized mutation context matching:

- canonical coverage branch or allowed route branch family;
- path project and canonical scope subject;
- canonical identity-source JSON and digest;
- request-bound actor, command, configuration, specification, reason, decision, reference, or
  submission digests as declared by the SF-106 coverage registry;
- immutable pre-state and expected-result versions consistent with the request and source batch;
- a complete valid journal batch satisfying the canonical coverage and source rules.

The response is reconstructed from the exact immutable source versions in that finalized batch,
never from a mutable current aggregate. Product, signal, work-item, transition, dispatch, and run
lifecycle results use their exact immutable revision/result records. Run binding is reconstructed
from the initial binding and the run, worker-session, and workspace source versions in the same
batch. If an exact historical result cannot be reconstructed, the row remains
`reconcile-required` and the API returns `409 uncertain-mutation`; it never invokes the normal
mutation path blindly.

Checkpoint and artifact application methods return a durable
`run-lifecycle-command-result.schema.json` record. SF-107 therefore uses that result as the
route's primary response record and `run-lifecycle-results` as its primary source proof. An
applied result must additionally bind the checkpoint or artifact reference source in the same
journal batch. A rejected result must not fabricate a reference record.

### Production semantic validation correction

The liveness, readiness, detailed-health, projection-status, journal-status, aggregate-query,
public-event, and mutation-result semantic checks must live in production validators, not only in
Foundation fixtures. Direct health responses are validated immediately before publication
against authoritative current UTC and, for detailed health, the exact readiness snapshot used to
construct the response.

Implementation may resume only after Foundation encodes these corrected contracts and the
complete Foundation level passes again.

## Canonical Terms

### API client identity

The local identity selected by an exact `X-Elder-Client-Id` and bearer-token digest match. It
identifies the transport client and its allowed routes/projects. It is not an Elder delegation,
authority result, approval, or provider identity.

### Actor identity

The identity carried by a mutation envelope or canonical command. For owner and factory-service
routes, it must equal the authenticated API client's configured identity. Existing application
services then validate its profile role and command authority.

### Route eligibility

The intersection of:

- route ID allowed by the client policy;
- client kind allowed by the route registry;
- project ID allowed by the client policy;
- at least one current canonical role resolved from the bound Product Factory profile and allowed
  by the route registry;
- actor identity and command-role consistency for mutations.

Eligibility permits the request to reach the application service. It never makes an otherwise
unauthorized transition valid.

### Liveness

Evidence that the HTTP process and handler are running. Liveness does not access SQLite and does
not imply that commands or queries are safe.

### Readiness

Evidence that the current API runtime lease, route registry, authentication policy, operations
store, journal, all active projections, and recent full verification permit safe request
processing.

### Capability availability

Whether one named API capability has a canonical implementation. An unimplemented optional
capability is reported explicitly. It does not fabricate empty data and does not automatically
make unrelated implemented routes unsafe.

### API idempotency record

Durable transport metadata binding route, client, project, key, canonical request digest,
execution ownership, and exact response. It does not replace canonical command or source records
and is not a journal source.

## Component Topology

```text
local owner, integration, factory-service, or worker-observer client
        |
        | numeric loopback HTTP
        v
request parser and transport limits
        |
        v
authentication policy and route authorization
        |
        +--> read route --> SF-106 ProjectionQueries / JournalIntegrity
        |
        +--> mutation route
                |
                v
        durable API idempotency boundary
                |
                v
        existing SF-100 through SF-105 application service
                |
                v
        canonical operation + immutable source + SF-106 journal transaction
                |
                v
        exact API response record

background health verifier
        |
        +--> route/auth/runtime contract verification
        +--> store and journal integrity
        +--> seven active projections and lag
        +--> capability, backup, uncertainty, and dead-letter degradations
```

Allowed dependency direction:

```text
HTTP handler -> transport parser
HTTP handler -> authentication/route policy
HTTP handler -> API idempotency service
HTTP handler -> application facade
application facade -> existing factory operations services
query facade -> SF-106 ProjectionQueries
health monitor -> SF-106 JournalIntegrity and ProjectionRuntime status
```

Forbidden:

```text
HTTP handler -> raw canonical table writes
HTTP handler -> direct journal append
HTTP handler -> projection reducer
API token -> canonical role or authority creation
worker-observer client -> mutation route
live event -> command or run completion
health result -> authority, maturity, promotion, merge, release, or deployment
API idempotency row -> canonical lifecycle state
```

## Machine-Readable Contract Inventory

SF-107 adds:

- `operations-api-route-registry.schema.json`;
- `operations-api-route-registry.json`;
- `operations-api-binding-registry.schema.json`;
- `operations-api-binding-registry.json`;
- `operations-api-auth-policy.schema.json`;
- `operations-api-mutation-request.schema.json`;
- `operations-api-mutation-payload.schema.json`;
- `operations-api-response.schema.json`;
- `operations-api-error.schema.json`;
- `operations-api-liveness.schema.json`;
- `operations-api-health.schema.json`;
- `operations-api-readiness.schema.json`;
- `operations-api-idempotency-record.schema.json`;
- `operations-api-runtime-record.schema.json`.

The SF-107 baseline closed with 45 exact method/path pairs. SF-300 extends the
same versioned local registry with one reviewed owner-inbox query, so the
current registry contains 46:

- 2 unauthenticated loopback health routes;
- 7 authenticated operational status/capability/owner-attention routes;
- 21 authenticated read/query/event/decision routes;
- 16 authenticated mutation routes.

Every route pins:

- route ID, method, and path template;
- liveness, readiness, query, or mutation kind;
- authentication requirement;
- allowed client kinds and canonical role eligibility;
- project-scope requirement;
- whether full service readiness is required;
- exact existing service method;
- request and response contract;
- successful HTTP status or one exact terminal error;
- idempotency requirement, replay strategy, and canonical identity fields;
- long-poll allowance and maximum wait.

The separately digested binding registry has exactly the same 46 route IDs and pins:

- exact path placeholders and allowed query parameters;
- one discriminated mutation payload operation where applicable;
- every selected nested application schema;
- every service argument and its path, query, body, authenticated-identity, or server source;
- every required path/body/identity equality;
- one exact response validator ID;
- runtime-fence requirement;
- exact application mutation-identity and journal-result replay proof;
- the fields that form the mutation-admission fence scope;
- for every projected or public-event response, one exact response scope containing the project
  source, optional subject source, and canonical projection domain.

Every member contract is catalog-qualified. A bare schema name resolves only under
`factory/operations/`; `factory/...` resolves under the repository factory catalog; and
`protocol/...` resolves under the repository protocol catalog. Validation resolves every dotted
member, equality, mutation-scope, and service-argument source through the selected operation
schema. A generic `type: object` placeholder cannot prove a nested binding when a more specific
member contract is required.

The route registry pins the binding-registry digest. Unknown routes, methods, placeholders, query
parameters, client kinds, roles, contracts, response validators, equality bindings, or service
arguments fail validation.

Foundation also pins the canonical digest of each complete registry. Self-consistent redigestion
does not authorize semantic drift. A reviewed registry change must update the machine document,
the complete canonical pin, the relevant negative probe, and independent review evidence
together.

Response validator meanings are closed:

| Validator | Required proof |
|---|---|
| `liveness` | exact liveness schema, digest, and authoritative-current-time tolerance |
| `readiness` | readiness schema, semantic cross-field checks, exact seven projections |
| `health-detail` | dependency health schema, readiness snapshot digest/time, and non-contradictory status |
| `capability-status` | factory capability-status schema and exact known capability keys |
| `projection-status` | active-generation registry, journal-tip equality, row counts, digests |
| `journal-status` | full SF-106 integrity report with ready state and verified tip |
| `owner-inbox-snapshot` | exact SF-300 source-stable, digest-bound owner-attention snapshot |
| `projection-page` | projection query-result schema, query metadata, response scope, and an exact store-verified aggregate-row or aggregate-history slice from one active generation |
| `projection-record` | one exact store-verified active-generation aggregate row with matching route project, subject, projection domain, stored bytes, and digest |
| `public-event-page` | SF-003 cursor identity plus every item as a valid public event |
| `public-event` | one valid SF-003 public event with matching project and event ID |
| `product-mutation-result` | exact Product Factory record and source/journal proof |
| `signal-mutation-result` | exact signal record and source/journal proof |
| `work-item-mutation-result` | exact work-item record and source/journal proof |
| `transition-mutation-result` | exact transition record and source/journal proof |
| `dispatch-mutation-result` | exact dispatch record and source/journal proof |
| `run-mutation-result` | exact run command/result/reference records and source/journal proof |
| `terminal-error` | exact route-declared terminal error; no success envelope |

Every successful response is recursively secret-scanned before its `data_sha256` is accepted.
The envelope `route_id` must equal the resolved route, `data_contract` must equal that route's
binding-registry validator, and `data_sha256` must equal the canonical digest of `data`.
Validator-specific outer keys are closed; nested records then validate against their selected
application or SF-003 contracts. There is no generic pass-through validator.

Every mutation result contains:

- `record_contract`, fixed by exact route;
- the complete application `record` and its canonical `record_sha256`;
- the exact primary SF-106 source-row proof containing source registry, table, primary key,
  record version, record digest, and row digest;
- a contiguous journal proof binding API request digest, application mutation ID and identity
  digest, canonical coverage branch, generation, first/last sequence, entry IDs, entry digests,
  and batch digest;
- `result_proof_sha256` over the record contract, record digest, source proof, and journal proof.

Product, signal, work-item, transition, dispatch, run-binding, run-lifecycle, checkpoint, and
artifact routes select their exact existing application schema. Dispatch records also pass the
existing semantic validator. Factory entities, projection documents, SF-003 events, and cursors
pass their existing semantic validators. Route project and subject identities are rechecked
after structural validation. The mutation validator loads the finalized mutation context and
ordered journal entries from SQLite, validates every entry with the SF-106 canonical validator,
recomputes the batch digest, applies SF-106's source-count, registered-family, append-order,
fixed-sequence, and per-write-site cardinality rules, and matches one unique primary source row
to the returned application record. It does not trust response-supplied source, journal,
mutation, or batch claims. Completed API idempotency rows cannot store or replay a response until
this complete validator succeeds.

`RunController.bind_start` returns an application aggregate plus a service-only
`command_result`. The API adapter removes only `command_result`, validates the remaining record
against `run-binding-record.schema.json`, and uses the nested
`initial_binding.content_sha256` as the `run-initial-bindings` primary-source digest. Foundation
pins this extraction contract, and a Component compatibility proof invokes the real SF-105
service, loads its finalized journal context and entries from SQLite, and validates the authentic
result through the SF-107 response validator.

Projection response validation receives the binding-registry response scope resolved from the
actual route and an independently loaded, digest-bound SF-106 projection-store context containing
project, projection, active generation, subject, exact stored aggregate JSON, indexed row digest,
projection digest, and journal tip. List and record responses must match exact stored aggregate
bytes. History responses must match an exact ordered page slice from the independently loaded
aggregate's `history`. Response-derived context is not a trusted origin.

## Transport Decision

Phase 1 uses the Python standard library `ThreadingHTTPServer` with a bounded request admission
layer.

Required transport behavior:

- bind only to `127.0.0.1`;
- reject `localhost`, wildcard, non-loopback IPv4, and IPv6 binding arguments rather than relying
  on DNS or interface configuration;
- use HTTP/1.1 with explicit `Content-Length`;
- reject request transfer encoding and chunked bodies;
- close a connection after malformed framing or an oversized undrainable request;
- accept JSON only as UTF-8 `application/json`;
- emit JSON only as UTF-8 with deterministic key ordering;
- set `Cache-Control: no-store`, `X-Content-Type-Options: nosniff`,
  `Referrer-Policy: no-referrer`, `X-Frame-Options: DENY`, and a deny-by-default
  `Content-Security-Policy`;
- do not set CORS headers;
- do not use cookies;
- do not serve static files;
- do not follow redirects;
- do not expose traceback, file path, SQL, bearer token, raw request body, or raw query string in
  responses or access logs.

Limits:

| Resource | Limit |
|---|---:|
| request body | 512 KiB |
| request target including query | 8 KiB |
| parsed headers | 64 |
| one header value | 8 KiB |
| query parameters | 32 |
| projection/event page size | 1 through 500 |
| total active requests | 64 |
| active long polls | 16 |
| event long poll | 0 through 30 seconds |
| graceful drain | 10 seconds |
| response body | 4 MiB |

The JSON loader rejects:

- duplicate object keys;
- non-object mutation bodies;
- `NaN`, positive or negative infinity;
- non-UTF-8 bytes;
- trailing bytes after the one JSON value;
- secret-shaped fields, values, or references not permitted by the selected payload contract.

## Authentication Policy

All `/v1` routes require:

```text
X-Elder-Client-Id: <configured client id>
Authorization: Bearer <raw local token>
```

The service receives an operator-selected auth-policy path. It does not generate, print, persist,
or return raw tokens.

The policy stores only:

- client ID;
- client kind;
- canonical identity ID;
- enabled flag;
- SHA-256 of a high-entropy raw bearer token;
- exact project IDs;
- exact route IDs;
- optional exact global-route IDs for separately authorized non-project
  queries.

Policy requirements:

1. The file validates against `operations-api-auth-policy.schema.json`.
2. Its canonical digest matches `content_sha256`.
3. `issued_at < expires_at` and current time is inside that interval.
4. Client IDs, token digests, and identity IDs are unique.
5. Every route ID exists in the route registry and is compatible with the configured client kind.
6. No wildcard project, route, identity, or client is accepted.
7. Raw bearer tokens must be base64url text carrying at least 256 bits of entropy and are compared
   by constant-time digest equality.
8. Every global-route grant must also be an exact route grant and cannot name
   a project-scoped route.
9. Disabled, missing, expired, not-yet-valid, malformed, changed, or duplicate clients fail
   closed.
10. Client IDs, identity IDs, and bearer-token digests are independently unique.
11. Policy changes require a process restart in Phase 1. There is no policy mutation endpoint.

The bearer token proves possession of one local API client credential. It does not prove that a
canonical role, Elder authority decision, delegated runtime lease, product approval, or worker
observation is valid.

The auth policy does not contain role assignments. For a project-scoped route, the server loads
the current registered Product Factory, verifies its bound profile and repository identity, and
resolves the authenticated identity's current canonical roles from that profile. The route
`roles` field is a required canonical-profile-role set, not a transport-policy grant. Global
health and integrity routes use exact route assignment and client kind only.

`product-register` is the only bootstrap exception. When no Product Factory exists for the path
project, the API validates the candidate registration contract, resolves its repository root and
relative `profile_path`, verifies the candidate profile digest and project identity, and requires
the authenticated identity to hold `human-owner` or `product-owner` in that candidate profile.
The candidate project must equal both path and envelope project. The application service repeats
the same repository, profile, identity, and role validation inside the fenced registration
transaction. If a current factory exists, normal current-profile authorization applies. No other
route may authorize from request-supplied profile material.

Only `/health/live` and `/health/ready` are unauthenticated. They are numeric-loopback-only,
read-only, body-bounded, and never include raw policy content, token digests, client IDs, actor
identities, file paths, or SQL details.

## Authorization

Request authorization is evaluated in this order:

1. resolve one exact route template;
2. authenticate client ID and bearer token;
3. verify client enabled and policy current;
4. verify route ID is explicitly assigned;
5. verify client kind is allowed by the route;
6. verify project path is present when required and appears in the client project allowlist;
7. for project-scoped routes, resolve the identity's current profile roles and require at least
   one route-eligible canonical role;
8. for mutations, require envelope `project_id` to equal the path project;
9. require envelope `actor_identity_id` to equal the authenticated client's identity;
10. verify the selected underlying payload's actor, role, project, entity IDs, expected versions,
    authority records, and idempotency identities agree with the transport bindings;
11. invoke the existing service, which revalidates profile roles and canonical authority.

The API cannot authorize a transition that the application service rejects.

For `dispatch-submit`, the SF-003 factory command intentionally has no actor field. The outer
mutation actor must equal the authenticated factory-service identity. That identity must resolve
to the current profile's `executor` role, the command and adapter request must both match the path
project, and the application service must validate the command `authority_ref`. SF-107 does not
invent an actor property inside the SF-003 command.

For `run-lifecycle-apply`, `run-checkpoint-reference`, and `run-artifact-reference`, the binding
passes path `project_id` as `expected_project_id`. The Run Controller must load the run aggregate
inside the same runtime-fenced canonical transaction and reject unless its project equals
`expected_project_id` before duplicate replay, optimistic-version handling, or mutation.

Client-kind rules:

- `owner-ui`: owner-authored product, work-item, and eligible transition commands plus owner
  queries;
- `integration-adapter`: signal ingestion and scoped signal/event reads only;
- `factory-service`: factory-owned dispatch/run commands and scoped reads;
- `worker-observer`: scoped read-only work-item, transition, command, run, capability, and event
  observation;
- `operator`: local health, readiness, integrity, projection, product, and owner-query access;
  product mutation still requires an exact owner identity and role.

No route allows `worker-observer` on a mutation. Provider worker output must enter through a
future factory-owned worker gateway, which translates and validates observations before calling
an existing application service.

## Route Surface

The canonical route inventory is
`factory/operations/operations-api-route-registry.json`.

### Health and operational status

```text
GET /health/live
GET /health/ready
GET /v1/health
GET /v1/readiness
GET /v1/capabilities
GET /v1/projections
GET /v1/projections/{projection_id}
GET /v1/journal
```

### Owner and observer queries

```text
GET /v1/projects/{project_id}/products
GET /v1/projects/{project_id}/products/{factory_id}
GET /v1/projects/{project_id}/signals
GET /v1/projects/{project_id}/signals/{signal_id}
GET /v1/projects/{project_id}/signals/{signal_id}/history
GET /v1/projects/{project_id}/work-items
GET /v1/projects/{project_id}/work-items/{work_item_id}
GET /v1/projects/{project_id}/work-items/{work_item_id}/history
GET /v1/projects/{project_id}/transitions
GET /v1/projects/{project_id}/transitions/{transition_id}
GET /v1/projects/{project_id}/commands
GET /v1/projects/{project_id}/commands/{command_id}
GET /v1/projects/{project_id}/commands/{command_id}/history
GET /v1/projects/{project_id}/runs
GET /v1/projects/{project_id}/runs/{run_id}
GET /v1/projects/{project_id}/runs/{run_id}/history
GET /v1/projects/{project_id}/timeline
GET /v1/projects/{project_id}/events
GET /v1/projects/{project_id}/events/{event_id}
GET /v1/projects/{project_id}/decisions
GET /v1/projects/{project_id}/decisions/{decision_id}
```

### Mutations

```text
POST /v1/projects/{project_id}/products
PUT  /v1/projects/{project_id}/products/{factory_id}
POST /v1/projects/{project_id}/products/{factory_id}/activate
POST /v1/projects/{project_id}/products/{factory_id}/pause
POST /v1/projects/{project_id}/products/{factory_id}/archive
POST /v1/projects/{project_id}/signals
POST /v1/projects/{project_id}/work-items
POST /v1/projects/{project_id}/signals/{signal_id}/work-items
PUT  /v1/projects/{project_id}/work-items/{work_item_id}
POST /v1/projects/{project_id}/work-items/{work_item_id}/transitions
POST /v1/projects/{project_id}/commands
POST /v1/projects/{project_id}/commands/{dispatch_id}/cancel
POST /v1/projects/{project_id}/runs
POST /v1/projects/{project_id}/runs/{run_id}/transitions
POST /v1/projects/{project_id}/runs/{run_id}/checkpoints
POST /v1/projects/{project_id}/runs/{run_id}/artifacts
```

The following existing internal methods are intentionally not exposed:

- dispatcher claim, reconciliation claim, lease renewal, execution begin, adapter response,
  uncertainty marking, retry, recovery, dead-letter, and shutdown-owner operations;
- run Elder-observation ingestion;
- work-item-start prepare, uncertain, and confirm compensation operations;
- projection reset, rebuild, activation, or cleanup;
- operations backup, restore, or database replacement;
- auth-policy mutation;
- raw SQL, raw journal append, or raw source-record insertion.

Those remain factory-owned internal operations. Later worker-gateway or operator-admin exposure
requires a separately reviewed route-registry change.

`dispatch-cancel` is an owner action. Only `owner-ui` or `operator` clients whose authenticated
identity resolves to `human-owner` or `product-owner` may call it. A queued cancellation supplies
null lease owner/generation. A leased cancellation must supply the exact current owner ID and
lease generation read from the command projection; the application service rechecks both before
changing state.

## Query And Pagination Semantics

SF-107 delegates read semantics to `ProjectionQueries`.

Rules:

- `limit` defaults to 100 and remains bounded to 1 through 500;
- query parameters not declared for the resolved route are rejected;
- repeated scalar query parameters are rejected;
- empty required path or query values are rejected;
- list and history ordering remains exactly the SF-106 ordering;
- the continuation value is opaque to the HTTP client;
- the server base64url-decodes no alternate token format and passes the exact SF-106 token;
- malformed or cross-method continuation becomes HTTP `400` with SF-003 code
  `invalid-request` and reason `invalid-projection-token`;
- stale continuation becomes HTTP `409` with SF-003 code `stale-cursor`, reason
  `stale-projection-token`, retry `refresh-cursor`, and `restart_required=true`;
- a stale token never silently restarts at page one;
- not-found records return HTTP `404`, never an empty object;
- projection corruption or missing active generation returns HTTP `503`;
- no query falls back from an active projection to canonical tables.

Successful queries use `operations-api-response.schema.json`. The envelope binds `route_id`,
`data_contract`, canonical `data`, and `data_sha256`. Before serialization the server invokes the
route's exact binding-registry response validator, recursively rejects secret-shaped output, and
then verifies `data_sha256`. The complete SF-106 query metadata remains under `data`.

## Public Events And Long Polling

`GET /v1/projects/{project_id}/events` accepts:

- one optional opaque cursor value encoding the exact SF-003 cursor JSON;
- `limit` from 1 through 500;
- `wait_seconds` from 0 through 30.

Behavior:

1. authenticate and authorize before allocating a long-poll slot;
2. validate the cursor against the exact project stream;
3. read immediately;
4. if events exist or wait is zero, return immediately;
5. otherwise poll the public stream tip with a monotonic deadline and a bounded 250 ms interval;
6. wake and return when the stream advances, the runtime drains, readiness fails, or the deadline
   expires;
7. return a valid empty page with the current cursor on timeout;
8. never synthesize an event, move a cursor twice, expose an internal-only fact, or use a live
   notification as canonical completion.

Only `events-list` may long poll. At most 16 long polls may exist. Additional attempts receive
HTTP `503` with code `provider-unavailable`, reason `long-poll-capacity-exhausted`, and retry
`same-request`.

A stale retained cursor returns HTTP `409`, code `stale-cursor`, and the exact current refresh
cursor. A future cursor is an invalid request and is never interpreted as stale.

## Mutation Envelope

Every mutation body validates against
`operations-api-mutation-request.schema.json`:

```text
version
project_id
idempotency_key
actor_identity_id
payload
payload_sha256
submitted_at
```

The HTTP `Idempotency-Key` header is mandatory and must equal body `idempotency_key`.
`payload_sha256` is recomputed over canonical payload JSON before any durable API acceptance.

`payload` is discriminated by the exact route ID through
`operations-api-mutation-payload.schema.json`. The binding registry then validates every nested
application document against its selected existing contract and maps every service argument.
Path identifiers must equal their payload equivalents.

The transport may supply only:

- the authenticated identity as the exact actor parameter;
- the original envelope `submitted_at` as the deterministic application timestamp;
- the current `{boot_id, runtime_generation}` runtime fence.

It never invents or overrides role, authority, expected version, idempotency, project, work-item,
command, run, session, workspace, checkpoint, artifact, lease-owner, or lease-generation values.

## Durable API Idempotency

API idempotency is scoped by:

```text
route_id + client_id + project_id + idempotency_key
```

The canonical request digest binds:

- API version;
- resolved route ID and HTTP method;
- normalized path parameters;
- canonical mutation envelope;
- authenticated client ID and identity ID;
- exact route-registry digest;
- exact auth-policy digest.

API idempotency rows use states:

```text
accepted -> executing -> completed
                 |
                 +-> retryable -> accepted
                 |
                 +-> reconcile-required
```

Acceptance flow:

1. finish parsing, authentication, authorization, project/actor binding, schema validation,
   secret scanning, payload digest validation, and readiness;
2. under `BEGIN IMMEDIATE`, insert the API idempotency row as `accepted`;
3. changed reuse of the scoped key returns `409 conflict`;
4. commit acceptance before invoking the application service;
5. set `executing` with the current API boot ID, runtime generation, mutation-scope digest,
   deterministic submitted time, and attempt count;
6. invoke the exact application method with the runtime fence;
7. serialize and schema-validate the exact response;
8. durably store response status, canonical JSON, and digest as `completed`;
9. return the stored bytes.

Duplicate behavior:

- exact `completed`: return the exact stored status/body and
  `Idempotent-Replay: true`;
- exact request owned by the current boot in `accepted` or `executing`: return an authenticated
  `202` status document with `Retry-After: 1`; do not invoke the service again and do not emit an
  SF-003 error tuple;
- only an explicit `DeterministicMutationRejectionError` (or a typed subclass for not-found,
  forbidden, or conflict) may become a permanent terminal response; transport code must never
  infer permanence from exception message text;
- any other canonical service `ProtocolError` with an unchanged journal tip: store a proven
  `retryable` response with HTTP `500`, reason
  `canonical-mutation-not-applied`, mutation state `not-applied`, and retry
  `same-idempotency-key`; the exact request may transition back to `accepted`, increment its
  attempt count, clear the prior response, and execute again;
- `retryable` rows do not block unrelated mutations because unchanged journal identity proves
  that invocation did not commit; changed reuse of the same scoped key still fails closed as an
  idempotency collision;
- changed request: return `409 conflict`, reason `idempotency-collision`, retry `never`;
- row owned by an expired runtime generation: mark `reconcile-required`;
- any `accepted`, `executing`, or `reconcile-required` row makes `mutation_ready=false` and blocks
  every new mutation key until it is completed or independently proven not applied;
- `reconcile-required`: the identical scoped request may bypass the global new-mutation blocker,
  enter `begin_reconciliation()`, and invoke only the route's exact identity-proof replay path
  using the original request and submitted time;
- if the application service proves the original result, store and return it;
- if it cannot prove applied or not-applied state, return `409 uncertain-mutation`, mutation state
  `unknown`, retry `reconcile`, and do not issue another canonical command.

SF-107 uses a read-only reconciliation resolver rather than blindly reinvoking a normal mutation.
The resolver derives and verifies the exact request-bound mutation identity and reconstructs the
historical result from immutable source versions. The original result is returned only when the
complete mutation identity, pre-state, result versions, source rows, journal batch, and response
validator agree. A same-key request that cannot be proven exact fails closed. Foundation and
Component tests must prove all 16 routes; the initial SF-106 methods are not assumed replay-safe
merely because they are idempotent for first execution.

API idempotency records:

- are transport metadata, not journal facts;
- cannot mutate canonical state;
- are included in operations-store integrity, backup, restore, and Gate B comparison;
- reject secret-shaped request or response material;
- are retained without deletion in local Phase 1;
- cannot be reset through HTTP.

## Error Contract

All authenticated API errors validate against `operations-api-error.schema.json`.

The top-level `code`, `retry`, and `mutation_state` use the SF-003 taxonomy. `reason_code`
provides the exact local transport or application reason without inventing contradictory retry
semantics.

| HTTP | SF-003 code | Typical reason | Retry |
|---:|---|---|---|
| 400 | `invalid-request` | malformed JSON, unknown query, invalid token, path/body mismatch | never |
| 401 | `unauthorized` | missing or invalid client/token | never |
| 403 | `forbidden` | route, project, client-kind, role, or actor mismatch | never |
| 404 | `not-found` | unknown route or record | never |
| 405 | `invalid-request` | method not allowed | never |
| 409 | `conflict` | optimistic concurrency or idempotency collision | never |
| 409 | `stale-cursor` | stale event or projection cursor | refresh cursor |
| 409 | `uncertain-mutation` | original effect cannot be proven | reconcile |
| 413 | `invalid-request` | request too large | never |
| 501 | `not-found` | `decision-source-unimplemented` | never |
| 503 | `provider-unavailable` | not ready, long-poll capacity, maintenance | same request |
| 500 | `internal-error` | bounded unexpected internal failure | same request only when not applied |

Rules:

- authentication errors never reveal whether a client ID exists;
- forbidden responses do not reveal cross-project record existence;
- error messages are diagnostic but cannot override code/retry/mutation state;
- details contain only allowlisted scalars, digests, cursor metadata, expected/actual versions,
  and restart/reconcile flags;
- tracebacks and raw exception representations are never returned;
- a mutation exception after durable service invocation is never mapped to a normal retriable
  `500` unless non-application is proven.
- `operation_kind`, `code`, `retry`, and `mutation_state` must match one allowed SF-003 tuple;
- details reject unknown keys and permit only bounded version, cursor, restart, and reconcile
  fields after recursive secret scanning.

A stale event cursor must include the complete current cursor: version, stream ID, generation,
sequence, nullable event ID, nullable snapshot digest, and issued time. A stale projection token
must include `restart_required=true`. Missing, partial, contradictory, or extra cursor details
fail schema validation. Event cursor semantics use the canonical SF-003 cursor validator,
including the zero-sequence/null-event and positive-sequence/non-null-event invariant. The
current cursor must match the exact path project stream and cannot be future-issued.

## Decisions Boundary

The two decisions routes are present because the stable owner API must expose capability truth.

Until a canonical decision source exists:

- `GET /decisions` and `GET /decisions/{decision_id}` call the SF-106 capability boundary;
- both return HTTP `501`;
- the body uses SF-003 code `not-found`, reason `decision-source-unimplemented`, retry `never`,
  and mutation state `not-applicable`;
- capabilities report `decisions.implemented=false`;
- readiness records a `decisions-unimplemented` degradation, not a hard blocker;
- the API never returns an empty list that implies implemented decision storage.

Adding decision mutation or persistence requires a separate task and authority review.

## Runtime Lease And Single-Process Enforcement

SF-107 adds one non-journal runtime table with a single service row.

The row binds:

- service and boot ID;
- monotonic runtime generation;
- status;
- process and host observation;
- route-registry and auth-policy digests;
- start, heartbeat, and lease-expiry timestamps;
- record digest.

Rules:

- startup claims or renews the service row under `BEGIN IMMEDIATE`;
- an unexpired row owned by another boot rejects startup;
- runtime generation increments on every accepted new boot;
- lease duration is 5 seconds and heartbeat interval is 1 second;
- a process never force-steals an unexpired lease;
- process ID and host ID are observations, not authority;
- every mutation acceptance checks the current boot and generation;
- every exposed application mutation receives an explicit runtime-fence argument;
- immediately after `BEGIN IMMEDIATE` and immediately before commit, the same canonical
  transaction verifies the runtime row has the supplied boot ID and generation and that its
  lease has not expired at the transaction's current UTC time;
- an application writer holding SQLite's write lock prevents a successor from claiming a new
  generation; if the old writer outlives its lease, its pre-commit check rolls back before the
  successor can claim;
- an old process that begins after a successor claim observes a generation mismatch and rolls
  back before any canonical write;
- loss of the lease stops new requests, marks readiness false, and begins drain;
- stale boot ownership cannot complete an API idempotency row;
- expired ownership changes unfinished rows to `reconcile-required`;
- graceful shutdown marks the runtime `draining`, stops mutation and long-poll admission, waits up
  to 10 seconds, then marks it `stopped`;
- process death leaves the lease to expire and is recovered by the next boot.

Runtime-record semantics additionally require `started_at <= heartbeat_at < lease_expires_at`,
no future heartbeat, and an exact five-second lease interval for `starting`, `ready`, or
`draining`. `expired` and `stopped` rows cannot retain a future lease. API idempotency timestamps
must satisfy `accepted <= service-started <= completed <= updated` for the timestamps present.

The runtime lease is local process fencing only. It does not replace a dispatch lease, Elder
runtime lease, identity, role, approval, or canonical authority.

## Health And Readiness

### Liveness

`GET /health/live`:

- performs no SQLite access;
- returns `200` while the handler and process loop can respond;
- includes service, boot ID, runtime generation, checked time, and uptime;
- reports no canonical readiness claim.

It validates against `operations-api-liveness.schema.json`, whose only status is `alive`.
Semantic validation requires `checked_at` to be within one second of authoritative current UTC
in both directions. A stale or future-dated liveness document is invalid even when its content
digest is internally consistent.

Authenticated detailed health includes the exact readiness snapshot digest and readiness checked
time. Health validation rejects a snapshot digest or timestamp that does not match the readiness
object used to produce the dependency summary. Its status must equal the bound readiness status,
dependency observations cannot be future-dated, and a required failed or unimplemented
dependency cannot coexist with `ready=true`.

### Full verification monitor

At startup and at least every 5 seconds, a background verifier checks:

- route-registry schema, semantic invariants, and digest;
- authentication-policy schema, time window, semantic invariants, and digest;
- current runtime lease and generation;
- operations-store access and schema versions;
- journal metadata, readiness, triggers, source bindings, sequence, and hash-chain integrity;
- all public streams;
- all seven active projection generations, row digests, and checkpoints;
- projection tip equality with the current journal tip;
- API idempotency and runtime-table schema/integrity;
- capability status;
- latest backup status and age;
- database and WAL warning thresholds;
- unresolved API reconciliation rows, uncertain dispatches, and dead letters.

The monitor stores an immutable in-memory snapshot and its canonical digest. It does not repair
state.

### Readiness

`GET /health/ready` and authenticated `GET /v1/readiness` compare the cached verification
journal tip with a fresh lightweight tip read. If they differ, verification is stale and
readiness fails until the monitor verifies the new state.

Hard blockers:

- route registry missing, changed, or invalid;
- auth policy missing, expired, changed, or invalid;
- current runtime lease missing, lost, or mismatched;
- service draining or maintenance mode;
- operations store unavailable or schema incompatible;
- journal not ready or integrity failure;
- public stream integrity failure;
- any required active projection missing, corrupt, failed, or behind the journal tip;
- full verification older than 15 seconds;
- API runtime or idempotency-table integrity failure.

Mutation blockers, represented separately from read readiness:

- any API idempotency row in `accepted`, `executing`, or `reconcile-required`;
- any runtime-fence verification failure;
- any mutation replay proof failure awaiting accountable reconciliation.

Degradations:

- decisions capability unimplemented;
- no successful operations backup;
- latest successful backup older than 24 hours;
- database or WAL warning threshold exceeded;
- full replay duration above the configured warning target;
- uncertain dispatches or dead letters exist.

HTTP behavior:

- no blockers, no degradations: `200`, `ready=true`, status `ready`;
- no blockers, one or more degradations: `200`, `ready=true`, status `degraded`;
- one or more blockers: `503`, `ready=false`, status `not-ready`.
- no mutation blockers: `mutation_ready=true`;
- one or more mutation blockers: `mutation_ready=false`; authenticated reads may remain ready but
  all mutation routes return `503 provider-unavailable` with
  `mutation-reconciliation-required`.

Before the first successful full verification, `last_full_verification_at` is null and
`verification_state` is `pending` or `failed`; readiness is false. Projection IDs must be the
exact seven unique IDs, every active projection must equal the verified journal tip, and schema
validation is followed by semantic cross-field validation.

When readiness is true, both the last full verification and last verification attempt must be no
older than `min(maximum_verification_age_seconds, 15)` at authoritative current UTC time, allowing
at most one second of declared clock tolerance. `checked_at` cannot be farther in the future than
that tolerance. Journal sequence zero requires null tip ID and digest; a positive sequence
requires both. These rules prevent a future-dated or stale cached snapshot, or an incomplete
journal tip, from reporting ready.

Readiness is evidence that implemented API routes can be served safely. It is not evidence that
all planned factory capabilities, hosted controls, autonomy, deployment, or production operation
exist.

## Request Admission During Degradation

- liveness remains available while the process can respond;
- detailed health/readiness remains available even when not ready;
- capabilities remain available only when authentication and route policy are valid;
- all readiness-required routes return `503` while not ready;
- no mutation is accepted during `not-ready`, `mutation_ready=false`, `draining`, or maintenance
  state;
- a degraded-but-ready state permits implemented routes;
- decision routes remain explicit `501`;
- no read falls back to stale or corrupt canonical tables.

## Observability And Audit

Each request receives a server-generated `request-<32 hex>` identifier.

Structured request audit fields:

- request ID;
- route ID and method;
- authenticated client ID digest, not raw token;
- actor identity ID only after authentication;
- project ID;
- idempotency-key digest for mutations;
- response status and SF-003 code/reason;
- duration;
- API boot ID and runtime generation;
- canonical mutation ID, journal range, or projection metadata when returned by the service.

Forbidden log content:

- authorization header;
- raw bearer token or token digest;
- complete request or response body;
- raw query string or continuation token;
- secret, personal contact, payment, prompt, model-output, or credential content;
- SQL statement or database path;
- traceback.

The API request audit is diagnostic evidence. It does not become a canonical journal, command,
approval, or telemetry authority.

## Backup And Restore

The SF-106 operations backup must be extended during implementation to include:

- API idempotency table;
- API runtime schema metadata, but not an active runtime lease as restorable ownership;
- route-registry and auth-policy digests recorded in API metadata;
- logical row digests for API idempotency.

Restore rules:

- restore is an offline operator operation only;
- the API process and any claimant process must be stopped and the runtime lease must be expired;
- restore first builds and verifies a transformed temporary database;
- runtime rows restore only as `expired`;
- the new process claims a new boot ID and generation;
- unfinished idempotency rows become `reconcile-required`;
- completed exact responses remain replayable;
- auth policy bytes are not copied into the operations backup;
- the operator supplies and revalidates the current policy separately;
- restored canonical journal and projection identity must remain equal to source backup identity.
- only after transformed integrity succeeds may the operator atomically replace the target
  database; on Windows no live connection may remain open against the target path.

## Gate B Kill-And-Restart Proof

The Phase 1 exit workflow uses separate real API, internal claimant, and offline operator
subprocesses against one temporary operations store and one test auth policy. Production HTTP
does not expose claim, renewal, projection rebuild, backup, or restore.

### Scenario A: queued work

1. Start the API on an ephemeral loopback port.
2. Create or load one active Product Factory and work item.
3. queue the work item and durably submit one dispatch command;
4. confirm the API response and journal/projection state;
5. terminate the API process without graceful shutdown before claim;
6. wait only for the bounded runtime lease expiry;
7. restart against the same store and policy;
8. prove the accepted dispatch remains queued exactly once;
9. prove work-item, command, journal, event cursor, and projections are unchanged except for
   expected API runtime metadata.

### Scenario B: leased work

1. Start a separate factory-owned claimant subprocess that invokes the internal SF-104 claim path
   against the same store and persists its owner ID and lease generation.
2. Synchronize on a retained `claimed` barrier file written after the claim commit.
3. Terminate the API process while the claimant and dispatch lease remain active.
4. Restart after API runtime lease expiry.
5. prove the dispatch lease remains canonical and is not treated as completed;
6. terminate the claimant and prove a stale old-owner/generation completion is rejected;
7. allow the dispatch lease to expire and recover through a new claimant subprocess using the
   existing SF-104 path;
8. prove no duplicate adapter effect or journal source appears.

### Scenario C: response loss after canonical commit

1. Launch the API through the test harness with a test-only injected
   `after-service-commit-before-api-complete` barrier; the production CLI has no failpoint flag.
2. wait for the retained barrier proving the canonical service commit, then terminate the API
   before API response persistence or socket write.
3. Restart.
4. resend the exact request with the same API idempotency key.
5. move the row to reconciliation and invoke only the exact identity-proof replay path;
6. return the proven canonical result;
7. prove one canonical mutation, one immutable source batch, one journal batch, and one API
   completed response.

### Scenario D: projection rebuild

1. Stop the API and wait for runtime lease expiry.
2. Use a separate offline operator subprocess to record pre-rebuild counts and digests, delete
   only disposable projection generations, and invoke the existing projection rebuild CLI.
3. verify all seven rebuilt projections against the journal before restarting the API;
4. restart and compare counts and exact projection digests with pre-kill values;
5. resume query pagination only from a fresh first page;
6. prove old continuation tokens fail stale.

Gate B closes only when all four scenarios pass and the complete ordered repository ladder is
green. Each scenario retains subprocess command lines, process IDs, barrier timestamps, runtime
generations, before/after logical snapshots, journal tips, projection digests, API responses, and
test duration.

## Failure Matrix

| Failure | Required result |
|---|---|
| non-loopback bind | startup rejection |
| missing/invalid/expired auth policy | startup or readiness failure |
| wrong token | `401`, no existence disclosure |
| valid token, wrong route/project/client kind/role | `403` |
| actor differs from authenticated identity | `403` |
| worker-observer mutation attempt | `403` |
| malformed or duplicate-key JSON | `400` |
| oversized or chunked body | `413` or `400`, connection safely closed |
| changed API idempotency replay | `409 conflict` |
| same request currently executing | `202` status only, no second invocation |
| operational failure with unchanged journal tip | `500`, proven not applied, same key retry |
| response lost after canonical commit | reconciliation and exact replay, no duplicate effect |
| unknown mutation state | `409 uncertain-mutation`, reconcile only |
| stale projection token | `409 stale-cursor`, restart page |
| stale event cursor | `409 stale-cursor`, refresh cursor |
| future cursor | `400 invalid-request` |
| long-poll capacity exhausted | `503`, no unbounded thread |
| decision read | `501 decision-source-unimplemented` |
| journal corruption | readiness `503`, all dependent routes blocked |
| active projection corruption or lag | readiness `503`, no canonical-table fallback |
| missing/stale backup | degraded, not false healthy |
| runtime lease lost before application commit | canonical transaction rollback, then drain |
| restored active runtime row | forced expired; new generation required |
| traceback or secret-shaped error detail | response rejection and generic bounded error |

## Test Ladder

Run one level at a time:

```text
Foundation -> Component -> Integration -> Workflow -> Stress
```

Accepted failure ceilings:

| Level | Ceiling |
|---|---:|
| Foundation | 15 minutes |
| Component | 45 minutes |
| Integration | 30 minutes |
| Workflow | 30 minutes |
| Stress | 60 minutes |
| build and installed wheel | 45 minutes |

### Foundation

- all new schemas validate and remain in the package catalog;
- route registry digest, uniqueness, exact count, path placeholders, method/path uniqueness,
  client kinds, canonical roles, service references, contracts, and status codes;
- all `/v1` routes require auth and both health routes do not;
- all mutation routes require project scope, readiness, bearer auth, API idempotency, and exact
  canonical identity fields;
- no worker-observer mutation;
- no internal claim, renew, response, retry, uncertainty, observation, compensation, projection
  reset/rebuild, backup/restore, raw SQL, or journal append route;
- auth-policy digest, date window, unique client/token/identity, exact route/project scope, and
  client-kind compatibility;
- binding-registry digest, exact route coverage, path/query declarations, nested schemas, service
  signatures, equality bindings, response validators, runtime fences, replay proofs, and mutation
  scopes;
- success, error, health, readiness, runtime, mutation, and idempotency fixtures;
- SF-003 error-code/retry/mutation-state consistency;
- negative cross-field fixtures for false readiness, invalid idempotency states, expired runtime
  rows, duplicate auth identities, terminal-route drift, and unsafe error tuples;
- request and response secret rejection.

### Component

- strict request parsing and all transport limits;
- bearer authentication constant-time behavior without information disclosure;
- route, client-kind, project, role, and actor enforcement;
- the current 46 routes and method-not-allowed behavior;
- query filter and pagination mapping;
- stale and malformed projection token mapping;
- event cursor initial/current/stale/future/wrong-project behavior;
- bounded long poll success, timeout, readiness wake, drain wake, and capacity rejection;
- every exposed mutation service exact replay;
- API idempotency acceptance, completed replay, changed collision, current execution, stale boot,
  reconciliation, and uncertain result;
- error envelope mapping;
- liveness without store;
- readiness hard blockers and degradations;
- runtime lease claim, heartbeat, expiry, generation, second-process rejection, and graceful
  drain;
- canonical transaction rejection when a runtime fence expires or changes before commit;
- API idempotency and runtime backup/restore behavior.

### Integration

- real loopback HTTP server with temporary auth policy and operations store;
- product, signal, work item, transition, command, run, event, capability, journal, and projection
  routes through real application services;
- cross-project and cross-client denial;
- actor/role/authority mismatch denial before canonical mutation;
- one API mutation produces the exact existing source and journal facts;
- process crash before invocation, during execution, after canonical commit, and before response;
- exact duplicate returns one durable response without repeating canonical effects;
- restored store replays completed responses and reconciles unfinished requests;
- readiness follows real journal and projection corruption/degradation.

### Workflow

- owner creates work, transitions it, observes dispatch/run state and timeline, and resumes events
  after API restart;
- integration ingests a signal and owner converts it to a work item;
- factory-service binds and updates one run while worker-observer remains read-only;
- decisions endpoints and capability report remain truthful;
- full Gate B scenarios A through D with retained subprocess and comparison evidence.

### Stress

- concurrent exact and changed idempotency keys;
- concurrent clients and project isolation;
- request and long-poll admission limits;
- append during event long poll;
- repeated kill/restart and runtime-generation fencing;
- response-loss injection across every exposed mutation family;
- large bounded query and event pages;
- slow-client and oversized-request handling;
- auth-policy and route-registry drift during startup;
- journal/projection corruption under load;
- `ResourceWarning` promoted to an error.

When a level fails, record root cause, fix it, and rerun that same level before advancing.

## Acceptance Evidence

SF-107 closes only when evidence proves:

1. the server cannot bind outside numeric loopback;
2. every `/v1` route requires a current valid bearer-policy client;
3. route, project, client-kind, role, and actor scopes are exact and fail closed;
4. worker observers cannot mutate canonical state;
5. all route request and response contracts are strict and packaged;
6. every exposed mutation is durable, API-idempotent, and exact-service-replay safe;
7. response loss after canonical commit cannot repeat an effect;
8. uncertain mutation state permits reconciliation only;
9. queries preserve exact SF-106 ordering, metadata, and stale-token behavior;
10. public-event long polling preserves SF-003 cursor identity and is bounded;
11. decision capability is explicit and never fabricated;
12. liveness does not imply readiness;
13. readiness fails on policy, runtime lease, store, journal, projection, or verification failure;
14. degradations remain visible without falsely blocking safe implemented routes;
15. API runtime and idempotency state survive backup/restore without restoring stale ownership;
16. queued and leased work survive process termination without lost state or duplicate effects;
17. all seven projections rebuild to equal counts and digests after restart;
18. the complete ordered repository ladder passes within the accepted ceilings;
19. the installed wheel contains the exact SF-107 contracts, runtime, CLI, tests, design,
    reproduction, and evidence inventory;
20. independent implementation/test review has no unresolved Critical or High finding.

## Closure Inventory

The implementation review and installed-wheel proof must account for this exact SF-107-owned
surface:

```text
elder_protocol/factory_operations/api_contracts.py
elder_protocol/factory_operations/api_auth.py
elder_protocol/factory_operations/api_store.py
elder_protocol/factory_operations/api_idempotency.py
elder_protocol/factory_operations/api_health.py
elder_protocol/factory_operations/api_projection_validation.py
elder_protocol/factory_operations/api_reconciliation.py
elder_protocol/factory_operations/api_service.py
elder_protocol/factory_operations/api_server.py
elder_protocol/factory_operations/__init__.py
elder_protocol/factory_operations/journal.py
elder_protocol/factory_operations/journal_store.py
elder_protocol/factory_operations/operations_store.py
elder_protocol/factory_operations/operations_backup.py
elder_protocol/factory_operations/product_registry.py
elder_protocol/factory_operations/signal_intake.py
elder_protocol/factory_operations/work_item_ledger.py
elder_protocol/factory_operations/transition_engine.py
elder_protocol/factory_operations/durable_dispatcher.py
elder_protocol/factory_operations/run_controller.py
elder_protocol/factory_operations/projections.py
elder_protocol/cli.py
elder_protocol/cli_parser.py
pyproject.toml
setup.py
MANIFEST.in
scripts/verify_installed_wheel.py
factory/operations/operations-api-*.schema.json
factory/operations/operations-api-route-registry.json
factory/operations/operations-api-binding-registry.json
factory/operations/run-checkpoint-worker-observation.schema.json
tests/foundation/test_operations_api_design.py
tests/foundation/test_product_factory_registry.py
tests/component/test_operations_api_*.py
tests/integration/test_operations_api_*.py
tests/workflow/test_sf107_gate_b.py
tests/stress/test_operations_api_concurrency.py
docs/software-factory/SF-107-design.md
docs/software-factory/SF-107-test-reproduction.md
docs/software-factory/SF-107-evidence.md
```

The implementation may consolidate modules only if the evidence inventory records the reviewed
replacement path and no responsibility disappears. Foundation must compare the final tracked
diff against this inventory and fail on an unaccounted implementation or packaging path. The
installed-wheel lifecycle must prove:

```text
elder factory operations-api --store ... --auth-policy ... --host 127.0.0.1 --port 0
GET /health/live
GET /health/ready
authenticated GET /v1/capabilities
authenticated mutation and exact completed replay
graceful shutdown
crash restart after lease expiry
offline operations-backup-verify and operations-restore
offline operations-rebuild
```

The reproduction record must pin interpreter, wheel digest, source revision, route and binding
digests, policy digest, commands, start/end timestamps, durations, test counts, warnings,
subprocess exit codes, retained artifact paths, and Gate B before/after logical snapshots.

## Implementation Sequence

After independent design acceptance:

1. add contract validators for route, auth, mutation, response, error, runtime, idempotency,
   health, and readiness documents;
2. add API metadata, runtime lease, and idempotency tables without making them journal sources;
3. extend operations backup, restore, and integrity to cover API metadata;
4. implement strict route resolution, request parsing, response serialization, and bounded
   request/long-poll admission;
5. implement auth-policy loading, digest/time validation, constant-time bearer authentication,
   route/project/client-kind/role checks, and actor binding;
6. implement read facade over SF-106 queries and event cursors;
7. implement durable API idempotency and exact replay adapters over the 16 exposed mutations;
8. implement error translation with explicit post-invocation uncertainty handling;
9. implement runtime lease, heartbeat, drain, restart reconciliation, and health monitor;
10. add `elder factory operations-api` CLI with required store and auth-policy paths, numeric
    loopback host, explicit port, and no remote fallback;
11. run Foundation and fix/rerun Foundation;
12. run Component and fix/rerun Component;
13. run Integration and fix/rerun Integration;
14. run Workflow including Gate B subprocess scenarios;
15. run Stress with `ResourceWarning` as error;
16. run protocol, skill, compile, diff, build, and installed-wheel closure;
17. obtain independent implementation review;
18. publish reproduction and evidence documents;
19. update software-factory status and Obsidian;
20. request explicit permission before staging or committing.

## Final Implementation Review Gate

Closure required independent review to confirm:

- no protected SF-002/SF-003 contract is silently changed;
- authentication is a transport boundary rather than a substitute for authority;
- worker non-authority is preserved;
- every mutation route is exact-replay safe across the HTTP response-loss window;
- project and actor binding cannot be confused;
- event and pagination cursor semantics remain exact;
- readiness is neither too weak nor permanently blocked by an intentionally unavailable
  capability;
- runtime lease and restore behavior cannot create split-brain API ownership;
- Gate B proof exercises real process termination and not only object re-instantiation;
- no Critical or High finding remains.

## Historical Provisional Local Acceptance

The final post-remediation implementation was accepted on 2026-08-12 for the declared local
scope. The accepted implementation includes:

- type-driven terminal mutation rejection and a distinct retryable non-application state;
- exact same-key retry only when the immutable journal proves no canonical mutation committed;
- stale event-cursor responses bound to the authoritative current cursor;
- journal-backed event waits that continuously revalidate runtime ownership, contract/auth
  bindings, API-store integrity, and journal availability without requiring unrelated
  projections to remain current while a new event is being published;
- cached readiness that performs a fresh full verification when the journal tip or mutation
  readiness changes;
- bootstrap heartbeat coverage through the potentially long initial full verification while
  retaining the exact five-second active runtime lease;
- installed-wheel startup with bounded 60-second readiness and deterministic process cleanup;
- four process-boundary Gate B scenarios and the complete ordered repository ladder.

Complete pre-final ordered evidence:

```text
Foundation: 112 passed in 34.611s
Component: 284 passed across complete bounded batches
Integration: 50 run in 822.680s; 49 passed, 1 explicit live-Azure skip
Workflow: 22 passed in 399.214s
Stress: 32 passed in 809.936s with ResourceWarning promoted to error
```

Post-review transport-delta evidence:

```text
SF-107 Component: 36 passed in 308.152s
Workflow: 22 passed in 386.462s
SF-107 Stress: 8 passed in 286.975s with ResourceWarning promoted to error
Independent review: no current-scope BLOCKER or REQUIRED code finding
```

Protocol validation, skill-registry validation, bytecode compilation, diff hygiene, package
build, and isolated installed-wheel verification are part of the retained closure procedure.

The worktree remains unstaged and uncommitted pending explicit human authorization.

## Phase-Proportional Transport Reconciliation

The post-acceptance audit correctly identified one current-scope defect and two groups of
production-strength concerns. The phase-proportional delivery rule requires the current defect
to be fixed and the stronger claims to be removed from Gate B rather than expanded into a new
transport architecture.

### Required authenticated long-poll admission

The total 64-request semaphore remains a transport-level bound. The scarcer 16-slot long-poll
capacity belongs to the application service and is acquired only after:

1. strict request framing and bounded body handling;
2. exact method and route resolution;
3. exact query parsing and validation;
4. bearer authentication;
5. client-kind, route, project, canonical-role, and actor authorization;
6. route-specific readiness admission.

Only the authenticated `events-list` route with `wait_seconds > 0` can acquire a long-poll slot.
Unknown routes, wrong methods, malformed queries, unauthenticated clients, unauthorized clients,
and partial requests cannot consume that capacity. The service releases the slot in `finally`.
The HTTP server retains only the total request bound and does not infer long-poll eligibility
from a path suffix.

### Boot-bound configuration and readiness

The route registry, binding registry, and authentication policy are boot-bound for one active
process. A configuration change requires a controlled restart. Health verification may detect
that the on-disk bytes no longer match the active runtime bindings and report not-ready, but
SF-107 does not claim an operating-system-wide tamper lock.

The background verifier maintains bounded local diagnostic evidence. Request admission rechecks
the active runtime lease and uses the current validated readiness snapshot. Journal movement or
mutation-readiness movement triggers a new complete verification. Event waits additionally
revalidate runtime ownership, route and policy bindings, API-store integrity, and journal
integrity without requiring unrelated projections to remain current.

Liveness, readiness, and detailed health are validated against each route's declared response
type immediately before the application service returns them. A not-ready health route returns
its declared readiness or health document with the matching HTTP status; it does not substitute
an unrelated generic response shape.

Canonical mutation safety remains inside the existing application transaction and active runtime
generation fence. SF-107 does not perform a complete journal and all-projection verification
inside every response publication.

### Normal graceful drain

Graceful drain uses normal local service semantics: requests admitted before drain may finish;
drain blocks new admissions and wakes bounded event waits through the runtime readiness checks.
The implementation does not claim that no response byte can cross the drain transition. Exact
mutation recovery remains the durable API idempotency record plus canonical transaction and
journal evidence, not a socket-publication lock.

### Deferred production transport guarantees

The following concerns are valid hardening topics but are outside the declared Phase 1 local
loopback threat model:

- byte-level publication locks or a first-status-byte commit protocol;
- public-network adversaries and hostile slow-client guarantees;
- multi-process fairness or distributed verification coordination;
- arbitrary external same-tip SQLite or file tamper exclusion;
- production load-balancer drain and zero-race response publication guarantees.

They are `DEFERRED` to the hosted operational work that owns remote transport, workload identity,
central telemetry, production traffic management, and qualified failure injection. They are not
Gate B blockers and the superseded
`factory/operations/operations-api-transport-boundary.json` design note is removed.

## Phase Boundary

SF-107 closes Phase 1 because the proportional correction passed the ordered relevant test
ladder and independent implementation review reported no unresolved current-scope `BLOCKER` or
`REQUIRED` finding.

Gate B does not authorize:

- a real Codex worker flow;
- physical isolated workspace provisioning;
- owner control-room UI;
- decision persistence;
- remote or hosted API access;
- production identity, secrets, telemetry, alerting, backup operations, or deployment;
- autonomous merge, release, promotion, learning application, or maturity change.

After Gate B, the next roadmap task is the Phase 2 worker adapter and issue-to-evidence flow. It
must consume the API and operations kernel without weakening this local authority, idempotency,
event, health, or restart contract.
