# SF-206 - Worker Recovery And Reconciliation

**Status:** VERIFIED

**Change class:** bounded local worker-runtime implementation

**Owner:** factory operations

**Approver:** human repository owner

**Dependencies:** SF-200, SF-202, SF-203, SF-205

**Source revision:** `56faa4d8eb7abd010e3d6ba798932fa75049045d`

## Outcome

The local operations process can discover interrupted worker controls, inspect
the exact worker session generation, reconcile exact adapter effects, safely
requeue only effects proved not applied, converge cross-store state after
restart, and persist owner-visible terminal recovery cases and orphan findings.

## Non-Goals

- accepting an unverifiable duplicate recovery response;
- fabricating a lost start reference, checkpoint payload, or usage accounting;
- force-cleaning, deleting, or reusing an orphaned workspace;
- hosted workers, distributed recovery, Phase 3 owner UI, merge, release, or
  deployment;
- claiming Gate C without one composed real-Codex issue-to-evidence restart
  proof.

## Required Guarantees

- one recovery case is bound to one exact uncertain SF-203 record version;
- recovery request identity is durable before adapter invocation;
- one worker recovery observation can serve only the exact eligible control
  versions in that session generation;
- an effect is retried only after the worker proves it was not applied;
- succeeded effects are never replayed to reconstruct missing data;
- start and checkpoint remain owner-required when indispensable response data
  was lost;
- cancellation can complete only from exact worker evidence and canonical
  lifecycle authority;
- SF-205 dependent work stops as uncertain on unresolved recovery but successful
  usage remains explicitly accounted;
- missing scheduled controls, control digest drift, known-run workspace drift,
  and manifests without canonical runs are durable orphan findings;
- cross-store restart converges from persisted SF-203 reconciliation evidence.

## Failure Conditions

- a recovery sweep blindly resubmits an uncertain effect;
- a prior recovery episode is reused for a later control attempt;
- two uncertain controls in one session cause duplicate worker recovery calls;
- a lost recovery response is accepted without the original durable exchange;
- a terminal goal or tick is rewritten;
- a workspace orphan is deleted, unlocked, or reused automatically;
- SQL scalar metadata can drift from immutable recovery JSON undetected.

## Phase Proportionality

Current phase: Phase 2 Worker Runtime.

Declared runtime: Windows local loopback, SQLite, one operations process, one
active control execution, local worker adapter stores, and local SF-202
worktrees.

All mandatory Phase 2 task implementations were verified after SF-206. At
SF-206 closure, formal Gate C remained unclaimed pending the separate composed
live proof. That proof later passed on 2026-08-13; see
[Gate C evidence](evidence/Gate-C.md).

## Test Plan

1. Foundation: closed schemas, exports, digests, exact request acceptance, and
   secret rejection.
2. Component: before-effect requeue, after-effect convergence, start,
   checkpoint, cancel, multi-control observation reuse, episode fencing, and
   orphan discovery.
3. Integration: controller/recovery restart and cross-store commit-order
   convergence.
4. Workflow: SF-205 recovery with explicit accounting and fail-closed lost
   recovery response.
5. Stress: concurrent sweeps invoke worker recovery once.

## Completion Gate

SF-206 closes only after the focused ordered ladder passes, independent review
has no current-scope blocker or required finding, package installation is
verified, evidence is recorded, and the task is committed separately before
any Phase 3 implementation begins.

## Completion

The implementation, focused ladder, independent review reconciliation,
package checks, and closure evidence pass for the declared local scope. See
[design](SF-206-design.md),
[test reproduction](SF-206-test-reproduction.md), and
[evidence](evidence/SF-206.md).
