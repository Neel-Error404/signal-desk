# SF-403 Evidence And Test Pipeline Design

**Status:** VERIFIED

## Composition

```text
current work-item evidence plan
-> active SF-402 authority and context
-> immutable ordered test plan
-> exact Git diff fingerprint
-> ordered result and artifact ingestion
-> independent advisory evaluation
-> completion evidence packet
-> existing human accept-outcome transition
```

The pipeline does not replace the Work Item Ledger, transition engine, SF-402
lease, Git, evaluator authority boundaries, or run artifact records.

## Diff Binding

The repository fingerprint binds baseline commit plus sorted changed paths,
status codes, and exact file SHA-256 values. The immutable plan, every result,
the evaluation request, and completion packet must refer to the same
fingerprint. A post-test edit blocks completion.

## Result Rules

- levels follow `Foundation`, `Component`, `Integration`, `Workflow`, `Stress`;
- only levels named by the work-item evidence plan are required;
- the exact planned command must be reported;
- exit code and verdict must agree;
- a failed accepted result blocks all later ingestion;
- result recording may trail completion by at most one hour;
- artifact paths stay within the repository and exact bytes must match;
- traces reject secret-shaped names, values, and references.

## Evaluation

Evaluation remains independent, advisory-only, and unable to approve or
promote. The evaluator differs from the executor and the response binds the
exact results and diff request. Completion requires verdict `pass`.

## Completion

The completion packet is evidence, not approval. It exposes
`validated_evidence_ref` and `outcome_record_ref`; the existing product-owner
`accept-outcome` transition retains completion authority.

## Durability

Plans, results, evaluation requests, evaluations, and completion packets use a
separate SQLite WAL store with immutable content digests and exact replay.

## Non-Claims

No CI service, hosted evaluator, provider call, merge, pull request, release,
deployment, SF-404 implementation, or maturity increase is claimed.
