# SF-104 Test Reproduction

## Purpose

This runbook reproduces the complete evidence required to close SF-104 while preserving the
governed order:

```text
Foundation -> Component -> Integration -> Workflow -> Stress
```

Stop on the first failed or timed-out level. Diagnose the root cause and rerun that same level
before advancing.

## Interpreter

Use the exact installed interpreter:

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'
& $python --version
```

The verified interpreter reported Python 3.13.5.

## Runtime Budget

| Level | Final unittest runtime | Final wall time | Command timeout | Expected result |
|---|---:|---:|---:|---|
| Foundation | 24.836s | 25.187s | 10 minutes | 78 passed |
| Component | 234.547s | 235.019s | 25 minutes | 214 passed |
| Integration | 104.691s | 105.069s | 20 minutes | 34 run, 33 passed, 1 skipped |
| Workflow | 57.703s | 58.088s | 10 minutes | 15 passed |
| Stress | 149.949s | 150.336s | 20 minutes | 20 passed |

Total unittest runtime was 571.726 seconds. Total measured wall time was 573.699 seconds.

Do not treat command silence as success. A level is complete only after unittest prints its final
summary and the process exits with code zero.

## Complete Ladder

Run each command separately from the repository root:

```powershell
$python = 'C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe'

& $python -m unittest discover -s tests/foundation -v
& $python -m unittest discover -s tests/component -v
& $python -m unittest discover -s tests/integration -v
& $python -m unittest discover -s tests/workflow -v
& $python -W error::ResourceWarning -m unittest discover -s tests/stress -v
```

The Integration skip is the existing opt-in live Azure Mem0 and Luna test:

```text
Set ELDER_RUN_LIVE_MEMORY_TESTS=1 to exercise Azure Mem0 and Luna.
```

It is outside SF-104 because the dispatcher is local, provider-neutral, and network-free.

## Focused Commands

```powershell
& $python -m unittest `
  tests.foundation.test_durable_dispatcher `
  tests.foundation.test_product_factory_registry -v

& $python -m unittest tests.component.test_durable_dispatcher -v
& $python -m unittest tests.integration.test_queued_work_item_dispatch -v
& $python -W error::ResourceWarning -m unittest `
  tests.stress.test_durable_dispatcher_concurrency -v
```

## Coverage

| Requirement | Primary reproducing test |
|---|---|
| SF-003 command and adapter-request reuse | `tests/foundation/test_durable_dispatcher.py` |
| Binding drift, unknown fields, and secret rejection | `tests/foundation/test_durable_dispatcher.py` |
| Explicit response matrix and local bounds | `tests/foundation/test_durable_dispatcher.py` |
| Submission replay, collision, and queue lineage | `tests/component/test_durable_dispatcher.py` |
| Claim, renewal, completion, and restart | `tests/component/test_durable_dispatcher.py` |
| Monotonic generation and stale-owner fencing | `tests/component/test_durable_dispatcher.py` |
| Safe retry, backoff, exhaustion, and dead letter | `tests/component/test_durable_dispatcher.py` |
| Uncertainty and explicit reconciliation | `tests/component/test_durable_dispatcher.py` |
| Callback loss and diagnostic scrubbing | `tests/component/test_durable_dispatcher.py` |
| Deadline expiry and offset-aware ordering | `tests/component/test_durable_dispatcher.py` |
| Cancellation, shutdown, and tamper detection | `tests/component/test_durable_dispatcher.py` |
| SF-103 queued boundary and no direct stage mutation | `tests/integration/test_queued_work_item_dispatch.py` |
| Concurrent exact submission and one local claim | `tests/stress/test_durable_dispatcher_concurrency.py` |
| Actual subprocess kill after execution start | `tests/stress/test_durable_dispatcher_concurrency.py` |
| Backlog order across terminal rows | `tests/stress/test_durable_dispatcher_concurrency.py` |
| Existing-system regression safety | Every complete ladder level |

## Additional Verification

```powershell
& $python -m elder_protocol.cli validate
& $python -m elder_protocol.cli skills validate
& $python -m py_compile `
  elder_protocol/factory_operations/durable_dispatcher.py `
  elder_protocol/factory_operations/__init__.py `
  tests/foundation/test_durable_dispatcher.py `
  tests/component/test_durable_dispatcher.py `
  tests/integration/test_queued_work_item_dispatch.py `
  tests/stress/test_durable_dispatcher_concurrency.py

git diff --check
& $python -m build --no-isolation
```

`--no-isolation` uses the repository's declared local build tooling without requiring a network
download in the sandbox.

Install the resulting wheel into a fresh target outside the checkout import path and verify:

1. `elder_protocol.constants.ROOT` resolves under the installed package `_kernel`;
2. `DurableDispatcher` imports;
3. the installed operations catalog contains twelve schemas;
4. the SF-104 design, evidence, and reproduction documents are packaged.

## Failure Discipline

The observed development failures and their resolved root causes are recorded in
[`evidence/SF-104.md`](evidence/SF-104.md). A reproducer must not weaken fencing, bypass
uncertainty, ignore resource warnings, or increase timeouts as a substitute for a complete test
summary.

## Next Task

After SF-104 is committed with explicit human approval, the next eligible task is:

```text
SF-105 - Run, Session, And Workspace Binding
```

SF-105 must be designed before implementation. Gate B remains open through SF-107.
