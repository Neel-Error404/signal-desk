# SF-305 Implementation Plan

**Status:** COMPLETED

**Date:** 2026-08-14

1. Add a closed project metrics snapshot contract with definitions,
   availability, missing-data, and reconciliation fields.
2. Aggregate work-item, dispatch, run, owner, and artifact records without
   copying high-cardinality identities or sensitive text.
3. Compute finite duration summaries and exact source-family counts.
4. Keep cost and learning impact unavailable until trustworthy records exist.
5. Add the authenticated project metrics API route and control-room view.
6. Run the invalidated Foundation through Stress ladder in order.
7. Verify responsive browser behavior and isolated installed-package contents.
8. Perform focused review, finalize evidence, update Obsidian, commit SF-305
   separately, and stop before SF-400.

No protected telemetry, authority, or maturity surface is modified.
