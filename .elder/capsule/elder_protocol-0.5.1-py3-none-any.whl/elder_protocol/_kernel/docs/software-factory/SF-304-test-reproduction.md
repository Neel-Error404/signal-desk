# SF-304 Audit And Replay View Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Ordered Test Ladder

Only invalidated modules were run. A first Foundation command referenced a
nonexistent dotted module and executed no tests; the corrected discovery
entrypoint was used thereafter.

### Foundation

```powershell
py -m unittest discover -s tests/foundation -p 'test_audit_replay_contract.py' -v
py -m unittest discover -s tests/foundation -p 'test_operations_api_design.py' -v
```

Final results: `1` and `23` tests passed. The first pass exposed the intended
closed response-validator enum and exact 55-route matrix; both were updated for
the one new read route and then passed.

### Component

```powershell
py -m unittest discover -s tests/component -p 'test_audit_replay.py' -v
```

Final result: `1 passed`. The test proves digest validation, explicit missing
authority/evidence links, journal actor preservation, and stable journal entry
identities and digest after timeline rebuild.

The first run found that cursor `issued_at` was incorrectly treated as source
movement. The stable cursor comparison now uses stream, generation, sequence,
entry id, entry digest, and snapshot digest only.

### Integration

```powershell
py -m unittest discover -s tests/integration -p 'test_audit_replay_api.py' -v
```

Final result: `1 passed`. The authenticated loopback audit route returned the
closed snapshot contract before and after operations API restart with the same
journal-backed entry digest.

### Workflow

```powershell
py -m unittest discover -s tests/workflow -p 'test_sf304_audit_replay.py' -v
```

Final result: `1 passed`. The owner can trace current work and the reported
actor limitation count exactly matches entries without a recorded actor.

The real Chrome workflow then authenticated, opened the Work Room, loaded the
audit route, created and resolved an approval request, refreshed both views,
and rendered `51` audit entries with visible
`journal 50 / replay verified` proof. Desktop `1280x800` and mobile `390x844`
had no page or descendant overflow, browser errors, console issues, or failed
API responses. Bounded screenshots and report are under `.tmp/evidence/`.

### Stress

```powershell
py -m unittest discover -s tests/stress -p 'test_audit_replay_concurrency.py' -v
```

Final result: `1 passed` across eight concurrent reads. The first run exposed
that the source digest included cursor `issued_at`; binding it to stable cursor
fields made all concurrent snapshots identical.

## Validation And Package

```powershell
py -m compileall -q elder_protocol tests
node --check elder_protocol/factory_operations/control_room/app.js
py -m elder_protocol.cli validate
py -m build --outdir .tmp\sf304-closure-dist-20260814
```

The final build produced the wheel and source archive under the bounded
closure directory. The wheel was installed into a fresh target outside the
checkout import path.
The installed package loaded `AuditReplay`, the 56-route registry, the
`audit-replay-get` service binding, and the audit snapshot schema.

## Review Corrections

The focused review corrected:

- volatile cursor issuance time falsely signaling source movement;
- volatile cursor issuance time making concurrent snapshot digests differ;
- Work Room mutations refreshing operational state without refreshing audit
  state.

No remaining current-scope blocker or required correction was found. SF-304
adds no mutation, authority, maturity, merge, release, or deployment claim.
