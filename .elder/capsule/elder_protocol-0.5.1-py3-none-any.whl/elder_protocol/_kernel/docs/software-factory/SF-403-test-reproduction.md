# SF-403 Test Reproduction

**Status:** VERIFIED

## Foundation

```powershell
py -m unittest tests.foundation.test_sf403_evidence_pipeline_contract -v
```

## Component

```powershell
py -m unittest tests.component.test_sf403_evidence_pipeline -v
```

Proves ordered success, failed lower-level blocking, stale result rejection,
changed diff and artifact rejection, secret-trace rejection, and independent
evaluator requirements. It also proves a tampered completion-store row fails
closed.

## Integration

```powershell
py -m unittest tests.integration.test_sf403_evidence_pipeline -v
```

Proves the completion packet supplies the existing validation and human
accept-outcome transitions.

## Workflow

```powershell
py -m unittest tests.workflow.test_sf403_evidence_pipeline -v
```

Proves plan, results, evaluator wait, completion, owner view, and restart.

## Stress

```powershell
py -m unittest tests.stress.test_sf403_evidence_pipeline_concurrency -v
```

Proves 24 concurrent exact result ingestions converge to one record.

## Additional

```powershell
py -m unittest tests.component.test_transition_engine -v
py -m unittest tests.foundation.test_operational_architecture -v
py -m compileall -q elder_protocol tests scripts
py -m elder_protocol.cli validate
git diff --check
```

Package and installed-package commands and hashes are recorded in the evidence
file and external closure record.
