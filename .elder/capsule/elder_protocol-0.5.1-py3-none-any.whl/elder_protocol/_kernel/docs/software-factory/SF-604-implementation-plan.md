# SF-604 Hosted Git And Review Controls Implementation Plan

**Status:** VERIFIED

1. Define exact policy, canonical trust-anchor, signed-statement,
   provider-response, and retained-record contracts.
2. Implement Ed25519 signature, role-separation, freshness, URL, Git-object,
   required-check, provenance, and independent-review verification.
3. Compose the verifier with the existing open SF-404/P5.2 supervised delivery
   record and pull-request packet.
4. Implement durable retained evidence, deterministic restart replay,
   idempotent duplicates, and cross-instance serialization.
5. Verify attempted bypass, stale statement, changed commit, untrusted URL,
   missing check, tampering, restart, retention, and concurrency.
6. Run Foundation, Component, Integration, Workflow, then Stress.
7. Complete focused correctness review, package build, installed-wheel proof,
   evidence, roadmap, README, and Obsidian updates.
8. Commit and push SF-604 separately, then stop before SF-605.
