# SF-601 Implementation Plan

**Status:** COMPLETED

1. Activate SF-601 from the clean pushed SF-600 closure.
2. Read the Phase 6 task, trust-anchor, authority-source, qualification,
   canary, secret-safety, and factory identity contracts.
3. Define exact workload identity and broker grant boundaries.
4. Implement provider-neutral OIDC/JWKS verification and safe identity output.
5. Implement opaque broker references, short-lived issue, rotation,
   revocation, outage handling, and secret-free audit.
6. Verify wrong subject, expiry, cross-product access, secret telemetry,
   broker outage, restart replay, and concurrency.
7. Run Foundation, Component, Integration, Workflow, and Stress in order.
8. Complete focused independent review and correct all required findings.
9. Validate protocol, build and install the package outside the checkout,
   update evidence, roadmap, README, and Obsidian, then commit and push SF-601
   separately.
10. Stop the SF-601 work item before beginning SF-602.
