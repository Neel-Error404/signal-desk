# SF-206 Worker Recovery And Reconciliation Design

**Status:** VERIFIED

**Date:** 2026-08-13

## Boundary

SF-206 adds a deterministic recovery coordinator above SF-203, SF-205, and the
unchanged SF-200 worker `recover` operation.

```text
expired or uncertain SF-203 control
              |
              v
WorkerRecoveryCoordinator
  case -> accepted request -> attempt -> observation
              |
              +--> worker recover once per eligible session set
              +--> exact SF-203 reconciliation
              +--> SF-205 fail-closed propagation
              +--> workspace and scheduled-control orphan findings
```

The coordinator does not own canonical run authority. SF-105 lifecycle
commands remain the only path for canonical cancellation completion.

## Durable Records

- **Recovery case:** one exact uncertain control record version, attempt count,
  interrupted adapter step, effect identity, workspace observation, dependent
  ticks, disposition, and owner-visible terminal reason.
- **Attempt event:** immutable started, completed, or failed event. The started
  event binds the exact recovery request before adapter invocation. Completed
  events retain the complete reconciled-effect set and exact eligible control
  versions.
- **Orphan finding:** immutable missing-control, control-drift, or
  workspace-drift evidence.

Case histories and attempt/orphan rows are append-only. SQL identity columns
are checked against their JSON records and content digests.

## Recovery Episodes

A safely requeued control can become uncertain again on its next exact attempt.
Therefore a case is not unique only by control ID. It is bound to:

- control ID;
- uncertain control record version and content digest;
- control attempt count and uncertainty time;
- exact adapter effect identity.

Prior observations cannot resolve a later episode. Shared observations are
eligible only for the exact control IDs, record versions, and effect identities
captured before that worker recovery invocation.

## Outcome Rules

- `not-applied`: requeue the exact accepted control and reuse the original
  effect idempotency key, unless the SF-203 attempt budget is exhausted.
- `succeeded` for prompt/follow-up/steer: mark the control succeeded using the
  exact effect response digest without replaying the command.
- `succeeded` for cancel: complete the deterministic canonical cancel command.
- `succeeded` for start or checkpoint: complete automatically only when the
  indispensable canonical/local state was already persisted; otherwise retain
  owner-required uncertainty.
- `unknown`, contradictory identity, generation drift, or unverifiable
  recovery response: fail closed.

The worker `recover` operation is itself a mutation. If its response is lost,
the adapter may later return `duplicate`, but factory validation requires the
original durable exchange. SF-206 does not invent that exchange; it records an
owner-required case and stops dependent work.

## Cross-Store Convergence

SF-203 and SF-206 use separate SQLite stores. If SF-203 commits reconciliation
before the recovery case commits, restart reads the terminal SF-203 control,
validates its exact reconciliation evidence against the open case, and closes
the case deterministically. No adapter call is repeated.

## SF-205 Propagation

Successful recovery does not fabricate token or elapsed-time usage. The
submitted tick remains available for explicit trusted accounting.

`owner-required` or `contradictory` recovery moves a submitted dependent tick
and its active goal to `uncertain`. Terminal ticks and goals are never
rewritten.

## Orphan Discovery

Each sweep inspects:

- submitted or uncertain SF-205 ticks whose control is missing;
- tick-to-control digest drift;
- workspace state for every run known through session controls;
- all SF-202 runtime manifests, including manifests whose run no longer exists
  in the canonical controller.

Orphans are evidence only. SF-206 never deletes, unlocks, force-cleans, or
reuses a workspace.

## Security And Authority

- all durable records are recursively secret-scanned;
- recovery request and response evidence is digest-bound;
- worker observations cannot grant lifecycle authority;
- no fallback accepts ambiguous duplicate responses;
- no merge, release, deployment, promotion, or maturity authority is added.
