# SF-305 Metrics, Cost, And Outcomes Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Ordered Test Ladder

Only the invalidated SF-305 contract and implementation modules were run. A
passing level was not repeated unless a later focused-review correction
changed behavior at that level.

### Foundation

```powershell
py -m unittest tests.foundation.test_operations_api_design tests.foundation.test_owner_metrics_contract -v
```

Final result: `24 passed`.

The first pass exposed three stale exact-route-count assertions after the new
read route changed the registry from 56 to 57 entries. Each assertion was
updated and the same Foundation set passed. After focused review strengthened
semantic aggregate reconciliation, the same set passed again.

### Component

```powershell
py -m unittest tests.component.test_owner_metrics -v
```

Final result: `2 passed`.

The component proof covers one real persisted running factory, exact project
outcomes, zero-by-evidence retry and failure counts, complete owner-source
accounting, unavailable cost and learning impact, nearest-rank duration
percentiles, digest tamper rejection, and rejection of a self-consistent but
arithmetically contradictory aggregate.

Pre-ladder probes corrected two source-boundary defects:

- owner-note and decision tables may be lazily absent and cannot be treated as
  measured zero;
- work-room notes are stored in the session database, not the operations
  database.

The final implementation reports unavailable sources explicitly and reads
notes and controls from one stable session-source snapshot.

### Integration

```powershell
py -m unittest tests.integration.test_owner_metrics_api -v
```

Final result: `1 passed`.

The bearer-authenticated `owner-metrics-get` route returned the closed
`owner-metrics-snapshot` contract before and after a complete operations API
restart with identical source reconciliation and outcome values.

### Workflow

```powershell
py -m unittest tests.workflow.test_sf305_metrics_outcomes -v
```

Final result: `1 passed`.

An owner read current delivery and control outcomes without inspecting a
database or terminal. Cost and learning impact remained explicitly
unavailable rather than being inferred.

### Stress

```powershell
py -m unittest tests.stress.test_owner_metrics_concurrency -v
```

Final result: `1 passed` across eight concurrent reads. All snapshots had one
content digest and the same journal sequence.

## Browser Proof

A real loopback runtime authenticated the control room, opened a Work Room,
loaded audit and metrics concurrently, raised and resolved one owner decision,
and refreshed the view.

Observed SF-305 values included:

- retries `0`;
- failures `0`;
- owner interventions `2`;
- recorded test-evidence coverage `0%`;
- cost `Unavailable`;
- learning impact `unavailable`.

Desktop `1280x800` and mobile `390x844` had no page or descendant overflow,
console warnings or errors, page errors, or failed API responses. The report
and screenshots are under `.tmp/evidence/`.

## Validation And Package

```powershell
py -m compileall -q elder_protocol tests
node --check elder_protocol/factory_operations/control_room/app.js
py -m elder_protocol.cli validate
py -m build --outdir .tmp\sf305-final-dist-20260814-r3
py -m pip install --no-deps --target .tmp\sf305-final-installed-r3 <wheel>
```

The isolated installed package loaded `OwnerMetrics`, the 57-route registry,
the `owner-metrics-get` service binding, the closed metrics schema, and the
control-room metrics panel from outside the checkout import path.

## Focused Review

The focused review corrected:

- optional owner tables being read as mandatory operations-store tables;
- work-room notes being read from the wrong durable store;
- aggregate validators accepting self-consistent digests with contradictory
  failure, terminal, completion, test-coverage, or owner-control totals.

No unresolved current-scope blocker or required correction remains. SF-305 is
read-only, advisory, and adds no authority, maturity, merge, release,
deployment, billing, or learning-effect claim.
