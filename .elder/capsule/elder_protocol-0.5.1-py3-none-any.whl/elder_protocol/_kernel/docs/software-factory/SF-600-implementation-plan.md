# SF-600 Implementation Plan

**Status:** COMPLETED

1. Activate SF-600 from the clean pushed SF-500 closure.
2. Read the Phase 6 task, accepted operational architecture, local storage,
   journal, projection, backup, and maturity contracts.
3. Define the inactive hosted schema and fail-closed cutover evidence.
4. Implement lazy PostgreSQL connectivity, ordered migrations, transactional
   outbox/inbox delivery, and fenced claims.
5. Implement projection checkpoints, quiesced SQLite export/import
   verification, logical backup, and empty-target restore.
6. Prove contention, exact duplicate delivery, outage uncertainty, connection
   rebind, restore equality, and projection rebuild.
7. Run Foundation, Component, Integration, Workflow, and Stress in order.
8. Complete focused correctness review and correct all current-scope findings.
9. Validate protocol, build the package, verify the installed wheel outside
   the checkout, update evidence, roadmap, README, and Obsidian, then commit
   and push SF-600 separately.
10. Stop the SF-600 work item before beginning SF-601.
