# SF-104 Durable Dispatcher Design

**Status:** VERIFIED

**Design date:** 2026-08-11

**Implementation branch:** `work/sf-104-durable-dispatcher`

**Activation:** `.tmp/session-activation-sf-104.json`

**Change class:** `internal-code`

## Outcome

SF-104 adds the restart-safe local dispatch boundary above an accepted SF-103 transition into
the canonical `queued` work-item stage.

The dispatcher must:

- durably accept a provider-neutral factory command before acknowledging it;
- bind that command to the exact accepted queue transition and current queued work item;
- claim at most the ratified local worker capacity;
- fence every claim by owner identity and monotonically increasing lease generation;
- renew a live claim without changing command authority;
- persist an execution-start marker before invoking an external callback;
- complete, retry, reject, fail, cancel, or dead-letter through explicit state changes;
- treat a lost mutating response as `uncertain`, never as an ordinary retry;
- reconcile uncertain work by the original request and idempotency key;
- survive process restart without repeating a confirmed or potentially applied side effect;
- preserve immutable revision history and dead-letter evidence.

The maximum truthful claim is a local single-process SQLite dispatch mechanism. SF-104 does not
prove a real Codex worker, hosted durability, distributed exactly-once execution, or canonical
maturity above L1.

## Ratified Inputs

This design implements, but does not amend:

- ADR 0021 and `factory/operational-architecture.json`;
- the SF-002 `Command` lifecycle and factory dispatch lease distinction;
- the SF-003 command, worker-adapter request, response, idempotency, error, and uncertainty
  contracts;
- SF-103 as the only implemented work-item stage-mutation boundary;
- the local-adaptation decision from SF-004;
- the Codex-primary, factory-owned uncertainty boundary from SF-005.

Pinned behavioral references:

- Mastra Factory commit `d81fe95420e4a001a2850c56b9193106bf400682`;
- Prime Agent commit `b9a4461149419156599d60174dddf15458e2b9ee`.

No source is copied, vendored, imported, or added as a dependency.

## Scope Boundary

SF-104 owns:

- durable dispatch submission;
- exact idempotency and replay;
- command and adapter-request validation;
- dispatch queue state;
- lease ownership, generation, renewal, and expiry;
- local capacity enforcement;
- execution-start fencing;
- adapter-response validation;
- safe retry and exponential backoff;
- uncertain mutation reconciliation;
- cancellation before delivery;
- attempt exhaustion and immutable dead letters;
- owner shutdown reconciliation;
- status, query, history, and integrity checks.

SF-104 does not own:

- creation of runs, worker sessions, workspaces, checkpoints, or artifacts;
- a real worker gateway or Codex process;
- provider session identity or generation;
- work-item transition from `queued` to `running`, `failed`, or `cancelled`;
- the SF-106 canonical event journal or projections;
- the SF-107 API, authentication boundary, or owner UI;
- schedules;
- Elder delegation/runtime-lease validation beyond preserving references already accepted by
  SF-103;
- distributed brokers, multi-process workers, Postgres, hosted recovery, or secret brokering.

SF-105 will consume a completed start delivery to create exact run/session/workspace bindings and
will request any resulting work-item transition through SF-103. A dispatch lease is concurrency
state only and never substitutes for identity, delegation, approval, or authority.

## Contracts

SF-104 adds three operations schemas:

1. `durable-dispatch-submission.schema.json`
   - exact factory command;
   - exact worker-adapter `send` request containing that command;
   - accepted queue-transition command id;
   - bounded maximum attempts;
   - first availability timestamp.

2. `durable-dispatch-record.schema.json`
   - current dispatch state and record version;
   - command and adapter-request digests;
   - queue-transition lineage;
- attempt count, durable lease-generation counter, and active lease state;
   - execution-start marker;
   - response, error, reconciliation, cancellation, completion, and dead-letter fields;
   - content digest.

3. `dispatch-dead-letter.schema.json`
   - immutable final dispatch, command, project, work-item, and idempotency identities;
   - terminal reason and bounded diagnostic code;
   - attempt count and command, request, transition, and final-dispatch digests;
   - creation timestamp and content digest.

Semantic validation additionally requires:

- factory command version `1.0.0`;
- command status `accepted` on first submission;
- mutating command with a non-null idempotency key;
- worker-adapter operation `send`;
- adapter request payload exactly `{"command": <submitted command>}`;
- identical project, work item, run, session, correlation, causation, and idempotency bindings;
- command causation equal to the accepted SF-103 queue transition id;
- command authority reference equal to the accepted queue transition authority reference;
- command submission at or after the queue transition;
- active Product Factory and exact queued work item;
- current work-item digest equal to the queue transition after-digest;
- no secret-shaped field, secret-like value, or forbidden secret-reference scheme.

The dispatcher persists the submitted `accepted` command and queue record in one transaction
before returning it. The original submission digest remains immutable.

## Dispatch State Machine

```text
pending -> leased -> completed
   |         |          |
   |         |          + command delivered or succeeded
   |         +-> retry
   |         +-> uncertain -> completed
   |         |               +-> retry
   |         |               +-> dead-letter
   |         +-> dead-letter
   |         +-> cancelled, only before execution starts
   +-> cancelled
   +-> dead-letter

retry -> leased
```

Terminal dispatch states:

- `completed`;
- `dead-letter`;
- `cancelled`.

`uncertain` is deliberately nonterminal. It blocks normal claiming until an explicit
reconciliation result is recorded.

## Command Status Mapping

| Dispatch outcome | Canonical command status |
|---|---|
| durable submission accepted | `accepted` |
| adapter accepted delivery | `delivered` |
| adapter confirmed operation completion | `succeeded` |
| adapter rejected before mutation | `rejected` |
| bounded safe failures exhausted | `failed` |
| mutation may have occurred | `uncertain` |
| cancelled before execution start | `cancelled` |

The dispatch `completed` state means the dispatch obligation ended. An adapter `accepted`
response can therefore complete delivery while the command remains `delivered`, because worker
execution completion is outside SF-104.

## Persistent Model

### `dispatch_commands`

Mutable current state, one row per accepted command:

- stable dispatch, command, project, work-item, and idempotency identities;
- current command and adapter-request JSON;
- exact submission, command, request, queue-transition, and content digests;
- status and record version;
- attempt count and bounded maximum;
- durable lease-generation counter retained while no lease is active;
- availability timestamp;
- lease owner, generation, acquisition, and expiry;
- execution-start timestamp;
- reconciliation reference;
- last response and error;
- cancellation request;
- completion and dead-letter references;
- created and updated timestamps.

Uniqueness:

- command id;
- project plus idempotency key;
- one dispatch id.

### `dispatch_history`

Append-only immutable snapshot for every accepted state change. Versions are contiguous and the
current row must equal the history tip.

### `dispatch_dead_letters`

Append-only immutable terminal record containing:

- dispatch, command, project, work-item, and idempotency identities;
- terminal reason and error code;
- final attempt count;
- command, request, queue-transition, and final-dispatch digests;
- creation timestamp and content digest.

No delete API is provided. SQLite triggers reject history and dead-letter update or delete.

## Lease And Capacity Semantics

- Local capacity is fixed at one active lease, matching ADR 0021.
- A claim runs under `BEGIN IMMEDIATE`.
- Candidate order is `available_at`, then creation time, then dispatch id.
- Terminal and uncertain records are excluded from the claim window.
- Request deadlines and command expiry are checked before invocation; expired work is
  dead-lettered without a lease or provider call.
- Claim increments both attempt count and lease generation.
- The lease contains owner id, generation, acquisition time, and expiry.
- Renew, begin execution, response recording, failure recording, and cancellation require the
  exact current owner and generation.
- A stale owner, stale generation, expired lease, or changed command cannot finalize work.
- Renewal must move expiry forward and cannot revive an expired lease.
- Scheduling and lease comparisons use parsed instants rather than lexical timestamp text, so
  equivalent ISO-8601 offsets retain chronological order.

An expired lease with no execution-start marker is safe to reclaim, subject to the attempt
budget. An expired lease with an execution-start marker becomes `uncertain`, because the process
may have crossed the external side-effect boundary.

## Execution Protocol

`dispatch_once` performs:

1. claim one available dispatch;
2. persist execution-start under the current lease;
3. invoke the supplied provider-neutral executor outside the database transaction;
4. validate the returned adapter response against the exact stored request;
5. persist the deterministic outcome under the same owner and generation.

The executor is an injected callback, not a provider implementation.

If the callback raises after execution start, the dispatcher records `uncertain`. Generic
exceptions are not treated as safe retry evidence.

Callers that know no side effect began must return a valid SF-003 error response such as
`provider-unavailable`, `timeout`, or `internal-error` with mutation state `not-applied` and
retry `same-idempotency-key`.

## Response Matrix

| Adapter response | Dispatch action |
|---|---|
| `accepted` | complete dispatch; command becomes `delivered` |
| `succeeded` | complete dispatch; command becomes `succeeded` |
| `duplicate` | validate against the original durable exchange; complete without another effect |
| `rejected` | dead-letter immediately; command becomes `rejected` |
| `timeout`, mutation `not-applied` | retry with original request and idempotency key |
| `failed`, mutation `not-applied` | retry with original request and idempotency key |
| `uncertain`, mutation `unknown` | enter `uncertain`; no normal retry |
| contradictory or invalid response | fail closed as `uncertain` |

Safe retries use exponential backoff:

```text
base_delay * 2 ** (attempt_count - 1)
```

The delay is capped. The implementation defaults will be explicit constants and included in
status output.

## Reconciliation

Reconciliation:

- is allowed only from `uncertain`;
- uses the exact stored request and original idempotency key;
- cannot alter command, project, work item, authority, payload, or redaction;
- records a new lease generation and attempt only for the reconciliation claim;
- accepts a valid `accepted`, `succeeded`, or `duplicate` response as observed delivery;
- accepts a valid not-applied timeout/failure as proof that a normal retry may be scheduled;
- retains `uncertain` when the mutation state remains unknown;
- dead-letters when the bounded attempt budget is exhausted.

A provider receipt or response from another command, project, idempotency key, owner, or
generation is rejected.

## Cancellation And Shutdown

Cancellation:

- `pending` or `retry`: terminal `cancelled`;
- `leased` before execution start: only the current owner and generation may cancel;
- `leased` after execution start: records a cancellation request but remains `uncertain` until
  reconciliation;
- `uncertain`: records a cancellation request but cannot claim non-application;
- terminal records are idempotent only for the exact same cancellation reason.

Graceful owner shutdown:

- releases unstarted owned leases back to immediate `retry`;
- converts execution-started owned leases to `uncertain`;
- does not alter another owner's lease;
- returns exact released and uncertain counts.

## Integrity And Replay

Every read validates:

- schema conformance;
- command and adapter-request semantics;
- immutable submission and queue-transition lineage;
- current content digest;
- contiguous history;
- current row equality with the history tip;
- lease-field consistency with status;
- response validity against the exact request;
- dead-letter digest and final-state binding;
- no secret material.

Exact resubmission returns the original durable dispatch. Reusing the command id or
project/idempotency key with changed content raises an explicit collision error.

## Error Handling

All errors are explicit `ProtocolError` failures with actionable messages.

No fallback:

- from uncertainty to normal retry;
- from lost authority lineage to acceptance;
- from stale lease to completion;
- from invalid adapter response to success;
- from exhausted attempts to an unbounded queue;
- from unavailable worker to silent completion.

Stored diagnostic messages are bounded and secret-scrubbed before persistence.

## Verification Plan

### Foundation

- all three schemas validate and reject unknown fields;
- SF-003 command/request/response semantics are reused, not weakened;
- state and response matrices are complete;
- secret material and provider-specific canonical fields are rejected;
- operations schema catalog includes the new contracts.

### Component

- submit and exact replay;
- command-id and idempotency collisions;
- active factory, queued stage, transition lineage, authority, digest, and time checks;
- one claim, lease generation, renewal, and stale-owner fencing;
- accepted and succeeded completion;
- safe retry with deterministic backoff;
- rejection and attempt-exhaustion dead letters;
- uncertain callback exception and explicit uncertain response;
- reconciliation to completion, retry, retained uncertainty, and dead letter;
- cancellation paths;
- restart durability, history equality, tamper detection, and immutable dead letters;
- graceful owner shutdown.

### Integration

- SF-103 `ready -> queued` transition to SF-104 durable submission;
- dispatcher never changes the work-item stage directly;
- completed delivery remains available for SF-105 binding;
- dead-lettered dispatch leaves the queued work item unchanged and reviewable.

### Workflow

- run the complete existing workflow suite to detect package and CLI regressions.

### Stress

- concurrent claimers produce exactly one lease owner;
- concurrent exact submissions produce one durable dispatch;
- stale generation cannot complete after lease recovery;
- process termination after execution-start becomes uncertain on restart;
- backlog ordering and capacity remain correct under many terminal rows.

## Runtime Budget

Use separate commands and stop on the first failed level:

| Level | Initial timeout budget |
|---|---:|
| Foundation | 10 minutes |
| Component | 25 minutes |
| Integration | 20 minutes |
| Workflow | 10 minutes |
| Stress | 20 minutes |

The SF-104 evidence must record final observed runtime, exact counts, skips, initial failures,
root causes, and same-level reruns.

## Phase Handoff

SF-104 closes only when the full ordered ladder and installed-wheel verification pass.

SF-105 then adds:

- durable run identity;
- immutable work-item, authority, context, repository, source revision, and workspace bindings;
- provider session and generation bindings;
- recovery metadata and cleanup intent;
- the governed SF-103 transition from queued work into active execution.

Gate B remains open until SF-105, SF-106, and SF-107 are separately verified.
