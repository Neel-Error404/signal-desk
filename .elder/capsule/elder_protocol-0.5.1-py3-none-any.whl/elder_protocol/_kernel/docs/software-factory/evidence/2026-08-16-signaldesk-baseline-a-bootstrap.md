# SignalDesk Baseline A Capsule Bootstrap

**Status:** VERIFIED

**Date:** 2026-08-16

## Baseline

SignalDesk was initialized as a separate Git repository at:

```text
D:\Balcony\Template\signal-desk
```

Its first portable Elder capsule was built from clean source commit:

```text
93a1de99930721a6d0fd93e43d6d5c05d1619198
```

The archive SHA-256 was:

```text
f31923466902903aa5b58a0e51da8a164443837cbf56f661a3dd74309433c9e1
```

The installed manifest content SHA-256 was:

```text
2372e3c69bb63f66e4d751583e0f392399ccfb758c04b9a66203abaa3df4ef59
```

## Independent Product Session

A separate persisted Codex session was started inside SignalDesk:

```text
01a00a52-2681-71b1-9a21-820f33d7ab95
```

The session was limited to capsule verification and read-only product
inspection. It did not create a profile, ratify, compile, or implement product
source.

`.\elder.ps1 capsule status --project-root .` failed before protocol
validation because the generated bootstrap unconditionally invoked:

```powershell
py -m venv --clear $RuntimeRoot
```

Inside the Codex execution environment, `C:\WINDOWS\py.exe` reported that no
Python installation was registered. The same session independently verified
that the exact installed interpreter existed, reported Python 3.13.5, and
successfully loaded `venv`:

```text
C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe
```

The ignored product-local evidence files and their SHA-256 digests are:

```text
92d65d3d11580ab0a0fbb816a223479daaee9e4e446d362eaa0aaa383eb2eeb6  bootstrap-events.jsonl
31124bcfbcdd1cec368b0999f6126895100203b991af4bfb657e2aa9348ddf48  bootstrap-last-message.md
c68bd478de12c01594144632d756b7219750522e95550d814439ef934f03165a  python-discovery-events.jsonl
8f0d8f69c71c19006f08e0325e1800eb24db5c65ae0b779b44cb73d5de5272d9  python-discovery-last-message.md
```

## Root Cause And Correction

The capsule assumed that Windows Python Launcher registration was equivalent
to an installed usable Python. That assumption is false in a Codex-spawned
environment where the interpreter remains directly executable but launcher
registration is unavailable.

The generated bootstrap now:

1. accepts an explicit `ELDER_BOOTSTRAP_PYTHON` path;
2. probes `py -3`;
3. probes every visible `python` and `python3` command;
4. inspects standard per-user and system Python installation roots;
5. deduplicates candidates;
6. requires a real file, Python 3.11 or newer, and an importable `venv`;
7. fails with one actionable Elder error when no usable candidate exists.

No product file, protected protocol surface, maturity record, or authority
source was changed.

## Verification

Ordered verification completed after the final correction:

```text
Foundation
- elder validate: PASS
- full foundation suite: 204 passed

Component
- tests.component.test_portable_memory_capsule: 7 passed

Integration
- tests.integration.test_portable_capsule: 1 passed
```

Independent Codex review found and drove correction of:

1. a P1 failure where the WindowsApps Python shim could terminate discovery;
2. a P2 optimized-away Python-version assertion;
3. a P2 non-binding explicit interpreter override.

The final independent review session reported no remaining code finding:

```text
01a00a6e-3479-7bd3-87ff-70e1af49c960
```

Its sandboxed integration rerun could not download isolated build dependencies.
The authoritative local integration run used the same final source and passed.

The first separate-session command used the wrong placement for the Codex
global approval option and exited before starting a session. The command was
corrected from `codex exec ... -a never` to `codex -a never exec ...` and
rerun successfully.

## Baseline B Replay

The correction was committed separately:

```text
280ccd77f4b082cd56a7ce52803a4fc47404aa4d
```

A new clean capsule was built and verified:

```text
archive SHA-256: d99abc1a8da571642973154eba0de2db331b298a7666c0024e8ac3a4a6858b99
manifest SHA-256: d5e6fd2fe91421c8eaa85e80cf89501623f39b4f2319b9970138ea5ecc60714d
wheel SHA-256: d77079cee6ecb2ad94f7f572b37fb3a39bb44e033eb2241ceb6978f4a9f92db6
```

The original SignalDesk Codex session was resumed. It reran the same Phase 1
commands:

```text
capsule status: exit 0
elder validate: exit 0
```

The replay evidence digests are:

```text
3622c79f0e34fd2a38005cfc834120343f11ffe69f4a079aaf6bf24bf60c5e0d  baseline-b-phase1-events.jsonl
64116f64d809debcc6a2e8fff6a780641b9f60a1923929779434ae305716d3d4  baseline-b-phase1-last-message.md
```

SignalDesk remained on an uncommitted initial `main` branch with only the
portable Elder baseline. No product profile, ratification, compilation, or
product implementation occurred during the replay.

## Non-Claims

This verified bootstrap correction does not qualify Gate F, Gate G, L2
maturity, autonomous pull-request authority, or deployment authority.
SignalDesk product intake still requires explicit human answers and profile
ratification before compilation or implementation.
