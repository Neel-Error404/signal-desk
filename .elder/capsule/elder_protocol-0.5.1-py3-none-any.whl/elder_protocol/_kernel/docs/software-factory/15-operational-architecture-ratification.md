# Operational Architecture Ratification

**Task:** SF-006 - Ratify Operational Architecture

**Status:** RATIFIED on 2026-08-08

**Accepted ADR:** `docs/adr/0021-software-factory-operational-architecture.md`

**Machine-readable decision:** `factory/operational-architecture.json`

## Decision

ADR 0021 is ratified as human-owner, architecture-owner, and code-owner.

The decision selects:

- an independently implemented Python operations kernel in the central Elder repository;
- SF-002 and SF-003 as the Phase 1 canonical domain and contract boundary;
- a dedicated operations SQLite store at `.factory/runtime/operations.db`;
- physically separate Elder knowledge, coordination, learning, qualification, and autonomy
  authority stores;
- one logical event spine with source-record references rather than one universal database;
- Codex as the primary version-pinned worker behind a factory-owned adapter;
- app-server v2 as the preferred interactive Codex surface and `exec --json` as fallback;
- Prime as a deferred optional continuity sidecar;
- local single-process rollout before Postgres, broker, multi-worker, or hosted controls.

The existing P3 `factory/factory-contract.json` remains the build, artifact, promotion, and
rollback substrate contract. SF-002 and SF-003 are layered operations-domain and adapter
contracts; they do not supersede P3.

## Why This Fits Elder

The architecture implements the already accepted `factory operations` layer without changing
the universal hierarchy. Workers remain executors rather than authority. Elder governance is
invoked at explicit lifecycle gates. Product repositories retain their own source and pinned
capsules. The operations service owns workflow truth but cannot approve, promote, qualify,
certify, merge, release, or deploy by itself.

The operations database is physical custody, not universal semantic authority. `ProductFactory`
remains owned by the product-owner plane. The product registry persists only an
owner-authorized binding and rebuildable projection; it cannot originate or reinterpret product
intent, profile ratification, autonomy ceiling, or owner decisions.

## Important Clarification

The target dossier describes one shared event spine. Ratification interprets that as one stable
cross-plane event contract and one canonical operations journal for operational facts.

It does not merge the P4.5B runtime journal, P4.6 learning journal, trusted-memory store,
qualification bundle, or autonomy records into the operations database. Operations stores
digest-bound references and normalized projections of those facts while their source stores
retain authority.

## Intentional Protected-Surface Diff Plan

No protected surface is changed before ratification.

After explicit approval:

1. Change ADR 0021 from `Proposed` to `Accepted`, recording the human owner and exact date.
2. Add ADR 0021 to `protocol/design-registry.json` with its final byte digest.
3. Register accepted ADRs 0019 and 0020, which currently exist but are absent from the design
   registry, or record a separate explicit remediation if the owner excludes them from SF-006.
4. Update `docs/software-factory/research-sources.json` so Mastra records the approved
   independent-local-adaptation decision and Prime records the approved deferred-sidecar
   decision. No dependency or code reuse becomes permitted.
5. Mark SF-002 and SF-003 documents as ratified for Phase 1 without changing their versions.
6. Register the exact SF-002, SF-003, and SF-006 bytes and digests as governed design inputs.
7. Re-add the ratified domain and contract validators to canonical protocol validation.
8. Regenerate `protocol/protocol-graph.json` from source truth.
9. Update any generated design-registry outputs and run Foundation validation.

No change is planned for:

- `protocol/meta-architecture.json`, because the four-plane implementation conforms to the
  accepted hierarchy;
- `protocol/authority-matrix.json`, unless SF-103 cannot map a factory transition to an existing
  Elder resource and action;
- `protocol/operational-maturity.json`, because canonical maturity remains L1;
- `protocol/autonomy-authority-source.json`, because no autonomy is activated;
- `ELDER_PROTOCOL.md`, because this selects an implementation within existing constitutional
  rules rather than amending them.

If validation shows that one of those files must change, stop and return a new explicit impact
diff for approval instead of widening the ratified change silently.

## Authority And Runtime Primitive Boundaries

Factory `authorized_roles` are eligible requesters, not standalone authority grants. Every
accepted transition requires a project role binding, exact Elder action/resource mapping,
current accountable command or delegation, an active assigned-identity runtime lease for
delegated execution, and a governance authorization result bound to the transition request.

The following are intentionally different:

- a factory dispatch lease is a concurrency claim in the operations store;
- an Elder delegation/runtime lease is authorization in the P4.5B coordination store;
- provider session generation is a recovery fence;
- a worker checkpoint is an observation until governance accepts it;
- a canonical delegated checkpoint remains P4.5B evidence;
- a projection checkpoint is only an internal read-model offset.

## Architecture Fitness Plan

Phase 1 must add executable checks for:

- module and import dependency direction;
- one command boundary for canonical mutations;
- duplicate signal and command idempotency;
- uncertain mutation reconciliation;
- owner and generation fenced leases;
- journal replay and projection equality;
- source-record digest verification across Elder gateways;
- exact Elder action/resource mapping and authority evidence for every transition;
- provider-object exclusion from canonical state;
- secret and credential rejection;
- repository and workspace containment;
- SQLite backup, restore, integrity, and later migration equality;
- complete work-item evidence linkage.

The current SF-006 Foundation test verifies that the ratified architecture declares all required
planes, components, stores, forbidden edges, rollout stages, and migration controls. It does not
claim the Phase 1 runtime fitness functions are implemented.

## Migration And Rollback

Local Phase 1 rollback is code and schema rollback against a versioned SQLite backup, provided no
accepted records would be discarded. Schema migrations must be explicit and tested in both
forward and restore directions.

Hosted migration uses a quiesced, single-writer cutover. The journal tip, record counts, and
projection digests must match before activation. Dual writable SQLite and Postgres primaries are
forbidden. Once Postgres has accepted new work, rollback requires validated reverse replay or
forward repair.

## Threat Review Summary

The highest-risk failures are:

- worker or integration bypass of the canonical ledger;
- duplicate or unknown provider side effects;
- stale lease completion;
- source-authority drift between operations and Elder records;
- secret persistence;
- repository escape;
- projection or event spoofing;
- split-brain migration;
- self-ratification.

ADR 0021 binds each threat to deterministic controls. Hosted identity, secret brokering,
multi-tenant isolation, central telemetry, and production rollback remain blocked future gates.

The machine-readable architecture is `accepted`, sets `ratification_required` to false, and
includes a human-owner ratification record bound to the exact reviewed input digests, every
public SF-002/SF-003 schema, the operational-architecture schema, retained byte-exact proposal
snapshots, and a cycle-safe digest of all substantive accepted architecture fields.

## Gate Decision

The human owner recorded:

```text
RATIFY ADR 0021 AS HUMAN-OWNER, ARCHITECTURE-OWNER, AND CODE-OWNER
```

Any future change must be applied to both the ADR and machine-readable architecture, then rerun
through Foundation validation, independent review, and a new accountable approval before it can
replace this ratified decision.

SF-006 is classified as `public-contract` plus `internal-code` validation support. Infrastructure
implementation is not activated by this decision. Later infrastructure tasks retain their
security-owner and release-owner approval requirements.
