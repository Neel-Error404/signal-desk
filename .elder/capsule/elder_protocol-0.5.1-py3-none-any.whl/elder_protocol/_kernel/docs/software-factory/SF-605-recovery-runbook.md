# SF-605 Product Recovery Runbook

**Status:** VERIFIED

## Trigger

Use this runbook for loss or corruption of one product partition or its
multi-product boundary state. Do not use it to merge products or migrate
ownership.

## Preconditions

1. Identify the exact tenant, product, project, policy digest, and backup ID.
2. Suspend new work for the affected product only.
3. Verify the backup digest, source-store catalog registration, product
   partition marker, and every component scope.
4. Prepare an empty target product under the same current policy.
5. Confirm unaffected products remain readable and their audit tips match.

## Restore

1. Mount the exact backup partition and source-store backup catalog read-only.
2. Restore the registered boundary backup into the empty matching product.
3. Confirm every formerly active worker is `recovery-required`.
4. Restore each returned component snapshot through its owning component's
   verified restore procedure.
5. Replay the restored product audit and compare its source backup tip.
6. Reconcile quotas, retained evidence, workspace state, integrations, and Git
   delivery records.
7. Issue new workload identity, secret, and worker leases. Never reuse restored
   credentials or active bindings.
8. Run one bounded read-only product workflow before reopening mutation.

## Abort Conditions

Abort and keep the product suspended when:

- tenant, product, project, or policy does not match;
- the backup file is absent from the immutable source-store catalog;
- the target contains state;
- any digest, audit link, component scope, or record count differs;
- another product appears in the backup;
- unaffected product state or audit changes during the exercise;
- a restored worker appears active instead of `recovery-required`.

## Evidence

Retain the backup manifest, verification result, restored audit tip, component
restore reports, worker reissue records, reconciliation report, and accountable
owner decision. This local runbook is not provider-native disaster-recovery
evidence until exercised in the SF-606 hosted environment.
