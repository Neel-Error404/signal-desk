# SF-201 Codex Worker Adapter Design

**Status:** VERIFIED

**Design date:** 2026-08-13

**Implementation branch:** `work/sf-107-factory-api-health`

**Base revision:** `03d8a2e9152118e0ee9fb943e3f0ebb5c064b603`

**Activation:** `.tmp/session-activation-sf201.json`

**Change class:** `internal-code`

## Outcome

SF-201 connects the provider-neutral SF-200 worker contract to the installed
`codex-cli 0.146.1` app-server v2 protocol. It proves that one bounded factory work item can
create a real Codex thread, execute a real turn in an explicitly bound workspace, and return
digest-bound adapter evidence.

The SF-200 operation set remains unchanged:

```text
prepare
start
send
observe
checkpoint
cancel
recover
collect-evidence
```

## Ownership Boundary

The factory continues to own work-item, run, worker-session, session-generation, workspace,
authority, context, command, idempotency, correlation, causation, checkpoint, canonical event,
and delivery identity.

Codex owns only opaque provider observations such as thread ID, turn ID, item ID, effective
runtime settings, usage, final message, and provider disposition. These values cannot replace
factory identity or grant canonical write authority.

The adapter consumes a factory-supplied mapping from the already authorized workspace ID to one
absolute existing directory. It validates that mapping; it does not create, lease, clean, retain,
or release workspaces. Those operations belong to SF-202.

The adapter-private SQLite store must resolve outside every provider-writable workspace. This
protects receipts, sessions, provider observations, checkpoints, and evidence from Codex
filesystem authority. Startup fails when the store is equal to or nested under an authorized
workspace.

## Runtime Choice

The adapter uses app-server v2 over stdio rather than a managed daemon:

1. start a short-lived `codex app-server --stdio` process;
2. perform `initialize`;
3. create the thread and keep that owned process through the first bounded turn;
4. collect the response and relevant notifications;
5. close stdin and allow bounded graceful rollout persistence before termination;
6. use a new short-lived process for each later resume or turn operation.

`start` uses `thread/start`, which creates the provider thread without starting a model turn.
Codex 0.146.1 does not materialize an empty thread rollout that another process can resume, so the
adapter retains only that first owned app-server process until the first `send` completes. The
completed first turn flushes the rollout; later operations use `thread/resume` to reattach by exact
opaque thread ID. This is a bounded pending-session bridge, not a reusable daemon or worker
supervisor.

The pending bridge has a 120-second default lifetime. A daemon timer closes the owned process and
reader threads when that bound expires. `send`, `cancel`, `recover`, and explicit adapter close
also consume or close it. A dead or expired pending process is never reported as a live provider
session.

If the adapter process is lost before the first turn persists, SF-201 does not fabricate a
restart-safe provider session. Durable queued start/send control and recovery across that boundary
belong to SF-203. After the first completed turn, the persisted thread is restartable by exact ID.

Every process launch includes explicit configuration overrides for:

- `approval_policy = "on-request"`;
- `sandbox_mode = "workspace-write"`;
- `sandbox_workspace_write.network_access = false`.

The adapter also supplies cwd and runtime workspace roots per thread or turn. It rejects a
response unless the effective cwd, roots, approval policy, reviewer, sandbox type, and network
setting exactly match the authorized adapter configuration.

The adapter checks `codex --version` before provider work and requires exact
`codex-cli 0.146.1`.

## Command Translation

| Factory command | Codex translation in SF-201 |
|---|---|
| `worker.prompt` | `turn/start` on the exact persisted thread |
| `worker.follow-up` | `turn/start` on the same thread after the prior synchronous turn |
| `worker.steer` | corrective `turn/start` on the same thread after the prior synchronous turn |

SF-201 does not claim live same-turn steering. Durable queued steering, concurrent cancellation,
waiting states, and owner-driven pause/resume belong to SF-203. The command remains distinct and
is recorded as a corrective steering observation so later session control can replace the
translation without changing the factory contract.

Each prompt includes factory command identity and a clear statement that Codex has no authority
to stage, commit, push, merge, release, deploy, or modify files outside the bound workspace.

## Durable State

The Codex adapter reuses the SF-200 adapter-private SQLite receipt, session, projection,
checkpoint, and evidence substrate. It adds only provider-specific observations:

- exact Codex CLI version;
- opaque thread ID and rollout reference;
- verified effective runtime policy;
- command ID to turn ID correlation;
- terminal turn status and error digest;
- normalized item and usage digests;
- final-message digest;
- typed process/protocol reason codes and diagnostic digests without raw provider errors or
  stderr.

Completed mutation receipts preserve the original response. Exact duplicate requests return the
original result without another provider invocation.

If a process or protocol failure occurs before provider dispatch, the adapter returns a typed
timeout or provider-unavailable result as not applied. If durable acceptance exists and provider
application cannot be excluded, it returns `uncertain-mutation`; the same command cannot be
blindly repeated.

A terminal turn is acknowledged only when its status is exactly `completed` and no terminal error
is present. Failed, interrupted, malformed, or error-bearing terminal turns remain uncertain
because provider-side file effects cannot be excluded.

SF-201 recovery reattaches to the exact persisted Codex thread and verifies current effective
policy after at least one turn has materialized the rollout. Before the first turn, recovery is
limited to the live adapter-owned pending process. It does not claim durable queued session
control or automatic command-effect reconciliation. An unresolved accepted provider command
remains uncertain for SF-206.

## Operation Behavior

### Prepare

Validates the existing factory identities and resolves the workspace ID to one absolute,
existing, authorized directory. No provider process starts.

### Start

Starts app-server, creates one thread with `thread/start`, verifies effective policy, stores the
opaque thread and policy observation, and retains that owned process only until the first send
materializes the rollout or the 120-second pending-session bound expires.

### Send

Durably accepts the command, uses the pending first app-server or resumes the exact persisted
thread, verifies effective policy, starts one turn, rejects interactive approval or user-input
requests, waits for terminal completion, and stores normalized turn observations. A provider
failure is explicit and actionable.

Only an exact error-free `completed` turn is acknowledged. Every other terminal result remains an
uncertain mutation.

### Observe

Returns only factory-supplied non-authoritative projections through the unchanged SF-200 cursor
contract. Raw Codex notifications remain adapter evidence and never become canonical events by
themselves.

### Checkpoint

Echoes the factory-supplied checkpoint ID and digest and adds an adapter-state digest covering
the current thread reference, verified policy observation, provider turn observations, and
factory projection snapshot.

### Cancel

Closes an idle pending first-turn process, or resumes the exact persisted thread. If an active
turn is visible, it issues `turn/interrupt`; otherwise it records that the thread was idle. It
then marks the adapter session cancelled and terminates its owned app-server process. It does not
delete provider history.

### Recover

Uses the live pending process before the first turn, or resumes the exact persisted thread after
the first turn. It verifies current effective policy and reports the provider status. Completed
durable receipts remain replayable. Ambiguous accepted commands remain uncertain.

### Collect Evidence

Returns a digest-bound bundle covering factory receipts, projections, checkpoints, Codex version,
thread reference, effective policy, normalized turn observations, final-message digests, and
terminal adapter status. It does not claim canonical factory writes or broader Phase 2
completion.

## Fail-Closed Rules

The adapter rejects or fails when:

- the Codex executable is missing or its version differs from `0.146.1`;
- a workspace ID is unknown, relative, missing, or no longer resolves to the configured path;
- app-server emits malformed JSON-RPC or exits unexpectedly;
- an effective policy field differs from the configured authority boundary;
- the runtime requests approval, user input, credential refresh, or another interactive action;
- a turn times out, fails, or is interrupted unexpectedly;
- a pending first-turn process exits or expires;
- a provider thread or turn reference is missing or changes identity;
- an accepted mutation has an unresolved provider outcome;
- provider observations contain canonical write claims.

## Verification

Foundation:

- exact Codex capability manifest and version pin;
- workspace and policy configuration validation;
- package visibility and no stable-contract changes.

Component:

- app-server initialize, thread start/resume, turn completion, malformed JSON, timeout, process
  exit, interactive request rejection, and effective-policy drift with a test-owned subprocess;
- pending-process death and expiry, and secret-shaped stderr sanitization;
- command translation and provider observation normalization;
- duplicate suppression, failed/interrupted terminal-turn uncertainty, and protected store
  placement.

Integration:

- unchanged SF-200 conformance runner against `CodexWorkerAdapter` with a deterministic
  test-owned runtime;
- deterministic adapter restart preserves the same opaque provider thread identity;
- live post-turn operations resume the persisted Codex rollout by exact thread ID;
- provider session identity remains separate from factory identity.

Workflow:

- one explicitly enabled live task in a disposable Git repository;
- Codex creates the expected bounded artifact;
- effective policy is recorded and verified;
- HEAD, branch, refs, commit count, and index remain unchanged;
- the only worktree delta is the expected untracked artifact;
- no push, merge, release, deployment, or Elder worktree mutation occurs;
- evidence bundle verifies.

Stress is not required because SF-201 introduces no concurrent supervisor, queue, or shared
multi-worker runtime.

## Completion Gate

SF-201 is complete only when the ordered test ladder passes, the live workflow evidence is
recorded, package/install verification includes the adapter, no current-scope `BLOCKER` or
`REQUIRED` finding remains, and an independent implementation review is reconciled.

Completion proves a bounded real Codex worker adapter. It does not complete SF-202 through SF-206
or Gate C by itself.
