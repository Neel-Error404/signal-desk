# SF-107 Evidence - Factory API And Health

**Status:** VERIFIED - LOCAL GATE B PASS

**Implementation date:** 2026-08-12

**Base revision:** `03d8a2e9152118e0ee9fb943e3f0ebb5c064b603`

**Implementation branch:** `work/sf-107-factory-api-health`

**Closure activation:** `activation-elder-protocol-562c3c4712da3c0c`

**Change class:** `internal-code`

## Verified Claim

SF-107 closes the Phase 1 local operations kernel. It provides a numeric-loopback,
single-active-process HTTP boundary over the SF-100 through SF-106 SQLite operations kernel.
Authenticated clients can query and mutate the durable factory model, resume bounded event
polling, observe health and readiness, and recover accepted work across API process restart.

The maximum claim is local. SF-107 does not provide remote workers, hosted identity, tenant
isolation, secret brokering, production telemetry, deployment, autonomous merge or release, or
canonical maturity above L1.

## Implemented Surface

- Digest-pinned 45-route and 45-binding registries.
- Two unauthenticated health routes, 27 authenticated query routes, and 16 authenticated
  mutation routes.
- Strict auth, request, response, error, mutation, idempotency, runtime, health, readiness, and
  worker-observation schemas.
- Numeric-loopback-only HTTP with bounded requests, bounded authenticated long polls, transport
  limits, security headers, no cookies, and no CORS.
- Exact client, route, project, kind, role, and actor authorization.
- Durable mutation idempotency, exact response replay, changed-key collision, stale-owner
  recovery, and evidence-bound reconciliation.
- One five-second runtime lease with monotonic generations, heartbeat, drain, and stale-writer
  fencing.
- Current readiness validation across runtime ownership, policy bindings, API-store integrity,
  journal integrity, projections, and mutation blockers.
- Operations backup and restore support for runtime and idempotency metadata.
- `elder factory operations-api` CLI with explicit store, policy, numeric host, and port.

## Phase-Proportional Remediation

The final audit produced one current-scope admission defect and stronger production transport
concerns. The current defect was corrected; later-phase concerns were removed from Gate B.

1. Scarce long-poll capacity is now owned by the application service and is acquired only after
   route resolution, query validation, authentication, authorization, and readiness admission.
   Unauthenticated, unauthorized, malformed, unknown-route, and wrong-method requests cannot
   consume a long-poll permit.
2. Route, binding, and auth policy bytes are boot-bound. Readiness detects drift and fails
   closed, but SF-107 does not claim operating-system-wide tamper exclusion.
3. Graceful drain now blocks fresh sockets and later requests on existing HTTP/1.1 keep-alive
   connections. Requests admitted before drain may finish. Drain responses are typed
   `503 service-draining` and close the connection.

Byte-publication locks, public-network adversaries, multi-process fairness, distributed
verification, arbitrary external tamper exclusion, and production load-balancer drain guarantees
remain deferred to hosted phases.

## Independent Review

The independent reviewer initially reproduced two current-scope issues:

- drain did not wait for admitted handlers or block post-drain admission;
- a five-second health fixture could expire before the assertion it intended to test.

After correction, a second probe found that a keep-alive connection could submit another request
during drain. The handler boundary and regression were corrected. Final independent verification
reported no current-scope `BLOCKER` or `REQUIRED` code finding.

The final probe observed:

```text
first keep-alive request: 200
second request after drain: 503
reason: service-draining
Connection: close: confirmed
close(): completed
server thread: stopped
runtime status: stopped
```

## Gate B Proof

`tests/workflow/test_sf107_gate_b.py` proves four separate process-boundary scenarios:

1. queued work survives hard API termination and exact restart;
2. leased work retains ownership, expires deterministically, fences the stale claimant, and
   admits one new claimant generation;
3. canonical commit followed by response loss reconciles exactly without duplicate facts;
4. offline rebuild reproduces all seven projections and rejects the old continuation token.

The observable Gate B proof therefore passes: killing and restarting the operations process does
not lose or duplicate accepted work.

## Complete Pre-Final Ladder

The complete repository ladder passed before the final keep-alive review correction:

| Level | Result |
|---|---|
| Foundation | 112 passed in 34.611s |
| Component | 284 passed across bounded batches; 88 + 35 + 161 |
| Integration | 50 run in 822.680s; 49 passed, 1 explicit live-Azure skip |
| Workflow | 22 passed in 399.214s |
| Stress | 32 passed in 809.936s with `ResourceWarning` promoted to error |

The Component level was split after the command wrapper terminated one long aggregate process.
No test failure occurred. Each disjoint batch was rerun to completion, and the three batches
cover the complete `tests/component` inventory.

## Post-Review Delta Ladder

The final keep-alive correction was rerun at every relevant higher-risk level:

| Level | Result |
|---|---|
| Focused Component | keep-alive drain regression passed in 23.142s |
| SF-107 Component | 36 passed in 308.152s |
| Workflow | 22 passed in 386.462s |
| SF-107 Stress | 8 passed in 286.975s with `ResourceWarning` promoted to error |

The final Component slice includes fresh-socket drain, admitted-request completion, keep-alive
rejection, authenticated long-poll admission, runtime health, readiness, contracts,
reconciliation, projection validation, and durable API-store behavior.

## Closure Artifacts

The closure procedure additionally requires protocol validation, skill validation, compilation,
diff hygiene, package build, and installed-wheel verification. Exact final artifact hashes and
command results are retained under `.tmp/` so the packaged evidence file does not create a
self-referential wheel hash.

The evidence was assembled before staging. The user subsequently authorized one reviewed closure
commit with SF-200 and SF-201; git history is the source of truth for that commit identity. No
push, reset, clean, or history rewrite is authorized by this evidence.
