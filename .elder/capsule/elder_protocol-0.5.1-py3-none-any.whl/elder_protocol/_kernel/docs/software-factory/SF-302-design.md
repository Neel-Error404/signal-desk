# SF-302 Work Room Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Boundary

SF-302 is an owner-facing composition and admission layer. It does not own
work-item, run, session, workspace, checkpoint, artifact, approval, or
governance state.

```text
Control Room
  |
  +-- GET work room ----------------------+
  |                                       |
  |                         Operations ledger/projections
  |                         SF-105 run aggregate
  |                         SF-203 controls/events
  |                         SF-302 append-only owner notes
  |
  +-- POST owner input -------------------+
          |
          +-- note -> append-only SF-302 note
          |
          +-- steer/follow-up/pause/resume/cancel
                    -> exact SF-203 pending control
                    -> existing worker coordinator executes later
```

## Durable Sources

The operations database remains authoritative for the work item, current run
aggregate, canonical timeline, checkpoints, and artifacts. The configured
SF-203 session database remains authoritative for worker-session controls and
events.

SF-302 adds one append-only table to the session database for owner notes. A
note carries project, work item, optional run, author, correlation,
idempotency, content, timestamps, and a canonical digest. Immutable triggers
prevent update or deletion.

Steering input is not copied into the note table. The accepted SF-203 control
is the durable owner input and is rendered directly in the room.

## Read Model

`WorkRoom.snapshot`:

1. loads and validates the current work item;
2. identifies runs whose immutable initial binding names that work item;
3. validates each selected run through `RunController`;
4. loads matching timeline, checkpoint, and artifact records;
5. validates current SF-203 controls and append-only owner notes;
6. rejects project, work-item, run, session, generation, digest, or correlation
   drift;
7. emits a bounded, deterministically ordered, secret-scanned snapshot.

Before and after each composition attempt, the service fingerprints every
operations, projection, session-control, and note table that contributes to
the room. A changed source retries the complete read up to three times and
then fails explicitly rather than publishing a mixed-source snapshot.

The snapshot exposes the work plan from the accepted work-item payload. Test
and diff evidence are artifact references classified by their existing
artifact kind; SF-302 does not infer missing evidence.

## Owner Input

The route accepts a closed `work-room-input` payload with an input kind and an
input-specific body.

- `note` requires text and may bind to the current run.
- `steer` and `follow-up` require an instruction.
- `follow-up` additionally requires the current waiting control.
- `pause`, `resume`, and `cancel` require an owner reason.

Command input requires the exact current run identifier. Read-only composition
may select the sole current nonterminal run, or the latest historical run when
no current run exists. It fails closed when more than one current run exists.
A historical room exposes notes only and cannot advertise or admit worker
commands.

For commands, the service reconstructs identifiers and binding fields from the
validated current run aggregate and one unique current SF-203 control lineage
for the same run, session, workspace, and generation. It revalidates the
current SF-202 workspace lease, manifest, sandbox, and inspection state before
comparing that binding with the current SF-203 lineage. Older valid generations
remain historical evidence and cannot authorize a current command. If no
current lineage exists or digests conflict, admission fails closed.

The API request idempotency key is reused as the durable note or SF-203 command
idempotency key. Exact retries return the original result; changed reuse is a
conflict. Durable source timestamps come from the validated request
`submitted_at`, so response-loss reconciliation reconstructs the same note or
control rather than generating a time-dependent collision.

The browser retains the exact request body, idempotency key, and
`submitted_at` value while a response is uncertain. It permits only an exact
retry until the source-owned result is reconciled.

## API Durability

The operations API still owns authentication, project scope, active-runtime
fencing, and durable response replay. Work-room input is a source-owned
mutation:

- note result proof is the validated append-only note digest;
- command result proof is the validated SF-203 control digest;
- retry after a process loss reconstructs the exact source record by
  idempotency identity;
- an unconfigured Work Room returns an unapplied `503` before an idempotency
  execution record is admitted;
- no operations-journal mutation claim is made.

This is a separate replay-proof family from canonical operations mutations.

## Security And Redaction

- `owner-ui` clients with `human-owner` or `product-owner` role may read;
- only an `owner-ui` client with `product-owner` role may submit owner input;
- route project, body project, authenticated grant, work item, and run must
  agree;
- all requests, persisted notes, controls, and response snapshots receive the
  existing recursive secret-shaped-field scan;
- credentials remain browser-memory only;
- raw environment, terminal, file content, and provider secrets are not
  returned.

## Failure Conditions

The service fails explicitly for:

- missing or mismatched project/work item;
- no current run for a command input;
- multiple current runs without an exact requested run;
- missing or conflicting SF-203 workspace binding lineage;
- invalid run/session status for the requested command;
- stale follow-up target;
- idempotency collision;
- malformed or secret-shaped content;
- source database unavailability or integrity drift.

## Proof

Completion requires deterministic restart reconstruction, exact API replay,
message correlation, secret rejection, concurrent input tests, and a real
browser workflow at desktop and mobile widths.
