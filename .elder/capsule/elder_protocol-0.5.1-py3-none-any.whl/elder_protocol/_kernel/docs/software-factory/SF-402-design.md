# SF-402 Authority And Delegation Integration Design

**Status:** VERIFIED

## Decision

Factory Operations uses one `AuthorityDelegationIntegration` service. It does
not implement a second authority engine. The service composes:

```text
queued Work Item Ledger record
-> SF-401 immutable governed context packet
-> current generated project profile and resolved authority bindings
-> P4.5A parent, delegation, and assigned child run
-> P4.5B transactional submit and assigned-identity claim
-> durable owner decision
-> use-time context and lease verification
```

## Ownership

- Work Item Ledger owns current work state and revision identity.
- SF-401 owns context request, packet, source, and activation validation.
- P4.5A owns authority narrowing and parent-child run validation.
- P4.5B owns runtime submission, lease transitions, expiry, cancellation,
  journals, and replay.
- SF-402 owns only the Factory Operations composition and owner read model.

## Durable Decisions

The integration stores immutable accepted or rejected decisions in a separate
SQLite WAL store. Each record binds:

- a safe request digest in which the lease token is replaced by its SHA-256;
- project, work item, delegation, child run, and requester;
- the exact governed context packet and digest;
- the submitted parent, delegation, and child authority artifacts;
- the complete persisted lease artifact without the raw token;
- runtime event count, reason code, actionable reason, and decision time.

The raw lease token remains an ephemeral caller capability. It is not written
to either durable store.

## Start And Child Gate

The same gate applies to the first delegated child and any later child
delegation. It validates the complete run chain before context use, submits the
chain through P4.5B, and claims only for `assigned_identity_id`. Exact retries
reconcile with an already submitted chain or already claimed matching lease.
A different chain, token digest, or request body fails closed.

## Execution Recheck

Before execution the service requires:

- one accepted start decision;
- the exact authorized context digest;
- one active lease for the exact child and assigned identity;
- a matching lease-token digest;
- current time before lease expiry;
- a still-current SF-401 activation, work item, run chain, source set, and
  packet.

## Owner View

The read model reports `authorized`, `waiting-for-lease`, `lease-released`,
`lease-expired`, `cancelled`, `expired`, or `blocked` with an actionable
reason. Rejected starts remain visible after restart. Owners do not need raw
SQLite rows or runtime terminal history.

## Non-Claims

SF-402 does not authenticate remote identities, execute tools, create hosted
leases, add a broker, raise maturity, implement SF-403 evidence completion, or
grant approval, promotion, merge, release, or deployment authority.
