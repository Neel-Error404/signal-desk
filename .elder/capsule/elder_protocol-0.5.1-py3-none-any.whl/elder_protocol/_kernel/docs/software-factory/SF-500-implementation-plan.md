# SF-500 Implementation Plan

**Status:** COMPLETED

1. Activate SF-500 from the clean pushed maturity-standard closure.
2. Read the Phase 5 task, proportional-delivery rule, current operational
   schemas, P4.6 boundary, Prime references, and Gate F clause.
3. Define closed source-manifest and normalized-trajectory schemas.
4. Implement one pure read-only normalizer with exact bindings, redaction,
   exclusions, missing links, and deterministic sampling.
5. Add a `learning normalize` CLI that requires no P4.6 store or project
   profile.
6. Prove outcome delay and expected-reference attachment without inference.
7. Prove the existing P4.6 learning store is unchanged.
8. Run Foundation, Component, Integration, Workflow, and Stress in order.
9. Complete an independent correctness review and correct all current-scope
   findings.
10. Validate protocol, build the package, verify the installed wheel outside
    the checkout, update evidence, roadmap, README, and Obsidian, then commit
    and push SF-500 separately.
11. Stop SF-500 closure before beginning SF-600.
