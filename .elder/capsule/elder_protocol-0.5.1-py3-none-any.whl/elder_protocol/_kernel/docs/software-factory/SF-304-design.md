# SF-304 Audit And Replay View Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Architectural Boundary

SF-304 is a read model over existing durable truth:

```text
immutable operations journal -> timeline projection ----+
owner decision store -----------------------------------+
work-room notes and controls ----------------------------+-> audit snapshot
run checkpoints and artifacts --------------------------+
```

It creates no alternate event stream and no mutable audit record. The journal
remains canonical for operations mutations covered by SF-106. SF-302 and
SF-303 records that are not yet journal sources are included as separately
identified digest-bound records and declared as non-journal limitations.

## Audit Entry Contract

Each entry has:

- stable audit entry id and source kind;
- event time and deterministic order;
- project, work item, and optional run binding;
- actor identity and kind when recorded;
- correlation and causation identifiers when recorded;
- summary plus the exact source digest;
- authority references and evidence references when recorded;
- journal sequence, entry digest, and previous-entry digest for journal facts;
- a closed list of limitation codes.

An absent field is represented as `null` and paired with a limitation. The
service never derives a human identity from a display label, treats ownership
as authority, or treats an artifact name as evidence of validity.

## Replay Semantics

Replay means deterministic reconstruction, not re-execution. The service:

1. verifies the current journal and timeline projection;
2. assembles journal-backed entries for the work item and selected run;
3. computes their ordered identity and content digest;
4. exposes the active projection generation and journal tip;
5. supports a component/workflow proof that rebuilding the timeline from the
   immutable journal reproduces those journal-backed entries.

The read request does not reset or rebuild projections. Projection rebuild is
an operator/test action using the existing SF-106 runtime.

## Correlation Rules

Journal records qualify when the work-item id is the source subject or appears
in registered parent ids. A selected run adds entries whose source subject or
parent ids bind that run. Non-journal records qualify only through their exact
stored project, work-item, and run fields.

Entries are ordered by occurrence time, journal sequence when available,
source kind, and entry id. Duplicate source identities are rejected.

## Authority And Evidence

Authority is exposed only from explicit source fields such as transition
authority records, decision roles, and command authorization references.
Evidence is exposed only from explicit evidence references, checkpoint
references, or artifact references.

The audit view reports:

- `actor-not-recorded`;
- `causation-not-recorded`;
- `authority-not-recorded`;
- `evidence-not-recorded`;
- `outside-operations-journal`.

These limitations are factual boundaries, not warnings that can be dismissed.

## Consistency And Failure

The service fingerprints journal, projections, work-room sources, and owner
decision sources before and after assembly. It retries at most three times.
Persistent source movement raises `OperationsReadUnavailableError`.

Schema, digest, project binding, duplicate identity, journal integrity, or
projection integrity failures are explicit. The service does not return a
partial snapshot after an integrity failure.

## API And UI

The owner route is:

`GET /v1/projects/{project_id}/work-items/{work_item_id}/audit-replay`

It uses numeric loopback, bearer policy, owner roles, readiness checks, and the
existing generic response envelope. The control room presents a compact audit
view with source filters, journal proof, authority/evidence references, and
visible limitations.

## Evidence

Completion evidence must show exact route contracts, deterministic snapshot
digests, journal rebuild equality, missing-link behavior, restart survival,
responsive browser operation, focused review, and installed-package import.
