# SF-300 Owner Inbox Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-13

## Ordered Test Ladder

1. Foundation schemas and semantic validation.
2. Component source mapping, priority, age, actions, and coalescing.
3. Integration separate-store restart determinism.
4. Workflow authenticated API and owner-facing behavior.
5. Stress concurrent stable reads.

Run only the current level. Correct the root cause and rerun that level before
advancing.

## Expected Initial Assertions

- every eligible work-item, session, recovery, and orphan record contributes
  evidence;
- no ineligible terminal-success record appears;
- duplicate reason-family records coalesce;
- coalescing retains every unique evidence reference;
- urgent items sort before high items;
- older items sort before newer items at the same severity;
- age is reproducible from explicit `observed_at`;
- source corruption, missing tables, and secret-shaped records fail closed;
- actions are descriptive and do not mutate source stores.

## Results

### Foundation

```powershell
py -m unittest tests.foundation.test_owner_inbox_contract -v
```

Final result: `5 passed` in `0.149s`.

The existing SF-107 contract foundation was rerun after the route registry
extension:

```powershell
py -m unittest tests.foundation.test_owner_inbox_contract `
  tests.foundation.test_product_factory_registry `
  tests.foundation.test_operations_api_design -v
```

Result: `33 passed` in `26.603s`.

After adding the explicit global-route grant, the two affected Foundation
checks were run. The auth-policy check correctly rejected an invalid
project-scoped global grant; its stale error-message expectation was corrected
and only that failed check was rerun. Effective final result: `2 passed`.

### Component

```powershell
py -m unittest tests.component.test_owner_inbox -v
```

An earlier full run passed eight tests and exposed one stale test expectation
after source corruption was intentionally reclassified from a client error to
source unavailable. Only that failed test was rerun at that point:

```powershell
py -m unittest `
  tests.component.test_owner_inbox.OwnerInboxComponentTests.test_session_index_drift_fails_closed `
  -v
```

After the independent review corrections, the complete SF-300 Component
module was rerun:

```powershell
py -m unittest tests.component.test_owner_inbox -v
```

Final result: `11 passed` in `22.401s`. Coverage includes exact duplicate
deduplication, durable indexed-row tamper, history binding, chronology,
per-source counts, missing stores, recovery/session identity mismatch,
work-item source corruption, and three-attempt cross-store drift.

The existing API-server Component module was rerun after adding the 46th
route:

```powershell
py -m unittest tests.component.test_operations_api_server -v
```

Result: `6 passed` in `120.541s`. Every registered route resolves to its exact
contract.

The auth-policy Component module was rerun for exact global-route behavior:

```powershell
py -m unittest tests.component.test_operations_api_auth -v
```

Result: `3 passed` in `2.606s`. An unfiltered route requires an explicit
non-project grant, and invalid global grants fail closed.

The existing SF-107 contract loader also passed:

```powershell
py -m unittest tests.component.test_operations_api_contracts -v
```

Result: `9 passed` in `9.871s`.

### Integration

```powershell
py -m unittest tests.integration.test_owner_inbox_restart -v
```

Final result: `1 passed` in `13.313s`. Separate operations, session, and recovery
stores reopened to the identical digest-bound snapshot.

### Workflow

```powershell
py -m unittest tests.workflow.test_sf300_owner_inbox_api -v
```

An initial authorization remediation denied unscoped reads, which protected
project data but made projectless recovery-orphan attention unreachable. The
final workflow requires an explicit `global_route_ids` grant for the
unfiltered queue, denies a cross-project filter, and permits the client's
granted project. Final result: `1 passed` in `26.152s`.

The first workflow attempts timed out because the broad SQLite `data_version`
check observed SF-107 runtime-heartbeat writes. A captured run reproduced the
retryable `503`. The root fix narrowed coherence checks to SF-300 source-table
fingerprints, and only the failed workflow was rerun.

### Stress

```powershell
py -m unittest tests.stress.test_owner_inbox_concurrency -v
```

Final result: `1 passed` in `50.468s`. Thirty-two reads across eight threads returned
identical snapshots while source rows remained stable.

### Validation And Package

```powershell
py -m elder_protocol.cli validate
py -m elder_protocol.cli skills validate
py -m build --outdir .tmp\sf300-closure-dist-20260813
```

Both validations passed. The build produced
`elder_protocol-0.5.1.tar.gz` and
`elder_protocol-0.5.1-py3-none-any.whl`.

The wheel was installed into `.tmp\sf300-closure-install-20260813` with its
declared dependencies. From an isolated interpreter outside the checkout, the
installed kernel loaded `OwnerInbox`, the two schemas, the 46-route registry,
the `owner-inbox-snapshot` binding, and the explicit `global_route_ids` auth
schema successfully.

## Review Result

The final independent narrow review reported no `BLOCKER` or `REQUIRED`
finding. It verified exact global grant enforcement, projectless orphan
visibility under that grant, continued cross-project denial, recovery/session
identity binding, and the 46-route regression correction.

## Root-Cause Corrections

- indexed SQLite columns and history tips are compared with canonical records;
- item chronology is bound to evidence and snapshot observation time;
- per-source counts are recomputed from unique evidence;
- the reducer is internal and production reads validate canonical source rows;
- exact duplicate source rows deduplicate;
- source-table fingerprints provide bounded cross-store coherence;
- work-item fingerprints cover every table consumed by aggregate reads;
- API heartbeat writes no longer create false source drift;
- owner-inbox HTTP reads require a project grant matching the query;
- unfiltered owner-inbox reads require a separate exact global-route grant;
- recovery-case identity must match the current linked session control;
- missing, corrupt, or unstable sources return retryable unavailable behavior.
