# SF-301 Product Portfolio And Work Board Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Ordered Test Ladder

Run only the invalidated level after a correction.

### Foundation

```powershell
py -m unittest tests.foundation.test_owner_portfolio_contract `
  tests.foundation.test_operations_api_design -v
```

Final result: `26 passed` in `7.546s`.

The closed snapshot contract verifies digest, secret rejection, ordering,
unique project counts, route identity, exact registry digests, and auth-policy
compatibility.

### Component

```powershell
py -m unittest tests.component.test_owner_portfolio -v
```

Final result: `4 passed` in `0.017s`.

The portfolio component verifies current dependency resolution, distinct
failed and cancelled dependencies, filter binding, paging, stale cursors, and
explicit invalid-filter errors.

The complete API-server component module passed earlier with all six tests.
After the final static-asset correction, only its invalidated real-loopback
test was rerun:

```powershell
py -m unittest `
  tests.component.test_operations_api_server.OperationsApiServerComponentTests.test_real_loopback_server_enforces_transport_and_auth_contracts `
  -v
```

Final result: `1 passed` in `34.405s`. HTML, JavaScript, CSS, and the favicon
are served with no-store and same-origin security headers.

The existing auth and API contract component modules also passed: `12 tests`.

### Integration

```powershell
py -m unittest tests.integration.test_owner_portfolio_api -v
```

Final result: `1 passed` in `61.861s`.

The real loopback API accepts an exact owner grant, rejects an unauthorized
project filter, and returns a zero-lag portfolio bound to the current product
and work-item projections.

### Workflow

The control room was exercised in Chrome against the real loopback runtime:

1. authenticate with a local `owner-ui` client;
2. load the current portfolio and product navigation;
3. switch between board and list modes;
4. apply text filtering and manually refresh;
5. reload and confirm in-memory credentials are cleared;
6. verify desktop at `1440x900`;
7. verify mobile at `390x844`.

The authenticated desktop and mobile views rendered the current work item,
had zero page-level horizontal overflow, and contained the wide board in its
own scroll region. Final reload produced no console messages. The document,
stylesheet, script, and favicon all returned `200`.

### Stress

```powershell
py -m unittest tests.stress.test_owner_portfolio_backlog -v
```

Final result: `1 passed` in `0.333s`.

The large-backlog fixture verifies bounded pages, deterministic filters, and
continuation behavior.

## Validation And Package

```powershell
py -m elder_protocol.cli validate
py -m elder_protocol.cli skills validate
py -m build --outdir .tmp\sf301-closure-dist-20260814-r2
```

Both Elder validations passed. The clean build produced
`elder_protocol-0.5.1.tar.gz` and
`elder_protocol-0.5.1-py3-none-any.whl` without the initial control-room
package-discovery warning.

The wheel was installed into
`.tmp\sf301-closure-install-20260814`. From an isolated working directory,
the installed package loaded `OwnerPortfolio`, the 47-route registry,
`owner-portfolio-get`, the packaged owner-portfolio schema, and all four
control-room assets.

## Review Corrections

The focused final review found and corrected:

- duplicate or unsorted per-project count rows were not rejected explicitly;
- the browser requested an undeclared favicon;
- the first package build treated the static directory as ambiguous package
  data.

Only the levels invalidated by those corrections were rerun. No remaining
current-scope blocker or required correction was found.
