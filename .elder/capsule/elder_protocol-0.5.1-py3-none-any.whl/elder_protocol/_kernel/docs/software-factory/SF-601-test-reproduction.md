# SF-601 Test Reproduction

**Status:** VERIFIED on 2026-08-14

## Foundation

```powershell
py -m unittest tests.foundation.test_sf601_hosted_identity_contract -v
```

## Component

```powershell
py -m unittest tests.component.test_sf601_hosted_identity -v
```

## Integration

```powershell
py -m unittest tests.integration.test_sf601_hosted_identity -v
```

## Workflow

```powershell
py -m unittest tests.workflow.test_sf601_hosted_identity -v
```

## Stress

```powershell
py -m unittest tests.stress.test_sf601_hosted_identity_concurrency -v
```

## Additional

```powershell
py -m compileall -q elder_protocol tests
py -m elder_protocol.cli validate
git diff --check
```

## Clean Package

```powershell
py -m build --outdir .tmp\dist-sf601-20260814-1
py -m pip install --no-deps `
  --target C:\Users\neela\AppData\Local\Temp\elder-sf601-installed-final-20260814 `
  .tmp\dist-sf601-20260814-1\elder_protocol-0.5.1-py3-none-any.whl
```

Artifacts:

- wheel: `61F30D3679B16DDDAD2907FDC1DC8D1E547B934E1560D29A269C92E46136FE84`
  SHA-256, 2,419,696 bytes;
- source distribution:
  `F415E5D706855636F5A88E4D9F9C1A457BCE2CBF27C0F5042B5B101F0419F6C7`
  SHA-256, 1,867,818 bytes.

The wheel was imported from the fresh target while the process ran from
`C:\Users\neela`. The installed-package workflow verified an RS256 workload
token, issued one scoped credential, produced two durable secret-free audit
events, and reconstructed the active lease after reopening the audit database.

The first installed-package check expected the terminal event name
`credential.issued`; the implemented and tested contract is
`broker.credential.issued`. The verification script was corrected and the same
installed-package level passed.

## Corrected Ladder Results

| Level | Result |
|---|---|
| Foundation | 3 passed |
| Component | 13 passed |
| Integration | 1 passed |
| Workflow | 2 passed |
| Stress | 1 passed |

Total focused qualification: 20 passed.

Affected regression checks also passed:

- operational architecture and product factory registry: 14;
- hosted qualification and P5.1/P5.2/P5.3 identity consumers: 38.

## Limitations

- No external identity provider, secret broker, cloud resource, hosted
  persistence, or production credential was created or contacted.
- Test credentials are synthetic bytes from a fake provider.
- Workspace injection belongs to SF-602; production integration and hosted Git
  enforcement belong to SF-603 and SF-604.
- Current signed hosted qualification and human L2 ratification remain SF-606.
