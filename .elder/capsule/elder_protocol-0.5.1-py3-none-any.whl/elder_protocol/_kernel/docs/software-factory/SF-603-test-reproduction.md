# SF-603 Test Reproduction

**Status:** VERIFIED on 2026-08-15

## Foundation

```powershell
py -m unittest tests.foundation.test_sf603_production_integration_contract -v
```

## Component

```powershell
py -m unittest tests.component.test_sf603_production_integrations -v
```

## Integration

```powershell
py -m unittest tests.integration.test_sf603_production_integrations -v
```

## Workflow

```powershell
py -m unittest tests.workflow.test_sf603_production_integrations -v
```

## Stress

```powershell
py -m unittest tests.stress.test_sf603_production_integration_concurrency -v
```

## Static And Protocol Checks

```powershell
py -m ruff check `
  elder_protocol/factory_operations/production_integrations.py `
  elder_protocol/factory_operations/__init__.py `
  tests/_sf603_support.py `
  tests/foundation/test_sf603_production_integration_contract.py `
  tests/component/test_sf603_production_integrations.py `
  tests/integration/test_sf603_production_integrations.py `
  tests/workflow/test_sf603_production_integrations.py `
  tests/stress/test_sf603_production_integration_concurrency.py
py -m compileall -q elder_protocol tests
py -m elder_protocol.cli validate
git diff --check
```

## Final Results

| Level | Result |
|---|---:|
| Foundation | 3 passed |
| Component | 21 passed |
| Integration | 1 passed |
| Workflow | 1 passed |
| Stress | 3 passed |

Total focused SF-603 qualification: 29 passed.

Independent adversarial re-review also passed 8 direct probes.

## Failure And Correction Record

1. Foundation initially imported a nonexistent test helper. The contract test
   now reads repository documents through the canonical root; Foundation
   passed.
2. The first Component setup used a broker request identifier containing a
   secret-shaped word. The non-secret identifier was corrected; Component
   advanced.
3. Credential rejection originally occurred after a command intent. Broker
   provenance is now validated before intent and held through provider access.
4. Reconciliation credential rejection and malformed provider pages could
   strand an unresolved read intent. Credential access now precedes intent,
   and every invalid page records a terminal safe failure.
5. A failed dead-letter replay generation could not advance to its next
   bounded attempt. Attempt identities are now generation- and attempt-bound.
6. Exact webhook duplicates originally returned before HMAC re-verification.
   Every duplicate now rechecks the live broker key and canonical signature.
7. Independent review found that the signature omitted source and provider
   event identity. HMAC now covers canonical source, event, timestamp, and
   body-digest fields.
8. Independent review found completed command, reconciliation, and replay
   paths accepted expired credentials. All durable return paths now recheck
   the live SF-601 credential.
9. Independent review found replay state could mutate before authorization.
   Current policy, workload identity, and credential checks now precede replay
   lookup and mutation.
10. Independent review found cursor cycles, future timestamps, and conflicting
    policy generations. Durable cursor history rejects cycles, future
    webhooks fail, and each audit ledger is bound to one policy digest.

Final independent disposition:

```text
BLOCKER: None
REQUIRED: None
```

## Package And Installed Verification

```powershell
py -m build --outdir .tmp\dist-sf603-20260815-1
py -m pip install --no-deps `
  --target C:\Users\neela\AppData\Local\Temp\elder-sf603-installed-final-20260815 `
  .tmp\dist-sf603-20260815-1\elder_protocol-0.5.1-py3-none-any.whl
```

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `elder_protocol-0.5.1-py3-none-any.whl` | 2,490,184 | `E77886553192A99B074B90EF8BCC6165F1DFB98283C804AD450ABCD23DBFBA11` |
| `elder_protocol-0.5.1.tar.gz` | 1,920,999 | `1842F94AA557079EC48FD62862F9FF3AF1795ED31D2AA1119A0F6DA434A5F25E` |

The wheel was imported from the fresh target while the current directory was
`C:\Users\neela`, outside the checkout. The installed-package workflow:

- issued a live SF-601 broker credential;
- accepted one canonically signed webhook;
- delivered one authenticated idempotent command;
- reconciled one external record page;
- reconstructed all three states after manager restart;
- confirmed request-body and credential bytes were absent from the integration
  audit database.

## Limitations

- No GitHub, issue tracker, chat, CI, or notification provider was contacted.
- The SQLite audit is a local provider-neutral proof, not a hosted production
  retention claim.
- Branch rules, required checks, independent hosted review, and provenance
  activation belong to SF-604.
- Multi-product isolation belongs to SF-605.
- Signed hosted qualification and L2 ratification belong to SF-606.
- Canonical Elder maturity remains L1.
