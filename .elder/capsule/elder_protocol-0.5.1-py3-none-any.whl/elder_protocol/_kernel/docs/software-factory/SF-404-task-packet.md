# SF-404 Task Packet

**Status:** VERIFIED

## Outcome

Eligible local work produces one exact P5.2 supervised pull-request packet and
an accountable owner can submit or reject it without gaining merge, release,
deployment, or maturity authority.

## Bounded Scope

- compose the current SF-402 authority decision and assigned-child lease;
- reverify the current SF-403 completion, diff, artifacts, tests, and evaluator;
- consume caller-supplied signed P4.7/P5.0-P5.2 trusted sources;
- invoke the existing P5.2 lease, packet, submission, and response validators;
- persist owner-visible authorized, ready, blocked, rejected, submitting, open,
  and reconciliation-required states;
- persist the owner submit or reject decision before provider invocation;
- prevent blind retry after an uncertain or rejected provider response.

Canonical P5.2 authority remains inactive. Gate E qualification, hosted
provisioning, real pull-request creation, merge, release, and deployment are
outside this task.

## Acceptance

1. The SF-402 authority and SF-403 completion are rechecked before P5.2
   authorization, packet creation, and submission.
2. The autonomy work item matches the exact Factory Operations project and work
   item.
3. The P5.2 lease and packet come only from existing trusted-source
   recomputation.
4. The hosted execution links the SF-403 completion and exact lower-level test
   records.
5. Only the product owner can submit or reject a ready packet.
6. Provider invocation begins only after the owner decision is durable.
7. An accepted response matches the exact packet, provider, repository,
   branches, revisions, diff, and trusted URL prefix.
8. Restart and exact concurrent submit preserve one durable owner view and at
   most one provider call.

## Failure Conditions

- expired qualification;
- inactive certification;
- stale or cancelled SF-402 authority;
- changed or missing SF-403 proof;
- unprotected base branch;
- changed execution, packet, provider response, or URL;
- unauthorized owner decision;
- response uncertainty without reconciliation.

## Finding Dispositions

- Hosted branch protection and real provider identity remain signed fixture
  evidence in SF-404; real hosted operation belongs to Phase 6.
- Canonical P5.2 readiness remains blocked by the empty canonical authority
  source and is not changed here.
- Gate E qualification remains a separate proof after SF-404 closure.
