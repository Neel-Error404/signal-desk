# SF-500 Task Packet

**Status:** VERIFIED

## Outcome

Worker actions, owner corrections, tests, retrieval, incidents, and explicit
outcomes can be composed into one bounded, versioned learning trajectory
without copying raw prompts, outputs, transcripts, or secrets.

## Bounded Scope

- validate one caller-produced source manifest;
- reject source files above the raw input byte limit before JSON parsing;
- require exact project, work-item, run, timestamp, evidence, and source-digest
  bindings;
- require opaque source and evidence references rather than free-form content;
- normalize structured facts from trusted primary, secondary, and historical
  sources;
- redact raw-content and secret-shaped fields;
- preserve required and owner/outcome/incident anchor events;
- sample optional events deterministically within declared count and byte
  budgets;
- expose exclusions, redactions, missing links, and delayed outcomes;
- emit a read-only artifact through `learning normalize`.

SF-501 through SF-507 are outside this task. SF-500 does not detect reusable
lessons, create a learning candidate, invoke Prime refinement, evaluate,
approve, promote, apply, monitor, or retrieve learned targets.

## Acceptance

1. All six declared trajectory categories can be normalized.
2. Every event retains source, producer, authority, binding, evidence, and
   digest provenance.
3. Raw content, secret-shaped fields, secret values, and secret references do
   not reach the normalized artifact.
4. Duplicate identities, changed source bindings, invalid digests, future
   records, free-form references, and required untrusted or oversized sources
   fail closed.
5. Optional oversize or untrusted sources are explicitly excluded.
6. Required and anchor events survive bounded deterministic sampling.
7. Input ordering cannot change the selected trajectory or final digest.
8. Only complete explicit measurements for every expected outcome can attach;
   delayed, unknown, partially measured, contradictory, or mismatched outcomes
   remain pending or contradictory.
9. Normalization does not create or mutate a P4.6 learning candidate or store.
10. The CLI cannot overwrite its source manifest.

## Failure Conditions

- invalid or changed source manifest digest;
- source project, work-item, run, timestamp, or evidence mismatch;
- same source identity with changed content or metadata;
- anchor set larger than the declared trajectory budget;
- secret material remaining after normalization;
- output ordering, count, byte, event digest, or outcome reconstruction
  mismatch.

## Authority And Maturity

The source manifest is an adapter contract, not new authority. Candidate
authority is excluded from trusted trajectory events. The output is evidence
input only and cannot approve, promote, or mutate governed state.

Canonical Elder maturity remains L1. Gate F remains unqualified.
