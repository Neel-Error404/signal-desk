# Gate C - Issue To Evidence Qualification

**Status:** VERIFIED

**Change class:** bounded local qualification harness and evidence

**Owner:** factory operations

**Approver:** human repository owner

**Dependencies:** SF-107, SF-200, SF-201, SF-202, SF-203, SF-205, SF-206

**Source revision:** `d907ad5a066f2e4ed69054762fed701de3f767a5`

## Outcome

One synthetic issue enters the durable local factory, becomes one canonical work
item and run, executes through the real Codex worker in an SF-202 workspace,
survives an operations-process termination and restart, and reaches one
digest-bound supervised delivery packet containing the exact diff, tests,
checkpoint, worker evidence, and final factory state.

## Non-Goals

- Phase 3 owner UI, inbox, work board, or work room;
- merge, release, deployment, branch protection, or hosted execution;
- creating a second run, worker contract, recovery subsystem, or evidence
  authority;
- treating test fixtures as canonical project authority outside the isolated
  qualification;
- claiming L2, L3, hosted durability, or production readiness.

## Required Guarantees

- the signal, work item, dispatch, run, workspace, worker session, controls,
  checkpoint, artifact, and final packet share exact identity and digest
  lineage;
- the real Codex adapter executes inside the exact SF-202 workspace and does
  not stage or commit;
- the first qualification process is terminated only after the worker effect
  and accepted SF-203 result are durable;
- the restarted process reopens the same stores and resumes the same provider
  thread without issuing another start or prompt effect;
- tests and the Git diff are collected from the qualified workspace after
  restart;
- the worker evidence bundle is verified and recorded as the run's
  `evidence-bundle` artifact before completion;
- the final run is completed, its work item is terminal, and all packet
  references validate from durable state;
- the packet records limitations and cannot authorize merge, release,
  deployment, promotion, or maturity mutation.

## Failure Conditions

- the live workflow is skipped or replaced by a deterministic worker;
- restart creates a new provider thread or repeats the worker effect;
- the final diff or test result is missing, stale, or from another workspace;
- any packet reference cannot be reconstructed from the persisted stores;
- the run completes without a checkpoint and verified evidence bundle;
- the proof depends on Phase 3 UI behavior;
- the evidence document is marked verified before the live proof passes.

## Phase Proportionality

Current phase: Phase 2 exit qualification.

Declared runtime: Windows local loopback, SQLite, one active operations
process, one synthetic repository, one SF-202 worktree, and one real Codex
worker session.

Gate C closes only this bounded local issue-to-evidence claim. Canonical
maturity remains L1.

## Test Plan

1. Foundation: closed qualification schema, validator, documentation contract,
   content digest, and secret rejection.
2. Component: packet construction, exact lineage, missing evidence, duplicate
   effect, and broader-authority rejection.
3. Integration: two spawned qualification processes use the same durable
   stores; the first is terminated after a deterministic worker effect and the
   second completes without replay.
4. Workflow: the same spawned-process proof runs with the real Codex adapter,
   produces the requested change, runs the declared test, and emits a passing
   packet.
5. Stress: concurrent restart finalizers cannot produce two terminal packets
   or repeat the accepted worker effect.

## Completion Gate

Gate C closes only after the ordered focused ladder passes, the real Codex
workflow is recorded, independent review has no current-scope blocker or
required finding, package installation includes the schema and validator,
closure documentation is updated, and the Gate C change is committed
separately before SF-300 begins.

All required conditions passed on 2026-08-13. Canonical maturity remains L1.

## Handoff

After the closure commit, activate `SF-300 - Owner Inbox And Attention Model`
from the clean Gate C revision.
