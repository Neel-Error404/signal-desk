# SF-302 Work Room Test Reproduction

**Status:** VERIFIED

**Date:** 2026-08-14

## Ordered Test Ladder

Only invalidated levels were rerun after review corrections.

### Foundation

```powershell
py -m unittest tests.foundation.test_operations_api_design `
  tests.foundation.test_work_room_contract -v
```

Final result: `25 passed` in `5.478s`.

The Foundation proof covers closed schemas, digest-bound records, allowed
owner-input kinds, secret rejection, exact routes and bindings, source-record
replay semantics, and pinned registry digests.

### Component

```powershell
py -m unittest tests.component.test_work_room `
  tests.component.test_workspace_lifecycle.WorkspaceLifecycleComponentTests.test_prepare_validate_lease_binding_and_clean_release -v
```

Final result: `4 passed` in `152.525s`.

The component proof covers room composition, immutable exact note replay,
changed-payload collision, the closed five-command mapping, actual SF-203
steering admission, exact run selection, current-generation selection, current
SF-202 workspace binding revalidation, expired and released lease rejection,
historical-room note-only behavior, restart reconstruction, and fail-closed
malformed input.

The invalidated real-loopback route-count assertion also passed separately
after the route registry moved from 47 to 49 routes. The rest of that API
server module and the unchanged operations API contract component module had
already passed and were not rerun.

### Integration

```powershell
py -m unittest tests.integration.test_work_room_api -v
```

Final result: `1 passed` in `149.714s`.

The real loopback API returned the room, accepted an authenticated owner note,
bound its durable timestamp to request `submitted_at`, replayed the exact
response, rejected mutation while the Work Room was unavailable without
admitting idempotency state, accepted an actual steer input, rejected a changed
current workspace binding as a deterministic conflict, restarted, and
reconstructed one note plus one steer control.

### Workflow

```powershell
py -m unittest tests.workflow.test_sf302_control_room -v
```

Final result: `1 passed` in `0.001s`.

The workflow contract verifies that the packaged control room exposes the
room navigation, plan, activity, evidence, and closed owner-input controls.

Chrome then exercised the real loopback runtime:

1. authenticate as the granted local owner;
2. open the current work item from the portfolio board;
3. inspect plan, activity, and evidence;
4. submit an owner note, simulate response loss after the server commits it,
   and retry the byte-equivalent request;
5. confirm both responses are `201` while only one durable note exists;
6. submit an actual steer command and confirm one pending SF-203 control;
7. refresh and confirm the note and control remain;
8. verify desktop at `1280x609`;
9. verify mobile at `390x844`.

Both layouts had zero page-level horizontal overflow. The mobile room had no
overflowing descendants, every Work Room request returned `200` or `201`, and
the browser produced no console warning, error, or issue.

### Stress

```powershell
py -m unittest tests.stress.test_work_room_concurrency -v
```

Final result: `1 passed` in `1.281s`.

The stress fixture submitted 32 exact retries and 32 distinct owner notes.
The exact identity produced one durable row and every distinct identity was
preserved.

## Validation And Package

```powershell
py -m compileall -q elder_protocol tests
node --check elder_protocol/factory_operations/control_room/app.js
py -m build --outdir .tmp\sf302-closure-dist-20260814-r4
```

Compilation and JavaScript syntax checks passed. The clean package build
produced `elder_protocol-0.5.1.tar.gz` and
`elder_protocol-0.5.1-py3-none-any.whl`.

The wheel was installed into
`.tmp\sf302-closure-install-20260814-r4`. From an isolated working directory,
the installed package loaded `WorkRoom`, the 49-route registry, both Work Room
routes, all four Work Room schemas, and all four control-room assets.

## Review Corrections

The focused closure review corrected:

- command admission could select a run implicitly instead of requiring the
  exact run identifier;
- historical rooms could advertise command controls even though only a current
  run may receive them;
- command admission trusted a historical SF-202 binding instead of
  revalidating the current workspace lease and manifest;
- source mutations could enter reconciliation when the Work Room was not
  configured instead of returning an unapplied `503`;
- deterministic source-binding conflicts could be classified as unknown
  reconciliation failures;
- the browser could generate a new request identity after response loss rather
  than retaining the exact pending request;
- the design allowed `human-owner` submission while the route contract
  correctly restricts submission to `product-owner`;
- command and browser evidence did not cover actual steering and response-loss
  replay end to end;
- durable note and command reconstruction used server observation time instead
  of request `submitted_at`;
- room stability checked only the work item while notes, controls, run state,
  timeline, projections, checkpoints, or artifacts could change during
  composition;
- the snapshot digest omitted the rendered timeline.

Only the invalidated Foundation, Component, Integration, and Stress levels
were rerun after backend corrections. The Workflow contract and browser proof
were rerun after the exact-retry UI correction.
