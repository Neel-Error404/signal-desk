# Gate C Issue To Evidence Qualification Design

**Status:** IMPLEMENTED

**Date:** 2026-08-13

## Boundary

Gate C adds a qualification harness around existing SF-100 through SF-206
production behavior. It does not add a second execution path.

```text
synthetic issue
    |
    v
signal -> work item -> dispatch -> run/workspace/session
                                      |
                                      v
                                 real Codex turn
                                      |
                         durable result before acknowledgement
                                      |
                         first operations process terminated
                                      |
                                      v
                         reopened stores and same thread
                                      |
                   diff + test + checkpoint + worker evidence
                                      |
                                      v
                     completed run + Gate C delivery packet
```

## Qualification Harness

The harness has three responsibilities:

1. execute the bounded synthetic workflow through the existing production
   classes;
2. persist a restart manifest containing only stable identifiers and digests;
3. validate and emit one closed Gate C packet after restart.

The harness supports an injected deterministic Codex runtime for lower-level
tests. A packet can receive a passing Gate C verdict only when the workflow
records the real Codex provider and the explicit live-workflow flag.

## Process Boundary

The parent qualification command launches phase one in a child process. Phase
one persists the accepted worker result, emits a ready marker, and waits. The
parent terminates that process without running in-process cleanup.

Phase two starts in a new process against the same stores and workspace. It
must:

- reopen the run controller, workspace manager, Codex adapter, session
  controller, and recovery coordinator;
- validate the restart manifest against durable records;
- resume the exact external provider thread;
- avoid a second start or prompt effect;
- collect and bind the post-restart evidence.

An intentional method call on a new object is not sufficient for the live
proof. The operating-system process identifier and boot identifier must change.

## Synthetic Repository

The qualification creates a disposable Git repository containing:

- `TASK.md` with one exact bounded change request;
- a small deterministic test owned by the fixture;
- no credentials, network requirement, or dependency installation.

Codex creates one untracked result file and does not stage or commit it. The
test verifies the exact requested content. The packet binds the baseline
revision, workspace status, diff digest, test command, exit code, and output
digest.

## Durable Lineage

The final packet binds:

- accepted signal and canonical work-item revisions;
- dispatch and run initial binding;
- SF-202 workspace manifest and sandbox digest;
- SF-203 start and prompt controls;
- external Codex thread reference and accepted prompt-response digest;
- restart process identifiers and restart manifest digest;
- canonical checkpoint reference;
- worker evidence bundle and run artifact reference;
- Git baseline, changed paths, diff digest, and test evidence;
- final run and work-item states.

Every embedded record is represented by stable identity plus content digest.
The packet itself uses the repository's canonical record digest convention.

## Completion Rules

A passing packet requires:

- exactly one accepted issue-to-work-item lineage;
- exactly one run, workspace, and worker session;
- one real Codex prompt effect;
- different pre-restart and post-restart process/boot identities;
- the same provider thread before and after restart;
- a non-empty bounded diff and passing declared test;
- one accepted checkpoint and one verified evidence-bundle artifact;
- completed canonical run and work item;
- no unresolved recovery case or orphan finding;
- explicit prohibition of merge, release, deployment, promotion, and maturity
  mutation.

Any missing or contradictory condition yields a failed packet. There is no
partial passing verdict.

## Security And Authority

- qualification records are recursively secret-scanned;
- the synthetic fixture contains no secret references;
- worker evidence cannot grant lifecycle authority;
- test fixtures provide bounded local authority only for this proof;
- output is written under `.tmp/` unless the owner selects another target;
- no protected protocol manifest or accepted ADR is changed;
- canonical maturity remains L1 after Gate C.

## Phase 3 Boundary

The packet is machine-readable evidence and a developer-facing artifact. It is
not an owner inbox, board, decision queue, audit UI, or metrics product. Those
surfaces begin at SF-300.
