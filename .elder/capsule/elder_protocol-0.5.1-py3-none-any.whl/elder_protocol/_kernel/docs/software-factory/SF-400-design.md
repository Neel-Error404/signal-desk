# SF-400 Elder Boundary Service Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Decision

Implement a concrete in-process governance adapter behind the already-ratified
SF-003 `factory-adapter-request` and `factory-adapter-response` envelopes.
Do not add a second wire protocol and do not revise the `1.0.0` public
contract.

## Boundary Shape

```text
Factory Operations
  -> validated governance-adapter request
  -> current protocol and operation-policy digest checks
  -> durable mutation reservation when required
  -> registered Elder handler
  -> validated governance-adapter response
  -> digest-bound governed record reference
```

The boundary dispatches only these registered operations:

- `classify`
- `assemble-context`
- `authorize`
- `validate-delegation`
- `evaluate`
- `qualify`
- `propose-learning`
- `promote`

Together they expose the SF-400 classification, context, delegation, evidence
and evaluation, qualification, autonomy, and learning domains.

## Digest Binding

Each request carries namespaced SF-003 extensions:

- `elder.local/protocol_version`
- `elder.local/protocol_sha256`
- `elder.local/policy_sha256`

The protocol digest binds the complete validated protocol snapshot. The policy
digest binds only the protocol documents relevant to the requested operation.
A service instance recomputes canonical protocol truth at construction and
rejects a supplied snapshot that is merely self-consistent but not current.
A protocol digest mismatch returns a contract `conflict` with reason
`protocol-digest-mismatch`. A policy mismatch returns `conflict` with reason
`stale-policy`. Neither reaches the handler.

## Failure Semantics

- invalid or unsupported boundary bindings: deterministic rejection;
- unavailable service, handler, or mutation store: `provider-unavailable`;
- handler `ProtocolError`: deterministic `invalid-request`, with no mutation
  effect allowed by the handler contract;
- unexpected read failure: `internal-error`;
- unexpected mutation failure or lost durable completion: `uncertain-mutation`;
- invalid handler output: fail closed before returning a response.

All returned errors use the ratified SF-003 taxonomy. Detailed reason codes are
diagnostic and do not change retry or authority semantics.

## Mutation Replay

`propose-learning` and `promote` reserve the SF-003 idempotency scope in a
small SQLite record before invoking a handler.

- a completed duplicate returns the original result;
- key reuse with changed identity or payload is rejected as `conflict`;
- an unfinished prior reservation returns `uncertain-mutation`;
- the boundary never repeats an uncertain mutation.

The boundary store records request and response envelopes only. Canonical
learning candidates and promotion packets remain in the P4.6 learning store.

## Handler Contract

Handlers receive the validated operation payload and request. They return the
exact SF-003 result object for that operation. They may:

- call an existing Elder validator or runtime;
- resolve records from the canonical Elder-owned store;
- return a digest-bound governed result.

Handlers may not create authority, bypass source validation, or return
provider-native objects as canonical results.

## Dependency Direction

Allowed:

```text
operations -> elder boundary -> Elder public validators and runtimes
elder boundary -> boundary replay SQLite
```

Forbidden:

```text
Elder protocol -> Factory Operations
operations store -> replacement Elder authority
boundary -> worker provider
boundary -> direct product transition
```

## Limits

This is a local adapter implementation, not a hosted service. It does not
persist context packets because that belongs to SF-401, bind decisions to run
lifecycle transitions, create supervised delivery packets, or raise Elder
maturity above L1.
