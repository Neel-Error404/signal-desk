# SF-401 Governed Context Assembly Design

**Status:** VERIFIED

**Date:** 2026-08-14

## Decision

Compose the current Work Item Ledger, project activation packet, P4.5A
parent/delegation/child-run chain, P4.4 `KnowledgeStore`, and SF-400
`ElderBoundaryService`. Do not add another context-selection algorithm or
change a protected protocol surface.

## Flow

```text
queued work item + generated-project activation + Elder run chain
-> recompute profile and authority bindings
-> derive query, scope, identity, and token ceiling
-> persist immutable full context request and input digests
-> SF-400 assemble-context request carrying safe request id/digest
-> resolve full request behind Elder
-> P4.4 authorized assembly
-> persist immutable packet and digest-bound binding
-> revalidate exact packet before later lifecycle use
```

The SF-003 envelope cannot carry the full P4.4 request because generic secret
field protection treats token-shaped names conservatively. The boundary
therefore carries only `project_id`, derived `query`, request `id`, and
`content_sha256`. The full request remains behind Elder.

## Derivation

- work item identity, objective, scope, acceptance criteria, current entity
  digest, and revision digest come from `WorkItemLedger`;
- project and instruction truth come from a current generated-project
  activation packet and its byte-exact instruction-source hashes;
- executor, delegated scope, packet id, run budget, and lineage come from the
  validated child run and delegation;
- the query is derived from canonical work objective, scope, acceptance
  criteria, and delegation objective rather than accepted from a caller;
- the token budget is the requested value only when it is no greater than the
  P4.4 default, delegation token limit, and child-run token limit.

## Persistence

`GovernedContextRepository` is an Elder-owned local SQLite evidence store. It
contains immutable request/input records and immutable packet/binding records.
It does not store operational transitions or create authority.

The packet binding includes:

- packet id and digest;
- activation id and digest;
- work-item and revision digests;
- parent-run, delegation, and child-run digests;
- prior packet id for an explicit refresh;
- request id and digest.

An exact duplicate request returns the first persisted packet. Concurrent
assembly may compute temporary candidates, but only one request-bound packet
becomes canonical.

## Refresh Rules

A persisted packet is immutable. Refresh requires:

1. the same project and work item;
2. a new child-run identity;
3. a new child-run `context_packet_id`;
4. an explicit previous packet id;
5. complete revalidation and a new packet digest.

A later lifecycle caller supplies the packet digest it authorized.
`verify_for_use` rejects any different digest, stale activation, changed work
item, changed run lineage, or changed repository bytes.

## Fail-Closed Rules

- empty source selection reaches P4.4 and fails because no authorized source
  is selected;
- callers cannot supply a wildcard query because query is derived and unknown
  submission fields are rejected;
- delegated graph and memory retrieval remain disabled until scoped
  provenance exists;
- required stale, missing, empty, unauthorized, or over-budget sources fail
  under P4.4;
- current packet validation reads repository bytes again before use.

## Dependency Direction

Allowed:

```text
Factory Operations -> SF-400 boundary -> P4.4 assembly
SF-401 -> Work Item Ledger read
SF-401 -> generated activation and current profile read
SF-401 repository -> immutable request and packet evidence
```

Forbidden:

```text
SF-401 -> authority grant or lifecycle transition
operations store -> replacement context packet truth
worker -> context refresh or trusted-memory selection
SF-401 -> SF-402 implementation
```

## Limits

The implementation is local and generated-project only. Delegated workers
receive repository context only because P4.4 does not yet provide scoped graph
or memory provenance for delegation. SF-402 remains responsible for authority
and delegation integration at lifecycle gates. Canonical maturity remains L1.
