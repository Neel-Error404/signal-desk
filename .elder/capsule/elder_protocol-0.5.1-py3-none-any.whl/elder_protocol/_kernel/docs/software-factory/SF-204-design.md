# SF-204 Optional Prime Agent Adapter Design

**Status:** VERIFIED

**Date:** 2026-08-13

**Base revision:** `483c38152867b6fb9c81d5f40545d834291fdff8`

## Boundary

SF-204 adds an optional Prime-specific translation behind the ratified SF-200
worker adapter contract. It does not add a new factory operation or change
canonical lifecycle ownership.

```text
SF-203 durable control
        |
        v
SF-200 WorkerAdapter
        |
        v
PrimeWorkerAdapter
        |
        +--> adapter-private SQLite receipts and observations
        |
        +--> stable Prime daemon clientId + commandId
        |
        +--> optional governed refinement-candidate sink
```

Prime provider objects remain opaque. The adapter stores only exact bindings,
digests, typed status, and provider observations needed for reconciliation and
evidence.

## Runtime Pinning

The adapter pins:

- Prime Agent package `0.7.0`;
- source commit `b9a4461149419156599d60174dddf15458e2b9ee`;
- daemon protocol `prime-agent.daemon` version `7`;
- schema revision `13`;
- one existing absolute Bash-compatible shell;
- one isolated absolute Prime agent directory;
- one explicit daemon socket or named-pipe path.

Handshake drift, version drift, missing Bash, missing bridge, or invalid paths
fail before a provider result is accepted.

Prime remains optional. Elder does not install it, add it to `pyproject.toml`,
or select it by default.

## Windows Bridge

The Prime daemon uses a local JSONL socket and stable command envelopes. A
small packaged Node bridge provides the same transport on Windows named pipes
and Unix sockets without importing Prime internals.

For each request the bridge:

1. connects to the configured socket;
2. waits for `daemon_hello`;
3. sends the exact protocol name/version, factory-derived client ID, stable
   command ID, and one daemon command;
4. returns the matching response plus bounded events;
5. fails on timeout, malformed JSON, socket loss, or response-ID drift.

The Python runtime independently verifies the hello version, schema, and app
version. Diagnostics are represented by digests rather than raw daemon output.

## Identity And Storage

The factory session identity and Prime identity are deliberately distinct.

| Identity | Owner |
|---|---|
| work item, run, worker session, generation | Elder factory |
| workspace and sandbox binding | SF-202 |
| Prime active-session ID and session path | Prime provider |
| Prime client ID and command ID | adapter translation |
| Elder authority and delegation | governance stores |

The Prime client ID is deterministically derived from project, worker session,
and generation. A send uses the existing factory command ID. Start and cancel
derive stable provider command IDs from the SF-200 mutation identity.

The adapter SQLite store and isolated Prime agent directory must both be
outside the provider-writable workspace. The adapter never reads or persists
`auth.json`; a separately provisioned agent directory may hold provider-local
credentials that are not exposed to Elder.

The runtime subprocess receives a narrow operating-system environment plus
`PRIME_AGENT_CODING_AGENT_DIR` and the exact Bash path. Secret-shaped inherited
environment is not forwarded.

## Operation Mapping

| SF-200 operation | Prime translation |
|---|---|
| `prepare` | validate exact workspace and factory bindings |
| `start` | daemon `create` with isolated session path |
| `send` | journaled daemon `prompt` using stable client and command IDs |
| `observe` | unchanged factory-owned projection observation |
| `checkpoint` | factory checkpoint plus digest of Prime session state |
| `cancel` | daemon `abort` with stable mutation identity |
| `recover` | daemon `attach`, then same-ID journal reconciliation |
| `collect-evidence` | digest-bound provider, command, and candidate evidence |

Provider results cannot claim canonical writes. The capability manifest
continues to declare `canonical_write_authority = none`.

## Restart And Journal Recovery

Daemon replacement changes the supervisor generation, not the Prime
active-session ID. Recovery attaches to the exact durable session and records a
new attach digest.

If an adapter receipt exists without a response:

- a `send` is resubmitted with the same Prime client ID and command ID;
- a completed Prime journal entry returns the recorded result;
- `command_result_uncertain` remains unresolved and is not replayed with a new
  identity;
- ambiguous `start` and `cancel` remain unknown for SF-206;
- deterministic adapter-local effects can still be reconstructed from durable
  state.

This is provider-specific command-journal consumption, not general SF-206
worker reconciliation.

## Session Lease Conflict

Prime owns a process-safe lease for each canonical session JSONL path. The
adapter derives one path from project, factory session, and generation.

`session_already_active` is a known not-applied conflict. It is reported as an
SF-200 rejected conflict and the adapter receipt becomes retryable only through
an explicit later request. The Prime lease grants no Elder authority.

## Refinement Interception

The runtime disables extensions, skills, prompt templates, serialized
refinement, and Prime's default-on automatic refinement for the bounded
session. It persists `autoRefine.enabled = false` in the dedicated agent
directory and rejects a project setting that attempts to re-enable it before
provider dispatch. The worker prompt also forbids Prime refinement and harness
mutation.

The adapter then enforces two deterministic rules:

1. `refinement_applications` must be empty. Any local or global application
   recorded in events or the attached session snapshot makes the worker
   mutation uncertain and stops delivery. This is fail-closed detection after
   an attempted provider-local write, not a claim that Elder intercepts every
   internal Prime instruction before execution.
2. `refinement_proposals` require an injected `PrimeRefinementCandidateSink`.
   The sink returns only an immutable candidate ID and digest. The adapter
   records that reference; it cannot approve, promote, apply, or retrieve it as
   trusted memory.

The sink is an authority boundary. A deployment may bind it to the existing
P4.6 learning runtime under an authorized learning-agent identity. Without a
sink, a proposal fails closed.

## Evidence

Prime evidence includes:

- pinned package, source, daemon protocol, and schema;
- opaque provider session reference and session-path digest;
- start and command observation digests;
- candidate IDs and digests;
- last attach and cancellation digests when present;
- unresolved receipt count and pass/partial verdict;
- explicit `direct_refinement_application_accepted = false`.

No credential values, raw auth files, unrestricted environment, transcript
contents, or provider session path are exposed in the evidence bundle.

## Completion

SF-204 is complete because the focused ordered test ladder passes, the
packaged bridge is present in an installed wheel, final review has no open
current-scope `BLOCKER` or `REQUIRED` finding, and closure evidence is
recorded. The task is committed separately before SF-205 begins.
