# Git And Change Protocol

## Repository Requirement

Every generated project must declare its topology: single repository, monorepo, multirepo, or
federated. Monorepo is not a universal default.

## Work Isolation

- Use one short-lived branch and isolated worktree per active work item.
- Do not share a mutable working directory between concurrent agents.
- Keep generated runtime artifacts outside shared Git truth.

## Change Preparation

Before implementation, record:

- outcome and work item
- change class and risk
- affected contracts and owners
- evidence plan
- rollback or recovery path
- dependencies and intended PR stack

## Commit Discipline

- Commit one coherent reason for change.
- Explain intent and consequences, not only files changed.
- Do not mix unrelated cleanup with product behavior.
- Do not manufacture additional commits or PRs when they do not improve review or rollback.

## Pull Requests

Each PR must include:

- problem and intended outcome
- design or ADR reference
- change class
- behavioral summary
- tests and evidence
- architecture and security impact
- deployment and rollback
- unresolved risk

Stack PRs when a large change can be divided into independently understandable and verifiable
steps. The stack must preserve a usable dependency order.

## Review And Promotion

- Deterministic checks run before probabilistic review.
- The authoring agent is not the sole approver.
- Governed releases use protected branches or equivalent approval controls.
- A live manual deployment is not represented as a clean branch-governed release.
- Production artifacts link to the exact source revision and build provenance.

## Repository Hygiene

- Never stage, commit, push, reset, clean, or rewrite history without the operator's permission.
- Leave unrelated working-tree changes untouched.
- Secrets, logs, local state, build output, and generated evidence caches stay ignored unless a
  governed artifact explicitly requires them.
