# P5.1 Certification Simulation

## Purpose

P5.1 evaluates bounded-autonomy work without performing it. It adds exact work-item matching,
side-effect-free simulation, hash-chained certification replay, and incident accounting.

## Work-Item Matching

An autonomy work item declares:

- one project, parent change class, and autonomy class;
- exact add, modify, or delete operations;
- normalized project-relative paths;
- before and after content digests;
- generated, production, test-support, fixture, snapshot, configuration, and generator-input
  classifications;
- one certified tool, optional pinned digest, and rule ids;
- required checks and evidence;
- semantic-equivalence mode and evidence;
- observed effects and an evidence plan.

Every changed path must fit the class and the certification's exact normalized concrete-path
allowlist. Wildcards are prohibited. Tool and rule bindings must match the certification.
Configuration, fixtures, snapshots, forbidden paths, unsupported operations, and scope expansion
fail closed.

## Simulation

Simulation checks all class requirements and returns `passed` or `blocked`. It records no executed
side effects and grants no PR, merge, deployment, or maturity authority.

```powershell
py -m elder_protocol.cli autonomy match `
  --work-item <work-item.json> `
  --certification <certification.json>

py -m elder_protocol.cli autonomy simulate `
  --work-item <work-item.json> `
  --certification <certification.json>
```

## Replay And Incident Accounting

Certification events are contiguous and hash chained. Events after the requested replay time are
rejected. Replay derives the current status, expiry, incident and rollback counts, budget
exhaustion, and whether immediate suspension is required. Lifecycle roles come from the autonomy
policy, and renewal validation uses the same class TTL rule as replay. The initial classes have
zero incident and rollback tolerance.

```powershell
py -m elder_protocol.cli autonomy replay `
  --certification <certification.json> `
  --events <events.json> `
  --at <iso-8601-time>
```

P5.1 does not mutate certification state. It deterministically reports what the lifecycle records
mean.
