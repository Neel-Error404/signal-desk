# P4.4 Governed Knowledge Runtime

## Purpose

P4.4 connects repository truth, durable graph state, governed memory, and context assembly:

```text
source or run artifact -> provenance-bound graph
-> candidate memory -> independent human promotion -> trusted memory
-> authority-filtered retrieval -> immutable context packet
```

The implementation is a local provider-neutral reference runtime. It does not claim a hosted
graph platform, vector search service, autonomous learning loop, or multi-agent checkpoint store.

## Knowledge Store

The SQLite adapter persists nodes, edges, memory records, metadata, and append-only audit events.
Each connection explicitly enables foreign keys, WAL journaling, a busy timeout, and full
synchronous durability. Initialization verifies the schema version and database integrity.

Graph ingest is transactional and idempotent. Nodes and edges carry source, authority, lifecycle
status, content or evidence, attributes, and content digests. Edges cannot reference unknown
nodes.

## Memory Governance

Memory is scoped by namespace and classified as episodic, semantic, or procedural.

- Agent and evaluator roles may propose candidate records.
- Candidate records require expiry and source evidence.
- Default retrieval returns only unexpired trusted records.
- Trusted promotion and every terminal transition require a typed approval artifact.
- The approver must have the `human-owner` role and cannot be the memory owner.
- Learning cannot mutate trusted memory directly.

## Context Assembly

The assembler combines explicit repository sources, active graph results, and trusted memory.
It uses deterministic authority-first ordering, content-digest deduplication, and a declared token
budget estimated from UTF-8 character count. Graph retrieval requires real query terms and is
capped independently by policy. Wildcard, empty-term, over-limit, and wholesale graph-context
requests fail closed.

Optional sources that do not fit are listed as exclusions. Required sources fail closed when
missing, stale, unauthorized, or too large. The output packet embeds the selected content,
provenance, sizes, assumptions, exclusions, and a digest over the complete packet.

## CLI

```powershell
py -m elder_protocol.cli knowledge init --store <knowledge.db>
py -m elder_protocol.cli knowledge ingest --store <knowledge.db> --graph <graph.json>
py -m elder_protocol.cli knowledge query --store <knowledge.db> --query <text>

py -m elder_protocol.cli memory propose --store <knowledge.db> --record <memory.json>
py -m elder_protocol.cli memory promote --store <knowledge.db> --memory-id <id> --approval <approval.json>
py -m elder_protocol.cli memory query --store <knowledge.db> --namespace <namespace> --query <text>

py -m elder_protocol.cli context assemble --store <knowledge.db> --request <request.json> --output <packet.json>
```

## Explicit Boundary

P4.4 does not provide embeddings, semantic vector ranking, a remote database, tenant
authentication, encryption-at-rest key management, backup automation, cross-region recovery,
agent delegation, autonomous consolidation, replay, shadow mode, or promotion of learning
candidates. Those capabilities require later stages and stack-specific evidence.
