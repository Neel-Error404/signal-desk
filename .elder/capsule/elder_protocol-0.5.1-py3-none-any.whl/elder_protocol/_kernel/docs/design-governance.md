# Design Governance

## Rule

Code may be provisional during exploration. Design intent for governed changes may not be vague,
unversioned, or undiscoverable.

## Design Document Required

Use an RFC or ADR before implementation when a change:

- alters a stable boundary, dependency direction, authority, schema, public interface, data
  lifecycle, deployment path, evaluator, or rollback contract;
- introduces an irreversible or expensive commitment;
- spans multiple components, languages, repositories, or accountable owners;
- changes a factory maturity claim.

## Minimum Content

- intended outcome and failure conditions;
- current evidence and unresolved assumptions;
- alternatives and why they were rejected;
- component, data, identity, cost, and operational effects;
- dependency and migration sequence;
- tests, evals, observation, rollback, and delayed review;
- accountable owner and notification audience.

## Enforcement

The work item and PR reference the design document. `protocol/design-registry.json` binds every
governed design document to its owners, status, change classes, notification audience,
supersession links, and content digest. Protocol validation fails when the digest drifts.

Stack adapters turn applicable dependency rules into executable fitness functions. A
probabilistic design review may find omissions, but the architecture owner remains accountable
for ratification.
