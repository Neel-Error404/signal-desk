# P2 Reference Project Architecture Audit

**Date:** 2026-08-05
**Reference project:** `reference_projects/elder-workbench`
**Verdict:** Operational local bridge; P2 closure gates remain open.

## Current Picture

Elder Workbench is an executable reference product, not another template. An
operator submits a brief through a responsive browser workspace. A typed local
API executes eleven bounded workflow nodes, persists an atomic run snapshot and
append-only trace, and returns a blueprint that stops at clarification or human
approval.

| Elder plane | P2 implementation | Boundary still open |
|---|---|---|
| Outcome | Objective, unknowns, success prompts, failure states | Real user and product outcome measurement |
| Constitution | Human gate and L2 authority enforced in output | External approval service |
| Ontology | Runtime entities and relationships in each blueprint | Persistent graph store, ingestion, and query |
| Organization | Product and architecture approval roles | Directory, delegation, and segregation service |
| Architecture | Bounded nodes, provider interface, AST dependency fitness check | Architecture-owner ratification |
| Factory substrate | Local process, repo-owned data, atomic snapshots | Git, CI, worktrees, sandboxing, identity, secrets |
| Execution | Eleven-node harness and replaceable reasoning provider | External models, tools, MCP servers, checkpoints |
| Change | Compiler ownership protection and reproducible generation | Repository protections, PR flow, artifacts, promotion |
| Assurance | Five-level tests, browser inspection, append-only traces | Independent eval service and delayed quality history |
| Learning | Trace material suitable for later replay | Quarantine, replay, candidate promotion, canary |
| Economics | Cost drivers, measurement requirements, human budget authority | Actual metering, budget, unit economics |
| Go to market | Proof-backed asset plan and human publishing authority | Audience validation, campaign execution, results |

## Operational Surfaces

- Backend: typed request model, service seam, workflow engine, explicit errors.
- Frontend: responsive operator workspace, graph, blueprint tabs, human gate,
  recent-run retrieval, and system status.
- Data: append-only JSONL traces and atomic JSON snapshots under `data/`.
- Agent: deterministic provider behind a typed replaceable interface.
- Security: localhost-only binding, request-size limit, CSP and browser security
  headers, strict fields, no credentials.
- Operations: health endpoint, operating signals, runbooks, rollback requirement,
  and explicit promotion rule.
- Economics: cost drivers and required metrics without fabricated estimates.
- Go to market: audience-validation gate, evidence-backed draft assets, and no
  autonomous publishing.

## Defects Found During P2

1. The Wayfinder did not recognize “measurable” as success language. The provider
   vocabulary was corrected and the Workflow level rerun.
2. Equal-priority skills were ordered from a set, causing cross-process compiler
   drift. A lexical tie-breaker and regression test now make regeneration
   reproducible.
3. Browser inspection found a favicon 404, undersized refresh control, and graph
   overflow after adding nodes. All were corrected and re-inspected.
4. The initial graph omitted economics, operations, and go-to-market planes.
   Three bounded nodes and corresponding operator views were added.

## Closure Gates

P2 implementation is ready for use, but P2 should not be marked fully complete
until:

1. The architecture owner ratifies ADR 0002.
2. The first delayed maintainability review is recorded on or after
   **August 12, 2026**.
3. Follow-up reviews are recorded around **September 4, 2026** and
   **November 3, 2026**.

P3 capabilities must remain non-operational claims until Git, CI, isolation,
identity, deployment, provenance, and rollback have current executable evidence.
