# P4.5B Bounded Multi-Agent Runtime

## Purpose

P4.5B operationalizes the P4.5A contracts as a bounded local coordinator. It does not create a
general autonomous software factory. It makes one validated delegation chain dispatchable,
inspectable, cancellable, and replayable under explicit local authority constraints.

## Runtime Chain

```text
project profile + resolved authority
-> parent agent run
-> active bounded delegation
-> child agent run
-> digest-bound context packet
-> assigned-identity lease
-> typed action and message journals
-> digest-linked checkpoint
-> completion, escalation, cancellation, or expiry
-> deterministic lifecycle replay
```

## Operational Controls

- Submission revalidates parent and child project authority, delegation scope, tools, budget,
  deadlines, identity, context-packet binding, and repository-source content. Repository
  provenance resolves to the same path as the source location, and content comparison is
  byte-exact UTF-8, including line endings and trailing whitespace.
- Claims are ordered deterministically and issued only to the delegation's assigned identity.
- Lease tokens are stored only as SHA-256 digests and expire no later than the delegated
  deadline. Claim, release, expiry, and cancellation each journal the complete digest-bound lease
  artifact.
- Child actions must use a delegated resource action and tool, report explicit budget
  consumption, remain within checkpoint frequency, and begin and complete inside the lease.
- Message, checkpoint, cancellation, and escalation operations require explicit matching
  authority grants on the originating run; a valid lease alone never grants authority.
- Parent-child messages bind the exact project, delegation, runs, identities, and contiguous
  sequence. Their state effect remains `none`.
- Checkpoints bind journaled action consumption, increase monotonically, and link to the previous
  checkpoint digest. Their signed `action_sequence` must equal the persisted action count.
- Completion requires no remaining scope and at least one evidence reference.
- Parent runs must remain active, and terminal checkpoints are blocked while descendants remain
  active.
- Cancellation propagates transactionally across active descendant delegations, runs, and leases.
  The completed cancellation artifact and its digest are bound to both persistence and runtime
  events. A cancellation with no active lease does not synthesize a lease transition during
  replay.
- Agent-originated cancellation resolves to one active leased requester run and may target only
  that run, its own delegation, or descendant work.
- Expiry uses the earliest delegation, expiry, or child-run deadline, aborts unfinished work,
  and releases any active lease.
- Escalation rows and events carry the same complete artifact digest.
- Replay verifies the global event hash chain, persisted journal-row digests, complete lease
  transitions, cancellation and escalation event bindings, record counts,
  action/message/checkpoint sequences, checkpoint chain, and reconstructed state against one
  transactionally consistent snapshot.

## Store Compatibility

This hardening raises the local runtime-store schema to version 2. A schema-version-1 store fails
closed at initialization because it lacks complete lease artifacts and cancellation and
escalation digests. Rebuild disposable local stores before use. No in-place migration is claimed
for P4.5B.

## Local Commands

```powershell
py -m elder_protocol.cli orchestration init --store <runtime.db>
py -m elder_protocol.cli orchestration submit --store <runtime.db> --bundle <bundle.json>
py -m elder_protocol.cli orchestration claim --store <runtime.db> --project-id <project> --identity-id <identity>
py -m elder_protocol.cli orchestration action --store <runtime.db> --record <action.json> --lease-token <token>
py -m elder_protocol.cli orchestration message --store <runtime.db> --record <message.json> --lease-token <token>
py -m elder_protocol.cli orchestration checkpoint --store <runtime.db> --record <checkpoint.json> --lease-token <token>
py -m elder_protocol.cli orchestration replay --store <runtime.db> --delegation-id <delegation>
```

## Non-Claims

P4.5B does not provide:

- external identity authentication or signed human requests;
- a hosted broker, remote agent service, distributed scheduler, or multi-tenant store;
- OS or container isolation for untrusted tools;
- model-provider or tool execution;
- hosted checkpoint durability, backup, recovery, encryption, or retention;
- autonomous evaluation, approval, promotion, deployment, or policy mutation;
- counterfactual execution, shadow learning, or candidate promotion;
- production readiness above the existing evidence-bound L1 assessment.
