# P4.5A Multi-Agent Entry Gate

## Purpose

P4.5A prepares the protocol for multi-agent work without implementing a multi-agent runtime.
It makes selected-pack obligations, project identities, delegated authority, parent-child run
relationships, checkpoints, and escalation machine-readable and fail closed.

## Contract Chain

```text
project profile
-> selected capability pack
-> resolved obligation
-> canonical owner role
-> project identity
-> required artifact type
-> required evidence
-> current status
```

```text
work item
-> parent agent run
-> bounded delegation
-> child agent run
-> checkpoint
-> evidence
-> evaluator
-> accountable approval decision
```

## Deterministic Entry Gate

P4.5B may begin only when:

1. P4.4 remains clean.
2. Canonical roles and project identities validate.
3. Selected packs resolve into inspectable obligations.
4. Delegation, message, checkpoint, and agent-run contracts validate.
5. Delegated authority cannot exceed parent or project authority.
6. Parent-child relationships appear in ontology and fixture graphs.
7. Delegated context packets bind project, delegation, identity, and scope.
8. Invalid delegations fail closed.
9. No second product is required.

## Hardening Closure

The P4.5A entry gate also requires:

- parent runs to explicitly claim delegation authority, with every claim remaining within
  resolved project role and identity grants;
- resolved authority bindings to match their profile, role-registry, and authority-matrix sources;
- child-run authority, tools, budget, deadline, expiry, and scope to remain within the
  finalized delegation;
- forbidden scope to reject overlap in either containment direction;
- checkpoints to bind the exact project, delegation, and child run before graph inclusion;
- delegated context assembly to require the actual delegation artifact, bind its digest, and
  reject repository sources outside delegated scope;
- delegated graph and memory retrieval to remain disabled until those sources carry enforceable
  scope provenance.

## Non-Claims

P4.5A does not provide a queue, message broker, scheduler, orchestrator, remote agent service,
hosted checkpoint store, runtime cancellation engine, autonomous evaluator, autonomous promoter,
checkpoint sequence-chain or replay validation, or production multi-agent operation. The JSON
fixtures are architectural proof, not products.

The delegated-source restriction is enforced by the runtime validator; schema-only validation is
not sufficient for delegated packets. P4.5A was not approved or released before this hardening,
so pre-hardening local context packets without `delegation_sha256` are intentionally not migrated.
