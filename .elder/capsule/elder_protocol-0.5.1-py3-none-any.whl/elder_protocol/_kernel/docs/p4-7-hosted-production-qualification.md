# P4.7 Hosted Production Qualification

## Purpose

P4.7 evaluates signed hosted evidence against Elder's cumulative L0-L5 maturity model. It
separates three truths:

1. the qualification mechanism is implemented;
2. a hosted evidence bundle is cryptographically valid;
3. the project has actually satisfied a requested maturity level.

Only the third permits a qualified report, and even that report remains advisory.

## Qualification Flow

```text
hosted provider payload
-> project/environment/artifact-bound evidence record
-> independent Ed25519 verifier attestation
-> independently signed immutable evidence bundle
-> trust, path, digest, signature, freshness, and contradiction checks
-> cumulative L0-L5 gate evaluation
-> immutable advisory qualification report
-> accountable owners decide any external claim or release action
```

## Evidence Rules

- Every payload remains inside the bundle and is bound by SHA-256.
- Every record is signed over canonical JSON excluding only the attestation and record digest.
- Every non-empty bundle is signed over its complete record set, target, and project bindings.
- Trust anchors constrain signer role, provider, and HTTPS source host.
- Records bind the same project, environment, and artifact as the bundle.
- Records and bundles have explicit creation, issue, and expiry times.
- Stale, expired, forged, revoked, contradictory, missing, or out-of-scope evidence fails
  closed.
- Maturity is cumulative. L3 cannot pass unless every L0-L3 gate passes.

## Commands

```powershell
py -m elder_protocol.cli qualification validate
py -m elder_protocol.cli qualification evaluate --bundle <bundle.json> --output <report.json>
```

Provider adapters are responsible for collecting hosted evidence and producing independently
signed records and bundle manifests. Local `qualification validate` and `qualification evaluate`
read immutable bundle files without network credentials. Provider issuance commands are separate
operations with explicit external credentials and trust boundaries.

## Current State

P4.8A configured separate operator and independent-reviewer trust anchors and produced one
verified advisory L2 bundle for exact commit
`d8c8eb3f5412bf1fe062a6cee55e35dd45e46589`. Qualification remains advisory and cannot mutate
the canonical L1 assessment. Current autonomy still fails closed because the repository has no
active authority source, qualification consumption, certification, or verified protected branch.

## Non-Claims

P4.7 does not:

- create a Git remote, branch rules, merge queue, or hosted CI run;
- provision workload identity, secret brokers, sandboxes, telemetry, databases, or recovery;
- collect evidence from cloud or source-control APIs;
- authenticate human identities;
- deploy, promote, roll back, revoke, or renew production operation;
- mutate `operational-maturity.json`;
- certify Elder above L1 without external signed evidence;
- implement P5 bounded autonomy.
