# P4 Assurance Architecture

## Purpose

P4 turns recommendations, traces, and outcomes into inspectable quality controls without allowing
agents to self-authorize policy, evaluator, memory, or production changes.

## Control Flow

```text
source recommendation
-> adopted principle
-> recommendation ledger
-> deterministic, probabilistic, and human controls
-> required artifacts and evidence
-> component operating contracts
-> execution and delivery traces
-> independent evaluation
-> judgment rubric and vetoes
-> maturity assessment
-> independently signed hosted evidence qualification
-> approved learning candidate or documented gap
```

## Separation

| Responsibility | May do | May not do |
|---|---|---|
| Executor | Implement the approved work item | Solely evaluate or promote it |
| Deterministic control | Reject invariant, schema, dependency, security, or test failures | Infer product taste |
| Meta-agent evaluator | Inspect traces, flag assumptions, compare candidates | Override checks or approve itself |
| Human evaluator | Judge consequence, taste, exceptions, and external commitments | Ignore failed deterministic gates |
| Promoter | Promote an approved immutable artifact or candidate | Change the evaluated artifact |

## Component Boundary

Every authority-bearing or independently operated component declares:

- typed inputs, outputs, and errors;
- allowed and forbidden dependencies;
- execution kind and side effects;
- identity, credentials, and tool scopes;
- data classification, retention, and lineage;
- failures, signals, and responses;
- traces, metrics, logs, and correlation;
- cost unit, budget, and meter;
- tests, evals, and architecture fitness functions;
- deployment artifact, health check, rollback trigger, procedure, and owner.

## Current Runtime Boundary

The recommendation ledger, design registry, Python architecture-boundary adapter, deterministic
independent transcript evaluator, hash-bound evaluation registry, deterministic graders,
offline rubric-judge calibration, paired comparison, schemas, graph, compiler output, and
assurance report are executable. P4.3 adds native Workbench trace context, typed Workbench,
factory, and evaluation adapters, correlated product/model/tool/factory/cost/outcome events,
and advisory cost, error, latency, correlation, outcome, and cardinality reports. P4.4 adds a
transactional local graph and memory store, governed candidate-to-trusted transitions, and
deterministic digest-bound context assembly. P4.5B adds a transactional local multi-agent
coordinator with assigned-identity leases, typed journals, cancellation propagation, and
deterministic lifecycle replay. P4.6 adds a transactional quarantined learning runtime with
immutable candidate artifacts, side-effect-free replay and shadow observations, independent
evaluation, accountable approvals, separate promotion, rollback packets, and journal replay.
P4.7 adds payload-bound hosted evidence bundles, Ed25519 trust anchors, cumulative maturity
gates, contradiction checks, and immutable advisory qualification reports.

External design notifications, additional language adapters, live model-provider evaluators,
hosted evaluator isolation, multi-rater calibration, a hosted telemetry collector, production
retention and alerting, hosted knowledge durability, distributed multi-agent coordination,
external runtime identity authentication, hosted shadow traffic, target-application adapters,
production self-learning, configured qualification trust anchors, and current signed hosted
evidence remain open.
