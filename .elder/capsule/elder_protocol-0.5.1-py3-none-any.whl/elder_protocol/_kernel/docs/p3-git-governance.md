# P3 Git Governance

## Branch And Worktree Path

```text
main
  `-> work/<work-item>
        `-> isolated .factory/worktrees/<work-item>
```

Work items use lowercase letters, numbers, and hyphens. Worktree creation
requires an initialized repository and baseline commit. Removal refuses dirty
worktrees; it does not force deletion.

## Hosted Main Policy

The desired hosted rules are:

- pull requests required;
- at least one approving review;
- stale approvals dismissed;
- linear history;
- no force pushes or branch deletion;
- required checks:
  - `P3 / protocol`
  - `P3 / reference-project`
  - `P3 / reproducible-artifact`
- merge queue required.

`CODEOWNERS` is intentionally absent until real GitHub identities are ratified.
The ruleset plan therefore does not claim code-owner review is active.

## Stacked Pull Requests

Use a stack only when each item has an independent purpose, evidence set, and
rollback boundary:

```text
work/foundation-contract
  -> work/factory-runtime
    -> work/hosted-activation
```

Each PR targets its predecessor until the stack is rebased or merged. More PRs
are not a goal; reviewability and independent rollback are.

## Current Repository State

The local root is initialized on `main` at baseline commit
`452e8c2c97c12b71158444dca6f9e63f95eb96de`. No remote exists. Root worktrees
are available for declared work items, while hosted governance cannot be
activated or verified until a remote and accountable identities exist.
