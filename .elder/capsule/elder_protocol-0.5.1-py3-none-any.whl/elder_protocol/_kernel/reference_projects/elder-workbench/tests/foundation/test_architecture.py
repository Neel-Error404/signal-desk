from __future__ import annotations

import unittest

from tests._support import PROJECT_ROOT
from workbench.architecture_check import find_violations


class ArchitectureFoundationTests(unittest.TestCase):
    def test_required_project_surfaces_exist(self) -> None:
        required = [
            PROJECT_ROOT / "pyproject.toml",
            PROJECT_ROOT / "run.py",
            PROJECT_ROOT / "web" / "index.html",
            PROJECT_ROOT / "web" / "styles.css",
            PROJECT_ROOT / "web" / "app.js",
            PROJECT_ROOT / ".elder" / "project-contract.json",
            PROJECT_ROOT / ".elder" / "design-registry.json",
            PROJECT_ROOT / ".elder" / "transcript-review-policy.json",
            PROJECT_ROOT / ".elder" / "evaluation-registry.json",
            PROJECT_ROOT / ".elder" / "evaluation-dataset.json",
            PROJECT_ROOT / ".elder" / "evaluator-contract.json",
            PROJECT_ROOT / "docs" / "EVALUATION.md",
            PROJECT_ROOT / "docs" / "architecture-boundaries.json",
        ]
        missing = [str(path.relative_to(PROJECT_ROOT)) for path in required if not path.is_file()]
        self.assertEqual(missing, [])

    def test_python_dependency_direction_matches_ratified_architecture(self) -> None:
        self.assertEqual(find_violations(PROJECT_ROOT / "src" / "workbench"), [])


if __name__ == "__main__":
    unittest.main()
