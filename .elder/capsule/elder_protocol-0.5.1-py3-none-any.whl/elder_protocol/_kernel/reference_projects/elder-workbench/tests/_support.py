from __future__ import annotations

import shutil
import sys
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


PROJECT_ROOT = Path(__file__).resolve().parent.parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))


@contextmanager
def workspace(label: str) -> Iterator[Path]:
    root = PROJECT_ROOT / ".tmp" / "tests"
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{label}-{uuid.uuid4().hex}"
    path.mkdir()
    try:
        yield path
    finally:
        resolved_root = root.resolve()
        resolved_path = path.resolve()
        if resolved_root not in resolved_path.parents:
            raise RuntimeError(f"Refusing to remove test path outside .tmp: {resolved_path}")
        shutil.rmtree(resolved_path)
