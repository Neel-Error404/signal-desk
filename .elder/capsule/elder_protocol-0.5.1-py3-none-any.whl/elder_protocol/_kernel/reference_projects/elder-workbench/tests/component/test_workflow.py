from __future__ import annotations

import json
import re
import unittest

from tests._support import workspace
from workbench.service import WorkbenchService


class WorkflowComponentTests(unittest.TestCase):
    def test_brief_produces_traceable_blueprint_and_human_gate(self) -> None:
        with workspace("workflow") as data_dir:
            service = WorkbenchService(data_dir)
            result = service.create_run(
                {
                    "brief": "Build an agent that reviews pull requests.",
                    "constraints": ["Do not merge without human approval."],
                    "risk_tier": "moderate",
                    "requested_capabilities": ["agentic", "git"],
                }
            )

            self.assertEqual(result["status"], "needs-clarification")
            self.assertGreaterEqual(len(result["blueprint"]["open_questions"]), 1)
            self.assertIn("human-gate", result["trace"]["completed_nodes"])
            self.assertEqual(
                result["blueprint"]["authority"]["promotion"], "human-owner"
            )
            self.assertEqual(
                result["blueprint"]["economics"]["budget_authority"], "human-owner"
            )
            self.assertIn(
                "rollback",
                result["blueprint"]["operations"]["required_runbooks"],
            )
            self.assertEqual(
                result["blueprint"]["go_to_market"]["claim_policy"],
                "evidence-required",
            )
            self.assertTrue((data_dir / "runs" / f"{result['run_id']}.json").is_file())
            self.assertTrue(
                (data_dir / "traces" / f"{result['run_id']}.jsonl").is_file()
            )
            events = [
                json.loads(line)
                for line in (
                    data_dir / "traces" / f"{result['run_id']}.jsonl"
                )
                .read_text(encoding="utf-8")
                .splitlines()
            ]
            self.assertRegex(result["trace"]["trace_id"], r"^[0-9a-f]{32}$")
            self.assertRegex(result["trace"]["root_span_id"], r"^[0-9a-f]{16}$")
            self.assertEqual(
                {event["trace_id"] for event in events},
                {result["trace"]["trace_id"]},
            )
            self.assertTrue(
                all(
                    re.fullmatch(r"[0-9a-f]{16}", event["span_id"])
                    for event in events
                )
            )
            self.assertEqual(
                {event["parent_span_id"] for event in events},
                {result["trace"]["root_span_id"]},
            )


if __name__ == "__main__":
    unittest.main()
