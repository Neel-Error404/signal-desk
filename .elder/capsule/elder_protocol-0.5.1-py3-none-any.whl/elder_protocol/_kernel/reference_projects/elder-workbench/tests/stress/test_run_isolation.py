from __future__ import annotations

import concurrent.futures
import json
import unittest

from tests._support import workspace
from workbench.service import WorkbenchService


class RunIsolationStressTests(unittest.TestCase):
    def test_parallel_runs_have_unique_snapshots_and_complete_traces(self) -> None:
        with workspace("parallel-runs") as data_dir:
            service = WorkbenchService(data_dir)

            def create(index: int) -> dict[str, object]:
                return service.create_run(
                    {
                        "brief": (
                            f"Build project workflow {index} for an operator with measurable "
                            "success criteria and a local deployment boundary."
                        ),
                        "constraints": ["Require human approval."],
                        "risk_tier": "moderate",
                        "requested_capabilities": ["agentic", "web-product"],
                    }
                )

            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                results = list(executor.map(create, range(40)))

            run_ids = {str(result["run_id"]) for result in results}
            self.assertEqual(len(run_ids), 40)
            self.assertEqual(len(list((data_dir / "runs").glob("*.json"))), 40)
            self.assertEqual(len(list((data_dir / "traces").glob("*.jsonl"))), 40)

            for run_id in run_ids:
                events = [
                    json.loads(line)
                    for line in (data_dir / "traces" / f"{run_id}.jsonl")
                    .read_text(encoding="utf-8")
                    .splitlines()
                ]
                self.assertEqual(len(events), 22)
                self.assertEqual(events[-1]["node_id"], "finalize")
                self.assertEqual(events[-1]["status"], "complete")


if __name__ == "__main__":
    unittest.main()
