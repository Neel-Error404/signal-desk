from __future__ import annotations

import json
import threading
import unittest
from urllib.request import Request, urlopen

from tests._support import PROJECT_ROOT, workspace
from workbench.api import create_server


class OperatorWorkflowTests(unittest.TestCase):
    def test_operator_assets_and_run_flow_share_the_same_contract(self) -> None:
        with workspace("operator-flow") as data_dir:
            server = create_server("127.0.0.1", 0, data_dir, PROJECT_ROOT / "web")
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base_url = f"http://127.0.0.1:{server.server_port}"
            try:
                with urlopen(f"{base_url}/", timeout=5) as response:
                    html = response.read().decode("utf-8")
                self.assertIn('id="run-form"', html)
                self.assertIn('id="workflow-graph"', html)
                self.assertIn('id="human-gate"', html)
                self.assertIn('data-tab="operations"', html)
                self.assertIn('data-tab="market"', html)

                with urlopen(f"{base_url}/app.js", timeout=5) as response:
                    script = response.read().decode("utf-8")
                self.assertIn('fetch("/api/runs"', script)
                self.assertIn("renderBlueprint", script)

                request = Request(
                    f"{base_url}/api/runs",
                    data=json.dumps(
                        {
                            "brief": (
                                "Build a local workflow for a product team with a named "
                                "operator, measurable review outcome, and local deployment."
                            ),
                            "constraints": ["Human approval is required before promotion."],
                            "risk_tier": "moderate",
                            "requested_capabilities": ["agentic", "web-product"],
                        }
                    ).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(request, timeout=5) as response:
                    result = json.load(response)
                self.assertEqual(result["status"], "needs-approval")
                self.assertEqual(result["blueprint"]["open_questions"], [])
                self.assertIn("cost_drivers", result["blueprint"]["economics"])
                self.assertIn("launch_assets", result["blueprint"]["go_to_market"])
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
