from __future__ import annotations

import json
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from tests._support import PROJECT_ROOT, workspace
from workbench.api import MAX_REQUEST_BYTES, create_server
from workbench.errors import InputValidationError


class ApiSecurityComponentTests(unittest.TestCase):
    def test_remote_bind_is_rejected(self) -> None:
        with workspace("remote-bind") as data_dir:
            with self.assertRaisesRegex(InputValidationError, "localhost only"):
                create_server("0.0.0.0", 0, data_dir, PROJECT_ROOT / "web")

    def test_invalid_and_oversized_requests_fail_explicitly(self) -> None:
        with workspace("request-validation") as data_dir:
            server = create_server("127.0.0.1", 0, data_dir, PROJECT_ROOT / "web")
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            endpoint = f"http://127.0.0.1:{server.server_port}/api/runs"
            try:
                invalid = Request(
                    endpoint,
                    data=b"not-json",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as invalid_error:
                    urlopen(invalid, timeout=5)
                self.assertEqual(invalid_error.exception.code, 400)
                self.assertEqual(
                    json.load(invalid_error.exception)["error"], "invalid_request"
                )

                oversized = Request(
                    endpoint,
                    data=b"x" * (MAX_REQUEST_BYTES + 1),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as oversized_error:
                    urlopen(oversized, timeout=5)
                self.assertEqual(oversized_error.exception.code, 413)
                self.assertIn(
                    "exceeds",
                    json.load(oversized_error.exception)["message"],
                )
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
