from __future__ import annotations

import json
import threading
import unittest
from urllib.request import Request, urlopen

from tests._support import PROJECT_ROOT, workspace
from workbench.api import create_server


class ApiIntegrationTests(unittest.TestCase):
    def test_health_graph_create_and_retrieve_run(self) -> None:
        with workspace("api") as data_dir:
            server = create_server(
                "127.0.0.1",
                0,
                data_dir,
                PROJECT_ROOT / "web",
            )
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base_url = f"http://127.0.0.1:{server.server_port}"
            try:
                with urlopen(f"{base_url}/health", timeout=5) as response:
                    health = json.load(response)
                self.assertEqual(health["status"], "ok")

                with urlopen(f"{base_url}/api/graph", timeout=5) as response:
                    graph = json.load(response)
                self.assertEqual(graph["nodes"][0]["id"], "intake")

                request = Request(
                    f"{base_url}/api/runs",
                    data=json.dumps(
                        {
                            "brief": "Build a local agent workflow for a product team.",
                            "constraints": ["Require human approval."],
                            "risk_tier": "moderate",
                            "requested_capabilities": ["agentic", "web-product"],
                        }
                    ).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(request, timeout=5) as response:
                    self.assertEqual(response.status, 201)
                    created = json.load(response)

                with urlopen(
                    f"{base_url}/api/runs/{created['run_id']}", timeout=5
                ) as response:
                    retrieved = json.load(response)
                self.assertEqual(retrieved["run_id"], created["run_id"])
                self.assertIn("human-gate", retrieved["trace"]["completed_nodes"])
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
