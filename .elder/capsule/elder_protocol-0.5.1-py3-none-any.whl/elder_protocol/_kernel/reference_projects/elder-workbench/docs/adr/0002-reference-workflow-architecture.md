# ADR 0002: Elder Workbench Reference Architecture

## Status

Implemented and proposed for architecture-owner ratification.

## Context

P2 requires a real product that proves Elder can govern an executable agentic
workflow rather than only generate project scaffolding. The reference must run
locally without credentials, preserve human authority, expose its graph, and
produce inspectable evidence across product, engineering, operations,
economics, and go-to-market concerns.

## Decision

Use a dependency-directed local architecture:

```text
browser -> HTTP API -> service -> workflow -> bounded nodes
                                      |-> reasoning-provider interface
                                      |-> append-only trace store
                                      `-> atomic run snapshots
```

The workflow contains eleven ordered nodes:

```text
intake -> wayfinder -> ontology -> architecture -> risk -> economics
-> evidence -> operations -> go-to-market -> human-gate -> finalize
```

The deterministic provider may clarify and structure a brief but cannot approve
architecture, commit budget, publish externally, promote a deployment, or
modify trusted policy. The final state is therefore `needs-clarification` or
`needs-approval`, never `approved`.

Python modules follow an executable allowlist enforced by
`workbench.architecture_check`. Browser code reaches persisted state only
through the API. Runtime files remain below the project `data/` directory.

## Failure Behavior

- Invalid or oversized requests return explicit `400` JSON errors.
- The reference server refuses non-localhost binding.
- Node failures produce a failed append-only trace event and propagate.
- Snapshot persistence is atomic within the runtime data directory.
- Missing runs return `404`; unknown routes return explicit errors.

## Consequences

- The project proves a bounded reference harness, not a complete factory.
- Economics and market outputs define measurement and authority requirements;
  they do not invent budgets, audiences, proof, or return on investment.
- Local JSON storage is sufficient for P2 evidence but not for multi-host
  production operation.
- Git, CI, sandboxing, workload identity, external secrets, deployment,
  rollback automation, independent eval services, and learning promotion remain
  later phases.

## Verification

- Foundation checks required assets and dependency direction.
- Component checks node contracts, request limits, and localhost binding.
- Integration checks API, workflow, and persistence linkage.
- Workflow checks the operator surface and end-to-end run contract.
- Stress checks forty parallel runs and twenty-two trace events per run.
