from __future__ import annotations

import argparse
import json
import mimetypes
import re
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from workbench.errors import (
    InputValidationError,
    RequestTooLargeError,
    RunNotFoundError,
    WorkbenchError,
)
from workbench.service import WorkbenchService


MAX_REQUEST_BYTES = 64 * 1024
MAX_DRAIN_BYTES = MAX_REQUEST_BYTES + 1024
RUN_ID_PATTERN = re.compile(r"^[a-f0-9]{32}$")
STATIC_FILES = {
    "/": "index.html",
    "/index.html": "index.html",
    "/app.js": "app.js",
    "/styles.css": "styles.css",
}


class WorkbenchHttpServer(ThreadingHTTPServer):
    service: WorkbenchService
    static_dir: Path


class WorkbenchHandler(BaseHTTPRequestHandler):
    server: WorkbenchHttpServer

    def _security_headers(self, content_type: str) -> None:
        self.send_header("Content-Type", content_type)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data:; connect-src 'self'; object-src 'none'; "
            "base-uri 'none'; frame-ancestors 'none'",
        )

    def _json(self, status: HTTPStatus, payload: dict[str, Any] | list[Any]) -> None:
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self._security_headers("application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: HTTPStatus, error: str, message: str) -> None:
        self._json(status, {"error": error, "message": message})

    def _read_json(self) -> dict[str, Any]:
        content_type = self.headers.get("Content-Type", "")
        if content_type.split(";", 1)[0].strip().lower() != "application/json":
            raise InputValidationError("Content-Type must be application/json.")
        raw_length = self.headers.get("Content-Length")
        if raw_length is None:
            raise InputValidationError("Content-Length is required.")
        try:
            length = int(raw_length)
        except ValueError as exc:
            raise InputValidationError("Content-Length must be an integer.") from exc
        if length <= 0:
            raise InputValidationError("Request body must not be empty.")
        if length > MAX_REQUEST_BYTES:
            if length <= MAX_DRAIN_BYTES:
                self.rfile.read(length)
            else:
                self.close_connection = True
            raise RequestTooLargeError(
                f"Request body exceeds the {MAX_REQUEST_BYTES} byte limit."
            )
        body = self.rfile.read(length)
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise InputValidationError("Request body must contain valid UTF-8 JSON.") from exc
        if not isinstance(payload, dict):
            raise InputValidationError("Request JSON must be an object.")
        return payload

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        try:
            if path == "/health":
                self._json(
                    HTTPStatus.OK,
                    {
                        "status": "ok",
                        "service": "elder-workbench",
                        "provider": self.server.service.provider.name,
                    },
                )
                return
            if path == "/api/graph":
                self._json(HTTPStatus.OK, self.server.service.get_graph())
                return
            if path == "/api/runs":
                self._json(
                    HTTPStatus.OK, {"runs": self.server.service.list_runs(limit=20)}
                )
                return
            if path.startswith("/api/runs/"):
                run_id = path.rsplit("/", 1)[-1]
                if not RUN_ID_PATTERN.fullmatch(run_id):
                    self._error(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_run_id",
                        "Run id must be 32 lowercase hexadecimal characters.",
                    )
                    return
                self._json(HTTPStatus.OK, self.server.service.get_run(run_id))
                return
            if path in STATIC_FILES:
                self._serve_static(STATIC_FILES[path])
                return
            self._error(HTTPStatus.NOT_FOUND, "not_found", "Route does not exist.")
        except RunNotFoundError as exc:
            self._error(HTTPStatus.NOT_FOUND, "run_not_found", str(exc))
        except WorkbenchError as exc:
            self._error(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                type(exc).__name__,
                str(exc),
            )

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path != "/api/runs":
            self._error(HTTPStatus.NOT_FOUND, "not_found", "Route does not exist.")
            return
        try:
            result = self.server.service.create_run(self._read_json())
            self._json(HTTPStatus.CREATED, result)
        except RequestTooLargeError as exc:
            self._error(
                HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                "request_too_large",
                str(exc),
            )
        except InputValidationError as exc:
            self._error(HTTPStatus.BAD_REQUEST, "invalid_request", str(exc))
        except WorkbenchError as exc:
            self._error(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                type(exc).__name__,
                str(exc),
            )

    def _serve_static(self, filename: str) -> None:
        target = (self.server.static_dir / filename).resolve()
        if self.server.static_dir.resolve() not in target.parents:
            self._error(HTTPStatus.NOT_FOUND, "not_found", "Static file does not exist.")
            return
        if not target.is_file():
            self._error(HTTPStatus.NOT_FOUND, "not_found", "Static file does not exist.")
            return
        body = target.read_bytes()
        content_type, _ = mimetypes.guess_type(target.name)
        self.send_response(HTTPStatus.OK)
        self._security_headers(content_type or "application/octet-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: object) -> None:
        print(f"[workbench] {self.address_string()} {format % args}")


def create_server(
    host: str,
    port: int,
    data_dir: Path,
    static_dir: Path,
) -> WorkbenchHttpServer:
    if host not in {"127.0.0.1", "localhost"}:
        raise InputValidationError(
            "The reference server binds to localhost only. Use a governed deployment for remote access."
        )
    server = WorkbenchHttpServer((host, port), WorkbenchHandler)
    server.service = WorkbenchService(data_dir)
    server.static_dir = static_dir.resolve()
    return server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the Elder Workbench locally.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=Path(__file__).resolve().parents[2] / "data",
    )
    parser.add_argument(
        "--static-dir",
        type=Path,
        default=Path(__file__).resolve().parents[2] / "web",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    server = create_server(
        args.host,
        args.port,
        args.data_dir.resolve(),
        args.static_dir.resolve(),
    )
    print(f"Elder Workbench listening at http://{args.host}:{server.server_port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping Elder Workbench.")
    finally:
        server.server_close()
    return 0
