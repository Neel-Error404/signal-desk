from __future__ import annotations

import secrets
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Protocol

from workbench.models import RunRequest
from workbench.provider import ReasoningProvider
from workbench.store import JsonRunStore


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


class WorkflowNode(Protocol):
    id: str
    label: str

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        """Return the context updates produced by this node."""


@dataclass(frozen=True)
class IntakeNode:
    id: str = "intake"
    label: str = "Validate intake"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        request: RunRequest = context["request"]
        return {
            "intake": request.to_dict(),
            "constraints": list(request.constraints),
        }


@dataclass(frozen=True)
class WayfinderNode:
    provider: ReasoningProvider
    id: str = "wayfinder"
    label: str = "Clarify outcomes"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        request: RunRequest = context["request"]
        return {
            "objective": self.provider.objective(request.brief),
            "open_questions": self.provider.open_questions(request.brief),
            "provider": self.provider.name,
        }


@dataclass(frozen=True)
class OntologyNode:
    id: str = "ontology"
    label: str = "Map ontology"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        request: RunRequest = context["request"]
        entities = [
            {"type": "project", "label": context["objective"]},
            {"type": "human-owner", "label": "product-owner"},
            {"type": "human-owner", "label": "architecture-owner"},
        ]
        entities.extend(
            {"type": "capability-pack", "label": capability}
            for capability in request.requested_capabilities
        )
        relationships = [
            {
                "type": "owns",
                "from": "product-owner",
                "to": context["objective"],
            }
        ]
        return {"ontology": {"entities": entities, "relationships": relationships}}


@dataclass(frozen=True)
class ArchitectureNode:
    id: str = "architecture"
    label: str = "Draft architecture"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        request: RunRequest = context["request"]
        components = [
            {
                "id": "intake-api",
                "responsibility": "Validate and normalize operator input.",
            },
            {
                "id": "workflow-engine",
                "responsibility": "Execute bounded nodes and record transitions.",
            },
            {
                "id": "trace-store",
                "responsibility": "Persist append-only trace events and run snapshots.",
            },
            {
                "id": "human-gate",
                "responsibility": "Prevent unapproved promotion or completion claims.",
            },
        ]
        if "agentic" in request.requested_capabilities:
            components.append(
                {
                    "id": "reasoning-provider",
                    "responsibility": "Provide replaceable bounded reasoning operations.",
                }
            )
        return {
            "architecture": {
                "components": components,
                "dependency_direction": [
                    "api -> service -> workflow -> nodes",
                    "workflow -> trace-store",
                    "nodes -> provider-interface",
                ],
                "forbidden_dependencies": [
                    "frontend -> data-files",
                    "provider -> production-credentials",
                    "learning -> trusted-policy",
                ],
            }
        }


@dataclass(frozen=True)
class RiskNode:
    id: str = "risk"
    label: str = "Classify risk"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        request: RunRequest = context["request"]
        autonomy = {
            "low": "L3",
            "moderate": "L2",
            "high": "L2",
            "critical": "L1",
        }[request.risk_tier]
        change_class = {
            "low": "internal-code",
            "moderate": "public-contract",
            "high": "infrastructure",
            "critical": "production-policy",
        }[request.risk_tier]
        return {
            "risk": {
                "tier": request.risk_tier,
                "change_class": change_class,
                "maximum_autonomy": autonomy,
                "required_approvals": ["architecture-owner", "product-owner"],
            }
        }


@dataclass(frozen=True)
class EconomicsNode:
    id: str = "economics"
    label: str = "Frame economics"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        request: RunRequest = context["request"]
        cost_drivers = [
            "human review and exception handling",
            "trace storage and operational monitoring",
            "maintenance, incident response, and rework",
        ]
        if "agentic" in request.requested_capabilities:
            cost_drivers.insert(0, "reasoning-provider inference and tool execution")
        return {
            "economics": {
                "budget_authority": "human-owner",
                "estimation_policy": "instrument-before-estimate",
                "cost_drivers": cost_drivers,
                "required_metrics": [
                    "cost-per-run",
                    "human-review-minutes",
                    "failed-run-rework-rate",
                ],
                "forbidden_claims": [
                    "unmeasured return on investment",
                    "unapproved spending commitment",
                ],
            }
        }


@dataclass(frozen=True)
class EvidenceNode:
    id: str = "evidence"
    label: str = "Define evidence"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "evidence_plan": [
                {
                    "level": "Foundation",
                    "proof": "Schemas, configuration, and architecture boundaries validate.",
                },
                {
                    "level": "Component",
                    "proof": "Each workflow node satisfies its public contract.",
                },
                {
                    "level": "Integration",
                    "proof": "Workflow, storage, and API preserve trace linkage.",
                },
                {
                    "level": "Workflow",
                    "proof": "An operator completes the browser flow and retrieves the run.",
                },
                {
                    "level": "Stress",
                    "proof": "Repeated runs remain isolated and recoverable.",
                },
            ]
        }


@dataclass(frozen=True)
class OperationsNode:
    id: str = "operations"
    label: str = "Define operations"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "operations": {
                "operating_mode": "local-supervised",
                "health_signals": [
                    "API availability",
                    "run completion status",
                    "trace persistence",
                    "human-gate state",
                ],
                "required_runbooks": [
                    "startup",
                    "backup",
                    "restore",
                    "rollback",
                    "incident-response",
                ],
                "promotion_rule": "No deployment or operational claim without current evidence.",
            }
        }


@dataclass(frozen=True)
class GoToMarketNode:
    id: str = "go-to-market"
    label: str = "Plan market proof"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        request: RunRequest = context["request"]
        enabled = "go-to-market" in request.requested_capabilities
        return {
            "go_to_market": {
                "enabled": enabled,
                "target_audience_status": "requires-human-validation",
                "claim_policy": "evidence-required",
                "launch_assets": [
                    "audience-specific product brief",
                    "proof-backed LinkedIn draft",
                    "proof-backed X draft",
                    "demo script and feedback route",
                ]
                if enabled
                else ["internal validation brief"],
                "publishing_authority": "human-owner",
                "forbidden_actions": [
                    "autonomous publishing",
                    "fabricated customer proof",
                    "unsupported performance claims",
                ],
            }
        }


@dataclass(frozen=True)
class HumanGateNode:
    id: str = "human-gate"
    label: str = "Require human decision"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        questions = context.get("open_questions", [])
        status = "needs-clarification" if questions else "needs-approval"
        return {
            "status": status,
            "authority": {
                "design": "architecture-owner",
                "promotion": "human-owner",
                "agent": "propose-only",
            },
            "human_gate": {
                "status": status,
                "questions": questions,
                "required_approvals": context["risk"]["required_approvals"],
            },
        }


@dataclass(frozen=True)
class FinalizeNode:
    id: str = "finalize"
    label: str = "Assemble blueprint"

    def run(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "blueprint": {
                "objective": context["objective"],
                "open_questions": context["open_questions"],
                "constraints": context["constraints"],
                "ontology": context["ontology"],
                "architecture": context["architecture"],
                "risk": context["risk"],
                "economics": context["economics"],
                "evidence_plan": context["evidence_plan"],
                "operations": context["operations"],
                "go_to_market": context["go_to_market"],
                "authority": context["authority"],
                "human_gate": context["human_gate"],
            }
        }


class WorkflowEngine:
    def __init__(
        self,
        nodes: list[WorkflowNode],
        store: JsonRunStore,
    ):
        self.nodes = nodes
        self.store = store

    def execute(self, run_id: str, request: RunRequest) -> dict[str, Any]:
        trace_id = secrets.token_hex(16)
        root_span_id = secrets.token_hex(8)
        context: dict[str, Any] = {
            "run_id": run_id,
            "request": request,
            "started_at": utc_now(),
            "trace_id": trace_id,
            "root_span_id": root_span_id,
        }
        completed_nodes: list[str] = []
        for sequence, node in enumerate(self.nodes, start=1):
            started = time.perf_counter()
            span_id = secrets.token_hex(8)
            event = {
                "run_id": run_id,
                "project_id": "elder-workbench",
                "trace_id": trace_id,
                "span_id": span_id,
                "parent_span_id": root_span_id,
                "sequence": sequence,
                "node_id": node.id,
                "label": node.label,
                "status": "running",
                "recorded_at": utc_now(),
            }
            self.store.append_trace(run_id, event)
            try:
                updates = node.run(context)
            except Exception as exc:
                self.store.append_trace(
                    run_id,
                    {
                        **event,
                        "status": "failed",
                        "error_type": type(exc).__name__,
                        "message": str(exc),
                        "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
                        "recorded_at": utc_now(),
                    },
                )
                raise
            context.update(updates)
            completed_nodes.append(node.id)
            self.store.append_trace(
                run_id,
                {
                    **event,
                    "status": "complete",
                    "output_keys": sorted(updates),
                    "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
                    "recorded_at": utc_now(),
                },
            )

        result = {
            "run_id": run_id,
            "status": context["status"],
            "provider": context["provider"],
            "created_at": context["started_at"],
            "completed_at": utc_now(),
            "request": request.to_dict(),
            "blueprint": context["blueprint"],
            "trace": {
                "trace_id": trace_id,
                "root_span_id": root_span_id,
                "completed_nodes": completed_nodes,
                "event_path": f"traces/{run_id}.jsonl",
            },
        }
        self.store.save_run(run_id, result)
        return result


def workflow_graph() -> dict[str, Any]:
    nodes = [
        ("intake", "Validate intake", "deterministic"),
        ("wayfinder", "Clarify outcomes", "reasoning"),
        ("ontology", "Map ontology", "deterministic"),
        ("architecture", "Draft architecture", "reasoning"),
        ("risk", "Classify risk", "deterministic"),
        ("economics", "Frame economics", "deterministic"),
        ("evidence", "Define evidence", "deterministic"),
        ("operations", "Define operations", "deterministic"),
        ("go-to-market", "Plan market proof", "reasoning"),
        ("human-gate", "Require human decision", "human"),
        ("finalize", "Assemble blueprint", "deterministic"),
    ]
    return {
        "nodes": [
            {"id": node_id, "label": label, "kind": kind}
            for node_id, label, kind in nodes
        ],
        "edges": [
            {"from": nodes[index][0], "to": nodes[index + 1][0]}
            for index in range(len(nodes) - 1)
        ],
    }
