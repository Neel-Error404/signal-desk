class WorkbenchError(RuntimeError):
    """Base error for the Elder Workbench."""


class InputValidationError(WorkbenchError):
    """Raised when a run request is incomplete or unsafe."""


class RequestTooLargeError(InputValidationError):
    """Raised when an HTTP request exceeds the local API size limit."""


class RunNotFoundError(WorkbenchError):
    """Raised when a requested run does not exist."""


class StorageError(WorkbenchError):
    """Raised when trace or run persistence fails."""
