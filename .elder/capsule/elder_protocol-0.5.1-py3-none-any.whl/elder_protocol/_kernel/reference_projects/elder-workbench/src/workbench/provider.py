from __future__ import annotations

from typing import Protocol


class ReasoningProvider(Protocol):
    @property
    def name(self) -> str:
        """Return the provider identifier recorded in traces."""

    def objective(self, brief: str) -> str:
        """Return a concise objective without inventing new facts."""

    def open_questions(self, brief: str) -> list[str]:
        """Return material questions that remain unanswered."""


class DeterministicReasoningProvider:
    @property
    def name(self) -> str:
        return "deterministic-v1"

    def objective(self, brief: str) -> str:
        sentence = brief.split(".", 1)[0].strip()
        return sentence if sentence else brief.strip()

    def open_questions(self, brief: str) -> list[str]:
        text = brief.lower()
        checks = [
            (
                {"user", "customer", "developer", "operator", "reviewer", "team"},
                "Who is the primary user or accountable operator?",
            ),
            (
                {
                    "metric",
                    "measurable",
                    "success",
                    "reduce",
                    "improve",
                    "accuracy",
                    "latency",
                    "time",
                },
                "What measurable result defines success?",
            ),
            (
                {"local", "staging", "production", "cloud", "github", "deployment"},
                "Where will the system run and who can promote it?",
            ),
        ]
        questions = [
            question for terms, question in checks if not any(term in text for term in terms)
        ]
        return questions
