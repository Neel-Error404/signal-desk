"""Elder Workbench reference application."""

__version__ = "0.1.0"
