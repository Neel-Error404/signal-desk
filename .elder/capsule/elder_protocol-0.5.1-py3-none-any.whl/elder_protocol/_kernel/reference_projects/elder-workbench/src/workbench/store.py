from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Any

from workbench.errors import RunNotFoundError, StorageError


class JsonRunStore:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir.resolve()
        self.runs_dir = self.data_dir / "runs"
        self.traces_dir = self.data_dir / "traces"
        self.temp_dir = self.data_dir / ".tmp"
        for path in [self.runs_dir, self.traces_dir, self.temp_dir]:
            path.mkdir(parents=True, exist_ok=True)

    def _atomic_json(self, target: Path, data: dict[str, Any]) -> None:
        temporary = self.temp_dir / f"{target.name}.{uuid.uuid4().hex}.tmp"
        try:
            temporary.write_text(
                json.dumps(data, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            os.replace(temporary, target)
        except OSError as exc:
            if temporary.exists():
                temporary.unlink()
            raise StorageError(f"Could not persist run data at {target}: {exc}") from exc

    def append_trace(self, run_id: str, event: dict[str, Any]) -> None:
        target = self.traces_dir / f"{run_id}.jsonl"
        try:
            with target.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(event, sort_keys=True) + "\n")
        except OSError as exc:
            raise StorageError(f"Could not append trace at {target}: {exc}") from exc

    def save_run(self, run_id: str, data: dict[str, Any]) -> None:
        self._atomic_json(self.runs_dir / f"{run_id}.json", data)

    def get_run(self, run_id: str) -> dict[str, Any]:
        target = self.runs_dir / f"{run_id}.json"
        if not target.is_file():
            raise RunNotFoundError(f"Run does not exist: {run_id}")
        try:
            data = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise StorageError(f"Could not read run data at {target}: {exc}") from exc
        if not isinstance(data, dict):
            raise StorageError(f"Run data is not a JSON object: {target}")
        return data

    def list_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        paths = sorted(
            self.runs_dir.glob("*.json"),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )[:limit]
        return [self.get_run(path.stem) for path in paths]
