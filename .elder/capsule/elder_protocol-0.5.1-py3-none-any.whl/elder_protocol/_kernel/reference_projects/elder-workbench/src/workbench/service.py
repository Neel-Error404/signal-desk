from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

from workbench.models import RunRequest
from workbench.provider import DeterministicReasoningProvider, ReasoningProvider
from workbench.store import JsonRunStore
from workbench.workflow import (
    ArchitectureNode,
    EconomicsNode,
    EvidenceNode,
    FinalizeNode,
    GoToMarketNode,
    HumanGateNode,
    IntakeNode,
    OntologyNode,
    OperationsNode,
    RiskNode,
    WayfinderNode,
    WorkflowEngine,
    workflow_graph,
)


class WorkbenchService:
    def __init__(
        self,
        data_dir: Path,
        provider: ReasoningProvider | None = None,
    ):
        self.store = JsonRunStore(data_dir)
        self.provider = provider or DeterministicReasoningProvider()
        self.engine = WorkflowEngine(
            [
                IntakeNode(),
                WayfinderNode(self.provider),
                OntologyNode(),
                ArchitectureNode(),
                RiskNode(),
                EconomicsNode(),
                EvidenceNode(),
                OperationsNode(),
                GoToMarketNode(),
                HumanGateNode(),
                FinalizeNode(),
            ],
            self.store,
        )

    def create_run(self, payload: dict[str, Any]) -> dict[str, Any]:
        request = RunRequest.from_dict(payload)
        run_id = uuid.uuid4().hex
        return self.engine.execute(run_id, request)

    def get_run(self, run_id: str) -> dict[str, Any]:
        return self.store.get_run(run_id)

    def list_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        return self.store.list_runs(limit)

    def get_graph(self) -> dict[str, Any]:
        return workflow_graph()
