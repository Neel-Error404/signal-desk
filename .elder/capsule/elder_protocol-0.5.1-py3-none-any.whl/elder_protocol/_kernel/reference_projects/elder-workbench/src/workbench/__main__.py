from workbench.api import main


raise SystemExit(main())
