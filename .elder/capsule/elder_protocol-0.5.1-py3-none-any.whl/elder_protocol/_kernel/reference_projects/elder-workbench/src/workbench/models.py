from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from workbench.errors import InputValidationError


RISK_TIERS = {"low", "moderate", "high", "critical"}


@dataclass(frozen=True)
class RunRequest:
    brief: str
    constraints: tuple[str, ...]
    risk_tier: str
    requested_capabilities: tuple[str, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RunRequest":
        allowed = {
            "brief",
            "constraints",
            "risk_tier",
            "requested_capabilities",
        }
        if not isinstance(data, dict):
            raise InputValidationError("Run request must be a JSON object.")
        unknown = set(data) - allowed
        missing = allowed - set(data)
        if missing:
            raise InputValidationError(f"Run request is missing: {sorted(missing)}")
        if unknown:
            raise InputValidationError(f"Run request has unknown fields: {sorted(unknown)}")

        brief = data["brief"]
        if not isinstance(brief, str) or len(brief.strip()) < 20:
            raise InputValidationError("Brief must contain at least 20 characters.")
        if len(brief) > 8000:
            raise InputValidationError("Brief must not exceed 8000 characters.")

        constraints = data["constraints"]
        if not isinstance(constraints, list) or len(constraints) > 20:
            raise InputValidationError("Constraints must be a list with at most 20 entries.")
        if any(
            not isinstance(item, str) or not item.strip() or len(item) > 500
            for item in constraints
        ):
            raise InputValidationError(
                "Each constraint must be a non-empty string up to 500 characters."
            )

        risk_tier = data["risk_tier"]
        if risk_tier not in RISK_TIERS:
            raise InputValidationError(
                f"Risk tier must be one of: {sorted(RISK_TIERS)}"
            )

        capabilities = data["requested_capabilities"]
        if not isinstance(capabilities, list) or not capabilities:
            raise InputValidationError(
                "requested_capabilities must contain at least one capability."
            )
        if len(capabilities) > 20 or any(
            not isinstance(item, str) or not item.strip() or len(item) > 80
            for item in capabilities
        ):
            raise InputValidationError(
                "Capabilities must be non-empty strings up to 80 characters."
            )
        if len(capabilities) != len(set(capabilities)):
            raise InputValidationError("Capabilities cannot contain duplicates.")

        return cls(
            brief=brief.strip(),
            constraints=tuple(item.strip() for item in constraints),
            risk_tier=risk_tier,
            requested_capabilities=tuple(item.strip() for item in capabilities),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "brief": self.brief,
            "constraints": list(self.constraints),
            "risk_tier": self.risk_tier,
            "requested_capabilities": list(self.requested_capabilities),
        }
