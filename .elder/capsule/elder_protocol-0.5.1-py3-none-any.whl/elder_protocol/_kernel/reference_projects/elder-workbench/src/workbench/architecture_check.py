from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any


def _internal_imports(path: Path, import_prefix: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    imports: set[str] = set()
    qualified_prefix = f"{import_prefix}."
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith(qualified_prefix):
                    imports.add(
                        alias.name[len(qualified_prefix) :].split(".", 1)[0]
                    )
        elif (
            isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.startswith(qualified_prefix)
        ):
            imports.add(
                node.module[len(qualified_prefix) :].split(".", 1)[0]
            )
    return imports


def _load_contract(contract_path: Path) -> dict[str, Any]:
    return json.loads(contract_path.read_text(encoding="utf-8"))


def find_violations(
    package_dir: Path,
    contract_path: Path | None = None,
) -> list[str]:
    violations: list[str] = []
    package_dir = package_dir.resolve()
    project_root = package_dir.parents[1]
    contract = _load_contract(
        contract_path
        or project_root / "docs" / "architecture-boundaries.json"
    )
    policies = {
        module["id"]: set(module["allowed_internal_dependencies"])
        for module in contract["modules"]
    }
    declared_paths = {
        (project_root / module["path"]).resolve()
        for module in contract["modules"]
    }
    for path in sorted(package_dir.glob("*.py")):
        module = path.stem
        allowed = policies.get(module)
        if allowed is None:
            if contract["unknown_module_policy"] == "deny":
                violations.append(
                    f"{module}: module has no declared dependency policy"
                )
            continue
        forbidden = sorted(
            _internal_imports(path, contract["import_prefix"]) - allowed
        )
        if forbidden:
            violations.append(
                f"{module}: forbidden internal imports {forbidden}; allowed {sorted(allowed)}"
            )
    missing = sorted(
        str(path.relative_to(project_root))
        for path in declared_paths
        if not path.is_file()
    )
    violations.extend(f"declared module does not exist: {path}" for path in missing)
    return violations


def main() -> int:
    package_dir = Path(__file__).resolve().parent
    violations = find_violations(package_dir)
    if violations:
        for violation in violations:
            print(f"ARCHITECTURE VIOLATION: {violation}")
        return 1
    print("Architecture dependency direction is valid.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
