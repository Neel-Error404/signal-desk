from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from workbench.service import WorkbenchService


def main() -> int:
    parser = argparse.ArgumentParser(description="Smoke-test an Elder Workbench artifact.")
    parser.add_argument("--data-dir", type=Path, required=True)
    args = parser.parse_args()

    result = WorkbenchService(args.data_dir.resolve()).create_run(
        {
            "brief": (
                "Build a local workflow for an operator with measurable success "
                "criteria and a governed deployment boundary."
            ),
            "constraints": ["Require human approval before promotion."],
            "risk_tier": "moderate",
            "requested_capabilities": [
                "agentic",
                "web-product",
                "data",
                "go-to-market",
            ],
        }
    )
    if result["status"] != "needs-approval":
        raise RuntimeError(
            f"Smoke run did not stop at human approval: {result['status']}"
        )
    if len(result["trace"]["completed_nodes"]) != 11:
        raise RuntimeError("Smoke run did not complete the eleven-node graph.")
    print(
        json.dumps(
            {
                "status": "ok",
                "run_id": result["run_id"],
                "decision": result["status"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
