const state = {
  graph: null,
  result: null,
  activeTab: "overview",
};

const elements = {
  form: document.querySelector("#run-form"),
  runButton: document.querySelector("#run-button"),
  formError: document.querySelector("#form-error"),
  graph: document.querySelector("#workflow-graph"),
  runState: document.querySelector("#run-state"),
  blueprint: document.querySelector("#blueprint-output"),
  gate: document.querySelector("#human-gate"),
  questions: document.querySelector("#open-questions"),
  questionCount: document.querySelector("#question-count"),
  recentRuns: document.querySelector("#recent-runs"),
  refreshRuns: document.querySelector("#refresh-runs"),
  statusDot: document.querySelector("#status-dot"),
  systemStatus: document.querySelector("#system-status"),
  providerName: document.querySelector("#provider-name"),
};

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, options);
  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload.message || `Request failed with status ${response.status}.`);
  }
  return payload;
}

function renderGraph(completedNodes = [], activeNode = null) {
  if (!state.graph) {
    elements.graph.innerHTML = '<p class="empty-state">Workflow contract unavailable.</p>';
    return;
  }
  elements.graph.innerHTML = state.graph.nodes
    .map((node, index) => {
      const classes = ["workflow-node", node.kind === "human" ? "human" : ""];
      if (completedNodes.includes(node.id)) classes.push("complete");
      if (activeNode === node.id) classes.push("active");
      const mark = completedNodes.includes(node.id) ? "✓" : String(index + 1).padStart(2, "0");
      return `
        <div class="${classes.filter(Boolean).join(" ")}" data-node="${escapeHtml(node.id)}">
          <span class="node-mark"><b>${mark}</b></span>
          <span>${escapeHtml(node.label)}</span>
        </div>
      `;
    })
    .join("");
}

function listMarkup(items) {
  if (!items.length) return "<p>None recorded.</p>";
  return `<ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`;
}

function renderOverview(blueprint) {
  return `
    <section class="blueprint-section">
      <h2>${escapeHtml(blueprint.objective)}</h2>
      <div class="metric-row">
        <div class="metric"><span>Risk tier</span><strong>${escapeHtml(blueprint.risk.tier)}</strong></div>
        <div class="metric"><span>Autonomy ceiling</span><strong>${escapeHtml(blueprint.risk.maximum_autonomy)}</strong></div>
        <div class="metric"><span>Decision state</span><strong>${escapeHtml(blueprint.human_gate.status)}</strong></div>
      </div>
      <div class="detail-list">
        <div class="detail-row"><strong>Constraints</strong>${listMarkup(blueprint.constraints)}</div>
        <div class="detail-row"><strong>Required approvals</strong>${listMarkup(blueprint.human_gate.required_approvals)}</div>
        <div class="detail-row"><strong>Authority</strong><p>Design: ${escapeHtml(blueprint.authority.design)} · Promotion: ${escapeHtml(blueprint.authority.promotion)} · Agent: ${escapeHtml(blueprint.authority.agent)}</p></div>
      </div>
    </section>
  `;
}

function renderArchitecture(blueprint) {
  const components = blueprint.architecture.components.map(
    (component) => `
      <div class="detail-row">
        <strong>${escapeHtml(component.id)}</strong>
        <p>${escapeHtml(component.responsibility)}</p>
      </div>
    `,
  ).join("");
  return `
    <section class="blueprint-section">
      <h2>Bounded components and dependency direction</h2>
      <div class="detail-list">
        ${components}
        <div class="detail-row"><strong>Allowed direction</strong>${listMarkup(blueprint.architecture.dependency_direction)}</div>
        <div class="detail-row"><strong>Forbidden</strong>${listMarkup(blueprint.architecture.forbidden_dependencies)}</div>
      </div>
    </section>
  `;
}

function renderEvidence(blueprint) {
  return `
    <section class="blueprint-section">
      <h2>Evidence required before an operational claim</h2>
      <div class="detail-list">
        ${blueprint.evidence_plan.map((item) => `
          <div class="detail-row">
            <strong>${escapeHtml(item.level)}</strong>
            <p>${escapeHtml(item.proof)}</p>
          </div>
        `).join("")}
      </div>
    </section>
  `;
}

function renderOntology(blueprint) {
  const entities = blueprint.ontology.entities.map(
    (entity) => `${entity.type}: ${entity.label}`,
  );
  const relationships = blueprint.ontology.relationships.map(
    (relationship) => `${relationship.from} ${relationship.type} ${relationship.to}`,
  );
  return `
    <section class="blueprint-section">
      <h2>Project ontology</h2>
      <div class="detail-list">
        <div class="detail-row"><strong>Entities</strong>${listMarkup(entities)}</div>
        <div class="detail-row"><strong>Relationships</strong>${listMarkup(relationships)}</div>
      </div>
    </section>
  `;
}

function renderOperations(blueprint) {
  return `
    <section class="blueprint-section">
      <h2>Operational controls and economic measurement</h2>
      <div class="detail-list">
        <div class="detail-row"><strong>Operating mode</strong><p>${escapeHtml(blueprint.operations.operating_mode)}</p></div>
        <div class="detail-row"><strong>Health signals</strong>${listMarkup(blueprint.operations.health_signals)}</div>
        <div class="detail-row"><strong>Required runbooks</strong>${listMarkup(blueprint.operations.required_runbooks)}</div>
        <div class="detail-row"><strong>Cost drivers</strong>${listMarkup(blueprint.economics.cost_drivers)}</div>
        <div class="detail-row"><strong>Required metrics</strong>${listMarkup(blueprint.economics.required_metrics)}</div>
        <div class="detail-row"><strong>Budget authority</strong><p>${escapeHtml(blueprint.economics.budget_authority)} · ${escapeHtml(blueprint.economics.estimation_policy)}</p></div>
      </div>
    </section>
  `;
}

function renderMarket(blueprint) {
  const market = blueprint.go_to_market;
  return `
    <section class="blueprint-section">
      <h2>Market work remains proof-backed and human-published</h2>
      <div class="metric-row">
        <div class="metric"><span>Enabled</span><strong>${market.enabled ? "yes" : "internal only"}</strong></div>
        <div class="metric"><span>Audience</span><strong>${escapeHtml(market.target_audience_status)}</strong></div>
        <div class="metric"><span>Claims</span><strong>${escapeHtml(market.claim_policy)}</strong></div>
      </div>
      <div class="detail-list">
        <div class="detail-row"><strong>Launch assets</strong>${listMarkup(market.launch_assets)}</div>
        <div class="detail-row"><strong>Forbidden actions</strong>${listMarkup(market.forbidden_actions)}</div>
        <div class="detail-row"><strong>Publishing authority</strong><p>${escapeHtml(market.publishing_authority)}</p></div>
      </div>
    </section>
  `;
}

function renderBlueprint() {
  if (!state.result) return;
  const blueprint = state.result.blueprint;
  const renderers = {
    overview: renderOverview,
    architecture: renderArchitecture,
    evidence: renderEvidence,
    ontology: renderOntology,
    operations: renderOperations,
    market: renderMarket,
  };
  elements.blueprint.innerHTML = renderers[state.activeTab](blueprint);
}

function renderDecision(result) {
  const questions = result.blueprint.open_questions;
  const needsClarification = result.status === "needs-clarification";
  elements.gate.innerHTML = `
    <div class="gate-status ${needsClarification ? "warning" : "approval"}">
      <span class="gate-symbol" aria-hidden="true">${needsClarification ? "?" : "✓"}</span>
      <div>
        <strong>${needsClarification ? "Clarification required" : "Human approval required"}</strong>
        <span>${needsClarification ? "Resolve material unknowns before approving architecture." : "Blueprint is ready for architecture and product owner review."}</span>
      </div>
    </div>
  `;
  elements.questionCount.textContent = String(questions.length);
  elements.questions.innerHTML = questions.length
    ? questions.map((question) => `<div class="question-item">${escapeHtml(question)}</div>`).join("")
    : '<p class="empty-copy">No material questions detected. Human approval is still required.</p>';
}

function renderResult(result) {
  state.result = result;
  elements.runState.textContent = result.status.replaceAll("-", " ");
  elements.runState.className = "run-state complete";
  renderGraph(result.trace.completed_nodes);
  renderDecision(result);
  renderBlueprint();
}

async function loadRuns() {
  try {
    const payload = await requestJson("/api/runs");
    elements.recentRuns.innerHTML = payload.runs.length
      ? payload.runs.map((run) => `
          <button class="recent-run" type="button" data-run-id="${escapeHtml(run.run_id)}">
            <strong>${escapeHtml(run.blueprint.objective)}</strong>
            <span>${escapeHtml(run.status)} · ${new Date(run.completed_at).toLocaleString()}</span>
          </button>
        `).join("")
      : '<p class="empty-copy">No local runs yet.</p>';
  } catch (error) {
    elements.recentRuns.innerHTML = `<p class="empty-copy">${escapeHtml(error.message)}</p>`;
  }
}

async function loadRun(runId) {
  elements.formError.textContent = "";
  try {
    renderResult(await requestJson(`/api/runs/${runId}`));
  } catch (error) {
    elements.formError.textContent = error.message;
  }
}

async function initialize() {
  try {
    const [health, graph] = await Promise.all([
      requestJson("/health"),
      requestJson("/api/graph"),
    ]);
    state.graph = graph;
    elements.statusDot.classList.add("online");
    elements.systemStatus.textContent = "Runtime online";
    elements.providerName.textContent = health.provider;
    renderGraph();
  } catch (error) {
    elements.systemStatus.textContent = "Runtime unavailable";
    elements.formError.textContent = error.message;
  }
  await loadRuns();
}

elements.form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(elements.form);
  const requestedCapabilities = formData.getAll("capability");
  if (!requestedCapabilities.length) {
    elements.formError.textContent = "Select at least one capability pack.";
    return;
  }
  const payload = {
    brief: String(formData.get("brief") || "").trim(),
    constraints: String(formData.get("constraints") || "")
      .split("\n")
      .map((item) => item.trim())
      .filter(Boolean),
    risk_tier: String(formData.get("risk_tier")),
    requested_capabilities: requestedCapabilities,
  };

  elements.formError.textContent = "";
  elements.runButton.disabled = true;
  elements.runState.textContent = "Running";
  elements.runState.className = "run-state running";
  const nodes = state.graph ? state.graph.nodes : [];
  let activeIndex = 0;
  renderGraph([], nodes[activeIndex]?.id);
  const animation = window.setInterval(() => {
    activeIndex = Math.min(activeIndex + 1, nodes.length - 1);
    renderGraph(nodes.slice(0, activeIndex).map((node) => node.id), nodes[activeIndex]?.id);
  }, 180);

  try {
    const result = await fetch("/api/runs", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload),
    });
    const responsePayload = await result.json();
    if (!result.ok) throw new Error(responsePayload.message || "Run failed.");
    renderResult(responsePayload);
    await loadRuns();
  } catch (error) {
    elements.formError.textContent = error.message;
    elements.runState.textContent = "Failed";
    elements.runState.className = "run-state";
    renderGraph();
  } finally {
    window.clearInterval(animation);
    elements.runButton.disabled = false;
  }
});

document.querySelector(".result-tabs").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-tab]");
  if (!button) return;
  state.activeTab = button.dataset.tab;
  document.querySelectorAll(".result-tabs button").forEach((tab) => {
    tab.classList.toggle("active", tab === button);
  });
  renderBlueprint();
});

elements.refreshRuns.addEventListener("click", loadRuns);
elements.recentRuns.addEventListener("click", (event) => {
  const button = event.target.closest("[data-run-id]");
  if (button) loadRun(button.dataset.runId);
});

initialize();
