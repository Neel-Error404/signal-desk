# Elder Workbench

Elder Workbench is the P2 reference product for Elder Protocol. It turns an
ambiguous project brief into a traceable blueprint with explicit questions,
architecture boundaries, risk classification, evidence requirements, and a
human approval gate. Its eleven-node graph also defines economic measurement,
operational runbooks, and proof-backed go-to-market work.

## Run

```powershell
py run.py
```

Open `http://127.0.0.1:8765`.

The default provider is deterministic and requires no external service or API
key. Runtime snapshots and append-only traces are written below `data/`.

## Verify

Run each level independently and do not advance past a failure:

```powershell
py -m unittest discover -s tests\foundation -v
py -m unittest discover -s tests\component -v
py -m unittest discover -s tests\integration -v
py -m unittest discover -s tests\workflow -v
py -m unittest discover -s tests\stress -v
```

Run the architecture fitness function directly:

```powershell
$env:PYTHONPATH = "src"
py -m workbench.architecture_check
```

## Authority Boundary

The workbench proposes a blueprint. It cannot approve architecture, promote a
release, modify trusted policy, or represent a run as operational. Those
decisions remain human-owned.
