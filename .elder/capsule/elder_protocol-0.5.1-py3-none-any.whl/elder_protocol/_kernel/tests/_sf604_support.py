from __future__ import annotations

import base64
import copy
from datetime import datetime, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from elder_protocol.factory_operations.hosted_git_controls import (
    HOSTED_GIT_CONTROL_VERSION,
    HostedGitReviewControls,
    hosted_git_content_sha256,
    sign_hosted_git_statement,
)
from elder_protocol.qualification import (
    CANONICAL_OPERATOR_ANCHOR_ID,
    CANONICAL_REVIEWER_ANCHOR_ID,
)
from tests._sf404_support import (
    DELIVERY_AT,
    CountingSubmitter,
    build_environment as build_sf404_environment,
)


NOW = DELIVERY_AT
ARTIFACT_SHA256 = "a" * 64
REPOSITORY = "fixture/product-one"
URL_PREFIX = f"https://git.example.test/{REPOSITORY}/pull/"
PROVIDER_SUBJECT = "operator:test:sf604:provider-verifier"
REVIEWER_SUBJECT = "reviewer:test:sf604:independent"


def finalize(document: dict[str, Any]) -> dict[str, Any]:
    prepared = copy.deepcopy(document)
    prepared["content_sha256"] = hosted_git_content_sha256(prepared)
    return prepared


class MutableClock:
    def __init__(self, value: datetime = NOW):
        self.value = value

    def __call__(self) -> datetime:
        return self.value

    def advance(self, seconds: int) -> None:
        self.value += timedelta(seconds=seconds)


def _private_key_base64(key: Ed25519PrivateKey) -> str:
    return base64.b64encode(key.private_bytes_raw()).decode("ascii")


def _public_key_base64(key: Ed25519PrivateKey) -> str:
    return base64.b64encode(
        key.public_key().public_bytes_raw()
    ).decode("ascii")


PROVIDER_KEY = Ed25519PrivateKey.generate()
REVIEWER_KEY = Ed25519PrivateKey.generate()
PROVIDER_KEY_BASE64 = _private_key_base64(PROVIDER_KEY)
REVIEWER_KEY_BASE64 = _private_key_base64(REVIEWER_KEY)
_ANCHOR_BODY = {
    "version": HOSTED_GIT_CONTROL_VERSION,
    "anchors": [
        {
            "id": CANONICAL_REVIEWER_ANCHOR_ID,
            "role": "independent-reviewer",
            "subject_identity": REVIEWER_SUBJECT,
            "public_key_base64": _public_key_base64(REVIEWER_KEY),
            "source_hosts": ["git.example.test"],
            "valid_from": "2026-08-01T00:00:00+00:00",
            "valid_until": "2027-08-01T00:00:00+00:00",
        },
        {
            "id": CANONICAL_OPERATOR_ANCHOR_ID,
            "role": "independent-verifier",
            "subject_identity": PROVIDER_SUBJECT,
            "public_key_base64": _public_key_base64(PROVIDER_KEY),
            "source_hosts": ["git.example.test"],
            "valid_from": "2026-08-01T00:00:00+00:00",
            "valid_until": "2027-08-01T00:00:00+00:00",
        },
    ],
}
TEST_ANCHORS = finalize(_ANCHOR_BODY)
patch(
    "elder_protocol.factory_operations.hosted_git_controls."
    "_canonical_hosted_git_trust_anchors",
    return_value=TEST_ANCHORS,
).start()

_SF404_TEMP: TemporaryDirectory[str] | None = None
_SF404_TEMPLATE: dict[str, Any] | None = None
_SF404_AUTHORITY_PATCHER: Any | None = None


def _sf404_template() -> dict[str, Any]:
    global _SF404_TEMP, _SF404_TEMPLATE, _SF404_AUTHORITY_PATCHER
    if _SF404_TEMPLATE is not None:
        return copy.deepcopy(_SF404_TEMPLATE)
    _SF404_TEMP = TemporaryDirectory(prefix="elder-sf604-sf404-")
    sf404 = build_sf404_environment(Path(_SF404_TEMP.name))
    submitter = CountingSubmitter()
    opened = sf404["delivery_service"].decide(
        sf404["delivery_request"],
        sf404["delivery_sources"],
        sf404["execution"],
        submitter,
        actor_identity_id="founder",
        decision="submit",
        reason="Open the exact supervised pull request for SF-604 proof.",
    )
    if opened["status"] != "open":
        raise AssertionError("SF-604 fixture could not open SF-404 delivery.")
    _SF404_TEMPLATE = {
        "delivery_record": sf404["delivery_service"].repository.get(
            sf404["delivery_request"]["request_id"]
        ),
        "delivery_request": sf404["delivery_request"],
        "delivery_sources": sf404["delivery_sources"],
        "execution": sf404["execution"],
        "authority_decision": sf404["authority"]["decision"],
        "completion": sf404["completion"],
    }
    _SF404_AUTHORITY_PATCHER = sf404["authority_patcher"]
    return copy.deepcopy(_SF404_TEMPLATE)


def build_environment(
    workspace: Path,
    *,
    now: datetime = NOW,
    policy_overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    provider_key_b64 = PROVIDER_KEY_BASE64
    reviewer_key_b64 = REVIEWER_KEY_BASE64
    anchors = TEST_ANCHORS
    sf404 = _sf404_template()
    delivery_record = sf404["delivery_record"]
    packet = copy.deepcopy(delivery_record["packet"])
    policy_body = {
        "version": HOSTED_GIT_CONTROL_VERSION,
        "policy_id": "sf604-policy",
        "provider": "fixture-ci",
        "provider_identity": "provider:git.example.test:hosted-service",
        "repository": REPOSITORY,
        "trusted_pull_request_url_prefix": URL_PREFIX,
        "protected_base_branch": "main",
        "ruleset_id": "ruleset-main",
        "branch_rules": {
            "blocks_deletions": True,
            "blocks_force_pushes": True,
            "dismisses_stale_reviews": True,
            "requires_approving_reviews": True,
            "requires_code_owner_review": True,
            "requires_conversation_resolution": True,
            "requires_linear_history": True,
            "requires_pull_request": True,
            "restricts_bypass": True,
        },
        "minimum_approving_reviews": 1,
        "required_checks": [
            "P3 / protocol",
            "P3 / reference-project",
            "P3 / reproducible-artifact",
        ],
        "provider_signer_ids": [CANONICAL_OPERATOR_ANCHOR_ID],
        "independent_reviewer_ids": [CANONICAL_REVIEWER_ANCHOR_ID],
        "statement_max_age_seconds": 900,
        "maximum_governance_response_skew_seconds": 60,
        "evidence_retention_seconds": 86400,
        "issued_at": (now - timedelta(hours=1)).isoformat(),
        "expires_at": (now + timedelta(days=2)).isoformat(),
    }
    if policy_overrides:
        policy_body.update(copy.deepcopy(policy_overrides))
    policy = finalize(policy_body)
    if (
        packet["provider"] != policy["provider"]
        or packet["repository"] != policy["repository"]
        or packet["pull_request_url_prefix"]
        != policy["trusted_pull_request_url_prefix"]
        or packet["base_branch"] != policy["protected_base_branch"]
    ):
        raise AssertionError("SF-404 packet does not match SF-604 policy.")
    statement_expiry = (now + timedelta(minutes=10)).isoformat()
    governance_statement = {
        "version": HOSTED_GIT_CONTROL_VERSION,
        "statement_type": "hosted-git-governance",
        "policy_sha256": policy["content_sha256"],
        "provider": policy["provider"],
        "repository": policy["repository"],
        "protected_base_branch": policy["protected_base_branch"],
        "trusted_pull_request_url_prefix": policy[
            "trusted_pull_request_url_prefix"
        ],
        "branch_rules": copy.deepcopy(policy["branch_rules"]),
        "minimum_approving_reviews": policy["minimum_approving_reviews"],
        "required_checks": copy.deepcopy(policy["required_checks"]),
        "provider_identity": policy["provider_identity"],
        "verifier_identity": PROVIDER_SUBJECT,
        "ruleset_id": policy["ruleset_id"],
        "ruleset_revision": 7,
        "ruleset_sha256": "7" * 64,
        "source_uri": (
            f"https://git.example.test/{REPOSITORY}/settings/rules/1"
        ),
        "observed_at": now.isoformat(),
        "expires_at": statement_expiry,
    }
    governance = sign_hosted_git_statement(
        governance_statement,
        signer_id=CANONICAL_OPERATOR_ANCHOR_ID,
        private_key_base64=provider_key_b64,
    )
    packet_bindings = {
        "packet_sha256": packet["content_sha256"],
        "provider": packet["provider"],
        "repository": packet["repository"],
        "git_object_format": packet["git_object_format"],
        "base_branch": packet["base_branch"],
        "head_branch": packet["head_branch"],
        "base_revision": packet["base_revision"],
        "head_revision": packet["head_revision"],
        "diff_sha256": packet["diff_sha256"],
    }
    provenance_statement = {
        "version": HOSTED_GIT_CONTROL_VERSION,
        "statement_type": "hosted-git-provenance",
        "policy_sha256": policy["content_sha256"],
        "governance_sha256": governance["content_sha256"],
        **packet_bindings,
        "artifact_sha256": ARTIFACT_SHA256,
        "supervised_delivery_record_sha256": delivery_record[
            "content_sha256"
        ],
        "trusted_sources_sha256": delivery_record[
            "trusted_sources_sha256"
        ],
        "check_results": [
            {
                "name": name,
                "status": "success",
                "head_revision": packet["head_revision"],
                "evidence_sha256": f"{index + 7:064x}",
            }
            for index, name in enumerate(policy["required_checks"])
        ],
        "provider_identity": policy["provider_identity"],
        "verifier_identity": PROVIDER_SUBJECT,
        "source_uri": (
            f"https://git.example.test/{REPOSITORY}/actions/runs/604"
        ),
        "observed_at": now.isoformat(),
        "expires_at": statement_expiry,
    }
    provenance = sign_hosted_git_statement(
        provenance_statement,
        signer_id=CANONICAL_OPERATOR_ANCHOR_ID,
        private_key_base64=provider_key_b64,
    )
    review_statement = {
        "version": HOSTED_GIT_CONTROL_VERSION,
        "statement_type": "hosted-git-independent-review",
        "policy_sha256": policy["content_sha256"],
        "governance_sha256": governance["content_sha256"],
        "provenance_sha256": provenance["content_sha256"],
        **packet_bindings,
        "artifact_sha256": ARTIFACT_SHA256,
        "pull_request_id": "42",
        "pull_request_url": f"{URL_PREFIX}42",
        "provider_response_sha256": None,
        "reviewer_identity": REVIEWER_SUBJECT,
        "review_artifact_sha256": "9" * 64,
        "remaining_findings": {
            "critical": 0,
            "high": 0,
            "medium": 0,
        },
        "decision": "approved",
        "source_uri": (
            f"https://git.example.test/{REPOSITORY}/pull/42/reviews/1"
        ),
        "observed_at": now.isoformat(),
        "expires_at": statement_expiry,
    }
    provider_response_statement = {
            "version": HOSTED_GIT_CONTROL_VERSION,
            "statement_type": "hosted-git-provider-response",
            "policy_sha256": policy["content_sha256"],
            "governance_sha256": governance["content_sha256"],
            "provenance_sha256": provenance["content_sha256"],
            "authorized_packet_sha256": packet["content_sha256"],
            "provider": packet["provider"],
            "repository": packet["repository"],
            "git_object_format": packet["git_object_format"],
            "base_branch": packet["base_branch"],
            "head_branch": packet["head_branch"],
            "base_revision": packet["base_revision"],
            "head_revision": packet["head_revision"],
            "diff_sha256": packet["diff_sha256"],
            "artifact_sha256": ARTIFACT_SHA256,
            "provider_identity": policy["provider_identity"],
            "verifier_identity": PROVIDER_SUBJECT,
            "ruleset_id": policy["ruleset_id"],
            "ruleset_revision": 7,
            "ruleset_sha256": "7" * 64,
            "pull_request_id": "42",
            "url": f"{URL_PREFIX}42",
            "status": "open",
            "merged": False,
            "deployed": False,
            "observed_at": now.isoformat(),
        }
    provider_response = sign_hosted_git_statement(
        provider_response_statement,
        signer_id=CANONICAL_OPERATOR_ANCHOR_ID,
        private_key_base64=provider_key_b64,
    )
    review_statement["provider_response_sha256"] = provider_response[
        "content_sha256"
    ]
    independent_review = sign_hosted_git_statement(
        review_statement,
        signer_id=CANONICAL_REVIEWER_ANCHOR_ID,
        private_key_base64=reviewer_key_b64,
    )
    authority_inputs = {
        "request": sf404["delivery_request"],
        "sources": sf404["delivery_sources"],
        "execution": sf404["execution"],
    }
    authority_decision = sf404["authority_decision"]
    evidence_completion = sf404["completion"]

    def authority_resolver(_delivery: dict[str, Any]) -> dict[str, Any]:
        return copy.deepcopy(authority_inputs)

    def authority_decision_loader(
        request_id: str,
    ) -> dict[str, Any] | None:
        if request_id != authority_decision["request_id"]:
            return None
        return copy.deepcopy(authority_decision)

    def evidence_completion_loader(
        plan_id: str,
    ) -> dict[str, Any] | None:
        if plan_id != evidence_completion["plan_id"]:
            return None
        return copy.deepcopy(evidence_completion)

    clock = MutableClock(now)
    controls = HostedGitReviewControls(
        workspace / "hosted-git-controls.db",
        policy=policy,
        authority_resolver=authority_resolver,
        authority_decision_loader=authority_decision_loader,
        evidence_completion_loader=evidence_completion_loader,
        now=clock,
    )
    return {
        "workspace": workspace,
        "provider_key_base64": provider_key_b64,
        "reviewer_key_base64": reviewer_key_b64,
        "anchors": anchors,
        "policy": policy,
        "packet": packet,
        "governance": governance,
        "provenance": provenance,
        "independent_review": independent_review,
        "provider_response": provider_response,
        "supervised_delivery_record": delivery_record,
        "supervised_delivery_request": sf404["delivery_request"],
        "supervised_delivery_sources": sf404["delivery_sources"],
        "supervised_delivery_execution": sf404["execution"],
        "authority_decision": authority_decision,
        "evidence_completion": evidence_completion,
        "authority_resolver": authority_resolver,
        "authority_decision_loader": authority_decision_loader,
        "evidence_completion_loader": evidence_completion_loader,
        "artifact_sha256": ARTIFACT_SHA256,
        "clock": clock,
        "controls": controls,
    }


def resign_governance(
    environment: dict[str, Any],
    statement: dict[str, Any],
) -> dict[str, Any]:
    return sign_hosted_git_statement(
        statement,
        signer_id=CANONICAL_OPERATOR_ANCHOR_ID,
        private_key_base64=environment["provider_key_base64"],
    )


def resign_provenance(
    environment: dict[str, Any],
    statement: dict[str, Any],
) -> dict[str, Any]:
    return sign_hosted_git_statement(
        statement,
        signer_id=CANONICAL_OPERATOR_ANCHOR_ID,
        private_key_base64=environment["provider_key_base64"],
    )


def resign_review(
    environment: dict[str, Any],
    statement: dict[str, Any],
) -> dict[str, Any]:
    return sign_hosted_git_statement(
        statement,
        signer_id=CANONICAL_REVIEWER_ANCHOR_ID,
        private_key_base64=environment["reviewer_key_base64"],
    )


def resign_provider_response(
    environment: dict[str, Any],
    statement: dict[str, Any],
) -> dict[str, Any]:
    return sign_hosted_git_statement(
        statement,
        signer_id=CANONICAL_OPERATOR_ANCHOR_ID,
        private_key_base64=environment["provider_key_base64"],
    )


def verify(environment: dict[str, Any]) -> dict[str, Any]:
    return environment["controls"].verify_delivery(
        packet=environment["packet"],
        governance=environment["governance"],
        provenance=environment["provenance"],
        independent_review=environment["independent_review"],
        provider_response=environment["provider_response"],
        supervised_delivery_record=environment[
            "supervised_delivery_record"
        ],
        artifact_sha256=environment["artifact_sha256"],
    )


def delivery_variant(
    environment: dict[str, Any],
    index: int,
) -> dict[str, Any]:
    variant = dict(environment)
    packet = copy.deepcopy(environment["packet"])
    packet["title"] = f"{packet['title']} variant {index}"
    packet["body"] = f"{packet['body']} Variant {index}."
    packet = finalize(
        {
            key: value
            for key, value in packet.items()
            if key != "content_sha256"
        }
    )
    packet_bindings = {
        "packet_sha256": packet["content_sha256"],
        "provider": packet["provider"],
        "repository": packet["repository"],
        "git_object_format": packet["git_object_format"],
        "base_branch": packet["base_branch"],
        "head_branch": packet["head_branch"],
        "base_revision": packet["base_revision"],
        "head_revision": packet["head_revision"],
        "diff_sha256": packet["diff_sha256"],
    }
    pull_request_id = str(1000 + index)
    pull_request_url = f"{URL_PREFIX}{pull_request_id}"
    p5_response = copy.deepcopy(
        environment["supervised_delivery_record"]["provider_response"]
    )
    p5_response.update(
        {
            "authorized_packet_sha256": packet["content_sha256"],
            "pull_request_id": pull_request_id,
            "url": pull_request_url,
        }
    )
    delivery_record = copy.deepcopy(
        environment["supervised_delivery_record"]
    )
    delivery_record.update(
        {
            "packet": packet,
            "provider_response": p5_response,
        }
    )
    delivery_record = finalize(
        {
            key: value
            for key, value in delivery_record.items()
            if key != "content_sha256"
        }
    )
    provenance_statement = copy.deepcopy(
        environment["provenance"]["statement"]
    )
    provenance_statement.update(packet_bindings)
    provenance_statement[
        "supervised_delivery_record_sha256"
    ] = delivery_record["content_sha256"]
    provenance_statement["trusted_sources_sha256"] = delivery_record[
        "trusted_sources_sha256"
    ]
    provenance_statement["check_results"] = [
        {
            **item,
            "head_revision": packet["head_revision"],
            "evidence_sha256": f"{index * 10 + offset + 300:064x}",
        }
        for offset, item in enumerate(provenance_statement["check_results"])
    ]
    provenance = resign_provenance(environment, provenance_statement)
    response_statement = copy.deepcopy(
        environment["provider_response"]["statement"]
    )
    response_statement.update(
        {
            "provenance_sha256": provenance["content_sha256"],
            "authorized_packet_sha256": packet["content_sha256"],
            "pull_request_id": pull_request_id,
            "url": pull_request_url,
        }
    )
    provider_response = resign_provider_response(
        environment,
        response_statement,
    )
    review_statement = copy.deepcopy(
        environment["independent_review"]["statement"]
    )
    review_statement.update(packet_bindings)
    review_statement["provenance_sha256"] = provenance["content_sha256"]
    review_statement["pull_request_id"] = pull_request_id
    review_statement["pull_request_url"] = pull_request_url
    review_statement["provider_response_sha256"] = provider_response[
        "content_sha256"
    ]
    review_statement["review_artifact_sha256"] = f"{index + 500:064x}"
    review_statement["source_uri"] = (
        f"https://git.example.test/{REPOSITORY}/pull/"
        f"{pull_request_id}/reviews/1"
    )
    independent_review = resign_review(environment, review_statement)
    variant.update(
        {
            "packet": packet,
            "provenance": provenance,
            "independent_review": independent_review,
            "provider_response": provider_response,
            "supervised_delivery_record": delivery_record,
        }
    )
    return variant
