from __future__ import annotations

import copy
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Mapping

from elder_protocol.factory_operations.hosted_identity import (
    BrokeredCredential,
    ExternalSecretBroker,
    IdentitySecretAuditLedger,
    WorkloadIdentityVerifier,
)
from elder_protocol.factory_operations.hosted_workspace import (
    HOSTED_WORKSPACE_VERSION,
    workspace_content_sha256,
)
from tests._sf601_support import FakeSecretProvider, resource_reference


NOW = datetime(2026, 8, 14, 23, 0, tzinfo=UTC)
IMAGE = "sha256:" + "a" * 64
ARTIFACT = "sha256:" + "b" * 64
TOOL_ARTIFACT = "sha256:" + "c" * 64
TREE = "sha256:" + "d" * 64
INSTRUCTIONS = "sha256:" + "e" * 64


def workspace_policy() -> dict[str, Any]:
    body = {
        "version": HOSTED_WORKSPACE_VERSION,
        "policy_id": "sf602-policy",
        "providers": [
            {
                "provider_id": "workspace-provider-one",
                "disposable": True,
                "network_default_deny": True,
                "images": [IMAGE],
                "repository_artifacts": [ARTIFACT],
                "repository_url_prefixes": [
                    "https://github.com/example/"
                ],
                "tools": [
                    {
                        "tool_id": "git",
                        "version": "2.51.0",
                        "artifact_sha256": TOOL_ARTIFACT,
                    }
                ],
                "allowed_egress": [
                    {
                        "protocol": "https",
                        "host": "api.example.test",
                        "port": 443,
                    }
                ],
                "maximum_resources": {
                    "cpu_millis": 2000,
                    "memory_bytes": 1024 * 1024 * 1024,
                    "disk_bytes": 4 * 1024 * 1024 * 1024,
                    "pids": 128,
                    "duration_seconds": 900,
                },
                "maximum_retention_seconds": 600,
            }
        ],
        "issued_at": (NOW - timedelta(minutes=5)).isoformat(),
        "expires_at": (NOW + timedelta(days=1)).isoformat(),
    }
    return {**body, "content_sha256": workspace_content_sha256(body)}


def credential() -> BrokeredCredential:
    return BrokeredCredential(
        lease_id="lease-workspace-one",
        reference_id="reference-database-v1",
        broker_id="broker-one",
        project_id="project-one",
        resource_id="resource-database",
        resource_version="v1",
        workload_id="worker-one",
        issued_at=(NOW - timedelta(seconds=5)).isoformat(),
        expires_at=(NOW + timedelta(minutes=5)).isoformat(),
        value=b"workspace-credential-value",
    )


def workspace_request(
    *,
    workspace_id: str = "workspace-sf602",
    project_id: str = "project-one",
    workload_id: str = "worker-one",
    image_digest: str = IMAGE,
    artifact_sha256: str = ARTIFACT,
    instruction_sha256: str = INSTRUCTIONS,
    retention_seconds: int = 120,
    brokered_credential: BrokeredCredential | None = None,
) -> dict[str, Any]:
    slot = {
        "slot_id": "database-read",
        "lease_id": "lease-workspace-one",
        "reference_id": "reference-database-v1",
        "broker_id": "broker-one",
        "resource_id": "resource-database",
        "resource_version": "v1",
    }
    if brokered_credential is not None:
        slot.update(
            {
                "lease_id": brokered_credential.lease_id,
                "reference_id": brokered_credential.reference_id,
                "broker_id": brokered_credential.broker_id,
                "resource_id": brokered_credential.resource_id,
                "resource_version": brokered_credential.resource_version,
            }
        )
    body = {
        "version": HOSTED_WORKSPACE_VERSION,
        "provider_id": "workspace-provider-one",
        "project_id": project_id,
        "workload_id": workload_id,
        "run_id": "run-sf602",
        "workspace_id": workspace_id,
        "image_digest": image_digest,
        "repository": {
            "url": "https://github.com/example/product.git",
            "revision": "f" * 40,
            "tree_sha256": TREE,
            "artifact_sha256": artifact_sha256,
            "instruction_sha256": instruction_sha256,
        },
        "tools": [
            {
                "tool_id": "git",
                "version": "2.51.0",
                "artifact_sha256": TOOL_ARTIFACT,
            }
        ],
        "network": {
            "default_deny": True,
            "allowed_egress": [
                {
                    "protocol": "https",
                    "host": "api.example.test",
                    "port": 443,
                }
            ],
        },
        "resources": {
            "cpu_millis": 1000,
            "memory_bytes": 512 * 1024 * 1024,
            "disk_bytes": 2 * 1024 * 1024 * 1024,
            "pids": 64,
            "duration_seconds": 600,
        },
        "injection_slots": [slot],
        "retention_seconds": retention_seconds,
    }
    return {**body, "content_sha256": workspace_content_sha256(body)}


def issue_workspace_credential(
    root: Path,
    verifier: WorkloadIdentityVerifier,
    token: str,
    *,
    request_id: str = "request-sf602-broker-issue",
) -> tuple[ExternalSecretBroker, BrokeredCredential]:
    broker = ExternalSecretBroker(
        identity_verifier=verifier,
        providers={
            "broker-one": FakeSecretProvider(
                now=NOW,
                ttl_seconds=120,
            )
        },
        audit=IdentitySecretAuditLedger(root / "identity.db"),
        now=lambda: NOW,
    )
    issued = broker.issue(
        resource_reference(),
        token,
        request_id=request_id,
        at=NOW.isoformat(),
    )
    return broker, issued


class FakeHostedWorkspaceProvider:
    def __init__(
        self,
        *,
        create_unavailable: bool = False,
        inspect_unavailable: bool = False,
        destroy_unavailable: bool = False,
        policy_sha256: str | None = None,
        create_error: Exception | None = None,
        inspect_error: Exception | None = None,
        destroy_error: Exception | None = None,
    ) -> None:
        self.create_unavailable = create_unavailable
        self.inspect_unavailable = inspect_unavailable
        self.destroy_unavailable = destroy_unavailable
        self.create_error = create_error
        self.inspect_error = inspect_error
        self.destroy_error = destroy_error
        self.policy_sha256 = (
            policy_sha256 or workspace_policy()["content_sha256"]
        )
        self.create_calls: list[dict[str, Any]] = []
        self.inspect_calls: list[dict[str, Any]] = []
        self.destroy_calls: list[dict[str, Any]] = []
        self.request: dict[str, Any] | None = None
        self.provider_workspace_id = "provider-workspace-sf602"
        self.image_digest: str | None = None
        self.artifact_sha256: str | None = None
        self.tree_sha256: str | None = None
        self.instruction_sha256: str | None = None
        self.tool_invocations: list[dict[str, Any]] | None = None
        self.egress: list[dict[str, Any]] | None = None
        self.resource_peaks: dict[str, int] | None = None
        self.violations: list[dict[str, Any]] = []
        self.cleanup_flags = {
            "processes_terminated": True,
            "network_detached": True,
            "storage_deleted": True,
            "injected_material_deleted": True,
            "workspace_absent": True,
        }

    def create(
        self,
        request: dict[str, Any],
        identity: dict[str, Any],
        injected_values: Mapping[str, bytes],
        *,
        at: str,
    ) -> dict[str, Any]:
        if self.create_error is not None:
            raise self.create_error
        if self.create_unavailable:
            raise OSError("workspace provider unavailable")
        self.request = copy.deepcopy(request)
        self.create_calls.append(
            {
                "request": copy.deepcopy(request),
                "identity": copy.deepcopy(identity),
                "injected_values": dict(injected_values),
                "at": at,
            }
        )
        return {
            "provider_id": request["provider_id"],
            "provider_workspace_id": self.provider_workspace_id,
            "workspace_id": request["workspace_id"],
            "request_sha256": request["content_sha256"],
            "policy_sha256": self.policy_sha256,
            "image_digest": request["image_digest"],
            "artifact_sha256": request["repository"]["artifact_sha256"],
            "tree_sha256": request["repository"]["tree_sha256"],
            "instruction_sha256": request["repository"][
                "instruction_sha256"
            ],
            "tool_policy_sha256": workspace_content_sha256(request["tools"]),
            "network_policy_sha256": workspace_content_sha256(
                request["network"]
            ),
            "resource_budget_sha256": workspace_content_sha256(
                request["resources"]
            ),
            "injection_slots_sha256": workspace_content_sha256(
                request["injection_slots"]
            ),
            "created_at": at,
            "expires_at": (
                datetime.fromisoformat(at)
                + timedelta(seconds=request["retention_seconds"])
            ).isoformat(),
            "disposable": True,
            "network_default_deny": True,
            "state": "running",
        }

    def inspect(
        self,
        provider_workspace_id: str,
        request_sha256: str,
        *,
        at: str,
    ) -> dict[str, Any]:
        if self.inspect_error is not None:
            raise self.inspect_error
        if self.inspect_unavailable:
            raise OSError("workspace provider unavailable")
        if self.request is None:
            raise AssertionError("workspace was not created")
        self.inspect_calls.append(
            {
                "provider_workspace_id": provider_workspace_id,
                "request_sha256": request_sha256,
                "at": at,
            }
        )
        request = self.request
        return {
            "provider_id": request["provider_id"],
            "provider_workspace_id": provider_workspace_id,
            "workspace_id": request["workspace_id"],
            "request_sha256": request_sha256,
            "observed_at": at,
            "state": "running",
            "image_digest": self.image_digest or request["image_digest"],
            "artifact_sha256": (
                self.artifact_sha256
                or request["repository"]["artifact_sha256"]
            ),
            "tree_sha256": (
                self.tree_sha256 or request["repository"]["tree_sha256"]
            ),
            "instruction_sha256": (
                self.instruction_sha256
                or request["repository"]["instruction_sha256"]
            ),
            "tool_invocations": copy.deepcopy(
                self.tool_invocations
                if self.tool_invocations is not None
                else [
                    {
                        **request["tools"][0],
                        "count": 1,
                    }
                ]
            ),
            "resource_peaks": copy.deepcopy(
                self.resource_peaks
                if self.resource_peaks is not None
                else {
                    "cpu_millis": 500,
                    "memory_bytes": 256 * 1024 * 1024,
                    "disk_bytes": 256 * 1024 * 1024,
                    "pids": 12,
                    "duration_seconds": 30,
                }
            ),
            "egress": copy.deepcopy(
                self.egress
                if self.egress is not None
                else [
                    {
                        **request["network"]["allowed_egress"][0],
                        "bytes_sent": 128,
                        "bytes_received": 512,
                        "connections": 1,
                    }
                ]
            ),
            "violations": copy.deepcopy(self.violations),
        }

    def destroy(
        self,
        provider_workspace_id: str,
        request_sha256: str,
        *,
        at: str,
    ) -> dict[str, Any]:
        if self.destroy_error is not None:
            raise self.destroy_error
        if self.destroy_unavailable:
            raise OSError("workspace provider unavailable")
        if self.request is None:
            raise AssertionError("workspace was not created")
        self.destroy_calls.append(
            {
                "provider_workspace_id": provider_workspace_id,
                "request_sha256": request_sha256,
                "at": at,
            }
        )
        return {
            "provider_id": self.request["provider_id"],
            "provider_workspace_id": provider_workspace_id,
            "workspace_id": self.request["workspace_id"],
            "request_sha256": request_sha256,
            "destroyed_at": at,
            "state": "destroyed",
            **copy.deepcopy(self.cleanup_flags),
        }
