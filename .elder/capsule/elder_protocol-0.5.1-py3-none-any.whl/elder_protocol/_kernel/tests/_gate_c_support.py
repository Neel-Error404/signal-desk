from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time
from typing import Any
import uuid

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import PROTOCOL_DIR, ROOT
from elder_protocol.factory_operations import (
    DurableDispatcher,
    DurableSessionController,
    FactoryOperationsBootstrap,
    LocalRepositoryInspector,
    ProductFactoryRegistry,
    RunController,
    RuntimeCoordinationInspector,
    SignalIntake,
    WorkItemLedger,
    WorkItemTransitionEngine,
    WorkspaceLifecycleManager,
    WorkerRecoveryCoordinator,
    GATE_C_FORBIDDEN_AUTHORITY,
    finalize_gate_c_record,
    record_content_sha256,
    transition_authorization_request_sha256,
    transition_authorization_result_sha256,
    validate_gate_c_qualification_packet,
    validate_gate_c_restart_manifest,
)
from elder_protocol.factory_workers import (
    CodexWorkerAdapter,
    WorkerConformanceScenario,
)
from elder_protocol.governance import (
    finalize_checkpoint,
    finalize_delegation,
    resolve_authority_bindings,
)
from elder_protocol.io import load_json
from elder_protocol.knowledge import KnowledgeStore
from elder_protocol.orchestration import MultiAgentRuntime
from elder_protocol.protocol import validate_protocol
from tests._codex_support import DeterministicCodexRuntime
from tests._sf203_support import control_command
from tests.component.test_durable_dispatcher import (
    DurableDispatcherComponentTests,
)
from tests.component.test_run_controller import RunControllerComponentTests


LEASE_TOKEN = "gate-c-runtime-lease-token-with-adequate-length"
DELEGATION_ID = "product-one-delegation"
WORKSPACE_OWNER = "gate-c-worker-owner"


class GateCDeterministicRuntime(DeterministicCodexRuntime):
    def run_turn(
        self,
        thread_id: str,
        workspace: Path,
        *,
        command_id: str,
        command_type: str,
        prompt: str,
    ) -> dict[str, Any]:
        result = super().run_turn(
            thread_id,
            workspace,
            command_id=command_id,
            command_type=command_type,
            prompt=prompt,
        )
        (workspace / "RESULT.txt").write_text(
            "GATE-C-LIVE-PASS\n",
            encoding="utf-8",
        )
        return result


def git(repository: Path, *arguments: str) -> str:
    return subprocess.run(
        ["git", "-C", str(repository), *arguments],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    ).stdout.strip()


def gate_control(
    aggregate: dict[str, Any],
    binding: dict[str, Any],
    operation: str,
    *,
    index: int,
    payload: dict[str, Any] | None = None,
    at: str,
) -> dict[str, Any]:
    command = control_command(
        aggregate,
        binding,
        operation,
        index=index,
        payload=payload,
        at=at,
    )
    command["deadline_at"] = "2026-08-14T16:00:00+00:00"
    return command


def create_repository(root: Path) -> tuple[Path, str, dict[str, Any]]:
    repository = root / "product-one"
    repository.mkdir(parents=True)
    profile = DurableDispatcherComponentTests._profile()
    profile_path = repository / ".elder" / "project-profile.json"
    profile_path.parent.mkdir(parents=True)
    profile_path.write_text(
        json.dumps(profile, indent=2) + "\n",
        encoding="utf-8",
    )
    (repository / ".gitignore").write_text(
        ".factory/\n__pycache__/\n",
        encoding="utf-8",
    )
    (repository / "TASK.md").write_text(
        "Create RESULT.txt containing exactly GATE-C-LIVE-PASS followed by "
        "one newline. Do not stage or commit files.\n",
        encoding="utf-8",
    )
    (repository / "verify_result.py").write_text(
        "from pathlib import Path\n"
        "assert Path('RESULT.txt').read_text(encoding='utf-8') == "
        "'GATE-C-LIVE-PASS\\n'\n",
        encoding="utf-8",
    )
    runtime_source = repository / "src" / "component" / "runtime-source.md"
    runtime_source.parent.mkdir(parents=True)
    runtime_source.write_text(
        "Bounded Gate C runtime context.\n",
        encoding="utf-8",
    )
    git(repository, "init", "-b", "main")
    git(repository, "config", "user.email", "gate-c@elder.invalid")
    git(repository, "config", "user.name", "Elder Gate C")
    git(repository, "add", ".")
    git(repository, "commit", "-m", "test: establish Gate C fixture")
    return repository, git(repository, "rev-parse", "HEAD"), profile


def _manual_signal() -> dict[str, Any]:
    normalized = {
        "type": "work-request",
        "title": "Produce the Gate C result artifact",
        "description": "Execute the exact task in TASK.md and retain evidence.",
        "priority": "high",
        "labels": ["gate-c", "qualification"],
    }
    return {
        "version": "1.0.0",
        "signal_id": "signal-gate-c-001",
        "project_id": "product-one",
        "integration_id": "owner-inbox",
        "source": "manual",
        "source_reference": "manual:owner-inbox/gate-c-001",
        "source_event_id": "gate-c-001",
        "source_sequence": None,
        "idempotency_key": "gate-c-001",
        "occurred_at": "2026-08-13T19:30:00+00:00",
        "authentication": {
            "status": "verified",
            "method": "profile-role-binding",
            "principal_ref": "founder",
            "evidence_ref": "profile:product-one:founder",
            "verified_at": "2026-08-13T19:30:01+00:00",
        },
        "normalized": normalized,
        "payload_sha256": canonical_sha256(normalized),
    }


def initialize_operations(
    root: Path,
    repository: Path,
    *,
    runtime_lease_ref: str,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    database = root / "operations.db"
    FactoryOperationsBootstrap(database).initialize()
    registry = ProductFactoryRegistry(database)
    factory = registry.register(
        {
            "version": "1.0.0",
            "project_id": "product-one",
            "repository_root": str(repository.resolve()),
            "profile_path": ".elder/project-profile.json",
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [
                {
                    "id": "owner-inbox",
                    "kind": "manual",
                    "reference": "manual:owner-inbox",
                    "enabled": True,
                }
            ],
        },
        actor_identity_id="founder",
        at="2026-08-13T19:29:00+00:00",
    )
    factory = registry.activate(
        factory["product_factory"]["id"],
        expected_version=1,
        actor_identity_id="founder",
        at="2026-08-13T19:29:01+00:00",
    )
    intake = SignalIntake(database)
    intake.initialize()
    signal = intake.ingest(
        _manual_signal(),
        actor_identity_id="founder",
        received_at="2026-08-13T19:30:02+00:00",
    )
    ledger = WorkItemLedger(database)
    ledger.initialize()
    specification = DurableDispatcherComponentTests._specification()
    specification["objective"] = "Produce the exact Gate C result artifact."
    specification["scope"] = ["RESULT.txt", "verify_result.py"]
    specification["acceptance_criteria"] = [
        "RESULT.txt contains the exact requested content.",
        "verify_result.py exits successfully.",
    ]
    specification["source_links"] = [
        {
            "kind": "signal",
            "reference": "signal:signal-gate-c-001",
            "content_sha256": signal["signal"]["content_sha256"],
        }
    ]
    work_item = ledger.create_from_signal(
        "signal-gate-c-001",
        specification,
        actor_identity_id="founder",
        change_reason="Accept the bounded Gate C qualification issue.",
        at="2026-08-13T19:31:00+00:00",
    )
    helper = DurableDispatcherComponentTests(methodName="runTest")
    transitions = WorkItemTransitionEngine(database)
    transitions.initialize()
    submitted = transitions.apply(
        helper._transition_command(
            command_id="transition-command-submit-build-repair",
            trigger="submit",
            expected_version=1,
            actor_identity_id="example-agentic-product-planning-agent",
            role="planning-agent",
            mode="modify-only",
            resource="design-doc",
            action="modify",
            field_bindings={
                "revision_id": work_item["current_revision"]["id"],
                "evidence_plan": work_item["work_item"]["payload"][
                    "evidence_plan"
                ],
            },
            evidence_refs={},
            submitted_at="2026-08-13T19:32:00+00:00",
        ),
        at="2026-08-13T19:32:01+00:00",
    )
    queue_command = helper._transition_command(
            command_id="transition-command-queue-build-repair",
            trigger="queue",
            expected_version=2,
            actor_identity_id="example-agentic-product-executor",
            role="executor",
            mode="execute-bounded",
            resource="context-packet",
            action="execute",
            field_bindings={
                "revision_id": work_item["current_revision"]["id"],
            },
            evidence_refs={
                "validated work item revision": "evidence:gate-c-revision"
            },
            submitted_at="2026-08-13T19:33:00+00:00",
        )
    queue_command["authority"]["delegated_runtime_lease_ref"] = (
        f"lease:{runtime_lease_ref}"
    )
    queue_command["authority"]["request_sha256"] = (
        transition_authorization_request_sha256(queue_command)
    )
    queue_command["authority"]["result_sha256"] = (
        transition_authorization_result_sha256(queue_command["authority"])
    )
    queued = transitions.apply(
        queue_command,
        at="2026-08-13T19:33:01+00:00",
    )
    dispatcher = DurableDispatcher(database)
    dispatcher.initialize()
    submission = helper._submission(queued)
    command = submission["command"]
    command["submitted_at"] = "2026-08-13T19:33:02+00:00"
    command["expires_at"] = "2026-08-13T21:00:00+00:00"
    request = submission["adapter_request"]
    request["submitted_at"] = "2026-08-13T19:33:03+00:00"
    request["deadline_at"] = "2026-08-13T20:30:00+00:00"
    request["payload"]["command"] = copy.deepcopy(command)
    request["payload_sha256"] = canonical_sha256(request["payload"])
    submission["available_at"] = "2026-08-13T19:33:03+00:00"
    dispatch = dispatcher.submit(
        submission,
        at="2026-08-13T19:34:00+00:00",
    )
    dispatcher.claim_next(
        owner_id="gate-c-dispatcher",
        at="2026-08-13T19:34:01+00:00",
        lease_seconds=120,
    )
    dispatcher.begin_execution(
        dispatch["dispatch_id"],
        owner_id="gate-c-dispatcher",
        lease_generation=1,
        at="2026-08-13T19:34:02+00:00",
    )
    completed = dispatcher.record_response(
        dispatch["dispatch_id"],
        helper._response(
            submission["adapter_request"],
            disposition="accepted",
            responded_at="2026-08-13T19:34:03+00:00",
        ),
        owner_id="gate-c-dispatcher",
        lease_generation=1,
        at="2026-08-13T19:34:03+00:00",
    )
    return signal, work_item, completed


def initialize_runtime(
    root: Path,
    repository: Path,
    profile: dict[str, Any],
) -> tuple[MultiAgentRuntime, dict[str, Any], dict[str, Any]]:
    protocol = validate_protocol()
    fixture = load_json(
        ROOT / "tests" / "fixtures" / "p4_5a" / "fixture-a-low-risk.json"
    )
    parent = copy.deepcopy(fixture["parent_run"])
    parent.update(
        {
            "id": "product-one-parent-run",
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "identity_id": "founder",
            "context_packet_id": "product-one-parent-context",
            "deadline": "2026-08-14T18:00:00+00:00",
            "started_at": "2026-08-13T19:34:04+00:00",
        }
    )
    delegation = copy.deepcopy(fixture["delegation"])
    delegation.update(
        {
            "delegation_id": DELEGATION_ID,
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "parent_run_id": parent["id"],
            "assigned_identity_id": "example-agentic-product-executor",
            "deadline": "2026-08-14T17:00:00+00:00",
            "expires_at": "2026-08-14T17:30:00+00:00",
        }
    )
    delegation = finalize_delegation(delegation)
    child = copy.deepcopy(fixture["child_run"])
    child.update(
        {
            "id": "product-one-child-run",
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "identity_id": "example-agentic-product-executor",
            "parent_run_id": parent["id"],
            "delegation_id": delegation["delegation_id"],
            "context_packet_id": "product-one-delegated-context",
            "deadline": "2026-08-14T17:00:00+00:00",
            "started_at": "2026-08-13T19:34:05+00:00",
        }
    )
    bindings = resolve_authority_bindings(
        profile,
        protocol["role-registry"],
        protocol["authority-matrix"],
    )
    request = copy.deepcopy(fixture["context_request"])
    request.update(
        {
            "id": child["context_packet_id"],
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "agent_identity_id": child["identity_id"],
            "assembled_by": "example-agentic-product-planning-agent",
            "delegation_id": delegation["delegation_id"],
            "repository_sources": [
                {
                    "id": "runtime-source",
                    "location": "src/component/runtime-source.md",
                    "authority": "primary",
                    "required": True,
                }
            ],
            "graph_limit": 0,
            "memory_limit": 0,
        }
    )
    context = KnowledgeStore(
        repository / ".factory" / "unused-knowledge.db"
    ).assemble_context(
        request,
        base_dir=repository,
        delegation=delegation,
        parent_run=parent,
        authority_bindings=bindings,
        delegation_policy=protocol["delegation-policy"],
        profile=profile,
        role_registry=protocol["role-registry"],
        authority_matrix=protocol["authority-matrix"],
    )
    chain = {
        "parent": parent,
        "delegation": delegation,
        "child": child,
        "context": context,
        "bindings": bindings,
    }
    runtime = MultiAgentRuntime(
        root / "runtime.db",
        load_json(PROTOCOL_DIR / "multi-agent-runtime-policy.json"),
    )
    runtime.initialize()
    runtime.submit(
        parent_run=chain["parent"],
        delegation=chain["delegation"],
        child_run=chain["child"],
        context_packet=chain["context"],
        context_base_dir=repository,
        profile=profile,
        authority_bindings=chain["bindings"],
        delegation_policy=protocol["delegation-policy"],
        role_registry=protocol["role-registry"],
        authority_matrix=protocol["authority-matrix"],
        submitted_at="2026-08-13T19:34:06+00:00",
    )
    claim = runtime.claim(
        project_id="product-one",
        identity_id=chain["child"]["identity_id"],
        lease_seconds=900,
        at="2026-08-13T19:34:07+00:00",
        lease_token=LEASE_TOKEN,
    )
    return runtime, chain, claim


def create_run_controller(
    root: Path,
    *,
    runtime: MultiAgentRuntime,
    delegation_id: str = DELEGATION_ID,
) -> RunController:
    controller = RunController(
        root / "operations.db",
        repository_inspector=LocalRepositoryInspector(),
        coordination_inspector=RuntimeCoordinationInspector(
            runtime,
            delegation_id,
        ),
    )
    controller.initialize()
    return controller


def bind_and_prepare_workspace(
    root: Path,
    *,
    repository: Path,
    revision: str,
    runtime: MultiAgentRuntime,
    chain: dict[str, Any],
    claim: dict[str, Any],
    dispatch: dict[str, Any],
) -> tuple[
    RunController,
    WorkspaceLifecycleManager,
    dict[str, Any],
    dict[str, Any],
]:
    controller = create_run_controller(root, runtime=runtime)
    registry = ProductFactoryRegistry(root / "operations.db")
    product = registry.get("product-factory-product-one")
    work = WorkItemLedger(root / "operations.db").get(
        "work-item-build-repair"
    )
    helper = RunControllerComponentTests(methodName="runTest")
    submission = {
        "version": "1.0.0",
        "dispatch_id": dispatch["dispatch_id"],
        "dispatch_sha256": dispatch["content_sha256"],
        "work_item": {
            "id": work["work_item"]["id"],
            "record_version": work["work_item"]["record_version"],
            "content_sha256": work["work_item"]["content_sha256"],
            "revision_id": work["current_revision"]["id"],
            "revision_entity_sha256": work["current_revision"][
                "content_sha256"
            ],
            "revision_snapshot_sha256": work["current_revision"]["payload"][
                "snapshot_sha256"
            ],
        },
        "product_factory": {
            "id": product["product_factory"]["id"],
            "profile_sha256": product["profile_binding"]["content_sha256"],
            "repository_root": str(repository.resolve()),
            "repository_binding_sha256": canonical_sha256(
                product["repository_binding"]
            ),
            "worker_policy_sha256": canonical_sha256(
                product["worker_policy"]
            ),
        },
        "workspace_policy": helper._workspace_policy(product, repository),
        "context_packet": chain["context"],
        "parent_run": chain["parent"],
        "delegation": chain["delegation"],
        "child_run": chain["child"],
        "runtime_lease": claim["lease"],
        "authority_bindings": chain["bindings"],
        "source": {
            "repository_root": str(repository.resolve()),
            "revision": revision,
            "instruction_mode": "trusted-source-revision",
            "trusted_instruction_revision": revision,
        },
        "cleanup_policy": {
            "completed": "release",
            "cancelled": "release",
            "failed_or_lost": "state-dependent",
            "retain_evidence": True,
            "physical_delete": False,
        },
        "requested_at": "2026-08-13T19:35:00+00:00",
    }
    aggregate = controller.bind_start(
        submission,
        at="2026-08-13T19:35:01+00:00",
    )
    provision = helper._command(
        aggregate,
        ["workspace-provision"],
        suffix="gate-c-workspace-provision",
        payload={
            "repository": str(repository.resolve()),
            "base_revision": revision,
        },
        evidence_refs={},
        at="2026-08-13T19:36:00+00:00",
    )
    controller.apply(provision, at=provision["submitted_at"])
    manager = WorkspaceLifecycleManager(controller)
    prepared = manager.prepare(
        aggregate["run"]["id"],
        at="2026-08-13T19:36:01+00:00",
    )
    current = controller.get(aggregate["run"]["id"])
    ready = helper._command(
        current,
        ["workspace-ready"],
        suffix="gate-c-workspace-ready",
        payload={
            "path": current["initial_binding"]["workspace_path"],
            "isolation_mode": current["initial_binding"]["isolation_mode"],
        },
        evidence_refs={"workspace verification": prepared["evidence_ref"]},
        at="2026-08-13T19:37:00+00:00",
    )
    controller.apply(ready, at=ready["submitted_at"])
    lease = manager.acquire_lease(
        aggregate["run"]["id"],
        owner_id=WORKSPACE_OWNER,
        lease_seconds=900,
        at="2026-08-13T19:37:01+00:00",
    )
    binding = manager.workspace_binding(
        aggregate["run"]["id"],
        owner_id=WORKSPACE_OWNER,
        generation=lease["lease"]["generation"],
        at="2026-08-13T19:37:02+00:00",
    )
    return controller, manager, binding, aggregate


def pre_restart_phase(
    root: Path,
    *,
    live_codex: bool,
) -> dict[str, Any]:
    repository, revision, profile = create_repository(root)
    runtime, chain, claim = initialize_runtime(root, repository, profile)
    signal, work, dispatch = initialize_operations(
        root,
        repository,
        runtime_lease_ref=claim["lease"]["id"],
    )
    controller, manager, binding, aggregate = bind_and_prepare_workspace(
        root,
        repository=repository,
        revision=revision,
        runtime=runtime,
        chain=chain,
        claim=claim,
        dispatch=dispatch,
    )
    worker_runtime = None if live_codex else GateCDeterministicRuntime()
    adapter = CodexWorkerAdapter.for_sf202(
        root / "worker.db",
        workspace_binding=binding,
        runtime=worker_runtime,
    )
    session = DurableSessionController(
        root / "session.db",
        run_controller=controller,
        adapter=adapter,
        workspace_authority=manager,
        workspace_binding=binding,
        workspace_binding_at="2026-08-13T19:38:00+00:00",
    )
    session.initialize()
    run_id = aggregate["run"]["id"]
    start = gate_control(
        controller.get(run_id),
        binding,
        "start",
        index=800,
        at="2026-08-13T19:38:01+00:00",
    )
    session.submit(start)
    started = session.execute_once(
        owner_id="gate-c-controller-before",
        at=start["submitted_at"],
        lease_seconds=120,
    )
    if started is None or started["status"] != "succeeded":
        raise AssertionError(f"Gate C worker start failed: {started}")
    helper = RunControllerComponentTests(methodName="runTest")
    current = controller.get(run_id)
    start_run = helper._command(
        current,
        ["run-claim", "workspace-bind", "run-start"],
        suffix="gate-c-run-start",
        payload={
            "authority_ref": current["initial_binding"]["authority_ref"],
            "run_id": run_id,
            "worker_session_id": current["worker_session"]["id"],
        },
        evidence_refs={
            "active lease": current["initial_binding"]["runtime_lease_ref"]
        },
        at="2026-08-13T19:39:00+00:00",
    )
    pending = controller.prepare_work_item_start(
        start_run,
        at=start_run["submitted_at"],
    )
    controller._transitions.apply(
        pending["result"]["transition_command"],
        at="2026-08-13T19:39:01+00:00",
    )
    controller.confirm_work_item_start(
        start_run["command_id"],
        at="2026-08-13T19:39:02+00:00",
    )
    prompt = gate_control(
        controller.get(run_id),
        binding,
        "prompt",
        index=801,
        payload={
            "instruction": (
                "Read TASK.md and perform only that task. Run "
                f"'{sys.executable} verify_result.py' after writing the file. "
                "Do not stage or commit any file."
            )
        },
        at="2026-08-13T19:40:00+00:00",
    )
    session.submit(prompt)
    prompted = session.execute_once(
        owner_id="gate-c-controller-before",
        at=prompt["submitted_at"],
        lease_seconds=600,
    )
    if prompted is None or prompted["status"] != "succeeded":
        raise AssertionError(f"Gate C prompt failed: {prompted}")
    workspace = Path(binding["path"])
    if (workspace / "RESULT.txt").read_text(encoding="utf-8") != (
        "GATE-C-LIVE-PASS\n"
    ):
        raise AssertionError("Gate C worker did not produce the exact result.")
    current = controller.get(run_id)
    prompt_record = session.get(prompt["control_id"])
    external_ref = current["worker_session"]["payload"][
        "external_session_ref"
    ]
    qualification_id = "gate-c-" + canonical_sha256(
        str(root.resolve())
    )[:24]
    manifest = finalize_gate_c_record(
        {
            "version": "1.0.0",
            "qualification_id": qualification_id,
            "phase": "pre-restart",
            "process_id": os.getpid(),
            "boot_id": f"gate-c-boot-{uuid.uuid4().hex}",
            "root": str(root.resolve()),
            "operations_store": str((root / "operations.db").resolve()),
            "session_store": str((root / "session.db").resolve()),
            "worker_store": str((root / "worker.db").resolve()),
            "recovery_store": str((root / "recovery.db").resolve()),
            "repository": str(repository.resolve()),
            "workspace": str(workspace.resolve()),
            "project_id": "product-one",
            "signal_id": signal["signal"]["id"],
            "work_item_id": work["work_item"]["id"],
            "dispatch_id": dispatch["dispatch_id"],
            "run_id": run_id,
            "workspace_id": current["workspace"]["id"],
            "worker_session_id": current["worker_session"]["id"],
            "session_generation": current["worker_session"]["payload"][
                "session_generation"
            ],
            "start_control_id": start["control_id"],
            "prompt_control_id": prompt["control_id"],
            "prompt_control_sha256": prompt_record["content_sha256"],
            "prompt_response_sha256": prompt_record["result"][
                "send_response_sha256"
            ],
            "external_session_ref_sha256": canonical_sha256(external_ref),
            "baseline_revision": revision,
            "recorded_at": "2026-08-13T19:40:01+00:00",
        }
    )
    from elder_protocol.factory_operations import validate_gate_c_restart_manifest

    validate_gate_c_restart_manifest(manifest)
    path = root / "restart-manifest.json"
    path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


def _runtime_inputs() -> dict[str, Any]:
    protocol = validate_protocol()
    return {
        "delegation_policy": protocol["delegation-policy"],
        "role_registry": protocol["role-registry"],
        "authority_matrix": protocol["authority-matrix"],
    }


def _artifact_reference(
    *,
    run_id: str,
    reference_id: str,
    artifact_sha256: str,
    artifact_type: str,
    provenance_ref: str,
    recorded_at: str,
) -> dict[str, Any]:
    record = {
        "version": "1.0.0",
        "id": reference_id,
        "run_id": run_id,
        "artifact_sha256": artifact_sha256,
        "artifact_type": artifact_type,
        "provenance_ref": provenance_ref,
        "status": "verified",
        "target_locator": None,
        "session_generation": 1,
        "recorded_at": recorded_at,
        "content_sha256": None,
    }
    record["content_sha256"] = record_content_sha256(record)
    return record


def _persisted_workspace_binding(
    manager: WorkspaceLifecycleManager,
    aggregate: dict[str, Any],
) -> dict[str, Any]:
    manifest_path, _ = manager._runtime_paths(aggregate)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    lease = manifest["lease"]
    inspection = manifest["latest_inspection"]
    if lease is None or inspection is None:
        raise AssertionError(
            "Gate C workspace manifest has no durable lease or inspection."
        )
    return {
        "workspace_id": aggregate["workspace"]["id"],
        "run_id": aggregate["run"]["id"],
        "path": manifest["workspace_path"],
        "lease_owner": lease["owner_id"],
        "lease_generation": lease["generation"],
        "sandbox": manifest["sandbox"],
        "sandbox_sha256": manifest["sandbox_sha256"],
        "inspection_sha256": inspection["content_sha256"],
    }


def _prompt_effect_count(worker_store: Path) -> int:
    with sqlite3.connect(worker_store) as connection:
        row = connection.execute(
            """
            SELECT COALESCE(SUM(effect_count), 0)
            FROM receipts
            WHERE operation = 'send'
            """
        ).fetchone()
    return int(row[0])


def _transition_work_item_to_completed(
    database: Path,
    *,
    runtime_lease_id: str,
    evidence_sha256: str,
) -> dict[str, Any]:
    helper = DurableDispatcherComponentTests(methodName="runTest")
    transitions = WorkItemTransitionEngine(database)
    transitions.initialize()
    validation = helper._transition_command(
        command_id="transition-command-gate-c-request-validation",
        trigger="request-validation",
        expected_version=4,
        actor_identity_id="example-agentic-product-executor",
        role="executor",
        mode="execute-bounded",
        resource="implementation",
        action="execute",
        field_bindings={},
        evidence_refs={
            "run evidence bundle": f"evidence:gate-c/{evidence_sha256}"
        },
        submitted_at="2026-08-13T19:47:00+00:00",
    )
    validation["authority"]["delegated_runtime_lease_ref"] = (
        f"lease:{runtime_lease_id}"
    )
    validation["authority"]["request_sha256"] = (
        transition_authorization_request_sha256(validation)
    )
    validation["authority"]["result_sha256"] = (
        transition_authorization_result_sha256(validation["authority"])
    )
    validation_result = transitions.apply(
        validation,
        at="2026-08-13T19:47:01+00:00",
    )
    if not validation_result["decision"]["accepted"]:
        raise AssertionError(
            f"Gate C validation transition failed: {validation_result}"
        )
    completion = helper._transition_command(
        command_id="transition-command-gate-c-accept-outcome",
        trigger="accept-outcome",
        expected_version=5,
        actor_identity_id="founder",
        role="product-owner",
        mode="human-approval",
        resource="approval-decision",
        action="approve",
        field_bindings={},
        evidence_refs={
            "validated evidence": f"evidence:gate-c/{evidence_sha256}",
            "outcome record": "outcome:gate-c-qualified-local-run",
        },
        submitted_at="2026-08-13T19:47:02+00:00",
    )
    completion["authority"]["delegated_runtime_lease_ref"] = None
    completion["authority"]["request_sha256"] = (
        transition_authorization_request_sha256(completion)
    )
    completion["authority"]["result_sha256"] = (
        transition_authorization_result_sha256(completion["authority"])
    )
    completion_result = transitions.apply(
        completion,
        at="2026-08-13T19:47:03+00:00",
    )
    if not completion_result["decision"]["accepted"]:
        raise AssertionError(
            f"Gate C completion transition failed: {completion_result}"
        )
    return WorkItemLedger(database).get("work-item-build-repair")


def _post_restart_phase_unlocked(
    root: Path,
    *,
    live_codex: bool,
    terminated: bool = True,
) -> dict[str, Any]:
    manifest = json.loads(
        (root / "restart-manifest.json").read_text(encoding="utf-8")
    )
    validate_gate_c_restart_manifest(manifest)
    repository = Path(manifest["repository"])
    workspace = Path(manifest["workspace"])
    runtime = MultiAgentRuntime(
        root / "runtime.db",
        load_json(PROTOCOL_DIR / "multi-agent-runtime-policy.json"),
    )
    runtime.initialize()
    controller = create_run_controller(root, runtime=runtime)
    run_id = manifest["run_id"]
    manager = WorkspaceLifecycleManager(controller)
    aggregate = controller.get(run_id)
    binding = _persisted_workspace_binding(manager, aggregate)
    manager.validate_workspace_binding(
        binding,
        at="2026-08-13T19:41:00+00:00",
    )
    worker_runtime = None if live_codex else GateCDeterministicRuntime()
    adapter = CodexWorkerAdapter.for_sf202(
        root / "worker.db",
        workspace_binding=binding,
        runtime=worker_runtime,
    )
    session = DurableSessionController(
        root / "session.db",
        run_controller=controller,
        adapter=adapter,
        workspace_authority=manager,
        workspace_binding=binding,
        workspace_binding_at="2026-08-13T19:41:00+00:00",
    )
    session.initialize()
    reopened = controller.get(run_id)
    external_ref = reopened["worker_session"]["payload"][
        "external_session_ref"
    ]
    if canonical_sha256(external_ref) != manifest[
        "external_session_ref_sha256"
    ]:
        raise AssertionError("Gate C Codex thread identity changed after restart.")

    checkpoint = finalize_checkpoint(
        {
            "version": "0.5.1",
            "id": "gate-c-final-checkpoint",
            "project_id": reopened["run"]["project_id"],
            "delegation_id": reopened["initial_binding"][
                "elder_delegation_id"
            ],
            "run_id": reopened["initial_binding"]["elder_child_run_id"],
            "sequence": 1,
            "action_sequence": 0,
            "status": "running",
            "completed_scope": [],
            "remaining_scope": ["src/component"],
            "evidence_refs": [
                f"worker-response:{manifest['prompt_response_sha256']}"
            ],
            "budget_consumed": {
                "token_limit": 0,
                "cost_limit_usd": 0,
                "tool_call_limit": 0,
                "elapsed_seconds_limit": 0,
            },
            "previous_checkpoint_sha256": None,
            "created_at": "2026-08-13T19:42:00+00:00",
        }
    )
    runtime.record_checkpoint(
        checkpoint,
        lease_token=LEASE_TOKEN,
        **_runtime_inputs(),
    )
    checkpoint_control = gate_control(
        controller.get(run_id),
        binding,
        "checkpoint",
        index=802,
        payload={
            "checkpoint_id": checkpoint["id"],
            "checkpoint_sha256": checkpoint["content_sha256"],
        },
        at="2026-08-13T19:42:01+00:00",
    )
    session.submit(checkpoint_control)
    checkpoint_result = session.execute_once(
        owner_id="gate-c-controller-after",
        at=checkpoint_control["submitted_at"],
        lease_seconds=120,
    )
    if checkpoint_result is None or checkpoint_result["status"] != "succeeded":
        raise AssertionError(
            f"Gate C checkpoint control failed: {checkpoint_result}"
        )

    scenario = WorkerConformanceScenario(
        project_id=reopened["run"]["project_id"],
        work_item_id=reopened["initial_binding"]["work_item_id"],
        run_id=run_id,
        worker_session_id=reopened["worker_session"]["id"],
        session_generation=1,
        workspace_id=reopened["workspace"]["id"],
        authority_ref=reopened["initial_binding"]["authority_ref"],
        context_sha256=reopened["initial_binding"][
            "context_packet_sha256"
        ],
        checkpoint_id=checkpoint["id"],
        checkpoint_sha256=checkpoint["content_sha256"],
        correlation_id=reopened["run"]["correlation_id"],
        causation_id=checkpoint_control["control_id"],
        timestamp="2026-08-13T19:43:00+00:00",
        deadline="2026-08-13T20:00:00+00:00",
    )
    evidence_response = adapter.execute(
        scenario.request(
            "collect-evidence",
            {
                "session": {
                    "worker_session_id": reopened["worker_session"]["id"],
                    "session_generation": 1,
                }
            },
            index=803,
            idempotency_key=None,
        )
    )
    evidence_bundle = evidence_response["result"]["evidence_bundle"]
    evidence_sha256 = canonical_sha256(evidence_bundle)
    evidence_status = (
        "verified"
        if evidence_bundle["verdict"] == "pass"
        else "rejected"
    )

    test_command = [sys.executable, "verify_result.py"]
    tested = subprocess.run(
        test_command,
        cwd=workspace,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    status_lines = [
        line
        for line in git(workspace, "status", "--porcelain=v1").splitlines()
        if line
    ]
    changed_paths = sorted(line[3:] for line in status_lines)
    staged = any(line[0] != " " and not line.startswith("??") for line in status_lines)
    committed = git(workspace, "rev-parse", "HEAD") != manifest[
        "baseline_revision"
    ]
    diff_result = subprocess.run(
        ["git", "-C", str(workspace), "diff", "--no-index", "--", "NUL", "RESULT.txt"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if diff_result.returncode not in {0, 1}:
        raise AssertionError(
            f"Gate C diff collection failed: {diff_result.stderr}"
        )
    diff_sha256 = canonical_sha256(diff_result.stdout)

    worker_observation = {
        "id": "gate-c-worker-checkpoint-observation",
        "checkpoint_id": checkpoint["id"],
        "checkpoint_sha256": checkpoint["content_sha256"],
    }
    current = controller.get(run_id)
    checkpoint_reference = {
        "version": "1.0.0",
        "id": "gate-c-checkpoint-reference",
        "run_id": run_id,
        "worker_session_id": current["worker_session"]["id"],
        "elder_run_id": current["initial_binding"]["elder_child_run_id"],
        "elder_run_sha256": current["initial_binding"][
            "elder_child_run_sha256"
        ],
        "project_id": current["run"]["project_id"],
        "delegation_id": current["initial_binding"]["elder_delegation_id"],
        "session_generation": 1,
        "checkpoint_id": checkpoint["id"],
        "checkpoint_sha256": checkpoint["content_sha256"],
        "adapter_cursor": canonical_sha256(
            checkpoint_result["result"]["cursor"]
        ),
        "observation_sequence": 1,
        "checkpoint_sequence": 1,
        "previous_checkpoint_sha256": None,
        "worker_observation_id": worker_observation["id"],
        "worker_observation_sha256": canonical_sha256(worker_observation),
        "recorded_at": "2026-08-13T19:44:00+00:00",
        "content_sha256": None,
    }
    checkpoint_reference["content_sha256"] = record_content_sha256(
        checkpoint_reference
    )
    helper = RunControllerComponentTests(methodName="runTest")
    checkpoint_record = controller.record_checkpoint_reference(
        helper._command(
            current,
            ["checkpoint-reference"],
            suffix="gate-c-checkpoint-reference",
            payload={},
            evidence_refs={},
            at=checkpoint_reference["recorded_at"],
        ),
        checkpoint_reference,
        checkpoint=checkpoint,
        worker_observation=worker_observation,
        at=checkpoint_reference["recorded_at"],
    )
    if checkpoint_record["status"] != "applied":
        raise AssertionError(
            f"Gate C checkpoint reference failed: {checkpoint_record}"
        )

    artifact_specs = [
        (
            "gate-c-diff-reference",
            diff_sha256,
            "diff",
            "git-diff:gate-c-result",
            "2026-08-13T19:44:01+00:00",
        ),
        (
            "gate-c-test-reference",
            canonical_sha256(
                {
                    "command": test_command,
                    "exit_code": tested.returncode,
                    "stdout": tested.stdout,
                    "stderr": tested.stderr,
                }
            ),
            "test-evidence",
            "test-result:gate-c-verify-result",
            "2026-08-13T19:44:02+00:00",
        ),
        (
            "gate-c-evidence-reference",
            evidence_sha256,
            "evidence-bundle",
            f"worker-evidence:{evidence_bundle['id']}",
            "2026-08-13T19:44:03+00:00",
        ),
    ]
    artifact_references: dict[str, dict[str, Any]] = {}
    for reference_id, digest, artifact_type, provenance, recorded_at in artifact_specs:
        reference = _artifact_reference(
            run_id=run_id,
            reference_id=reference_id,
            artifact_sha256=digest,
            artifact_type=artifact_type,
            provenance_ref=provenance,
            recorded_at=recorded_at,
        )
        current = controller.get(run_id)
        result = controller.record_artifact_reference(
            helper._command(
                current,
                ["artifact-reference"],
                suffix=reference_id,
                payload={},
                evidence_refs={},
                at=recorded_at,
            ),
            reference,
            at=recorded_at,
        )
        if result["status"] != "applied":
            raise AssertionError(
                f"Gate C artifact reference failed: {result}"
            )
        artifact_references[artifact_type] = reference

    current = controller.get(run_id)
    validated = controller.apply(
        helper._command(
            current,
            ["run-validate", "worker-session-complete"],
            suffix="gate-c-run-validate",
            payload={},
            evidence_refs={
                "checkpoint": f"checkpoint:{checkpoint['id']}",
                "evidence records": f"evidence:{evidence_sha256}",
                "final checkpoint": (
                    f"checkpoint-reference:{checkpoint_reference['id']}"
                ),
            },
            at="2026-08-13T19:45:00+00:00",
        ),
        at="2026-08-13T19:45:00+00:00",
    )
    if validated["status"] != "applied":
        raise AssertionError(f"Gate C run validation failed: {validated}")
    current = controller.get(run_id)
    completed = controller.apply(
        helper._command(
            current,
            ["run-complete"],
            suffix="gate-c-run-complete",
            payload={},
            evidence_refs={
                "validated evidence bundle": (
                    f"evidence-bundle:{evidence_bundle['id']}"
                )
            },
            at="2026-08-13T19:46:00+00:00",
        ),
        at="2026-08-13T19:46:00+00:00",
    )
    if completed["status"] != "applied":
        raise AssertionError(f"Gate C run completion failed: {completed}")
    final_run = controller.get(run_id)
    final_work_item = _transition_work_item_to_completed(
        root / "operations.db",
        runtime_lease_id=reopened["initial_binding"][
            "runtime_lease_ref"
        ].removeprefix("lease:"),
        evidence_sha256=evidence_sha256,
    )

    recovery = WorkerRecoveryCoordinator(
        root / "recovery.db",
        session_controller=session,
        workspace_manager=manager,
    )
    recovery.initialize()
    recovery_status = recovery.status()
    open_cases = sum(
        recovery_status["counts"][name]
        for name in ("pending", "reconciling", "owner-required", "contradictory")
    )
    orphan_count = sum(recovery_status["orphan_counts"].values())
    capabilities = adapter.capabilities().as_dict()
    provider = evidence_bundle.get("provider", {})
    cli_version = provider.get(
        "cli_version",
        capabilities["implementation_version"],
    )
    evidence_reference = artifact_references["evidence-bundle"]
    packet = finalize_gate_c_record(
        {
            "version": "1.0.0",
            "qualification_id": manifest["qualification_id"],
            "gate": "C",
            "verdict": "pass" if live_codex else "fail",
            "live_codex": live_codex,
            "project_id": manifest["project_id"],
            "signal": {
                "id": manifest["signal_id"],
                "content_sha256": SignalIntake(
                    root / "operations.db"
                ).get(manifest["signal_id"])["signal"]["content_sha256"],
            },
            "work_item": {
                "id": final_work_item["work_item"]["id"],
                "content_sha256": final_work_item["work_item"][
                    "content_sha256"
                ],
                "status": final_work_item["work_item"]["status"],
            },
            "dispatch": {
                "id": manifest["dispatch_id"],
                "content_sha256": DurableDispatcher(
                    root / "operations.db"
                ).get(manifest["dispatch_id"])["content_sha256"],
            },
            "run": {
                "id": final_run["run"]["id"],
                "content_sha256": final_run["run"]["content_sha256"],
                "status": final_run["run"]["status"],
            },
            "workspace": {
                "id": final_run["workspace"]["id"],
                "content_sha256": final_run["workspace"]["content_sha256"],
                "status": final_run["workspace"]["status"],
                "path_sha256": canonical_sha256(str(workspace.resolve())),
                "sandbox_sha256": binding["sandbox_sha256"],
            },
            "worker": {
                "adapter_id": capabilities["adapter_id"],
                "cli_version": cli_version,
                "external_session_ref_sha256": canonical_sha256(external_ref),
                "thread_continuity_sha256": canonical_sha256(
                    [
                        manifest["external_session_ref_sha256"],
                        canonical_sha256(external_ref),
                    ]
                ),
                "prompt_effect_count": _prompt_effect_count(
                    root / "worker.db"
                ),
                "prompt_response_sha256": manifest[
                    "prompt_response_sha256"
                ],
            },
            "restart": {
                "before_process_id": manifest["process_id"],
                "before_boot_id": manifest["boot_id"],
                "after_process_id": os.getpid(),
                "after_boot_id": f"gate-c-boot-{uuid.uuid4().hex}",
                "terminated": terminated,
                "manifest_sha256": manifest["content_sha256"],
            },
            "git": {
                "baseline_revision": manifest["baseline_revision"],
                "changed_paths": changed_paths,
                "diff_sha256": diff_sha256,
                "staged": staged,
                "committed": committed,
            },
            "test": {
                "command_sha256": canonical_sha256(test_command),
                "exit_code": tested.returncode,
                "stdout_sha256": canonical_sha256(tested.stdout),
                "stderr_sha256": canonical_sha256(tested.stderr),
            },
            "checkpoint": {
                "id": checkpoint["id"],
                "content_sha256": checkpoint["content_sha256"],
                "reference_sha256": checkpoint_reference["content_sha256"],
            },
            "evidence_bundle": {
                "artifact_ref_id": evidence_reference["id"],
                "artifact_sha256": evidence_reference["artifact_sha256"],
                "reference_sha256": evidence_reference["content_sha256"],
                "status": evidence_status,
            },
            "recovery": {
                "open_case_count": open_cases,
                "orphan_count": orphan_count,
            },
            "forbidden_authority": list(GATE_C_FORBIDDEN_AUTHORITY),
            "recorded_at": "2026-08-13T19:48:00+00:00",
        }
    )
    validate_gate_c_qualification_packet(packet)
    (root / "gate-c-qualification.json").write_text(
        json.dumps(packet, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return packet


def post_restart_phase(
    root: Path,
    *,
    live_codex: bool,
    terminated: bool = True,
) -> dict[str, Any]:
    claim_path = root / "gate-c-finalization.claim"
    packet_path = root / "gate-c-qualification.json"
    try:
        descriptor = os.open(
            claim_path,
            os.O_CREAT | os.O_EXCL | os.O_WRONLY,
        )
    except FileExistsError:
        deadline = time.monotonic() + 600
        while time.monotonic() < deadline:
            if packet_path.is_file():
                try:
                    packet = json.loads(
                        packet_path.read_text(encoding="utf-8")
                    )
                    validate_gate_c_qualification_packet(packet)
                except (OSError, json.JSONDecodeError):
                    time.sleep(0.05)
                    continue
                if packet["live_codex"] is not live_codex:
                    raise AssertionError(
                        "Gate C finalization mode changed across processes."
                    )
                return packet
            time.sleep(0.05)
        raise TimeoutError(
            "Gate C finalization claim did not produce a packet."
        )
    else:
        with os.fdopen(descriptor, "w", encoding="utf-8") as claim:
            claim.write(f"{os.getpid()}\n")
        return _post_restart_phase_unlocked(
            root,
            live_codex=live_codex,
            terminated=terminated,
        )
