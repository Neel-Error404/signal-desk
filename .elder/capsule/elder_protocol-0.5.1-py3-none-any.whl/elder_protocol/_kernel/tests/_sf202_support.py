from __future__ import annotations

import copy
import os
import subprocess
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations.run_controller import (
    FACTORY_CONTRACT_PATH,
    record_content_sha256,
)
from elder_protocol.io import load_json


PYTHON = Path(
    os.environ.get(
        "ELDER_TEST_PYTHON",
        r"C:\Users\neela\AppData\Local\Programs\Python\Python313\python.exe",
    )
)


def git(repository: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", "-C", str(repository), *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )


def initialize_repository(
    repository: Path,
    *,
    agents_text: str = "# Trusted instructions\n",
    gitignore: str = ".factory/\nnode_modules/\n__pycache__/\n",
) -> str:
    repository.mkdir(parents=True)
    git(repository, "init", "-b", "main")
    git(repository, "config", "user.email", "sf202@example.invalid")
    git(repository, "config", "user.name", "SF-202 Fixture")
    (repository / "AGENTS.md").write_text(agents_text, encoding="utf-8")
    (repository / ".gitignore").write_text(gitignore, encoding="utf-8")
    (repository / "README.md").write_text("fixture\n", encoding="utf-8")
    git(repository, "add", ".")
    git(repository, "commit", "-m", "fixture baseline")
    return git(repository, "rev-parse", "HEAD").stdout.strip()


def commit_all(repository: Path, message: str) -> str:
    git(repository, "add", ".")
    git(repository, "commit", "-m", message)
    return git(repository, "rev-parse", "HEAD").stdout.strip()


def workspace_aggregate(
    repository: Path,
    revision: str,
    *,
    workspace_status: str = "provisioning",
    instruction_mode: str = "trusted-source-revision",
    trusted_instruction_revision: str | None = None,
    suffix: str = "abcdef123456",
) -> dict[str, Any]:
    contract = load_json(FACTORY_CONTRACT_PATH)
    execution_key = f"sf202-fixture-{suffix}"
    run_id = f"run-{'1' * 20}{suffix}"
    workspace_id = f"workspace-{'2' * 20}{suffix}"
    workspace_path = (
        repository
        / contract["workspace"]["state_root"]
        / contract["workspace"]["worktrees"]
        / execution_key
    ).resolve()
    initial = {
        "run_id": run_id,
        "workspace_id": workspace_id,
        "repository_root": str(repository.resolve()),
        "factory_contract_sha256": canonical_sha256(contract),
        "git_policy_sha256": canonical_sha256(contract["git"]),
        "workspace_policy_sha256": canonical_sha256(contract["workspace"]),
        "base_revision": revision,
        "source_revision": revision,
        "branch": f"{contract['git']['work_branch_prefix']}{execution_key}",
        "workspace_path": str(workspace_path),
        "isolation_mode": "planned-git-worktree",
        "instruction_mode": instruction_mode,
        "trusted_instruction_revision": (
            trusted_instruction_revision or revision
        ),
        "content_sha256": None,
    }
    initial["content_sha256"] = record_content_sha256(initial)
    return {
        "initial_binding": initial,
        "run": {"id": run_id},
        "workspace": {
            "id": workspace_id,
            "status": workspace_status,
        },
        "worker_session": {
            "id": f"worker-session-{'3' * 20}{suffix}",
            "status": "prepared",
        },
    }


class AggregateController:
    def __init__(self, aggregate: dict[str, Any]):
        self.aggregate = copy.deepcopy(aggregate)

    def get(self, run_id: str) -> dict[str, Any]:
        if self.aggregate["run"]["id"] != run_id:
            raise KeyError(run_id)
        return copy.deepcopy(self.aggregate)

    @contextmanager
    def locked_get(self, run_id: str) -> Iterator[dict[str, Any]]:
        yield self.get(run_id)

    def set_workspace_status(self, status: str) -> None:
        self.aggregate["workspace"]["status"] = status

    def set_worker_session_status(self, status: str) -> None:
        self.aggregate["worker_session"]["status"] = status
