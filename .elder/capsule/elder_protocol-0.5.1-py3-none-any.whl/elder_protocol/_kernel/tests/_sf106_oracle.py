from __future__ import annotations

import copy
import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Any

from elder_protocol.factory_operations.journal_store import (
    JournalInitializer,
    JournalRecorder,
)
from elder_protocol.factory_operations.operations_store import (
    operations_connection,
)
from elder_protocol.schema_validation import validate_against_schema


ROOT = Path(__file__).resolve().parents[1]
GOLDEN_ROOT = ROOT / "tests" / "fixtures" / "sf106" / "golden"
FIXTURE_ROOT = GOLDEN_ROOT / "composite-all-sources"
SOURCE_REGISTRY_PATH = (
    ROOT / "factory" / "operations" / "journal-source-registry.json"
)

PROJECTIONS = (
    "products",
    "signals",
    "work-items",
    "transitions",
    "commands",
    "runs",
    "timeline",
)


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def sha256(value: Any) -> str:
    return hashlib.sha256(
        canonical_json(value).encode("utf-8")
    ).hexdigest()


def _document_digest(document: dict[str, Any]) -> str:
    return sha256(
        {
            key: value
            for key, value in document.items()
            if key != "content_sha256"
        }
    )


def _find(value: Any, names: tuple[str, ...]) -> Any | None:
    if isinstance(value, dict):
        for name in names:
            if value.get(name) is not None:
                return value[name]
        for nested in value.values():
            found = _find(nested, names)
            if found is not None:
                return found
    elif isinstance(value, list):
        for nested in value:
            found = _find(nested, names)
            if found is not None:
                return found
    return None


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _source_registry() -> dict[str, dict[str, Any]]:
    registry = _load(SOURCE_REGISTRY_PATH)
    return {source["id"]: source for source in registry["sources"]}


def _fixture_files() -> dict[str, Path]:
    return {
        "source-rows.json": FIXTURE_ROOT / "source-rows.json",
        "journal-entries.json": FIXTURE_ROOT / "journal-entries.json",
        "expected-products.json": FIXTURE_ROOT / "expected-products.json",
        "expected-signals.json": FIXTURE_ROOT / "expected-signals.json",
        "expected-work-items.json": FIXTURE_ROOT / "expected-work-items.json",
        "expected-transitions.json": FIXTURE_ROOT / "expected-transitions.json",
        "expected-commands.json": FIXTURE_ROOT / "expected-commands.json",
        "expected-runs.json": FIXTURE_ROOT / "expected-runs.json",
        "expected-timeline.json": FIXTURE_ROOT / "expected-timeline.json",
        "expected-public-events.json": FIXTURE_ROOT / "expected-public-events.json",
    }


def validate_fixture(
    *,
    fixture_root: Path = FIXTURE_ROOT,
    manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    manifest_path = fixture_root / "manifest.json"
    manifest = copy.deepcopy(manifest or _load(manifest_path))
    validate_against_schema(
        manifest,
        "fixture-manifest.schema.json",
        label="SF-106 golden fixture manifest",
        schema_root=GOLDEN_ROOT,
    )
    if manifest["authored_by"] == manifest["independently_reviewed_by"]:
        raise ValueError(
            "SF-106 golden fixture author and reviewer must be distinct."
        )
    files = _fixture_files()
    for name, metadata in manifest["files"].items():
        path = files.get(name)
        if path is None:
            raise ValueError(f"Manifest references an unknown fixture file: {name}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != metadata["sha256"]:
            raise ValueError(f"Golden fixture digest drift: {name}.")
    return manifest


def load_fixture() -> dict[str, Any]:
    manifest = validate_fixture()
    source_rows = _load(FIXTURE_ROOT / "source-rows.json")
    entry_specs = _load(FIXTURE_ROOT / "journal-entries.json")
    expected = {
        projection_id: _load(
            FIXTURE_ROOT / f"expected-{projection_id}.json"
        )
        for projection_id in PROJECTIONS[:-1]
    }
    expected["timeline"] = _load(FIXTURE_ROOT / "expected-timeline.json")
    expected["public-events"] = _load(
        FIXTURE_ROOT / "expected-public-events.json"
    )
    return {
        "manifest": manifest,
        "source_rows": source_rows,
        "entry_specs": entry_specs,
        "expected": expected,
    }


def _source_identity(
    spec: dict[str, Any],
    source: dict[str, Any],
) -> dict[str, Any]:
    record = spec["record"]
    parents = spec["parent_ids"]
    identity: dict[str, Any] = {}
    for field in source["source_identity"]:
        if field == "record_version":
            identity[field] = spec["subject_version"]
        elif field in parents:
            identity[field] = parents[field]
        elif field in record:
            identity[field] = record[field]
        elif field == "signal_id":
            identity[field] = spec["subject_id"]
        elif field == "work_item_id":
            identity[field] = spec["subject_id"]
        elif field == "transition_id":
            identity[field] = spec["subject_id"]
        elif field == "dispatch_id":
            identity[field] = spec["subject_id"]
        elif field == "run_id":
            identity[field] = spec["subject_id"]
        elif field == "worker_session_id":
            identity[field] = spec["subject_id"]
        elif field == "workspace_id":
            identity[field] = spec["subject_id"]
        elif field == "id":
            identity[field] = spec["subject_id"]
        elif field.endswith("_version"):
            identity[field] = spec["subject_version"]
        else:
            identity[field] = spec["subject_id"]
    return identity


def expand_entries(fixture: dict[str, Any]) -> list[dict[str, Any]]:
    sources = _source_registry()
    source_rows = {
        item["source_row_ref"]: item for item in fixture["source_rows"]
    }
    previous: str | None = None
    entries: list[dict[str, Any]] = []
    for spec in fixture["entry_specs"]:
        source = sources[spec["source_registry_id"]]
        source_row = source_rows[spec["source_row_ref"]]
        record = copy.deepcopy(spec["record"])
        parent_ids = copy.deepcopy(spec["parent_ids"])
        record_sha256 = sha256(record)
        entry = {
            "version": "1.0.0",
            "stream_id": "factory-operations",
            "generation": 1,
            "sequence": spec["sequence"],
            "entry_id": f"journal-entry-sf106-{spec['sequence']:02d}",
            "previous_entry_sha256": previous,
            "entry_sha256": "0" * 64,
            "transaction_id": spec["transaction_id"],
            "transaction_position": spec["transaction_position"],
            "transaction_fact_count": spec["transaction_fact_count"],
            "source_append_order": source["append_order"],
            "coverage_branch_id": "golden.sf106.composite",
            "mutation_identity_sha256": sha256(
                {
                    "fixture_id": fixture["manifest"]["fixture_id"],
                    "transaction_id": spec["transaction_id"],
                    "sequence": spec["sequence"],
                }
            ),
            "fact_type": source["fact_type"],
            "project_id": spec["project_id"],
            "subject_type": source["fact_type"],
            "subject_id": spec["subject_id"],
            "subject_version": spec["subject_version"],
            "operation": spec["operation"],
            "occurred_at": spec["occurred_at"],
            "recorded_at": spec["recorded_at"],
            "source_actor": {
                "identity_id": "golden-source-author",
                "kind": "human",
            },
            "recorded_by": {
                "identity_id": "factory-journal",
                "kind": "service",
            },
            "source": {
                "plane": "factory-operations",
                "component": source["component"],
                "reference": (
                    f"golden:{source['table']}:{canonical_json(_source_identity(spec, source))}"
                ),
            },
            "correlation_id": spec["correlation_id"],
            "causation_id": spec["causation_id"],
            "idempotency_key": spec["idempotency_key"],
            "redaction": {
                "classification": "internal",
                "redacted_fields": [],
            },
            "source_record": {
                "source_registry_id": source["id"],
                "table": source["table"],
                "key": copy.deepcopy(source_row["key"]),
                "record_version": spec["subject_version"],
                "record_sha256": record_sha256,
                "row_sha256": sha256(source_row["row"]),
            },
            "projection_document_sha256": sha256(
                {
                    "fact_type": source["fact_type"],
                    "fact_version": source["fact_version"],
                    "parent_ids": parent_ids,
                    "record": record,
                    "record_sha256": record_sha256,
                }
            ),
            "projection_document": {
                "fact_type": source["fact_type"],
                "fact_version": source["fact_version"],
                "parent_ids": parent_ids,
                "record": record,
                "record_sha256": record_sha256,
            },
            "extensions": {},
        }
        entry["entry_sha256"] = sha256(
            {
                key: value
                for key, value in entry.items()
                if key != "entry_sha256"
            }
        )
        previous = entry["entry_sha256"]
        entries.append(entry)
    return entries


def _subject(
    projection_id: str,
    entry: dict[str, Any],
) -> str | None:
    source_id = entry["source_record"]["source_registry_id"]
    parents = entry["projection_document"]["parent_ids"]
    if projection_id == "timeline":
        return str(entry["sequence"])
    if projection_id == "products":
        return parents.get("product_factory_id") or (
            entry["subject_id"]
            if source_id == "product-factory-revisions"
            else None
        )
    if projection_id == "signals":
        return parents.get("signal_id") or entry["subject_id"]
    if projection_id == "work-items":
        return parents.get("work_item_id") or (
            entry["subject_id"] if source_id == "work-item-history" else None
        )
    if projection_id == "transitions":
        return parents.get("transition_id") or (
            entry["subject_id"] if source_id == "stage-transitions" else None
        )
    if projection_id == "commands":
        return parents.get("dispatch_id") or (
            entry["subject_id"] if source_id == "dispatch-history" else None
        )
    if projection_id == "runs":
        return parents.get("run_id") or (
            entry["subject_id"]
            if source_id
            in {"run-history", "run-initial-bindings", "run-elder-observations"}
            else None
        )
    return None


def _updated_at(entry: dict[str, Any]) -> str:
    record = entry["projection_document"]["record"]
    value = _find(
        record,
        ("updated_at", "recorded_at", "observed_at", "created_at", "received_at"),
    )
    return value if isinstance(value, str) else entry["recorded_at"]


def _fold_projection_row(
    projection_id: str,
    prior: dict[str, Any] | None,
    entry: dict[str, Any],
    subject_id: str,
) -> dict[str, Any]:
    document = entry["projection_document"]
    source_id = entry["source_record"]["source_registry_id"]
    if projection_id == "timeline":
        row = {
            "version": "1.0.0",
            "projection_id": "timeline",
            "project_id": entry["project_id"],
            "subject_id": subject_id,
            "journal_sequence": entry["sequence"],
            "entry_id": entry["entry_id"],
            "entry_sha256": entry["entry_sha256"],
            "fact_type": entry["fact_type"],
            "operation": entry["operation"],
            "source_registry_id": source_id,
            "source_subject_id": entry["subject_id"],
            "source_subject_version": entry["subject_version"],
            "correlation_id": entry["correlation_id"],
            "causation_id": entry["causation_id"],
            "occurred_at": entry["occurred_at"],
            "recorded_at": entry["recorded_at"],
            "parent_ids": copy.deepcopy(document.get("parent_ids", {})),
            "record": copy.deepcopy(document["record"]),
            "updated_at": entry["recorded_at"],
            "content_sha256": None,
        }
        row["content_sha256"] = _document_digest(row)
        return row

    row = copy.deepcopy(prior) if prior is not None else {
        "version": "1.0.0",
        "projection_id": projection_id,
        "project_id": entry["project_id"],
        "subject_id": subject_id,
        "history": [],
        "latest_by_source": {},
        "parent_ids": {},
        "source_subject_version": 0,
        "last_journal_sequence": 0,
        "updated_at": entry["recorded_at"],
        "content_sha256": None,
    }
    row["history"].append(
        {
            "journal_sequence": entry["sequence"],
            "entry_id": entry["entry_id"],
            "source_registry_id": source_id,
            "source_subject_id": entry["subject_id"],
            "source_subject_version": entry["subject_version"],
            "operation": entry["operation"],
            "occurred_at": entry["occurred_at"],
            "record": copy.deepcopy(document["record"]),
        }
    )
    row["latest_by_source"][source_id] = copy.deepcopy(document["record"])
    row["parent_ids"].update(copy.deepcopy(document.get("parent_ids", {})))
    row["source_subject_version"] = max(
        int(row["source_subject_version"]),
        int(entry["subject_version"]),
    )
    row["last_journal_sequence"] = entry["sequence"]
    row["updated_at"] = _updated_at(entry)
    status_sources = {
        "products": {"product-factory-revisions"},
        "signals": {"signal-revisions"},
        "work-items": {"work-item-history"},
        "transitions": {"stage-transitions"},
        "commands": {"dispatch-history"},
        "runs": {"run-history"},
    }
    if source_id in status_sources.get(projection_id, set()):
        if projection_id in {"commands", "runs"}:
            status = document["record"].get("status")
        else:
            entity_keys = {
                "products": "product_factory",
                "signals": "signal",
                "work-items": "work_item",
                "transitions": "transition",
            }
            entity = document["record"].get(entity_keys[projection_id])
            status = entity.get("status") if isinstance(entity, dict) else None
        if isinstance(status, str):
            row["status"] = status
    if projection_id == "signals":
        received_at = _find(document["record"], ("received_at",))
        if isinstance(received_at, str):
            row["received_at"] = received_at
    if projection_id == "work-items":
        priority = _find(document["record"], ("priority",))
        if isinstance(priority, str):
            row["priority"] = priority
    if projection_id == "transitions" and source_id == "stage-transitions":
        row["recorded_at"] = entry["recorded_at"]
        command_id = _find(document["record"], ("command_id",))
        if isinstance(command_id, str):
            row["command_id"] = command_id
    row["content_sha256"] = _document_digest(row)
    return row


def _public_event(entry: dict[str, Any]) -> dict[str, Any]:
    signal = entry["projection_document"]["record"]["signal"]
    project_id = entry["project_id"]
    stream_id = f"factory-public-events-{project_id}"
    event_id = "event-" + sha256(
        {"mapping_id": "signal-accepted", "entry_id": entry["entry_id"]}
    )[:32]
    payload = {
        "signal_id": signal["id"],
        "source_reference": signal["payload"]["source_reference"],
    }
    event = {
        "version": "1.0.0",
        "event_id": event_id,
        "event_type": "integration.signal.accepted",
        "record_kind": "journal-entry",
        "authoritative": True,
        "source_event_id": None,
        "occurred_at": signal["updated_at"],
        "recorded_at": entry["recorded_at"],
        "cursor": {
            "version": "1.0.0",
            "stream_id": stream_id,
            "generation": 1,
            "sequence": 1,
            "event_id": event_id,
            "snapshot_sha256": None,
            "issued_at": entry["recorded_at"],
        },
        "correlations": {
            "product_id": None,
            "project_id": project_id,
            "work_item_id": None,
            "run_id": None,
            "session_id": None,
        },
        "actor": copy.deepcopy(entry["source_actor"]),
        "source": {
            "plane": "factory-operations",
            "adapter_id": None,
            "source_ref": f"journal:{entry['entry_id']}",
        },
        "correlation_id": signal["correlation_id"],
        "causation_id": signal["causation_id"],
        "idempotency_key": signal["payload"]["idempotency_key"],
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": sha256(payload),
        "payload": payload,
        "extensions": {
            "elder.local/journal-entry-id": entry["entry_id"],
            "elder.local/journal-entry-sha256": entry["entry_sha256"],
        },
    }
    document_digest = sha256(
        {
            **event,
            "cursor": {
                **event["cursor"],
                "snapshot_sha256": None,
            },
        }
    )
    event["cursor"]["snapshot_sha256"] = sha256(
        {
            "stream_id": stream_id,
            "generation": 1,
            "sequence": 1,
            "event_id": event_id,
            "event_document_sha256": document_digest,
        }
    )
    return event


def oracle_replay(
    fixture: dict[str, Any],
) -> dict[str, Any]:
    entries = expand_entries(fixture)
    reducers = fixture["manifest"]["classification_matrix"]
    rows: dict[str, dict[tuple[str, str], dict[str, Any]]] = {
        projection_id: {} for projection_id in PROJECTIONS
    }
    classifications: list[dict[str, str]] = []
    for entry in entries:
        source_id = entry["source_record"]["source_registry_id"]
        for projection_id in PROJECTIONS:
            if projection_id in reducers[source_id]["reducers"]:
                subject_id = _subject(projection_id, entry)
                if subject_id is None:
                    raise AssertionError(
                        f"Oracle reducer has no subject: {source_id}/{projection_id}"
                    )
                key = (entry["project_id"], subject_id)
                rows[projection_id][key] = _fold_projection_row(
                    projection_id,
                    rows[projection_id].get(key),
                    entry,
                    subject_id,
                )
                classification = "reducer"
            elif projection_id in reducers[source_id]["no_ops"]:
                classification = "no-op"
            else:
                raise AssertionError(
                    f"Fixture classification is incomplete: {source_id}/{projection_id}"
                )
            classifications.append(
                {
                    "source_registry_id": source_id,
                    "projection_id": projection_id,
                    "classification": classification,
                }
            )
    projected = {}
    for projection_id in PROJECTIONS:
        ordered = [
            rows[projection_id][key]
            for key in sorted(rows[projection_id])
        ]
        digest_rows = [
            {
                "key": f"{row['project_id']}\u0000{row['subject_id']}",
                "content_sha256": row["content_sha256"],
            }
            for row in ordered
        ]
        projected[projection_id] = {
            "projection_id": projection_id,
            "rows": ordered,
            "row_count": len(ordered),
            "projection_sha256": sha256(digest_rows),
        }
    signal_entry = next(
        entry
        for entry in entries
        if entry["source_record"]["source_registry_id"] == "signal-revisions"
    )
    return {
        "entries": entries,
        "projections": projected,
        "public_events": [_public_event(signal_entry)],
        "classifications": classifications,
    }


def validate_scenario_coverage(
    fixture: dict[str, Any],
    entries: list[dict[str, Any]],
) -> dict[str, list[str]]:
    scenario_entry_ids = fixture["manifest"]["scenario_entry_ids"]
    entry_by_id = {entry["entry_id"]: entry for entry in entries}
    missing = {
        label: sorted(set(entry_ids) - set(entry_by_id))
        for label, entry_ids in scenario_entry_ids.items()
        if set(entry_ids) - set(entry_by_id)
    }
    if missing:
        raise AssertionError(f"Scenario entries are missing: {missing}")

    def scenario(label: str) -> list[dict[str, Any]]:
        return [entry_by_id[entry_id] for entry_id in scenario_entry_ids[label]]

    signal_entries = scenario("accepted-signal-then-work-item-conversion")
    signal = next(
        entry
        for entry in signal_entries
        if entry["source_record"]["source_registry_id"] == "signal-revisions"
    )
    work_item = next(
        entry
        for entry in signal_entries
        if entry["source_record"]["source_registry_id"] == "work-item-history"
    )
    if signal["operation"] != "accept":
        raise AssertionError("Accepted signal scenario lacks accept operation.")
    if signal["projection_document"]["record"].get("status") != "accepted":
        raise AssertionError("Accepted signal scenario lacks accepted status.")
    if work_item["projection_document"]["parent_ids"].get("signal_id") != signal[
        "subject_id"
    ]:
        raise AssertionError("Work-item conversion is not linked to the signal.")

    transition_entries = scenario(
        "accepted-and-rejected-transitions-with-terminal-hook"
    )
    transition_statuses = [
        entry["projection_document"]["record"].get("status")
        for entry in transition_entries
        if entry["source_record"]["source_registry_id"] == "stage-transitions"
    ]
    if transition_statuses != ["accepted", "rejected"]:
        raise AssertionError(
            f"Expected accepted/rejected transitions, got {transition_statuses!r}."
        )
    terminal_hooks = [
        entry
        for entry in transition_entries
        if entry["source_record"]["source_registry_id"]
        == "work-item-terminal-hooks"
    ]
    if len(terminal_hooks) != 1:
        raise AssertionError("Expected exactly one terminal hook.")
    if terminal_hooks[0]["projection_document"]["parent_ids"].get(
        "transition_id"
    ) != "transition-golden":
        raise AssertionError("Terminal hook is not linked to the accepted transition.")

    dispatch_entries = scenario(
        "dispatch-success-uncertainty-retry-exhaustion-dead-letter"
    )
    dispatch_history = [
        entry
        for entry in dispatch_entries
        if entry["source_record"]["source_registry_id"] == "dispatch-history"
    ]
    dispatch_statuses = [
        entry["projection_document"]["record"].get("status")
        for entry in dispatch_history
    ]
    if dispatch_statuses != ["succeeded", "uncertain", "retry-exhausted"]:
        raise AssertionError(
            f"Expected ordered dispatch outcomes, got {dispatch_statuses!r}."
        )
    dead_letters = [
        entry
        for entry in dispatch_entries
        if entry["source_record"]["source_registry_id"]
        == "dispatch-dead-letters"
    ]
    if len(dead_letters) != 1 or dead_letters[0]["sequence"] <= dispatch_history[-1][
        "sequence"
    ]:
        raise AssertionError("Dead letter must follow dispatch retry exhaustion.")

    bind_entries = scenario(
        "run-bind-start-across-policy-binding-run-session-workspace-command-authorization-result-observation"
    )
    required_bind_sources = {
        "product-workspace-policies",
        "run-initial-bindings",
        "run-history",
        "worker-session-history",
        "workspace-history",
        "run-lifecycle-commands",
        "run-command-authorizations",
        "run-lifecycle-results",
        "run-elder-observations",
    }
    actual_bind_sources = {
        entry["source_record"]["source_registry_id"] for entry in bind_entries
    }
    if not required_bind_sources <= actual_bind_sources:
        raise AssertionError(
            f"Run bind/start coverage missing {required_bind_sources - actual_bind_sources}."
        )

    lifecycle_entries = scenario("lifecycle-transition-across-run-session-workspace-histories")
    lifecycle_sources = {
        "run-history",
        "worker-session-history",
        "workspace-history",
    }
    lifecycle_rows = [
        entry
        for entry in lifecycle_entries
        if entry["source_record"]["source_registry_id"] in lifecycle_sources
    ]
    if not lifecycle_rows or not all(
        entry["subject_version"] >= 2 for entry in lifecycle_rows
    ):
        raise AssertionError("Lifecycle transition lacks versioned history rows.")
    if not all(
        entry["projection_document"]["record"].get("status") == "paused"
        for entry in lifecycle_rows
    ):
        raise AssertionError("Lifecycle transition lacks paused state across histories.")

    work_start_entries = scenario("work-item-start-preparation-uncertainty-confirmation")
    result_statuses = [
        entry["projection_document"]["record"].get("status")
        for entry in work_start_entries
        if entry["source_record"]["source_registry_id"]
        == "run-lifecycle-results"
    ]
    if result_statuses != ["prepared", "uncertain", "confirmed"]:
        raise AssertionError(
            f"Expected work-item start results, got {result_statuses!r}."
        )
    if not any(
        entry["source_record"]["source_registry_id"] == "run-external-step-history"
        for entry in work_start_entries
    ):
        raise AssertionError("Work-item start lacks an external-step preparation fact.")

    checkpoint_entries = scenario("same-state-checkpoint-history-and-checkpoint-reference")
    checkpoint_history = [
        entry
        for entry in checkpoint_entries
        if entry["source_record"]["source_registry_id"]
        == "worker-session-history"
    ]
    if len(checkpoint_history) != 2 or [
        entry["projection_document"]["record"].get("status")
        for entry in checkpoint_history
    ] != ["active", "active"]:
        raise AssertionError("Checkpoint scenario lacks same-state session history.")
    checkpoint_reference = next(
        entry
        for entry in checkpoint_entries
        if entry["source_record"]["source_registry_id"]
        == "run-checkpoint-references"
    )
    if checkpoint_reference["projection_document"]["parent_ids"].get("run_id") != (
        "run-golden"
    ):
        raise AssertionError("Checkpoint reference is not bound to the run.")

    artifact_entries = scenario("artifact-reference")
    if not any(
        entry["source_record"]["source_registry_id"] == "run-artifact-references"
        for entry in artifact_entries
    ):
        raise AssertionError("Artifact-reference scenario has no artifact fact.")

    public_boundary_entries = scenario("internal-only-facts-around-one-public-event")
    public_sources = {"signal-revisions"}
    public_candidates = [
        entry
        for entry in public_boundary_entries
        if entry["source_record"]["source_registry_id"] in public_sources
        and entry["operation"] == "accept"
        and entry["projection_document"]["record"].get("status") == "accepted"
    ]
    if len(public_candidates) != 1:
        raise AssertionError("Expected exactly one public-event-producing fact.")
    all_accepted_signals = [
        entry
        for entry in entries
        if entry["source_record"]["source_registry_id"] == "signal-revisions"
        and entry["operation"] == "accept"
        and entry["projection_document"]["record"].get("status") == "accepted"
    ]
    if len(all_accepted_signals) != 1:
        raise AssertionError(
            f"Expected exactly one accepted signal, got {len(all_accepted_signals)}."
        )
    if not any(
        entry["source_record"]["source_registry_id"] != "signal-revisions"
        for entry in entries
        if entry["sequence"] > public_candidates[0]["sequence"]
    ):
        raise AssertionError("Expected internal-only facts after the public event.")
    return {
        label: list(entry_ids)
        for label, entry_ids in scenario_entry_ids.items()
    }


def install_fixture_store(
    path: Path,
    fixture: dict[str, Any],
    replay: dict[str, Any],
) -> None:
    sqlite3.connect(path).close()
    connection = sqlite3.connect(path)
    try:
        connection.execute(
            "CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)"
        )
        for source in _source_registry().values():
            columns = list(
                dict.fromkeys(
                    [
                        *source["primary_key"],
                        *source["source_identity"],
                        source["record_json_field"],
                        source["record_digest_field"],
                        source["occurred_at_field"],
                        *(
                            [source["native_version"]]
                            if source["native_version"] is not None
                            else []
                        ),
                        *(
                            [source["operation_field"]]
                            if source["operation_field"] is not None
                            else []
                        ),
                    ]
                )
            )
            definitions = []
            for column in columns:
                column_type = (
                    "INTEGER"
                    if column.endswith("_version") or column == "record_version"
                    else "TEXT"
                )
                definitions.append(f'"{column}" {column_type}')
            primary_key = ", ".join(
                f'"{column}"' for column in source["primary_key"]
            )
            connection.execute(
                f'CREATE TABLE "{source["table"]}" '
                f"({', '.join(definitions)}, PRIMARY KEY({primary_key}))"
            )
        connection.commit()
    finally:
        connection.close()
    JournalInitializer(path).initialize()
    entries = replay["entries"]
    connection = sqlite3.connect(path)
    try:
        stream_id = connection.execute(
            "SELECT stream_id FROM factory_journal_stream"
        ).fetchone()[0]
        connection.execute(
            """
            UPDATE factory_journal_stream
            SET stream_id = 'factory-operations'
            WHERE stream_id = ?
            """,
            (stream_id,),
        )
        for entry in entries:
            source = entry["source_record"]
            connection.execute(
                """
                INSERT INTO factory_journal_entries(
                    sequence, entry_id, stream_id, generation,
                    transaction_id, transaction_position,
                    transaction_fact_count, source_append_order,
                    coverage_branch_id, mutation_identity_sha256,
                    project_id, subject_type, subject_id,
                    subject_version, fact_type, operation, occurred_at,
                    recorded_at, previous_entry_sha256, entry_sha256,
                    source_registry_id, source_identity_json,
                    source_version, source_record_sha256,
                    source_row_sha256, projection_document_sha256,
                    entry_json
                ) VALUES(
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
                """,
                (
                    entry["sequence"],
                    entry["entry_id"],
                    entry["stream_id"],
                    entry["generation"],
                    entry["transaction_id"],
                    entry["transaction_position"],
                    entry["transaction_fact_count"],
                    entry["source_append_order"],
                    entry["coverage_branch_id"],
                    entry["mutation_identity_sha256"],
                    entry["project_id"],
                    entry["subject_type"],
                    entry["subject_id"],
                    entry["subject_version"],
                    entry["fact_type"],
                    entry["operation"],
                    entry["occurred_at"],
                    entry["recorded_at"],
                    entry["previous_entry_sha256"],
                    entry["entry_sha256"],
                    source["source_registry_id"],
                    canonical_json(
                        _source_identity(
                            next(
                                spec
                                for spec in fixture["entry_specs"]
                                if spec["sequence"] == entry["sequence"]
                            ),
                            _source_registry()[source["source_registry_id"]],
                        )
                    ),
                    source["record_version"],
                    source["record_sha256"],
                    source["row_sha256"],
                    entry["projection_document_sha256"],
                    canonical_json(entry),
                ),
            )
        tip = entries[-1]
        connection.execute(
            """
            UPDATE factory_journal_stream
            SET current_sequence = ?,
                current_entry_id = ?,
                current_entry_sha256 = ?,
                updated_at = ?
            WHERE stream_id = 'factory-operations' AND generation = 1
            """,
            (
                tip["sequence"],
                tip["entry_id"],
                tip["entry_sha256"],
                tip["recorded_at"],
            ),
        )
        connection.commit()
    finally:
        connection.close()
    recorder = JournalRecorder()
    with operations_connection(path, isolation_level=None) as connection:
        connection.execute("BEGIN IMMEDIATE")
        for entry in entries:
            recorder._append_public_event_for_fact(
                connection,
                entry=entry,
                fact={
                    "operation": entry["operation"],
                    "record": entry["projection_document"]["record"],
                },
            )
        connection.commit()


def read_projection_rows(
    path: Path,
    projection_id: str,
) -> list[dict[str, Any]]:
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    try:
        rows = connection.execute(
            """
            SELECT record_json
            FROM factory_projection_rows
            WHERE projection_id = ? AND projection_generation = (
                SELECT generation
                FROM factory_projection_generations
                WHERE projection_id = ?
                  AND status IN ('active', 'building')
                ORDER BY
                  CASE status WHEN 'active' THEN 0 ELSE 1 END,
                  generation DESC
                LIMIT 1
            )
            ORDER BY project_id, subject_id
            """,
            (projection_id, projection_id),
        ).fetchall()
        return [json.loads(row["record_json"]) for row in rows]
    finally:
        connection.close()


def read_public_events(path: Path) -> list[dict[str, Any]]:
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    try:
        rows = connection.execute(
            "SELECT event_json FROM factory_public_events ORDER BY sequence"
        ).fetchall()
        return [json.loads(row["event_json"]) for row in rows]
    finally:
        connection.close()
