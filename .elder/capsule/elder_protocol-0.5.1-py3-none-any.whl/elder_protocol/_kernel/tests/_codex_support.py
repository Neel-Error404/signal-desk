from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_workers import (
    CODEX_CLI_VERSION,
    CodexRuntimeConfig,
    CodexRuntimeError,
)


class DeterministicCodexRuntime:
    def __init__(self) -> None:
        self.config = CodexRuntimeConfig(executable=("fake-codex",))
        self.calls: list[dict[str, Any]] = []
        self.fail_next_turn: CodexRuntimeError | None = None
        self.next_turn_status = "completed"
        self.next_turn_error: dict[str, Any] | None = None

    def version(self) -> str:
        return CODEX_CLI_VERSION

    @staticmethod
    def _thread_id(workspace: Path) -> str:
        return f"thread-{canonical_sha256(str(workspace))[:24]}"

    def _effective(
        self,
        workspace: Path,
        *,
        thread_id: str,
    ) -> dict[str, Any]:
        return {
            "thread_id": thread_id,
            "rollout_path": str(workspace / ".codex-rollout.jsonl"),
            "thread_status": {"type": "idle"},
            "cli_version": CODEX_CLI_VERSION,
            "model": "deterministic-codex",
            "model_provider": "test-owned",
            "cwd": str(workspace),
            "runtime_workspace_roots": [str(workspace)],
            "approval_policy": "on-request",
            "approvals_reviewer": "user",
            "sandbox": {
                "type": "workspaceWrite",
                "network_access": False,
            },
            "notification_sha256s": [],
        }

    def start_session(self, workspace: Path) -> dict[str, Any]:
        thread_id = self._thread_id(workspace)
        self.calls.append(
            {
                "operation": "start",
                "workspace": str(workspace),
                "thread_id": thread_id,
            }
        )
        return self._effective(workspace, thread_id=thread_id)

    def resume_session(
        self,
        thread_id: str,
        workspace: Path,
    ) -> dict[str, Any]:
        self.calls.append(
            {
                "operation": "resume",
                "workspace": str(workspace),
                "thread_id": thread_id,
            }
        )
        return self._effective(workspace, thread_id=thread_id)

    def run_turn(
        self,
        thread_id: str,
        workspace: Path,
        *,
        command_id: str,
        command_type: str,
        prompt: str,
    ) -> dict[str, Any]:
        self.calls.append(
            {
                "operation": "turn",
                "workspace": str(workspace),
                "thread_id": thread_id,
                "command_id": command_id,
                "command_type": command_type,
                "prompt": prompt,
            }
        )
        if self.fail_next_turn is not None:
            failure = self.fail_next_turn
            self.fail_next_turn = None
            raise failure
        effective = self._effective(workspace, thread_id=thread_id)
        return {
            "thread_id": thread_id,
            "turn_id": f"turn-{command_id}",
            "turn_status": self.next_turn_status,
            "turn_error_present": self.next_turn_error is not None,
            "turn_error_sha256": (
                canonical_sha256(self.next_turn_error)
                if self.next_turn_error is not None
                else None
            ),
            "command_id": command_id,
            "command_type": command_type,
            "effective_policy_sha256": canonical_sha256(effective),
            "item_summaries": [
                {
                    "id": f"item-{command_id}",
                    "type": "agentMessage",
                    "status": None,
                }
            ],
            "item_summary_sha256": canonical_sha256(
                [
                    {
                        "id": f"item-{command_id}",
                        "type": "agentMessage",
                        "status": None,
                    }
                ]
            ),
            "usage": {
                "inputTokens": 1,
                "outputTokens": 1,
                "totalTokens": 2,
            },
            "usage_sha256": canonical_sha256(
                {
                    "inputTokens": 1,
                    "outputTokens": 1,
                    "totalTokens": 2,
                }
            ),
            "final_message_sha256": canonical_sha256("done"),
            "notification_sha256s": [],
        }

    def cancel_session(
        self,
        thread_id: str,
        workspace: Path,
    ) -> dict[str, Any]:
        self.calls.append(
            {
                "operation": "cancel",
                "workspace": str(workspace),
                "thread_id": thread_id,
            }
        )
        return {
            "thread_id": thread_id,
            "provider_status": {"type": "idle"},
            "active_turn_id": None,
            "interrupted": False,
            "effective_policy_sha256": canonical_sha256(
                self._effective(workspace, thread_id=thread_id)
            ),
            "notification_sha256s": [],
        }

    def clone(self) -> DeterministicCodexRuntime:
        clone = DeterministicCodexRuntime()
        clone.calls = copy.deepcopy(self.calls)
        return clone
