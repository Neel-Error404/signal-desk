from __future__ import annotations

import copy
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_contracts import FACTORY_CONTRACT_VERSION
from elder_protocol.factory_operations.elder_boundary import (
    build_elder_boundary_snapshot,
    elder_boundary_extensions,
)


SUBMITTED_AT = "2026-08-14T12:00:00+00:00"
DEADLINE_AT = "2026-08-14T14:00:00+00:00"
CLOCK_AT = "2026-08-14T13:00:00+00:00"
SHA256 = "a" * 64

PAYLOADS = {
    "classify": {
        "work_item": {
            "id": "work-item-001",
            "project_id": "project-001",
            "change_class": "internal-code",
        }
    },
    "assemble-context": {
        "context_request": {
            "project_id": "project-001",
            "query": "bounded Elder context",
        }
    },
    "authorize": {
        "action": {
            "resource": "implementation",
            "action": "modify",
            "identity_id": "executor-001",
            "role": "executor",
        }
    },
    "validate-delegation": {
        "delegation": {
            "delegation_id": "delegation-001",
            "content_sha256": SHA256,
        }
    },
    "evaluate": {
        "evidence": {
            "id": "evidence-001",
            "claim": "The bounded behavior is verified.",
        }
    },
    "qualify": {"bundle": {"id": "bundle-001"}},
    "propose-learning": {
        "trajectory": {
            "run_id": "run-001",
            "evidence_refs": ["evidence:001"],
        }
    },
    "promote": {
        "promotion_packet": {
            "candidate_id": "candidate-001",
            "evaluation_id": "evaluation-001",
            "content_sha256": SHA256,
        }
    },
}

RESULTS = {
    "classify": {"change_class": "internal-code"},
    "assemble-context": {
        "context_packet": {
            "id": "context-001",
            "content_sha256": SHA256,
        }
    },
    "authorize": {
        "authority_result": {
            "decision": "allowed",
            "authority_ref": "elder://authority/project-001/executor-001",
        }
    },
    "validate-delegation": {"validation_result": {"valid": True}},
    "evaluate": {"evaluation_result": {"verdict": "pass"}},
    "qualify": {"qualification_report": {"decision": "qualified"}},
    "propose-learning": {
        "learning_candidate": {
            "candidate_id": "candidate-001",
            "content_sha256": SHA256,
        }
    },
    "promote": {
        "governed_target_result": {
            "status": "promoted",
            "target_ref": "memory:project-001/candidate-001",
        }
    },
}


def boundary_snapshot() -> dict[str, Any]:
    return build_elder_boundary_snapshot()


def request_for(
    snapshot: dict[str, Any],
    operation: str,
    *,
    request_id: str | None = None,
    idempotency_key: str | None = None,
    payload: dict[str, Any] | None = None,
    deadline_at: str | None = DEADLINE_AT,
) -> dict[str, Any]:
    selected_payload = copy.deepcopy(payload or PAYLOADS[operation])
    mutating = operation in {"propose-learning", "promote"}
    if mutating and idempotency_key is None:
        idempotency_key = f"sf400-{operation}-001"
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "contract_id": "governance-adapter",
        "operation": operation,
        "request_id": request_id or f"request-{operation}",
        "project_id": "project-001",
        "work_item_id": "work-item-001",
        "run_id": "run-001",
        "session_id": None,
        "submitted_at": SUBMITTED_AT,
        "deadline_at": deadline_at,
        "correlation_id": "correlation-sf400-001",
        "causation_id": None,
        "mutability": "mutation" if mutating else "read",
        "idempotency_key": idempotency_key if mutating else None,
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(selected_payload),
        "payload": selected_payload,
        "extensions": elder_boundary_extensions(snapshot, operation),
    }


def success_handlers(
    calls: dict[str, int] | None = None,
) -> dict[str, Any]:
    handlers: dict[str, Any] = {}
    for operation, result in RESULTS.items():
        def handler(
            payload: dict[str, Any],
            request: dict[str, Any],
            *,
            selected_operation: str = operation,
            selected_result: dict[str, Any] = result,
        ) -> dict[str, Any]:
            del payload, request
            if calls is not None:
                calls[selected_operation] = calls.get(selected_operation, 0) + 1
            return copy.deepcopy(selected_result)

        handlers[operation] = handler
    return handlers
