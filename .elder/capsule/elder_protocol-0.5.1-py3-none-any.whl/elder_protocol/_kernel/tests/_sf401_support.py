from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

from elder_protocol.activation import activate_session
from elder_protocol.compiler import compile_project
from elder_protocol.constants import ROOT
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    GovernedContextAssembly,
    ProductFactoryRegistry,
    WorkItemLedger,
    WorkItemTransitionEngine,
)
from elder_protocol.governance import finalize_delegation
from elder_protocol.io import load_json
from elder_protocol.knowledge import KnowledgeStore
from tests.component.test_durable_dispatcher import (
    DurableDispatcherComponentTests,
)


CLOCK_AT = "2026-08-14T14:00:00+00:00"
SUBMITTED_AT = "2026-08-14T13:00:00+00:00"
DEADLINE_AT = "2026-08-14T15:00:00+00:00"


def _profile_path(workspace: Path) -> Path:
    profile = copy.deepcopy(
        load_json(ROOT / "examples" / "minimal-project-profile.json")
    )
    profile["slug"] = "product-one"
    profile["name"] = "Product One"
    path = workspace / "product-one-profile.json"
    path.write_text(json.dumps(profile, indent=2) + "\n", encoding="utf-8")
    return path


def _queued_work_item(
    database: Path,
    project: Path,
) -> dict[str, Any]:
    FactoryOperationsBootstrap(database).initialize()
    registry = ProductFactoryRegistry(database)
    factory = registry.register(
        {
            "version": "1.0.0",
            "project_id": "product-one",
            "repository_root": str(project.resolve()),
            "profile_path": ".elder/project-profile.json",
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [
                {
                    "id": "owner-inbox",
                    "kind": "manual",
                    "reference": "manual:owner-inbox",
                    "enabled": True,
                }
            ],
        },
        actor_identity_id="founder",
        at="2026-08-14T12:00:00+00:00",
    )
    registry.activate(
        factory["product_factory"]["id"],
        expected_version=1,
        actor_identity_id="founder",
        at="2026-08-14T12:01:00+00:00",
    )
    helper = DurableDispatcherComponentTests(methodName="runTest")
    ledger = WorkItemLedger(database)
    ledger.initialize()
    specification = helper._specification()
    specification["objective"] = (
        "Repair the bounded product component with governed context."
    )
    specification["scope"] = ["src/component"]
    specification["acceptance_criteria"] = [
        "The executor receives only authorized repository context.",
        "The context packet remains digest-bound through run preparation.",
    ]
    created = ledger.create(
        specification,
        actor_identity_id="founder",
        change_reason="Accept the SF-401 fixture work item.",
        at="2026-08-14T12:02:00+00:00",
    )
    transitions = WorkItemTransitionEngine(database)
    transitions.initialize()
    transitions.apply(
        helper._transition_command(
            command_id="transition-command-submit-build-repair",
            trigger="submit",
            expected_version=1,
            actor_identity_id="example-agentic-product-planning-agent",
            role="planning-agent",
            mode="modify-only",
            resource="design-doc",
            action="modify",
            field_bindings={
                "revision_id": created["current_revision"]["id"],
                "evidence_plan": created["work_item"]["payload"][
                    "evidence_plan"
                ],
            },
            evidence_refs={},
            submitted_at="2026-08-14T12:03:00+00:00",
        ),
        at="2026-08-14T12:03:01+00:00",
    )
    ready = ledger.get("work-item-build-repair")
    transitions.apply(
        helper._transition_command(
            command_id="transition-command-queue-build-repair",
            trigger="queue",
            expected_version=2,
            actor_identity_id="example-agentic-product-executor",
            role="executor",
            mode="execute-bounded",
            resource="context-packet",
            action="execute",
            field_bindings={
                "revision_id": ready["current_revision"]["id"],
            },
            evidence_refs={
                "validated work item revision": (
                    "evidence:sf401-work-item-revision"
                )
            },
            submitted_at="2026-08-14T12:04:00+00:00",
        ),
        at="2026-08-14T12:04:01+00:00",
    )
    return ledger.get("work-item-build-repair")


def run_chain(
    *,
    packet_id: str = "product-one-context-001",
    child_run_id: str = "product-one-child-run-001",
) -> dict[str, Any]:
    fixture = load_json(
        ROOT / "tests" / "fixtures" / "p4_5a" / "fixture-a-low-risk.json"
    )
    parent = copy.deepcopy(fixture["parent_run"])
    parent.update(
        {
            "id": "product-one-parent-run",
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "identity_id": "founder",
            "context_packet_id": "product-one-parent-context",
            "deadline": "2026-08-15T18:00:00+00:00",
            "started_at": "2026-08-14T12:05:00+00:00",
        }
    )
    delegation = copy.deepcopy(fixture["delegation"])
    delegation.update(
        {
            "delegation_id": "product-one-delegation",
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "parent_run_id": parent["id"],
            "assigned_identity_id": "example-agentic-product-executor",
            "objective": (
                "Repair the bounded component using only authorized context."
            ),
            "scope": ["src/component"],
            "forbidden_scope": ["production"],
            "deadline": "2026-08-15T16:00:00+00:00",
            "expires_at": "2026-08-15T17:00:00+00:00",
        }
    )
    delegation = finalize_delegation(delegation)
    child = copy.deepcopy(fixture["child_run"])
    child.update(
        {
            "id": child_run_id,
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "identity_id": "example-agentic-product-executor",
            "parent_run_id": parent["id"],
            "delegation_id": delegation["delegation_id"],
            "context_packet_id": packet_id,
            "scope": ["src/component"],
            "deadline": "2026-08-15T16:00:00+00:00",
            "started_at": "2026-08-14T12:06:00+00:00",
        }
    )
    return {
        "parent_run": parent,
        "delegation": delegation,
        "child_run": child,
    }


def build_environment(
    workspace: Path,
) -> dict[str, Any]:
    project = workspace / "product-one"
    compile_project(_profile_path(workspace), project)
    (project / ".git").mkdir()
    source = project / "src" / "component" / "runtime-source.md"
    source.parent.mkdir(parents=True)
    source.write_text(
        "SF-401 supplies bounded authorized component context.\n",
        encoding="utf-8",
    )
    activation = activate_session(
        project,
        "Assemble governed task context for the queued component repair",
    )
    database = workspace / "operations.db"
    work = _queued_work_item(database, project)
    knowledge_path = workspace / "knowledge.db"
    KnowledgeStore(knowledge_path).initialize()
    context_path = workspace / "governed-context.db"
    boundary_state_path = workspace / "elder-boundary.db"
    service = GovernedContextAssembly(
        operations_path=database,
        knowledge_path=knowledge_path,
        context_path=context_path,
        boundary_state_path=boundary_state_path,
        project_root=project,
        activation=activation,
        clock=lambda: CLOCK_AT,
    )
    service.initialize()
    return {
        "activation": activation,
        "boundary_state_path": boundary_state_path,
        "context_path": context_path,
        "database": database,
        "knowledge_path": knowledge_path,
        "project": project,
        "service": service,
        "source": source,
        "work": work,
        **run_chain(),
    }


def submission(
    environment: dict[str, Any],
    *,
    chain: dict[str, Any] | None = None,
    previous_packet_id: str | None = None,
    requested_token_budget: int | None = 2000,
    memory_namespaces: list[str] | None = None,
    repository_sources: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    selected = chain or {
        "parent_run": environment["parent_run"],
        "delegation": environment["delegation"],
        "child_run": environment["child_run"],
    }
    sources = repository_sources
    if sources is None:
        sources = [
            {
                "id": "runtime-source",
                "location": "src/component/runtime-source.md",
                "authority": "primary",
                "required": True,
            }
        ]
    return {
        "version": "1.0.0",
        "work_item_id": "work-item-build-repair",
        "assembled_by": "example-agentic-product-planning-agent",
        "parent_run": copy.deepcopy(selected["parent_run"]),
        "delegation": copy.deepcopy(selected["delegation"]),
        "child_run": copy.deepcopy(selected["child_run"]),
        "repository_sources": copy.deepcopy(sources),
        "memory_namespaces": copy.deepcopy(memory_namespaces or []),
        "token_budget": requested_token_budget,
        "previous_packet_id": previous_packet_id,
        "submitted_at": SUBMITTED_AT,
        "deadline_at": DEADLINE_AT,
    }
