from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
import threading
from typing import Any, Mapping

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_workers import (
    PRIME_AGENT_VERSION,
    PRIME_DAEMON_PROTOCOL_VERSION,
    PRIME_DAEMON_SCHEMA_REVISION,
    PRIME_SOURCE_REVISION,
    PrimeRuntimeConfig,
    PrimeRuntimeError,
)


GIT_BASH = Path(r"C:\Program Files\Git\bin\bash.exe")


@dataclass
class DeterministicPrimeState:
    daemon_generation: int = 1
    sessions_by_path: dict[str, str] = field(default_factory=dict)
    session_paths: dict[str, str] = field(default_factory=dict)
    journals: dict[tuple[str, str], dict[str, Any]] = field(
        default_factory=dict
    )
    calls: list[dict[str, Any]] = field(default_factory=list)
    lock: threading.Lock = field(default_factory=threading.Lock)


class DeterministicPrimeRuntime:
    def __init__(
        self,
        root: Path,
        *,
        state: DeterministicPrimeState | None = None,
    ) -> None:
        self.state = state or DeterministicPrimeState()
        agent_dir = (root / "prime-agent-state").resolve()
        agent_dir.mkdir(parents=True, exist_ok=True)
        self.config = PrimeRuntimeConfig(
            executable=("fake-prime-agent",),
            agent_dir=agent_dir,
            socket_path="deterministic-prime-socket",
            bash_path=GIT_BASH,
        )
        self.fail_after_dispatch_once = False
        self.next_refinement_proposals: list[dict[str, Any]] = []
        self.next_refinement_applications: list[dict[str, Any]] = []

    def version(self) -> str:
        return PRIME_AGENT_VERSION

    def restart_daemon(self) -> None:
        with self.state.lock:
            self.state.daemon_generation += 1

    @staticmethod
    def _session_id(session_path: Path) -> str:
        return f"prime-{canonical_sha256(str(session_path))[:24]}"

    def _daemon(self) -> dict[str, Any]:
        return {
            "protocol": {
                "name": "prime-agent.daemon",
                "version": PRIME_DAEMON_PROTOCOL_VERSION,
            },
            "schemaRevision": PRIME_DAEMON_SCHEMA_REVISION,
            "appVersion": PRIME_AGENT_VERSION,
            "sourceRevision": PRIME_SOURCE_REVISION,
            "supervisorGeneration": (
                f"generation-{self.state.daemon_generation}"
            ),
        }

    def start_session(
        self,
        workspace: Path,
        *,
        session_path: Path,
        client_id: str,
        command_id: str,
    ) -> dict[str, Any]:
        key = (client_id, command_id)
        with self.state.lock:
            existing = self.state.journals.get(key)
            if existing is not None:
                return copy.deepcopy(existing)
            path = str(session_path)
            if path in self.state.sessions_by_path:
                raise PrimeRuntimeError(
                    "Prime session path is already leased.",
                    reason="session_already_active",
                    dispatched=True,
                )
            active_session_id = self._session_id(session_path)
            observation = {
                "active_session_id": active_session_id,
                "session_path": path,
                "cwd": str(workspace),
                "daemon": self._daemon(),
                "create_response_sha256": canonical_sha256(
                    [client_id, command_id, path]
                ),
                "refinement_proposals": [],
                "refinement_applications": [],
            }
            self.state.sessions_by_path[path] = active_session_id
            self.state.session_paths[active_session_id] = path
            self.state.journals[key] = copy.deepcopy(observation)
            self.state.calls.append(
                {
                    "operation": "start",
                    "client_id": client_id,
                    "command_id": command_id,
                    "active_session_id": active_session_id,
                }
            )
            return copy.deepcopy(observation)

    def resume_session(
        self,
        active_session_id: str,
        workspace: Path,
        *,
        client_id: str,
        cursor: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        with self.state.lock:
            if active_session_id not in self.state.session_paths:
                raise PrimeRuntimeError(
                    "Prime session is unavailable.",
                    reason="session-not-found",
                    dispatched=False,
                )
            observation = {
                "active_session_id": active_session_id,
                "cwd": str(workspace),
                "daemon": self._daemon(),
                "attach": {
                    "activeSessionId": active_session_id,
                    "lastEventCursor": copy.deepcopy(cursor),
                },
                "attach_sha256": canonical_sha256(
                    [
                        active_session_id,
                        self.state.daemon_generation,
                        cursor,
                    ]
                ),
            }
            self.state.calls.append(
                {
                    "operation": "resume",
                    "client_id": client_id,
                    "active_session_id": active_session_id,
                    "daemon_generation": self.state.daemon_generation,
                }
            )
            return observation

    def run_command(
        self,
        active_session_id: str,
        workspace: Path,
        *,
        client_id: str,
        command_id: str,
        command_type: str,
        prompt: str,
    ) -> dict[str, Any]:
        key = (client_id, command_id)
        with self.state.lock:
            existing = self.state.journals.get(key)
            if existing is not None:
                self.state.calls.append(
                    {
                        "operation": "journal-replay",
                        "client_id": client_id,
                        "command_id": command_id,
                    }
                )
                return copy.deepcopy(existing)
            if active_session_id not in self.state.session_paths:
                raise PrimeRuntimeError(
                    "Prime session is unavailable.",
                    reason="session-not-found",
                    dispatched=False,
                )
            observation = {
                "active_session_id": active_session_id,
                "command_id": command_id,
                "command_type": command_type,
                "status": "completed",
                "prompt_sha256": canonical_sha256(prompt),
                "provider_cursor": {
                    "generation": f"worker-{active_session_id}",
                    "sequence": len(self.state.journals) + 1,
                },
                "refinement_proposals": copy.deepcopy(
                    self.next_refinement_proposals
                ),
                "refinement_applications": copy.deepcopy(
                    self.next_refinement_applications
                ),
            }
            self.next_refinement_proposals = []
            self.next_refinement_applications = []
            self.state.journals[key] = copy.deepcopy(observation)
            self.state.calls.append(
                {
                    "operation": "command",
                    "client_id": client_id,
                    "command_id": command_id,
                    "command_type": command_type,
                    "active_session_id": active_session_id,
                }
            )
            if self.fail_after_dispatch_once:
                self.fail_after_dispatch_once = False
                raise PrimeRuntimeError(
                    "Prime response was lost after dispatch.",
                    reason="command-response-lost",
                    dispatched=True,
                )
            return observation

    def cancel_session(
        self,
        active_session_id: str,
        workspace: Path,
        *,
        client_id: str,
        command_id: str,
    ) -> dict[str, Any]:
        key = (client_id, command_id)
        with self.state.lock:
            existing = self.state.journals.get(key)
            if existing is not None:
                return copy.deepcopy(existing)
            observation = {
                "active_session_id": active_session_id,
                "status": "cancelled",
                "abort_response_sha256": canonical_sha256(
                    [active_session_id, command_id]
                ),
            }
            self.state.journals[key] = copy.deepcopy(observation)
            self.state.calls.append(
                {
                    "operation": "cancel",
                    "client_id": client_id,
                    "command_id": command_id,
                    "active_session_id": active_session_id,
                }
            )
            return observation


class RecordingPrimeCandidateSink:
    def __init__(self) -> None:
        self.candidates: list[dict[str, Any]] = []

    def record_candidate(
        self,
        *,
        project_id: str,
        work_item_id: str,
        run_id: str,
        worker_session_id: str,
        provider_session_ref: str,
        proposal: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        content = {
            "project_id": project_id,
            "work_item_id": work_item_id,
            "run_id": run_id,
            "worker_session_id": worker_session_id,
            "provider_session_ref": provider_session_ref,
            "proposal": copy.deepcopy(dict(proposal)),
            "status": "candidate",
            "direct_application": False,
        }
        candidate = {
            **content,
            "candidate_id": (
                f"prime-candidate-{canonical_sha256(content)[:24]}"
            ),
            "content_sha256": canonical_sha256(content),
        }
        self.candidates.append(candidate)
        return candidate
