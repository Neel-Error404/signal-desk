from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from elder_protocol.factory_operations import (
    AuthorityDelegationIntegration,
)
from tests._sf401_support import (
    build_environment as build_context_environment,
    submission as context_submission,
)


STARTED_AT = "2026-08-14T14:01:00+00:00"
VIEWED_AT = "2026-08-14T14:05:00+00:00"
LEASE_TOKEN = "sf402-assigned-child-lease-token-0001"


def build_environment(workspace: Path) -> dict[str, Any]:
    environment = build_context_environment(workspace)
    context = environment["service"].assemble(
        context_submission(environment)
    )
    gate = AuthorityDelegationIntegration(
        operations_path=environment["database"],
        context_service=environment["service"],
        runtime_path=workspace / "multi-agent-runtime.db",
        decision_path=workspace / "authority-decisions.db",
        project_root=environment["project"],
        clock=lambda: VIEWED_AT,
    )
    gate.initialize()
    return {
        **environment,
        "context": context,
        "decision_path": workspace / "authority-decisions.db",
        "gate": gate,
        "runtime_path": workspace / "multi-agent-runtime.db",
    }


def restart_gate(
    environment: dict[str, Any],
) -> AuthorityDelegationIntegration:
    gate = AuthorityDelegationIntegration(
        operations_path=environment["database"],
        context_service=environment["service"],
        runtime_path=environment["runtime_path"],
        decision_path=environment["decision_path"],
        project_root=environment["project"],
        clock=lambda: VIEWED_AT,
    )
    gate.initialize()
    return gate


def start_submission(
    environment: dict[str, Any],
    *,
    request_id: str = "sf402-start-product-one-001",
    parent_run: dict[str, Any] | None = None,
    delegation: dict[str, Any] | None = None,
    child_run: dict[str, Any] | None = None,
    requested_by: str | None = None,
    lease_seconds: int = 600,
    lease_token: str = LEASE_TOKEN,
    submitted_at: str = STARTED_AT,
) -> dict[str, Any]:
    selected_parent = copy.deepcopy(
        parent_run or environment["parent_run"]
    )
    selected_delegation = copy.deepcopy(
        delegation or environment["delegation"]
    )
    selected_child = copy.deepcopy(child_run or environment["child_run"])
    return {
        "version": "1.0.0",
        "request_id": request_id,
        "work_item_id": environment["work"]["work_item"]["id"],
        "requested_by": requested_by or selected_parent["identity_id"],
        "parent_run": selected_parent,
        "delegation": selected_delegation,
        "child_run": selected_child,
        "context_packet_id": environment["context"]["packet"]["id"],
        "authorized_context_sha256": environment["context"]["packet"][
            "content_sha256"
        ],
        "lease_seconds": lease_seconds,
        "lease_token": lease_token,
        "submitted_at": submitted_at,
    }


def cancellation(
    environment: dict[str, Any],
    *,
    cancellation_id: str = "sf402-cancel-product-one-001",
    requested_at: str = "2026-08-14T14:06:00+00:00",
) -> dict[str, Any]:
    return {
        "version": environment["delegation"]["version"],
        "id": cancellation_id,
        "project_id": environment["delegation"]["project_id"],
        "subject_type": "delegation",
        "subject_id": environment["delegation"]["delegation_id"],
        "requested_by": environment["parent_run"]["identity_id"],
        "reason": "Owner cancelled the bounded delegated run.",
        "propagate_to_active_children": True,
        "requested_at": requested_at,
        "status": "requested",
    }
