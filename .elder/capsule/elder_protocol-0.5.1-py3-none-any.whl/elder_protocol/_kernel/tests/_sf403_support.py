from __future__ import annotations

import copy
import subprocess
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations import (
    EvidenceTestPipeline,
    repository_fingerprint,
)
from elder_protocol.io import sha256_file
from tests._sf402_support import (
    LEASE_TOKEN,
    build_environment as build_authority_environment,
    start_submission,
)


PIPELINE_AT = "2026-08-14T14:05:00+00:00"
FOUNDATION_STARTED = "2026-08-14T14:05:10+00:00"
FOUNDATION_COMPLETED = "2026-08-14T14:05:20+00:00"
COMPONENT_STARTED = "2026-08-14T14:05:30+00:00"
COMPONENT_COMPLETED = "2026-08-14T14:05:40+00:00"


def _git(repository: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(repository), *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="strict",
        check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(
            f"git {' '.join(args)} failed: {completed.stderr}"
        )
    return completed.stdout


def build_environment(
    workspace: Path,
    *,
    repository_fixture: str = "component-add",
) -> dict[str, Any]:
    environment = build_authority_environment(workspace)
    authority = environment["gate"].start(
        start_submission(
            environment,
            lease_seconds=900,
        )
    )
    git_dir = environment["project"] / ".git"
    git_dir.rmdir()
    _git(environment["project"], "init")
    _git(environment["project"], "config", "user.name", "SF403 Test")
    _git(
        environment["project"],
        "config",
        "user.email",
        "sf403@example.invalid",
    )
    change = environment["project"] / "src" / "component" / "implementation.py"
    if repository_fixture == "semantic-formatting":
        change.parent.mkdir(parents=True, exist_ok=True)
        change.write_text(
            "def repaired_component( ) -> str:\n"
            "    return  \"verified\"\n",
            encoding="utf-8",
        )
        (environment["project"] / ".gitignore").write_text(
            "artifacts/\n",
            encoding="utf-8",
        )
    elif repository_fixture != "component-add":
        raise AssertionError(
            f"Unsupported SF-403 repository fixture: {repository_fixture}"
        )
    _git(environment["project"], "add", ".")
    _git(environment["project"], "commit", "-m", "fixture baseline")
    if repository_fixture == "semantic-formatting":
        change.write_text(
            "def repaired_component() -> str:\n"
            "    return \"verified\"\n",
            encoding="utf-8",
        )
    else:
        change.write_text(
            "def repaired_component() -> str:\n"
            "    return \"verified\"\n",
            encoding="utf-8",
        )
    artifacts = environment["project"] / "artifacts"
    artifacts.mkdir()
    foundation_artifact = artifacts / "foundation.txt"
    component_artifact = artifacts / "component.txt"
    foundation_artifact.write_text("Foundation passed.\n", encoding="utf-8")
    component_artifact.write_text("Component passed.\n", encoding="utf-8")
    pipeline_path = workspace / "evidence-pipeline.db"
    pipeline = EvidenceTestPipeline(
        operations_path=environment["database"],
        authority_gate=environment["gate"],
        pipeline_path=pipeline_path,
        repository_root=environment["project"],
        clock=lambda: PIPELINE_AT,
    )
    pipeline.initialize()
    plan = pipeline.create_plan(
        work_item_id=environment["work"]["work_item"]["id"],
        authority_request_id=authority["decision"]["request_id"],
        executor_id=environment["child_run"]["identity_id"],
        commands={
            "Foundation": ["py", "-m", "unittest", "tests.foundation"],
            "Component": ["py", "-m", "unittest", "tests.component"],
        },
        lease_token=LEASE_TOKEN,
        authorized_context_sha256=environment["context"]["packet"][
            "content_sha256"
        ],
    )
    return {
        **environment,
        "authority": authority,
        "change": change,
        "component_artifact": component_artifact,
        "foundation_artifact": foundation_artifact,
        "pipeline": pipeline,
        "pipeline_path": pipeline_path,
        "plan": plan,
    }


def restart_pipeline(environment: dict[str, Any]) -> EvidenceTestPipeline:
    pipeline = EvidenceTestPipeline(
        operations_path=environment["database"],
        authority_gate=environment["gate"],
        pipeline_path=environment["pipeline_path"],
        repository_root=environment["project"],
        clock=lambda: PIPELINE_AT,
    )
    pipeline.initialize()
    return pipeline


def result(
    environment: dict[str, Any],
    level: str,
    *,
    verdict: str = "pass",
    exit_code: int | None = None,
    recorded_at: str | None = None,
    trace: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if level == "Foundation":
        started_at = FOUNDATION_STARTED
        completed_at = FOUNDATION_COMPLETED
        artifact = environment["foundation_artifact"]
        command = ["py", "-m", "unittest", "tests.foundation"]
    elif level == "Component":
        started_at = COMPONENT_STARTED
        completed_at = COMPONENT_COMPLETED
        artifact = environment["component_artifact"]
        command = ["py", "-m", "unittest", "tests.component"]
    else:
        raise AssertionError(f"Unsupported SF-403 fixture level: {level}")
    selected_trace = copy.deepcopy(
        trace
        if trace is not None
        else [
            {
                "sequence": 1,
                "level": level,
                "status": verdict,
                "elapsed_ms": 10,
            }
        ]
    )
    body = {
        "version": "1.0.0",
        "id": f"sf403-result-{level.lower()}",
        "plan_id": environment["plan"]["id"],
        "level": level,
        "command": command,
        "exit_code": (0 if verdict == "pass" else 1)
        if exit_code is None
        else exit_code,
        "verdict": verdict,
        "diff_sha256": repository_fingerprint(environment["project"])[
            "content_sha256"
        ],
        "artifacts": [
            {
                "id": f"sf403-artifact-{level.lower()}",
                "type": "test-evidence",
                "path": artifact.relative_to(environment["project"]).as_posix(),
                "sha256": sha256_file(artifact),
            }
        ],
        "trace": selected_trace,
        "trace_sha256": canonical_sha256(selected_trace),
        "started_at": started_at,
        "completed_at": completed_at,
        "recorded_at": recorded_at or completed_at,
        "content_sha256": None,
    }
    body["content_sha256"] = canonical_sha256(
        {key: value for key, value in body.items() if key != "content_sha256"}
    )
    return body


def evaluation_request(environment: dict[str, Any]) -> dict[str, Any]:
    return environment["pipeline"].request_evaluation(
        environment["plan"]["id"],
        evaluator_id="example-agentic-product-evaluator",
        requested_by=environment["parent_run"]["identity_id"],
    )


def evaluation(
    environment: dict[str, Any],
    request: dict[str, Any],
    *,
    verdict: str = "pass",
) -> dict[str, Any]:
    body = {
        "version": "1.0.0",
        "id": "sf403-independent-evaluation",
        "request_id": request["id"],
        "plan_id": environment["plan"]["id"],
        "executor_id": environment["child_run"]["identity_id"],
        "evaluator_id": request["evaluator_id"],
        "independent": True,
        "authority": "advisory-only",
        "verdict": verdict,
        "findings": [],
        "evidence_sha256": canonical_sha256(
            {
                "results_sha256": request["results_sha256"],
                "diff_sha256": request["diff_sha256"],
            }
        ),
        "evaluated_at": "2026-08-14T14:06:00+00:00",
        "content_sha256": None,
    }
    body["content_sha256"] = canonical_sha256(
        {key: value for key, value in body.items() if key != "content_sha256"}
    )
    return body


def complete_pipeline(environment: dict[str, Any]) -> dict[str, Any]:
    environment["pipeline"].ingest_result(result(environment, "Foundation"))
    environment["pipeline"].ingest_result(result(environment, "Component"))
    request = evaluation_request(environment)
    environment["pipeline"].record_evaluation(
        evaluation(environment, request)
    )
    return environment["pipeline"].complete(
        environment["plan"]["id"],
        outcome_record_ref="outcome:sf403-build-repair",
    )
