from __future__ import annotations

import base64
from contextlib import closing
import hashlib
from pathlib import Path
import sqlite3

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    ProjectionRuntime,
    validate_session_control_command,
    validate_session_control_record,
)
from elder_protocol.factory_operations._common import canonical_json
from elder_protocol.factory_operations.api_contracts import (
    canonical_content_sha256,
)
from elder_protocol.io import json_text


OBSERVED_AT = "2026-08-13T13:00:00+00:00"


def token(seed: bytes = b"o") -> str:
    return base64.urlsafe_b64encode(seed * 32).decode("ascii").rstrip("=")


def waiting_control_record() -> dict:
    payload = {"waiting_reason": "owner-decision"}
    command = {
        "version": "1.0.0",
        "control_id": "session-control-sf300-owner-wait",
        "idempotency_key": "sf300-owner-wait",
        "operation": "wait",
        "project_id": "project-one",
        "run_id": "run-" + "1" * 32,
        "worker_session_id": "worker-session-" + "2" * 32,
        "workspace_id": "workspace-" + "3" * 32,
        "workspace_binding_sha256": "4" * 64,
        "session_generation": 1,
        "requested_by_identity_id": "founder",
        "submitted_at": "2026-08-12T12:00:00+00:00",
        "deadline_at": "2026-08-12T12:30:00+00:00",
        "reason": "Wait for one explicit owner decision.",
        "payload": payload,
        "payload_sha256": canonical_sha256(payload),
    }
    validate_session_control_command(command)
    body = {
        "version": "1.0.0",
        "control_id": command["control_id"],
        "command": command,
        "status": "waiting-owner",
        "record_version": 1,
        "attempt_count": 1,
        "lease_generation": 1,
        "lease": None,
        "current_step": None,
        "external_effect_started": False,
        "result": None,
        "last_error": None,
        "waiting_reason": "owner-decision",
        "continuation_of": None,
        "continued_by": None,
        "created_at": command["submitted_at"],
        "updated_at": "2026-08-12T12:05:00+00:00",
        "completed_at": None,
    }
    record = {**body, "content_sha256": canonical_sha256(body)}
    return validate_session_control_record(record)


def create_operations_store(path: Path) -> Path:
    FactoryOperationsBootstrap(path).initialize()
    ProjectionRuntime(path).rebuild_all()
    return path


def create_session_store(path: Path) -> Path:
    record = waiting_control_record()
    command = record["command"]
    with closing(sqlite3.connect(path)) as connection:
        connection.executescript(
            """
            CREATE TABLE session_controls (
                control_id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                run_id TEXT NOT NULL,
                worker_session_id TEXT NOT NULL,
                session_generation INTEGER NOT NULL,
                idempotency_key TEXT NOT NULL,
                operation TEXT NOT NULL,
                status TEXT NOT NULL,
                record_version INTEGER NOT NULL,
                attempt_count INTEGER NOT NULL,
                lease_owner TEXT,
                lease_generation INTEGER NOT NULL,
                lease_expires_at TEXT,
                record_json TEXT NOT NULL,
                content_sha256 TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                completed_at TEXT
            );
            CREATE TABLE session_control_history (
                control_id TEXT NOT NULL,
                record_version INTEGER NOT NULL,
                operation TEXT NOT NULL,
                snapshot_json TEXT NOT NULL,
                content_sha256 TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY(control_id, record_version)
            );
            """
        )
        connection.execute(
            """
            INSERT INTO session_controls(
                control_id, project_id, run_id, worker_session_id,
                session_generation, idempotency_key, operation, status,
                record_version, attempt_count, lease_owner, lease_generation,
                lease_expires_at, record_json, content_sha256, created_at,
                updated_at, completed_at
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record["control_id"],
                command["project_id"],
                command["run_id"],
                command["worker_session_id"],
                command["session_generation"],
                command["idempotency_key"],
                command["operation"],
                record["status"],
                record["record_version"],
                record["attempt_count"],
                None,
                record["lease_generation"],
                None,
                canonical_json(record),
                record["content_sha256"],
                record["created_at"],
                record["updated_at"],
                record["completed_at"],
            ),
        )
        connection.execute(
            """
            INSERT INTO session_control_history(
                control_id, record_version, operation, snapshot_json,
                content_sha256, created_at
            ) VALUES(?, ?, ?, ?, ?, ?)
            """,
            (
                record["control_id"],
                record["record_version"],
                "wait",
                canonical_json(record),
                record["content_sha256"],
                record["updated_at"],
            ),
        )
        connection.commit()
    return path


def create_recovery_store(
    path: Path,
    *,
    include_unbound_orphan: bool = False,
) -> Path:
    with closing(sqlite3.connect(path)) as connection:
        connection.executescript(
            """
            CREATE TABLE worker_recovery_cases (
                case_id TEXT PRIMARY KEY,
                control_id TEXT NOT NULL,
                control_record_version INTEGER NOT NULL,
                status TEXT NOT NULL,
                disposition TEXT,
                record_version INTEGER NOT NULL,
                record_json TEXT NOT NULL,
                content_sha256 TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                resolved_at TEXT
            );
            CREATE TABLE worker_recovery_case_history (
                case_id TEXT NOT NULL,
                record_version INTEGER NOT NULL,
                operation TEXT NOT NULL,
                snapshot_json TEXT NOT NULL,
                content_sha256 TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY(case_id, record_version)
            );
            CREATE TABLE worker_recovery_orphans (
                orphan_id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                status TEXT NOT NULL,
                record_json TEXT NOT NULL,
                content_sha256 TEXT NOT NULL,
                observed_at TEXT NOT NULL
            );
            CREATE TABLE sf300_change_marker (
                marker_id INTEGER PRIMARY KEY,
                value INTEGER NOT NULL
            );
            INSERT INTO sf300_change_marker(marker_id, value) VALUES(1, 0);
            """
        )
        if include_unbound_orphan:
            identity = {
                "kind": "missing-session-control",
                "project_id": None,
                "run_id": None,
                "worker_session_id": None,
                "workspace_id": None,
                "tick_id": "continuation-tick-" + "5" * 24,
                "control_id": None,
                "status": "owner-required",
                "reason": "continuation-tick-has-no-session-control",
            }
            body = {
                "version": "1.0.0",
                "orphan_id": (
                    "worker-recovery-orphan-"
                    + canonical_sha256(identity)[:24]
                ),
                **identity,
                "observed_at": "2026-08-12T12:06:00+00:00",
            }
            orphan = {
                **body,
                "content_sha256": canonical_sha256(body),
            }
            connection.execute(
                """
                INSERT INTO worker_recovery_orphans(
                    orphan_id, kind, status, record_json,
                    content_sha256, observed_at
                ) VALUES(?, ?, ?, ?, ?, ?)
                """,
                (
                    orphan["orphan_id"],
                    orphan["kind"],
                    orphan["status"],
                    canonical_json(orphan),
                    orphan["content_sha256"],
                    orphan["observed_at"],
                ),
            )
        connection.commit()
    return path


def auth_policy(path: Path, raw_token: str) -> Path:
    policy = {
        "version": "1.0.0",
        "policy_id": "operations-api-auth-sf300",
        "issued_at": "2026-08-13T00:00:00+00:00",
        "expires_at": "2099-01-01T00:00:00+00:00",
        "clients": [
            {
                "client_id": "owner-control-room",
                "kind": "owner-ui",
                "identity_id": "identity:owner-control-room",
                "enabled": True,
                "bearer_token_sha256": hashlib.sha256(
                    raw_token.encode("ascii")
                ).hexdigest(),
                "project_ids": ["project-one"],
                "route_ids": ["owner-inbox-get"],
                "global_route_ids": ["owner-inbox-get"],
            }
        ],
        "content_sha256": "",
    }
    policy["content_sha256"] = canonical_content_sha256(policy)
    target = path / "sf300-auth-policy.json"
    target.write_text(json_text(policy), encoding="utf-8")
    return target
