from __future__ import annotations

import base64
import copy
import hashlib
import json
import threading
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from elder_protocol.autonomy import (
    calculate_effective_autonomy,
    canonical_sha256,
    consume_qualification,
)
from elder_protocol.autonomy_runtime import (
    match_autonomy_work_item,
    replay_certification,
    simulate_autonomy_work_item,
)
from elder_protocol.factory_operations import (
    SupervisedDeliveryService,
    supervised_delivery_sources_sha256,
)
from elder_protocol.io import load_json, sha256_file
from elder_protocol.constants import PROTOCOL_DIR
from tests._sf403_support import (
    LEASE_TOKEN,
    build_environment as build_evidence_environment,
    complete_pipeline,
)
from tests.component import test_p4_7_qualification as p47
from tests.component import test_p5_0_autonomy as p50
from tests.component.test_p5_1_p5_2_autonomy import (
    RecordingSubmitter,
    event,
    finalize,
    signed_authority_evidence,
)


DELIVERY_AT = datetime(2026, 8, 14, 14, 7, tzinfo=UTC)
BASELINE_SOURCE = (
    "def repaired_component( ) -> str:\n"
    "    return  \"verified\"\n"
)


class MutableClock:
    def __init__(self, value: datetime = DELIVERY_AT):
        self.value = value

    def __call__(self) -> str:
        return self.value.isoformat()


class CountingSubmitter(RecordingSubmitter):
    def __init__(self, response_overrides: dict | None = None) -> None:
        super().__init__(response_overrides)
        self.calls = 0
        self._lock = threading.Lock()

    def submit(self, packet: dict) -> dict:
        with self._lock:
            self.calls += 1
        response = super().submit(packet)
        if "repository" not in self.response_overrides:
            response["repository"] = "fixture/product-one"
        if "url" not in self.response_overrides:
            response["url"] = (
                "https://git.example.test/fixture/product-one/pull/42"
            )
        return response


def _sign_statement(
    record: dict[str, Any],
    private_key: Ed25519PrivateKey,
) -> dict[str, Any]:
    statement = {
        key: value
        for key, value in record.items()
        if key not in {"attestation", "content_sha256"}
    }
    statement_bytes = p47.canonical_bytes(statement)
    record["attestation"] = {
        "signer_id": "verifier-key-1",
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(
            statement_bytes
        ).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement_bytes)
        ).decode("ascii"),
    }
    record["content_sha256"] = p47.content_digest(record)
    return record


def _qualification_context(
    workspace: Path,
    *,
    consumed_at: datetime,
    expires_at: datetime | None = None,
) -> dict[str, Any]:
    private_key = Ed25519PrivateKey.generate()
    maturity = p47.simple_maturity()
    hosted_policy = p47.qualification_policy(private_key)
    issued_at = consumed_at - timedelta(hours=1)
    records = []
    for index, gate_id in enumerate(
        [
            "l0-capability",
            "l0-evidence",
            "l1-capability",
            "l1-evidence",
            "l2-capability",
            "l2-evidence",
        ],
        start=1,
    ):
        record = p47.signed_record(
            workspace,
            private_key,
            gate_id=gate_id,
            index=index,
            issued_at=issued_at,
        )
        record["project_id"] = "product-one"
        if expires_at is not None:
            record["expires_at"] = expires_at.isoformat()
        records.append(_sign_statement(record, private_key))
    manifest = p47.write_bundle(
        workspace,
        records,
        private_key,
        issued_at=issued_at,
    )
    bundle = json.loads(manifest.read_text(encoding="utf-8"))
    bundle["project_id"] = "product-one"
    if expires_at is not None:
        bundle["expires_at"] = expires_at.isoformat()
    _sign_statement(bundle, private_key)
    manifest.write_text(
        json.dumps(bundle, indent=2) + "\n",
        encoding="utf-8",
    )
    autonomy_policy = p50.fixture_autonomy_policy(hosted_policy, maturity)
    checks = {
        name: {"checked_at": consumed_at.isoformat(), "present": False}
        for name in ["contradiction", "suspension", "revocation"]
    }
    consumption = consume_qualification(
        manifest,
        hosted_policy,
        maturity,
        autonomy_policy,
        project_id="product-one",
        environment="production",
        artifact_sha256="a" * 64,
        requested_level="L2",
        state_checks=checks,
        at=consumed_at.isoformat(),
    )
    return {
        "autonomy_policy": autonomy_policy,
        "consumption": consumption,
        "manifest": manifest,
        "qualification_policy": hosted_policy,
        "maturity_model": maturity,
        "state_checks": checks,
        "artifact_sha256": "a" * 64,
        "private_key": private_key,
    }


def _work_item(environment: dict[str, Any]) -> dict[str, Any]:
    return finalize(
        {
            "version": "0.5.1",
            "work_item_id": environment["work"]["work_item"]["id"],
            "project_id": environment["work"]["work_item"]["project_id"],
            "parent_change_class": "internal-code",
            "autonomy_class_id": "semantic-preserving-formatting",
            "objective": "Normalize formatting without changing component behavior.",
            "changes": [
                {
                    "path": "src/component/implementation.py",
                    "operation": "modify",
                    "existed_before": True,
                    "generated": False,
                    "production_code": True,
                    "test_support": False,
                    "generator_input": False,
                    "fixture": False,
                    "snapshot": False,
                    "configuration": False,
                    "before_sha256": hashlib.sha256(
                        BASELINE_SOURCE.encode("utf-8")
                    ).hexdigest(),
                    "after_sha256": sha256_file(environment["change"]),
                }
            ],
            "tool": {
                "id": "fixture-formatter",
                "digest_sha256": "7" * 64,
                "rule_ids": [],
            },
            "checks": [
                {
                    "name": name,
                    "status": "passed",
                    "evidence": [f"check:{index}"],
                }
                for index, name in enumerate(
                    [
                        "formatter digest",
                        "language adapter",
                        "semantic equivalence",
                        "ordered test ladder",
                    ],
                    start=1,
                )
            ],
            "observed_effects": [],
            "generator_inputs_unchanged": True,
            "semantic_equivalence": {
                "mode": "language-adapter",
                "status": "verified",
                "evidence": ["semantic:fixture-adapter"],
            },
            "evidence_plan": [
                "Run the complete ordered ladder and independent evaluation."
            ],
        }
    )


def _certification(
    consumption: dict[str, Any],
    *,
    active: bool,
    issued_at: datetime,
) -> dict[str, Any]:
    return finalize(
        {
            "version": "0.5.1",
            "certification_id": "CERT-SF404",
            "project_id": "product-one",
            "environment": "production",
            "autonomy_class_id": "semantic-preserving-formatting",
            "certification_level": "L2",
            "status": "active" if active else "candidate",
            "scope_paths": ["src/component/implementation.py"],
            "tool_bindings": [
                {
                    "id": "fixture-formatter",
                    "digest_sha256": "7" * 64,
                    "rule_ids": [],
                }
            ],
            "issued_by": "fixture-architecture-owner",
            "issuer_role": "architecture-owner",
            "evaluator_id": "example-agentic-product-evaluator",
            "issued_at": issued_at.isoformat(),
            "valid_from": issued_at.isoformat(),
            "valid_until": (issued_at + timedelta(days=10)).isoformat(),
            "qualification_consumption_sha256": consumption["content_sha256"],
            "incident_budget_id": "BUDGET-SF404",
            "evidence": ["evaluation:sf404"],
        }
    )


def _budget(issued_at: datetime) -> dict[str, Any]:
    return finalize(
        {
            "version": "0.5.1",
            "budget_id": "BUDGET-SF404",
            "certification_id": "CERT-SF404",
            "autonomy_class_id": "semantic-preserving-formatting",
            "window_started_at": issued_at.isoformat(),
            "window_ends_at": (issued_at + timedelta(days=30)).isoformat(),
            "maximum_incidents": 0,
            "incident_count": 0,
            "maximum_rollbacks": 0,
            "rollback_count": 0,
            "exhausted": False,
            "evidence": [],
        }
    )


def _signed_hosted_evidence(
    private_key: Ed25519PrivateKey,
    *,
    environment: dict[str, Any],
    completion: dict[str, Any],
    issued_at: datetime,
    protected_branch: bool = True,
) -> dict[str, Any]:
    stored_results = {
        item["level"]: item
        for item in environment["pipeline"].repository.results(
            environment["plan"]["id"]
        )
    }
    results = []
    for index, level in enumerate(
        ["Foundation", "Component", "Integration", "Workflow", "Stress"],
        start=1,
    ):
        stored = stored_results.get(level)
        results.append(
            {
                "level": level,
                "status": "passed",
                "command": (
                    stored["command"]
                    if stored is not None
                    else ["py", "-m", "unittest", f"tests.{level.lower()}"]
                ),
                "evidence_sha256": (
                    stored["content_sha256"]
                    if stored is not None
                    else str(index) * 64
                ),
            }
        )
    evaluation = environment["pipeline"].owner_view(
        environment["plan"]["id"]
    )["evaluation"]
    evidence = {
        "version": "0.5.1",
        "evidence_id": "HOSTED-GIT-SF404",
        "project_id": "product-one",
        "provider": "fixture-ci",
        "repository": "fixture/product-one",
        "pull_request_url_prefix": (
            "https://git.example.test/fixture/product-one/pull/"
        ),
        "git_object_format": "sha1",
        "base_branch": "main",
        "head_branch": "work/semantic-formatting-sf404",
        "base_revision": "3" * 40,
        "head_revision": "4" * 40,
        "diff_sha256": completion["diff_sha256"],
        "workspace": "/isolated/worktrees/semantic-formatting-sf404",
        "changed_paths": ["src/component/implementation.py"],
        "changes": [
            {
                "path": "src/component/implementation.py",
                "operation": "modify",
                "before_sha256": hashlib.sha256(
                    BASELINE_SOURCE.encode("utf-8")
                ).hexdigest(),
                "after_sha256": sha256_file(environment["change"]),
            }
        ],
        "test_results": results,
        "executor_id": environment["child_run"]["identity_id"],
        "evaluator_id": evaluation["evaluator_id"],
        "independent_evaluation": {
            "status": "passed",
            "report_sha256": evaluation["content_sha256"],
        },
        "controls": {
            "remote-present": "verified",
            "protected-base-branch": (
                "verified" if protected_branch else "unverified"
            ),
            "required-checks": "verified",
            "signed-provenance": "verified",
            "external-identity": "verified",
            "isolated-workspace": "verified",
            "ordered-tests": "verified",
            "independent-evaluation": "verified",
        },
        "producer_identity": "fixture-hosted-git-service",
        "source_uri": (
            "https://ci.example.test/repositories/"
            "fixture/product-one/pulls/42"
        ),
        "issued_at": issued_at.isoformat(),
        "expires_at": (issued_at + timedelta(minutes=20)).isoformat(),
    }
    return _sign_statement(evidence, private_key)


def _sources(
    workspace: Path,
    environment: dict[str, Any],
    *,
    active_certification: bool = True,
    expired_qualification: bool = False,
) -> dict[str, Any]:
    consumed_at = DELIVERY_AT
    expires_at = None
    if expired_qualification:
        consumed_at = DELIVERY_AT - timedelta(minutes=2)
        expires_at = DELIVERY_AT - timedelta(minutes=1)
    context = _qualification_context(
        workspace / "qualification",
        consumed_at=consumed_at,
        expires_at=expires_at,
    )
    registry = load_json(PROTOCOL_DIR / "autonomy-classes.json")
    change_classes = load_json(PROTOCOL_DIR / "change-classes.json")
    work_item = _work_item(environment)
    issued_at = consumed_at - timedelta(minutes=5)
    certification = _certification(
        context["consumption"],
        active=active_certification,
        issued_at=issued_at,
    )
    budget = _budget(issued_at)
    autonomy_class = next(
        item
        for item in registry["classes"]
        if item["id"] == certification["autonomy_class_id"]
    )
    issued = event(
        certification,
        sequence=1,
        event_type="issued",
        occurred_at=issued_at,
        previous=None,
        payload={
            "certification_sha256": certification["content_sha256"],
            "initial_status": "candidate",
        },
    )
    events = [issued]
    if active_certification:
        events.append(
            event(
                certification,
                sequence=2,
                event_type="activated",
                occurred_at=issued_at + timedelta(minutes=1),
                previous=issued["content_sha256"],
                payload={
                    "qualification_consumption_sha256": context[
                        "consumption"
                    ]["content_sha256"]
                },
            )
        )
    replay = replay_certification(
        certification,
        autonomy_class,
        events,
        policy=context["autonomy_policy"],
        at=consumed_at.isoformat(),
    )
    match = match_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=context["autonomy_policy"],
    )
    simulation = simulate_autonomy_work_item(
        work_item,
        registry,
        certification=certification,
        policy=context["autonomy_policy"],
    )
    effective = calculate_effective_autonomy(
        context["autonomy_policy"],
        registry,
        change_classes,
        project_id="product-one",
        project_autonomy_ceiling="L2",
        autonomy_class_id=work_item["autonomy_class_id"],
        certification=certification,
        qualification_consumption=context["consumption"],
        incident_budget=budget,
        suspensions=[],
        revocations=[],
        at=consumed_at.isoformat(),
    )
    chain = {
        "policy": context["autonomy_policy"],
        "consumption": context["consumption"],
        "certification": certification,
        "budget": budget,
        "context": context,
        "work_item": work_item,
        "match": match,
        "simulation": simulation,
        "effective": effective,
        "certification_events": events,
        "certification_replay": replay,
    }
    authority_source = {
        "version": "0.5.1",
        "id": "elder-canonical-autonomy-authority-source-v1",
        "projects": [
            {
                "project_id": "product-one",
                "project_autonomy_ceiling": "L2",
                "autonomy_policy_sha256": canonical_sha256(chain["policy"]),
                "autonomy_classes_sha256": canonical_sha256(registry),
                "change_classes_sha256": canonical_sha256(change_classes),
                "qualification_policy_sha256": canonical_sha256(
                    context["qualification_policy"]
                ),
                "maturity_model_sha256": canonical_sha256(
                    context["maturity_model"]
                ),
                "status": "active",
            }
        ],
    }
    chain["authority_source"] = authority_source
    chain["authority_evidence"] = signed_authority_evidence(
        context["private_key"],
        chain=chain,
        registry=registry,
        change_classes=change_classes,
        evaluated_at=consumed_at,
    )
    sources = {
        "policy": chain["policy"],
        "work_item": work_item,
        "registry": registry,
        "change_classes": change_classes,
        "project_autonomy_ceiling": "L2",
        "certification": certification,
        "certification_events": events,
        "certification_replay_report": replay,
        "qualification_consumption": context["consumption"],
        "incident_budget": budget,
        "suspensions": [],
        "revocations": [],
        "authority_evidence": chain["authority_evidence"],
        "qualification_manifest_path": str(context["manifest"]),
        "qualification_policy": context["qualification_policy"],
        "maturity_model": context["maturity_model"],
        "qualification_state_checks": context["state_checks"],
        "artifact_sha256": context["artifact_sha256"],
        "effective_autonomy_report": effective,
        "match_report": match,
        "simulation_report": simulation,
    }
    return {
        "sources": sources,
        "authority_source": authority_source,
        "private_key": context["private_key"],
    }


def build_environment(
    workspace: Path,
    *,
    active_certification: bool = True,
    expired_qualification: bool = False,
    protected_branch: bool = True,
    prepare: bool = True,
) -> dict[str, Any]:
    environment = build_evidence_environment(
        workspace,
        repository_fixture="semantic-formatting",
    )
    completion = complete_pipeline(environment)
    p5 = _sources(
        workspace,
        environment,
        active_certification=active_certification,
        expired_qualification=expired_qualification,
    )
    authority_project = p5["authority_source"]["projects"][0]
    authority_patcher = patch(
        "elder_protocol.autonomy_runtime._load_canonical_autonomy_authority",
        return_value=(p5["authority_source"], authority_project),
    )
    authority_patcher.start()
    clock = MutableClock()
    service = SupervisedDeliveryService(
        operations_path=environment["database"],
        authority_gate=environment["gate"],
        evidence_pipeline=environment["pipeline"],
        delivery_path=workspace / "supervised-delivery.db",
        clock=clock,
    )
    service.initialize()
    sources = p5["sources"]
    request = {
        "version": "1.0.0",
        "request_id": "sf404-delivery-request",
        "factory_work_item_id": environment["work"]["work_item"]["id"],
        "authority_request_id": environment["authority"]["decision"][
            "request_id"
        ],
        "evidence_plan_id": environment["plan"]["id"],
        "requested_by": environment["parent_run"]["identity_id"],
        "trusted_sources_sha256": supervised_delivery_sources_sha256(sources),
        "lease_token": LEASE_TOKEN,
        "authorized_context_sha256": environment["context"]["packet"][
            "content_sha256"
        ],
        "requested_at": clock(),
    }
    authorization = service.authorize(request, sources)
    execution = None
    prepared = authorization
    if authorization["status"] == "authorized":
        record = service.repository.get(request["request_id"])
        hosted = _signed_hosted_evidence(
            p5["private_key"],
            environment=environment,
            completion=completion,
            issued_at=DELIVERY_AT,
            protected_branch=protected_branch,
        )
        execution = finalize(
            {
                "version": "0.5.1",
                "execution_id": "EXEC-SF404",
                "project_id": "product-one",
                "work_item_id": environment["work"]["work_item"]["id"],
                "lease_sha256": record["autonomy_lease"]["content_sha256"],
                "workspace": hosted["workspace"],
                "git_object_format": hosted["git_object_format"],
                "base_revision": hosted["base_revision"],
                "head_revision": hosted["head_revision"],
                "base_branch": hosted["base_branch"],
                "head_branch": hosted["head_branch"],
                "changed_paths": copy.deepcopy(hosted["changed_paths"]),
                "changes": copy.deepcopy(hosted["changes"]),
                "diff_sha256": hosted["diff_sha256"],
                "test_results": copy.deepcopy(hosted["test_results"]),
                "executor_id": hosted["executor_id"],
                "evaluator_id": hosted["evaluator_id"],
                "independent_evaluation": copy.deepcopy(
                    hosted["independent_evaluation"]
                ),
                "hosted_git_evidence": hosted,
                "evidence": [
                    completion["validated_evidence_ref"],
                    f"factory-diff:{completion['diff_sha256']}",
                    "tests:ordered",
                    "evaluation:independent",
                ],
            }
        )
        if prepare:
            prepared = service.prepare_packet(
                request,
                sources,
                execution,
                title="Normalize component formatting",
                body=(
                    "Bounded semantic formatting with ordered evidence and "
                    "human merge."
                ),
            )
    return {
        **environment,
        "authority_patcher": authority_patcher,
        "clock": clock,
        "completion": completion,
        "delivery_service": service,
        "delivery_request": request,
        "delivery_sources": sources,
        "delivery_authorization": authorization,
        "delivery_view": prepared,
        "execution": execution,
    }


def restart_service(environment: dict[str, Any]) -> SupervisedDeliveryService:
    service = SupervisedDeliveryService(
        operations_path=environment["database"],
        authority_gate=environment["gate"],
        evidence_pipeline=environment["pipeline"],
        delivery_path=environment["delivery_service"].repository.path,
        clock=environment["clock"],
    )
    service.initialize()
    return service
