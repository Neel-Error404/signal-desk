from __future__ import annotations

import os
import shutil
import sqlite3
import stat
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from elder_protocol.constants import ROOT


def tamper_sqlite_store(
    path: Path,
    statement: str,
    parameters: tuple[object, ...] = (),
) -> None:
    """Inject storage corruption while restoring the exact trigger contract."""
    connection = sqlite3.connect(path)
    try:
        triggers = connection.execute(
            """
            SELECT name, sql
            FROM sqlite_master
            WHERE type = 'trigger' AND sql IS NOT NULL
            ORDER BY name
            """
        ).fetchall()
        connection.execute("BEGIN IMMEDIATE")
        for name, _ in triggers:
            connection.execute(
                f'DROP TRIGGER "{str(name).replace(chr(34), chr(34) * 2)}"'
            )
        connection.execute(statement, parameters)
        for _, sql in triggers:
            connection.execute(sql)
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _remove_readonly(function: object, path: str, _: object) -> None:
    os.chmod(path, stat.S_IWRITE)
    function(path)


@contextmanager
def test_workspace(label: str) -> Iterator[Path]:
    root = ROOT / ".tmp" / "tests"
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{label}-{uuid.uuid4().hex}"
    path.mkdir()
    try:
        yield path
    finally:
        resolved_root = root.resolve()
        resolved_path = path.resolve()
        if resolved_root not in resolved_path.parents:
            raise RuntimeError(f"Refusing to remove test path outside .tmp: {resolved_path}")
        shutil.rmtree(resolved_path, onexc=_remove_readonly)


test_workspace.__test__ = False
