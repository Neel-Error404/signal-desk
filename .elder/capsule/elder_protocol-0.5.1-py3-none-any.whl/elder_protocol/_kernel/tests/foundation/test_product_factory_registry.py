from __future__ import annotations

import copy
import unittest

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    OPERATIONS_STORE_SCHEMA_VERSION,
    PRODUCT_FACTORY_REGISTRY_VERSION,
    validate_product_factory_registration,
)
from elder_protocol.io import load_json
from elder_protocol.schema_validation import validate_schema_catalog


def _registration() -> dict:
    return {
        "version": "1.0.0",
        "project_id": "example-agentic-product",
        "repository_root": str(ROOT),
        "profile_path": "examples/minimal-project-profile.json",
        "worker_policy": {
            "adapter_id": "codex",
            "max_concurrent_workers": 1,
            "approval_policy": "on-request",
            "sandbox_mode": "workspace-write",
            "network_access": False,
        },
        "integration_refs": [
            {
                "id": "owner-inbox",
                "kind": "manual",
                "reference": "manual:owner-inbox",
                "enabled": True,
            }
        ],
    }


class ProductFactoryRegistryFoundationTests(unittest.TestCase):
    def test_implementation_schema_catalog_is_valid_and_bounded(self) -> None:
        schemas = validate_schema_catalog(ROOT / "factory" / "operations")
        self.assertEqual(
            set(schemas),
            {
                "audit-replay-snapshot.schema.json",
                "continuation-goal-record.schema.json",
                "continuation-goal-request.schema.json",
                "continuation-heartbeat-record.schema.json",
                "continuation-schedule-record.schema.json",
                "continuation-tick-record.schema.json",
                "dispatch-dead-letter.schema.json",
                "durable-dispatch-record.schema.json",
                "durable-dispatch-submission.schema.json",
                "factory-capability-status.schema.json",
                "gate-c-qualification.schema.json",
                "gate-c-restart-manifest.schema.json",
                "journal-mutation-coverage.schema.json",
                "journal-source-registry.schema.json",
                "learning-trajectory-source.schema.json",
                "learning-trajectory.schema.json",
                "operations-api-binding-registry.schema.json",
                "operations-api-auth-policy.schema.json",
                "operations-api-error.schema.json",
                "operations-api-health.schema.json",
                "operations-api-idempotency-record.schema.json",
                "operations-api-liveness.schema.json",
                "operations-api-mutation-payload.schema.json",
                "operations-api-mutation-request.schema.json",
                "operations-api-readiness.schema.json",
                "operations-api-response.schema.json",
                "operations-api-route-registry.schema.json",
                "operations-api-runtime-record.schema.json",
                "operations-backup-manifest.schema.json",
                "operations-journal-cursor.schema.json",
                "operations-journal-entry.schema.json",
                "operations-journal-projection-document.schema.json",
                "owner-attention-item.schema.json",
                "owner-inbox-snapshot.schema.json",
                "owner-metrics-snapshot.schema.json",
                "owner-portfolio-snapshot.schema.json",
                "owner-decision-effect.schema.json",
                "owner-decision-mutation-result.schema.json",
                "owner-decision-page.schema.json",
                "owner-decision-request-input.schema.json",
                "owner-decision-request.schema.json",
                "owner-decision-response.schema.json",
                "owner-decision-state.schema.json",
                "owner-decision.schema.json",
                "product-factory-registration.schema.json",
                "product-factory-registry-record.schema.json",
                "product-workspace-policy.schema.json",
                "projection-page-token.schema.json",
                "projection-query-result.schema.json",
                "projection-registry.schema.json",
                "public-event-mapping.schema.json",
                "run-artifact-reference.schema.json",
                "run-backup-manifest.schema.json",
                "run-binding-record.schema.json",
                "run-binding-submission.schema.json",
                "run-checkpoint-reference.schema.json",
                "run-checkpoint-worker-observation.schema.json",
                "run-elder-observation.schema.json",
                "run-external-step.schema.json",
                "run-lifecycle-authority-mapping.schema.json",
                "run-lifecycle-command-result.schema.json",
                "run-lifecycle-command.schema.json",
                "session-control-command.schema.json",
                "session-control-record.schema.json",
                "signal-intake-envelope.schema.json",
                "signal-intake-record.schema.json",
                "transition-authority-mapping.schema.json",
                "worker-recovery-attempt.schema.json",
                "worker-recovery-case.schema.json",
                "worker-recovery-orphan.schema.json",
                "work-item-ledger-record.schema.json",
                "work-item-specification.schema.json",
                "work-item-transition-command.schema.json",
                "work-item-transition-record.schema.json",
                "work-room-input-result.schema.json",
                "work-room-input.schema.json",
                "work-room-note.schema.json",
                "work-room-snapshot.schema.json",
                "workspace-inspection.schema.json",
                "workspace-runtime-manifest.schema.json",
                "workspace-sandbox-spec.schema.json",
            },
        )

    def test_registration_contract_matches_phase_one_constraints(self) -> None:
        configuration = validate_product_factory_registration(_registration())
        self.assertEqual(configuration["version"], PRODUCT_FACTORY_REGISTRY_VERSION)
        self.assertEqual(
            configuration["worker_policy"]["max_concurrent_workers"],
            1,
        )
        self.assertFalse(configuration["worker_policy"]["network_access"])
        self.assertEqual(OPERATIONS_STORE_SCHEMA_VERSION, 1)

    def test_registration_schema_rejects_provider_and_capacity_drift(self) -> None:
        invalid = _registration()
        invalid["worker_policy"]["adapter_id"] = "prime"
        with self.assertRaisesRegex(ProtocolError, "does not match"):
            validate_product_factory_registration(invalid)

        invalid = _registration()
        invalid["worker_policy"]["max_concurrent_workers"] = 2
        with self.assertRaisesRegex(ProtocolError, "does not match"):
            validate_product_factory_registration(invalid)

        invalid = _registration()
        invalid["worker_policy"]["network_access"] = True
        with self.assertRaisesRegex(ProtocolError, "does not match"):
            validate_product_factory_registration(invalid)

    def test_registration_rejects_secret_fields_references_and_values(self) -> None:
        invalid = _registration()
        invalid["api_key_ref"] = "vault:factory-key"
        with self.assertRaisesRegex(ProtocolError, "secret field or secret reference"):
            validate_product_factory_registration(invalid)

        invalid = _registration()
        invalid["integration_refs"][0]["reference"] = "vault:factory-key"
        with self.assertRaisesRegex(ProtocolError, "secret reference scheme"):
            validate_product_factory_registration(invalid)

        invalid = _registration()
        invalid["integration_refs"][0]["reference"] = (
            "manual:ghp_1234567890abcdef"
        )
        with self.assertRaisesRegex(ProtocolError, "secret-like material"):
            validate_product_factory_registration(invalid)

    def test_registration_rejects_duplicate_integration_ids(self) -> None:
        invalid = _registration()
        invalid["integration_refs"].append(
            copy.deepcopy(invalid["integration_refs"][0])
        )
        with self.assertRaisesRegex(ProtocolError, "must be unique"):
            validate_product_factory_registration(invalid)

    def test_canonical_product_factory_payload_remains_unextended(self) -> None:
        domain = load_json(ROOT / "factory" / "factory-domain.json")
        product_factory = next(
            item for item in domain["entities"] if item["id"] == "product-factory"
        )
        self.assertEqual(
            product_factory["required_payload_fields"],
            ["name", "profile_ref", "autonomy_ceiling"],
        )
        self.assertNotIn("repository_root", product_factory["required_payload_fields"])


if __name__ == "__main__":
    unittest.main()
