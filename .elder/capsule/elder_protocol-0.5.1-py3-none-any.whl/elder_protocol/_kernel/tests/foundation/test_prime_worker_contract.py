from __future__ import annotations

from pathlib import Path
import unittest

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_workers import (
    PRIME_AGENT_VERSION,
    PRIME_DAEMON_PROTOCOL_VERSION,
    PRIME_DAEMON_SCHEMA_REVISION,
    PRIME_SOURCE_REVISION,
    WORKER_OPERATIONS,
    PrimeRuntimeConfig,
    PrimeWorkerAdapter,
    validate_worker_capabilities,
)
from tests._prime_support import DeterministicPrimeRuntime, GIT_BASH
from tests._support import test_workspace


class PrimeWorkerContractFoundationTests(unittest.TestCase):
    def test_runtime_pins_and_windows_shell_are_fail_closed(self) -> None:
        with test_workspace("sf204-foundation-config") as workspace:
            agent_dir = (workspace / "agent").resolve()
            invalid = (
                PrimeRuntimeConfig(
                    executable=("prime-agent",),
                    agent_dir=agent_dir,
                    socket_path="socket",
                    bash_path=GIT_BASH,
                    expected_version="0.6.0",
                ),
                PrimeRuntimeConfig(
                    executable=("prime-agent",),
                    agent_dir=agent_dir,
                    socket_path="socket",
                    bash_path=GIT_BASH,
                    expected_source_revision="0" * 40,
                ),
                PrimeRuntimeConfig(
                    executable=("prime-agent",),
                    agent_dir=agent_dir,
                    socket_path="socket",
                    bash_path=GIT_BASH,
                    protocol_version=PRIME_DAEMON_PROTOCOL_VERSION - 1,
                ),
                PrimeRuntimeConfig(
                    executable=("prime-agent",),
                    agent_dir=agent_dir,
                    socket_path="socket",
                    bash_path=workspace / "missing-bash.exe",
                ),
            )
            for config in invalid:
                with self.subTest(config=config):
                    with self.assertRaises(ProtocolError):
                        config.validate()

    def test_capabilities_preserve_exact_sf200_contract_without_authority(
        self,
    ) -> None:
        with test_workspace("sf204-foundation-capabilities") as workspace:
            provider_workspace = workspace / "provider"
            provider_workspace.mkdir()
            runtime = DeterministicPrimeRuntime(workspace)
            adapter = PrimeWorkerAdapter(
                workspace / "worker.db",
                workspace_bindings={
                    "workspace-sf200": provider_workspace.resolve()
                },
                runtime=runtime,
            )
            capabilities = validate_worker_capabilities(adapter.capabilities())
            self.assertEqual(
                set(capabilities["supported_operations"]),
                set(WORKER_OPERATIONS),
            )
            self.assertEqual(
                capabilities["adapter_id"],
                "elder-prime-worker",
            )
            self.assertEqual(
                capabilities["canonical_write_authority"],
                "none",
            )

    def test_ratified_prime_source_surface_is_still_pinned(self) -> None:
        source = ROOT / ".tmp" / "factory-research" / "prime-agent"
        package = source / "package.json"
        protocol = (
            source
            / "packages"
            / "coding-agent"
            / "src"
            / "modes"
            / "daemon"
            / "daemon-protocol.ts"
        )
        journal = protocol.with_name("command-recovery-journal.ts")
        self.assertTrue(package.is_file())
        self.assertTrue(protocol.is_file())
        self.assertTrue(journal.is_file())
        package_text = package.read_text(encoding="utf-8")
        protocol_text = protocol.read_text(encoding="utf-8")
        journal_text = journal.read_text(encoding="utf-8")
        self.assertIn(f'"version": "{PRIME_AGENT_VERSION}"', package_text)
        self.assertIn(
            f"DAEMON_PROTOCOL_VERSION = {PRIME_DAEMON_PROTOCOL_VERSION}",
            protocol_text,
        )
        self.assertIn(
            f"DAEMON_SCHEMA_REVISION = {PRIME_DAEMON_SCHEMA_REVISION}",
            protocol_text,
        )
        self.assertIn("clientId, commandId", journal_text)
        self.assertEqual(
            PRIME_SOURCE_REVISION,
            "b9a4461149419156599d60174dddf15458e2b9ee",
        )

    def test_sf204_files_are_package_visible(self) -> None:
        expected = (
            ROOT / "elder_protocol" / "factory_workers" / "prime_worker.py",
            ROOT
            / "elder_protocol"
            / "factory_workers"
            / "prime_daemon_bridge.mjs",
            ROOT / "docs" / "software-factory" / "SF-204-task-packet.md",
            ROOT / "docs" / "software-factory" / "SF-204-design.md",
            ROOT
            / "docs"
            / "software-factory"
            / "SF-204-test-reproduction.md",
            ROOT
            / "docs"
            / "software-factory"
            / "evidence"
            / "SF-204.md",
        )
        self.assertTrue(all(path.is_file() for path in expected))


if __name__ == "__main__":
    unittest.main()
