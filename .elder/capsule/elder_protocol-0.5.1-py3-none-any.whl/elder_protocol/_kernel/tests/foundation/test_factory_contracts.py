from __future__ import annotations

import copy
import unittest
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_contracts import (
    FACTORY_CONTRACT_VERSION,
    REQUIRED_ERRORS,
    REQUIRED_OPERATIONS,
    require_compatible_version,
    validate_adapter_request_data,
    validate_adapter_response_data,
    validate_cursor_window,
    validate_factory_command_data,
    validate_factory_contracts,
    validate_factory_contracts_data,
    validate_factory_event_data,
    validate_idempotent_replay,
)
from elder_protocol.io import load_json
from elder_protocol.schema_validation import validate_schema_catalog


FIXTURE_DIR = ROOT / "tests" / "fixtures" / "factory_contracts"
SHA256 = "a" * 64
TIME = "2026-08-07T12:00:00+00:00"


def _cursor(
    sequence: int = 1,
    *,
    generation: int = 1,
    event_id: str | None = "event-001",
) -> dict[str, Any]:
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "stream_id": "project-001-events",
        "generation": generation,
        "sequence": sequence,
        "event_id": event_id if sequence else None,
        "snapshot_sha256": SHA256,
        "issued_at": TIME,
    }


def _request(
    *,
    request_id: str = "request-001",
    operation: str = "send",
    mutability: str = "mutation",
) -> dict[str, Any]:
    payload = (
        {"cursor": _cursor(sequence=1, event_id="event-001")}
        if operation == "observe"
        else {"command": _command()}
    )
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "contract_id": "worker-adapter",
        "operation": operation,
        "request_id": request_id,
        "project_id": "project-001",
        "work_item_id": "work-item-001",
        "run_id": "run-001",
        "session_id": "session-001",
        "submitted_at": TIME,
        "deadline_at": "2026-08-07T12:05:00+00:00",
        "correlation_id": "correlation-001",
        "causation_id": None,
        "mutability": mutability,
        "idempotency_key": (
            "worker-send-project-001-command-001"
            if mutability == "mutation"
            else None
        ),
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _response(
    request: dict[str, Any],
    *,
    disposition: str = "accepted",
) -> dict[str, Any]:
    accepted_command = _command()
    accepted_command["status"] = "accepted"
    result = {"accepted_command": accepted_command}
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "contract_id": request["contract_id"],
        "operation": request["operation"],
        "request_id": request["request_id"],
        "request_sha256": canonical_sha256(request),
        "project_id": request["project_id"],
        "responded_at": TIME,
        "disposition": disposition,
        "operation_completed": False,
        "mutation_state": "not-started",
        "retry": "never",
        "source_of_truth": "adapter-observation",
        "result_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "result_sha256": canonical_sha256(result),
        "result": result,
        "error": None,
        "cursor": None,
        "original_response_sha256": None,
        "extensions": {},
    }


def _uncertain_response(request: dict[str, Any]) -> dict[str, Any]:
    response = _response(request, disposition="uncertain")
    response.update(
        {
            "mutation_state": "unknown",
            "retry": "reconcile",
            "result_sha256": None,
            "result": {},
            "error": {
                "code": "uncertain-mutation",
                "message": "The side effect may have occurred.",
                "details": {},
            },
        }
    )
    return response


def _stale_response() -> tuple[dict[str, Any], dict[str, Any]]:
    request = _request(operation="observe", mutability="read")
    response = _response(request, disposition="stale-cursor")
    response.update(
        {
            "mutation_state": "not-applicable",
            "retry": "refresh-cursor",
            "result_sha256": None,
            "result": {},
            "error": {
                "code": "stale-cursor",
                "message": "The requested cursor is outside retention.",
                "details": {},
            },
            "cursor": _cursor(sequence=10, event_id="event-010"),
        }
    )
    return request, response


def _command() -> dict[str, Any]:
    payload = {"instruction": "Run the bounded verification."}
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "command_id": "command-001",
        "project_id": "project-001",
        "work_item_id": "work-item-001",
        "run_id": "run-001",
        "worker_session_id": "session-001",
        "command_type": "worker.verify",
        "mutability": "mutation",
        "idempotency_key": "command-project-001-run-001-verify",
        "authority_ref": "elder://authority/001",
        "correlation_id": "correlation-001",
        "causation_id": None,
        "attempt": 1,
        "status": "pending",
        "submitted_at": TIME,
        "expires_at": "2026-08-07T12:05:00+00:00",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _event() -> dict[str, Any]:
    payload = {
        "command_id": "command-001",
        "command_status": "accepted",
    }
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "event_id": "event-001",
        "event_type": "command.accepted",
        "record_kind": "journal-entry",
        "authoritative": True,
        "source_event_id": None,
        "occurred_at": TIME,
        "recorded_at": TIME,
        "cursor": _cursor(),
        "correlations": {
            "product_id": None,
            "project_id": "project-001",
            "work_item_id": "work-item-001",
            "run_id": "run-001",
            "session_id": "session-001",
        },
        "actor": {"identity_id": "executor-001", "kind": "agent"},
        "source": {
            "plane": "factory-operations",
            "adapter_id": None,
            "source_ref": "journal:project-001:1",
        },
        "correlation_id": "correlation-001",
        "causation_id": "command-001",
        "idempotency_key": "command-project-001-run-001-verify",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _set_path(document: Any, path: list[Any], value: Any) -> None:
    target = document
    for item in path[:-1]:
        target = target[item]
    target[path[-1]] = value


class FactoryContractsFoundationTests(unittest.TestCase):
    def test_schema_catalog_and_contract_registry_are_valid(self) -> None:
        schemas = validate_schema_catalog(ROOT / "factory")
        self.assertEqual(
            set(schemas),
            {
                "factory-adapter-request.schema.json",
                "factory-adapter-response.schema.json",
                "factory-command.schema.json",
                "factory-contracts.schema.json",
                "factory-cursor.schema.json",
                "factory-domain.schema.json",
                "factory-entity.schema.json",
                "factory-event.schema.json",
                "operational-architecture.schema.json",
            },
        )
        registry = validate_factory_contracts()
        operations = {
            contract["id"]: {
                operation["name"]: operation["mutability"]
                for operation in contract["operations"]
            }
            for contract in registry["contracts"]
        }
        self.assertEqual(operations, REQUIRED_OPERATIONS)
        self.assertEqual(
            {error["code"] for error in registry["errors"]},
            set(REQUIRED_ERRORS),
        )

    def test_language_neutral_documents_validate(self) -> None:
        validate_factory_command_data(_command())
        validate_factory_event_data(_event())
        request = _request()
        validate_adapter_request_data(request)
        validate_adapter_response_data(_response(request), request=request)

    def test_version_and_cursor_compatibility_fail_closed(self) -> None:
        require_compatible_version("1.0.0", "1.0.0")
        with self.assertRaisesRegex(ProtocolError, "Incompatible"):
            require_compatible_version("1.1.0", "1.0.0")
        with self.assertRaisesRegex(ProtocolError, "Incompatible"):
            require_compatible_version("2.0.0", "1.0.0")

        minimum = _cursor(sequence=5, event_id="event-005")
        current = _cursor(sequence=10, event_id="event-010")
        self.assertEqual(
            validate_cursor_window(
                _cursor(sequence=6, event_id="event-006"),
                current,
                minimum,
            ),
            "available",
        )
        self.assertEqual(
            validate_cursor_window(
                _cursor(sequence=4, event_id="event-004"),
                current,
                minimum,
            ),
            "stale",
        )
        with self.assertRaisesRegex(ProtocolError, "future"):
            validate_cursor_window(
                _cursor(sequence=11, event_id="event-011"),
                current,
                minimum,
            )

    def test_inline_digests_and_secret_shaped_fields_are_rejected(self) -> None:
        command = _command()
        command["payload"]["instruction"] = "Changed after digest."
        with self.assertRaisesRegex(ProtocolError, "payload_sha256"):
            validate_factory_command_data(command)

        request = _request()
        request["payload"] = {"api_key": "must-not-cross-contracts"}
        request["payload_sha256"] = canonical_sha256(request["payload"])
        with self.assertRaisesRegex(ProtocolError, "secret-shaped"):
            validate_adapter_request_data(request)

        request = _request()
        request["extensions"] = {
            "example.provider/credential": "raw-secret-token"
        }
        with self.assertRaisesRegex(ProtocolError, "secret-shaped|secret-like"):
            validate_adapter_request_data(request)

        request = _request()
        request["extensions"] = {
            "example.provider/api_key_ref": "abc123"
        }
        with self.assertRaisesRegex(ProtocolError, "opaque URI-like reference"):
            validate_adapter_request_data(request)

        request["extensions"] = {
            "example.provider/api_key_ref": "vault://project/key-001"
        }
        validate_adapter_request_data(request)

        original = _request()
        retry = copy.deepcopy(original)
        retry["request_id"] = "request-002"
        changed_command = _command()
        changed_command["command_id"] = "command-002"
        retry["payload"] = {"command": changed_command}
        retry["payload_sha256"] = canonical_sha256(retry["payload"])
        with self.assertRaisesRegex(ProtocolError, "different payload"):
            validate_idempotent_replay(original, retry)

    def test_outcome_event_and_operation_matrices_fail_closed(self) -> None:
        request = _request()
        accepted = _response(request)
        accepted["mutation_state"] = "not-applied"
        with self.assertRaisesRegex(ProtocolError, "Accepted mutation"):
            validate_adapter_response_data(accepted, request=request)

        timeout = _response(request, disposition="timeout")
        timeout.update(
            {
                "mutation_state": "not-applied",
                "retry": "same-idempotency-key",
                "result_sha256": None,
                "result": {},
                "error": {
                    "code": "timeout",
                    "message": "Dispatch did not begin.",
                    "details": {},
                },
            }
        )
        timeout["disposition"] = "rejected"
        with self.assertRaisesRegex(ProtocolError, "requires disposition 'timeout'"):
            validate_adapter_response_data(timeout, request=request)

        observe_request = _request(operation="observe", mutability="read")
        duplicate = _response(observe_request, disposition="duplicate")
        duplicate.update(
            {
                "operation_completed": True,
                "mutation_state": "not-applicable",
                "result": {
                    "events": [],
                    "next_cursor": _cursor(2, event_id="event-002"),
                },
                "original_response_sha256": SHA256,
            }
        )
        duplicate["result_sha256"] = canonical_sha256(duplicate["result"])
        with self.assertRaisesRegex(ProtocolError, "only for idempotent mutations"):
            validate_adapter_response_data(duplicate, request=observe_request)

        observe_result = _response(observe_request, disposition="succeeded")
        observe_result.update(
            {
                "operation_completed": True,
                "mutation_state": "not-applicable",
                "result": {
                    "events": ["not-an-event"],
                    "next_cursor": _cursor(2, event_id="event-002"),
                },
            }
        )
        observe_result["result_sha256"] = canonical_sha256(
            observe_result["result"]
        )
        with self.assertRaisesRegex(ProtocolError, "factory-event"):
            validate_adapter_response_data(
                observe_result,
                request=observe_request,
            )

        wrong_request = _request()
        wrong_request["payload"] = {"provider_session": "prime-runtime"}
        wrong_request["payload_sha256"] = canonical_sha256(wrong_request["payload"])
        with self.assertRaisesRegex(ProtocolError, "request fields must be"):
            validate_adapter_request_data(wrong_request)

        wrong_nested = _request()
        wrong_nested["payload"] = {"command": "provider-command"}
        wrong_nested["payload_sha256"] = canonical_sha256(wrong_nested["payload"])
        with self.assertRaisesRegex(ProtocolError, "factory-command"):
            validate_adapter_request_data(wrong_nested)

        wrong_result = _response(request)
        wrong_result["result"] = {"accepted_command": "provider-result"}
        wrong_result["result_sha256"] = canonical_sha256(wrong_result["result"])
        with self.assertRaisesRegex(ProtocolError, "factory-command"):
            validate_adapter_response_data(wrong_result, request=request)

        event = _event()
        event["event_type"] = "provider.custom"
        with self.assertRaisesRegex(ProtocolError, "Unknown canonical factory event"):
            validate_factory_event_data(event)

        event = _event()
        event["payload"]["command_id"] = 7
        event["payload_sha256"] = canonical_sha256(event["payload"])
        with self.assertRaisesRegex(ProtocolError, "value type 'string'"):
            validate_factory_event_data(event)

        stale_request, stale = _stale_response()
        stale["cursor"]["stream_id"] = "foreign-stream"
        with self.assertRaisesRegex(ProtocolError, "requested stream_id"):
            validate_adapter_response_data(stale, request=stale_request)

        stale_request, stale = _stale_response()
        stale["cursor"] = copy.deepcopy(stale_request["payload"]["cursor"])
        stale["cursor"]["snapshot_sha256"] = "b" * 64
        with self.assertRaisesRegex(ProtocolError, "must advance"):
            validate_adapter_response_data(stale, request=stale_request)

        original_request = _request()
        original_response = _response(original_request)
        retry_request = _request(request_id="request-duplicate")
        duplicate = copy.deepcopy(original_response)
        duplicate.update(
            {
                "request_id": retry_request["request_id"],
                "request_sha256": canonical_sha256(retry_request),
                "disposition": "duplicate",
                "original_response_sha256": canonical_sha256(original_response),
                "mutation_state": "not-applied",
            }
        )
        with self.assertRaisesRegex(ProtocolError, "does not match the original"):
            validate_adapter_response_data(
                duplicate,
                request=retry_request,
                original_request=original_request,
                original_response=original_response,
            )

        duplicate["mutation_state"] = original_response["mutation_state"]
        duplicate["extensions"] = {"example.provider/attempt": 2}
        with self.assertRaisesRegex(ProtocolError, "field 'extensions'"):
            validate_adapter_response_data(
                duplicate,
                request=retry_request,
                original_request=original_request,
                original_response=original_response,
            )

    def test_invalid_conformance_fixtures_fail_for_declared_reason(self) -> None:
        fixtures = sorted(Path(FIXTURE_DIR).glob("*.json"))
        self.assertEqual(len(fixtures), 7)
        for fixture_path in fixtures:
            with self.subTest(fixture=fixture_path.name):
                fixture = load_json(fixture_path)
                target = fixture["target"]
                if target == "compatibility":
                    with self.assertRaisesRegex(
                        ProtocolError, fixture["expected_error"]
                    ):
                        require_compatible_version(
                            fixture["producer"],
                            fixture["consumer"],
                        )
                    continue

                request = _request()
                if target == "registry":
                    document = load_json(
                        ROOT / "factory" / "factory-contracts.json"
                    )
                    validator = validate_factory_contracts_data
                    kwargs = {}
                elif target == "request":
                    document = request
                    validator = validate_adapter_request_data
                    kwargs = {}
                elif target == "response":
                    document = _response(request)
                    validator = validate_adapter_response_data
                    kwargs = {"request": request}
                elif target == "uncertain-response":
                    document = _uncertain_response(request)
                    validator = validate_adapter_response_data
                    kwargs = {"request": request}
                elif target == "stale-response":
                    stale_request, document = _stale_response()
                    validator = validate_adapter_response_data
                    kwargs = {"request": stale_request}
                elif target == "event":
                    document = _event()
                    validator = validate_factory_event_data
                    kwargs = {}
                else:
                    self.fail(f"Unknown fixture target: {target}")

                mutated = copy.deepcopy(document)
                _set_path(mutated, fixture["path"], fixture["value"])
                with self.assertRaisesRegex(
                    ProtocolError, fixture["expected_error"]
                ):
                    validator(mutated, **kwargs)


if __name__ == "__main__":
    unittest.main()
