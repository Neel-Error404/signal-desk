from __future__ import annotations

import unittest

from elder_protocol.constants import ROOT
from elder_protocol.factory import validate_factory_contract


class FactoryContractFoundationTests(unittest.TestCase):
    def test_p3_factory_contract_and_ci_surfaces_are_valid(self) -> None:
        contract = validate_factory_contract(
            ROOT / "factory" / "factory-contract.json"
        )
        self.assertEqual(contract["project"]["id"], "elder-workbench")
        self.assertEqual(
            [item["level"] for item in contract["project"]["test_ladder"]],
            ["Foundation", "Component", "Integration", "Workflow", "Stress"],
        )

        workflow = (ROOT / ".github" / "workflows" / "elder-ci.yml").read_text(
            encoding="utf-8"
        )
        self.assertIn("merge_group:", workflow)
        self.assertIn("attestations: write", workflow)
        self.assertIn("id-token: write", workflow)


if __name__ == "__main__":
    unittest.main()
