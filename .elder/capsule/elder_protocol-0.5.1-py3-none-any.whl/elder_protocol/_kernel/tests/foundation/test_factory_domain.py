from __future__ import annotations

import copy
import unittest
from pathlib import Path
from typing import Any

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_domain import (
    REQUIRED_ENTITY_IDS,
    REQUIRED_PLANES,
    factory_entity_content_sha256,
    validate_decision_supersession_data,
    validate_factory_domain,
    validate_factory_domain_data,
    validate_factory_entity_data,
    validate_learning_chain_data,
)
from elder_protocol.io import load_json
from elder_protocol.schema_validation import validate_schema_catalog


FIXTURE_DIR = ROOT / "tests" / "fixtures" / "factory_domain"
SHA256 = "a" * 64


def _work_item_record() -> dict[str, Any]:
    return {
        "version": "0.1.0",
        "id": "work-item-record-001",
        "entity_type": "work-item",
        "project_id": "example-project",
        "actor_identity_id": "owner-001",
        "status": "draft",
        "record_version": 1,
        "created_at": "2026-08-07T10:00:00+00:00",
        "updated_at": "2026-08-07T10:00:00+00:00",
        "correlation_id": "correlation-001",
        "causation_id": None,
        "content_sha256": None,
        "payload": {
            "objective": "Define the canonical factory domain.",
            "scope": ["factory"],
            "non_goals": ["runtime"],
            "priority": "high",
            "stage": "draft",
            "revision_id": "revision-001",
            "owner_identity_id": "owner-001",
            "evidence_plan": ["foundation"],
        },
    }


def _bind_digest(record: dict[str, Any]) -> dict[str, Any]:
    record["content_sha256"] = factory_entity_content_sha256(record)
    return record


def _apply_fixture(domain: dict[str, Any], fixture: dict[str, Any]) -> None:
    operation = fixture["operation"]
    if operation == "duplicate-entity":
        entity_id = fixture["entity_id"]
        entity = next(item for item in domain["entities"] if item["id"] == entity_id)
        domain["entities"][-1] = copy.deepcopy(entity)
        return
    if operation == "append-transition":
        domain["transitions"].append(copy.deepcopy(fixture["transition"]))
        return
    if operation == "set-project-binding":
        entity_id = fixture["entity_id"]
        entity = next(item for item in domain["entities"] if item["id"] == entity_id)
        entity["project_binding"] = fixture["value"]
        return
    if operation == "duplicate-ownership":
        entity_id = fixture["entity_id"]
        domain["ownership"][-1] = {
            "entity_id": entity_id,
            "authoritative_plane": fixture["authoritative_plane"],
            "owner_role": fixture["owner_role"],
            "allowed_writer_roles": fixture["allowed_writer_roles"],
            "mutation_policy": fixture["mutation_policy"],
        }
        return
    raise AssertionError(f"Unsupported factory-domain fixture operation: {operation}")


class FactoryDomainFoundationTests(unittest.TestCase):
    def test_schema_catalog_and_canonical_registry_are_valid(self) -> None:
        schemas = validate_schema_catalog(ROOT / "factory")
        self.assertEqual(
            set(schemas),
            {
                "factory-adapter-request.schema.json",
                "factory-adapter-response.schema.json",
                "factory-command.schema.json",
                "factory-contracts.schema.json",
                "factory-cursor.schema.json",
                "factory-domain.schema.json",
                "factory-entity.schema.json",
                "factory-event.schema.json",
                "operational-architecture.schema.json",
            },
        )
        domain = validate_factory_domain()
        self.assertEqual(
            {plane["id"] for plane in domain["planes"]}, REQUIRED_PLANES
        )
        self.assertEqual(
            {entity["id"] for entity in domain["entities"]},
            REQUIRED_ENTITY_IDS,
        )
        self.assertTrue(domain["provider_neutral"])
        self.assertEqual(domain["status"], "RATIFIED")

    def test_every_entity_is_project_bound_and_singly_owned(self) -> None:
        domain = validate_factory_domain()
        self.assertTrue(
            all(
                entity["project_binding"] == "required"
                for entity in domain["entities"]
            )
        )
        entity_ids = {entity["id"] for entity in domain["entities"]}
        ownership_ids = [
            ownership["entity_id"] for ownership in domain["ownership"]
        ]
        self.assertEqual(set(ownership_ids), entity_ids)
        self.assertEqual(len(ownership_ids), len(set(ownership_ids)))
        worker = next(
            plane for plane in domain["planes"] if plane["id"] == "worker"
        )
        self.assertFalse(worker["can_hold_canonical_state"])

    def test_invalid_fixtures_fail_closed_for_the_intended_reason(self) -> None:
        canonical = load_json(ROOT / "factory" / "factory-domain.json")
        fixtures = sorted(Path(FIXTURE_DIR).glob("*.json"))
        self.assertEqual(len(fixtures), 4)
        for fixture_path in fixtures:
            with self.subTest(fixture=fixture_path.name):
                fixture = load_json(fixture_path)
                mutated = copy.deepcopy(canonical)
                _apply_fixture(mutated, fixture)
                with self.assertRaisesRegex(
                    ProtocolError, fixture["expected_error"]
                ):
                    validate_factory_domain_data(mutated)

    def test_transition_authority_matches_role_capabilities(self) -> None:
        domain = load_json(ROOT / "factory" / "factory-domain.json")
        transition = next(
            item
            for item in domain["transitions"]
            if item["id"] == "work-item-complete"
        )
        transition["authorized_roles"].append("executor")
        with self.assertRaisesRegex(
            ProtocolError, "human approval authority to non-approver roles"
        ):
            validate_factory_domain_data(domain)

    def test_entity_instances_are_bound_to_type_status_payload_and_time(self) -> None:
        validate_factory_entity_data(_work_item_record())

        invalid_type = _work_item_record()
        invalid_type["entity_type"] = "unknown-entity"
        with self.assertRaisesRegex(ProtocolError, "unknown entity_type"):
            validate_factory_entity_data(invalid_type)

        invalid_status = _work_item_record()
        invalid_status["status"] = "unknown-status"
        with self.assertRaisesRegex(ProtocolError, "unknown status"):
            validate_factory_entity_data(invalid_status)

        missing_payload = _work_item_record()
        del missing_payload["payload"]["objective"]
        with self.assertRaisesRegex(ProtocolError, "missing required payload fields"):
            validate_factory_entity_data(missing_payload)

        extra_payload = _work_item_record()
        extra_payload["payload"]["provider_session"] = "prime-specific"
        with self.assertRaisesRegex(ProtocolError, "undeclared payload fields"):
            validate_factory_entity_data(extra_payload)

        reversed_time = _work_item_record()
        reversed_time["updated_at"] = "2026-08-07T09:59:59+00:00"
        with self.assertRaisesRegex(ProtocolError, "cannot be earlier"):
            validate_factory_entity_data(reversed_time)

    def test_immutable_records_and_promotions_require_digest_safety(self) -> None:
        decision = {
            **_work_item_record(),
            "id": "decision-record-001",
            "entity_type": "decision",
            "status": "approved",
            "payload": {
                "decision_request_id": "decision-request-001",
                "subject_sha256": SHA256,
                "decision": "approved",
                "decided_by": "owner-001",
                "decided_as_role": "human-owner",
                "evidence_refs": ["evidence-001"],
            },
        }
        with self.assertRaisesRegex(ProtocolError, "requires content_sha256"):
            validate_factory_entity_data(decision)
        _bind_digest(decision)
        validate_factory_entity_data(decision)

        promotion = {
            **_work_item_record(),
            "id": "promotion-record-001",
            "entity_type": "promotion",
            "status": "proposed",
            "content_sha256": SHA256,
            "payload": {
                "candidate_id": "candidate-001",
                "candidate_sha256": SHA256,
                "evaluation_id": "evaluation-001",
                "evaluation_sha256": SHA256,
                "approval_ids": ["approval-001"],
                "approval_digests": [SHA256],
                "approver_identity_ids": ["owner-001"],
                "action": "promote",
                "target_ref": "memory/target",
                "artifact_sha256": SHA256,
                "promoter_identity_id": "promoter-001",
                "applies_target_mutation": True,
            },
        }
        _bind_digest(promotion)
        with self.assertRaisesRegex(ProtocolError, "applies_target_mutation"):
            validate_factory_entity_data(promotion)

    def test_advisory_evaluators_cannot_mutate_run_state(self) -> None:
        domain = load_json(ROOT / "factory" / "factory-domain.json")
        ownership = next(
            item for item in domain["ownership"] if item["entity_id"] == "run"
        )
        ownership["allowed_writer_roles"].append("evaluator")
        with self.assertRaisesRegex(ProtocolError, "Evaluator is advisory-only"):
            validate_factory_domain_data(domain)

    def test_ambiguous_triggers_and_unreachable_statuses_fail_closed(self) -> None:
        domain = load_json(ROOT / "factory" / "factory-domain.json")
        collision = copy.deepcopy(
            next(
                item
                for item in domain["transitions"]
                if item["id"] == "signal-accept"
            )
        )
        collision["id"] = "signal-accept-as-rejected"
        collision["to_status"] = "rejected"
        domain["transitions"].append(collision)
        with self.assertRaisesRegex(ProtocolError, "Ambiguous factory transition"):
            validate_factory_domain_data(domain)

        domain = load_json(ROOT / "factory" / "factory-domain.json")
        decision = next(
            item for item in domain["entities"] if item["id"] == "decision"
        )
        decision["statuses"].append("superseded")
        decision["terminal_statuses"].append("superseded")
        with self.assertRaisesRegex(ProtocolError, "unreachable statuses"):
            validate_factory_domain_data(domain)

        domain = load_json(ROOT / "factory" / "factory-domain.json")
        factory = next(
            item
            for item in domain["entities"]
            if item["id"] == "product-factory"
        )
        factory["statuses"].extend(["orphan-one", "orphan-two"])
        for source, target in [
            ("orphan-one", "orphan-two"),
            ("orphan-two", "orphan-one"),
        ]:
            domain["transitions"].append(
                {
                    "id": f"product-factory-{source}-cycle",
                    "entity_id": "product-factory",
                    "from_statuses": [source],
                    "to_status": target,
                    "trigger": "cycle",
                    "authorized_roles": ["human-owner"],
                    "authority": "human-approval",
                    "required_fields": [],
                    "required_evidence": ["cycle evidence"],
                    "side_effect": "state-change",
                }
            )
        with self.assertRaisesRegex(ProtocolError, "unreachable statuses"):
            validate_factory_domain_data(domain)

    def test_reuse_learning_and_recovery_contracts_are_structural(self) -> None:
        domain = load_json(ROOT / "factory" / "factory-domain.json")
        reuse = next(
            item
            for item in domain["elder_reuse_contracts"]
            if item["entity_id"] == "work-item"
        )
        reuse["elder_schema"] = "protocol/agent-run.schema.json"
        with self.assertRaisesRegex(ProtocolError, "does not match"):
            validate_factory_domain_data(domain)

        domain = load_json(ROOT / "factory" / "factory-domain.json")
        recovery = next(
            item
            for item in domain["transitions"]
            if item["id"] == "worker-session-recover"
        )
        recovery["required_fields"].remove("session_generation")
        with self.assertRaisesRegex(ProtocolError, "recovery must bind"):
            validate_factory_domain_data(domain)

        domain = load_json(ROOT / "factory" / "factory-domain.json")
        promotion = next(
            item
            for item in domain["transitions"]
            if item["id"] == "learning-candidate-promote"
        )
        promotion["required_fields"].remove("promotion_sha256")
        with self.assertRaisesRegex(ProtocolError, "immutable promotion packet"):
            validate_factory_domain_data(domain)

    def test_worker_session_instance_requires_fencing_values(self) -> None:
        session = {
            **_work_item_record(),
            "id": "worker-session-001",
            "entity_type": "worker-session",
            "status": "detached",
            "payload": {
                "run_id": "run-001",
                "worker_adapter": "codex",
                "external_session_ref": "external-001",
                "lease_ref": "lease-001",
                "lease_token_sha256": SHA256,
                "session_generation": 2,
                "recovery_attempt": 1,
                "checkpoint_cursor": "checkpoint-003",
                "waiting_reason": "client detached",
            },
        }
        validate_factory_entity_data(session)
        session["payload"]["session_generation"] = True
        with self.assertRaisesRegex(ProtocolError, "positive integer"):
            validate_factory_entity_data(session)

    def test_learning_chain_is_digest_bound_and_separation_enforced(self) -> None:
        candidate = {
            **_work_item_record(),
            "id": "candidate-001",
            "entity_type": "learning-candidate",
            "status": "promoted",
            "content_sha256": None,
            "payload": {
                "target_ref": "memory/target",
                "artifact_sha256": "c" * 64,
                "hypothesis": "The candidate improves retrieval quality.",
                "source_evidence": ["evidence-001"],
                "created_by": "learning-agent-001",
                "evaluation_id": "evaluation-001",
                "evaluation_sha256": "",
                "approval_refs": ["approval-001"],
                "promotion_id": "promotion-001",
                "promotion_sha256": "",
            },
        }
        evaluation = {
            **_work_item_record(),
            "id": "evaluation-001",
            "entity_type": "learning-evaluation",
            "status": "qualified",
            "content_sha256": None,
            "payload": {
                "candidate_id": "candidate-001",
                "candidate_sha256": "c" * 64,
                "evaluator_id": "evaluator-001",
                "observation_ids": ["observation-001"],
                "verdict": "qualified",
            },
        }
        approval = {
            **_work_item_record(),
            "id": "approval-001",
            "entity_type": "decision",
            "status": "approved",
            "content_sha256": None,
            "payload": {
                "decision_request_id": "decision-request-001",
                "subject_sha256": "c" * 64,
                "decision": "approved",
                "decided_by": "approver-001",
                "decided_as_role": "human-owner",
                "evidence_refs": ["evaluation-001"],
            },
        }
        _bind_digest(approval)
        promotion = {
            **_work_item_record(),
            "id": "promotion-001",
            "entity_type": "promotion",
            "status": "applied",
            "content_sha256": None,
            "payload": {
                "candidate_id": "candidate-001",
                "candidate_sha256": "c" * 64,
                "evaluation_id": "evaluation-001",
                "evaluation_sha256": "",
                "approval_ids": ["approval-001"],
                "approval_digests": [approval["content_sha256"]],
                "approver_identity_ids": ["approver-001"],
                "action": "promote",
                "target_ref": "memory/target",
                "artifact_sha256": "c" * 64,
                "promoter_identity_id": "promoter-001",
                "applies_target_mutation": False,
            },
        }
        _bind_digest(evaluation)
        candidate["payload"]["evaluation_sha256"] = evaluation["content_sha256"]
        promotion["payload"]["evaluation_sha256"] = evaluation["content_sha256"]
        _bind_digest(promotion)
        candidate["payload"]["promotion_sha256"] = promotion["content_sha256"]
        _bind_digest(candidate)
        validate_learning_chain_data(candidate, evaluation, promotion, [approval])

        promotion["payload"]["evaluation_sha256"] = "0" * 64
        _bind_digest(promotion)
        with self.assertRaisesRegex(ProtocolError, "does not match evaluation digest"):
            validate_learning_chain_data(candidate, evaluation, promotion, [approval])

        promotion["payload"]["evaluation_sha256"] = evaluation["content_sha256"]
        promotion["payload"]["promoter_identity_id"] = "evaluator-001"
        _bind_digest(promotion)
        candidate["payload"]["promotion_sha256"] = promotion["content_sha256"]
        _bind_digest(candidate)
        with self.assertRaisesRegex(ProtocolError, "must be distinct"):
            validate_learning_chain_data(candidate, evaluation, promotion, [approval])

        promotion["payload"]["promoter_identity_id"] = "promoter-001"
        promotion["payload"]["target_ref"] = "memory/other-target"
        _bind_digest(promotion)
        candidate["payload"]["promotion_sha256"] = promotion["content_sha256"]
        _bind_digest(candidate)
        with self.assertRaisesRegex(ProtocolError, "target_ref does not match"):
            validate_learning_chain_data(candidate, evaluation, promotion, [approval])

        promotion["payload"]["target_ref"] = "memory/target"
        _bind_digest(promotion)
        candidate["payload"]["promotion_sha256"] = promotion["content_sha256"]
        candidate["status"] = "approved"
        _bind_digest(candidate)
        with self.assertRaisesRegex(ProtocolError, "status does not match"):
            validate_learning_chain_data(candidate, evaluation, promotion, [approval])

    def test_digest_approval_and_supersession_integrity_fail_closed(self) -> None:
        decision = {
            **_work_item_record(),
            "id": "decision-001",
            "entity_type": "decision",
            "status": "approved",
            "created_at": "2026-08-07T10:00:00+00:00",
            "updated_at": "2026-08-07T10:00:00+00:00",
            "payload": {
                "decision_request_id": "request-001",
                "subject_sha256": SHA256,
                "decision": "approved",
                "decided_by": "owner-001",
                "decided_as_role": "human-owner",
                "evidence_refs": ["evidence-001"],
            },
        }
        _bind_digest(decision)
        decision["payload"]["decision"] = "rejected"
        with self.assertRaisesRegex(ProtocolError, "does not bind"):
            validate_factory_entity_data(decision)

        decision["payload"]["decision"] = "approved"
        _bind_digest(decision)
        replacement = copy.deepcopy(decision)
        replacement["id"] = "decision-002"
        replacement["created_at"] = "2026-08-07T10:01:00+00:00"
        replacement["updated_at"] = "2026-08-07T10:01:00+00:00"
        replacement["payload"]["decision"] = "changes-requested"
        replacement["payload"]["supersedes_decision_id"] = decision["id"]
        _bind_digest(replacement)
        validate_decision_supersession_data(decision, replacement)

        replacement["created_at"] = decision["created_at"]
        replacement["updated_at"] = decision["updated_at"]
        _bind_digest(replacement)
        with self.assertRaisesRegex(ProtocolError, "must be later"):
            validate_decision_supersession_data(decision, replacement)

        replacement["created_at"] = "2026-08-07T10:01:00+00:00"
        replacement["updated_at"] = "2026-08-07T10:01:00+00:00"
        replacement["payload"]["subject_sha256"] = "b" * 64
        _bind_digest(replacement)
        with self.assertRaisesRegex(ProtocolError, "same request and subject"):
            validate_decision_supersession_data(decision, replacement)

        promotion = {
            **_work_item_record(),
            "id": "promotion-approval-integrity",
            "entity_type": "promotion",
            "status": "proposed",
            "payload": {
                "candidate_id": "candidate-001",
                "candidate_sha256": "c" * 64,
                "evaluation_id": "evaluation-001",
                "evaluation_sha256": "d" * 64,
                "approval_ids": ["approval-001", "approval-001"],
                "approval_digests": ["not-a-digest", "f" * 64],
                "approver_identity_ids": ["approver-001", "approver-002"],
                "action": "promote",
                "target_ref": "memory/target",
                "artifact_sha256": "c" * 64,
                "promoter_identity_id": "promoter-001",
                "applies_target_mutation": False,
            },
        }
        _bind_digest(promotion)
        with self.assertRaisesRegex(
            ProtocolError, "unique non-empty strings|lowercase SHA-256"
        ):
            validate_factory_entity_data(promotion)
