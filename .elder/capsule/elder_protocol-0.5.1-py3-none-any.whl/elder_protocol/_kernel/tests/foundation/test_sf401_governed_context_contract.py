from __future__ import annotations

import unittest

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    GOVERNED_CONTEXT_STORE_SCHEMA_VERSION,
    GOVERNED_CONTEXT_VERSION,
    GovernedContextAssembly,
    GovernedContextRepository,
    validate_governed_context_submission,
)


class SF401GovernedContextFoundationTests(unittest.TestCase):
    def test_task_artifacts_declare_scope_and_next_boundary(self) -> None:
        for name in (
            "SF-401-task-packet.md",
            "SF-401-design.md",
            "SF-401-implementation-plan.md",
            "SF-401-test-reproduction.md",
        ):
            text = (
                ROOT / "docs" / "software-factory" / name
            ).read_text(encoding="utf-8")
            self.assertIn("SF-401", text)
            self.assertIn("SF-402", text)
            self.assertIn("L1", text)

    def test_internal_contract_is_exported_without_new_protocol_surface(self) -> None:
        self.assertEqual(GOVERNED_CONTEXT_VERSION, "1.0.0")
        self.assertEqual(GOVERNED_CONTEXT_STORE_SCHEMA_VERSION, 1)
        self.assertTrue(callable(GovernedContextAssembly))
        self.assertTrue(callable(GovernedContextRepository))
        self.assertFalse(
            (ROOT / "protocol" / "governed-context-policy.json").exists()
        )

    def test_caller_cannot_supply_a_wildcard_query(self) -> None:
        submission = {
            "version": "1.0.0",
            "work_item_id": "work-item-build-repair",
            "assembled_by": "planning-agent",
            "parent_run": {},
            "delegation": {},
            "child_run": {},
            "repository_sources": [],
            "memory_namespaces": [],
            "token_budget": 100,
            "previous_packet_id": None,
            "submitted_at": "2026-08-14T13:00:00+00:00",
            "deadline_at": "2026-08-14T14:00:00+00:00",
            "query": "*",
        }
        with self.assertRaisesRegex(ProtocolError, "fields must be exactly"):
            validate_governed_context_submission(submission)


if __name__ == "__main__":
    unittest.main()
