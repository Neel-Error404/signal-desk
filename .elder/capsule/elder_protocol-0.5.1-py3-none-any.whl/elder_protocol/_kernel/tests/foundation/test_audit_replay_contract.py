from __future__ import annotations

import unittest

from elder_protocol.factory_operations.api_contracts import (
    load_operations_api_contracts,
)
from elder_protocol.schema_validation import validate_schema_catalog


class AuditReplayContractTests(unittest.TestCase):
    def test_schema_and_api_route_are_closed(self) -> None:
        validate_schema_catalog()
        contracts = load_operations_api_contracts()
        route = contracts.routes_by_id["audit-replay-get"]
        binding = contracts.bindings_by_route_id["audit-replay-get"]
        self.assertEqual(route["service"], "AuditReplay.snapshot")
        self.assertEqual(
            route["path"],
            "/v1/projects/{project_id}/work-items/{work_item_id}/audit-replay",
        )
        self.assertEqual(binding["response_validator"], "audit-replay-snapshot")
        self.assertFalse(binding["runtime_fence_required"])


if __name__ == "__main__":
    unittest.main()
