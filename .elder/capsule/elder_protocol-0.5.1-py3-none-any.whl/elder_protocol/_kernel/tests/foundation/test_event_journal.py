from __future__ import annotations

import copy
import shutil
import tempfile
import unittest
from pathlib import Path

from elder_protocol.errors import ProtocolError
from elder_protocol.errors import (
    CapabilityUnavailableError,
    InvalidProjectionTokenError,
    StaleProjectionTokenError,
)
from elder_protocol.factory_operations import (
    JOURNAL_SCHEMA_VERSION,
    JOURNAL_VERSION,
    decode_event_cursor,
    decode_page_token,
    derive_mutation_identity,
    encode_event_cursor,
    encode_page_token,
    factory_capability_status,
    internal_stream_snapshot_sha256,
    journal_entry_sha256,
    public_event_document_sha256,
    public_stream_snapshot_sha256,
    validate_internal_cursor_data,
    validate_journal_entry_data,
    validate_journal_registries,
    validate_mutation_coverage,
    validate_mutation_implementation_coverage,
    validate_projection_registry,
    validate_public_event_mapping,
    validate_source_registry,
)
from elder_protocol.factory_operations._common import canonical_json
from elder_protocol.factory_operations.journal_store import (
    SOURCE_ACTOR_EXTRACTORS,
    SOURCE_CAUSATION_EXTRACTORS,
    SOURCE_CORRELATION_EXTRACTORS,
    SOURCE_IDEMPOTENCY_EXTRACTORS,
    SOURCE_NORMALIZERS,
)
from elder_protocol.io import load_json
from elder_protocol.constants import ROOT


def _sha256(value: object) -> str:
    import hashlib

    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _journal_entry() -> dict:
    projection = {
        "id": "product-factory-one",
        "project_id": "project-one",
        "record_version": 1,
        "status": "active",
    }
    entry = {
        "version": JOURNAL_VERSION,
        "stream_id": "factory-operations-store-one",
        "generation": 1,
        "sequence": 1,
        "entry_id": "journal-entry-" + "1" * 32,
        "previous_entry_sha256": None,
        "entry_sha256": "0" * 64,
        "transaction_id": "mutation-" + "2" * 32,
        "transaction_position": 1,
        "transaction_fact_count": 1,
        "source_append_order": 100,
        "coverage_branch_id": "product.register",
        "mutation_identity_sha256": "3" * 64,
        "fact_type": "product.factory.revision",
        "project_id": "project-one",
        "subject_type": "product-factory",
        "subject_id": "product-factory-one",
        "subject_version": 1,
        "operation": "register",
        "occurred_at": "2026-08-11T12:00:00+00:00",
        "recorded_at": "2026-08-11T12:00:01+00:00",
        "source_actor": {
            "identity_id": "product-owner-one",
            "kind": "human",
        },
        "recorded_by": {
            "identity_id": "factory-journal",
            "kind": "service",
        },
        "source": {
            "plane": "factory-operations",
            "component": "sf-100",
            "reference": "product_factory_revisions:product-factory-one:1",
        },
        "correlation_id": "project-one:product-factory-one",
        "causation_id": None,
        "idempotency_key": None,
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "source_record": {
            "source_registry_id": "product-factory-revisions",
            "table": "product_factory_revisions",
            "key": {
                "product_factory_id": "product-factory-one",
                "record_version": 1,
            },
            "record_version": 1,
            "record_sha256": "4" * 64,
            "row_sha256": "5" * 64,
        },
        "projection_document_sha256": _sha256(projection),
        "projection_document": projection,
        "extensions": {},
    }
    entry["entry_sha256"] = journal_entry_sha256(entry)
    return entry


def _public_event() -> dict:
    payload = {
        "signal_id": "signal-one",
        "source_reference": "manual:source-one",
    }
    event = {
        "version": "1.0.0",
        "event_id": "event-" + "6" * 32,
        "event_type": "integration.signal.accepted",
        "record_kind": "journal-entry",
        "authoritative": True,
        "source_event_id": None,
        "occurred_at": "2026-08-11T12:01:00+00:00",
        "recorded_at": "2026-08-11T12:01:01+00:00",
        "cursor": {
            "version": "1.0.0",
            "stream_id": "factory-public-events-project-one",
            "generation": 1,
            "sequence": 1,
            "event_id": "event-" + "6" * 32,
            "snapshot_sha256": "0" * 64,
            "issued_at": "2026-08-11T12:01:01+00:00",
        },
        "correlations": {
            "product_id": None,
            "project_id": "project-one",
            "work_item_id": None,
            "run_id": None,
            "session_id": None,
        },
        "actor": {"identity_id": "product-owner-one", "kind": "human"},
        "source": {
            "plane": "factory-operations",
            "adapter_id": None,
            "source_ref": "journal:signal_revisions:signal-one:2",
        },
        "correlation_id": "signal:project-one:signal-one",
        "causation_id": "source-event-one",
        "idempotency_key": "signal-one-accepted",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": _sha256(payload),
        "payload": payload,
        "extensions": {
            "elder.local/journal-entry-id": "journal-entry-" + "7" * 32
        },
    }
    document_sha256 = public_event_document_sha256(event)
    event["cursor"]["snapshot_sha256"] = public_stream_snapshot_sha256(
        stream_id=event["cursor"]["stream_id"],
        generation=1,
        sequence=1,
        event_id=event["event_id"],
        event_document_sha256=document_sha256,
    )
    return event


class EventJournalFoundationTests(unittest.TestCase):
    def test_versions_and_machine_readable_registries_are_pinned(self) -> None:
        self.assertEqual(JOURNAL_VERSION, "1.0.0")
        self.assertEqual(JOURNAL_SCHEMA_VERSION, 1)
        status = validate_journal_registries()
        self.assertEqual(status["source_count"], 19)
        self.assertEqual(status["branch_count"], 36)
        self.assertEqual(status["mapping_count"], 1)
        self.assertEqual(status["projection_count"], 7)

        sources = validate_source_registry()
        self.assertEqual(
            {
                item["ordering_mode"]
                for item in sources["sources"]
            },
            {"contiguous", "singleton"},
        )
        validate_mutation_coverage()
        validate_public_event_mapping()
        validate_projection_registry()
        implementation = validate_mutation_implementation_coverage()
        self.assertEqual(implementation["branch_count"], 35)

    def test_registry_digest_and_cross_reference_drift_fail_closed(self) -> None:
        registry = load_json(
            ROOT / "factory" / "operations" / "journal-source-registry.json"
        )
        changed = copy.deepcopy(registry)
        changed["sources"][0]["append_order"] = 999
        with self.assertRaisesRegex(ProtocolError, "content_sha256"):
            from elder_protocol.factory_operations.journal import (
                validate_source_registry_data,
            )

            validate_source_registry_data(changed)

        coverage = load_json(
            ROOT
            / "factory"
            / "operations"
            / "journal-mutation-coverage.json"
        )
        changed_coverage = copy.deepcopy(coverage)
        changed_coverage["branches"][0]["identity_fields"].append(
            "process_id"
        )
        unsigned = {
            key: value
            for key, value in changed_coverage.items()
            if key != "content_sha256"
        }
        changed_coverage["content_sha256"] = _sha256(unsigned)
        from elder_protocol.factory_operations.journal import (
            validate_mutation_coverage_data,
        )

        with self.assertRaisesRegex(ProtocolError, "forbidden identity"):
            validate_mutation_coverage_data(changed_coverage)

        changed_write_site = copy.deepcopy(coverage)
        changed_write_site["branches"][0]["write_sites"][0][
            "resolved_tables"
        ] = ["unknown_current_table"]
        changed_write_site["content_sha256"] = _sha256(
            {
                key: value
                for key, value in changed_write_site.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "unknown tables"):
            validate_mutation_coverage_data(changed_write_site)

        changed_source = copy.deepcopy(registry)
        changed_source["sources"][0]["no_op_projections"].remove("commands")
        changed_source["content_sha256"] = _sha256(
            {
                key: value
                for key, value in changed_source.items()
                if key != "content_sha256"
            }
        )
        from elder_protocol.factory_operations.journal import (
            validate_source_registry_data,
        )

        with self.assertRaisesRegex(ProtocolError, "classify every"):
            validate_source_registry_data(changed_source)

        missing_schema = copy.deepcopy(registry)
        missing_schema["sources"][0][
            "normalized_schema_id"
        ] = "does-not-exist"
        missing_schema["content_sha256"] = _sha256(
            {
                key: value
                for key, value in missing_schema.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(
            ProtocolError,
            "unknown normalized projection schema",
        ):
            validate_source_registry_data(missing_schema)

        changed_schema_digest = copy.deepcopy(registry)
        changed_schema_digest["sources"][0][
            "normalized_schema_sha256"
        ] = "0" * 64
        changed_schema_digest["content_sha256"] = _sha256(
            {
                key: value
                for key, value in changed_schema_digest.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(
            ProtocolError,
            "normalized projection schema digest changed",
        ):
            validate_source_registry_data(changed_schema_digest)

        missing_extractor = copy.deepcopy(registry)
        missing_extractor["sources"][0][
            "actor_extractor_id"
        ] = "does-not-exist"
        missing_extractor["content_sha256"] = _sha256(
            {
                key: value
                for key, value in missing_extractor.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "unknown actor extractor"):
            validate_source_registry_data(missing_extractor)

        unordered = copy.deepcopy(coverage)
        branch = next(
            item
            for item in unordered["branches"]
            if item["branch_id"] == "work-item.create-from-signal"
        )
        branch["source_ids"].reverse()
        unordered["content_sha256"] = _sha256(
            {
                key: value
                for key, value in unordered.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "append order"):
            validate_mutation_coverage_data(unordered)

    def test_registered_normalizers_and_extractors_are_executable(
        self,
    ) -> None:
        registry = validate_source_registry()
        self.assertEqual(
            set(SOURCE_NORMALIZERS),
            {source["normalizer_id"] for source in registry["sources"]},
        )
        for source in registry["sources"]:
            record = {
                "project_id": "project-one",
                "actor_identity_id": "founder",
                "command_id": "command-one",
                "idempotency_key": "idempotency-one",
            }
            context = {
                "source": source,
                "row": {"changed_by": "founder"},
                "record": record,
                "project_id": "project-one",
                "subject_id": "subject-one",
                "source_version": 1,
                "operation": "recorded",
                "occurred_at": "2026-08-11T12:00:00+00:00",
                "primary_key": {"id": "subject-one"},
                "source_identity": {"id": "subject-one"},
                "parent_ids": {},
            }
            normalized = SOURCE_NORMALIZERS[source["normalizer_id"]](
                **context,
                record_sha256="1" * 64,
                row_sha256="2" * 64,
            )
            self.assertEqual(
                normalized["source_registry_id"],
                source["id"],
            )
            actor = SOURCE_ACTOR_EXTRACTORS[
                source["actor_extractor_id"]
            ](**context)
            self.assertEqual(actor["identity_id"], "founder")
            correlation = SOURCE_CORRELATION_EXTRACTORS[
                source["correlation_extractor_id"]
            ](**context)
            self.assertEqual(
                correlation,
                f"{source['fact_type']}:subject-one",
            )
            causation = SOURCE_CAUSATION_EXTRACTORS[
                source["causation_extractor_id"]
            ](**context)
            self.assertEqual(causation, "command-one")
            idempotency = SOURCE_IDEMPOTENCY_EXTRACTORS[
                source["idempotency_extractor_id"]
            ](**context)
            self.assertEqual(idempotency, "idempotency-one")
        first, second = registry["sources"][:2]
        with self.assertRaisesRegex(
            ProtocolError,
            "cannot process source",
        ):
            SOURCE_NORMALIZERS[first["normalizer_id"]](
                source=second,
                row={},
                record={},
                project_id="project-one",
                subject_id="subject-one",
                source_version=1,
                operation="recorded",
                occurred_at="2026-08-11T12:00:00+00:00",
                primary_key={"id": "subject-one"},
                source_identity={"id": "subject-one"},
                parent_ids={},
                record_sha256="1" * 64,
                row_sha256="2" * 64,
            )

    def test_implementation_coverage_is_bound_to_reachable_write_calls(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cases = (
                (
                    "missing-helper",
                    "product_registry.py",
                    "self._append_revision(",
                    "self._append_revision_removed(",
                    "helper path is not a direct executable call",
                ),
                (
                    "missing-statement",
                    "work_item_ledger.py",
                    "DELETE FROM work_item_dependencies",
                    "SELECT * FROM work_item_dependencies",
                    "SQL operation changed",
                ),
                (
                    "dynamic-table-drift",
                    "run_controller.py",
                    "INSERT INTO {table}(",
                    "INSERT INTO factory_history_changed(",
                    "has no exact SQL statement",
                ),
            )
            for (
                label,
                filename,
                original,
                replacement,
                expected,
            ) in cases:
                case_root = root / label
                target = (
                    case_root
                    / "elder_protocol"
                    / "factory_operations"
                )
                shutil.copytree(
                    ROOT / "elder_protocol" / "factory_operations",
                    target,
                )
                implementation = target / filename
                text = implementation.read_text(encoding="utf-8")
                if original not in text:
                    self.fail(
                        f"Mutation coverage test fixture missing: {original}"
                    )
                implementation.write_text(
                    text.replace(original, replacement, 1),
                    encoding="utf-8",
                )
                with self.subTest(label=label):
                    with self.assertRaisesRegex(
                        ProtocolError,
                        expected,
                    ):
                        validate_mutation_implementation_coverage(
                            root=case_root
                        )

    def test_journal_entry_hash_chain_and_cursor_are_exact(self) -> None:
        entry = _journal_entry()
        self.assertEqual(validate_journal_entry_data(entry), entry)

        changed = copy.deepcopy(entry)
        changed["source_append_order"] += 1
        with self.assertRaisesRegex(ProtocolError, "entry_sha256"):
            validate_journal_entry_data(changed)

        snapshot = internal_stream_snapshot_sha256(
            stream_id=entry["stream_id"],
            generation=entry["generation"],
            sequence=entry["sequence"],
            entry_id=entry["entry_id"],
            entry_sha256=entry["entry_sha256"],
        )
        cursor = {
            "version": JOURNAL_VERSION,
            "stream_id": entry["stream_id"],
            "generation": 1,
            "sequence": 1,
            "entry_id": entry["entry_id"],
            "entry_sha256": entry["entry_sha256"],
            "snapshot_sha256": snapshot,
            "issued_at": "2026-08-11T12:00:02+00:00",
        }
        self.assertEqual(validate_internal_cursor_data(cursor), cursor)
        changed_cursor = copy.deepcopy(cursor)
        changed_cursor["sequence"] = 2
        with self.assertRaisesRegex(ProtocolError, "snapshot_sha256"):
            validate_internal_cursor_data(changed_cursor)

    def test_public_event_digest_is_acyclic_and_cursor_bound(self) -> None:
        event = _public_event()
        first = public_event_document_sha256(event)
        second = public_event_document_sha256(copy.deepcopy(event))
        self.assertEqual(first, second)
        self.assertEqual(
            event["cursor"]["snapshot_sha256"],
            public_stream_snapshot_sha256(
                stream_id=event["cursor"]["stream_id"],
                generation=1,
                sequence=1,
                event_id=event["event_id"],
                event_document_sha256=first,
            ),
        )
        changed = copy.deepcopy(event)
        changed["payload"]["signal_id"] = "signal-two"
        changed["payload_sha256"] = _sha256(changed["payload"])
        self.assertNotEqual(public_event_document_sha256(changed), first)

    def test_mutation_identity_page_token_and_capability_status(self) -> None:
        identity = derive_mutation_identity(
            coverage_branch_id="product.register",
            project_id="project-one",
            subject_id="product-factory-one",
            identity_source={
                "configuration_sha256": "8" * 64,
                "actor_identity_id": "product-owner-one",
            },
            pre_state=None,
            expected_result_versions={"product_factory": 1},
            coverage_sha256="9" * 64,
        )
        self.assertRegex(identity["mutation_id"], r"^mutation-[a-f0-9]{32}$")
        self.assertEqual(
            identity,
            derive_mutation_identity(
                coverage_branch_id="product.register",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "configuration_sha256": "8" * 64,
                    "actor_identity_id": "product-owner-one",
                },
                pre_state=None,
                expected_result_versions={"product_factory": 1},
                coverage_sha256="9" * 64,
            ),
        )

        token = {
            "version": JOURNAL_VERSION,
            "projection_id": "products",
            "projection_generation": 1,
            "projection_sha256": "a" * 64,
            "journal_generation": 1,
            "journal_sequence": 10,
            "journal_entry_id": "journal-entry-" + "b" * 32,
            "method_id": "list-products",
            "filter_sha256": "c" * 64,
            "sort_id": "products-default",
            "page_size": 100,
            "last_sort_values": ["project-one", "product-factory-one"],
        }
        encoded = encode_page_token(token)
        self.assertEqual(decode_page_token(encoded), token)
        with self.assertRaisesRegex(ProtocolError, "malformed"):
            decode_page_token("not valid!")

        cursor = {
            "version": JOURNAL_VERSION,
            "stream_id": "factory-public-events-project-one",
            "generation": 1,
            "sequence": 0,
            "event_id": None,
            "snapshot_sha256": "d" * 64,
            "issued_at": "2026-08-12T00:00:00+00:00",
        }
        encoded_cursor = encode_event_cursor(cursor)
        self.assertEqual(decode_event_cursor(encoded_cursor), cursor)
        with self.assertRaisesRegex(ProtocolError, "malformed"):
            decode_event_cursor("not valid!")

        status = factory_capability_status()
        self.assertTrue(status["capabilities"]["decisions"]["implemented"])
        self.assertEqual(
            status["capabilities"]["decisions"]["status"],
            "ready",
        )
        self.assertIsNone(
            status["capabilities"]["decisions"]["reason_code"]
        )
        self.assertTrue(issubclass(InvalidProjectionTokenError, ProtocolError))
        self.assertTrue(issubclass(StaleProjectionTokenError, ProtocolError))
        self.assertTrue(issubclass(CapabilityUnavailableError, ProtocolError))

        coverage = validate_mutation_coverage()
        checkpoint = next(
            item
            for item in coverage["branches"]
            if item["branch_id"] == "run.checkpoint-reference"
        )
        self.assertEqual(
            checkpoint["source_cardinality"],
            {"minimum": 3, "maximum": 20},
        )


if __name__ == "__main__":
    unittest.main()
