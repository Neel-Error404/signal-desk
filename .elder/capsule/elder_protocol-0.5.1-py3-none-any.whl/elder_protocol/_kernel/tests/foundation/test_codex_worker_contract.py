from __future__ import annotations

from pathlib import Path
import unittest

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_workers import (
    CODEX_CLI_VERSION,
    WORKER_OPERATIONS,
    CodexRuntimeConfig,
    CodexWorkerAdapter,
    validate_worker_capabilities,
)
from tests._codex_support import DeterministicCodexRuntime
from tests._support import test_workspace


class CodexWorkerContractFoundationTests(unittest.TestCase):
    def test_runtime_policy_and_version_are_fail_closed(self) -> None:
        invalid = (
            CodexRuntimeConfig(expected_version="codex-cli 0.146.0"),
            CodexRuntimeConfig(approval_policy="never"),
            CodexRuntimeConfig(approvals_reviewer="auto_review"),
            CodexRuntimeConfig(sandbox_mode="danger-full-access"),
            CodexRuntimeConfig(network_access=True),
            CodexRuntimeConfig(request_timeout_seconds=0),
            CodexRuntimeConfig(pending_session_timeout_seconds=0),
        )
        for config in invalid:
            with self.subTest(config=config):
                with self.assertRaises(ProtocolError):
                    config.validate()
        valid = CodexRuntimeConfig()
        valid.validate()
        self.assertEqual(valid.expected_version, CODEX_CLI_VERSION)

    def test_capabilities_preserve_the_exact_sf200_contract(self) -> None:
        with test_workspace("sf201-foundation-capabilities") as workspace:
            provider_workspace = workspace / "provider"
            provider_workspace.mkdir()
            adapter = CodexWorkerAdapter(
                workspace / "worker.db",
                workspace_bindings={
                    "workspace-sf200": provider_workspace
                },
                runtime=DeterministicCodexRuntime(),
            )
            capabilities = validate_worker_capabilities(adapter.capabilities())
            self.assertEqual(
                set(capabilities["supported_operations"]),
                set(WORKER_OPERATIONS),
            )
            self.assertEqual(
                capabilities["adapter_id"],
                "elder-codex-worker",
            )
            self.assertEqual(
                capabilities["canonical_write_authority"],
                "none",
            )

    def test_workspace_bindings_require_existing_absolute_directories(
        self,
    ) -> None:
        with test_workspace("sf201-foundation-workspace") as workspace:
            provider_workspace = workspace / "provider"
            provider_workspace.mkdir()
            with self.assertRaisesRegex(ProtocolError, "must be absolute"):
                CodexWorkerAdapter(
                    workspace / "relative.db",
                    workspace_bindings={
                        "workspace-sf200": Path("relative-workspace")
                    },
                    runtime=DeterministicCodexRuntime(),
                )
            with self.assertRaisesRegex(
                ProtocolError,
                "outside the provider-writable workspace",
            ):
                CodexWorkerAdapter(
                    provider_workspace / "worker.db",
                    workspace_bindings={
                        "workspace-sf200": provider_workspace
                    },
                    runtime=DeterministicCodexRuntime(),
                )
            with self.assertRaises(FileNotFoundError):
                CodexWorkerAdapter(
                    workspace / "missing.db",
                    workspace_bindings={
                        "workspace-sf200": workspace / "missing"
                    },
                    runtime=DeterministicCodexRuntime(),
                )

    def test_sf201_files_are_package_visible(self) -> None:
        expected = (
            ROOT / "elder_protocol" / "factory_workers" / "codex_worker.py",
            ROOT / "docs" / "software-factory" / "SF-201-design.md",
            ROOT
            / "docs"
            / "software-factory"
            / "SF-201-test-reproduction.md",
            ROOT
            / "docs"
            / "software-factory"
            / "evidence"
            / "SF-201.md",
            ROOT / "tests" / "foundation" / "test_codex_worker_contract.py",
            ROOT / "tests" / "component" / "test_codex_worker_adapter.py",
            ROOT / "tests" / "integration" / "test_codex_worker_adapter.py",
            ROOT / "tests" / "workflow" / "test_sf201_codex_worker_live.py",
        )
        self.assertTrue(all(path.is_file() for path in expected))


if __name__ == "__main__":
    unittest.main()
