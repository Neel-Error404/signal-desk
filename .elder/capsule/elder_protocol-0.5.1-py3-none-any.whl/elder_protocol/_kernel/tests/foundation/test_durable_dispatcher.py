from __future__ import annotations

import copy
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    DEFAULT_BACKOFF_SECONDS,
    DEFAULT_LEASE_SECONDS,
    DEFAULT_MAX_ATTEMPTS,
    DISPATCH_RESPONSE_ACTIONS,
    DURABLE_DISPATCHER_VERSION,
    LOCAL_DISPATCH_CAPACITY,
    validate_dispatch_submission,
)


def _command() -> dict:
    payload = {
        "work_item_id": "work-item-build-repair",
        "operation": "start",
    }
    return {
        "version": "1.0.0",
        "command_id": "command-start-build-repair",
        "project_id": "product-one",
        "work_item_id": "work-item-build-repair",
        "run_id": None,
        "worker_session_id": None,
        "command_type": "worker.start",
        "mutability": "mutation",
        "idempotency_key": "start-build-repair-001",
        "authority_ref": "authority:queue-build-repair",
        "correlation_id": "work-item:work-item-build-repair",
        "causation_id": "stage-transition-queue-build-repair",
        "attempt": 1,
        "status": "accepted",
        "submitted_at": "2026-08-11T01:00:00+00:00",
        "expires_at": "2026-08-11T02:00:00+00:00",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _submission() -> dict:
    command = _command()
    payload = {"command": command}
    request = {
        "version": "1.0.0",
        "contract_id": "worker-adapter",
        "operation": "send",
        "request_id": "request-start-build-repair",
        "project_id": command["project_id"],
        "work_item_id": command["work_item_id"],
        "run_id": command["run_id"],
        "session_id": command["worker_session_id"],
        "submitted_at": "2026-08-11T01:00:01+00:00",
        "deadline_at": "2026-08-11T01:30:00+00:00",
        "correlation_id": command["correlation_id"],
        "causation_id": command["causation_id"],
        "mutability": "mutation",
        "idempotency_key": command["idempotency_key"],
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }
    return {
        "version": DURABLE_DISPATCHER_VERSION,
        "command": command,
        "adapter_request": request,
        "queue_transition_command_id": "transition-command-queue-build-repair",
        "max_attempts": DEFAULT_MAX_ATTEMPTS,
        "available_at": "2026-08-11T01:00:01+00:00",
    }


class DurableDispatcherFoundationTests(unittest.TestCase):
    def test_submission_reuses_exact_sf003_command_and_request(self) -> None:
        submission = validate_dispatch_submission(_submission())
        self.assertEqual(submission["command"]["status"], "accepted")
        self.assertEqual(
            submission["adapter_request"]["payload"],
            {"command": submission["command"]},
        )
        self.assertEqual(submission["max_attempts"], 5)

    def test_contract_binding_drift_fails_closed(self) -> None:
        invalid = _submission()
        invalid["adapter_request"]["idempotency_key"] = "different-key-001"
        with self.assertRaisesRegex(ProtocolError, "idempotency_key"):
            validate_dispatch_submission(invalid)

        invalid = _submission()
        invalid["command"]["status"] = "pending"
        invalid["adapter_request"]["payload"]["command"]["status"] = "pending"
        invalid["adapter_request"]["payload_sha256"] = canonical_sha256(
            invalid["adapter_request"]["payload"]
        )
        with self.assertRaisesRegex(ProtocolError, "accepted status"):
            validate_dispatch_submission(invalid)

    def test_secret_material_and_unknown_fields_fail_before_storage(self) -> None:
        invalid = _submission()
        invalid["command"]["payload"]["api_key"] = "ghp_1234567890abcdef"
        with self.assertRaisesRegex(ProtocolError, "secret"):
            validate_dispatch_submission(invalid)

        invalid = _submission()
        invalid["provider"] = "codex"
        with self.assertRaisesRegex(ProtocolError, "Additional properties"):
            validate_dispatch_submission(invalid)

    def test_response_matrix_and_local_bounds_are_explicit(self) -> None:
        self.assertEqual(
            DISPATCH_RESPONSE_ACTIONS,
            {
                "accepted": "complete-delivery",
                "succeeded": "complete-success",
                "duplicate": "complete-original",
                "rejected": "dead-letter",
                "timeout": "retry-safe",
                "failed": "retry-safe",
                "uncertain": "reconcile",
            },
        )
        self.assertEqual(LOCAL_DISPATCH_CAPACITY, 1)
        self.assertEqual(DEFAULT_LEASE_SECONDS, 30.0)
        self.assertEqual(DEFAULT_MAX_ATTEMPTS, 5)
        self.assertEqual(DEFAULT_BACKOFF_SECONDS, 1.0)


if __name__ == "__main__":
    unittest.main()
