from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    finalize_owner_inbox_record,
    validate_owner_attention_item,
    validate_owner_inbox_snapshot,
)
from elder_protocol.factory_operations.owner_inbox import (
    _reduce_owner_inbox_snapshot,
)


def work_item(
    *,
    item_id: str = "work-item-owner-review",
    status: str = "validation",
    updated_at: str = "2026-08-13T10:00:00+00:00",
) -> dict:
    return {
        "work_item": {
            "id": item_id,
            "project_id": "product-one",
            "status": status,
            "created_at": "2026-08-13T09:00:00+00:00",
            "updated_at": updated_at,
            "content_sha256": "a" * 64,
        }
    }


def snapshot() -> dict:
    return _reduce_owner_inbox_snapshot(
        work_items=[work_item()],
        session_controls=[],
        recovery_cases=[],
        recovery_orphans=[],
        observed_at="2026-08-13T11:00:00+00:00",
    )


class OwnerInboxContractTests(unittest.TestCase):
    def test_valid_attention_item_and_snapshot(self) -> None:
        record = snapshot()
        validate_owner_inbox_snapshot(record)
        validate_owner_attention_item(record["items"][0])
        self.assertEqual(record["item_count"], 1)
        self.assertEqual(record["items"][0]["age_seconds"], 3600)

    def test_digest_and_closed_schema_fail(self) -> None:
        record = snapshot()
        record["content_sha256"] = "0" * 64
        with self.assertRaisesRegex(ProtocolError, "digest is invalid"):
            validate_owner_inbox_snapshot(record)

        extra = snapshot()
        extra["hidden_waiting_count"] = 0
        extra = finalize_owner_inbox_record(extra)
        with self.assertRaises(ProtocolError):
            validate_owner_inbox_snapshot(extra)

    def test_reason_policy_and_authority_tamper_fail(self) -> None:
        item = copy.deepcopy(snapshot()["items"][0])
        item["severity"] = "urgent"
        item["priority_rank"] = 4
        item = finalize_owner_inbox_record(item)
        with self.assertRaisesRegex(ProtocolError, "policy fields"):
            validate_owner_attention_item(item)

        action = copy.deepcopy(snapshot()["items"][0])
        action["allowed_actions"].append(
            {
                "action_id": "deploy",
                "kind": "session-control",
                "authority_mode": "execute-bounded",
                "available": True,
                "target_ref": action["subject"]["primary_ref"],
            }
        )
        action["allowed_actions"].sort(key=lambda value: value["action_id"])
        action = finalize_owner_inbox_record(action)
        with self.assertRaisesRegex(ProtocolError, "policy fields"):
            validate_owner_attention_item(action)

    def test_secret_and_project_filter_drift_fail(self) -> None:
        record = snapshot()
        record["api_key"] = "sk-owner-inbox-secret"
        record = finalize_owner_inbox_record(record)
        with self.assertRaisesRegex(ProtocolError, "forbidden secret"):
            validate_owner_inbox_snapshot(record)

        filtered = snapshot()
        filtered["project_filter"] = "product-two"
        filtered = finalize_owner_inbox_record(filtered)
        with self.assertRaisesRegex(ProtocolError, "another project"):
            validate_owner_inbox_snapshot(filtered)

    def test_chronology_and_source_count_drift_fail(self) -> None:
        chronology = snapshot()
        item = chronology["items"][0]
        item["first_observed_at"] = "2026-08-13T10:30:00+00:00"
        item["last_updated_at"] = "2026-08-13T10:30:00+00:00"
        item["age_seconds"] = 1800
        chronology["items"][0] = finalize_owner_inbox_record(item)
        chronology = finalize_owner_inbox_record(chronology)
        with self.assertRaisesRegex(ProtocolError, "chronology"):
            validate_owner_inbox_snapshot(chronology)

        observation = snapshot()
        item = observation["items"][0]
        item["observed_at"] = "2026-08-13T10:30:00+00:00"
        item["age_seconds"] = 1800
        observation["items"][0] = finalize_owner_inbox_record(item)
        observation = finalize_owner_inbox_record(observation)
        with self.assertRaisesRegex(ProtocolError, "observation time"):
            validate_owner_inbox_snapshot(observation)

        counts = snapshot()
        counts["source_counts"]["work-items"] = 0
        counts["source_counts"]["session-controls"] = 1
        counts = finalize_owner_inbox_record(counts)
        with self.assertRaisesRegex(ProtocolError, "source counts"):
            validate_owner_inbox_snapshot(counts)


if __name__ == "__main__":
    unittest.main()
