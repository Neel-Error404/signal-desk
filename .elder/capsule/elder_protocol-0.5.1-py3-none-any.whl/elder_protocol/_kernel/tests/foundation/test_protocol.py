from __future__ import annotations

import unittest

from elder_protocol.constants import PROTOCOL_VERSION, ROOT
from elder_protocol.io import load_json
from elder_protocol.profiles import validate_profile
from elder_protocol.protocol import validate_protocol
from elder_protocol.skills import validate_skill_registry


class ProtocolFoundationTests(unittest.TestCase):
    def test_repository_protocol_is_valid(self) -> None:
        data = validate_protocol()
        self.assertEqual(data["ontology"]["version"], PROTOCOL_VERSION)
        self.assertEqual(data["skill-registry"]["version"], PROTOCOL_VERSION)

    def test_example_profile_is_valid(self) -> None:
        data = validate_protocol()
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        validate_profile(profile, data)

    def test_skill_registry_is_valid(self) -> None:
        registry = validate_skill_registry(
            ROOT / "protocol" / "skill-registry.json", ROOT / "skills"
        )
        self.assertGreaterEqual(len(registry["skills"]), 10)

    def test_ontology_has_relationship_contract(self) -> None:
        ontology = validate_protocol()["ontology"]
        relation_ids = {relation["id"] for relation in ontology["relation_types"]}
        self.assertIn("traces-to", relation_ids)
        self.assertIn("constrains", relation_ids)
        self.assertIn("belongs-to", relation_ids)
        self.assertIn("adapts", relation_ids)
        entity_ids = {entity["id"] for entity in ontology["entity_types"]}
        self.assertIn("architecture-layer", entity_ids)
        self.assertIn("stack-adapter", entity_ids)

    def test_agent_interface_schemas_are_present(self) -> None:
        data = validate_protocol()
        for name in [
            "tool-contract.schema",
            "mcp-registry.schema",
            "context-packet.schema",
            "memory-record.schema",
            "learning-candidate.schema",
        ]:
            self.assertIn(name, data)

    def test_hierarchical_meta_architecture_and_protocol_graph_are_valid(self) -> None:
        data = validate_protocol()
        self.assertTrue(data["meta-architecture"]["identity"]["product_agnostic"])
        self.assertEqual(
            [layer["id"] for layer in data["meta-architecture"]["layers"]],
            [
                "kernel",
                "capability",
                "adapter",
                "project",
                "factory",
                "assurance-learning",
            ],
        )
        graph = data["protocol-graph"]
        node_ids = {node["id"] for node in graph["nodes"]}
        edge_types = {edge["type"] for edge in graph["edges"]}
        self.assertIn("layer:kernel", node_ids)
        self.assertIn("pack:agentic", node_ids)
        self.assertIn("skill:wayfinder", node_ids)
        self.assertIn("requires", edge_types)
        self.assertIn("governs", edge_types)

    def test_capability_packs_are_complete_contracts(self) -> None:
        packs = validate_protocol()["capability-packs"]["packs"]
        for pack in packs:
            self.assertIn(
                pack["layer"],
                {"kernel", "capability", "factory", "assurance-learning"},
            )
            self.assertTrue(pack["responsibilities"])
            self.assertTrue(pack["required_artifacts"])
            self.assertTrue(pack["required_evidence"])
            self.assertIn(
                pack["contract_status"],
                {"verified", "implemented", "specified", "planned"},
            )
            self.assertIn(
                pack["runtime_status"],
                {"verified", "reference-only", "specified", "planned"},
            )

        agentic = next(pack for pack in packs if pack["id"] == "agentic")
        self.assertEqual(agentic["contract_status"], "implemented")
        self.assertEqual(agentic["runtime_status"], "reference-only")

    def test_p4_assurance_constitution_maps_recommendations_to_enforcement(self) -> None:
        data = validate_protocol()
        recommendations = data["recommendation-ledger"]["recommendations"]
        self.assertGreaterEqual(len(recommendations), 14)
        for recommendation in recommendations:
            self.assertTrue(recommendation["architecture_layers"])
            self.assertTrue(recommendation["controls"])
            self.assertTrue(recommendation["required_artifacts"])
            self.assertTrue(recommendation["required_evidence"])
            self.assertNotEqual(recommendation["operational_status"], "claimed")

        packs = {
            pack["id"]: pack for pack in data["capability-packs"]["packs"]
        }
        self.assertTrue(packs["factory-operations"]["required"])
        self.assertTrue(packs["assurance"]["required"])
        self.assertIn(
            "component-operating-contract.schema",
            data,
        )
        self.assertIn("judgment-rubric", data)
        self.assertIn("operational-maturity", data)

    def test_p4_1_operational_assurance_contracts_are_connected(self) -> None:
        data = validate_protocol()
        self.assertGreaterEqual(len(data["design-registry"]["documents"]), 6)
        self.assertEqual(
            data["transcript-review-policy"]["trace_format"],
            "workflow-jsonl-v1",
        )
        for schema in [
            "design-registry.schema",
            "architecture-boundary.schema",
            "transcript-review-policy.schema",
            "transcript-review.schema",
        ]:
            self.assertIn(schema, data)
        for schema in [
            data["hosted-git-evidence.schema"],
            data["supervised-pr-execution.schema"],
            data["supervised-pr-packet.schema"],
            data["supervised-pr-response.schema"],
        ]:
            self.assertEqual(len(schema["allOf"]), 2)
        self.assertIn(
            "authorized_packet_sha256",
            data["supervised-pr-response.schema"]["required"],
        )

        node_ids = {node["id"] for node in data["protocol-graph"]["nodes"]}
        self.assertIn("design-document:ADR-0006", node_ids)
        self.assertIn(
            "control:elder-workflow-transcript-review",
            node_ids,
        )

    def test_p4_2_evaluation_harness_contracts_are_connected(self) -> None:
        data = validate_protocol()
        self.assertEqual(
            data["evaluation-dataset"]["id"],
            "elder-workbench-assurance-v1",
        )
        self.assertEqual(
            set(data["evaluator-contract"]["allowed_graders"]),
            {"exact", "contains", "numeric", "rubric"},
        )
        for schema in [
            "evaluation-registry.schema",
            "evaluation-dataset.schema",
            "evaluator-contract.schema",
            "evaluation-candidate.schema",
            "judge-results.schema",
            "evaluation-report.schema",
            "calibration-report.schema",
            "comparison-report.schema",
        ]:
            self.assertIn(schema, data)

        node_ids = {node["id"] for node in data["protocol-graph"]["nodes"]}
        self.assertIn("design-document:ADR-0007", node_ids)
        self.assertIn(
            "evaluation-dataset:elder-workbench-assurance-v1",
            node_ids,
        )
        self.assertIn(
            "evaluator-contract:elder-independent-evaluator",
            node_ids,
        )

    def test_p4_3_correlated_telemetry_contracts_are_connected(self) -> None:
        data = validate_protocol()
        self.assertEqual(
            set(data["telemetry-contract"]["scopes"]),
            {"product", "model", "tool", "factory", "cost", "outcome"},
        )
        self.assertEqual(
            data["telemetry-contract"]["authority"]["mode"],
            "advisory-only",
        )
        for schema in [
            "telemetry-contract.schema",
            "telemetry-event.schema",
            "telemetry-report.schema",
        ]:
            self.assertIn(schema, data)
        node_ids = {node["id"] for node in data["protocol-graph"]["nodes"]}
        self.assertIn("design-document:ADR-0008", node_ids)
        self.assertIn(
            "telemetry-contract:elder-correlated-telemetry-v1",
            node_ids,
        )
        invariant_ids = {
            invariant["id"] for invariant in data["invariants"]["invariants"]
        }
        self.assertIn("INV-010", invariant_ids)

    def test_p4_4_governed_knowledge_contracts_are_connected(self) -> None:
        data = validate_protocol()
        self.assertEqual(
            data["context-policy"]["allowed_memory_statuses"],
            ["trusted"],
        )
        self.assertEqual(
            data["memory-policy"]["trusted_promoters"],
            ["human-owner"],
        )
        self.assertFalse(
            data["context-policy"]["assembly"]["allow_wholesale_graph_context"]
        )
        for schema in [
            "context-policy.schema",
            "context-request.schema",
            "context-packet.schema",
            "memory-policy.schema",
            "memory-record.schema",
            "memory-approval.schema",
            "knowledge-graph.schema",
            "knowledge-query.schema",
        ]:
            self.assertIn(schema, data)
        node_ids = {node["id"] for node in data["protocol-graph"]["nodes"]}
        self.assertIn("design-document:ADR-0009", node_ids)
        self.assertIn(
            "context-policy:elder-governed-context-v1",
            node_ids,
        )
        self.assertIn(
            "memory-policy:elder-governed-memory-v1",
            node_ids,
        )
        invariant_ids = {
            invariant["id"] for invariant in data["invariants"]["invariants"]
        }
        self.assertTrue({"INV-011", "INV-028"} <= invariant_ids)

    def test_p4_5a_multi_agent_entry_gate_contracts_are_connected(self) -> None:
        data = validate_protocol()
        role_ids = {role["id"] for role in data["role-registry"]["roles"]}
        self.assertTrue(
            {
                "human-owner",
                "product-owner",
                "architecture-owner",
                "security-owner",
                "release-owner",
                "code-owner",
                "executor",
                "evaluator",
                "promoter",
            }
            <= role_ids
        )
        for schema in [
            "role-registry.schema",
            "authority-bindings.schema",
            "resolved-obligations.schema",
            "delegation.schema",
            "agent-message.schema",
            "checkpoint.schema",
            "approval-decision.schema",
            "stack-adapter.schema",
        ]:
            self.assertIn(schema, data)
        entity_ids = {entity["id"] for entity in data["ontology"]["entity_types"]}
        relation_ids = {relation["id"] for relation in data["ontology"]["relation_types"]}
        self.assertTrue({"delegation", "checkpoint", "message", "approval-decision"} <= entity_ids)
        self.assertTrue({"delegates", "spawns", "child-of", "checkpoints"} <= relation_ids)
        invariant_ids = {item["id"] for item in data["invariants"]["invariants"]}
        self.assertTrue({"INV-012", "INV-013", "INV-014", "INV-015", "INV-016"} <= invariant_ids)

    def test_p4_5b_runtime_policy_actions_leases_and_replay_are_connected(self) -> None:
        data = validate_protocol()
        self.assertEqual(
            data["multi-agent-runtime-policy"]["id"],
            "local-bounded-multi-agent-runtime",
        )
        self.assertEqual(
            data["multi-agent-runtime-policy"]["replay"]["mode"],
            "deterministic-state-reconstruction",
        )
        self.assertFalse(
            data["multi-agent-runtime-policy"]["authority"]["can_approve"]
        )
        self.assertFalse(
            data["multi-agent-runtime-policy"]["authority"]["can_promote"]
        )
        for schema in [
            "agent-action.schema",
            "runtime-lease.schema",
            "multi-agent-runtime-policy.schema",
        ]:
            self.assertIn(schema, data)
        entity_ids = {entity["id"] for entity in data["ontology"]["entity_types"]}
        relation_ids = {
            relation["id"] for relation in data["ontology"]["relation_types"]
        }
        self.assertTrue({"agent-action", "runtime-lease"} <= entity_ids)
        self.assertTrue(
            {"performs", "claims", "leases", "uses-context"} <= relation_ids
        )
        invariant_ids = {item["id"] for item in data["invariants"]["invariants"]}
        self.assertTrue({"INV-017", "INV-018"} <= invariant_ids)
        policy_schema = data["multi-agent-runtime-policy.schema"]
        for section in [
            "store",
            "dispatch",
            "sequencing",
            "enforcement",
            "replay",
            "authority",
        ]:
            contract = policy_schema["properties"][section]
            self.assertFalse(contract["additionalProperties"])
            self.assertTrue(contract["required"])
            self.assertTrue(contract["properties"])

    def test_p4_6_quarantined_learning_contracts_are_connected(self) -> None:
        data = validate_protocol()
        policy = data["learning-policy"]
        self.assertEqual(policy["id"], "elder-quarantined-learning-v1")
        self.assertEqual(
            policy["observation_modes"],
            ["counterfactual-replay", "shadow"],
        )
        self.assertTrue(policy["authority"]["promotion_packet_only"])
        self.assertFalse(policy["authority"]["candidate_can_mutate_target"])
        for schema in [
            "learning-policy.schema",
            "learning-candidate.schema",
            "learning-observation.schema",
            "learning-evaluation.schema",
            "learning-approval.schema",
            "learning-promotion.schema",
        ]:
            self.assertIn(schema, data)
        node_ids = {node["id"] for node in data["protocol-graph"]["nodes"]}
        self.assertIn("design-document:ADR-0012", node_ids)
        self.assertIn(
            "learning-policy:elder-quarantined-learning-v1",
            node_ids,
        )
        entity_ids = {entity["id"] for entity in data["ontology"]["entity_types"]}
        relation_ids = {
            relation["id"] for relation in data["ontology"]["relation_types"]
        }
        self.assertTrue(
            {
                "learning-candidate",
                "learning-observation",
                "learning-evaluation",
                "learning-approval",
                "learning-promotion",
            }
            <= entity_ids
        )
        self.assertTrue({"replays", "shadows", "qualifies"} <= relation_ids)
        invariant_ids = {item["id"] for item in data["invariants"]["invariants"]}
        self.assertTrue({"INV-019", "INV-020"} <= invariant_ids)

    def test_p4_7_hosted_qualification_contracts_are_connected(self) -> None:
        data = validate_protocol()
        policy = data["qualification-policy"]
        self.assertEqual(
            policy["id"],
            "elder-hosted-production-qualification-v1",
        )
        self.assertEqual(len(policy["trust"]["anchors"]), 2)
        anchors = {
            anchor["id"]: anchor for anchor in policy["trust"]["anchors"]
        }
        anchor = anchors["p4-8a-operator-verifier-v1"]
        self.assertEqual(
            anchor["id"],
            "p4-8a-operator-verifier-v1",
        )
        self.assertEqual(
            anchor["roles"],
            ["accountable-operator", "independent-verifier"],
        )
        self.assertEqual(
            anchor["providers"],
            ["elder-governance", "github-actions"],
        )
        self.assertEqual(anchor["source_hosts"], ["github.com"])
        self.assertEqual(anchor["status"], "active")
        reviewer = anchors["p4-8a-independent-reviewer-v1"]
        self.assertEqual(reviewer["roles"], ["independent-reviewer"])
        self.assertEqual(reviewer["providers"], ["elder-governance"])
        self.assertNotEqual(
            anchor["subject_identity"],
            reviewer["subject_identity"],
        )
        self.assertTrue(policy["trust"]["require_signature"])
        self.assertTrue(policy["qualification"]["advisory_only"])
        self.assertFalse(policy["qualification"]["can_mutate_maturity"])
        self.assertFalse(policy["qualification"]["can_promote"])
        self.assertFalse(policy["qualification"]["can_deploy"])
        for schema in [
            "qualification-policy.schema",
            "hosted-evidence-bundle.schema",
            "qualification-report.schema",
        ]:
            self.assertIn(schema, data)
        node_ids = {node["id"] for node in data["protocol-graph"]["nodes"]}
        self.assertIn("design-document:ADR-0013", node_ids)
        self.assertIn(
            "qualification-policy:elder-hosted-production-qualification-v1",
            node_ids,
        )
        entity_ids = {entity["id"] for entity in data["ontology"]["entity_types"]}
        relation_ids = {
            relation["id"] for relation in data["ontology"]["relation_types"]
        }
        self.assertTrue(
            {
                "qualification-policy",
                "hosted-evidence-bundle",
                "hosted-evidence-record",
                "qualification-report",
                "trust-anchor",
            }
            <= entity_ids
        )
        self.assertTrue({"attests", "verifies", "qualifies"} <= relation_ids)
        invariant_ids = {item["id"] for item in data["invariants"]["invariants"]}
        self.assertTrue({"INV-021", "INV-022"} <= invariant_ids)

    def test_p5_autonomy_contracts_are_connected_and_fail_closed(self) -> None:
        data = validate_protocol()
        policy = data["autonomy-policy"]
        registry = data["autonomy-classes"]
        self.assertEqual(policy["id"], "elder-bounded-autonomy-v1")
        self.assertEqual(policy["mode"], "qualification-gated-supervised-pr")
        self.assertEqual(len(registry["classes"]), 5)
        self.assertTrue(policy["authority"]["can_activate_certification"])
        self.assertTrue(policy["authority"]["can_issue_runtime_lease"])
        self.assertTrue(policy["authority"]["can_create_pr"])
        self.assertTrue(policy["authority"]["can_execute_canary"])
        self.assertFalse(policy["authority"]["can_promote_canary"])
        self.assertFalse(policy["authority"]["can_merge"])
        self.assertFalse(policy["authority"]["can_deploy"])
        self.assertFalse(policy["authority"]["can_mutate_maturity"])
        for schema in [
            "autonomy-authority-source.schema",
            "autonomy-policy.schema",
            "autonomy-class.schema",
            "autonomy-certification.schema",
            "incident-budget.schema",
            "autonomy-suspension.schema",
            "autonomy-revocation.schema",
            "autonomy-renewal.schema",
            "qualification-consumption.schema",
            "effective-autonomy-report.schema",
            "autonomy-work-item.schema",
            "autonomy-match-report.schema",
            "autonomy-simulation-report.schema",
            "autonomy-certification-event.schema",
            "autonomy-replay-report.schema",
            "autonomy-authority-evidence.schema",
            "autonomy-authority-lease.schema",
            "hosted-git-evidence.schema",
            "supervised-pr-execution.schema",
            "supervised-pr-packet.schema",
            "supervised-pr-response.schema",
            "canary-plan.schema",
            "canary-simulation-report.schema",
            "canary-authority-lease.schema",
            "canary-authority-evidence.schema",
            "canary-provider-evidence.schema",
            "canary-execution-packet.schema",
            "canary-response.schema",
            "canary-observation.schema",
            "canary-observation-report.schema",
            "canary-rollback-packet.schema",
            "canary-rollback-response.schema",
            "canary-workflow-result.schema",
        ]:
            self.assertIn(schema, data)
        node_ids = {node["id"] for node in data["protocol-graph"]["nodes"]}
        self.assertIn("design-document:ADR-0014", node_ids)
        self.assertIn("design-document:ADR-0018", node_ids)
        self.assertIn(
            "autonomy-policy:elder-bounded-autonomy-v1",
            node_ids,
        )
        self.assertIn(
            "autonomy-class:documentation-only-correction",
            node_ids,
        )
        entity_ids = {entity["id"] for entity in data["ontology"]["entity_types"]}
        relation_ids = {
            relation["id"] for relation in data["ontology"]["relation_types"]
        }
        self.assertTrue(
            {
                "autonomy-policy",
                "autonomy-class",
                "autonomy-certification",
                "incident-budget",
                "autonomy-suspension",
                "autonomy-revocation",
                "autonomy-renewal",
                "qualification-consumption",
                "effective-autonomy-report",
                "autonomy-authority-source",
                "autonomy-authority-evidence",
                "hosted-git-evidence",
                "supervised-pr-response",
                "canary-plan",
                "canary-authority-evidence",
                "canary-authority-lease",
                "canary-provider-evidence",
                "canary-execution-packet",
                "canary-response",
                "canary-observation",
                "canary-observation-report",
                "canary-rollback-packet",
                "canary-rollback-response",
                "canary-workflow-result",
            }
            <= entity_ids
        )
        self.assertTrue(
            {
                "subclass-of",
                "certifies",
                "consumes",
                "suspends",
                "revokes",
                "renews",
                "calculates",
                "authorizes-canary",
                "packages-canary",
                "confirms-canary",
                "observes-canary",
                "rolls-back-canary",
            }
            <= relation_ids
        )
        invariant_ids = {item["id"] for item in data["invariants"]["invariants"]}
        self.assertTrue(
            {"INV-023", "INV-024", "INV-025", "INV-029"} <= invariant_ids
        )


if __name__ == "__main__":
    unittest.main()
