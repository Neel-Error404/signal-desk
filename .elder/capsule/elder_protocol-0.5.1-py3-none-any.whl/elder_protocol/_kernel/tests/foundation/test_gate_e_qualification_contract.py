from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[2]


class GateEQualificationContractTests(unittest.TestCase):
    def test_qualification_documents_cover_exact_gate_and_non_claims(
        self,
    ) -> None:
        paths = [
            ROOT / "docs/software-factory/Gate-E-qualification-task-packet.md",
            ROOT / "docs/software-factory/Gate-E-qualification-design.md",
            ROOT
            / "docs/software-factory/Gate-E-qualification-implementation-plan.md",
            ROOT
            / "docs/software-factory/Gate-E-qualification-test-reproduction.md",
            ROOT / "docs/software-factory/evidence/Gate-E.md",
        ]
        text = "\n".join(path.read_text(encoding="utf-8") for path in paths)
        for phrase in (
            "expired authority",
            "stale context",
            "missing evidence",
            "unauthorized transition",
            "owner-visible",
            "Canonical Elder maturity remains L1",
            "Phase 5",
        ):
            self.assertIn(phrase, text)

    def test_qualification_composes_existing_phase_4_services(self) -> None:
        support = (
            ROOT / "tests/_gate_e_support.py"
        ).read_text(encoding="utf-8")
        for service in (
            "GovernedContextAssembly",
            "AuthorityDelegationIntegration",
            "EvidenceTestPipeline",
            "SupervisedDeliveryService",
        ):
            self.assertIn(service, support)
        self.assertNotIn("class GateEAuthority", support)
        self.assertNotIn("class GateEContext", support)
        self.assertNotIn("class GateEEvidence", support)


if __name__ == "__main__":
    unittest.main()
