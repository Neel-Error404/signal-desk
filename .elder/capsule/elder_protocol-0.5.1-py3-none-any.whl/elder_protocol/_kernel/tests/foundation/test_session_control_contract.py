from __future__ import annotations

import copy
import unittest
from pathlib import Path

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    SESSION_CONTROL_OPERATIONS,
    SESSION_CONTROL_VERSION,
    DurableSessionController,
    validate_session_control_command,
)
from elder_protocol.schema_validation import validate_schema_catalog


class SessionControlFoundationTests(unittest.TestCase):
    def test_schemas_exports_and_design_are_package_visible(self) -> None:
        schemas = validate_schema_catalog(Path("factory/operations"))
        self.assertIn("session-control-command.schema.json", schemas)
        self.assertIn("session-control-record.schema.json", schemas)
        self.assertEqual(SESSION_CONTROL_VERSION, "1.0.0")
        self.assertEqual(
            DurableSessionController.__name__,
            "DurableSessionController",
        )
        self.assertEqual(
            SESSION_CONTROL_OPERATIONS,
            {
                "start",
                "prompt",
                "follow-up",
                "steer",
                "wait",
                "pause",
                "resume",
                "checkpoint",
                "cancel",
            },
        )
        for path in (
            "docs/software-factory/SF-203-task-packet.md",
            "docs/software-factory/SF-203-design.md",
        ):
            self.assertTrue(Path(path).is_file(), path)

    @staticmethod
    def _command(operation: str, payload: dict) -> dict:
        command = {
            "version": "1.0.0",
            "control_id": f"session-control-foundation-{operation.replace('-', '')}",
            "idempotency_key": f"foundation-{operation}-idempotency",
            "operation": operation,
            "project_id": "project-one",
            "run_id": f"run-{'1' * 32}",
            "worker_session_id": f"worker-session-{'2' * 32}",
            "workspace_id": f"workspace-{'3' * 32}",
            "workspace_binding_sha256": "4" * 64,
            "session_generation": 1,
            "requested_by_identity_id": "founder",
            "submitted_at": "2026-08-13T12:00:00+00:00",
            "deadline_at": "2026-08-13T12:30:00+00:00",
            "reason": "Exercise the bounded session control contract.",
            "payload": payload,
            "payload_sha256": canonical_sha256(payload),
        }
        return command

    def test_operation_payloads_are_closed_and_digest_bound(self) -> None:
        payloads = {
            "start": {},
            "prompt": {"instruction": "Implement the bounded change."},
            "follow-up": {
                "instruction": "Continue after owner input.",
                "continuation_of": "session-control-waiting",
            },
            "steer": {"instruction": "Correct the current approach."},
            "wait": {"waiting_reason": "owner-decision"},
            "pause": {},
            "resume": {},
            "checkpoint": {
                "checkpoint_id": "checkpoint-one",
                "checkpoint_sha256": "5" * 64,
            },
            "cancel": {},
        }
        for operation, payload in payloads.items():
            with self.subTest(operation=operation):
                validate_session_control_command(
                    self._command(operation, payload)
                )
        changed = self._command("pause", {})
        changed["payload"]["extra"] = True
        changed["payload_sha256"] = canonical_sha256(changed["payload"])
        with self.assertRaisesRegex(ProtocolError, "fields must be exactly"):
            validate_session_control_command(changed)
        drifted = self._command("wait", {"waiting_reason": "owner"})
        drifted["payload_sha256"] = "0" * 64
        with self.assertRaisesRegex(ProtocolError, "digest"):
            validate_session_control_command(drifted)

    def test_secret_shaped_controls_fail_before_storage(self) -> None:
        command = self._command(
            "prompt",
            {"instruction": "Use api_key=sk-example-secret-value"},
        )
        with self.assertRaises(ProtocolError):
            validate_session_control_command(command)
        unknown = copy.deepcopy(self._command("start", {}))
        unknown["provider_thread_id"] = "provider-specific"
        with self.assertRaises(ProtocolError):
            validate_session_control_command(unknown)


if __name__ == "__main__":
    unittest.main()
