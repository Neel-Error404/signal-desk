from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    GATE_C_FORBIDDEN_AUTHORITY,
    finalize_gate_c_record,
    validate_gate_c_qualification_packet,
    validate_gate_c_restart_manifest,
)


def restart_manifest() -> dict:
    return finalize_gate_c_record(
        {
            "version": "1.0.0",
            "qualification_id": "gate-c-" + "a" * 24,
            "phase": "pre-restart",
            "process_id": 101,
            "boot_id": "boot-before",
            "root": "C:/gate-c",
            "operations_store": "C:/gate-c/operations.db",
            "session_store": "C:/gate-c/session.db",
            "worker_store": "C:/gate-c/worker.db",
            "recovery_store": "C:/gate-c/recovery.db",
            "repository": "C:/gate-c/repository",
            "workspace": "C:/gate-c/workspace",
            "project_id": "gate-c-project",
            "signal_id": "signal-gate-c",
            "work_item_id": "work-item-gate-c",
            "dispatch_id": "dispatch-gate-c",
            "run_id": "run-" + "b" * 32,
            "workspace_id": "workspace-gate-c",
            "worker_session_id": "worker-session-gate-c",
            "session_generation": 1,
            "start_control_id": "control-start",
            "prompt_control_id": "control-prompt",
            "prompt_control_sha256": "c" * 64,
            "prompt_response_sha256": "d" * 64,
            "external_session_ref_sha256": "e" * 64,
            "baseline_revision": "f" * 40,
            "recorded_at": "2026-08-13T19:30:00+00:00",
        }
    )


def qualification_packet(*, live_codex: bool = True) -> dict:
    return finalize_gate_c_record(
        {
            "version": "1.0.0",
            "qualification_id": "gate-c-" + "a" * 24,
            "gate": "C",
            "verdict": "pass",
            "live_codex": live_codex,
            "project_id": "gate-c-project",
            "signal": {"id": "signal-gate-c", "content_sha256": "1" * 64},
            "work_item": {
                "id": "work-item-gate-c",
                "content_sha256": "2" * 64,
                "status": "completed",
            },
            "dispatch": {
                "id": "dispatch-gate-c",
                "content_sha256": "3" * 64,
            },
            "run": {
                "id": "run-" + "b" * 32,
                "content_sha256": "4" * 64,
                "status": "completed",
            },
            "workspace": {
                "id": "workspace-gate-c",
                "content_sha256": "5" * 64,
                "status": "retained",
                "path_sha256": "6" * 64,
                "sandbox_sha256": "7" * 64,
            },
            "worker": {
                "adapter_id": "codex-worker-v1",
                "cli_version": "codex-cli-test",
                "external_session_ref_sha256": "8" * 64,
                "thread_continuity_sha256": "9" * 64,
                "prompt_effect_count": 1,
                "prompt_response_sha256": "a" * 64,
            },
            "restart": {
                "before_process_id": 101,
                "before_boot_id": "boot-before",
                "after_process_id": 202,
                "after_boot_id": "boot-after",
                "terminated": True,
                "manifest_sha256": "b" * 64,
            },
            "git": {
                "baseline_revision": "f" * 40,
                "changed_paths": ["RESULT.txt"],
                "diff_sha256": "c" * 64,
                "staged": False,
                "committed": False,
            },
            "test": {
                "command_sha256": "d" * 64,
                "exit_code": 0,
                "stdout_sha256": "e" * 64,
                "stderr_sha256": "f" * 64,
            },
            "checkpoint": {
                "id": "checkpoint-gate-c",
                "content_sha256": "0" * 64,
                "reference_sha256": "1" * 64,
            },
            "evidence_bundle": {
                "artifact_ref_id": "artifact-gate-c-evidence",
                "artifact_sha256": "2" * 64,
                "reference_sha256": "3" * 64,
                "status": "verified",
            },
            "recovery": {"open_case_count": 0, "orphan_count": 0},
            "forbidden_authority": list(GATE_C_FORBIDDEN_AUTHORITY),
            "recorded_at": "2026-08-13T19:35:00+00:00",
        }
    )


class GateCQualificationContractTests(unittest.TestCase):
    def test_restart_manifest_and_passing_packet_validate(self) -> None:
        validate_gate_c_restart_manifest(restart_manifest())
        validate_gate_c_qualification_packet(qualification_packet())

    def test_digest_and_closed_schema_fail(self) -> None:
        packet = qualification_packet()
        packet["content_sha256"] = "0" * 64
        with self.assertRaisesRegex(ProtocolError, "digest is invalid"):
            validate_gate_c_qualification_packet(packet)

        extra = qualification_packet()
        extra["authority"] = "merge"
        extra = finalize_gate_c_record(extra)
        with self.assertRaises(ProtocolError):
            validate_gate_c_qualification_packet(extra)

    def test_passing_packet_requires_live_restart_and_one_effect(self) -> None:
        packet = qualification_packet(live_codex=False)
        with self.assertRaisesRegex(ProtocolError, "live Codex execution"):
            validate_gate_c_qualification_packet(packet)

        duplicate = qualification_packet()
        duplicate["worker"]["prompt_effect_count"] = 2
        duplicate = finalize_gate_c_record(duplicate)
        with self.assertRaisesRegex(ProtocolError, "exactly one prompt effect"):
            validate_gate_c_qualification_packet(duplicate)

        in_process = qualification_packet()
        in_process["restart"]["after_boot_id"] = "boot-before"
        in_process = finalize_gate_c_record(in_process)
        with self.assertRaisesRegex(ProtocolError, "distinct restarted process"):
            validate_gate_c_qualification_packet(in_process)

    def test_secret_material_and_authority_expansion_fail(self) -> None:
        manifest = restart_manifest()
        manifest["api_key"] = "sk-example-secret"
        manifest = finalize_gate_c_record(manifest)
        with self.assertRaisesRegex(ProtocolError, "forbidden secret"):
            validate_gate_c_restart_manifest(manifest)

        packet = qualification_packet()
        packet["forbidden_authority"] = [
            value
            for value in packet["forbidden_authority"]
            if value != "deployment"
        ]
        packet = finalize_gate_c_record(packet)
        with self.assertRaises(ProtocolError):
            validate_gate_c_qualification_packet(packet)


if __name__ == "__main__":
    unittest.main()
