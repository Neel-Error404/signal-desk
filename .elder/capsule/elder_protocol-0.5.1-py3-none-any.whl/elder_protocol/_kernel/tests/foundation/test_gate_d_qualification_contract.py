from __future__ import annotations

import unittest

from elder_protocol.constants import ROOT


CONTROL_ROOM = (
    ROOT / "elder_protocol" / "factory_operations" / "control_room"
)


class GateDQualificationContractTests(unittest.TestCase):
    def test_control_room_exposes_attention_and_composed_owner_surfaces(
        self,
    ) -> None:
        html = (CONTROL_ROOM / "index.html").read_text(encoding="utf-8")
        script = (CONTROL_ROOM / "app.js").read_text(encoding="utf-8")
        styles = (CONTROL_ROOM / "styles.css").read_text(encoding="utf-8")
        for required in (
            'id="owner-inbox"',
            'id="inbox-items"',
            'id="work-room"',
            'id="room-audit"',
            'id="room-metrics-proof"',
        ):
            self.assertIn(required, html)
        for required in (
            "requestInbox",
            "/v1/owner-inbox",
            "requestRoom",
            "requestAudit",
            "requestProjectMetrics",
            "submitRoomInput",
        ):
            self.assertIn(required, script)
        self.assertIn(".owner-inbox", styles)
        self.assertIn(".room-open > .owner-inbox", styles)

    def test_gate_d_documents_keep_sf400_out_of_scope(self) -> None:
        paths = [
            ROOT / "docs" / "software-factory" / name
            for name in (
                "Gate-D-qualification-task-packet.md",
                "Gate-D-qualification-design.md",
                "Gate-D-qualification-implementation-plan.md",
                "Gate-D-qualification-test-reproduction.md",
                "evidence/Gate-D.md",
            )
        ]
        for path in paths:
            self.assertTrue(path.is_file(), path)
            text = path.read_text(encoding="utf-8")
            self.assertIn("Gate D", text)
            self.assertIn("SF-400", text)


if __name__ == "__main__":
    unittest.main()
