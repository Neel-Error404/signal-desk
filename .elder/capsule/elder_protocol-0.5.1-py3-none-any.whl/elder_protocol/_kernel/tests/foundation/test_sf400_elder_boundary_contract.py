from __future__ import annotations

import unittest

from elder_protocol.constants import ROOT
from elder_protocol.factory_contracts import validate_factory_contracts
from elder_protocol.factory_operations.elder_boundary import (
    GOVERNANCE_OPERATIONS,
    MUTATING_OPERATIONS,
    POLICY_DOCUMENTS,
    validate_elder_boundary_snapshot,
)
from tests._sf400_support import boundary_snapshot


class SF400ElderBoundaryFoundationTests(unittest.TestCase):
    def test_boundary_consumes_the_ratified_governance_contract(self) -> None:
        registry = validate_factory_contracts()
        governance = next(
            contract
            for contract in registry["contracts"]
            if contract["id"] == "governance-adapter"
        )
        self.assertEqual(
            [operation["name"] for operation in governance["operations"]],
            list(GOVERNANCE_OPERATIONS),
        )
        self.assertEqual(
            {
                operation["name"]
                for operation in governance["operations"]
                if operation["mutability"] == "mutation"
            },
            MUTATING_OPERATIONS,
        )

    def test_snapshot_covers_each_operation_policy(self) -> None:
        snapshot = validate_elder_boundary_snapshot(boundary_snapshot())
        self.assertEqual(
            set(snapshot["policy_sha256"]),
            set(GOVERNANCE_OPERATIONS),
        )
        self.assertEqual(set(POLICY_DOCUMENTS), set(GOVERNANCE_OPERATIONS))

    def test_task_documents_preserve_later_phase_boundaries(self) -> None:
        for name in (
            "SF-400-task-packet.md",
            "SF-400-design.md",
            "SF-400-implementation-plan.md",
        ):
            text = (ROOT / "docs" / "software-factory" / name).read_text(
                encoding="utf-8"
            )
            self.assertIn("SF-400", text)
            self.assertIn("SF-401", text)
            self.assertIn("L1", text)


if __name__ == "__main__":
    unittest.main()
