from __future__ import annotations

import copy
import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.research_sources import (
    _verify_bound_file,
    _verify_checkout,
    _verify_package_metadata,
    validate_research_sources,
)
from elder_protocol.schema_validation import validate_against_schema


MANIFEST_PATH = ROOT / "docs" / "software-factory" / "research-sources.json"
SCHEMA_ROOT = MANIFEST_PATH.parent


class ResearchSourceFoundationTests(unittest.TestCase):
    def test_canonical_research_sources_are_valid(self) -> None:
        report = validate_research_sources(MANIFEST_PATH, ROOT)
        self.assertEqual(report["source_count"], 5)
        self.assertFalse(report["checkouts_verified"])

    def test_source_requires_revision_license_path_and_reuse_decision(self) -> None:
        manifest = load_json(MANIFEST_PATH)
        cases = [
            ("revision", "revision"),
            ("license", "license"),
            ("local_path", "local_path"),
            ("reuse", "reuse"),
        ]
        for field, expected in cases:
            with self.subTest(field=field):
                invalid = copy.deepcopy(manifest)
                del invalid["sources"][0][field]
                with self.assertRaisesRegex(ProtocolError, expected):
                    validate_against_schema(
                        invalid,
                        "research-sources.schema.json",
                        label="Research-source manifest",
                        schema_root=SCHEMA_ROOT,
                    )

    def test_available_source_requires_exact_commit(self) -> None:
        invalid = load_json(MANIFEST_PATH)
        invalid["sources"][0]["revision"]["commit"] = "main"
        with self.assertRaisesRegex(ProtocolError, "commit"):
            validate_against_schema(
                invalid,
                "research-sources.schema.json",
                label="Research-source manifest",
                schema_root=SCHEMA_ROOT,
            )

    def test_unavailable_source_cannot_claim_code_or_package_reuse(self) -> None:
        invalid = load_json(MANIFEST_PATH)
        source = next(
            item
            for item in invalid["sources"]
            if item["source_availability"] == "unavailable"
        )
        source["reuse"]["code_reuse"] = "copied"
        with self.assertRaisesRegex(ProtocolError, "code_reuse"):
            validate_against_schema(
                invalid,
                "research-sources.schema.json",
                label="Research-source manifest",
                schema_root=SCHEMA_ROOT,
            )

    def test_undeclared_elder_license_blocks_compatibility_claim(self) -> None:
        invalid = load_json(MANIFEST_PATH)
        invalid["sources"][0]["reuse"][
            "repository_license_compatibility"
        ] = "compatible"
        with self.assertRaisesRegex(ProtocolError, "not declared"):
            temporary = MANIFEST_PATH.with_name("research-sources.invalid.json")
            temporary.write_text(
                json.dumps(invalid),
                encoding="utf-8",
            )
            try:
                validate_research_sources(temporary, ROOT)
            finally:
                temporary.unlink(missing_ok=True)

    def test_bound_evidence_digest_uses_exact_file_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evidence = root / "evidence.txt"
            content = b"line one\r\nline two\r\n"
            evidence.write_bytes(content)
            _verify_bound_file(
                root,
                {
                    "path": "evidence.txt",
                    "sha256": hashlib.sha256(content).hexdigest(),
                },
                "Test evidence",
            )

    def test_bound_evidence_rejects_a_stale_digest(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evidence = root / "evidence.txt"
            evidence.write_bytes(b"current bytes")
            with self.assertRaisesRegex(ProtocolError, "digest is stale"):
                _verify_bound_file(
                    root,
                    {
                        "path": "evidence.txt",
                        "sha256": hashlib.sha256(b"older bytes").hexdigest(),
                    },
                    "Test evidence",
                )

    def test_parsed_package_metadata_rejects_a_version_mismatch(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            checkout = Path(directory)
            (checkout / "package.json").write_text(
                json.dumps({"name": "example", "version": "2.0.0"}),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ProtocolError, "package version"):
                _verify_package_metadata(
                    checkout,
                    {
                        "path": "package.json",
                        "package_name": "example",
                        "version": "1.0.0",
                        "metadata_verification": "parsed-json",
                    },
                    "example",
                )

    def test_checkout_verification_rejects_a_dirty_worktree(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            checkout = root / "source"
            subprocess.run(
                ["git", "init", str(checkout)],
                capture_output=True,
                text=True,
                check=True,
            )
            subprocess.run(
                ["git", "-C", str(checkout), "config", "user.name", "Test"],
                check=True,
            )
            subprocess.run(
                [
                    "git",
                    "-C",
                    str(checkout),
                    "config",
                    "user.email",
                    "test@example.invalid",
                ],
                check=True,
            )
            subprocess.run(
                [
                    "git",
                    "-C",
                    str(checkout),
                    "remote",
                    "add",
                    "origin",
                    "https://example.invalid/source.git",
                ],
                check=True,
            )
            evidence = checkout / "README.md"
            evidence.write_text("initial\n", encoding="utf-8")
            subprocess.run(
                ["git", "-C", str(checkout), "add", "README.md"],
                check=True,
            )
            subprocess.run(
                ["git", "-C", str(checkout), "commit", "-m", "initial"],
                capture_output=True,
                text=True,
                check=True,
            )
            commit = subprocess.run(
                ["git", "-C", str(checkout), "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                check=True,
            ).stdout.strip()
            evidence.write_text("modified\n", encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "must be clean"):
                _verify_checkout(
                    {
                        "id": "example",
                        "local_path": "source",
                        "upstream_url": "https://example.invalid/source.git",
                        "source_availability": "available",
                        "revision": {"commit": commit},
                    },
                    root,
                )

    def test_approved_policy_must_bind_the_decision_record(self) -> None:
        invalid = load_json(MANIFEST_PATH)
        invalid["reuse_policy"].update(
            {
                "status": "approved",
                "selected_option": "reference-only",
                "approved_by": "human-owner",
                "approved_at": "2026-08-07",
                "approval_evidence": "unbound-owner-note",
            }
        )
        for source in invalid["sources"]:
            source["reuse"]["approval_state"] = "human-approved"
            source["reuse"]["approval_basis"] = "elder-software-factory-reuse-v1"
        temporary = MANIFEST_PATH.with_name("research-sources.invalid.json")
        temporary.write_text(json.dumps(invalid), encoding="utf-8")
        try:
            with self.assertRaisesRegex(ProtocolError, "decision-record"):
                validate_research_sources(temporary, ROOT)
        finally:
            temporary.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
