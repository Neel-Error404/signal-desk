from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
ARCHITECTURE_PATH = ROOT / "factory" / "operational-architecture.json"
SCHEMA_PATH = ROOT / "factory" / "operational-architecture.schema.json"
RATIFICATION_PATH = (
    ROOT / "docs" / "software-factory" / "evidence" / "SF-006-ratification.json"
)


def _accepted_architecture_sha256(architecture: dict[str, object]) -> str:
    canonical = json.loads(json.dumps(architecture))
    ratification = canonical["ratification"]
    if not isinstance(ratification, dict):
        raise AssertionError("Accepted architecture must contain a ratification object.")
    ratification.pop("accepted_architecture_sha256", None)
    ratification.pop("approval_record_sha256", None)
    payload = json.dumps(
        canonical,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


class OperationalArchitectureFoundationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.architecture = json.loads(ARCHITECTURE_PATH.read_text(encoding="utf-8"))
        cls.schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))

    def test_architecture_document_matches_schema(self) -> None:
        Draft202012Validator.check_schema(self.schema)
        errors = sorted(
            Draft202012Validator(self.schema).iter_errors(self.architecture),
            key=lambda item: list(item.absolute_path),
        )
        self.assertEqual([], [error.message for error in errors])

    def test_acceptance_is_bound_to_the_human_ratification_record(self) -> None:
        self.assertEqual("accepted", self.architecture["status"])
        self.assertFalse(self.architecture["ratification_required"])
        ratification = self.architecture["ratification"]
        approval_record = json.loads(RATIFICATION_PATH.read_text(encoding="utf-8"))
        self.assertEqual("ratified", ratification["decision"])
        self.assertEqual("human-owner", ratification["ratifier_role"])
        self.assertEqual(
            {"human-owner", "architecture-owner", "code-owner"},
            set(ratification["approved_roles"]),
        )
        for proposal_key, digest_key in (
            ("proposal_adr", "proposal_adr_sha256"),
            ("proposal_architecture", "proposal_architecture_sha256"),
        ):
            proposal = approval_record[proposal_key]
            snapshot = (ROOT / proposal["path"]).resolve()
            self.assertTrue(snapshot.is_relative_to(ROOT))
            self.assertTrue(snapshot.is_file())
            self.assertEqual(
                proposal["sha256"],
                hashlib.sha256(snapshot.read_bytes()).hexdigest(),
            )
            self.assertEqual(
                proposal["sha256"],
                ratification[digest_key],
            )
        self.assertEqual(
            ratification["approval_record_sha256"],
            hashlib.sha256(RATIFICATION_PATH.read_bytes()).hexdigest(),
        )
        self.assertEqual(
            self.architecture["ratified_inputs"],
            approval_record["accepted_inputs"],
        )

        ratified_inputs = json.dumps(
            self.architecture["ratified_inputs"],
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        self.assertEqual(
            ratification["ratified_inputs_sha256"],
            hashlib.sha256(ratified_inputs).hexdigest(),
        )
        self.assertEqual(
            ratification["ratified_inputs_sha256"],
            approval_record["ratified_inputs_sha256"],
        )
        self.assertEqual(
            ratification["accepted_architecture_sha256"],
            _accepted_architecture_sha256(self.architecture),
        )
        self.assertEqual(
            ratification["accepted_architecture_sha256"],
            approval_record["accepted_architecture_sha256"],
        )
        unsigned_record = {
            key: value
            for key, value in approval_record.items()
            if key != "content_sha256"
        }
        canonical_record = json.dumps(
            unsigned_record,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        self.assertEqual(
            approval_record["content_sha256"],
            hashlib.sha256(canonical_record).hexdigest(),
        )

    def test_worker_and_provider_state_are_non_authoritative(self) -> None:
        planes = {item["id"]: item for item in self.architecture["planes"]}
        self.assertFalse(planes["worker"]["canonical_state"])
        self.assertEqual("codex", self.architecture["workers"]["primary"])
        self.assertEqual(
            "deferred",
            self.architecture["workers"]["optional"]["status"],
        )
        self.assertEqual(
            [],
            self.architecture["dependencies"]["direct_external_packages"],
        )

    def test_operations_store_does_not_absorb_elder_authority(self) -> None:
        components = {
            item["id"]: item for item in self.architecture["components"]
        }
        self.assertEqual(
            "product-owner",
            components["product-registry"]["owner_plane"],
        )
        stores = {item["id"]: item for item in self.architecture["stores"]}
        self.assertEqual(
            ".factory/runtime/operations.db",
            stores["operations-store"]["path"],
        )
        for required in {
            "knowledge-store",
            "coordination-store",
            "learning-store",
            "qualification-autonomy-records",
        }:
            self.assertIn(required, stores)
            self.assertNotEqual(
                stores["operations-store"]["authority"],
                stores[required]["authority"],
            )
        self.assertIn(
            "operations-store->elder-authority-replacement",
            self.architecture["dependencies"]["forbidden"],
        )
        self.assertIn(
            "dispatch leases never substitute for identity delegation approval or authority",
            self.architecture["authority_constraints"],
        )
        self.assertIn(
            "operations custody of product factory bindings does not transfer product owner authority",
            self.architecture["authority_constraints"],
        )
        self.assertIn(
            "every transition verifies an exact Elder action resource mapping and current authorization evidence",
            self.architecture["fitness_functions"],
        )

    def test_dependency_and_migration_controls_fail_closed(self) -> None:
        forbidden = set(self.architecture["dependencies"]["forbidden"])
        self.assertTrue(
            {
                "owner-client->database",
                "integration-adapter->worker-runtime",
                "worker-runtime->work-ledger",
                "worker-runtime->trusted-memory",
                "provider-object->canonical-identity",
                "live-event-or-projection->command-completion",
            }
            <= forbidden
        )
        migration = self.architecture["migration"]
        self.assertEqual("quiesced-single-writer-cutover", migration["mode"])
        self.assertFalse(migration["dual_writable_primaries"])
        self.assertTrue(
            {
                "source-backup-digest",
                "journal-tip-and-hash-equality",
                "projection-digest-equality",
            }
            <= set(migration["required_checks"])
        )

    def test_contract_layers_and_runtime_primitives_are_distinct(self) -> None:
        layers = {item["id"]: item for item in self.architecture["contract_layers"]}
        self.assertEqual(
            {
                "p3-factory-substrate",
                "sf002-factory-domain",
                "sf003-operations-contracts",
            },
            set(layers),
        )
        self.assertTrue(
            all(
                item["relationship"] == "layered-not-superseded"
                for item in layers.values()
            )
        )
        primitives = {
            item["id"]: item for item in self.architecture["runtime_primitives"]
        }
        self.assertEqual(
            "none",
            primitives["factory-dispatch-lease"]["authority_effect"],
        )
        self.assertEqual(
            "delegated-authorization",
            primitives["elder-delegation-runtime-lease"]["authority_effect"],
        )
        self.assertNotEqual(
            primitives["worker-checkpoint-observation"]["authority_store"],
            primitives["canonical-delegated-checkpoint"]["authority_store"],
        )

    def test_ratified_inputs_bind_current_file_bytes(self) -> None:
        required_inputs = {
            "factory/factory-domain.json",
            "factory/factory-domain.schema.json",
            "factory/factory-entity.schema.json",
            "factory/factory-contracts.json",
            "factory/factory-contracts.schema.json",
            "factory/factory-command.schema.json",
            "factory/factory-event.schema.json",
            "factory/factory-adapter-request.schema.json",
            "factory/factory-adapter-response.schema.json",
            "factory/factory-cursor.schema.json",
            "factory/operational-architecture.schema.json",
            "docs/software-factory/11-canonical-factory-domain.md",
            "docs/software-factory/12-stable-contracts-and-events.md",
            "docs/software-factory/13-mastra-operations-spike.md",
            "docs/software-factory/14-codex-prime-worker-spike.md",
        }
        self.assertEqual(
            required_inputs,
            {item["path"] for item in self.architecture["ratified_inputs"]},
        )
        for item in self.architecture["ratified_inputs"]:
            target = (ROOT / item["path"]).resolve()
            self.assertTrue(target.is_relative_to(ROOT))
            self.assertTrue(target.is_file(), item["path"])
            self.assertEqual(
                item["sha256"],
                hashlib.sha256(target.read_bytes()).hexdigest(),
                item["path"],
            )

    def test_rollout_remains_evidence_bounded(self) -> None:
        rollout = self.architecture["rollout"]
        self.assertEqual(
            list(range(1, len(rollout) + 1)),
            [item["order"] for item in rollout],
        )
        self.assertEqual("local-operations-kernel", rollout[0]["id"])
        self.assertEqual("hosted-l2", rollout[-2]["id"])
        self.assertEqual("narrow-l3", rollout[-1]["id"])
        self.assertIn(
            "canonical maturity remains L1 until independently qualified",
            self.architecture["authority_constraints"],
        )


if __name__ == "__main__":
    unittest.main()
