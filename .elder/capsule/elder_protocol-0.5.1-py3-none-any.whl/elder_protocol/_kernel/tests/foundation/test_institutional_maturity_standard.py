from __future__ import annotations

from pathlib import Path
import unittest

from elder_protocol.protocol import validate_protocol


ROOT = Path(__file__).resolve().parents[2]


class InstitutionalMaturityStandardFoundationTests(unittest.TestCase):
    def test_l2_l3_standard_is_canonical_and_graph_connected(self) -> None:
        data = validate_protocol()
        maturity = data["operational-maturity"]
        standard = maturity["institutional_standard"]

        self.assertEqual(
            standard["id"],
            "elder-factory-maturity-standard",
        )
        self.assertEqual(standard["version"], "1.0.0")
        self.assertEqual(standard["ratifying_adr"], "ADR-0022")
        self.assertRegex(standard["content_sha256"], "^[a-f0-9]{64}$")
        self.assertEqual(
            standard["overall_level_rule"],
            "minimum-mandatory-dimension",
        )
        self.assertEqual(len(standard["dimensions"]), 8)
        self.assertEqual(set(standard["benchmarks"]), {"L2", "L3"})
        self.assertEqual(
            maturity["current_assessment"]["level"],
            "L1",
        )

        graph = data["protocol-graph"]
        nodes = {node["id"]: node for node in graph["nodes"]}
        edges = {edge["id"] for edge in graph["edges"]}
        self.assertIn(
            "maturity-standard:elder-factory-maturity-standard",
            nodes,
        )
        self.assertEqual(
            nodes[
                "maturity-standard:elder-factory-maturity-standard"
            ]["attributes"]["content_sha256"],
            standard["content_sha256"],
        )
        for level in ("L2", "L3"):
            self.assertIn(f"maturity-benchmark:{level}", nodes)
            self.assertEqual(
                nodes[f"maturity-level:{level}"]["attributes"][
                    "institutional_benchmark"
                ],
                standard["benchmarks"][level],
            )
            self.assertIn(
                f"benchmarks:maturity-benchmark:{level}->"
                f"maturity-level:{level}",
                edges,
            )
        for dimension in standard["dimensions"]:
            self.assertIn(
                f"maturity-dimension:{dimension['id']}",
                nodes,
            )

    def test_constitution_and_accepted_adr_preserve_authority_boundary(
        self,
    ) -> None:
        constitution = " ".join(
            (ROOT / "ELDER_PROTOCOL.md").read_text(
                encoding="utf-8"
            ).split()
        )
        for phrase in (
            "Hosted supervised delivery",
            "humans retain merge, release, deployment",
            "Bounded production operation",
            "humans retain class definition, scope expansion, full rollout",
            "minimum verified level across every mandatory dimension",
        ):
            self.assertIn(phrase, constitution)

        data = validate_protocol()
        documents = {
            item["id"]: item
            for item in data["design-registry"]["documents"]
        }
        self.assertEqual(documents["ADR-0022"]["status"], "accepted")
        self.assertEqual(
            documents["ADR-0022"]["path"],
            "docs/adr/0022-institutional-factory-maturity-standard.md",
        )


if __name__ == "__main__":
    unittest.main()
