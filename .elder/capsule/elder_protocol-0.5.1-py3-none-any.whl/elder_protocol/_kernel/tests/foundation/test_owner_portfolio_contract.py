from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.owner_portfolio import (
    finalize_owner_portfolio_record,
    validate_owner_portfolio_snapshot,
)


SHA = "a" * 64
AT = "2026-08-14T06:00:00+00:00"


def snapshot() -> dict:
    stage_counts = {
        status: int(status == "running")
        for status in (
            "draft",
            "ready",
            "queued",
            "running",
            "waiting",
            "validation",
            "blocked",
            "completed",
            "failed",
            "cancelled",
        )
    }
    counts = {
        "project_id": "product-one",
        "work_item_count": 1,
        "stage_counts": stage_counts,
        "priority_counts": {
            "low": 0,
            "normal": 0,
            "high": 1,
            "urgent": 0,
        },
        "dependency_blocked_count": 0,
    }
    return finalize_owner_portfolio_record(
        {
            "version": "1.0.0",
            "observed_at": AT,
            "project_ids": ["product-one"],
            "filters": {
                "project_id": None,
                "status": None,
                "priority": None,
                "dependency_state": None,
                "search": None,
            },
            "products": [
                {
                    "factory_id": "product-factory-product-one",
                    "project_id": "product-one",
                    "status": "active",
                    "updated_at": AT,
                    "record_version": 1,
                    **{
                        key: copy.deepcopy(value)
                        for key, value in counts.items()
                        if key != "project_id"
                    },
                    "content_sha256": SHA,
                }
            ],
            "all_project_counts": [counts],
            "total_work_item_count": 1,
            "filtered_work_item_count": 1,
            "returned_work_item_count": 1,
            "work_items": [
                {
                    "work_item_id": "work-item-one",
                    "project_id": "product-one",
                    "objective": "Deliver the bounded owner portfolio view.",
                    "status": "running",
                    "priority": "high",
                    "owner_identity_id": "identity:owner",
                    "updated_at": AT,
                    "record_version": 1,
                    "dependency_state": "clear",
                    "blocking_dependency_count": 0,
                    "dependencies": [],
                    "content_sha256": SHA,
                }
            ],
            "continuation": None,
            "freshness": {
                "status": "current",
                "lag_entries": 0,
                "projection_sha256": SHA,
                "projections": [
                    {
                        "projection_id": "products",
                        "generation": 1,
                        "row_count": 1,
                        "projection_sha256": SHA,
                    },
                    {
                        "projection_id": "work-items",
                        "generation": 1,
                        "row_count": 1,
                        "projection_sha256": SHA,
                    },
                ],
                "journal": {
                    "generation": 1,
                    "sequence": 1,
                    "entry_id": "journal-entry-one",
                    "entry_sha256": SHA,
                },
            },
        }
    )


class OwnerPortfolioContractTests(unittest.TestCase):
    def test_valid_snapshot(self) -> None:
        self.assertEqual(
            validate_owner_portfolio_snapshot(snapshot())["products"][0][
                "project_id"
            ],
            "product-one",
        )

    def test_digest_shape_and_secret_fail_closed(self) -> None:
        bad_digest = snapshot()
        bad_digest["observed_at"] = "2026-08-14T06:01:00+00:00"
        with self.assertRaisesRegex(ProtocolError, "digest"):
            validate_owner_portfolio_snapshot(bad_digest)

        extra = snapshot()
        extra["unexpected"] = True
        extra = finalize_owner_portfolio_record(extra)
        with self.assertRaises(ProtocolError):
            validate_owner_portfolio_snapshot(extra)

        secret = snapshot()
        secret["work_items"][0]["api_key"] = "sk-secret-value"
        secret = finalize_owner_portfolio_record(secret)
        with self.assertRaisesRegex(ProtocolError, "secret"):
            validate_owner_portfolio_snapshot(secret)

    def test_project_counts_and_order_fail_closed(self) -> None:
        wrong_count = snapshot()
        wrong_count["products"][0]["work_item_count"] = 2
        wrong_count = finalize_owner_portfolio_record(wrong_count)
        with self.assertRaisesRegex(ProtocolError, "counts disagree"):
            validate_owner_portfolio_snapshot(wrong_count)

        duplicate_counts = snapshot()
        duplicate_counts["all_project_counts"].append(
            copy.deepcopy(duplicate_counts["all_project_counts"][0])
        )
        duplicate_counts = finalize_owner_portfolio_record(duplicate_counts)
        with self.assertRaisesRegex(ProtocolError, "counts are not unique"):
            validate_owner_portfolio_snapshot(duplicate_counts)

        wrong_order = snapshot()
        second = copy.deepcopy(wrong_order["work_items"][0])
        second["work_item_id"] = "work-item-two"
        second["status"] = "blocked"
        second["dependency_state"] = "blocked"
        wrong_order["work_items"].insert(0, second)
        wrong_order["returned_work_item_count"] = 2
        wrong_order["filtered_work_item_count"] = 2
        wrong_order["total_work_item_count"] = 2
        wrong_order = finalize_owner_portfolio_record(wrong_order)
        with self.assertRaisesRegex(ProtocolError, "not sorted"):
            validate_owner_portfolio_snapshot(wrong_order)


if __name__ == "__main__":
    unittest.main()
