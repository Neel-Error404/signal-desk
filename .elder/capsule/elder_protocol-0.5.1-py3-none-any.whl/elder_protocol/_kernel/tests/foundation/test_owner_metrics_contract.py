from __future__ import annotations

import json
import unittest

from elder_protocol.constants import ROOT
from elder_protocol.factory_operations.owner_metrics import DEFINITIONS
from elder_protocol.io import load_json


OPERATIONS_ROOT = ROOT / "factory" / "operations"


class OwnerMetricsContractTests(unittest.TestCase):
    def test_route_definitions_and_closed_schema_are_registered(self) -> None:
        routes = load_json(
            OPERATIONS_ROOT / "operations-api-route-registry.json"
        )["routes"]
        bindings = load_json(
            OPERATIONS_ROOT / "operations-api-binding-registry.json"
        )["bindings"]
        route = next(item for item in routes if item["id"] == "owner-metrics-get")
        binding = next(
            item for item in bindings if item["route_id"] == "owner-metrics-get"
        )

        self.assertEqual(route["method"], "GET")
        self.assertEqual(route["path"], "/v1/projects/{project_id}/metrics")
        self.assertEqual(route["service"], "OwnerMetrics.snapshot")
        self.assertEqual(route["roles"], ["human-owner", "product-owner"])
        self.assertEqual(
            binding["response_validator"],
            "owner-metrics-snapshot",
        )
        self.assertEqual(
            [item["id"] for item in DEFINITIONS],
            [
                "cycle-time",
                "wait-time",
                "retry-count",
                "failure-count",
                "owner-intervention-count",
                "test-evidence-coverage",
                "cost",
                "learning-impact",
                "completion-ratio",
            ],
        )

        schema = load_json(
            OPERATIONS_ROOT / "owner-metrics-snapshot.schema.json"
        )
        self.assertFalse(schema["additionalProperties"])
        self.assertEqual(
            schema["properties"]["cost"]["$ref"],
            "#/$defs/unavailable",
        )
        serialized = json.dumps(schema, sort_keys=True)
        for forbidden in (
            "prompt_text",
            "output_text",
            "trace_id",
            "span_id",
            "secret",
        ):
            self.assertNotIn(forbidden, serialized)


if __name__ == "__main__":
    unittest.main()
