from __future__ import annotations

import copy
import unittest
from pathlib import Path

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    CONTINUATION_SCHEDULER_VERSION,
    DEFAULT_TICK_CLAIM_SECONDS,
    STOP_REASONS,
    DurableContinuationScheduler,
    validate_continuation_goal_record,
    validate_continuation_goal_request,
)
from elder_protocol.schema_validation import validate_schema_catalog


class ContinuationSchedulerFoundationTests(unittest.TestCase):
    @staticmethod
    def _request() -> dict:
        return {
            "version": "1.0.0",
            "goal_id": "continuation-goal-foundation",
            "schedule_id": "continuation-schedule-foundation",
            "idempotency_key": "foundation-goal-idempotency",
            "project_id": "project-one",
            "run_id": f"run-{'1' * 32}",
            "worker_session_id": f"worker-session-{'2' * 32}",
            "workspace_id": f"workspace-{'3' * 32}",
            "workspace_binding_sha256": "4" * 64,
            "session_generation": 1,
            "requested_by_identity_id": "founder",
            "objective": "Complete the bounded local continuation objective.",
            "created_at": "2026-08-13T12:00:00+00:00",
            "deadline_at": "2026-08-13T13:00:00+00:00",
            "schedule": {
                "first_tick_at": "2026-08-13T12:05:00+00:00",
                "interval_seconds": 60,
                "misfire_grace_seconds": 10,
            },
            "budget": {
                "token_limit": 1000,
                "elapsed_seconds_limit": 1200,
                "continuation_limit": 3,
            },
        }

    def test_schemas_exports_and_docs_are_present(self) -> None:
        schemas = validate_schema_catalog(Path("factory/operations"))
        for name in (
            "continuation-goal-request.schema.json",
            "continuation-goal-record.schema.json",
            "continuation-schedule-record.schema.json",
            "continuation-tick-record.schema.json",
            "continuation-heartbeat-record.schema.json",
        ):
            self.assertIn(name, schemas)
        self.assertEqual(CONTINUATION_SCHEDULER_VERSION, "1.0.0")
        self.assertEqual(DEFAULT_TICK_CLAIM_SECONDS, 30)
        self.assertEqual(
            DurableContinuationScheduler.__name__,
            "DurableContinuationScheduler",
        )
        self.assertIn("uncertain-tick", STOP_REASONS)
        for path in (
            "docs/software-factory/SF-205-task-packet.md",
            "docs/software-factory/SF-205-design.md",
        ):
            self.assertTrue(Path(path).is_file(), path)

    def test_goal_request_is_closed_bounded_and_digest_safe(self) -> None:
        request = self._request()
        self.assertEqual(validate_continuation_goal_request(request), request)

        invalid_tick = copy.deepcopy(request)
        invalid_tick["schedule"]["first_tick_at"] = request["deadline_at"]
        with self.assertRaisesRegex(ProtocolError, "within the goal lifetime"):
            validate_continuation_goal_request(invalid_tick)

        unknown = copy.deepcopy(request)
        unknown["provider_schedule_id"] = "provider-owned"
        with self.assertRaises(ProtocolError):
            validate_continuation_goal_request(unknown)

        secret = copy.deepcopy(request)
        secret["objective"] = "Use api_key=sk-example-secret-value to continue."
        with self.assertRaises(ProtocolError):
            validate_continuation_goal_request(secret)

        self.assertEqual(
            canonical_sha256(request),
            canonical_sha256(copy.deepcopy(request)),
        )

    def test_goal_authority_snapshot_is_closed_typed_and_bound(self) -> None:
        request = self._request()
        authority = {
            "project_id": request["project_id"],
            "run_id": request["run_id"],
            "worker_session_id": request["worker_session_id"],
            "workspace_id": request["workspace_id"],
            "session_generation": request["session_generation"],
            "authority_ref": "authority:foundation",
            "delegation_id": "delegation-foundation",
            "delegation_sha256": "5" * 64,
            "delegation_status": "active",
            "child_run_id": "child-run-foundation",
            "child_run_contract_sha256": "6" * 64,
            "child_run_status": "running",
            "child_run_cancellation_status": "active",
            "runtime_lease_id": "runtime-lease-foundation",
            "runtime_lease_sha256": "7" * 64,
            "runtime_lease_status": "active",
            "runtime_lease_released_at": None,
            "authority_expires_at": "2026-08-13T12:45:00+00:00",
            "budget": {
                "token_limit": 2000,
                "cost_limit_usd": 10.0,
                "tool_call_limit": 10,
                "elapsed_seconds_limit": 1800,
            },
            "observed_at": request["created_at"],
        }
        body = {
            "version": "1.0.0",
            "goal_id": request["goal_id"],
            "request": request,
            "authority": authority,
            "status": "active",
            "stop_reason": None,
            "record_version": 1,
            "tokens_used": 0,
            "elapsed_seconds_used": 0,
            "continuations_used": 0,
            "created_at": request["created_at"],
            "updated_at": request["created_at"],
            "completed_at": None,
        }
        record = {**body, "content_sha256": canonical_sha256(body)}
        self.assertEqual(validate_continuation_goal_record(record), record)

        invalid_budget = copy.deepcopy(record)
        invalid_budget["authority"]["budget"]["token_limit"] = "unbounded"
        invalid_budget["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in invalid_budget.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaises(ProtocolError):
            validate_continuation_goal_record(invalid_budget)

        changed_binding = copy.deepcopy(record)
        changed_binding["authority"]["project_id"] = "another-project"
        changed_binding["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in changed_binding.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "does not match"):
            validate_continuation_goal_record(changed_binding)


if __name__ == "__main__":
    unittest.main()
