from __future__ import annotations

import copy
import inspect
import re
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_contracts import (
    validate_factory_cursor_data,
    validate_factory_event_data,
)
from elder_protocol.factory_domain import (
    factory_entity_content_sha256,
    validate_factory_entity_data,
)
from elder_protocol.factory_operations import (
    AuditReplay,
    DurableDispatcher,
    OwnerDecisions,
    OwnerInbox,
    OwnerMetrics,
    OwnerPortfolio,
    ProductFactoryRegistry,
    ProjectionQueries,
    RunController,
    SignalIntake,
    WorkItemLedger,
    WorkItemTransitionEngine,
    WorkRoom,
    factory_capability_status,
    journal_entry_sha256,
    validate_dispatch_record,
    validate_journal_entry_data,
    validate_owner_portfolio_snapshot,
    validate_owner_metrics_snapshot,
    validate_owner_decision,
    validate_owner_decision_mutation_result,
    validate_owner_decision_page,
    validate_owner_decision_state,
    validate_work_room_input_result,
    validate_work_room_snapshot,
    validate_audit_replay_snapshot,
)
from elder_protocol.io import load_json
from elder_protocol.schema_validation import validate_against_schema
from elder_protocol.factory_operations._common import reject_secret_material
from elder_protocol.factory_operations.api_contracts import (
    canonical_content_sha256,
)
from elder_protocol.factory_operations.api_server import (
    OperationsApiRequestHandler,
)
from elder_protocol.factory_operations.api_service import OperationsApiService


OPERATIONS_ROOT = ROOT / "factory" / "operations"
ROUTE_REGISTRY_PATH = OPERATIONS_ROOT / "operations-api-route-registry.json"
BINDING_REGISTRY_PATH = (
    OPERATIONS_ROOT / "operations-api-binding-registry.json"
)
DESIGN_PATH = ROOT / "docs" / "software-factory" / "SF-107-design.md"
SHA256 = "a" * 64
TIMESTAMP = "2026-08-11T12:00:00Z"
NOW = datetime(2026, 8, 11, 12, 0, tzinfo=timezone.utc)
EXPECTED_BINDING_REGISTRY_SHA256 = (
    "0ad5d7a8a930064d1beb3e7401c062b83b0a6f46dca217b77bbe14d900e17cad"
)
EXPECTED_ROUTE_REGISTRY_SHA256 = (
    "a3f9af4e7d453074608ed1547d6ce9b21d0312473bae81839edfd18875768d4c"
)

SERVICE_TYPES = {
    "AuditReplay": AuditReplay,
    "DurableDispatcher": DurableDispatcher,
    "OwnerInbox": OwnerInbox,
    "OwnerMetrics": OwnerMetrics,
    "OwnerPortfolio": OwnerPortfolio,
    "OwnerDecisions": OwnerDecisions,
    "ProductFactoryRegistry": ProductFactoryRegistry,
    "ProjectionQueries": ProjectionQueries,
    "RunController": RunController,
    "SignalIntake": SignalIntake,
    "WorkItemLedger": WorkItemLedger,
    "WorkItemTransitionEngine": WorkItemTransitionEngine,
    "WorkRoom": WorkRoom,
}

FORBIDDEN_SERVICE_METHODS = {
    "activate_projection",
    "begin_execution",
    "claim_next",
    "claim_reconciliation",
    "cleanup_superseded",
    "confirm_work_item_start",
    "create_backup",
    "dead_letters",
    "mark_uncertain",
    "prepare_work_item_start",
    "rebuild_all",
    "rebuild_current",
    "rebuild_projection",
    "record_elder_observation",
    "record_response",
    "renew",
    "reset_projection",
    "restore",
    "shutdown_owner",
}

EXPECTED_ERROR_CODES = {
    "conflict",
    "forbidden",
    "internal-error",
    "invalid-request",
    "not-found",
    "provider-unavailable",
    "stale-cursor",
    "timeout",
    "unauthorized",
    "uncertain-mutation",
    "unsupported-version",
}

EXPECTED_PROJECTIONS = (
    "products",
    "signals",
    "work-items",
    "transitions",
    "commands",
    "runs",
    "timeline",
)

EXPECTED_ROUTE_MATRIX_TEXT = """
health-live|GET|/health/live|liveness|none|false|false|OperationsApiHealth.live|liveness
health-ready|GET|/health/ready|readiness|none|false|false|OperationsApiHealth.ready|readiness
health-detail|GET|/v1/health|query|bearer-policy|false|false|OperationsApiHealth.detail|health-detail
readiness-detail|GET|/v1/readiness|query|bearer-policy|false|false|OperationsApiHealth.readiness|readiness
capabilities-get|GET|/v1/capabilities|query|bearer-policy|false|false|ProjectionQueries.get_capability_status|capability-status
projections-list|GET|/v1/projections|query|bearer-policy|false|false|ProjectionQueries.get_projection_status|projection-status
projection-get|GET|/v1/projections/{projection_id}|query|bearer-policy|false|false|ProjectionQueries.get_projection_status|projection-status
journal-get|GET|/v1/journal|query|bearer-policy|false|false|ProjectionQueries.get_journal_status|journal-status
owner-inbox-get|GET|/v1/owner-inbox|query|bearer-policy|false|true|OwnerInbox.snapshot|owner-inbox-snapshot
owner-portfolio-get|GET|/v1/owner-portfolio|query|bearer-policy|false|true|OwnerPortfolio.snapshot|owner-portfolio-snapshot
work-room-get|GET|/v1/projects/{project_id}/work-items/{work_item_id}/work-room|query|bearer-policy|true|true|WorkRoom.snapshot|work-room-snapshot
audit-replay-get|GET|/v1/projects/{project_id}/work-items/{work_item_id}/audit-replay|query|bearer-policy|true|true|AuditReplay.snapshot|audit-replay-snapshot
owner-metrics-get|GET|/v1/projects/{project_id}/metrics|query|bearer-policy|true|true|OwnerMetrics.snapshot|owner-metrics-snapshot
work-room-input-create|POST|/v1/projects/{project_id}/work-items/{work_item_id}/work-room/inputs|mutation|bearer-policy|true|true|WorkRoom.submit_input|work-room-input-result
products-list|GET|/v1/projects/{project_id}/products|query|bearer-policy|true|true|ProjectionQueries.list_products|projection-page
product-get|GET|/v1/projects/{project_id}/products/{factory_id}|query|bearer-policy|true|true|ProjectionQueries.get_product|projection-record
signals-list|GET|/v1/projects/{project_id}/signals|query|bearer-policy|true|true|ProjectionQueries.list_signals|projection-page
signal-get|GET|/v1/projects/{project_id}/signals/{signal_id}|query|bearer-policy|true|true|ProjectionQueries.get_signal|projection-record
signal-history|GET|/v1/projects/{project_id}/signals/{signal_id}/history|query|bearer-policy|true|true|ProjectionQueries.signal_history|projection-page
work-items-list|GET|/v1/projects/{project_id}/work-items|query|bearer-policy|true|true|ProjectionQueries.list_work_items|projection-page
work-item-get|GET|/v1/projects/{project_id}/work-items/{work_item_id}|query|bearer-policy|true|true|ProjectionQueries.get_work_item|projection-record
work-item-history|GET|/v1/projects/{project_id}/work-items/{work_item_id}/history|query|bearer-policy|true|true|ProjectionQueries.work_item_history|projection-page
transitions-list|GET|/v1/projects/{project_id}/transitions|query|bearer-policy|true|true|ProjectionQueries.list_transitions|projection-page
transition-get|GET|/v1/projects/{project_id}/transitions/{transition_id}|query|bearer-policy|true|true|ProjectionQueries.get_transition|projection-record
commands-list|GET|/v1/projects/{project_id}/commands|query|bearer-policy|true|true|ProjectionQueries.list_commands|projection-page
command-get|GET|/v1/projects/{project_id}/commands/{command_id}|query|bearer-policy|true|true|ProjectionQueries.get_command|projection-record
command-history|GET|/v1/projects/{project_id}/commands/{command_id}/history|query|bearer-policy|true|true|ProjectionQueries.command_history|projection-page
runs-list|GET|/v1/projects/{project_id}/runs|query|bearer-policy|true|true|ProjectionQueries.list_runs|projection-page
run-get|GET|/v1/projects/{project_id}/runs/{run_id}|query|bearer-policy|true|true|ProjectionQueries.get_run|projection-record
run-history|GET|/v1/projects/{project_id}/runs/{run_id}/history|query|bearer-policy|true|true|ProjectionQueries.run_history|projection-page
timeline-list|GET|/v1/projects/{project_id}/timeline|query|bearer-policy|true|true|ProjectionQueries.timeline|projection-page
events-list|GET|/v1/projects/{project_id}/events|query|bearer-policy|true|true|ProjectionQueries.read_public_events|public-event-page
event-get|GET|/v1/projects/{project_id}/events/{event_id}|query|bearer-policy|true|true|ProjectionQueries.get_public_event|public-event
decision-requests-list|GET|/v1/projects/{project_id}/decision-requests|query|bearer-policy|true|true|OwnerDecisions.list_requests|owner-decision-page
decision-request-get|GET|/v1/projects/{project_id}/decision-requests/{decision_request_id}|query|bearer-policy|true|true|OwnerDecisions.state|owner-decision-state
decisions-list|GET|/v1/projects/{project_id}/decisions|query|bearer-policy|true|true|OwnerDecisions.list_decisions|owner-decision-page
decision-get|GET|/v1/projects/{project_id}/decisions/{decision_id}|query|bearer-policy|true|true|OwnerDecisions.get_decision|owner-decision
decision-request-create|POST|/v1/projects/{project_id}/decision-requests|mutation|bearer-policy|true|true|OwnerDecisions.create_request|owner-decision-mutation-result
decision-create|POST|/v1/projects/{project_id}/decision-requests/{decision_request_id}/decisions|mutation|bearer-policy|true|true|OwnerDecisions.decide|owner-decision-mutation-result
decision-request-cancel|POST|/v1/projects/{project_id}/decision-requests/{decision_request_id}/cancel|mutation|bearer-policy|true|true|OwnerDecisions.cancel_request|owner-decision-mutation-result
decision-request-expire|POST|/v1/projects/{project_id}/decision-requests/{decision_request_id}/expire|mutation|bearer-policy|true|true|OwnerDecisions.expire_request|owner-decision-mutation-result
product-register|POST|/v1/projects/{project_id}/products|mutation|bearer-policy|true|true|ProductFactoryRegistry.register|product-mutation-result
product-update|PUT|/v1/projects/{project_id}/products/{factory_id}|mutation|bearer-policy|true|true|ProductFactoryRegistry.update|product-mutation-result
product-activate|POST|/v1/projects/{project_id}/products/{factory_id}/activate|mutation|bearer-policy|true|true|ProductFactoryRegistry.activate|product-mutation-result
product-pause|POST|/v1/projects/{project_id}/products/{factory_id}/pause|mutation|bearer-policy|true|true|ProductFactoryRegistry.pause|product-mutation-result
product-archive|POST|/v1/projects/{project_id}/products/{factory_id}/archive|mutation|bearer-policy|true|true|ProductFactoryRegistry.archive|product-mutation-result
signal-ingest|POST|/v1/projects/{project_id}/signals|mutation|bearer-policy|true|true|SignalIntake.ingest|signal-mutation-result
work-item-create|POST|/v1/projects/{project_id}/work-items|mutation|bearer-policy|true|true|WorkItemLedger.create|work-item-mutation-result
work-item-create-from-signal|POST|/v1/projects/{project_id}/signals/{signal_id}/work-items|mutation|bearer-policy|true|true|WorkItemLedger.create_from_signal|work-item-mutation-result
work-item-update|PUT|/v1/projects/{project_id}/work-items/{work_item_id}|mutation|bearer-policy|true|true|WorkItemLedger.update|work-item-mutation-result
transition-apply|POST|/v1/projects/{project_id}/work-items/{work_item_id}/transitions|mutation|bearer-policy|true|true|WorkItemTransitionEngine.apply|transition-mutation-result
dispatch-submit|POST|/v1/projects/{project_id}/commands|mutation|bearer-policy|true|true|DurableDispatcher.submit|dispatch-mutation-result
dispatch-cancel|POST|/v1/projects/{project_id}/commands/{dispatch_id}/cancel|mutation|bearer-policy|true|true|DurableDispatcher.cancel|dispatch-mutation-result
run-bind-start|POST|/v1/projects/{project_id}/runs|mutation|bearer-policy|true|true|RunController.bind_start|run-mutation-result
run-lifecycle-apply|POST|/v1/projects/{project_id}/runs/{run_id}/transitions|mutation|bearer-policy|true|true|RunController.apply|run-mutation-result
run-checkpoint-reference|POST|/v1/projects/{project_id}/runs/{run_id}/checkpoints|mutation|bearer-policy|true|true|RunController.record_checkpoint_reference|run-mutation-result
run-artifact-reference|POST|/v1/projects/{project_id}/runs/{run_id}/artifacts|mutation|bearer-policy|true|true|RunController.record_artifact_reference|run-mutation-result
""".strip()

EXPECTED_ROUTE_MATRIX = {
    fields[0]: {
        "method": fields[1],
        "path": fields[2],
        "kind": fields[3],
        "authentication": fields[4],
        "project_scoped": fields[5] == "true",
        "readiness_required": fields[6] == "true",
        "service": fields[7],
        "response_validator": fields[8],
    }
    for line in EXPECTED_ROUTE_MATRIX_TEXT.splitlines()
    for fields in [line.split("|")]
}

EXPECTED_QUERY_PARAMETERS = {
    "owner-inbox-get": ["project_id"],
    "owner-portfolio-get": [
        "project_id",
        "status",
        "priority",
        "dependency_state",
        "search",
        "limit",
        "continuation",
    ],
    "products-list": ["status", "limit", "continuation"],
    "signals-list": ["status", "limit", "continuation"],
    "signal-history": ["limit", "continuation"],
    "work-items-list": ["status", "limit", "continuation"],
    "work-item-history": ["limit", "continuation"],
    "transitions-list": ["work_item_id", "limit", "continuation"],
    "commands-list": ["status", "limit", "continuation"],
    "command-history": ["limit", "continuation"],
    "runs-list": ["status", "limit", "continuation"],
    "run-history": ["limit", "continuation"],
    "timeline-list": [
        "subject_id",
        "correlation_id",
        "limit",
        "continuation",
    ],
    "events-list": ["cursor", "limit", "wait_seconds"],
    "decision-requests-list": ["status", "work_item_id", "limit"],
    "decisions-list": ["work_item_id", "limit"],
}

EXPECTED_RESPONSE_SCOPES = {
    "products-list": ("path.project_id", None, "products"),
    "product-get": ("path.project_id", "path.factory_id", "products"),
    "signals-list": ("path.project_id", None, "signals"),
    "signal-get": ("path.project_id", "path.signal_id", "signals"),
    "signal-history": ("path.project_id", "path.signal_id", "signals"),
    "work-items-list": ("path.project_id", None, "work-items"),
    "work-item-get": (
        "path.project_id",
        "path.work_item_id",
        "work-items",
    ),
    "work-item-history": (
        "path.project_id",
        "path.work_item_id",
        "work-items",
    ),
    "transitions-list": ("path.project_id", None, "transitions"),
    "transition-get": (
        "path.project_id",
        "path.transition_id",
        "transitions",
    ),
    "commands-list": ("path.project_id", None, "commands"),
    "command-get": ("path.project_id", "path.command_id", "commands"),
    "command-history": (
        "path.project_id",
        "path.command_id",
        "commands",
    ),
    "runs-list": ("path.project_id", None, "runs"),
    "run-get": ("path.project_id", "path.run_id", "runs"),
    "run-history": ("path.project_id", "path.run_id", "runs"),
    "timeline-list": (
        "path.project_id",
        None,
        "timeline",
    ),
    "events-list": ("path.project_id", None, "public-events"),
    "event-get": (
        "path.project_id",
        "path.event_id",
        "public-events",
    ),
}

EXPECTED_RESPONSE_EXTRACTIONS = [
    {
        "route_id": "run-bind-start",
        "transform": "omit-service-result-fields",
        "omitted_fields": ["command_result"],
        "record_contract": "run-binding-record.schema.json",
        "primary_source_registry": "run-initial-bindings",
        "primary_source_record_digest_source": (
            "record.initial_binding.content_sha256"
        ),
    }
]

FIXTURE_SUBJECT_BY_ROUTE = {
    "product-get": "product-factory-foundation",
    "signal-get": "signal-foundation",
    "signal-history": "signal-foundation",
    "work-item-get": "work-item-foundation",
    "work-item-history": "work-item-foundation",
    "transition-get": "transition-foundation",
    "command-get": "dispatch-foundation",
    "command-history": "dispatch-foundation",
    "run-get": "run-foundation",
    "run-history": "run-foundation",
    "event-get": "event-foundation",
}

PROJECTION_FIXTURE_SOURCE_BY_ID = {
    "products": "product-factory-revisions",
    "signals": "signal-revisions",
    "work-items": "work-item-history",
    "transitions": "stage-transitions",
    "commands": "dispatch-history",
    "runs": "run-history",
    "timeline": "product-factory-revisions",
}

EXPECTED_TERMINAL_ERROR = {
    "http_status": 501,
    "code": "not-found",
    "reason_code": "decision-source-unimplemented",
    "retry": "never",
    "mutation_state": "not-applicable",
}

RESPONSE_DATA_FIELDS = {
    "capability-status": {"version", "capabilities"},
    "projection-status": {
        "version",
        "projection",
        "journal",
        "verified_at",
    },
    "journal-status": {
        "version",
        "status",
        "journal",
        "integrity",
        "verified_at",
    },
    "owner-inbox-snapshot": {
        "version",
        "project_filter",
        "observed_at",
        "complete",
        "source_counts",
        "item_count",
        "items",
        "content_sha256",
    },
    "owner-portfolio-snapshot": {
        "version",
        "observed_at",
        "project_ids",
        "filters",
        "products",
        "all_project_counts",
        "total_work_item_count",
        "filtered_work_item_count",
        "returned_work_item_count",
        "work_items",
        "continuation",
        "freshness",
        "content_sha256",
    },
    "work-room-snapshot": {
        "version",
        "project_id",
        "work_item_id",
        "observed_at",
        "work_item",
        "plan",
        "runs",
        "selected_run_id",
        "activity",
        "checkpoints",
        "artifacts",
        "test_evidence",
        "diff_evidence",
        "decision_requests",
        "decisions",
        "decision_effects",
        "allowed_inputs",
        "source_sha256",
        "content_sha256",
    },
    "work-room-input-result": {
        "version",
        "input_kind",
        "record_contract",
        "record",
        "record_sha256",
        "source",
        "result_proof_sha256",
    },
    "audit-replay-snapshot": {
        "version",
        "project_id",
        "work_item_id",
        "selected_run_id",
        "observed_at",
        "entries",
        "entry_count",
        "limitation_counts",
        "replay",
        "source_sha256",
        "content_sha256",
    },
    "owner-metrics-snapshot": {
        "version",
        "project_id",
        "observed_at",
        "definitions",
        "delivery",
        "reliability",
        "control",
        "test_quality",
        "cost",
        "learning_impact",
        "outcomes",
        "missing_data",
        "reconciliation",
        "content_sha256",
    },
    "owner-decision-page": {
        "version",
        "project_id",
        "kind",
        "status_filter",
        "work_item_id_filter",
        "items",
        "count",
        "observed_at",
        "content_sha256",
    },
    "owner-decision-state": {
        "version",
        "request",
        "decision",
        "effect",
        "content_sha256",
    },
    "owner-decision": {
        "version",
        "decision_id",
        "decision_request_id",
        "project_id",
        "work_item_id",
        "run_id",
        "subject_sha256",
        "subject_version",
        "choice_id",
        "decision",
        "transition_trigger",
        "transition_evidence_refs",
        "reason",
        "evidence_refs",
        "decided_by_identity_id",
        "decided_as_role",
        "decided_at",
        "content_sha256",
    },
    "owner-decision-mutation-result": {
        "version",
        "operation",
        "state",
        "state_sha256",
        "result_proof_sha256",
    },
    "projection-page": {
        "version",
        "items",
        "continuation",
        "projection",
        "journal",
        "query",
    },
    "projection-record": set(),
    "public-event-page": {
        "version",
        "project_id",
        "stream_id",
        "items",
        "cursor",
    },
    "public-event": {
        "version",
        "event_id",
        "event_type",
        "record_kind",
        "authoritative",
        "source_event_id",
        "occurred_at",
        "recorded_at",
        "cursor",
        "correlations",
        "actor",
        "source",
        "correlation_id",
        "causation_id",
        "idempotency_key",
        "payload_mode",
        "redaction",
        "payload_sha256",
        "payload",
        "extensions",
    },
    "product-mutation-result": {
        "version",
        "record_contract",
        "record",
        "record_sha256",
        "source",
        "journal",
        "result_proof_sha256",
    },
    "signal-mutation-result": {
        "version",
        "record_contract",
        "record",
        "record_sha256",
        "source",
        "journal",
        "result_proof_sha256",
    },
    "work-item-mutation-result": {
        "version",
        "record_contract",
        "record",
        "record_sha256",
        "source",
        "journal",
        "result_proof_sha256",
    },
    "transition-mutation-result": {
        "version",
        "record_contract",
        "record",
        "record_sha256",
        "source",
        "journal",
        "result_proof_sha256",
    },
    "dispatch-mutation-result": {
        "version",
        "record_contract",
        "record",
        "record_sha256",
        "source",
        "journal",
        "result_proof_sha256",
    },
    "run-mutation-result": {
        "version",
        "record_contract",
        "record",
        "record_sha256",
        "source",
        "journal",
        "result_proof_sha256",
    },
}

PROJECTION_AGGREGATE_BASE_FIELDS = {
    "version",
    "projection_id",
    "project_id",
    "subject_id",
    "history",
    "latest_by_source",
    "parent_ids",
    "source_subject_version",
    "last_journal_sequence",
    "updated_at",
    "content_sha256",
}
PROJECTION_AGGREGATE_ROUTE_FIELDS = {
    "product-get": {"status"},
    "signal-get": {"status", "received_at"},
    "work-item-get": {"status", "priority"},
    "transition-get": {"status", "recorded_at", "command_id"},
    "command-get": {"status"},
    "run-get": {"status"},
}
PROJECTION_AGGREGATE_FIELDS_BY_ID = {
    "products": {"status"},
    "signals": {"status", "received_at"},
    "work-items": {"status", "priority"},
    "transitions": {"status", "recorded_at", "command_id"},
    "commands": {"status"},
    "runs": {"status"},
}
PROJECTION_HISTORY_ROUTES = {
    "signal-history",
    "work-item-history",
    "command-history",
    "run-history",
}
PROJECTION_HISTORY_ITEM_FIELDS = {
    "journal_sequence",
    "entry_id",
    "source_registry_id",
    "source_subject_id",
    "source_subject_version",
    "operation",
    "occurred_at",
    "record",
}
TIMELINE_ROW_FIELDS = {
    "version",
    "projection_id",
    "project_id",
    "subject_id",
    "journal_sequence",
    "entry_id",
    "entry_sha256",
    "fact_type",
    "operation",
    "source_registry_id",
    "source_subject_id",
    "source_subject_version",
    "correlation_id",
    "causation_id",
    "occurred_at",
    "recorded_at",
    "parent_ids",
    "record",
    "updated_at",
    "content_sha256",
}

DIRECT_RESPONSE_VALIDATORS = {
    "health-detail",
    "liveness",
    "readiness",
}

MUTATION_RECORD_SCHEMA_BY_ROUTE = {
    "product-register": "product-factory-registry-record.schema.json",
    "product-update": "product-factory-registry-record.schema.json",
    "product-activate": "product-factory-registry-record.schema.json",
    "product-pause": "product-factory-registry-record.schema.json",
    "product-archive": "product-factory-registry-record.schema.json",
    "signal-ingest": "signal-intake-record.schema.json",
    "work-item-create": "work-item-ledger-record.schema.json",
    "work-item-create-from-signal": "work-item-ledger-record.schema.json",
    "work-item-update": "work-item-ledger-record.schema.json",
    "transition-apply": "work-item-transition-record.schema.json",
    "dispatch-submit": "durable-dispatch-record.schema.json",
    "dispatch-cancel": "durable-dispatch-record.schema.json",
    "run-bind-start": "run-binding-record.schema.json",
    "run-lifecycle-apply": "run-lifecycle-command-result.schema.json",
    "run-checkpoint-reference": "run-lifecycle-command-result.schema.json",
    "run-artifact-reference": "run-lifecycle-command-result.schema.json",
}

MUTATION_PRIMARY_SOURCE_BY_ROUTE = {
    "product-register": "product-factory-revisions",
    "product-update": "product-factory-revisions",
    "product-activate": "product-factory-revisions",
    "product-pause": "product-factory-revisions",
    "product-archive": "product-factory-revisions",
    "signal-ingest": "signal-revisions",
    "work-item-create": "work-item-history",
    "work-item-create-from-signal": "work-item-history",
    "work-item-update": "work-item-history",
    "transition-apply": "stage-transitions",
    "dispatch-submit": "dispatch-history",
    "dispatch-cancel": "dispatch-history",
    "run-bind-start": "run-initial-bindings",
    "run-lifecycle-apply": "run-lifecycle-results",
    "run-checkpoint-reference": "run-lifecycle-results",
    "run-artifact-reference": "run-lifecycle-results",
}

MUTATION_FIXTURE_BRANCH_BY_ROUTE = {
    "product-register": "product.register",
    "product-update": "product.update",
    "product-activate": "product.activate",
    "product-pause": "product.pause",
    "product-archive": "product.archive",
    "signal-ingest": "signal.ingest.accept",
    "work-item-create": "work-item.create",
    "work-item-create-from-signal": "work-item.create-from-signal",
    "work-item-update": "work-item.update",
    "transition-apply": "transition.apply.recorded-nonterminal",
    "dispatch-submit": "dispatch.submit",
    "dispatch-cancel": "dispatch.cancel",
    "run-bind-start": "run.bind-start",
    "run-lifecycle-apply": "run.lifecycle-apply",
    "run-checkpoint-reference": "run.checkpoint-reference",
    "run-artifact-reference": "run.artifact-reference",
}

MUTATION_BRANCH_PREFIX_BY_ROUTE = {
    route_id: branch_id
    for route_id, branch_id in MUTATION_FIXTURE_BRANCH_BY_ROUTE.items()
}
MUTATION_BRANCH_PREFIX_BY_ROUTE["signal-ingest"] = "signal.ingest."
MUTATION_BRANCH_PREFIX_BY_ROUTE["transition-apply"] = "transition.apply."

RECONCILIATION_IDENTITY_FIELDS_BY_ROUTE = {
    "product-register": (
        "project_id",
        "configuration_sha256",
        "actor_identity_id",
    ),
    "product-update": (
        "factory_id",
        "expected_version",
        "configuration_sha256",
        "actor_identity_id",
        "reason_sha256",
    ),
    "product-activate": (
        "factory_id",
        "expected_version",
        "actor_identity_id",
    ),
    "product-pause": (
        "factory_id",
        "expected_version",
        "actor_identity_id",
        "reason_sha256",
    ),
    "product-archive": (
        "factory_id",
        "expected_version",
        "actor_identity_id",
        "decision_sha256",
    ),
    "signal-ingest": (
        "signal_id",
        "integration_id",
        "idempotency_key",
        "request_sha256",
    ),
    "work-item-create": (
        "work_item_id",
        "specification_sha256",
        "actor_identity_id",
        "change_reason_sha256",
    ),
    "work-item-create-from-signal": (
        "signal_id",
        "work_item_id",
        "specification_sha256",
        "actor_identity_id",
    ),
    "work-item-update": (
        "work_item_id",
        "expected_version",
        "specification_sha256",
        "actor_identity_id",
    ),
    "transition-apply": ("command_id", "command_sha256"),
    "dispatch-submit": (
        "dispatch_id",
        "command_id",
        "submission_sha256",
    ),
    "dispatch-cancel": (
        "dispatch_id",
        "requested_by_identity_id",
        "reason_sha256",
        "record_version",
    ),
    "run-bind-start": (
        "dispatch_id",
        "submission_sha256",
        "binding_seed_sha256",
    ),
    "run-lifecycle-apply": ("command_id", "command_sha256"),
    "run-checkpoint-reference": (
        "command_id",
        "reference_id",
        "checkpoint_sha256",
    ),
    "run-artifact-reference": (
        "command_id",
        "reference_id",
        "content_sha256",
    ),
}


def _content_sha256(document: dict) -> str:
    unsigned = {
        key: value
        for key, value in document.items()
        if key != "content_sha256"
    }
    return canonical_sha256(unsigned)


def _parse_time(value: str, label: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProtocolError(f"{label} must be a valid date-time.") from exc
    if parsed.tzinfo is None:
        raise ProtocolError(f"{label} must include a timezone.")
    return parsed


def _schema_path(schema_ref: str) -> Path:
    if schema_ref.startswith("factory/"):
        return ROOT / schema_ref
    if schema_ref.startswith("protocol/"):
        return ROOT / schema_ref
    return OPERATIONS_ROOT / schema_ref


def _resolve_schema_ref(
    document: dict,
    schema_path: Path,
    reference: str,
) -> tuple[dict, dict, Path]:
    if reference.startswith("#/"):
        target = document
        for segment in reference[2:].split("/"):
            target = target[segment.replace("~1", "/").replace("~0", "~")]
        return document, target, schema_path
    external, separator, fragment = reference.partition("#")
    target_path = (schema_path.parent / external).resolve()
    target_document = load_json(target_path)
    target = target_document
    if separator and fragment:
        for segment in fragment.removeprefix("/").split("/"):
            target = target[segment.replace("~1", "/").replace("~0", "~")]
    return target_document, target, target_path


def _schema_has_path(schema_ref: str, fields: list[str]) -> bool:
    schema_path = _schema_path(schema_ref)
    document = load_json(schema_path)
    node = document
    current_path = schema_path
    for field in fields:
        while "$ref" in node:
            document, node, current_path = _resolve_schema_ref(
                document,
                current_path,
                node["$ref"],
            )
        properties = node.get("properties")
        if not isinstance(properties, dict) or field not in properties:
            return False
        node = properties[field]
    return True


def _payload_schema_has_path(operation: str, fields: list[str]) -> bool:
    schema_path = OPERATIONS_ROOT / (
        "operations-api-mutation-payload.schema.json"
    )
    document = load_json(schema_path)
    node = document["$defs"][operation.replace("-", "_")]
    for field in fields:
        while "$ref" in node:
            document, node, schema_path = _resolve_schema_ref(
                document,
                schema_path,
                node["$ref"],
            )
        properties = node.get("properties")
        if not isinstance(properties, dict) or field not in properties:
            return False
        node = properties[field]
    return True


def _binding_source_exists(binding: dict, source: str) -> bool:
    root, _, remainder = source.partition(".")
    fields = remainder.split(".") if remainder else []
    if root == "path":
        return len(fields) == 1 and fields[0] in binding["path_parameters"]
    if root == "query":
        return len(fields) == 1 and fields[0] in binding["query_parameters"]
    if root == "auth":
        return fields in (["identity_id"], ["project_ids"])
    if root == "server":
        return fields in (["runtime_fence"], ["observed_at"])
    if root == "header":
        return fields == ["idempotency_key"]
    if root != "body" or not fields:
        return False

    member_contracts = sorted(
        binding["member_contracts"],
        key=lambda item: len(item["source"]),
        reverse=True,
    )
    for contract in member_contracts:
        contract_prefix = contract["source"]
        if source == contract_prefix:
            if not _schema_path(contract["schema"]).is_file():
                return False
            parent_contracts = [
                item
                for item in member_contracts
                if contract_prefix.startswith(item["source"] + ".")
            ]
            if parent_contracts:
                parent = max(
                    parent_contracts,
                    key=lambda item: len(item["source"]),
                )
                residual = contract_prefix[
                    len(parent["source"]) + 1 :
                ].split(".")
                return _schema_has_path(parent["schema"], residual)
            contract_fields = contract_prefix.split(".")[1:]
            if contract_fields[0] != "payload":
                return _schema_has_path(
                    "operations-api-mutation-request.schema.json",
                    contract_fields,
                )
            return _payload_schema_has_path(
                binding["payload_operation"],
                contract_fields[1:],
            )
        if source.startswith(contract_prefix + "."):
            residual = source[len(contract_prefix) + 1 :].split(".")
            return _schema_has_path(contract["schema"], residual)

    if fields[0] == "payload":
        if binding["payload_operation"] is None:
            return False
        return _payload_schema_has_path(
            binding["payload_operation"],
            fields[1:],
        )
    return _schema_has_path(
        "operations-api-mutation-request.schema.json",
        fields,
    )


def _redigest_registries(
    registry: dict,
    binding_registry: dict,
) -> tuple[dict, dict]:
    binding_registry["content_sha256"] = _content_sha256(binding_registry)
    registry["binding_registry_sha256"] = binding_registry[
        "content_sha256"
    ]
    registry["content_sha256"] = _content_sha256(registry)
    return registry, binding_registry


def _route_registry() -> dict:
    return load_json(ROUTE_REGISTRY_PATH)


def _binding_registry() -> dict:
    return load_json(BINDING_REGISTRY_PATH)


def _journal_sources() -> dict[str, dict]:
    registry = load_json(
        OPERATIONS_ROOT / "journal-source-registry.json"
    )
    return {source["id"]: source for source in registry["sources"]}


def _journal_coverage() -> dict[str, dict]:
    registry = load_json(
        OPERATIONS_ROOT / "journal-mutation-coverage.json"
    )
    return {branch["branch_id"]: branch for branch in registry["branches"]}


def _validate_coverage_source_ids(
    branch: dict,
    actual_ids: list[str],
) -> None:
    minimum = branch["source_cardinality"]["minimum"]
    maximum = branch["source_cardinality"]["maximum"]
    if not minimum <= len(actual_ids) <= maximum:
        raise ProtocolError(
            "Mutation journal source count is outside canonical coverage."
        )
    expected_ids = list(branch["source_ids"])
    if any(source_id not in expected_ids for source_id in actual_ids):
        raise ProtocolError(
            "Mutation journal contains an unregistered source family."
        )
    sources = _journal_sources()
    ordered_ids = sorted(
        actual_ids,
        key=lambda source_id: (
            sources[source_id]["append_order"],
            source_id,
        ),
    )
    if actual_ids != ordered_ids:
        raise ProtocolError(
            "Mutation journal sources are outside registered append order."
        )
    if (
        minimum == maximum == len(expected_ids)
        and actual_ids != expected_ids
    ):
        raise ProtocolError(
            "Mutation journal changed the exact registered source sequence."
        )
    actual_counts = {
        source_id: actual_ids.count(source_id)
        for source_id in set(actual_ids) | set(expected_ids)
    }
    for site in branch["write_sites"]:
        if site["current_table"]:
            continue
        bounds = site["source_cardinality"]
        for source_id in site["immutable_source_ids"]:
            count = actual_counts.get(source_id, 0)
            if not bounds["minimum"] <= count <= bounds["maximum"]:
                raise ProtocolError(
                    "Mutation journal source family violates write-site "
                    "cardinality."
                )


def _coverage_boundary_source_ids(
    branch: dict,
    *,
    use_maximum: bool,
) -> list[str]:
    expected_ids = set(branch["source_ids"])
    lower = {source_id: 0 for source_id in expected_ids}
    upper = {
        source_id: branch["source_cardinality"]["maximum"]
        for source_id in expected_ids
    }
    constrained = set()
    for site in branch["write_sites"]:
        if site["current_table"]:
            continue
        bounds = site["source_cardinality"]
        for source_id in site["immutable_source_ids"]:
            constrained.add(source_id)
            lower[source_id] = max(lower[source_id], bounds["minimum"])
            upper[source_id] = min(upper[source_id], bounds["maximum"])
    for source_id in expected_ids - constrained:
        upper[source_id] = branch["source_cardinality"]["maximum"]

    counts = dict(upper if use_maximum else lower)
    target = (
        min(branch["source_cardinality"]["maximum"], sum(upper.values()))
        if use_maximum
        else max(branch["source_cardinality"]["minimum"], sum(lower.values()))
    )
    total = sum(counts.values())
    if total > target:
        for source_id in sorted(
            counts,
            key=lambda item: (
                upper[item] - lower[item],
                item,
            ),
            reverse=True,
        ):
            reduction = min(total - target, counts[source_id] - lower[source_id])
            counts[source_id] -= reduction
            total -= reduction
            if total == target:
                break
    elif total < target:
        for source_id in sorted(
            counts,
            key=lambda item: (
                _journal_sources()[item]["append_order"],
                item,
            ),
        ):
            addition = min(target - total, upper[source_id] - counts[source_id])
            counts[source_id] += addition
            total += addition
            if total == target:
                break
    if total != target:
        raise ProtocolError("Cannot construct canonical coverage boundary.")
    sources = _journal_sources()
    return [
        source_id
        for source_id in sorted(
            counts,
            key=lambda item: (
                sources[item]["append_order"],
                item,
            ),
        )
        for _ in range(counts[source_id])
    ]


def _auth_policy(routes: list[dict]) -> dict:
    policy = {
        "version": "1.0.0",
        "policy_id": "operations-api-auth-foundation",
        "issued_at": "2026-08-11T00:00:00Z",
        "expires_at": "2026-08-12T00:00:00Z",
        "clients": [
            {
                "client_id": "owner-client",
                "kind": "owner-ui",
                "identity_id": "human-owner:foundation",
                "enabled": True,
                "bearer_token_sha256": "1" * 64,
                "project_ids": ["example-agentic-product"],
                "route_ids": [
                    route["id"]
                    for route in routes
                    if "owner-ui" in route["client_kinds"]
                ],
                "global_route_ids": ["owner-inbox-get"],
            }
        ],
        "content_sha256": "",
    }
    policy["content_sha256"] = _content_sha256(policy)
    return policy


def _mutation_payloads() -> dict[str, dict]:
    return {
        "product-register": {
            "operation": "product-register",
            "configuration": {"project_id": "example-agentic-product"},
        },
        "product-update": {
            "operation": "product-update",
            "configuration": {"project_id": "example-agentic-product"},
            "expected_version": 1,
            "reason": "owner update",
        },
        "product-activate": {
            "operation": "product-activate",
            "expected_version": 1,
        },
        "product-pause": {
            "operation": "product-pause",
            "expected_version": 1,
            "reason": "owner pause",
        },
        "product-archive": {
            "operation": "product-archive",
            "expected_version": 1,
            "decision": "owner archive decision",
        },
        "signal-ingest": {
            "operation": "signal-ingest",
            "envelope": {"signal_id": "signal-foundation"},
        },
        "work-item-create": {
            "operation": "work-item-create",
            "specification": {"work_item_id": "work-foundation"},
            "change_reason": "create work",
        },
        "work-item-create-from-signal": {
            "operation": "work-item-create-from-signal",
            "specification": {"work_item_id": "work-foundation"},
            "change_reason": "create from signal",
        },
        "work-item-update": {
            "operation": "work-item-update",
            "specification": {"work_item_id": "work-foundation"},
            "expected_version": 1,
            "change_reason": "update work",
        },
        "transition-apply": {
            "operation": "transition-apply",
            "command": {"command_id": "transition-foundation"},
        },
        "dispatch-submit": {
            "operation": "dispatch-submit",
            "submission": {"dispatch_id": "dispatch-foundation"},
        },
        "dispatch-cancel": {
            "operation": "dispatch-cancel",
            "reason": "owner cancellation",
            "owner_id": None,
            "lease_generation": None,
        },
        "run-bind-start": {
            "operation": "run-bind-start",
            "submission": {"dispatch_id": "dispatch-foundation"},
        },
        "run-lifecycle-apply": {
            "operation": "run-lifecycle-apply",
            "command": {"command_id": "run-command-foundation"},
        },
        "run-checkpoint-reference": {
            "operation": "run-checkpoint-reference",
            "command": {"command_id": "checkpoint-command-foundation"},
            "reference": {"id": "checkpoint-reference-foundation"},
            "checkpoint": {"id": "checkpoint-foundation"},
            "worker_observation": {"id": "worker-observation-foundation"},
        },
        "run-artifact-reference": {
            "operation": "run-artifact-reference",
            "command": {"command_id": "artifact-command-foundation"},
            "reference": {"id": "artifact-reference-foundation"},
        },
        "work-room-input-create": {
            "operation": "work-room-input-create",
            "input": {
                "kind": "note",
                "run_id": None,
                "reason": "Record owner context.",
                "payload": {"text": "Keep the current implementation bounded."},
            },
        },
        "decision-request-create": {
            "operation": "decision-request-create",
            "request": {
                "version": "1.0.0",
                "decision_request_id": "decision-request-foundation",
                "project_id": "example-agentic-product",
                "work_item_id": "work-item-foundation",
                "run_id": None,
                "kind": "approval",
                "subject_sha256": SHA256,
                "subject_version": 1,
                "required_role": "product-owner",
                "question": "Cancel this bounded work item?",
                "impact": "Approval moves the work item to cancelled.",
                "choices": [
                    {
                        "choice_id": "approve-cancel",
                        "label": "Approve cancellation",
                        "decision": "approved",
                        "transition_trigger": "cancel",
                        "evidence_refs": {
                            "cancellation decision": "evidence:foundation"
                        },
                    },
                    {
                        "choice_id": "reject-cancel",
                        "label": "Continue work",
                        "decision": "rejected",
                        "transition_trigger": None,
                        "evidence_refs": {},
                    },
                ],
                "requested_by_identity_id": "human-owner:foundation",
                "requested_at": TIMESTAMP,
                "expires_at": "2026-08-11T13:00:00Z",
            },
        },
        "decision-create": {
            "operation": "decision-create",
            "response": {
                "version": "1.0.0",
                "decision_id": "decision-foundation",
                "choice_id": "approve-cancel",
                "reason": "Approve the exact bounded decision.",
                "evidence_refs": ["evidence:foundation-review"],
                "decided_by_identity_id": "human-owner:foundation",
                "decided_as_role": "product-owner",
            },
        },
        "decision-request-cancel": {
            "operation": "decision-request-cancel",
            "reason": "Cancel the pending decision request.",
        },
        "decision-request-expire": {
            "operation": "decision-request-expire",
        },
    }


def _mutation_request(operation: str = "product-activate") -> dict:
    payload = _mutation_payloads()[operation]
    return {
        "version": "1.0.0",
        "project_id": "example-agentic-product",
        "idempotency_key": "foundation-request-001",
        "actor_identity_id": "human-owner:foundation",
        "payload": payload,
        "payload_sha256": canonical_sha256(payload),
        "submitted_at": TIMESTAMP,
    }


def _liveness() -> dict:
    document = {
        "version": "1.0.0",
        "service": "elder-factory-operations-api",
        "status": "alive",
        "boot_id": "operations-api-boot-" + "1" * 32,
        "runtime_generation": 1,
        "checked_at": TIMESTAMP,
        "uptime_seconds": 1.5,
        "content_sha256": "",
    }
    document["content_sha256"] = _content_sha256(document)
    return document


def _health(readiness: dict | None = None) -> dict:
    readiness = readiness or _readiness()
    document = {
        "version": "1.0.0",
        "service": "elder-factory-operations-api",
        "status": "ready",
        "boot_id": "operations-api-boot-" + "1" * 32,
        "runtime_generation": 1,
        "checked_at": TIMESTAMP,
        "uptime_seconds": 1.5,
        "dependencies": [
            {
                "id": "decisions",
                "status": "ready",
                "required": False,
                "reason_code": None,
                "observed_at": TIMESTAMP,
            }
        ],
        "readiness_snapshot_sha256": readiness["content_sha256"],
        "readiness_checked_at": readiness["checked_at"],
        "content_sha256": "",
    }
    document["content_sha256"] = _content_sha256(document)
    return document


def _readiness() -> dict:
    document = {
        "version": "1.0.0",
        "ready": True,
        "status": "ready",
        "checked_at": TIMESTAMP,
        "last_full_verification_at": TIMESTAMP,
        "last_verification_attempt_at": TIMESTAMP,
        "verification_state": "current",
        "maximum_verification_age_seconds": 30,
        "mutation_ready": True,
        "journal": {
            "generation": 1,
            "sequence": 0,
            "entry_id": None,
            "entry_sha256": None,
        },
        "projections": [
            {
                "projection_id": projection_id,
                "generation": 1,
                "journal_sequence": 0,
                "lag": 0,
                "status": "ready",
                "projection_sha256": SHA256,
            }
            for projection_id in EXPECTED_PROJECTIONS
        ],
        "capabilities": factory_capability_status()["capabilities"],
        "blockers": [],
        "mutation_blockers": [],
        "degradations": [],
        "content_sha256": "",
    }
    document["content_sha256"] = _content_sha256(document)
    return document


def _idempotency_record(status: str = "accepted") -> dict:
    document = {
        "version": "1.0.0",
        "route_id": "product-update",
        "client_id": "owner-client",
        "project_id": "example-agentic-product",
        "idempotency_key": "foundation-request-001",
        "request_sha256": SHA256,
        "mutation_scope_sha256": "b" * 64,
        "status": status,
        "owner_boot_id": "operations-api-boot-" + "1" * 32,
        "owner_runtime_generation": 1,
        "attempt_count": 1,
        "accepted_at": TIMESTAMP,
        "service_started_at": None,
        "completed_at": None,
        "updated_at": TIMESTAMP,
        "response_status": None,
        "response_json": None,
        "response_sha256": None,
        "result_proof_sha256": None,
        "content_sha256": "",
    }
    if status in {"executing", "retryable", "completed"}:
        document["service_started_at"] = TIMESTAMP
    if status == "retryable":
        response = {
            "version": "1.0.0",
            "status": "error",
            "error": {
                "code": "internal-error",
                "reason_code": "canonical-mutation-not-applied",
            },
        }
        document.update(
            {
                "response_status": 500,
                "response_json": response,
                "response_sha256": canonical_sha256(response),
                "result_proof_sha256": "c" * 64,
            }
        )
    if status == "completed":
        response = {"version": "1.0.0", "status": "ok"}
        document.update(
            {
                "completed_at": TIMESTAMP,
                "response_status": 200,
                "response_json": response,
                "response_sha256": canonical_sha256(response),
                "result_proof_sha256": "c" * 64,
            }
        )
    document["content_sha256"] = _content_sha256(document)
    return document


def _runtime_record(status: str = "ready") -> dict:
    document = {
        "version": "1.0.0",
        "service_id": "elder-factory-operations-api",
        "boot_id": "operations-api-boot-" + "1" * 32,
        "runtime_generation": 1,
        "status": status,
        "process_id": 1234,
        "host_id": "foundation-host",
        "route_registry_sha256": SHA256,
        "binding_registry_sha256": "b" * 64,
        "auth_policy_sha256": "c" * 64,
        "started_at": "2026-08-11T11:59:55Z",
        "heartbeat_at": TIMESTAMP,
        "lease_expires_at": "2026-08-11T12:00:05Z",
        "content_sha256": "",
    }
    document["content_sha256"] = _content_sha256(document)
    return document


def _factory_entity(
    entity_type: str,
    entity_id: str,
    status: str,
    payload: dict,
) -> dict:
    record = {
        "version": "0.1.0",
        "id": entity_id,
        "entity_type": entity_type,
        "project_id": "example-agentic-product",
        "actor_identity_id": "founder",
        "status": status,
        "record_version": 1,
        "created_at": TIMESTAMP,
        "updated_at": TIMESTAMP,
        "correlation_id": f"{entity_type}:{entity_id}",
        "causation_id": None,
        "content_sha256": None,
        "payload": payload,
    }
    record["content_sha256"] = factory_entity_content_sha256(record)
    return record


def _factory_command() -> dict:
    payload = {"operation": "start"}
    return {
        "version": "1.0.0",
        "command_id": "command-foundation",
        "project_id": "example-agentic-product",
        "work_item_id": "work-item-foundation",
        "run_id": None,
        "worker_session_id": None,
        "command_type": "worker.start",
        "mutability": "mutation",
        "idempotency_key": "dispatch-foundation-001",
        "authority_ref": "authority:dispatch-foundation",
        "correlation_id": "work-item:work-item-foundation",
        "causation_id": "transition-foundation",
        "attempt": 1,
        "status": "accepted",
        "submitted_at": "2026-08-11T11:00:00Z",
        "expires_at": "2026-08-11T13:00:00Z",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _adapter_request(command: dict) -> dict:
    payload = {"command": command}
    return {
        "version": "1.0.0",
        "contract_id": "worker-adapter",
        "operation": "send",
        "request_id": "request-dispatch-foundation",
        "project_id": command["project_id"],
        "work_item_id": command["work_item_id"],
        "run_id": None,
        "session_id": None,
        "submitted_at": "2026-08-11T11:00:01Z",
        "deadline_at": "2026-08-11T12:00:00Z",
        "correlation_id": command["correlation_id"],
        "causation_id": command["causation_id"],
        "mutability": "mutation",
        "idempotency_key": command["idempotency_key"],
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _mutation_record(route_id: str) -> dict:
    if route_id.startswith("product-"):
        product = _factory_entity(
            "product-factory",
            "product-factory-foundation",
            "draft",
            {
                "name": "Foundation Product",
                "profile_ref": "profile:example-agentic-product",
                "autonomy_ceiling": "L1",
            },
        )
        return {
            "version": "1.0.0",
            "product_factory": product,
            "profile_binding": {
                "profile_path": "examples/minimal-project-profile.json",
                "protocol_version": "0.5.1",
                "profile_status": "ratified",
                "content_sha256": SHA256,
            },
            "repository_binding": {"root": str(ROOT)},
            "worker_policy": {"adapter_id": "codex"},
            "integration_refs": [],
            "archived_at": None,
        }
    if route_id == "signal-ingest":
        signal = _factory_entity(
            "signal",
            "signal-foundation",
            "accepted",
            {
                "source": "manual",
                "source_reference": "manual:owner-inbox/foundation",
                "idempotency_key": "signal-foundation-ingress",
                "payload_sha256": SHA256,
            },
        )
        normalized = {
            "type": "work-request",
            "title": "Foundation request",
            "description": "Validate the SF-107 response contract.",
            "priority": "normal",
            "labels": ["foundation"],
        }
        return {
            "version": "1.0.0",
            "signal": signal,
            "integration_id": "owner-inbox",
            "source_event_id": "manual-foundation",
            "source_sequence": None,
            "occurred_at": TIMESTAMP,
            "received_at": TIMESTAMP,
            "authentication": {
                "status": "verified",
                "method": "profile-role-binding",
                "principal_ref": "founder",
                "evidence_ref": "profile:example-agentic-product/founder",
                "verified_at": TIMESTAMP,
            },
            "normalized": normalized,
            "envelope_sha256": SHA256,
            "request_sha256": "b" * 64,
            "disposition": {
                "quarantined": False,
                "reason_code": None,
                "reason": None,
                "duplicate_of": None,
            },
        }
    if route_id.startswith("work-item-"):
        work_item = _factory_entity(
            "work-item",
            "work-item-foundation",
            "draft",
            {
                "objective": "Validate the SF-107 response contract.",
                "scope": ["foundation"],
                "non_goals": ["runtime"],
                "priority": "normal",
                "stage": "draft",
                "revision_id": "work-item-revision-foundation",
                "owner_identity_id": "founder",
                "evidence_plan": ["foundation"],
            },
        )
        revision = _factory_entity(
            "work-item-revision",
            "work-item-revision-foundation",
            "current",
            {
                "work_item_id": work_item["id"],
                "revision_number": 1,
                "previous_revision_id": None,
                "snapshot_sha256": SHA256,
                "change_reason": "Create the foundation fixture.",
            },
        )
        return {
            "version": "1.0.0",
            "work_item": work_item,
            "current_revision": revision,
            "acceptance_criteria": ["The contract validates."],
            "outcome_ids": ["outcome:foundation"],
            "change_class": "internal-code",
            "authority_refs": ["profile:example-agentic-product/founder"],
            "dependencies": [],
            "source_links": [{"kind": "manual"}],
        }
    if route_id == "transition-apply":
        transition = _factory_entity(
            "stage-transition",
            "transition-foundation",
            "recorded",
            {
                "work_item_id": "work-item-foundation",
                "from_stage": "draft",
                "to_stage": "ready",
                "trigger": "submit",
                "authority_ref": "authority:transition-foundation",
                "evidence_refs": [],
            },
        )
        command = {
            "version": "1.0.0",
            "command_id": "transition-command-foundation",
            "project_id": "example-agentic-product",
            "work_item_id": "work-item-foundation",
            "trigger": "submit",
            "expected_version": 1,
            "actor_identity_id": "founder",
            "reason": "Submit the foundation work item.",
            "field_bindings": {"revision_id": "revision-foundation"},
            "evidence_refs": {},
            "authority": {
                "role": "product-owner",
                "mode": "modify-only",
                "resource": "obligation",
                "action": "modify",
                "authority_ref": "authority:transition-foundation",
                "accountable_command_ref": "command:transition-foundation",
                "delegated_runtime_lease_ref": None,
                "request_sha256": SHA256,
                "decision": "allowed",
                "decision_ref": "decision:transition-foundation",
                "decided_at": TIMESTAMP,
                "result_sha256": "b" * 64,
            },
            "submitted_at": TIMESTAMP,
        }
        return {
            "version": "1.0.0",
            "transition": transition,
            "command": command,
            "command_sha256": canonical_sha256(command),
            "rule_id": "submit-draft",
            "authority_mapping": {"role": "product-owner"},
            "decision": {
                "accepted": True,
                "reason_code": "accepted",
                "reason": "Accepted.",
                "observed_stage": "draft",
                "requested_stage": "ready",
                "observed_work_item_version": 1,
                "resulting_work_item_version": 2,
            },
            "work_item_before_sha256": SHA256,
            "work_item_after_sha256": "b" * 64,
            "terminal_hook": None,
        }
    if route_id.startswith("dispatch-"):
        command = _factory_command()
        request = _adapter_request(command)
        record = {
            "version": "1.0.0",
            "dispatch_id": "dispatch-foundation",
            "record_version": 1,
            "status": "pending",
            "accepted_command": command,
            "current_command": copy.deepcopy(command),
            "adapter_request": request,
            "queue_transition_command_id": "transition-command-foundation",
            "queue_transition_sha256": SHA256,
            "submission_sha256": "b" * 64,
            "attempt_count": 0,
            "lease_generation": 0,
            "max_attempts": 5,
            "available_at": "2026-08-11T11:00:01Z",
            "lease": None,
            "execution_started_at": None,
            "reconciliation_ref": None,
            "last_response": None,
            "last_error": None,
            "cancellation": None,
            "dead_letter_id": None,
            "created_at": "2026-08-11T11:00:01Z",
            "updated_at": "2026-08-11T11:00:01Z",
            "completed_at": None,
            "content_sha256": "",
        }
        record["content_sha256"] = _content_sha256(record)
        return record
    if route_id == "run-bind-start":
        initial_binding = {
            "run_id": "run-foundation",
            "content_sha256": "",
        }
        initial_binding["content_sha256"] = _content_sha256(
            initial_binding
        )
        record = {
            "version": "1.0.0",
            "binding_seed_sha256": SHA256,
            "initial_binding": initial_binding,
            "run": {
                "id": "run-foundation",
                "project_id": "example-agentic-product",
            },
            "worker_session": {"id": "worker-session-foundation"},
            "workspace": {"id": "workspace-foundation"},
            "cleanup_state": "not-required",
            "elder_reconciliation_state": "current",
            "content_sha256": "",
        }
    elif route_id in {
        "run-lifecycle-apply",
        "run-checkpoint-reference",
        "run-artifact-reference",
    }:
        result = {
            "run_id": "run-foundation",
            "project_id": "example-agentic-product",
        }
        if route_id == "run-checkpoint-reference":
            result.update(
                {
                    "checkpoint_reference_id": (
                        "checkpoint-reference-foundation"
                    ),
                    "checkpoint_sha256": "b" * 64,
                }
            )
        elif route_id == "run-artifact-reference":
            result.update(
                {
                    "artifact_reference_id": (
                        "artifact-reference-foundation"
                    ),
                    "artifact_sha256": "b" * 64,
                }
            )
        record = {
            "version": "1.0.0",
            "command_id": "run-command-foundation",
            "result_version": 1,
            "status": "applied",
            "result": result,
            "recorded_at": TIMESTAMP,
            "causation_sha256": SHA256,
            "content_sha256": "",
        }
    record["content_sha256"] = _content_sha256(record)
    return record


def _projection_history_item(subject_id: str) -> dict:
    return {
        "journal_sequence": 1,
        "entry_id": "journal-entry-" + "1" * 32,
        "source_registry_id": "product-factory-revisions",
        "source_subject_id": subject_id,
        "source_subject_version": 1,
        "operation": "register",
        "occurred_at": TIMESTAMP,
        "record": {"id": subject_id, "status": "draft"},
    }


def _projection_record(route_id: str = "product-get") -> dict:
    scope = EXPECTED_RESPONSE_SCOPES.get(
        route_id,
        EXPECTED_RESPONSE_SCOPES["product-get"],
    )
    projection_id = scope[2]
    if projection_id == "public-events":
        projection_id = "products"
    subject_id = FIXTURE_SUBJECT_BY_ROUTE.get(
        route_id,
        {
            "products": "product-factory-foundation",
            "signals": "signal-foundation",
            "work-items": "work-item-foundation",
            "transitions": "transition-foundation",
            "commands": "dispatch-foundation",
            "runs": "run-foundation",
            "timeline": "product-factory-foundation",
        }[projection_id],
    )
    if projection_id == "timeline":
        row = {
            "version": "1.0.0",
            "projection_id": "timeline",
            "project_id": "example-agentic-product",
            "subject_id": "1",
            "journal_sequence": 1,
            "entry_id": "journal-entry-" + "1" * 32,
            "entry_sha256": SHA256,
            "fact_type": "product.factory-revision",
            "operation": "register",
            "source_registry_id": "product-factory-revisions",
            "source_subject_id": subject_id,
            "source_subject_version": 1,
            "correlation_id": "project:example-agentic-product",
            "causation_id": None,
            "occurred_at": TIMESTAMP,
            "recorded_at": TIMESTAMP,
            "parent_ids": {"product_factory_id": subject_id},
            "record": {"id": subject_id, "status": "draft"},
            "updated_at": TIMESTAMP,
            "content_sha256": "",
        }
        row["content_sha256"] = _content_sha256(row)
        return row
    source_id = PROJECTION_FIXTURE_SOURCE_BY_ID[projection_id]
    history_item = _projection_history_item(subject_id)
    history_item["source_registry_id"] = source_id
    row = {
        "version": "1.0.0",
        "projection_id": projection_id,
        "project_id": "example-agentic-product",
        "subject_id": subject_id,
        "history": [history_item],
        "latest_by_source": {
            source_id: copy.deepcopy(history_item["record"])
        },
        "parent_ids": {"subject_id": subject_id},
        "source_subject_version": 1,
        "last_journal_sequence": 1,
        "updated_at": TIMESTAMP,
        "content_sha256": "",
        "status": "draft",
    }
    if projection_id == "signals":
        row["received_at"] = TIMESTAMP
        row["status"] = "accepted"
    elif projection_id == "work-items":
        row["priority"] = "medium"
    elif projection_id == "transitions":
        row["recorded_at"] = TIMESTAMP
        row["command_id"] = "transition-command-foundation"
        row["status"] = "accepted"
    elif projection_id == "commands":
        row["status"] = "pending"
    elif projection_id == "runs":
        row["status"] = "queued"
    row["content_sha256"] = _content_sha256(row)
    return row


def _public_event() -> dict:
    payload = {
        "signal_id": "signal-foundation",
        "source_reference": "manual:owner-inbox/foundation",
    }
    event_id = "event-foundation"
    return {
        "version": "1.0.0",
        "event_id": event_id,
        "event_type": "integration.signal.accepted",
        "record_kind": "journal-entry",
        "authoritative": True,
        "source_event_id": None,
        "occurred_at": TIMESTAMP,
        "recorded_at": TIMESTAMP,
        "cursor": {
            "version": "1.0.0",
            "stream_id": "factory-public-events-example-agentic-product",
            "generation": 1,
            "sequence": 1,
            "event_id": event_id,
            "snapshot_sha256": SHA256,
            "issued_at": TIMESTAMP,
        },
        "correlations": {
            "product_id": "product-factory-foundation",
            "project_id": "example-agentic-product",
            "work_item_id": None,
            "run_id": None,
            "session_id": None,
        },
        "actor": {"identity_id": "factory-journal", "kind": "system"},
        "source": {
            "plane": "factory-operations",
            "adapter_id": None,
            "source_ref": "journal:product-factory-revisions:1",
        },
        "correlation_id": "product.factory.revision:foundation",
        "causation_id": None,
        "idempotency_key": "signal-foundation-ingress",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _mutation_result_data(route_id: str) -> dict:
    record = _mutation_record(route_id)
    evidence = _trusted_mutation_evidence(route_id, record)
    return _mutation_result_from_evidence(route_id, record, evidence)


def _mutation_result_from_evidence(
    route_id: str,
    record: dict,
    evidence: dict,
) -> dict:
    record_contract = MUTATION_RECORD_SCHEMA_BY_ROUTE[route_id]
    source = copy.deepcopy(evidence["primary_source"])
    entries = evidence["entries"]
    journal = {
        "api_request_sha256": evidence["api_request_sha256"],
        "mutation_id": evidence["mutation_id"],
        "mutation_identity_sha256": evidence[
            "mutation_identity_sha256"
        ],
        "coverage_branch_id": evidence["coverage_branch_id"],
        "generation": evidence["generation"],
        "first_sequence": entries[0]["sequence"],
        "last_sequence": entries[-1]["sequence"],
        "entry_ids": [entry["entry_id"] for entry in entries],
        "entry_sha256s": [
            entry["entry_sha256"] for entry in entries
        ],
        "batch_sha256": canonical_sha256(
            [entry["entry_sha256"] for entry in entries]
        ),
    }
    proof = {
        "record_contract": record_contract,
        "record_sha256": canonical_sha256(record),
        "source": source,
        "journal": journal,
    }
    return {
        "version": "1.0.0",
        "record_contract": record_contract,
        "record": record,
        "record_sha256": proof["record_sha256"],
        "source": source,
        "journal": journal,
        "result_proof_sha256": canonical_sha256(proof),
    }


def _mutation_record_identity(
    route_id: str,
    record: dict,
    *,
    trusted_project_id: str | None = None,
) -> tuple[str, str, str]:
    if route_id.startswith("product-"):
        entity = record["product_factory"]
        return entity["project_id"], entity["id"], entity["id"]
    if route_id == "signal-ingest":
        entity = record["signal"]
        return entity["project_id"], entity["id"], entity["id"]
    if route_id.startswith("work-item-"):
        entity = record["work_item"]
        return entity["project_id"], entity["id"], entity["id"]
    if route_id == "transition-apply":
        return (
            record["command"]["project_id"],
            record["command"]["work_item_id"],
            record["transition"]["id"],
        )
    if route_id.startswith("dispatch-"):
        return (
            record["accepted_command"]["project_id"],
            record["dispatch_id"],
            record["dispatch_id"],
        )
    if route_id == "run-bind-start":
        return (
            record["run"]["project_id"],
            record["run"]["id"],
            record["run"]["id"],
        )
    if route_id in {
        "run-lifecycle-apply",
        "run-checkpoint-reference",
        "run-artifact-reference",
    }:
        return (
            record["result"]["project_id"],
            record["result"]["run_id"],
            record["command_id"],
        )
    if trusted_project_id is None:
        raise ProtocolError("Run mutation identity requires project truth.")
    raise ProtocolError(f"Unsupported run mutation identity: {route_id}")


def _mutation_source_record_sha256(route_id: str, record: dict) -> str:
    if route_id == "run-bind-start":
        return record["initial_binding"]["content_sha256"]
    if route_id.startswith(("dispatch-", "run-")):
        return record["content_sha256"]
    return canonical_sha256(record)


def _extract_mutation_record(
    route_id: str,
    service_result: dict,
) -> dict:
    record = copy.deepcopy(service_result)
    if route_id == "run-bind-start":
        command_result = record.pop("command_result", None)
        if command_result is None:
            raise ProtocolError(
                "Run bind service result is missing command_result."
            )
    return record


def _trusted_mutation_evidence(
    route_id: str,
    record: dict,
) -> dict:
    project_id, scope_subject_id, source_subject_id = (
        _mutation_record_identity(
            route_id,
            record,
            trusted_project_id="example-agentic-product",
        )
    )
    branch_id = MUTATION_FIXTURE_BRANCH_BY_ROUTE[route_id]
    branch = _journal_coverage()[branch_id]
    sources = _journal_sources()
    api_request_sha256 = canonical_sha256(
        {
            "route_id": route_id,
            "project_id": project_id,
            "subject_id": scope_subject_id,
        }
    )
    mutation_identity_sha256 = canonical_sha256(
        {
            "coverage_branch_id": branch_id,
            "api_request_sha256": api_request_sha256,
        }
    )
    mutation_id = f"mutation-{mutation_identity_sha256[:32]}"
    primary_source_id = MUTATION_PRIMARY_SOURCE_BY_ROUTE[route_id]
    primary_position = max(
        index
        for index, source_id in enumerate(branch["source_ids"], start=1)
        if source_id == primary_source_id
    )
    source_versions: dict[str, int] = {}
    entries = []
    previous_sha256 = None
    primary_source = None
    source_record_sha256 = _mutation_source_record_sha256(
        route_id,
        record,
    )
    fact_count = len(branch["source_ids"])
    for position, source_id in enumerate(branch["source_ids"], start=1):
        source = sources[source_id]
        source_versions[source_id] = source_versions.get(source_id, 0) + 1
        source_version = source_versions[source_id]
        is_primary = position == primary_position
        subject_id = (
            source_subject_id
            if is_primary
            else f"{source_id}-support-{position}"
        )
        source_record = {
            "source_registry_id": source_id,
            "table": source["table"],
            "key": {
                source["primary_key"][0]: subject_id,
            },
            "record_version": source_version,
            "record_sha256": (
                source_record_sha256 if is_primary else SHA256
            ),
            "row_sha256": canonical_sha256(
                {
                    "source_registry_id": source_id,
                    "subject_id": subject_id,
                    "source_version": source_version,
                }
            ),
        }
        projection_document = {
            "source_registry_id": source_id,
            "project_id": project_id,
            "subject_id": subject_id,
            "record_sha256": source_record["record_sha256"],
        }
        entry = {
            "version": "1.0.0",
            "stream_id": "factory-operations",
            "generation": 1,
            "sequence": position,
            "entry_id": (
                "journal-entry-"
                + canonical_sha256(
                    {
                        "mutation_id": mutation_id,
                        "position": position,
                    }
                )[:32]
            ),
            "previous_entry_sha256": previous_sha256,
            "entry_sha256": "0" * 64,
            "transaction_id": mutation_id,
            "transaction_position": position,
            "transaction_fact_count": fact_count,
            "source_append_order": source["append_order"],
            "coverage_branch_id": branch_id,
            "mutation_identity_sha256": mutation_identity_sha256,
            "fact_type": source["fact_type"],
            "project_id": project_id,
            "subject_type": source["fact_type"],
            "subject_id": subject_id,
            "subject_version": source_version,
            "operation": "api.result",
            "occurred_at": TIMESTAMP,
            "recorded_at": TIMESTAMP,
            "source_actor": {
                "identity_id": "human-owner-foundation",
                "kind": "human",
            },
            "recorded_by": {
                "identity_id": "factory-journal",
                "kind": "service",
            },
            "source": {
                "plane": "factory-operations",
                "component": source["component"],
                "reference": f"journal:{source['table']}:{position}",
            },
            "correlation_id": f"api-result:{route_id}",
            "causation_id": None,
            "idempotency_key": "foundation-request-001",
            "redaction": {
                "classification": "internal",
                "redacted_fields": [],
            },
            "source_record": source_record,
            "projection_document_sha256": canonical_sha256(
                projection_document
            ),
            "projection_document": projection_document,
            "extensions": {},
        }
        entry["entry_sha256"] = journal_entry_sha256(entry)
        previous_sha256 = entry["entry_sha256"]
        entries.append(entry)
        if is_primary:
            primary_source = copy.deepcopy(source_record)
    if primary_source is None:
        raise ProtocolError("Mutation fixture primary source is missing.")
    return {
        "api_request_sha256": api_request_sha256,
        "mutation_id": mutation_id,
        "mutation_identity_sha256": mutation_identity_sha256,
        "coverage_branch_id": branch_id,
        "generation": 1,
        "canonical_project_id": project_id,
        "canonical_scope_subject_id": scope_subject_id,
        "primary_source": primary_source,
        "entries": tuple(entries),
    }


def _response_data(validator: str, route_id: str) -> dict:
    if (
        validator.endswith("-mutation-result")
        and validator != "owner-decision-mutation-result"
    ):
        return _mutation_result_data(route_id)
    if validator == "owner-inbox-snapshot":
        snapshot = {
            "version": "1.0.0",
            "project_filter": None,
            "observed_at": TIMESTAMP,
            "complete": True,
            "source_counts": {
                "work-items": 0,
                "session-controls": 0,
                "worker-recovery-cases": 0,
                "worker-recovery-orphans": 0,
            },
            "item_count": 0,
            "items": [],
        }
        return {
            **snapshot,
            "content_sha256": canonical_sha256(snapshot),
        }
    if validator == "owner-portfolio-snapshot":
        stage_counts = {
            status: 0
            for status in (
                "draft",
                "ready",
                "queued",
                "running",
                "waiting",
                "validation",
                "blocked",
                "completed",
                "failed",
                "cancelled",
            )
        }
        counts = {
            "project_id": "example-agentic-product",
            "work_item_count": 0,
            "stage_counts": stage_counts,
            "priority_counts": {
                "low": 0,
                "normal": 0,
                "high": 0,
                "urgent": 0,
            },
            "dependency_blocked_count": 0,
        }
        data = {
            "version": "1.0.0",
            "observed_at": TIMESTAMP,
            "project_ids": ["example-agentic-product"],
            "filters": {
                "project_id": None,
                "status": None,
                "priority": None,
                "dependency_state": None,
                "search": None,
            },
            "products": [
                {
                    "factory_id": "product-factory-foundation",
                    "project_id": "example-agentic-product",
                    "status": "active",
                    "updated_at": TIMESTAMP,
                    "record_version": 1,
                    "work_item_count": 0,
                    "stage_counts": copy.deepcopy(stage_counts),
                    "priority_counts": {
                        "low": 0,
                        "normal": 0,
                        "high": 0,
                        "urgent": 0,
                    },
                    "dependency_blocked_count": 0,
                    "content_sha256": SHA256,
                }
            ],
            "all_project_counts": [counts],
            "total_work_item_count": 0,
            "filtered_work_item_count": 0,
            "returned_work_item_count": 0,
            "work_items": [],
            "continuation": None,
            "freshness": {
                "status": "current",
                "lag_entries": 0,
                "projection_sha256": SHA256,
                "projections": [
                    {
                        "projection_id": "products",
                        "generation": 1,
                        "row_count": 1,
                        "projection_sha256": SHA256,
                    },
                    {
                        "projection_id": "work-items",
                        "generation": 1,
                        "row_count": 0,
                        "projection_sha256": SHA256,
                    },
                ],
                "journal": {
                    "generation": 1,
                    "sequence": 0,
                    "entry_id": None,
                    "entry_sha256": None,
                },
            },
        }
        return {**data, "content_sha256": canonical_sha256(data)}
    if validator == "work-room-snapshot":
        data = {
            "version": "1.0.0",
            "project_id": "example-agentic-product",
            "work_item_id": "work-item-foundation",
            "observed_at": TIMESTAMP,
            "work_item": {
                "status": "running",
                "priority": "high",
                "objective": "Implement the bounded work-room contract.",
                "owner_identity_id": "human-owner:foundation",
                "record_version": 1,
                "content_sha256": SHA256,
            },
            "plan": {
                "scope": ["Owner work-room surface"],
                "non_goals": ["Approval authority"],
                "acceptance_criteria": ["Durable context survives restart"],
                "evidence_plan": ["Foundation contract proof"],
            },
            "runs": [],
            "selected_run_id": None,
            "activity": [],
            "checkpoints": [],
            "artifacts": [],
            "test_evidence": [],
            "diff_evidence": [],
            "decision_requests": [],
            "decisions": [],
            "decision_effects": [],
            "allowed_inputs": ["note"],
            "source_sha256": SHA256,
        }
        return {**data, "content_sha256": canonical_sha256(data)}
    if validator == "work-room-input-result":
        note_body = {
            "version": "1.0.0",
            "note_id": "work-room-note-" + "1" * 32,
            "project_id": "example-agentic-product",
            "work_item_id": "work-item-foundation",
            "run_id": None,
            "author_identity_id": "human-owner:foundation",
            "idempotency_key": "foundation-request-001",
            "correlation_id": "work-room:work-item-foundation",
            "text": "Keep the implementation bounded.",
            "created_at": TIMESTAMP,
        }
        note = {
            **note_body,
            "content_sha256": canonical_sha256(note_body),
        }
        record_sha256 = canonical_sha256(note)
        return {
            "version": "1.0.0",
            "input_kind": "note",
            "record_contract": "work-room-note.schema.json",
            "record": note,
            "record_sha256": record_sha256,
            "source": "work-room-notes",
            "result_proof_sha256": canonical_sha256(
                {
                    "source": "work-room-notes",
                    "record_contract": "work-room-note.schema.json",
                    "record_sha256": record_sha256,
                }
            ),
        }
    request_body = {
        "version": "1.0.0",
        "decision_request_id": "decision-request-foundation",
        "project_id": "example-agentic-product",
        "work_item_id": "work-item-foundation",
        "run_id": None,
        "kind": "approval",
        "subject_sha256": SHA256,
        "subject_version": 1,
        "required_role": "product-owner",
        "question": "Cancel this bounded work item?",
        "impact": "Approval moves the work item to cancelled.",
        "choices": [
            {
                "choice_id": "approve-cancel",
                "label": "Approve cancellation",
                "decision": "approved",
                "transition_trigger": "cancel",
                "evidence_refs": {
                    "cancellation decision": "evidence:foundation"
                },
            },
            {
                "choice_id": "reject-cancel",
                "label": "Continue work",
                "decision": "rejected",
                "transition_trigger": None,
                "evidence_refs": {},
            },
        ],
        "requested_by_identity_id": "human-owner:foundation",
        "requested_at": TIMESTAMP,
        "expires_at": "2026-08-11T13:00:00Z",
        "status": "waiting",
        "record_version": 2,
        "resolved_decision_id": None,
        "terminal_reason": None,
        "updated_at": TIMESTAMP,
    }
    decision_request = {
        **request_body,
        "content_sha256": canonical_sha256(request_body),
    }
    state_body = {
        "version": "1.0.0",
        "request": decision_request,
        "decision": None,
        "effect": None,
    }
    decision_state = {
        **state_body,
        "content_sha256": canonical_sha256(state_body),
    }
    decision_body = {
        "version": "1.0.0",
        "decision_id": "decision-foundation",
        "decision_request_id": "decision-request-foundation",
        "project_id": "example-agentic-product",
        "work_item_id": "work-item-foundation",
        "run_id": None,
        "subject_sha256": SHA256,
        "subject_version": 1,
        "choice_id": "approve-cancel",
        "decision": "approved",
        "transition_trigger": "cancel",
        "transition_evidence_refs": {
            "cancellation decision": "evidence:foundation"
        },
        "reason": "Approve the exact bounded decision.",
        "evidence_refs": ["evidence:foundation-review"],
        "decided_by_identity_id": "human-owner:foundation",
        "decided_as_role": "product-owner",
        "decided_at": TIMESTAMP,
    }
    owner_decision = {
        **decision_body,
        "content_sha256": canonical_sha256(decision_body),
    }
    if validator == "owner-decision-page":
        page_body = {
            "version": "1.0.0",
            "project_id": "example-agentic-product",
            "kind": (
                "decision-requests"
                if route_id == "decision-requests-list"
                else "decisions"
            ),
            "status_filter": None,
            "work_item_id_filter": None,
            "items": [],
            "count": 0,
            "observed_at": TIMESTAMP,
        }
        return {
            **page_body,
            "content_sha256": canonical_sha256(page_body),
        }
    if validator == "owner-decision-state":
        return decision_state
    if validator == "owner-decision":
        return owner_decision
    if validator == "owner-decision-mutation-result":
        state_sha256 = canonical_sha256(decision_state)
        return {
            "version": "1.0.0",
            "operation": route_id,
            "state": decision_state,
            "state_sha256": state_sha256,
            "result_proof_sha256": canonical_sha256(
                {
                    "operation": route_id,
                    "state_sha256": state_sha256,
                }
            ),
        }
    if validator == "audit-replay-snapshot":
        body = {
            "version": "1.0.0",
            "project_id": "example-agentic-product",
            "work_item_id": "work-item-foundation",
            "selected_run_id": None,
            "observed_at": TIMESTAMP,
            "entries": [],
            "entry_count": 0,
            "limitation_counts": {
                "actor-not-recorded": 0,
                "causation-not-recorded": 0,
                "authority-not-recorded": 0,
                "evidence-not-recorded": 0,
                "outside-operations-journal": 0,
            },
            "replay": {
                "status": "verified",
                "journal_generation": 1,
                "journal_sequence": 0,
                "journal_entry_id": None,
                "journal_entry_sha256": None,
                "timeline_generation": 1,
                "timeline_sha256": SHA256,
                "journal_entry_count": 0,
                "journal_entries_sha256": canonical_sha256([]),
            },
            "source_sha256": SHA256,
        }
        return {**body, "content_sha256": canonical_sha256(body)}
    if validator == "owner-metrics-snapshot":
        definitions = [
            {
                "id": metric_id,
                "formula": formula,
                "unit": unit,
                "population": population,
                "exclusions": exclusions,
            }
            for metric_id, formula, unit, population, exclusions in [
                ("cycle-time", "terminal work-item updated_at minus work-item created_at", "seconds", "terminal work items in the selected project", ["nonterminal work items", "records missing either timestamp"]),
                ("wait-time", "sum of each waiting history timestamp to its next history timestamp", "seconds", "closed waiting intervals in work-item history", ["open waiting intervals"]),
                ("retry-count", "count of dispatch history snapshots with status retry", "events", "dispatch history in the selected project", []),
                ("failure-count", "durable failed work items, failed or lost runs, and dead-letter dispatches", "records", "current selected-project records", ["retries that later succeeded"]),
                ("owner-intervention-count", "notes plus work-room controls plus decision requests plus decisions", "records", "explicit owner-facing records in the selected project", ["automatic runtime controls"]),
                ("test-evidence-coverage", "runs with a test-evidence artifact divided by all runs", "ratio", "runs in the selected project", ["test correctness or pass rate not present in artifact metadata"]),
                ("cost", "sum of explicit USD cost records", "USD", "recorded project cost events", ["budget limits", "unpriced tokens", "inferred provider rates"]),
                ("learning-impact", "approved linked learning evaluation delta", "delta", "delivered work linked to governed learning evaluations", ["unlinked candidates", "unapproved observations"]),
                ("completion-ratio", "completed work items divided by all terminal work items", "ratio", "terminal work items in the selected project", ["nonterminal work items"]),
            ]
        ]
        body = {
            "version": "1.0.0",
            "project_id": "example-agentic-product",
            "observed_at": TIMESTAMP,
            "definitions": definitions,
            "delivery": {
                "work_item_count": 0,
                "cycle_time": {
                    "status": "unavailable",
                    "sample_count": 0,
                    "excluded_count": 0,
                    "mean_seconds": None,
                    "p50_seconds": None,
                    "p95_seconds": None,
                },
                "wait_time": {
                    "status": "unavailable",
                    "sample_count": 0,
                    "excluded_count": 0,
                    "mean_seconds": None,
                    "p50_seconds": None,
                    "p95_seconds": None,
                },
            },
            "reliability": {
                "dispatch_count": 0,
                "retry_count": 0,
                "dead_letter_count": 0,
                "failure_count": 0,
                "failed_work_item_count": 0,
                "failed_run_count": 0,
            },
            "control": {
                "status": "partial",
                "owner_intervention_count": None,
                "by_source": {
                    "notes": 0,
                    "controls": None,
                    "decision_requests": 0,
                    "decisions": 0,
                },
            },
            "test_quality": {
                "status": "unavailable",
                "label": "recorded-test-evidence-coverage",
                "run_count": 0,
                "runs_with_test_evidence": 0,
                "coverage_ratio": None,
            },
            "cost": {
                "status": "unavailable",
                "value": None,
                "unit": "USD",
                "reason": "No explicit priced usage or cost events are recorded.",
            },
            "learning_impact": {
                "status": "unavailable",
                "value": None,
                "unit": "evaluation-delta",
                "reason": "No approved governed learning evaluation is linked.",
            },
            "outcomes": {
                "by_status": {
                    status: 0
                    for status in (
                        "draft", "ready", "queued", "running", "waiting",
                        "validation", "blocked", "completed", "failed",
                        "cancelled",
                    )
                },
                "terminal_count": 0,
                "completion_ratio": None,
            },
            "missing_data": [
                "cost-records-unavailable",
                "learning-linkage-unavailable",
                "no-run-samples",
                "no-terminal-cycle-samples",
                "session-control-source-unavailable",
            ],
            "reconciliation": {
                "journal_generation": 1,
                "journal_sequence": 0,
                "journal_entry_sha256": None,
                "work_items_projection_sha256": SHA256,
                "runs_projection_sha256": SHA256,
                "commands_projection_sha256": SHA256,
                "source_counts": {},
                "source_sha256": SHA256,
            },
        }
        return {**body, "content_sha256": canonical_sha256(body)}
    projection_record = _projection_record(route_id)
    public_event = _public_event()
    page_items = [projection_record]
    if route_id in PROJECTION_HISTORY_ROUTES:
        page_items = copy.deepcopy(projection_record["history"])
    values = {
        "version": "1.0.0",
        "capabilities": factory_capability_status()["capabilities"],
        "projection": {
            "projection_id": "products",
            "generation": 1,
            "journal_sequence": 0,
            "projection_sha256": SHA256,
        },
        "journal": {
            "generation": 1,
            "sequence": 0,
            "entry_id": None,
            "entry_sha256": None,
        },
        "verified_at": TIMESTAMP,
        "status": "ready",
        "integrity": {"status": "verified", "report_sha256": SHA256},
        "items": page_items,
        "continuation": None,
        "query": {"limit": 100},
        "project_id": "example-agentic-product",
        "stream_id": "factory-public-events-example-agentic-product",
        "cursor": public_event["cursor"],
    }
    if validator == "projection-record":
        return projection_record
    if validator == "public-event":
        return public_event
    if validator == "public-event-page":
        values["items"] = [public_event]
    return {
        field: copy.deepcopy(values[field])
        for field in RESPONSE_DATA_FIELDS[validator]
    }


def _response_fixture(route_id: str, validator: str) -> dict:
    data = _response_data(validator, route_id)
    return {
        "version": "1.0.0",
        "request_id": "request-" + "1" * 32,
        "route_id": route_id,
        "status": "ok",
        "data_contract": validator,
        "data": data,
        "data_sha256": canonical_sha256(data),
    }


def _mutation_validation_kwargs(
    route_id: str,
    response: dict,
) -> dict:
    evidence = _trusted_mutation_evidence(
        route_id,
        response["data"]["record"],
    )
    return {
        "expected_project_id": evidence["canonical_project_id"],
        "expected_subject_id": evidence[
            "canonical_scope_subject_id"
        ],
        "expected_api_request_sha256": evidence[
            "api_request_sha256"
        ],
        "trusted_mutation_evidence": evidence,
    }


def _redigest_mutation_response(response: dict) -> None:
    data = response["data"]
    data["record_sha256"] = canonical_sha256(data["record"])
    proof = {
        "record_contract": data["record_contract"],
        "record_sha256": data["record_sha256"],
        "source": data["source"],
        "journal": data["journal"],
    }
    data["result_proof_sha256"] = canonical_sha256(proof)
    response["data_sha256"] = canonical_sha256(data)


def _set_mutation_record_project(
    route_id: str,
    record: dict,
    project_id: str,
) -> bool:
    entities = []
    if route_id.startswith("product-"):
        entities = [record["product_factory"]]
    elif route_id == "signal-ingest":
        entities = [record["signal"]]
    elif route_id.startswith("work-item-"):
        entities = [record["work_item"], record["current_revision"]]
    if entities:
        for entity in entities:
            entity["project_id"] = project_id
            entity["content_sha256"] = factory_entity_content_sha256(
                entity
            )
        return True
    if route_id == "transition-apply":
        record["command"]["project_id"] = project_id
        record["command_sha256"] = canonical_sha256(record["command"])
        return True
    if route_id.startswith("dispatch-"):
        record["accepted_command"]["project_id"] = project_id
        record["current_command"]["project_id"] = project_id
        return True
    if route_id == "run-bind-start":
        record["run"]["project_id"] = project_id
        record["content_sha256"] = _content_sha256(record)
        return True
    if route_id in {
        "run-lifecycle-apply",
        "run-checkpoint-reference",
        "run-artifact-reference",
    }:
        record["result"]["project_id"] = project_id
        record["content_sha256"] = _content_sha256(record)
        return True
    return False


def _trusted_projection_store_context(
    route_id: str,
    response_scope: dict,
) -> dict:
    record = _projection_record(route_id)
    context = {
        "origin": "sf-106-projection-store",
        "project_id": record["project_id"],
        "projection_id": response_scope["projection_id"],
        "generation": 1,
        "journal": {
            "generation": 1,
            "sequence": 0,
            "entry_id": None,
            "entry_sha256": None,
        },
        "rows": [
            {
                "subject_id": record["subject_id"],
                "record_json": copy.deepcopy(record),
                "content_sha256": record["content_sha256"],
                "record_sha256": canonical_sha256(record),
            }
        ],
        "content_sha256": "",
    }
    context["content_sha256"] = _content_sha256(context)
    return context


def _projection_validation_kwargs(
    route_id: str,
    response_scope: dict,
) -> dict:
    return {
        "expected_project_id": "example-agentic-product",
        "expected_subject_id": FIXTURE_SUBJECT_BY_ROUTE.get(route_id),
        "response_scope": response_scope,
        "trusted_projection_context": (
            _trusted_projection_store_context(route_id, response_scope)
        ),
    }


def _validate_auth_policy_semantics(
    policy: dict,
    routes: list[dict],
    *,
    now: datetime,
) -> None:
    if policy["content_sha256"] != _content_sha256(policy):
        raise ProtocolError("Auth policy content_sha256 does not match.")
    issued = _parse_time(policy["issued_at"], "Auth policy issued_at")
    expires = _parse_time(policy["expires_at"], "Auth policy expires_at")
    if not issued <= now < expires:
        raise ProtocolError("Auth policy is not current.")
    by_id = {route["id"]: route for route in routes}
    for field in ("client_id", "identity_id", "bearer_token_sha256"):
        values = [client[field] for client in policy["clients"]]
        if len(values) != len(set(values)):
            raise ProtocolError(f"Auth policy {field} values must be unique.")
    for client in policy["clients"]:
        if "roles" in client:
            raise ProtocolError("Auth policy cannot assign canonical roles.")
        reject_secret_material(
            client["identity_id"],
            path=f"Auth policy identity {client['client_id']}",
        )
        for route_id in client["route_ids"]:
            if route_id not in by_id:
                raise ProtocolError(f"Unknown auth policy route: {route_id}")
            if client["kind"] not in by_id[route_id]["client_kinds"]:
                raise ProtocolError(
                    f"Client kind is not eligible for route: {route_id}"
                )
        for route_id in client.get("global_route_ids", []):
            if route_id not in client["route_ids"]:
                raise ProtocolError(
                    "Global auth route must also be an exact route grant."
                )
            if by_id[route_id]["project_scoped"]:
                raise ProtocolError(
                    "Global auth route cannot be project scoped."
                )


def _validate_binding_semantics(
    registry: dict,
    binding_registry: dict,
) -> None:
    if registry["content_sha256"] != _content_sha256(registry):
        raise ProtocolError("Route registry content_sha256 does not match.")
    if binding_registry["content_sha256"] != _content_sha256(
        binding_registry
    ):
        raise ProtocolError("Binding registry content_sha256 does not match.")
    if (
        registry["binding_registry_sha256"]
        != binding_registry["content_sha256"]
    ):
        raise ProtocolError("Route registry binding digest does not match.")

    routes = {route["id"]: route for route in registry["routes"]}
    bindings = {
        binding["route_id"]: binding
        for binding in binding_registry["bindings"]
    }
    if len(routes) != len(registry["routes"]):
        raise ProtocolError("Route IDs must be unique.")
    if len(bindings) != len(binding_registry["bindings"]):
        raise ProtocolError("Binding route IDs must be unique.")
    if set(routes) != set(bindings):
        raise ProtocolError("Route and binding registries must cover exact IDs.")
    if set(routes) != set(EXPECTED_ROUTE_MATRIX):
        raise ProtocolError("Route registry does not match the closed route matrix.")

    bootstrap = binding_registry["registration_bootstrap"]
    if bootstrap != {
        "route_id": "product-register",
        "configuration_source": "body.payload.configuration",
        "profile_path_source": (
            "body.payload.configuration.profile_path"
        ),
        "identity_source": "auth.identity_id",
        "required_roles": ["human-owner", "product-owner"],
        "repeat_in_application_service": True,
    }:
        raise ProtocolError("Product registration bootstrap contract changed.")
    register_binding = bindings["product-register"]
    for source in (
        bootstrap["configuration_source"],
        bootstrap["profile_path_source"],
        bootstrap["identity_source"],
    ):
        if not _binding_source_exists(register_binding, source):
            raise ProtocolError(
                f"Product registration bootstrap source is invalid: {source}"
            )

    response_scopes = {
        scope["route_id"]: scope
        for scope in binding_registry["response_scopes"]
    }
    if len(response_scopes) != len(
        binding_registry["response_scopes"]
    ):
        raise ProtocolError("Response scope route IDs must be unique.")
    if set(response_scopes) != set(EXPECTED_RESPONSE_SCOPES):
        raise ProtocolError("Response scopes do not cover exact query routes.")
    for route_id, expected_scope in EXPECTED_RESPONSE_SCOPES.items():
        scope = response_scopes[route_id]
        observed_scope = (
            scope["project_source"],
            scope["subject_source"],
            scope["projection_id"],
        )
        if observed_scope != expected_scope:
            raise ProtocolError(
                f"Response scope changed for route: {route_id}"
            )
        binding = bindings[route_id]
        for source in (
            scope["project_source"],
            scope["subject_source"],
        ):
            if source is not None and not _binding_source_exists(
                binding,
                source,
            ):
                raise ProtocolError(
                    f"Response scope source is invalid: {route_id}"
                )
    if (
        binding_registry["response_extractions"]
        != EXPECTED_RESPONSE_EXTRACTIONS
    ):
        raise ProtocolError("Response extraction contract changed.")

    for route_id, route in routes.items():
        binding = bindings[route_id]
        expected = EXPECTED_ROUTE_MATRIX[route_id]
        for field in (
            "method",
            "path",
            "kind",
            "authentication",
            "project_scoped",
            "readiness_required",
            "service",
        ):
            if route[field] != expected[field]:
                raise ProtocolError(
                    f"Closed route matrix mismatch for {route_id}: {field}"
                )
        if binding["response_validator"] != expected[
            "response_validator"
        ]:
            raise ProtocolError(
                f"Closed response validator mismatch: {route_id}"
            )
        if binding["query_parameters"] != EXPECTED_QUERY_PARAMETERS.get(
            route_id,
            [],
        ):
            raise ProtocolError(
                f"Closed query parameter mismatch: {route_id}"
            )

        placeholders = re.findall(r"\{([a-z0-9_]+)\}", route["path"])
        if placeholders != binding["path_parameters"]:
            raise ProtocolError(
                f"Path parameters do not match route: {route_id}"
            )
        for contract in binding["member_contracts"]:
            if not _schema_path(contract["schema"]).is_file():
                raise ProtocolError(
                    f"Binding references missing schema: {route_id}"
                )
            if not _binding_source_exists(binding, contract["source"]):
                raise ProtocolError(
                    f"Binding member source does not exist: {route_id}"
                )
        for equality in binding["equality_bindings"]:
            left, right = equality.split("=", 1)
            if not _binding_source_exists(
                binding,
                left,
            ) or not _binding_source_exists(binding, right):
                raise ProtocolError(
                    f"Binding equality source does not exist: {route_id}"
                )
        for source in binding["mutation_scope_fields"]:
            if not _binding_source_exists(binding, source):
                raise ProtocolError(
                    f"Binding mutation scope source does not exist: {route_id}"
                )
        for argument in binding["service_arguments"]:
            if not _binding_source_exists(binding, argument["source"]):
                raise ProtocolError(
                    f"Binding service source does not exist: {route_id}"
                )

        if route["path"].startswith("/health/"):
            if (
                route["authentication"] != "none"
                or route["client_kinds"]
                or route["roles"]
            ):
                raise ProtocolError(
                    f"Health route exposure changed: {route_id}"
                )
        elif route["authentication"] != "bearer-policy":
            raise ProtocolError(f"Authenticated route drift: {route_id}")
        if route["project_scoped"] != (
            "{project_id}" in route["path"]
        ):
            raise ProtocolError(f"Project scope mismatch: {route_id}")
        if route["project_scoped"] and not route["roles"]:
            raise ProtocolError(f"Project route has no role gate: {route_id}")
        if not route["project_scoped"] and route["roles"]:
            raise ProtocolError(f"Global route assigns roles: {route_id}")

        if route["kind"] == "mutation":
            if binding["payload_operation"] != route_id:
                raise ProtocolError(
                    f"Mutation payload operation mismatch: {route_id}"
                )
            if (
                route["authentication"] != "bearer-policy"
                or not route["project_scoped"]
                or not route["readiness_required"]
                or route["request_contract"]
                != "operations-api-mutation-request.schema.json"
                or route["response_contract"]
                != "operations-api-response.schema.json"
                or route["terminal_error"] is not None
                or route["success_status"] is None
                or not route["idempotency"]["required"]
                or route["idempotency"]["replay_strategy"]
                != "identity-proof-replay"
                or "worker-observer" in route["client_kinds"]
            ):
                raise ProtocolError(
                    f"Mutation route safety contract changed: {route_id}"
                )
            if not binding["runtime_fence_required"]:
                raise ProtocolError(
                    f"Mutation requires runtime fence: {route_id}"
                )
            expected_replay_source = (
                "source-record"
                if route_id
                in {
                    "work-room-input-create",
                    "decision-request-create",
                    "decision-create",
                    "decision-request-cancel",
                    "decision-request-expire",
                }
                else "application-mutation-identity-and-journal-result"
            )
            if binding["replay_proof_source"] != expected_replay_source:
                raise ProtocolError(
                    f"Mutation requires identity proof replay: {route_id}"
                )
            if not binding["mutation_scope_fields"]:
                raise ProtocolError(
                    f"Mutation requires scope fields: {route_id}"
                )
            if not any(
                argument["name"] == "runtime_fence"
                and argument["source"] == "server.runtime_fence"
                for argument in binding["service_arguments"]
            ):
                raise ProtocolError(
                    f"Mutation runtime fence argument missing: {route_id}"
                )
        else:
            if (
                route["idempotency"]["required"]
                or route["idempotency"]["replay_strategy"]
                != "not-applicable"
                or route["idempotency"]["canonical_identity_fields"]
            ):
                raise ProtocolError(
                    f"Read route cannot require idempotency: {route_id}"
                )
            if binding["payload_operation"] is not None:
                raise ProtocolError(
                    f"Read route cannot have mutation payload: {route_id}"
                )
            if binding["runtime_fence_required"]:
                raise ProtocolError(
                    f"Read route cannot require runtime fence: {route_id}"
                )
            if binding["replay_proof_source"] is not None:
                raise ProtocolError(
                    f"Read route cannot have replay proof: {route_id}"
                )
        if route["terminal_error"] is not None:
            raise ProtocolError(f"Unexpected terminal route: {route_id}")
        if binding["response_validator"] == "terminal-error":
            raise ProtocolError(
                f"Success route cannot use terminal validator: {route_id}"
            )

        service_type_name, method_name = route["service"].split(".", 1)
        if service_type_name == "OperationsApiHealth":
            continue
        if route["terminal_error"] is not None:
            continue
        method = getattr(SERVICE_TYPES[service_type_name], method_name)
        parameters = {
            name
            for name in inspect.signature(method).parameters
            if name not in {"self", "_"}
        }
        mapped = {
            argument["name"]
            for argument in binding["service_arguments"]
        }
        planned_arguments = set()
        if route["kind"] == "mutation":
            planned_arguments.add("runtime_fence")
        if route_id in {
            "run-lifecycle-apply",
            "run-checkpoint-reference",
            "run-artifact-reference",
        }:
            planned_arguments.add("expected_project_id")
        expected_arguments = parameters | planned_arguments
        if not mapped <= expected_arguments:
            raise ProtocolError(
                f"Binding contains unknown service argument: {route_id}"
            )
        if route["kind"] == "mutation" and mapped != expected_arguments:
            raise ProtocolError(
                f"Mutation binding does not cover service signature: {route_id}"
            )
    if registry["content_sha256"] != EXPECTED_ROUTE_REGISTRY_SHA256:
        raise ProtocolError("Canonical route registry digest changed.")
    if (
        binding_registry["content_sha256"]
        != EXPECTED_BINDING_REGISTRY_SHA256
    ):
        raise ProtocolError("Canonical binding registry digest changed.")


def _validate_readiness_semantics(
    document: dict,
    *,
    now: datetime,
    clock_tolerance_seconds: int = 1,
) -> None:
    if document["content_sha256"] != _content_sha256(document):
        raise ProtocolError("Readiness content_sha256 does not match.")
    projection_ids = [
        projection["projection_id"]
        for projection in document["projections"]
    ]
    if tuple(projection_ids) != EXPECTED_PROJECTIONS:
        raise ProtocolError("Readiness projections must be exact and ordered.")
    if len(projection_ids) != len(set(projection_ids)):
        raise ProtocolError("Readiness projection IDs must be unique.")
    if document["ready"]:
        for projection in document["projections"]:
            if (
                projection["status"] != "ready"
                or projection["lag"] != 0
                or projection["journal_sequence"]
                != document["journal"]["sequence"]
            ):
                raise ProtocolError(
                    "Ready state requires current healthy projections."
                )
    checked = _parse_time(document["checked_at"], "Readiness checked_at")
    tolerance = timedelta(seconds=clock_tolerance_seconds)
    if checked > now + tolerance:
        raise ProtocolError("Readiness checked_at is in the future.")
    attempted = _parse_time(
        document["last_verification_attempt_at"],
        "Readiness last_verification_attempt_at",
    )
    if attempted > checked:
        raise ProtocolError("Readiness verification attempt is in the future.")
    if document["last_full_verification_at"] is not None:
        completed = _parse_time(
            document["last_full_verification_at"],
            "Readiness last_full_verification_at",
        )
        if completed > checked:
            raise ProtocolError(
                "Readiness full verification is in the future."
            )
        if document["ready"]:
            maximum_age = min(
                document["maximum_verification_age_seconds"],
                15,
            )
            if now - completed > timedelta(
                seconds=maximum_age
            ) + tolerance:
                raise ProtocolError(
                    "Ready state requires a fresh full verification."
                )
    elif document["ready"]:
        raise ProtocolError(
            "Ready state requires a completed full verification."
        )
    if document["ready"]:
        maximum_age = min(
            document["maximum_verification_age_seconds"],
            15,
        )
        if now - attempted > timedelta(seconds=maximum_age) + tolerance:
            raise ProtocolError(
                "Ready state requires a fresh verification attempt."
            )
    journal = document["journal"]
    if journal["sequence"] == 0:
        if (
            journal["entry_id"] is not None
            or journal["entry_sha256"] is not None
        ):
            raise ProtocolError(
                "Empty journal readiness cannot identify a tip entry."
            )
    elif (
        journal["entry_id"] is None
        or journal["entry_sha256"] is None
    ):
        raise ProtocolError(
            "Non-empty journal readiness requires a complete tip."
        )


def _validate_liveness_semantics(
    document: dict,
    *,
    now: datetime,
    clock_tolerance_seconds: int = 1,
) -> None:
    if document["content_sha256"] != _content_sha256(document):
        raise ProtocolError("Liveness content_sha256 does not match.")
    checked = _parse_time(document["checked_at"], "Liveness checked_at")
    if abs(now - checked) > timedelta(seconds=clock_tolerance_seconds):
        raise ProtocolError(
            "Liveness checked_at is outside the current-time tolerance."
        )
    if document["uptime_seconds"] < 0:
        raise ProtocolError("Liveness uptime cannot be negative.")


def _validate_health_semantics(
    document: dict,
    *,
    readiness: dict,
) -> None:
    if document["content_sha256"] != _content_sha256(document):
        raise ProtocolError("Health content_sha256 does not match.")
    if (
        document["readiness_snapshot_sha256"]
        != readiness["content_sha256"]
        or document["readiness_checked_at"] != readiness["checked_at"]
    ):
        raise ProtocolError(
            "Health response does not bind the readiness snapshot."
        )
    expected_status = {
        "ready": "ready",
        "degraded": "degraded",
        "not-ready": "not-ready",
    }[readiness["status"]]
    if document["status"] != expected_status:
        raise ProtocolError(
            "Health status contradicts the readiness snapshot."
        )
    checked = _parse_time(document["checked_at"], "Health checked_at")
    for dependency in document["dependencies"]:
        observed = _parse_time(
            dependency["observed_at"],
            f"Health dependency {dependency['id']} observed_at",
        )
        if observed > checked + timedelta(seconds=1):
            raise ProtocolError(
                "Health dependency observation is in the future."
            )
        if (
            dependency["required"]
            and dependency["status"] in {"failed", "unimplemented"}
            and readiness["ready"]
        ):
            raise ProtocolError(
                "Required failed dependency contradicts readiness."
            )


def _validate_idempotency_semantics(document: dict) -> None:
    if document["content_sha256"] != _content_sha256(document):
        raise ProtocolError("Idempotency content_sha256 does not match.")
    accepted = _parse_time(
        document["accepted_at"],
        "Idempotency accepted_at",
    )
    updated = _parse_time(
        document["updated_at"],
        "Idempotency updated_at",
    )
    if accepted > updated:
        raise ProtocolError("Idempotency accepted_at follows updated_at.")
    started = None
    if document["service_started_at"] is not None:
        started = _parse_time(
            document["service_started_at"],
            "Idempotency service_started_at",
        )
        if not accepted <= started <= updated:
            raise ProtocolError(
                "Idempotency service start is not monotonic."
            )
    if document["completed_at"] is not None:
        completed = _parse_time(
            document["completed_at"],
            "Idempotency completed_at",
        )
        if started is None or not started <= completed <= updated:
            raise ProtocolError(
                "Idempotency completion is not monotonic."
            )


def _validate_error_semantics(
    document: dict,
    *,
    expected_project_id: str | None = None,
    now: datetime,
) -> None:
    error = document["error"]
    if error["code"] != "stale-cursor":
        return
    if error["reason_code"] == "stale-event-cursor":
        cursor = validate_factory_cursor_data(
            error["details"]["current_cursor"]
        )
        if expected_project_id is None:
            raise ProtocolError(
                "Stale event cursor validation requires project context."
            )
        expected_stream = f"factory-public-events-{expected_project_id}"
        if cursor["stream_id"] != expected_stream:
            raise ProtocolError(
                "Stale event cursor stream does not match the route project."
            )
        if _parse_time(cursor["issued_at"], "Cursor issued_at") > now:
            raise ProtocolError("Stale event cursor cannot be future-issued.")
    elif error["reason_code"] == "stale-projection-token":
        if error["details"] != {"restart_required": True}:
            raise ProtocolError(
                "Stale projection details must require an exact restart."
            )


def _validate_projection_record(
    record: dict,
    *,
    expected_project_id: str,
    expected_projection_id: str,
    expected_subject_id: str | None = None,
    trusted_projection_context: dict | None = None,
) -> None:
    expected_fields = (
        TIMELINE_ROW_FIELDS
        if expected_projection_id == "timeline"
        else (
            PROJECTION_AGGREGATE_BASE_FIELDS
            | PROJECTION_AGGREGATE_FIELDS_BY_ID[expected_projection_id]
        )
    )
    if set(record) != expected_fields:
        raise ProtocolError("Projection aggregate shape does not match.")
    if record["project_id"] != expected_project_id:
        raise ProtocolError("Projection aggregate project does not match.")
    if record["projection_id"] != expected_projection_id:
        raise ProtocolError("Projection aggregate domain does not match.")
    if (
        expected_subject_id is not None
        and record["subject_id"] != expected_subject_id
    ):
        raise ProtocolError("Projection aggregate subject does not match.")
    if record["content_sha256"] != _content_sha256(record):
        raise ProtocolError("Projection aggregate digest does not match.")
    if trusted_projection_context is None:
        raise ProtocolError("Projection store context is required.")
    if (
        trusted_projection_context.get("origin")
        != "sf-106-projection-store"
        or trusted_projection_context.get("content_sha256")
        != _content_sha256(trusted_projection_context)
        or trusted_projection_context.get("project_id")
        != expected_project_id
        or trusted_projection_context.get("projection_id")
        != expected_projection_id
    ):
        raise ProtocolError("Projection store context is invalid.")
    matching_rows = [
        row
        for row in trusted_projection_context["rows"]
        if (
            row["subject_id"] == record["subject_id"]
            and row["record_json"] == record
            and row["content_sha256"] == record["content_sha256"]
            and row["record_sha256"] == canonical_sha256(record)
        )
    ]
    if len(matching_rows) != 1:
        raise ProtocolError(
            "Projection aggregate is not store-verified."
        )


def _validate_mutation_result(
    data: dict,
    *,
    route_id: str,
    expected_project_id: str,
    expected_subject_id: str | None,
    expected_api_request_sha256: str | None,
    trusted_evidence: dict | None,
) -> None:
    if (
        expected_subject_id is None
        or expected_api_request_sha256 is None
        or trusted_evidence is None
    ):
        raise ProtocolError(
            "Mutation validation requires route and trusted store context."
        )
    expected_contract = MUTATION_RECORD_SCHEMA_BY_ROUTE[route_id]
    if data["record_contract"] != expected_contract:
        raise ProtocolError("Mutation record_contract does not match route.")
    record = data["record"]
    validate_against_schema(
        record,
        expected_contract,
        label=f"{route_id} mutation record",
        schema_root=OPERATIONS_ROOT,
    )
    record_sha256 = canonical_sha256(record)
    if data["record_sha256"] != record_sha256:
        raise ProtocolError("Mutation record_sha256 does not match.")
    record_project_id, scope_subject_id, source_subject_id = (
        _mutation_record_identity(
            route_id,
            record,
            trusted_project_id=trusted_evidence[
                "canonical_project_id"
            ],
        )
    )
    if (
        record_project_id != expected_project_id
        or record_project_id
        != trusted_evidence["canonical_project_id"]
        or scope_subject_id != expected_subject_id
        or scope_subject_id
        != trusted_evidence["canonical_scope_subject_id"]
    ):
        raise ProtocolError(
            "Mutation record identity does not match route scope."
        )
    source = data["source"]
    if set(source) != {
        "source_registry_id",
        "table",
        "key",
        "record_version",
        "record_sha256",
        "row_sha256",
    }:
        raise ProtocolError("Mutation source proof shape does not match.")
    if (
        source != trusted_evidence["primary_source"]
        or source["source_registry_id"]
        != MUTATION_PRIMARY_SOURCE_BY_ROUTE[route_id]
        or source["record_sha256"]
        != _mutation_source_record_sha256(route_id, record)
    ):
        raise ProtocolError("Mutation source proof does not bind the record.")
    journal = data["journal"]
    if set(journal) != {
        "api_request_sha256",
        "mutation_id",
        "mutation_identity_sha256",
        "coverage_branch_id",
        "generation",
        "first_sequence",
        "last_sequence",
        "entry_ids",
        "entry_sha256s",
        "batch_sha256",
    }:
        raise ProtocolError("Mutation journal proof shape does not match.")
    branch_prefix = MUTATION_BRANCH_PREFIX_BY_ROUTE[route_id]
    branch_id = journal["coverage_branch_id"]
    if (
        branch_id != branch_prefix
        and not branch_id.startswith(branch_prefix)
    ):
        raise ProtocolError("Mutation coverage branch does not match route.")
    coverage = _journal_coverage()
    if branch_id not in coverage:
        raise ProtocolError("Mutation coverage branch is not canonical.")
    branch = coverage[branch_id]
    trusted_entries = list(trusted_evidence["entries"])
    for entry in trusted_entries:
        validate_journal_entry_data(entry)
    if (
        journal["api_request_sha256"] != expected_api_request_sha256
        or journal["api_request_sha256"]
        != trusted_evidence["api_request_sha256"]
        or journal["mutation_id"] != trusted_evidence["mutation_id"]
        or journal["mutation_identity_sha256"]
        != trusted_evidence["mutation_identity_sha256"]
        or branch_id != trusted_evidence["coverage_branch_id"]
        or journal["generation"] != trusted_evidence["generation"]
    ):
        raise ProtocolError(
            "Mutation journal proof does not match trusted evidence."
        )
    observed_source_ids = [
        entry["source_record"]["source_registry_id"]
        for entry in trusted_entries
    ]
    _validate_coverage_source_ids(branch, observed_source_ids)
    for index, entry in enumerate(trusted_entries):
        if (
            entry["transaction_id"] != journal["mutation_id"]
            or entry["mutation_identity_sha256"]
            != journal["mutation_identity_sha256"]
            or entry["coverage_branch_id"] != branch_id
            or entry["generation"] != journal["generation"]
            or entry["transaction_position"] != index + 1
            or entry["transaction_fact_count"] != len(trusted_entries)
            or entry["project_id"] != expected_project_id
            or (
                index > 0
                and entry["previous_entry_sha256"]
                != trusted_entries[index - 1]["entry_sha256"]
            )
        ):
            raise ProtocolError(
                "Trusted mutation journal chain is inconsistent."
            )
    matching_sources = [
        entry["source_record"]
        for entry in trusted_entries
        if (
            entry["source_record"] == source
            and entry["subject_id"] == source_subject_id
        )
    ]
    if len(matching_sources) != 1:
        raise ProtocolError(
            "Mutation primary source is not uniquely journal-bound."
        )
    expected_entry_ids = [
        entry["entry_id"] for entry in trusted_entries
    ]
    expected_entry_sha256s = [
        entry["entry_sha256"] for entry in trusted_entries
    ]
    expected_batch_sha256 = canonical_sha256(
        expected_entry_sha256s
    )
    if (
        journal["generation"] < 1
        or journal["first_sequence"] < 1
        or journal["last_sequence"] < journal["first_sequence"]
        or journal["first_sequence"] != trusted_entries[0]["sequence"]
        or journal["last_sequence"] != trusted_entries[-1]["sequence"]
        or journal["entry_ids"] != expected_entry_ids
        or journal["entry_sha256s"] != expected_entry_sha256s
        or journal["batch_sha256"] != expected_batch_sha256
    ):
        raise ProtocolError(
            "Mutation journal proof is not the trusted canonical batch."
        )
    proof = {
        "record_contract": expected_contract,
        "record_sha256": record_sha256,
        "source": source,
        "journal": journal,
    }
    if data["result_proof_sha256"] != canonical_sha256(proof):
        raise ProtocolError("Mutation result proof digest does not match.")

    if route_id.startswith("product-"):
        validate_factory_entity_data(record["product_factory"])
    elif route_id == "signal-ingest":
        validate_factory_entity_data(record["signal"])
    elif route_id.startswith("work-item-"):
        validate_factory_entity_data(record["work_item"])
        validate_factory_entity_data(record["current_revision"])
    elif route_id == "transition-apply":
        validate_factory_entity_data(record["transition"])
        validate_against_schema(
            record["command"],
            "work-item-transition-command.schema.json",
            label="transition mutation command",
            schema_root=OPERATIONS_ROOT,
        )
    elif route_id.startswith("dispatch-"):
        validate_dispatch_record(record)
    elif record.get("content_sha256") != _content_sha256(record):
        raise ProtocolError("Run mutation record content digest is invalid.")
def _validate_response_semantics(
    response: dict,
    route_id: str,
    binding: dict,
    *,
    expected_project_id: str = "example-agentic-product",
    expected_subject_id: str | None = None,
    expected_api_request_sha256: str | None = None,
    trusted_mutation_evidence: dict | None = None,
    response_scope: dict | None = None,
    trusted_projection_context: dict | None = None,
) -> None:
    validate_against_schema(
        response,
        "operations-api-response.schema.json",
        label=f"{route_id} response",
        schema_root=OPERATIONS_ROOT,
    )
    validator = binding["response_validator"]
    if validator in DIRECT_RESPONSE_VALIDATORS:
        raise ProtocolError(
            f"Direct response validator cannot use success envelope: {route_id}"
        )
    if validator == "terminal-error":
        raise ProtocolError(
            f"Terminal route cannot emit a success response: {route_id}"
        )
    if response["route_id"] != route_id:
        raise ProtocolError("Success response route_id does not match.")
    if response["data_contract"] != validator:
        raise ProtocolError("Success response data_contract does not match.")
    if response["data_sha256"] != canonical_sha256(response["data"]):
        raise ProtocolError("Success response data_sha256 does not match.")
    reject_secret_material(response, path="API response")
    expected_fields = RESPONSE_DATA_FIELDS.get(validator)
    if expected_fields is None:
        raise ProtocolError(f"Unknown response validator: {validator}")
    if validator == "projection-record":
        projection_id = EXPECTED_RESPONSE_SCOPES[route_id][2]
        expected_fields = (
            PROJECTION_AGGREGATE_BASE_FIELDS
            | PROJECTION_AGGREGATE_FIELDS_BY_ID[projection_id]
        )
    if set(response["data"]) != expected_fields:
        raise ProtocolError(
            f"Success response data shape does not match: {validator}"
        )
    data = response["data"]
    if validator in {
        "projection-page",
        "projection-record",
        "public-event-page",
        "public-event",
    }:
        if (
            response_scope is None
            or response_scope["route_id"] != route_id
            or response_scope["project_source"] != "path.project_id"
        ):
            raise ProtocolError(
                "Response scope is missing or does not match route."
            )
        if (
            response_scope["subject_source"] is not None
            and expected_subject_id is None
        ):
            raise ProtocolError(
                "Scoped response requires the resolved route subject."
            )
        if (
            validator in {"projection-page", "projection-record"}
            and trusted_projection_context is None
        ):
            raise ProtocolError(
                "Projection response requires trusted store context."
            )
    if validator == "capability-status":
        validate_against_schema(
            data,
            "factory-capability-status.schema.json",
            label="capability status response",
            schema_root=OPERATIONS_ROOT,
        )
        if set(data["capabilities"]) != {
            "decisions",
            "events",
            "projections",
        }:
            raise ProtocolError("Capability status keys are not exact.")
    elif validator == "owner-portfolio-snapshot":
        validate_owner_portfolio_snapshot(copy.deepcopy(data))
    elif validator == "work-room-snapshot":
        validate_work_room_snapshot(copy.deepcopy(data))
    elif validator == "work-room-input-result":
        validate_work_room_input_result(copy.deepcopy(data))
    elif validator == "audit-replay-snapshot":
        validate_audit_replay_snapshot(copy.deepcopy(data))
    elif validator == "owner-metrics-snapshot":
        validate_owner_metrics_snapshot(copy.deepcopy(data))
    elif validator == "owner-decision-page":
        validate_owner_decision_page(copy.deepcopy(data))
    elif validator == "owner-decision-state":
        validate_owner_decision_state(copy.deepcopy(data))
    elif validator == "owner-decision":
        validate_owner_decision(copy.deepcopy(data))
    elif validator == "owner-decision-mutation-result":
        validate_owner_decision_mutation_result(copy.deepcopy(data))
    elif validator == "projection-page":
        validate_against_schema(
            data,
            "projection-query-result.schema.json",
            label="projection page response",
            schema_root=OPERATIONS_ROOT,
        )
        if route_id in PROJECTION_HISTORY_ROUTES:
            if any(
                set(item) != PROJECTION_HISTORY_ITEM_FIELDS
                for item in data["items"]
            ):
                raise ProtocolError(
                    "Projection history item shape does not match."
                )
            rows = trusted_projection_context["rows"]
            if len(rows) != 1:
                raise ProtocolError(
                    "Projection history requires one store row."
                )
            history = rows[0]["record_json"]["history"]
            if data["items"] != history[: len(data["items"])]:
                raise ProtocolError(
                    "Projection history is not an exact store slice."
                )
        else:
            for item in data["items"]:
                _validate_projection_record(
                    item,
                    expected_project_id=expected_project_id,
                    expected_projection_id=response_scope["projection_id"],
                    expected_subject_id=(
                        expected_subject_id
                        if response_scope["subject_source"] is not None
                        else None
                    ),
                    trusted_projection_context=trusted_projection_context,
                )
        if (
            data["projection"]["generation"]
            != trusted_projection_context["generation"]
        ):
            raise ProtocolError(
                "Projection page generation is not store-verified."
            )
    elif validator == "projection-record":
        _validate_projection_record(
            data,
            expected_project_id=expected_project_id,
            expected_projection_id=response_scope["projection_id"],
            expected_subject_id=expected_subject_id,
            trusted_projection_context=trusted_projection_context,
        )
    elif validator == "public-event-page":
        validate_factory_cursor_data(data["cursor"])
        if (
            data["project_id"] != expected_project_id
            or data["stream_id"]
            != f"factory-public-events-{expected_project_id}"
            or data["cursor"]["stream_id"] != data["stream_id"]
        ):
            raise ProtocolError("Public event page identity does not match.")
        for event in data["items"]:
            validate_factory_event_data(event)
            if event["correlations"]["project_id"] != expected_project_id:
                raise ProtocolError("Public event project does not match.")
    elif validator == "public-event":
        validate_factory_event_data(data)
        if (
            data["correlations"]["project_id"] != expected_project_id
            or (
                expected_subject_id is not None
                and data["event_id"] != expected_subject_id
            )
        ):
            raise ProtocolError("Public event identity does not match.")
    elif validator.endswith("-mutation-result"):
        _validate_mutation_result(
            data,
            route_id=route_id,
            expected_project_id=expected_project_id,
            expected_subject_id=expected_subject_id,
            expected_api_request_sha256=expected_api_request_sha256,
            trusted_evidence=trusted_mutation_evidence,
        )
    elif validator == "projection-status":
        if (
            data["projection"]["journal_sequence"]
            != data["journal"]["sequence"]
        ):
            raise ProtocolError("Projection status is behind the journal.")
    elif validator == "journal-status":
        if data["integrity"]["status"] != "verified":
            raise ProtocolError("Journal status is not verified.")


def _validate_runtime_semantics(
    document: dict,
    *,
    now: datetime,
) -> None:
    if document["content_sha256"] != _content_sha256(document):
        raise ProtocolError("Runtime content_sha256 does not match.")
    started = _parse_time(document["started_at"], "Runtime started_at")
    heartbeat = _parse_time(
        document["heartbeat_at"],
        "Runtime heartbeat_at",
    )
    expires = _parse_time(
        document["lease_expires_at"],
        "Runtime lease_expires_at",
    )
    if not started <= heartbeat < expires:
        raise ProtocolError("Runtime timestamps are not monotonic.")
    if heartbeat > now:
        raise ProtocolError("Runtime heartbeat is in the future.")
    if document["status"] in {"starting", "ready", "draining"}:
        if expires - heartbeat != timedelta(seconds=5):
            raise ProtocolError(
                "Active runtime lease duration must be exactly 5 seconds."
            )
        if not now < expires:
            raise ProtocolError("Active runtime lease is expired.")
    elif expires > now:
        raise ProtocolError(
            "Expired or stopped runtime cannot retain a future lease."
        )


class OperationsApiDesignFoundationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = _route_registry()
        self.binding_registry = _binding_registry()
        self.routes = self.registry["routes"]
        self.by_id = {route["id"]: route for route in self.routes}
        self.bindings = {
            binding["route_id"]: binding
            for binding in self.binding_registry["bindings"]
        }
        self.response_scopes = {
            scope["route_id"]: scope
            for scope in self.binding_registry["response_scopes"]
        }

    def test_route_and_binding_registries_are_exact_and_digest_bound(self) -> None:
        validate_against_schema(
            self.registry,
            "operations-api-route-registry.schema.json",
            label="operations API route registry",
            schema_root=OPERATIONS_ROOT,
        )
        validate_against_schema(
            self.binding_registry,
            "operations-api-binding-registry.schema.json",
            label="operations API binding registry",
            schema_root=OPERATIONS_ROOT,
        )
        _validate_binding_semantics(self.registry, self.binding_registry)
        self.assertEqual(len(self.routes), 57)
        self.assertEqual(len(self.bindings), 57)
        self.assertEqual(len(self.response_scopes), 19)
        self.assertEqual(
            sum(route["kind"] == "mutation" for route in self.routes),
            21,
        )
        self.assertEqual(
            len({(route["method"], route["path"]) for route in self.routes}),
            57,
        )

        changed = copy.deepcopy(self.binding_registry)
        changed["bindings"][0]["response_validator"] = "readiness"
        with self.assertRaisesRegex(ProtocolError, "content_sha256"):
            _validate_binding_semantics(self.registry, changed)

    def test_closed_route_matrix_rejects_semantic_drift(self) -> None:
        cases = {}

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        next(
            route
            for route in registry["routes"]
            if route["id"] == "product-update"
        )["authentication"] = "none"
        cases["mutation authentication"] = (
            *_redigest_registries(registry, bindings),
            "Closed route matrix mismatch",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        route = next(
            item
            for item in registry["routes"]
            if item["id"] == "product-update"
        )
        route["idempotency"]["required"] = False
        cases["mutation idempotency"] = (
            *_redigest_registries(registry, bindings),
            "Mutation route safety contract",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        route = next(
            item
            for item in registry["routes"]
            if item["id"] == "decision-get"
        )
        route["readiness_required"] = False
        cases["decision readiness"] = (
            *_redigest_registries(registry, bindings),
            "Closed route matrix mismatch",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "product-get"
        )
        binding["response_validator"] = "readiness"
        cases["response validator"] = (
            *_redigest_registries(registry, bindings),
            "Closed response validator mismatch",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "transition-apply"
        )
        binding["member_contracts"][0]["source"] = (
            "body.payload.command.missing"
        )
        cases["member source"] = (
            *_redigest_registries(registry, bindings),
            "member source does not exist",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "product-register"
        )
        binding["equality_bindings"].append(
            "path.project_id=body.payload.configuration.missing"
        )
        cases["equality source"] = (
            *_redigest_registries(registry, bindings),
            "equality source does not exist",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "product-register"
        )
        binding["mutation_scope_fields"].append(
            "body.payload.configuration.missing"
        )
        cases["scope source"] = (
            *_redigest_registries(registry, bindings),
            "mutation scope source does not exist",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "product-get"
        )
        binding["query_parameters"] = ["status"]
        cases["query parameters"] = (
            *_redigest_registries(registry, bindings),
            "Closed query parameter mismatch",
        )

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        scope = next(
            item
            for item in bindings["response_scopes"]
            if item["route_id"] == "product-get"
        )
        scope["projection_id"] = "signals"
        cases["response scope"] = (
            *_redigest_registries(registry, bindings),
            "Response scope changed",
        )

        for label, (registry, bindings, message) in cases.items():
            with self.subTest(case=label):
                with self.assertRaisesRegex(ProtocolError, message):
                    _validate_binding_semantics(registry, bindings)

    def test_full_registry_pins_reject_valid_but_wrong_drift(self) -> None:
        probes = []

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        route = next(
            item
            for item in registry["routes"]
            if item["id"] == "dispatch-submit"
        )
        route["client_kinds"].append("owner-ui")
        route["roles"].append("product-owner")
        probes.append(_redigest_registries(registry, bindings))

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "product-get"
        )
        binding["service_arguments"] = [
            item
            for item in binding["service_arguments"]
            if item["name"] != "project_id"
        ]
        probes.append(_redigest_registries(registry, bindings))

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "products-list"
        )
        binding["service_arguments"] = [
            item
            for item in binding["service_arguments"]
            if item["name"] != "status"
        ]
        probes.append(_redigest_registries(registry, bindings))

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "transition-apply"
        )
        next(
            item
            for item in binding["service_arguments"]
            if item["name"] == "command"
        )["source"] = "body.payload.operation"
        binding["equality_bindings"] = [
            item
            for item in binding["equality_bindings"]
            if "actor_identity_id" not in item
        ]
        probes.append(_redigest_registries(registry, bindings))

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "run-lifecycle-apply"
        )
        next(
            item
            for item in binding["service_arguments"]
            if item["name"] == "expected_project_id"
        )["source"] = "body.project_id"
        probes.append(_redigest_registries(registry, bindings))

        registry = copy.deepcopy(self.registry)
        bindings = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in bindings["bindings"]
            if item["route_id"] == "work-item-update"
        )
        binding["mutation_scope_fields"] = ["path.project_id"]
        probes.append(_redigest_registries(registry, bindings))

        for index, (registry, bindings) in enumerate(probes):
            with self.subTest(probe=index):
                with self.assertRaisesRegex(
                    ProtocolError,
                    "Canonical .* registry digest changed",
                ):
                    _validate_binding_semantics(registry, bindings)

    def test_auth_project_scope_long_poll_and_decision_routes_are_exact(self) -> None:
        health_routes = {
            route["path"]: route
            for route in self.routes
            if route["path"].startswith("/health/")
        }
        self.assertEqual(set(health_routes), {"/health/live", "/health/ready"})
        for route in health_routes.values():
            self.assertEqual(route["authentication"], "none")
            self.assertEqual(route["client_kinds"], [])
            self.assertEqual(route["roles"], [])

        for route in self.routes:
            if route["path"].startswith("/v1/"):
                self.assertEqual(route["authentication"], "bearer-policy")
                self.assertTrue(route["client_kinds"])
            if route["project_scoped"]:
                self.assertTrue(route["roles"])
            else:
                self.assertEqual(route["roles"], [])
            self.assertEqual(
                route["project_scoped"],
                "{project_id}" in route["path"],
                route["id"],
            )

        long_poll_routes = [
            route
            for route in self.routes
            if route["long_poll"]["enabled"]
        ]
        self.assertEqual(
            [route["id"] for route in long_poll_routes],
            ["events-list"],
        )
        self.assertEqual(
            long_poll_routes[0]["long_poll"]["maximum_wait_seconds"],
            30,
        )

        for route_id in ("decisions-list", "decision-get"):
            route = self.by_id[route_id]
            self.assertEqual(route["success_status"], 200)
            self.assertIsNone(route["terminal_error"])
            self.assertEqual(
                route["response_contract"],
                "operations-api-response.schema.json",
            )
            self.assertTrue(route["readiness_required"])
            self.assertEqual(
                self.bindings[route_id]["response_validator"],
                (
                    "owner-decision-page"
                    if route_id == "decisions-list"
                    else "owner-decision"
                ),
            )
        self.assertFalse(self.by_id["capabilities-get"]["readiness_required"])

    def test_mutation_bindings_are_fenced_scoped_and_identity_replay_safe(
        self,
    ) -> None:
        mutations = [
            route for route in self.routes if route["kind"] == "mutation"
        ]
        for route in mutations:
            binding = self.bindings[route["id"]]
            self.assertTrue(route["project_scoped"])
            self.assertTrue(route["readiness_required"])
            self.assertTrue(route["idempotency"]["required"])
            self.assertEqual(
                route["idempotency"]["replay_strategy"],
                "identity-proof-replay",
            )
            self.assertNotIn("worker-observer", route["client_kinds"])
            self.assertTrue(binding["runtime_fence_required"])
            self.assertEqual(binding["payload_operation"], route["id"])
            self.assertTrue(binding["mutation_scope_fields"])
            self.assertIn(
                {
                    "name": "runtime_fence",
                    "source": "server.runtime_fence",
                },
                binding["service_arguments"],
            )

        cancel = self.by_id["dispatch-cancel"]
        self.assertEqual(cancel["client_kinds"], ["owner-ui", "operator"])
        self.assertEqual(cancel["roles"], ["human-owner", "product-owner"])
        self.assertIn(
            "body.payload.lease_generation",
            cancel["idempotency"]["canonical_identity_fields"],
        )

        changed = copy.deepcopy(self.binding_registry)
        binding = next(
            item
            for item in changed["bindings"]
            if item["route_id"] == "product-update"
        )
        binding["service_arguments"] = [
            argument
            for argument in binding["service_arguments"]
            if argument["name"] != "runtime_fence"
        ]
        changed["content_sha256"] = _content_sha256(changed)
        changed_registry = copy.deepcopy(self.registry)
        changed_registry["binding_registry_sha256"] = changed[
            "content_sha256"
        ]
        changed_registry["content_sha256"] = _content_sha256(
            changed_registry
        )
        with self.assertRaisesRegex(ProtocolError, "runtime fence"):
            _validate_binding_semantics(changed_registry, changed)

    def test_reconciliation_identity_and_historical_sources_are_exact(
        self,
    ) -> None:
        coverage = _journal_coverage()
        self.assertEqual(
            set(RECONCILIATION_IDENTITY_FIELDS_BY_ROUTE),
            set(MUTATION_RECORD_SCHEMA_BY_ROUTE),
        )
        for route_id, expected_fields in (
            RECONCILIATION_IDENTITY_FIELDS_BY_ROUTE.items()
        ):
            branch_id = MUTATION_FIXTURE_BRANCH_BY_ROUTE[route_id]
            branch = coverage[branch_id]
            with self.subTest(route=route_id):
                self.assertEqual(
                    tuple(branch["identity_fields"]),
                    expected_fields,
                )
                self.assertIn(
                    MUTATION_PRIMARY_SOURCE_BY_ROUTE[route_id],
                    branch["source_ids"],
                )
        for route_id, reference_source in (
            ("run-checkpoint-reference", "run-checkpoint-references"),
            ("run-artifact-reference", "run-artifact-references"),
        ):
            branch = coverage[MUTATION_FIXTURE_BRANCH_BY_ROUTE[route_id]]
            self.assertEqual(
                MUTATION_RECORD_SCHEMA_BY_ROUTE[route_id],
                "run-lifecycle-command-result.schema.json",
            )
            self.assertEqual(
                MUTATION_PRIMARY_SOURCE_BY_ROUTE[route_id],
                "run-lifecycle-results",
            )
            self.assertIn(reference_source, branch["source_ids"])

    def test_routes_reference_public_services_not_internal_controls(self) -> None:
        for route in self.routes:
            service_type_name, method_name = route["service"].split(".", 1)
            if service_type_name == "OperationsApiHealth":
                self.assertIn(
                    method_name,
                    {"detail", "live", "readiness", "ready"},
                )
                continue
            self.assertIn(service_type_name, SERVICE_TYPES, route["id"])
            self.assertTrue(
                hasattr(SERVICE_TYPES[service_type_name], method_name),
                route["service"],
            )
            self.assertNotIn(method_name, FORBIDDEN_SERVICE_METHODS)

        exposed = {route["service"] for route in self.routes}
        self.assertFalse(
            any(
                service.endswith("." + method_name)
                for service in exposed
                for method_name in FORBIDDEN_SERVICE_METHODS
            )
        )

    def test_auth_policy_is_current_unique_role_free_and_route_compatible(
        self,
    ) -> None:
        policy = _auth_policy(self.routes)
        validate_against_schema(
            policy,
            "operations-api-auth-policy.schema.json",
            label="operations API authentication policy",
            schema_root=OPERATIONS_ROOT,
        )
        _validate_auth_policy_semantics(policy, self.routes, now=NOW)
        self.assertNotIn("roles", policy["clients"][0])

        for field in ("client_id", "identity_id", "bearer_token_sha256"):
            duplicate = copy.deepcopy(policy)
            second = copy.deepcopy(duplicate["clients"][0])
            second["client_id"] = "second-client"
            second["identity_id"] = "human-owner:second"
            second["bearer_token_sha256"] = "2" * 64
            second[field] = duplicate["clients"][0][field]
            duplicate["clients"].append(second)
            duplicate["content_sha256"] = _content_sha256(duplicate)
            with self.subTest(field=field):
                with self.assertRaisesRegex(ProtocolError, "unique"):
                    _validate_auth_policy_semantics(
                        duplicate,
                        self.routes,
                        now=NOW,
                    )

        expired = copy.deepcopy(policy)
        expired["expires_at"] = "2026-08-11T11:59:59Z"
        expired["content_sha256"] = _content_sha256(expired)
        with self.assertRaisesRegex(ProtocolError, "not current"):
            _validate_auth_policy_semantics(expired, self.routes, now=NOW)

        wrong_kind = copy.deepcopy(policy)
        wrong_kind["clients"][0]["kind"] = "worker-observer"
        wrong_kind["content_sha256"] = _content_sha256(wrong_kind)
        with self.assertRaisesRegex(ProtocolError, "not eligible"):
            _validate_auth_policy_semantics(
                wrong_kind,
                self.routes,
                now=NOW,
            )

        invalid_global = copy.deepcopy(policy)
        invalid_global["clients"][0]["global_route_ids"] = [
            "products-list"
        ]
        invalid_global["content_sha256"] = _content_sha256(invalid_global)
        with self.assertRaisesRegex(ProtocolError, "project scoped"):
            _validate_auth_policy_semantics(
                invalid_global,
                self.routes,
                now=NOW,
            )

        raw_secret = copy.deepcopy(policy)
        raw_secret["clients"][0]["bearer_token"] = "secret-value"
        with self.assertRaisesRegex(ProtocolError, "Additional properties"):
            validate_against_schema(
                raw_secret,
                "operations-api-auth-policy.schema.json",
                label="operations API authentication policy",
                schema_root=OPERATIONS_ROOT,
            )

        for identity_id in ("*", "owner identity"):
            invalid_identity = copy.deepcopy(policy)
            invalid_identity["clients"][0]["identity_id"] = identity_id
            invalid_identity["content_sha256"] = _content_sha256(
                invalid_identity
            )
            with self.subTest(identity_id=identity_id):
                with self.assertRaises(ProtocolError):
                    validate_against_schema(
                        invalid_identity,
                        "operations-api-auth-policy.schema.json",
                        label="invalid auth identity",
                        schema_root=OPERATIONS_ROOT,
                    )

        secret_identity = copy.deepcopy(policy)
        secret_identity["clients"][0]["identity_id"] = (
            "service:ghp_1234567890abcdef"
        )
        secret_identity["content_sha256"] = _content_sha256(
            secret_identity
        )
        validate_against_schema(
            secret_identity,
            "operations-api-auth-policy.schema.json",
            label="secret-shaped auth identity",
            schema_root=OPERATIONS_ROOT,
        )
        with self.assertRaisesRegex(ProtocolError, "secret"):
            _validate_auth_policy_semantics(
                secret_identity,
                self.routes,
                now=NOW,
            )

    def test_all_mutation_payloads_are_discriminated_and_strict(
        self,
    ) -> None:
        payloads = _mutation_payloads()
        self.assertEqual(set(payloads), {
            route["id"]
            for route in self.routes
            if route["kind"] == "mutation"
        })
        for operation, payload in payloads.items():
            with self.subTest(operation=operation):
                validate_against_schema(
                    payload,
                    "operations-api-mutation-payload.schema.json",
                    label=operation,
                    schema_root=OPERATIONS_ROOT,
                )
                invalid = copy.deepcopy(payload)
                invalid["unexpected"] = True
                with self.assertRaises(ProtocolError):
                    validate_against_schema(
                        invalid,
                        "operations-api-mutation-payload.schema.json",
                        label=operation,
                        schema_root=OPERATIONS_ROOT,
                    )

        mismatched = _mutation_request("product-activate")
        mismatched["payload"]["operation"] = "product-pause"
        mismatched["payload_sha256"] = canonical_sha256(
            mismatched["payload"]
        )
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                mismatched,
                "operations-api-mutation-request.schema.json",
                label="mismatched operation request",
                schema_root=OPERATIONS_ROOT,
            )

    def test_public_document_fixtures_and_state_invariants(self) -> None:
        response = _response_fixture(
            "product-activate",
            "product-mutation-result",
        )
        readiness = _readiness()
        health = _health(readiness)
        fixtures = {
            "operations-api-mutation-request.schema.json": (
                _mutation_request()
            ),
            "operations-api-response.schema.json": response,
            "operations-api-liveness.schema.json": _liveness(),
            "operations-api-health.schema.json": health,
            "operations-api-readiness.schema.json": readiness,
            "operations-api-idempotency-record.schema.json": (
                _idempotency_record()
            ),
            "operations-api-runtime-record.schema.json": _runtime_record(),
        }
        for schema_name, fixture in fixtures.items():
            with self.subTest(schema=schema_name):
                validate_against_schema(
                    fixture,
                    schema_name,
                    label=schema_name,
                    schema_root=OPERATIONS_ROOT,
                )

        _validate_readiness_semantics(
            fixtures["operations-api-readiness.schema.json"],
            now=NOW,
        )
        _validate_liveness_semantics(
            fixtures["operations-api-liveness.schema.json"],
            now=NOW,
        )
        _validate_health_semantics(health, readiness=readiness)
        _validate_runtime_semantics(
            fixtures["operations-api-runtime-record.schema.json"],
            now=NOW,
        )
        _validate_response_semantics(
            response,
            "product-activate",
            self.bindings["product-activate"],
            **_mutation_validation_kwargs(
                "product-activate",
                response,
            ),
        )

        false_ready = _readiness()
        false_ready["status"] = "not-ready"
        false_ready["content_sha256"] = _content_sha256(false_ready)
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                false_ready,
                "operations-api-readiness.schema.json",
                label="false readiness",
                schema_root=OPERATIONS_ROOT,
            )

        duplicate_projection = _readiness()
        duplicate_projection["projections"][-1]["projection_id"] = "runs"
        duplicate_projection["content_sha256"] = _content_sha256(
            duplicate_projection
        )
        with self.assertRaisesRegex(ProtocolError, "exact and ordered"):
            _validate_readiness_semantics(
                duplicate_projection,
                now=NOW,
            )

        stale_readiness = _readiness()
        stale_readiness["last_full_verification_at"] = (
            "2026-08-11T10:00:00Z"
        )
        stale_readiness["last_verification_attempt_at"] = (
            "2026-08-11T10:00:00Z"
        )
        stale_readiness["content_sha256"] = _content_sha256(
            stale_readiness
        )
        with self.assertRaisesRegex(ProtocolError, "fresh"):
            _validate_readiness_semantics(stale_readiness, now=NOW)

        future_readiness = _readiness()
        future_readiness["checked_at"] = "2027-08-11T12:00:00Z"
        future_readiness["last_full_verification_at"] = (
            "2027-08-11T12:00:00Z"
        )
        future_readiness["last_verification_attempt_at"] = (
            "2027-08-11T12:00:00Z"
        )
        future_readiness["content_sha256"] = _content_sha256(
            future_readiness
        )
        with self.assertRaisesRegex(ProtocolError, "future"):
            _validate_readiness_semantics(future_readiness, now=NOW)

        incomplete_tip = _readiness()
        incomplete_tip["journal"]["sequence"] = 1
        for projection in incomplete_tip["projections"]:
            projection["journal_sequence"] = 1
        incomplete_tip["content_sha256"] = _content_sha256(incomplete_tip)
        with self.assertRaisesRegex(ProtocolError, "complete tip"):
            _validate_readiness_semantics(incomplete_tip, now=NOW)

        wrong_health = copy.deepcopy(health)
        wrong_health["readiness_snapshot_sha256"] = "f" * 64
        wrong_health["content_sha256"] = _content_sha256(wrong_health)
        with self.assertRaisesRegex(ProtocolError, "readiness snapshot"):
            _validate_health_semantics(
                wrong_health,
                readiness=readiness,
            )

        future_liveness = _liveness()
        future_liveness["checked_at"] = "2027-08-11T12:00:00Z"
        future_liveness["content_sha256"] = _content_sha256(
            future_liveness
        )
        with self.assertRaisesRegex(ProtocolError, "tolerance"):
            _validate_liveness_semantics(future_liveness, now=NOW)

        stale_liveness = _liveness()
        stale_liveness["checked_at"] = "2025-08-11T12:00:00Z"
        stale_liveness["content_sha256"] = _content_sha256(
            stale_liveness
        )
        with self.assertRaisesRegex(ProtocolError, "tolerance"):
            _validate_liveness_semantics(stale_liveness, now=NOW)

        wrong_liveness_digest = _liveness()
        wrong_liveness_digest["content_sha256"] = "f" * 64
        with self.assertRaisesRegex(ProtocolError, "content_sha256"):
            _validate_liveness_semantics(
                wrong_liveness_digest,
                now=NOW,
            )

        contradictory_health = copy.deepcopy(health)
        contradictory_health["status"] = "degraded"
        contradictory_health["content_sha256"] = _content_sha256(
            contradictory_health
        )
        with self.assertRaisesRegex(ProtocolError, "contradicts"):
            _validate_health_semantics(
                contradictory_health,
                readiness=readiness,
            )

        expired_runtime = _runtime_record()
        expired_runtime["started_at"] = "2026-08-11T11:59:50Z"
        expired_runtime["heartbeat_at"] = "2026-08-11T11:59:54Z"
        expired_runtime["lease_expires_at"] = "2026-08-11T11:59:59Z"
        expired_runtime["content_sha256"] = _content_sha256(expired_runtime)
        with self.assertRaisesRegex(ProtocolError, "expired"):
            _validate_runtime_semantics(expired_runtime, now=NOW)

        future_heartbeat = _runtime_record()
        future_heartbeat["heartbeat_at"] = "2026-08-11T12:00:01Z"
        future_heartbeat["lease_expires_at"] = "2026-08-11T12:00:06Z"
        future_heartbeat["content_sha256"] = _content_sha256(
            future_heartbeat
        )
        with self.assertRaisesRegex(ProtocolError, "future"):
            _validate_runtime_semantics(future_heartbeat, now=NOW)

        wrong_duration = _runtime_record()
        wrong_duration["lease_expires_at"] = "2026-08-11T12:00:06Z"
        wrong_duration["content_sha256"] = _content_sha256(wrong_duration)
        with self.assertRaisesRegex(ProtocolError, "exactly 5 seconds"):
            _validate_runtime_semantics(wrong_duration, now=NOW)

        stopped_with_future_lease = _runtime_record("stopped")
        stopped_with_future_lease["content_sha256"] = _content_sha256(
            stopped_with_future_lease
        )
        with self.assertRaisesRegex(ProtocolError, "future lease"):
            _validate_runtime_semantics(
                stopped_with_future_lease,
                now=NOW,
            )

    def test_success_response_validators_are_closed_and_digest_bound(
        self,
    ) -> None:
        routes_by_validator = {}
        for route in self.routes:
            validator = self.bindings[route["id"]]["response_validator"]
            if (
                validator not in DIRECT_RESPONSE_VALIDATORS
                and validator != "terminal-error"
            ):
                routes_by_validator.setdefault(validator, route["id"])
        self.assertEqual(
            set(routes_by_validator),
            set(RESPONSE_DATA_FIELDS),
        )

        for validator, route_id in routes_by_validator.items():
            binding = self.bindings[route_id]
            response = _response_fixture(route_id, validator)
            expected_subject_id = None
            semantic_kwargs = {}
            if (
                validator.endswith("-mutation-result")
                and validator != "owner-decision-mutation-result"
            ):
                semantic_kwargs = _mutation_validation_kwargs(
                    route_id,
                    response,
                )
            elif validator in {"projection-page", "projection-record"}:
                semantic_kwargs = _projection_validation_kwargs(
                    route_id,
                    self.response_scopes[route_id],
                )
            elif validator in {"public-event-page", "public-event"}:
                semantic_kwargs = {
                    "expected_subject_id": (
                        FIXTURE_SUBJECT_BY_ROUTE.get(route_id)
                    ),
                    "response_scope": self.response_scopes[route_id],
                }
            if not semantic_kwargs:
                semantic_kwargs["expected_subject_id"] = (
                    expected_subject_id
                )
            with self.subTest(validator=validator):
                _validate_response_semantics(
                    response,
                    route_id,
                    binding,
                    **semantic_kwargs,
                )

                wrong_contract = copy.deepcopy(response)
                wrong_contract["data_contract"] = "projection-record"
                if validator == "projection-record":
                    wrong_contract["data_contract"] = "projection-page"
                with self.assertRaisesRegex(
                    ProtocolError,
                    "data_contract",
                ):
                    _validate_response_semantics(
                        wrong_contract,
                        route_id,
                        binding,
                        **semantic_kwargs,
                    )

                wrong_digest = copy.deepcopy(response)
                wrong_digest["data_sha256"] = "f" * 64
                with self.assertRaisesRegex(
                    ProtocolError,
                    "data_sha256",
                ):
                    _validate_response_semantics(
                        wrong_digest,
                        route_id,
                        binding,
                        **semantic_kwargs,
                    )

                wrong_route = copy.deepcopy(response)
                wrong_route["route_id"] = "different-route"
                with self.assertRaisesRegex(ProtocolError, "route_id"):
                    _validate_response_semantics(
                        wrong_route,
                        route_id,
                        binding,
                        **semantic_kwargs,
                    )

                wrong_shape = copy.deepcopy(response)
                wrong_shape["data"].pop(next(iter(wrong_shape["data"])))
                wrong_shape["data_sha256"] = canonical_sha256(
                    wrong_shape["data"]
                )
                with self.assertRaisesRegex(
                    ProtocolError,
                    "data shape",
                ):
                    _validate_response_semantics(
                        wrong_shape,
                        route_id,
                        binding,
                        **semantic_kwargs,
                    )

        for route_id, record_contract in (
            MUTATION_RECORD_SCHEMA_BY_ROUTE.items()
        ):
            validator = self.bindings[route_id]["response_validator"]
            response = _response_fixture(route_id, validator)
            validation_kwargs = _mutation_validation_kwargs(
                route_id,
                response,
            )
            with self.subTest(mutation_route=route_id):
                _validate_response_semantics(
                    response,
                    route_id,
                    self.bindings[route_id],
                    **validation_kwargs,
                )

                invalid_record = copy.deepcopy(response)
                data = invalid_record["data"]
                data["record"] = {"arbitrary": "invalid nested contract"}
                data["record_sha256"] = canonical_sha256(data["record"])
                data["source"]["record_sha256"] = data["record_sha256"]
                proof = {
                    "record_contract": data["record_contract"],
                    "record_sha256": data["record_sha256"],
                    "source": data["source"],
                    "journal": data["journal"],
                }
                data["result_proof_sha256"] = canonical_sha256(proof)
                invalid_record["data_sha256"] = canonical_sha256(data)
                with self.assertRaises(ProtocolError):
                    _validate_response_semantics(
                        invalid_record,
                        route_id,
                        self.bindings[route_id],
                        **validation_kwargs,
                    )

                wrong_record_contract = copy.deepcopy(response)
                wrong_record_contract["data"]["record_contract"] = (
                    "run-artifact-reference.schema.json"
                    if record_contract
                    != "run-artifact-reference.schema.json"
                    else "product-factory-registry-record.schema.json"
                )
                wrong_record_contract["data_sha256"] = canonical_sha256(
                    wrong_record_contract["data"]
                )
                with self.assertRaisesRegex(
                    ProtocolError,
                    "record_contract",
                ):
                    _validate_response_semantics(
                        wrong_record_contract,
                        route_id,
                        self.bindings[route_id],
                        **validation_kwargs,
                    )

                wrong_source = copy.deepcopy(response)
                wrong_source["data"]["source"]["source_registry_id"] = (
                    "signal-revisions"
                    if MUTATION_PRIMARY_SOURCE_BY_ROUTE[route_id]
                    != "signal-revisions"
                    else "product-factory-revisions"
                )
                proof = {
                    "record_contract": wrong_source["data"][
                        "record_contract"
                    ],
                    "record_sha256": wrong_source["data"][
                        "record_sha256"
                    ],
                    "source": wrong_source["data"]["source"],
                    "journal": wrong_source["data"]["journal"],
                }
                wrong_source["data"]["result_proof_sha256"] = (
                    canonical_sha256(proof)
                )
                wrong_source["data_sha256"] = canonical_sha256(
                    wrong_source["data"]
                )
                with self.assertRaisesRegex(ProtocolError, "source proof"):
                    _validate_response_semantics(
                        wrong_source,
                        route_id,
                        self.bindings[route_id],
                        **validation_kwargs,
                    )

                wrong_batch = copy.deepcopy(response)
                wrong_batch["data"]["journal"]["batch_sha256"] = (
                    "f" * 64
                )
                proof = {
                    "record_contract": wrong_batch["data"][
                        "record_contract"
                    ],
                    "record_sha256": wrong_batch["data"][
                        "record_sha256"
                    ],
                    "source": wrong_batch["data"]["source"],
                    "journal": wrong_batch["data"]["journal"],
                }
                wrong_batch["data"]["result_proof_sha256"] = (
                    canonical_sha256(proof)
                )
                wrong_batch["data_sha256"] = canonical_sha256(
                    wrong_batch["data"]
                )
                with self.assertRaisesRegex(
                    ProtocolError,
                    "trusted canonical batch",
                ):
                    _validate_response_semantics(
                        wrong_batch,
                        route_id,
                        self.bindings[route_id],
                        **validation_kwargs,
                    )

        nested_cases = []
        capability = _response_fixture(
            "capabilities-get",
            "capability-status",
        )
        capability["data"]["capabilities"]["fabricated"] = {
            "implemented": True,
            "status": "ready",
            "reason_code": None,
        }
        capability["data_sha256"] = canonical_sha256(capability["data"])
        nested_cases.append(
            (
                capability,
                "capabilities-get",
                "Capability status keys",
                {},
            )
        )

        projection_page = _response_fixture(
            "products-list",
            "projection-page",
        )
        projection_page_kwargs = _projection_validation_kwargs(
            "products-list",
            self.response_scopes["products-list"],
        )
        projection_page["data"]["items"] = [{"arbitrary": "invalid"}]
        projection_page["data_sha256"] = canonical_sha256(
            projection_page["data"]
        )
        nested_cases.append(
            (
                projection_page,
                "products-list",
                "Projection aggregate shape",
                projection_page_kwargs,
            )
        )

        projection_record = _response_fixture(
            "product-get",
            "projection-record",
        )
        projection_record_kwargs = _projection_validation_kwargs(
            "product-get",
            self.response_scopes["product-get"],
        )
        projection_record["data"]["status"] = "changed"
        projection_record["data_sha256"] = canonical_sha256(
            projection_record["data"]
        )
        nested_cases.append(
            (
                projection_record,
                "product-get",
                "aggregate digest",
                projection_record_kwargs,
            )
        )

        event_page = _response_fixture(
            "events-list",
            "public-event-page",
        )
        event_page["data"]["items"][0]["payload"] = {"invalid": True}
        event_page["data"]["items"][0]["payload_sha256"] = canonical_sha256(
            event_page["data"]["items"][0]["payload"]
        )
        event_page["data_sha256"] = canonical_sha256(event_page["data"])
        nested_cases.append(
            (
                event_page,
                "events-list",
                "payload fields",
                {
                    "response_scope": self.response_scopes[
                        "events-list"
                    ],
                },
            )
        )

        event = _response_fixture("event-get", "public-event")
        event["data"]["correlations"]["project_id"] = "other-project"
        event["data_sha256"] = canonical_sha256(event["data"])
        nested_cases.append(
            (
                event,
                "event-get",
                "identity",
                {
                    "expected_subject_id": "event-foundation",
                    "response_scope": self.response_scopes["event-get"],
                },
            )
        )

        projection_status = _response_fixture(
            "projections-list",
            "projection-status",
        )
        projection_status["data"]["projection"]["journal_sequence"] = 1
        projection_status["data_sha256"] = canonical_sha256(
            projection_status["data"]
        )
        nested_cases.append(
            (projection_status, "projections-list", "behind", {})
        )

        journal_status = _response_fixture(
            "journal-get",
            "journal-status",
        )
        journal_status["data"]["integrity"]["status"] = "failed"
        journal_status["data_sha256"] = canonical_sha256(
            journal_status["data"]
        )
        nested_cases.append(
            (journal_status, "journal-get", "not verified", {})
        )

        for response, route_id, message, semantic_kwargs in nested_cases:
            with self.subTest(nested_route=route_id):
                with self.assertRaisesRegex(ProtocolError, message):
                    _validate_response_semantics(
                        response,
                        route_id,
                        self.bindings[route_id],
                        **semantic_kwargs,
                    )

    def test_all_response_scopes_are_required_and_store_verified(
        self,
    ) -> None:
        for route_id, scope in self.response_scopes.items():
            validator = self.bindings[route_id]["response_validator"]
            response = _response_fixture(route_id, validator)
            if validator in {"projection-page", "projection-record"}:
                semantic_kwargs = _projection_validation_kwargs(
                    route_id,
                    scope,
                )
            else:
                semantic_kwargs = {
                    "expected_subject_id": (
                        FIXTURE_SUBJECT_BY_ROUTE.get(route_id)
                    ),
                    "response_scope": scope,
                }
            with self.subTest(route=route_id):
                _validate_response_semantics(
                    response,
                    route_id,
                    self.bindings[route_id],
                    **semantic_kwargs,
                )
                if scope["subject_source"] is not None:
                    missing_subject = dict(semantic_kwargs)
                    missing_subject["expected_subject_id"] = None
                    with self.assertRaisesRegex(
                        ProtocolError,
                        "resolved route subject",
                    ):
                        _validate_response_semantics(
                            response,
                            route_id,
                            self.bindings[route_id],
                            **missing_subject,
                        )

        cross_domain = _response_fixture(
            "product-get",
            "projection-record",
        )
        cross_domain_kwargs = _projection_validation_kwargs(
            "product-get",
            self.response_scopes["product-get"],
        )
        cross_domain["data"]["projection_id"] = "signals"
        cross_domain["data"]["content_sha256"] = _content_sha256(
            cross_domain["data"]
        )
        cross_domain["data_sha256"] = canonical_sha256(
            cross_domain["data"]
        )
        with self.assertRaisesRegex(ProtocolError, "aggregate domain"):
            _validate_response_semantics(
                cross_domain,
                "product-get",
                self.bindings["product-get"],
                **cross_domain_kwargs,
            )

        unverified = _response_fixture(
            "product-get",
            "projection-record",
        )
        unverified_kwargs = _projection_validation_kwargs(
            "product-get",
            self.response_scopes["product-get"],
        )
        unverified["data"]["status"] = "active"
        unverified["data"]["content_sha256"] = _content_sha256(
            unverified["data"]
        )
        unverified["data_sha256"] = canonical_sha256(
            unverified["data"]
        )
        with self.assertRaisesRegex(ProtocolError, "store-verified"):
            _validate_response_semantics(
                unverified,
                "product-get",
                self.bindings["product-get"],
                **unverified_kwargs,
            )

        response_derived_context = copy.deepcopy(
            unverified_kwargs["trusted_projection_context"]
        )
        response_derived_context["origin"] = "response-derived"
        response_derived_context["rows"][0]["record_json"] = copy.deepcopy(
            unverified["data"]
        )
        response_derived_context["rows"][0]["content_sha256"] = (
            unverified["data"]["content_sha256"]
        )
        response_derived_context["rows"][0]["record_sha256"] = (
            canonical_sha256(unverified["data"])
        )
        response_derived_context["content_sha256"] = _content_sha256(
            response_derived_context
        )
        response_derived_kwargs = dict(unverified_kwargs)
        response_derived_kwargs["trusted_projection_context"] = (
            response_derived_context
        )
        with self.assertRaisesRegex(ProtocolError, "context is invalid"):
            _validate_response_semantics(
                unverified,
                "product-get",
                self.bindings["product-get"],
                **response_derived_kwargs,
            )

    def test_mutation_proofs_reject_self_consistent_fabrication(
        self,
    ) -> None:
        response = _response_fixture(
            "product-register",
            "product-mutation-result",
        )
        semantic_kwargs = _mutation_validation_kwargs(
            "product-register",
            response,
        )
        attacks = {
            "source registry": lambda data: data["source"].__setitem__(
                "source_registry_id",
                "signal-revisions",
            ),
            "source row": lambda data: data["source"].__setitem__(
                "row_sha256",
                "f" * 64,
            ),
            "request digest": lambda data: data["journal"].__setitem__(
                "api_request_sha256",
                "f" * 64,
            ),
            "mutation id": lambda data: data["journal"].__setitem__(
                "mutation_id",
                "mutation-" + "f" * 32,
            ),
            "mutation identity": lambda data: data[
                "journal"
            ].__setitem__("mutation_identity_sha256", "f" * 64),
            "coverage branch": lambda data: data["journal"].__setitem__(
                "coverage_branch_id",
                "product.update",
            ),
            "entry id": lambda data: data["journal"][
                "entry_ids"
            ].__setitem__(0, "journal-entry-" + "f" * 32),
            "entry digest": lambda data: data["journal"][
                "entry_sha256s"
            ].__setitem__(0, "f" * 64),
            "batch digest": lambda data: data["journal"].__setitem__(
                "batch_sha256",
                "f" * 64,
            ),
        }
        for label, attack in attacks.items():
            fabricated = copy.deepcopy(response)
            attack(fabricated["data"])
            if label == "entry digest":
                fabricated["data"]["journal"]["batch_sha256"] = (
                    canonical_sha256(
                        fabricated["data"]["journal"]["entry_sha256s"]
                    )
                )
            _redigest_mutation_response(fabricated)
            with self.subTest(attack=label):
                with self.assertRaises(ProtocolError):
                    _validate_response_semantics(
                        fabricated,
                        "product-register",
                        self.bindings["product-register"],
                        **semantic_kwargs,
                    )

        with self.assertRaisesRegex(ProtocolError, "trusted store context"):
            _validate_response_semantics(
                response,
                "product-register",
                self.bindings["product-register"],
            )

    def test_variable_journal_coverage_matches_sf106_rules(self) -> None:
        coverage = _journal_coverage()
        variable_branches = (
            "dispatch.cancel",
            "run.bind-start",
            "run.lifecycle-apply",
            "run.checkpoint-reference",
            "run.artifact-reference",
        )
        for branch_id in variable_branches:
            branch = coverage[branch_id]
            minimum_ids = _coverage_boundary_source_ids(
                branch,
                use_maximum=False,
            )
            maximum_ids = _coverage_boundary_source_ids(
                branch,
                use_maximum=True,
            )
            with self.subTest(branch=branch_id, boundary="minimum"):
                _validate_coverage_source_ids(branch, minimum_ids)
            with self.subTest(branch=branch_id, boundary="maximum"):
                _validate_coverage_source_ids(branch, maximum_ids)
            self.assertLessEqual(len(minimum_ids), len(maximum_ids))

        with self.assertRaisesRegex(ProtocolError, "source count"):
            _validate_coverage_source_ids(
                coverage["dispatch.cancel"],
                [],
            )

        with self.assertRaisesRegex(ProtocolError, "unregistered"):
            _validate_coverage_source_ids(
                coverage["dispatch.cancel"],
                ["signal-revisions"],
            )

        bind_minimum = _coverage_boundary_source_ids(
            coverage["run.bind-start"],
            use_maximum=False,
        )
        with self.assertRaisesRegex(ProtocolError, "append order"):
            _validate_coverage_source_ids(
                coverage["run.bind-start"],
                list(reversed(bind_minimum)),
            )

        lifecycle = coverage["run.lifecycle-apply"]
        invalid_site_counts = _coverage_boundary_source_ids(
            lifecycle,
            use_maximum=False,
        )
        invalid_site_counts.remove("run-lifecycle-results")
        invalid_site_counts.append("run-history")
        invalid_site_counts.sort(
            key=lambda source_id: (
                _journal_sources()[source_id]["append_order"],
                source_id,
            )
        )
        with self.assertRaisesRegex(ProtocolError, "write-site"):
            _validate_coverage_source_ids(
                lifecycle,
                invalid_site_counts,
            )

    def test_run_bind_response_extraction_matches_sf105_contract(
        self,
    ) -> None:
        record = _mutation_record("run-bind-start")
        service_result = copy.deepcopy(record)
        service_result["command_result"] = {
            "command_id": "run-command-foundation",
            "status": "applied",
        }
        with self.assertRaisesRegex(ProtocolError, "Additional properties"):
            validate_against_schema(
                service_result,
                "run-binding-record.schema.json",
                label="raw run bind service result",
                schema_root=OPERATIONS_ROOT,
            )
        extracted = _extract_mutation_record(
            "run-bind-start",
            service_result,
        )
        validate_against_schema(
            extracted,
            "run-binding-record.schema.json",
            label="extracted run bind response record",
            schema_root=OPERATIONS_ROOT,
        )
        self.assertNotIn("command_result", extracted)
        self.assertEqual(
            _mutation_source_record_sha256(
                "run-bind-start",
                extracted,
            ),
            extracted["initial_binding"]["content_sha256"],
        )
        self.assertNotEqual(
            extracted["initial_binding"]["content_sha256"],
            extracted["content_sha256"],
        )

    def test_all_mutation_records_are_route_identity_bound(self) -> None:
        for route_id in MUTATION_RECORD_SCHEMA_BY_ROUTE:
            validator = self.bindings[route_id]["response_validator"]
            response = _response_fixture(route_id, validator)
            semantic_kwargs = _mutation_validation_kwargs(
                route_id,
                response,
            )

            wrong_project = copy.deepcopy(response)
            project_changed = _set_mutation_record_project(
                route_id,
                wrong_project["data"]["record"],
                "other-project",
            )
            project_kwargs = copy.deepcopy(semantic_kwargs)
            if project_changed:
                _redigest_mutation_response(wrong_project)
            else:
                project_kwargs["trusted_mutation_evidence"][
                    "canonical_project_id"
                ] = "other-project"
            with self.subTest(route=route_id, identity="project"):
                with self.assertRaisesRegex(
                    ProtocolError,
                    "record identity",
                ):
                    _validate_response_semantics(
                        wrong_project,
                        route_id,
                        self.bindings[route_id],
                        **project_kwargs,
                    )

            wrong_subject_kwargs = copy.deepcopy(semantic_kwargs)
            wrong_subject_kwargs["expected_subject_id"] = (
                "different-subject"
            )
            with self.subTest(route=route_id, identity="subject"):
                with self.assertRaisesRegex(
                    ProtocolError,
                    "record identity",
                ):
                    _validate_response_semantics(
                        response,
                        route_id,
                        self.bindings[route_id],
                        **wrong_subject_kwargs,
                    )

    def test_idempotency_schema_enforces_every_state_shape(self) -> None:
        for status in (
            "accepted",
            "executing",
            "retryable",
            "completed",
            "reconcile-required",
        ):
            with self.subTest(status=status):
                record = _idempotency_record(status)
                validate_against_schema(
                    record,
                    "operations-api-idempotency-record.schema.json",
                    label=f"idempotency {status}",
                    schema_root=OPERATIONS_ROOT,
                )
                _validate_idempotency_semantics(record)

        invalid_completed = _idempotency_record("completed")
        invalid_completed["response_json"] = None
        invalid_completed["response_sha256"] = None
        invalid_completed["result_proof_sha256"] = None
        invalid_completed["content_sha256"] = _content_sha256(
            invalid_completed
        )
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                invalid_completed,
                "operations-api-idempotency-record.schema.json",
                label="completed without proof",
                schema_root=OPERATIONS_ROOT,
            )

        invalid_retryable = _idempotency_record("retryable")
        invalid_retryable["result_proof_sha256"] = None
        invalid_retryable["content_sha256"] = _content_sha256(
            invalid_retryable
        )
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                invalid_retryable,
                "operations-api-idempotency-record.schema.json",
                label="retryable without non-application proof",
                schema_root=OPERATIONS_ROOT,
            )

        invalid_accepted = _idempotency_record("accepted")
        invalid_accepted["response_status"] = 200
        invalid_accepted["response_json"] = {"status": "ok"}
        invalid_accepted["response_sha256"] = SHA256
        invalid_accepted["content_sha256"] = _content_sha256(
            invalid_accepted
        )
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                invalid_accepted,
                "operations-api-idempotency-record.schema.json",
                label="accepted with response",
                schema_root=OPERATIONS_ROOT,
            )

        invalid_order = _idempotency_record("completed")
        invalid_order["completed_at"] = "2026-08-11T11:59:58Z"
        invalid_order["content_sha256"] = _content_sha256(invalid_order)
        validate_against_schema(
            invalid_order,
            "operations-api-idempotency-record.schema.json",
            label="idempotency invalid temporal order",
            schema_root=OPERATIONS_ROOT,
        )
        with self.assertRaisesRegex(ProtocolError, "not monotonic"):
            _validate_idempotency_semantics(invalid_order)

    def test_permanent_mutation_rejections_are_type_driven(self) -> None:
        source = (
            ROOT
            / "elder_protocol"
            / "factory_operations"
            / "api_service.py"
        ).read_text(encoding="utf-8")
        classifier = source.split(
            "    def _deterministic_mutation_error(",
            1,
        )[1].split(
            "    def _validate_public_event_response(",
            1,
        )[0]
        self.assertIn(
            "isinstance(error, DeterministicMutationRejectionError)",
            classifier,
        )
        self.assertNotIn("normalized = message.lower()", classifier)
        for forbidden_marker in (
            '"does not exist" in normalized',
            '"already has"',
            '"version conflict"',
            '"authorization"',
        ):
            with self.subTest(marker=forbidden_marker):
                self.assertNotIn(forbidden_marker, classifier)

    def test_error_schema_rejects_unsafe_sf003_tuples_and_details(self) -> None:
        valid = {
            "version": "1.0.0",
            "request_id": "request-" + "1" * 32,
            "status": "error",
            "error": {
                "operation_kind": "read",
                "code": "not-found",
                "reason_code": "decision-source-unimplemented",
                "message": "Decisions are not implemented.",
                "retry": "never",
                "mutation_state": "not-applicable",
                "details": {},
            },
        }
        validate_against_schema(
            valid,
            "operations-api-error.schema.json",
            label="terminal decision error",
            schema_root=OPERATIONS_ROOT,
        )

        unsafe = copy.deepcopy(valid)
        unsafe["error"]["retry"] = "same-request"
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                unsafe,
                "operations-api-error.schema.json",
                label="unsafe retry tuple",
                schema_root=OPERATIONS_ROOT,
            )

        unsafe = copy.deepcopy(valid)
        unsafe["error"]["mutation_state"] = "applied"
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                unsafe,
                "operations-api-error.schema.json",
                label="unsafe mutation state",
                schema_root=OPERATIONS_ROOT,
            )

        secret = copy.deepcopy(valid)
        secret["error"]["details"]["api_key"] = "ghp_1234567890abcdef"
        with self.assertRaisesRegex(ProtocolError, "Additional properties"):
            validate_against_schema(
                secret,
                "operations-api-error.schema.json",
                label="secret-shaped error details",
                schema_root=OPERATIONS_ROOT,
            )

        stale_event = copy.deepcopy(valid)
        stale_event["error"].update(
            {
                "code": "stale-cursor",
                "reason_code": "stale-event-cursor",
                "message": "The event cursor is stale.",
                "retry": "refresh-cursor",
                "details": {
                    "current_cursor": {
                        "version": "1.0.0",
                        "stream_id": (
                            "factory-public-events-example-agentic-product"
                        ),
                        "generation": 1,
                        "sequence": 0,
                        "event_id": None,
                        "snapshot_sha256": None,
                        "issued_at": TIMESTAMP,
                    }
                },
            }
        )
        validate_against_schema(
            stale_event,
            "operations-api-error.schema.json",
            label="stale event cursor",
            schema_root=OPERATIONS_ROOT,
        )
        _validate_error_semantics(
            stale_event,
            expected_project_id="example-agentic-product",
            now=NOW,
        )
        missing_cursor = copy.deepcopy(stale_event)
        missing_cursor["error"]["details"] = {}
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                missing_cursor,
                "operations-api-error.schema.json",
                label="stale event without current cursor",
                schema_root=OPERATIONS_ROOT,
            )

        stale_projection = copy.deepcopy(valid)
        stale_projection["error"].update(
            {
                "code": "stale-cursor",
                "reason_code": "stale-projection-token",
                "message": "The projection token is stale.",
                "retry": "refresh-cursor",
                "details": {"restart_required": True},
            }
        )
        validate_against_schema(
            stale_projection,
            "operations-api-error.schema.json",
            label="stale projection token",
            schema_root=OPERATIONS_ROOT,
        )
        for details in ({}, {"restart_required": False}):
            invalid_projection = copy.deepcopy(stale_projection)
            invalid_projection["error"]["details"] = details
            with self.subTest(details=details):
                with self.assertRaises(ProtocolError):
                    validate_against_schema(
                        invalid_projection,
                        "operations-api-error.schema.json",
                        label="invalid stale projection details",
                        schema_root=OPERATIONS_ROOT,
                    )
        _validate_error_semantics(
            stale_projection,
            expected_project_id="example-agentic-product",
            now=NOW,
        )

        sequence_mismatch = copy.deepcopy(stale_event)
        sequence_mismatch["error"]["details"]["current_cursor"].update(
            {"sequence": 1, "event_id": None}
        )
        with self.assertRaises(ProtocolError):
            _validate_error_semantics(
                sequence_mismatch,
                expected_project_id="example-agentic-product",
                now=NOW,
            )

        wrong_stream = copy.deepcopy(stale_event)
        wrong_stream["error"]["details"]["current_cursor"]["stream_id"] = (
            "factory-public-events-other-project"
        )
        with self.assertRaisesRegex(ProtocolError, "route project"):
            _validate_error_semantics(
                wrong_stream,
                expected_project_id="example-agentic-product",
                now=NOW,
            )

        future_cursor = copy.deepcopy(stale_event)
        future_cursor["error"]["details"]["current_cursor"]["issued_at"] = (
            "2027-08-11T12:00:00Z"
        )
        with self.assertRaisesRegex(ProtocolError, "future-issued"):
            _validate_error_semantics(
                future_cursor,
                expected_project_id="example-agentic-product",
                now=NOW,
            )

        extra_event_detail = copy.deepcopy(stale_event)
        extra_event_detail["error"]["details"]["restart_required"] = True
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                extra_event_detail,
                "operations-api-error.schema.json",
                label="stale event with projection detail",
                schema_root=OPERATIONS_ROOT,
            )

        extra_projection_detail = copy.deepcopy(stale_projection)
        extra_projection_detail["error"]["details"]["current_cursor"] = (
            stale_event["error"]["details"]["current_cursor"]
        )
        with self.assertRaises(ProtocolError):
            validate_against_schema(
                extra_projection_detail,
                "operations-api-error.schema.json",
                label="stale projection with event detail",
                schema_root=OPERATIONS_ROOT,
            )

    def test_request_and_response_documents_require_recursive_secret_scan(
        self,
    ) -> None:
        request = _mutation_request()
        request["payload"]["api_key"] = "ghp_1234567890abcdef"
        request["payload_sha256"] = canonical_sha256(request["payload"])
        with self.assertRaisesRegex(ProtocolError, "secret"):
            reject_secret_material(request, path="API mutation request")

        response = {
            "version": "1.0.0",
            "request_id": "request-" + "1" * 32,
            "route_id": "product-get",
            "status": "ok",
            "data_contract": "projection-record",
            "data": {"authorization": "Bearer secret-value"},
            "data_sha256": canonical_sha256(
                {"authorization": "Bearer secret-value"}
            ),
        }
        validate_against_schema(
            response,
            "operations-api-response.schema.json",
            label="secret-shaped response before semantic scan",
            schema_root=OPERATIONS_ROOT,
        )
        with self.assertRaisesRegex(ProtocolError, "secret"):
            reject_secret_material(response, path="API response")

    def test_error_codes_remain_exactly_the_ratified_sf003_set(self) -> None:
        contracts = load_json(ROOT / "factory" / "factory-contracts.json")
        ratified_codes = {
            error["code"] for error in contracts["errors"]
        }
        self.assertEqual(ratified_codes, EXPECTED_ERROR_CODES)

        error_schema = load_json(
            OPERATIONS_ROOT / "operations-api-error.schema.json"
        )
        api_codes = set(
            error_schema["properties"]["error"]["properties"]["code"]["enum"]
        )
        self.assertEqual(api_codes, ratified_codes)

    def test_decisions_are_truthfully_implemented_capability(self) -> None:
        capability = factory_capability_status()["capabilities"]["decisions"]
        self.assertTrue(capability["implemented"])
        self.assertEqual(capability["status"], "ready")
        self.assertIsNone(capability["reason_code"])

    def test_design_records_phase_proportional_transport_closure(
        self,
    ) -> None:
        design = DESIGN_PATH.read_text(encoding="utf-8")
        self.assertIn(
            "**Status:** VERIFIED - LOCAL GATE B PASS",
            design,
        )
        self.assertIn(
            "**Implementation:** COMPLETE FOR THE DECLARED PHASE 1 SCOPE",
            design,
        )
        self.assertIn(
            "**Design review:** ACCEPTED FOR THE DECLARED PHASE 1 CONTRACT",
            design,
        )
        self.assertIn("## Phase-Proportional Transport Reconciliation", design)
        self.assertIn("### Required authenticated long-poll admission", design)
        self.assertIn("### Boot-bound configuration and readiness", design)
        self.assertIn("### Normal graceful drain", design)
        self.assertIn("### Deferred production transport guarantees", design)
        normalized_design = " ".join(design.split())
        self.assertIn(
            "requests admitted before drain may finish; drain blocks new "
            "admissions",
            normalized_design,
        )
        self.assertIn(
            "does not claim that no response byte can cross the drain "
            "transition",
            normalized_design,
        )
        self.assertIn(
            "configuration change requires a controlled restart",
            normalized_design,
        )
        self.assertIn(
            "each route's declared response type",
            normalized_design,
        )
        self.assertIn("byte-level publication locks", design)
        self.assertFalse(
            (
                OPERATIONS_ROOT
                / "operations-api-transport-boundary.json"
            ).exists()
        )

        server_source = inspect.getsource(OperationsApiRequestHandler)
        service_source = inspect.getsource(OperationsApiService.handle)
        self.assertNotIn("_is_long_poll", server_source)
        self.assertNotIn("long_poll_slots", server_source)
        self.assertLess(
            service_source.index("self._auth.authenticate"),
            service_source.index("self._long_poll_slots.acquire"),
        )
        self.assertLess(
            service_source.index("self._health.require_event_wait_ready"),
            service_source.index("self._long_poll_slots.acquire"),
        )
        self.assertIn("## Initial Independent Review", design)
        self.assertIn("## Final Independent Design Acceptance", design)
        self.assertIn("Two independent reviewers returned `READY`", design)
        self.assertIn("## Implementation Audit Reopening", design)
        self.assertIn("### Projection response correction", design)
        self.assertIn(
            "### Interrupted mutation reconciliation correction",
            design,
        )
        self.assertIn(
            "### Production semantic validation correction",
            design,
        )
        self.assertIn("active-generation aggregate projection rows", design)
        self.assertIn("exact immutable source versions", design)
        self.assertIn("begin_reconciliation()", design)
        self.assertIn(
            "`run-lifecycle-command-result.schema.json`",
            design,
        )
        self.assertIn(
            "### Final remediation after second re-review",
            design,
        )
        self.assertIn("## Historical Provisional Local Acceptance", design)
        self.assertIn("Foundation: 112 passed", design)
        self.assertIn("Stress: 32 passed", design)
        self.assertIn(
            "### Final remediation after final re-review",
            design,
        )
        self.assertIn("canonical digest pins", design)
        self.assertIn("result-proof digest", design)
        self.assertIn("authoritative current UTC time", design)
        self.assertIn("Self-consistent redigestion", design)
        self.assertIn("19 exact response scopes", design)
        self.assertIn("store-loaded finalized SF-106 mutation context", design)
        self.assertIn("store-verified source binding", design)
        self.assertIn("per-write-site cardinality", design)
        self.assertIn("omit the service-only `command_result`", design)
        self.assertIn("independently loaded, digest-bound SF-106", design)
        self.assertIn("## Final Implementation Review Gate", design)
        self.assertIn("## Gate B Kill-And-Restart Proof", design)
        self.assertIn("### Scenario A: queued work", design)
        self.assertIn("### Scenario B: leased work", design)
        self.assertIn(
            "### Scenario C: response loss after canonical commit",
            design,
        )
        self.assertIn("### Scenario D: projection rebuild", design)
        self.assertIn("factory-owned claimant subprocess", design)
        self.assertIn("offline operator subprocess", design)
        self.assertIn(
            "after-service-commit-before-api-complete",
            design,
        )
        self.assertIn(
            "Closure required independent review to confirm",
            design,
        )
        self.assertIn(
            "elder_protocol/factory_operations/operations_store.py",
            design,
        )
        self.assertIn("elder_protocol/cli.py", design)
        self.assertIn("pyproject.toml", design)
        self.assertIn("unaccounted implementation or packaging path", design)


if __name__ == "__main__":
    unittest.main()
