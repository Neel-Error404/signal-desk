from __future__ import annotations

import copy
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    RUN_CONTROLLER_SCHEMA_VERSION,
    RUN_CONTROLLER_VERSION,
    authorization_result_sha256,
    derive_execution_key,
    derive_run_identities,
    lifecycle_authorization_request_sha256,
    record_content_sha256,
    validate_content_record,
    validate_lifecycle_authority_mapping,
    validate_product_workspace_policy,
    validate_run_binding_submission,
    validate_run_lifecycle_command,
    workspace_policy_authorization_request_sha256,
)
from elder_protocol.io import load_json


class RunControllerFoundationTests(unittest.TestCase):
    @staticmethod
    def _workspace_policy(repository_root: str) -> dict:
        source = load_json(ROOT / "factory" / "factory-contract.json")
        policy = {
            "version": "1.0.0",
            "id": "workspace-policy-product-one",
            "product_factory_id": "product-factory-product-one",
            "repository_root": repository_root,
            "repository_binding_sha256": canonical_sha256(
                {"root": repository_root}
            ),
            "source_scope": "central-p3-policy-subsets",
            "source_repository": str(ROOT.resolve()),
            "source_path": "factory/factory-contract.json",
            "source_version": source["version"],
            "source_sha256": canonical_sha256(source),
            "git_policy": copy.deepcopy(source["git"]),
            "git_policy_sha256": canonical_sha256(source["git"]),
            "workspace_policy": copy.deepcopy(source["workspace"]),
            "workspace_policy_sha256": canonical_sha256(source["workspace"]),
            "authority": {
                "actor_identity_id": "founder",
                "role": "product-owner",
                "mode": "human-approval",
                "resource": "approval-decision",
                "action": "approve",
                "authority_ref": "authority:workspace-policy-product-one",
                "accountable_command_ref": (
                    "command:approve-workspace-policy-product-one"
                ),
                "request_sha256": "0" * 64,
                "decision": "allowed",
                "decision_ref": "decision:workspace-policy-product-one",
                "decided_at": "2026-08-11T06:00:00+00:00",
                "result_sha256": "0" * 64,
            },
            "content_sha256": "0" * 64,
        }
        policy["authority"]["request_sha256"] = (
            workspace_policy_authorization_request_sha256(policy)
        )
        policy["authority"]["result_sha256"] = authorization_result_sha256(
            policy["authority"]
        )
        policy["content_sha256"] = record_content_sha256(policy)
        return policy

    @staticmethod
    def _lifecycle_command() -> dict:
        command = {
            "version": "1.0.0",
            "command_id": "run-command-start-session",
            "idempotency_key": "start-session-one",
            "operation": "start-session",
            "run_id": "run-" + "1" * 32,
            "worker_session_id": "worker-session-" + "2" * 32,
            "workspace_id": "workspace-" + "3" * 32,
            "expected_versions": {
                "run": 2,
                "worker_session": 1,
                "workspace": 1,
            },
            "actor_identity_id": "example-agentic-product-executor",
            "session_generation": 1,
            "authorizations": [
                {
                    "transition_id": "worker-session-start",
                    "role": "executor",
                    "mode": "execute-bounded",
                    "resource": "implementation",
                    "action": "execute",
                    "authority_ref": "authority:start-session-one",
                    "accountable_command_ref": "command:start-session-one",
                    "delegated_runtime_lease_ref": "lease:runtime-one",
                    "record_bindings": {
                        "run_sha256": "4" * 64,
                        "worker_session_sha256": "5" * 64,
                        "workspace_sha256": "6" * 64,
                    },
                    "request_sha256": "0" * 64,
                    "decision": "allowed",
                    "decision_ref": "decision:start-session-one",
                    "decided_at": "2026-08-11T06:01:00+00:00",
                    "result_sha256": "0" * 64,
                }
            ],
            "evidence_refs": {},
            "payload": {},
            "reason": "Start the prepared worker session.",
            "submitted_at": "2026-08-11T06:02:00+00:00",
            "payload_sha256": canonical_sha256({}),
        }
        authority = command["authorizations"][0]
        authority["request_sha256"] = lifecycle_authorization_request_sha256(
            command,
            authority,
        )
        authority["result_sha256"] = authorization_result_sha256(authority)
        return command

    def test_versions_mapping_and_deterministic_identities_are_pinned(self) -> None:
        self.assertEqual(RUN_CONTROLLER_VERSION, "1.0.0")
        self.assertEqual(RUN_CONTROLLER_SCHEMA_VERSION, 1)
        mapping = validate_lifecycle_authority_mapping()
        self.assertEqual(len(mapping["transitions"]), 29)
        self.assertEqual(len(mapping["operations"]), 2)

        identities = derive_run_identities(
            dispatch_id="dispatch-start-build-repair",
            dispatch_sha256="a" * 64,
            project_id="product-one",
            work_item_revision_id="work-item-revision-build-repair-1",
            source_revision="b" * 40,
            repository_root="C:/products/product-one",
        )
        self.assertRegex(identities["run_id"], r"^run-[a-f0-9]{32}$")
        self.assertRegex(
            identities["worker_session_id"],
            r"^worker-session-[a-f0-9]{32}$",
        )
        self.assertRegex(
            identities["workspace_id"],
            r"^workspace-[a-f0-9]{32}$",
        )
        self.assertEqual(
            derive_execution_key(
                "work-item-build-repair",
                identities["binding_seed_sha256"],
            ),
            "build-repair-" + identities["binding_seed_sha256"][:12],
        )

    def test_workspace_policy_is_product_scoped_and_digest_bound(self) -> None:
        policy = self._workspace_policy("C:/products/product-one")
        self.assertEqual(validate_product_workspace_policy(policy), policy)

        changed = copy.deepcopy(policy)
        changed["workspace_policy"]["state_root"] = ".other"
        changed["content_sha256"] = record_content_sha256(changed)
        with self.assertRaisesRegex(ProtocolError, "not pinned"):
            validate_product_workspace_policy(changed)

        secret = copy.deepcopy(policy)
        secret["api_key"] = "sk-example-secret"
        with self.assertRaisesRegex(ProtocolError, "secret"):
            validate_product_workspace_policy(secret)

    def test_binding_shape_and_lifecycle_contracts_fail_closed(self) -> None:
        repository_root = "C:/products/product-one"
        policy = self._workspace_policy(repository_root)
        submission = {
            "version": "1.0.0",
            "dispatch_id": "dispatch-start-build-repair",
            "dispatch_sha256": "a" * 64,
            "work_item": {
                "id": "work-item-build-repair",
                "record_version": 3,
                "content_sha256": "b" * 64,
                "revision_id": "work-item-revision-build-repair-1",
                "revision_entity_sha256": "c" * 64,
                "revision_snapshot_sha256": "d" * 64,
            },
            "product_factory": {
                "id": "product-factory-product-one",
                "profile_sha256": "e" * 64,
                "repository_root": repository_root,
                "repository_binding_sha256": canonical_sha256(
                    {"root": repository_root}
                ),
                "worker_policy_sha256": "f" * 64,
            },
            "workspace_policy": policy,
            "context_packet": {"id": "shape-only-context"},
            "parent_run": {"id": "shape-only-parent"},
            "delegation": {"delegation_id": "shape-only-delegation"},
            "child_run": {"id": "shape-only-child"},
            "runtime_lease": {"id": "shape-only-lease"},
            "authority_bindings": {"version": "shape-only"},
            "source": {
                "repository_root": repository_root,
                "revision": "1" * 40,
                "instruction_mode": "trusted-source-revision",
                "trusted_instruction_revision": "1" * 40,
            },
            "cleanup_policy": {
                "completed": "release",
                "cancelled": "release",
                "failed_or_lost": "state-dependent",
                "retain_evidence": True,
                "physical_delete": False,
            },
            "requested_at": "2026-08-11T06:03:00+00:00",
        }
        self.assertEqual(validate_run_binding_submission(submission), submission)

        empty_context = copy.deepcopy(submission)
        empty_context["context_packet"] = {}
        with self.assertRaisesRegex(ProtocolError, "should be non-empty"):
            validate_run_binding_submission(empty_context)

        changed = copy.deepcopy(submission)
        changed["source"]["repository_root"] = "C:/products/wrong"
        with self.assertRaisesRegex(ProtocolError, "does not match"):
            validate_run_binding_submission(changed)

        command = self._lifecycle_command()
        self.assertEqual(validate_run_lifecycle_command(command), command)
        changed_command = copy.deepcopy(command)
        changed_command["authorizations"][0]["resource"] = "checkpoint"
        with self.assertRaisesRegex(ProtocolError, "mapping mismatch"):
            validate_run_lifecycle_command(changed_command)

    def test_reference_records_preserve_canonical_fields(self) -> None:
        artifact = {
            "version": "1.0.0",
            "id": "artifact-ref-one",
            "run_id": "run-" + "1" * 32,
            "artifact_sha256": "a" * 64,
            "artifact_type": "diff",
            "provenance_ref": "git-diff:artifact-one",
            "status": "produced",
            "target_locator": None,
            "session_generation": 1,
            "recorded_at": "2026-08-11T06:04:00+00:00",
            "content_sha256": "0" * 64,
        }
        artifact["content_sha256"] = record_content_sha256(artifact)
        self.assertEqual(
            validate_content_record(
                artifact,
                "run-artifact-reference.schema.json",
                "Run artifact reference",
            ),
            artifact,
        )

        mapping = validate_lifecycle_authority_mapping()
        mapping["factory_domain_sha256"] = "0" * 64
        with self.assertRaisesRegex(ProtocolError, "not pinned"):
            validate_lifecycle_authority_mapping(mapping)


if __name__ == "__main__":
    unittest.main()
