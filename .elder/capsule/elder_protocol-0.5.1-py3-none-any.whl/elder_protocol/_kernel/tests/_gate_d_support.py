from __future__ import annotations

import base64
import hashlib
import http.client
import json
from pathlib import Path
import threading
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations import ProjectionRuntime
from elder_protocol.factory_operations.api_contracts import (
    canonical_content_sha256,
)
from elder_protocol.factory_operations.api_server import OperationsApiRuntime
from elder_protocol.io import json_text
from tests._sf203_support import (
    StaticWorkspaceAuthority,
    control_command,
    running_fixture,
)
from tests._sf300_support import create_recovery_store


CLIENT_ID = "gate-d-owner-control-room"
IDENTITY_ID = "founder"
TOKEN = base64.urlsafe_b64encode(b"gate-d-owner-token-" * 2).decode(
    "ascii"
).rstrip("=")
ROUTE_IDS = [
    "owner-inbox-get",
    "owner-portfolio-get",
    "work-room-get",
    "audit-replay-get",
    "owner-metrics-get",
    "work-room-input-create",
]


def write_auth_policy(
    workspace: Path,
    *,
    project_id: str,
) -> Path:
    policy = {
        "version": "1.0.0",
        "policy_id": "operations-api-auth-gate-d",
        "issued_at": "2026-08-14T00:00:00+00:00",
        "expires_at": "2099-01-01T00:00:00+00:00",
        "clients": [
            {
                "client_id": CLIENT_ID,
                "kind": "owner-ui",
                "identity_id": IDENTITY_ID,
                "enabled": True,
                "bearer_token_sha256": hashlib.sha256(
                    TOKEN.encode("ascii")
                ).hexdigest(),
                "project_ids": [project_id],
                "route_ids": ROUTE_IDS,
                "global_route_ids": ["owner-inbox-get"],
            }
        ],
        "content_sha256": "",
    }
    policy["content_sha256"] = canonical_content_sha256(policy)
    target = workspace / "gate-d-auth-policy.json"
    target.write_text(json_text(policy), encoding="utf-8")
    return target


def prepare_environment(workspace: Path) -> dict[str, Any]:
    (
        _,
        controller,
        aggregate,
        binding,
        adapter,
        session,
    ) = running_fixture(workspace)
    wait = control_command(
        aggregate,
        binding,
        "wait",
        index=400,
        payload={"waiting_reason": "owner-clarification"},
        at="2026-08-11T01:09:00+00:00",
        reason="Wait for the owner to provide the bounded clarification.",
    )
    session.submit(wait)
    waiting = session.execute_once(
        owner_id="gate-d-worker-controller",
        at=wait["submitted_at"],
    )
    if waiting is None or waiting["status"] != "waiting-owner":
        raise AssertionError(f"Gate D waiting fixture failed: {waiting}")
    ProjectionRuntime(controller.path).rebuild_all()
    current = controller.get(aggregate["run"]["id"])
    project_id = current["run"]["project_id"]
    work_item_id = current["initial_binding"]["work_item_id"]
    recovery = create_recovery_store(workspace / "gate-d-recovery.db")
    policy = write_auth_policy(workspace, project_id=project_id)
    return {
        "controller": controller,
        "aggregate": current,
        "binding": binding,
        "adapter": adapter,
        "session": session,
        "wait": wait,
        "project_id": project_id,
        "work_item_id": work_item_id,
        "store_path": controller.path,
        "session_store_path": session.path,
        "recovery_store_path": recovery,
        "auth_policy_path": policy,
        "workspace_authority": StaticWorkspaceAuthority(binding),
    }


def start_runtime(
    environment: dict[str, Any],
    *,
    port: int = 0,
) -> tuple[OperationsApiRuntime, threading.Thread]:
    runtime = OperationsApiRuntime(
        store_path=environment["store_path"],
        auth_policy_path=environment["auth_policy_path"],
        host="127.0.0.1",
        port=port,
        session_store_path=environment["session_store_path"],
        recovery_store_path=environment["recovery_store_path"],
        workspace_authority=environment["workspace_authority"],
    )
    thread = threading.Thread(
        target=runtime.serve_forever,
        name=f"gate-d-api-{runtime.runtime_generation}",
    )
    thread.start()
    return runtime, thread


def stop_runtime(
    runtime: OperationsApiRuntime,
    thread: threading.Thread,
) -> None:
    runtime.close()
    thread.join(timeout=15)
    if thread.is_alive():
        raise AssertionError("Gate D operations API runtime did not stop.")


def request(
    runtime: OperationsApiRuntime,
    method: str,
    target: str,
    *,
    body: dict[str, Any] | None = None,
) -> tuple[int, dict[str, Any], dict[str, str]]:
    host, port = runtime.address
    connection = http.client.HTTPConnection(host, port, timeout=30)
    payload = (
        json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
        if body is not None
        else None
    )
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "X-Elder-Client-Id": CLIENT_ID,
    }
    if payload is not None:
        headers.update(
            {
                "Content-Type": "application/json",
                "Content-Length": str(len(payload)),
                "Idempotency-Key": body["idempotency_key"],
            }
        )
    connection.request(method, target, body=payload, headers=headers)
    response = connection.getresponse()
    response_body = json.loads(response.read().decode("utf-8"))
    response_headers = {
        key.lower(): value for key, value in response.getheaders()
    }
    status = response.status
    connection.close()
    return status, response_body, response_headers


def paths(environment: dict[str, Any]) -> dict[str, str]:
    project_id = environment["project_id"]
    work_item_id = environment["work_item_id"]
    return {
        "inbox": f"/v1/owner-inbox?project_id={project_id}",
        "portfolio": f"/v1/owner-portfolio?project_id={project_id}&limit=100",
        "room": (
            f"/v1/projects/{project_id}/work-items/{work_item_id}/work-room"
        ),
        "audit": (
            f"/v1/projects/{project_id}/work-items/{work_item_id}/audit-replay"
        ),
        "metrics": f"/v1/projects/{project_id}/metrics",
    }


def follow_up_request(
    environment: dict[str, Any],
    *,
    submitted_at: str = "2026-08-14T12:00:00+00:00",
) -> dict[str, Any]:
    payload = {
        "operation": "work-room-input-create",
        "input": {
            "kind": "follow-up",
            "run_id": environment["aggregate"]["run"]["id"],
            "reason": "Owner supplied the clarification requested by the run.",
            "payload": {
                "instruction": (
                    "Continue within the accepted scope and preserve the "
                    "current evidence links."
                ),
                "continuation_of": environment["wait"]["control_id"],
            },
        },
    }
    return {
        "version": "1.0.0",
        "project_id": environment["project_id"],
        "idempotency_key": "work-room-follow-up-gate-d",
        "actor_identity_id": IDENTITY_ID,
        "payload": payload,
        "payload_sha256": canonical_sha256(payload),
        "submitted_at": submitted_at,
    }
