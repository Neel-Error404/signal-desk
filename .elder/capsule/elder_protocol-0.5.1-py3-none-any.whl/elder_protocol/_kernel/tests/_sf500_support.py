from __future__ import annotations

import copy
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations.learning_trajectory import (
    learning_trajectory_content_sha256,
)


PROJECT_ID = "elder-protocol"
WORK_ITEM_ID = "sf-500"
RUN_ID = "run-sf-500"
OBSERVED_AT = "2026-08-14T20:45:00+00:00"


def source_record(
    source_id: str,
    category: str,
    facts: dict[str, Any],
    *,
    kind: str | None = None,
    authority: str = "primary",
    required: bool = False,
    anchor: bool = False,
    occurred_at: str = "2026-08-14T20:30:00+00:00",
    recorded_at: str = "2026-08-14T20:31:00+00:00",
) -> dict[str, Any]:
    return {
        "id": source_id,
        "category": category,
        "kind": kind or f"{category}.recorded",
        "authority": authority,
        "required": required,
        "anchor": anchor,
        "occurred_at": occurred_at,
        "recorded_at": recorded_at,
        "project_id": PROJECT_ID,
        "work_item_id": WORK_ITEM_ID,
        "run_id": RUN_ID,
        "producer_id": f"{category}-adapter",
        "source_ref": f"journal:{source_id}",
        "source_sha256": canonical_sha256(facts),
        "evidence": [
            {
                "id": f"evidence:{source_id}",
                "sha256": canonical_sha256(
                    {"source_id": source_id, "kind": "fixture-evidence"}
                ),
            }
        ],
        "facts": copy.deepcopy(facts),
    }


def source_manifest(
    sources: list[dict[str, Any]] | None = None,
    *,
    expected_outcome_refs: list[str] | None = None,
    missing_links: list[dict[str, Any]] | None = None,
    manifest_id: str = "learning-source-manifest-sf500",
) -> dict[str, Any]:
    body = {
        "version": "1.0.0",
        "id": manifest_id,
        "project_id": PROJECT_ID,
        "work_item_id": WORK_ITEM_ID,
        "run_id": RUN_ID,
        "observed_at": OBSERVED_AT,
        "expected_outcome_refs": (
            ["outcome:sf-500-delivery"]
            if expected_outcome_refs is None
            else copy.deepcopy(expected_outcome_refs)
        ),
        "missing_links": copy.deepcopy(missing_links or []),
        "sources": copy.deepcopy(sources or []),
    }
    return {
        **body,
        "content_sha256": learning_trajectory_content_sha256(body),
    }


def complete_sources() -> list[dict[str, Any]]:
    return [
        source_record(
            "source-worker-action",
            "worker-action",
            {
                "action": "normalize-trajectory",
                "status": "completed",
                "input_tokens": 1200,
            },
            required=True,
        ),
        source_record(
            "source-owner-correction",
            "owner-correction",
            {
                "correction": "preserve-delayed-outcome",
                "status": "accepted",
            },
        ),
        source_record(
            "source-test",
            "test",
            {
                "level": "Component",
                "status": "passed",
                "test_count": 7,
            },
            required=True,
        ),
        source_record(
            "source-retrieval",
            "retrieval",
            {
                "packet_ref": "context:sf-500",
                "status": "assembled",
                "used": False,
            },
        ),
        source_record(
            "source-incident",
            "incident",
            {
                "condition": "stale-source",
                "status": "resolved",
            },
        ),
        source_record(
            "source-outcome",
            "outcome",
            {
                "outcome_ref": "outcome:sf-500-delivery",
                "status": "met",
                "measurement": "trajectory-artifact-validated",
            },
            recorded_at="2026-08-14T20:40:00+00:00",
        ),
    ]
