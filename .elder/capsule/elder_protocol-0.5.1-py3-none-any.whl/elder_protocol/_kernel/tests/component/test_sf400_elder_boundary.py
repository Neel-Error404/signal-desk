from __future__ import annotations

import copy
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.elder_boundary import (
    POLICY_SHA256_EXTENSION,
    PROTOCOL_SHA256_EXTENSION,
    ElderBoundaryService,
)
from tests._sf400_support import (
    CLOCK_AT,
    RESULTS,
    boundary_snapshot,
    request_for,
    success_handlers,
)
from tests._support import test_workspace


class SF400ElderBoundaryComponentTests(unittest.TestCase):
    def _service(self, workspace, *, handlers=None, available=None, calls=None):
        snapshot = boundary_snapshot()
        service = ElderBoundaryService(
            snapshot=snapshot,
            handlers=handlers or success_handlers(calls),
            state_path=workspace / "elder-boundary.db",
            available=available,
            clock=lambda: CLOCK_AT,
        )
        service.initialize()
        return snapshot, service

    def test_all_registered_operations_return_valid_decisions(self) -> None:
        with test_workspace("sf400-component-success") as workspace:
            calls: dict[str, int] = {}
            snapshot, service = self._service(workspace, calls=calls)
            for operation, expected in RESULTS.items():
                response = service.decide(request_for(snapshot, operation))
                self.assertEqual(response["disposition"], "succeeded")
                self.assertEqual(response["result"], expected)
                self.assertEqual(
                    response["source_of_truth"],
                    "governance-record-reference",
                )
            self.assertEqual(calls, {operation: 1 for operation in RESULTS})

    def test_protocol_policy_availability_and_deadline_fail_closed(self) -> None:
        with test_workspace("sf400-component-preflight") as workspace:
            calls: dict[str, int] = {}
            snapshot, service = self._service(workspace, calls=calls)

            forged_snapshot = copy.deepcopy(snapshot)
            forged_snapshot["protocol_sha256"] = "d" * 64
            forged_snapshot["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in forged_snapshot.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "current canonical protocol truth",
            ):
                ElderBoundaryService(
                    snapshot=forged_snapshot,
                    handlers=success_handlers(),
                    state_path=workspace / "forged.db",
                    clock=lambda: CLOCK_AT,
                )

            protocol_drift = request_for(snapshot, "classify")
            protocol_drift["extensions"][PROTOCOL_SHA256_EXTENSION] = "b" * 64
            response = service.decide(protocol_drift)
            self.assertEqual(response["error"]["details"]["reason_code"], "protocol-digest-mismatch")

            stale_policy = request_for(
                snapshot,
                "classify",
                request_id="request-classify-stale",
            )
            stale_policy["extensions"][POLICY_SHA256_EXTENSION] = "c" * 64
            response = service.decide(stale_policy)
            self.assertEqual(response["error"]["details"]["reason_code"], "stale-policy")

            expired = request_for(
                snapshot,
                "classify",
                request_id="request-classify-expired",
                deadline_at="2026-08-14T12:30:00+00:00",
            )
            response = service.decide(expired)
            self.assertEqual(response["error"]["code"], "timeout")
            self.assertEqual(calls, {})

            _, unavailable = self._service(
                workspace,
                handlers=success_handlers(calls),
                available=lambda: False,
            )
            response = unavailable.decide(
                request_for(
                    snapshot,
                    "classify",
                    request_id="request-classify-unavailable",
                )
            )
            self.assertEqual(response["error"]["code"], "provider-unavailable")
            self.assertEqual(calls, {})

    def test_handler_rejection_and_invalid_output_fail_closed(self) -> None:
        with test_workspace("sf400-component-handler-failure") as workspace:
            snapshot = boundary_snapshot()

            def rejected(payload, request):
                del payload, request
                raise ProtocolError("The governed evidence is incomplete.")

            service = ElderBoundaryService(
                snapshot=snapshot,
                handlers={"evaluate": rejected},
                state_path=workspace / "rejected.db",
                clock=lambda: CLOCK_AT,
            )
            service.initialize()
            response = service.decide(request_for(snapshot, "evaluate"))
            self.assertEqual(response["error"]["code"], "invalid-request")
            self.assertEqual(
                response["error"]["details"]["reason_code"],
                "elder-validation-rejected",
            )

            service = ElderBoundaryService(
                snapshot=snapshot,
                handlers={"evaluate": lambda payload, request: {"wrong": True}},
                state_path=workspace / "invalid-output.db",
                clock=lambda: CLOCK_AT,
            )
            service.initialize()
            response = service.decide(request_for(snapshot, "evaluate"))
            self.assertEqual(response["error"]["code"], "internal-error")
            self.assertEqual(
                response["error"]["details"]["reason_code"],
                "invalid-handler-result",
            )

    def test_mutation_replay_conflict_and_uncertainty_do_not_repeat_effects(self) -> None:
        with test_workspace("sf400-component-replay") as workspace:
            calls: dict[str, int] = {}
            snapshot, service = self._service(workspace, calls=calls)
            original = request_for(snapshot, "propose-learning")
            first = service.decide(original)
            replay = copy.deepcopy(original)
            replay["request_id"] = "request-propose-learning-replay"
            replay["submitted_at"] = "2026-08-14T12:01:00+00:00"
            replay["deadline_at"] = "2026-08-14T14:01:00+00:00"
            duplicate = service.decide(replay)
            self.assertEqual(first["disposition"], "succeeded")
            self.assertEqual(duplicate["disposition"], "duplicate")
            self.assertEqual(calls["propose-learning"], 1)

            conflict = copy.deepcopy(replay)
            conflict["request_id"] = "request-propose-learning-conflict"
            conflict["payload"]["trajectory"]["evidence_refs"] = ["evidence:changed"]
            conflict["payload_sha256"] = canonical_sha256(conflict["payload"])
            response = service.decide(conflict)
            self.assertEqual(
                response["error"]["details"]["reason_code"],
                "idempotency-conflict",
            )
            self.assertEqual(calls["propose-learning"], 1)

            uncertain_calls = {"count": 0}

            def uncertain(payload, request):
                del payload, request
                uncertain_calls["count"] += 1
                raise RuntimeError("Lost mutation result.")

            uncertain_service = ElderBoundaryService(
                snapshot=snapshot,
                handlers={"promote": uncertain},
                state_path=workspace / "uncertain.db",
                clock=lambda: CLOCK_AT,
            )
            uncertain_service.initialize()
            mutation = request_for(snapshot, "promote")
            first_uncertain = uncertain_service.decide(mutation)
            retry = copy.deepcopy(mutation)
            retry["request_id"] = "request-promote-retry"
            retry["submitted_at"] = "2026-08-14T12:02:00+00:00"
            retry["deadline_at"] = "2026-08-14T14:02:00+00:00"
            second_uncertain = uncertain_service.decide(retry)
            self.assertEqual(first_uncertain["disposition"], "uncertain")
            self.assertEqual(second_uncertain["disposition"], "uncertain")
            self.assertEqual(uncertain_calls["count"], 1)


if __name__ == "__main__":
    unittest.main()
