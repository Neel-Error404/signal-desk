from __future__ import annotations

import copy
import sqlite3
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.hosted_store import (
    HOSTED_MIGRATIONS,
    HOSTED_TABLES,
    PostgresDurableBroker,
    PostgresMigrationManager,
    build_sqlite_cutover_manifest,
    create_hosted_backup,
    hosted_content_sha256,
    restore_hosted_backup,
    verify_hosted_backup,
    _migration_digest,
)
from tests._sf600_support import ScriptedConnection, message
from tests._support import test_workspace


AT = "2026-08-14T21:50:00+00:00"


class HostedStoreComponentTests(unittest.TestCase):
    def test_migrations_apply_once_and_bind_sql_digest(self) -> None:
        connection = ScriptedConnection([[], [], [], []])
        changed = PostgresMigrationManager().apply(connection, at=AT)
        self.assertEqual(changed, [1])
        self.assertIn("CREATE TABLE IF NOT EXISTS factory_hosted_migrations", connection.calls[0][0])
        self.assertIn("INSERT INTO factory_hosted_migrations", connection.calls[-1][0])
        self.assertEqual(connection.commits, 1)

    def test_migration_history_drift_fails_closed(self) -> None:
        connection = ScriptedConnection(
            [
                [],
                [
                    {
                        "version": 1,
                        "name": HOSTED_MIGRATIONS[0][1],
                        "sql_sha256": "0" * 64,
                    }
                ],
            ]
        )
        with self.assertRaisesRegex(ProtocolError, "history drifted"):
            PostgresMigrationManager().apply(connection, at=AT)
        self.assertEqual(connection.rollbacks, 1)

    def test_unknown_migration_version_fails_closed(self) -> None:
        connection = ScriptedConnection(
            [
                [],
                [
                    {
                        "version": 99,
                        "name": "unregistered",
                        "sql_sha256": "0" * 64,
                    }
                ],
            ]
        )
        with self.assertRaisesRegex(ProtocolError, "unknown versions"):
            PostgresMigrationManager().apply(connection, at=AT)

    def test_publish_is_idempotent_but_changed_duplicate_is_rejected(self) -> None:
        accepted = ScriptedConnection([[{"message_id": "message-sf600"}]])
        broker = PostgresDurableBroker(lambda: accepted)
        result = broker.publish(message(), at=AT)
        self.assertFalse(result["replayed"])
        self.assertEqual(
            result["payload_sha256"],
            hosted_content_sha256(message()["payload"]),
        )

        changed = ScriptedConnection(
            [
                [],
                [
                    {
                        "topic": "factory.run",
                        "message_key": "changed-run",
                        "payload_sha256": result["payload_sha256"],
                        "available_at": message()["available_at"],
                    }
                ],
            ]
        )
        with self.assertRaisesRegex(ProtocolError, "reused with changed"):
            PostgresDurableBroker(lambda: changed).publish(message(), at=AT)

    def test_claim_uses_competing_consumer_lock_and_returns_fence(self) -> None:
        connection = ScriptedConnection(
            [
                [
                    {
                        "message_id": "message-sf600",
                        "topic": "factory.run",
                        "message_key": "run-sf600",
                        "payload_json": message()["payload"],
                        "payload_sha256": hosted_content_sha256(
                            message()["payload"]
                        ),
                        "lease_owner": "worker-one",
                        "lease_generation": 3,
                        "lease_expires_at": "2026-08-14T21:51:00+00:00",
                        "attempts": 2,
                    }
                ]
            ]
        )
        delivery = PostgresDurableBroker(lambda: connection).claim(
            topic="factory.run",
            owner="worker-one",
            lease_seconds=60,
            at=AT,
        )[0]
        self.assertEqual(delivery["lease_generation"], 3)
        self.assertIn("FOR UPDATE SKIP LOCKED", connection.calls[0][0])
        self.assertIn("lease_generation = outbox.lease_generation + 1", connection.calls[0][0])

    def test_acknowledgement_is_transactional_and_duplicate_safe(self) -> None:
        payload_sha256 = hosted_content_sha256(message()["payload"])
        delivery = {
            "message_id": "message-sf600",
            "payload_sha256": payload_sha256,
            "lease_owner": "worker-one",
            "lease_generation": 3,
        }
        accepted = ScriptedConnection(
            [[], [{"message_id": "message-sf600"}], []]
        )
        self.assertTrue(
            PostgresDurableBroker(lambda: accepted).acknowledge(
                delivery,
                consumer_id="consumer-one",
                at=AT,
            )
        )
        self.assertIn("lease_expires_at > %s", accepted.calls[1][0])
        self.assertIn("INSERT INTO factory_hosted_inbox", accepted.calls[2][0])

        duplicate = ScriptedConnection(
            [[{"payload_sha256": payload_sha256}]]
        )
        self.assertFalse(
            PostgresDurableBroker(lambda: duplicate).acknowledge(
                delivery,
                consumer_id="consumer-one",
                at=AT,
            )
        )
        self.assertEqual(len(duplicate.calls), 1)

    def test_database_outage_is_explicit_and_has_no_fallback(self) -> None:
        def unavailable() -> object:
            raise OSError("database unavailable")

        with self.assertRaisesRegex(ProtocolError, "unavailable"):
            PostgresDurableBroker(unavailable).claim(
                topic="factory.run",
                owner="worker-one",
                lease_seconds=60,
                at=AT,
            )

    def test_secret_payload_is_rejected_before_persistence(self) -> None:
        unsafe = message()
        unsafe["payload"]["api_key"] = "sk-prohibited-value"
        connection = ScriptedConnection()
        with self.assertRaisesRegex(ProtocolError, "secret"):
            PostgresDurableBroker(lambda: connection).publish(unsafe, at=AT)
        self.assertEqual(connection.calls, [])

    def test_quiesced_sqlite_cutover_is_deterministic(self) -> None:
        with test_workspace("sf600-cutover") as workspace:
            database = workspace / "operations.db"
            connection = sqlite3.connect(database)
            connection.execute(
                "CREATE TABLE facts(id TEXT PRIMARY KEY, value TEXT NOT NULL)"
            )
            connection.executemany(
                "INSERT INTO facts VALUES (?, ?)",
                [("two", "b"), ("one", "a")],
            )
            connection.commit()
            connection.close()
            kwargs = {
                "cutover_id": "cutover-sf600",
                "maintenance_mode": True,
                "uncertain_commands": 0,
                "active_leases": 0,
                "source_schema_version": 1,
                "journal_tip": {
                    "generation": 1,
                    "sequence": 2,
                    "entry_sha256": "a" * 64,
                },
                "projections": [
                    {
                        "projection_id": "facts",
                        "generation": 1,
                        "projection_sha256": "b" * 64,
                    }
                ],
                "at": AT,
            }
            first = build_sqlite_cutover_manifest(database, **kwargs)
            second = build_sqlite_cutover_manifest(database, **kwargs)
            self.assertEqual(first, second)
            self.assertEqual(first["record_count"], 2)
            self.assertEqual(first["table_counts"], {"facts": 2})
            self.assertEqual(
                first["records"][0]["primary_key"],
                {"id": first["records"][0]["record"]["id"]},
            )

            with self.assertRaisesRegex(ProtocolError, "maintenance mode"):
                build_sqlite_cutover_manifest(
                    database, **{**kwargs, "maintenance_mode": False}
                )

            forged = copy.deepcopy(first)
            forged["maintenance_mode"] = False
            forged["content_sha256"] = hosted_content_sha256(
                {
                    key: value
                    for key, value in forged.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "maintenance mode"):
                from elder_protocol.factory_operations.hosted_store import (
                    HostedCutoverCoordinator,
                )

                HostedCutoverCoordinator(
                    lambda: ScriptedConnection()
                ).import_manifest(forged)

            forged_checkpoint = copy.deepcopy(first)
            forged_checkpoint["journal_tip"]["generation"] = 0
            forged_checkpoint["journal_tip"]["sequence"] = -1
            forged_checkpoint["journal_tip"]["entry_sha256"] = "invalid"
            forged_checkpoint["content_sha256"] = hosted_content_sha256(
                {
                    key: value
                    for key, value in forged_checkpoint.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "journal tip"):
                HostedCutoverCoordinator(
                    lambda: ScriptedConnection()
                ).import_manifest(forged_checkpoint)

    def test_backup_digest_and_inventory_fail_closed(self) -> None:
        tables = {
            table: []
            for table in (
                "factory_hosted_backup_catalog",
                "factory_hosted_cutovers",
                "factory_hosted_inbox",
                "factory_hosted_migrations",
                "factory_hosted_outbox",
                "factory_hosted_projection_checkpoints",
                "factory_hosted_records",
            )
        }
        tables["factory_hosted_migrations"] = [
            {
                "version": 1,
                "name": HOSTED_MIGRATIONS[0][1],
                "sql_sha256": _migration_digest(
                    HOSTED_MIGRATIONS[0][2]
                ),
                "applied_at": AT,
            }
        ]
        body = {
            "version": "1.0.0",
            "backup_id": "backup-sf600",
            "tables": tables,
            "record_count": 1,
            "created_at": AT,
        }
        manifest = {
            **body,
            "snapshot_sha256": hosted_content_sha256(body),
        }
        self.assertEqual(verify_hosted_backup(manifest)["record_count"], 1)
        changed = copy.deepcopy(manifest)
        changed["record_count"] = 2
        with self.assertRaisesRegex(ProtocolError, "digest changed"):
            verify_hosted_backup(changed)

        unsupported = copy.deepcopy(manifest)
        unsupported["version"] = "2.0.0"
        unsupported["snapshot_sha256"] = hosted_content_sha256(
            {
                key: value
                for key, value in unsupported.items()
                if key != "snapshot_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "version is not supported"):
            verify_hosted_backup(unsupported)

        duplicate = copy.deepcopy(manifest)
        duplicate["tables"]["factory_hosted_migrations"].append(
            copy.deepcopy(
                duplicate["tables"]["factory_hosted_migrations"][0]
            )
        )
        duplicate["record_count"] += 1
        duplicate["snapshot_sha256"] = hosted_content_sha256(
            {
                key: value
                for key, value in duplicate.items()
                if key != "snapshot_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "duplicate versions"):
            verify_hosted_backup(duplicate)

    def test_restore_reproduces_snapshot_before_recording_recovery(self) -> None:
        migration = {
            "version": 1,
            "name": HOSTED_MIGRATIONS[0][1],
            "sql_sha256": _migration_digest(HOSTED_MIGRATIONS[0][2]),
            "applied_at": "2026-08-14T20:00:00+00:00",
        }
        tables = {table: [] for table in HOSTED_TABLES}
        tables["factory_hosted_migrations"] = [migration]
        body = {
            "version": "1.0.0",
            "backup_id": "backup-sf600",
            "tables": tables,
            "record_count": 1,
            "created_at": AT,
        }
        manifest = {
            **body,
            "snapshot_sha256": hosted_content_sha256(body),
        }
        responses = [[(0,)] for _ in range(6)]
        responses.extend(
            [
                [],
                [],
            ]
        )
        for table in HOSTED_TABLES:
            responses.append(
                [migration]
                if table == "factory_hosted_migrations"
                else []
            )
        responses.append([])
        connection = ScriptedConnection(responses)
        restored = restore_hosted_backup(connection, manifest, at=AT)
        self.assertEqual(
            restored["snapshot_sha256"],
            manifest["snapshot_sha256"],
        )
        self.assertTrue(
            any(
                "INSERT INTO factory_hosted_migrations SELECT *" in sql
                for sql, _ in connection.calls
            )
        )

    def test_backup_uses_one_repeatable_read_transaction(self) -> None:
        connection = ScriptedConnection(
            [
                [],
                *([[]] * len(HOSTED_TABLES)),
                [{"backup_id": "backup-repeatable"}],
            ]
        )
        manifest = create_hosted_backup(
            connection,
            backup_id="backup-repeatable",
            at=AT,
        )
        self.assertEqual(manifest["record_count"], 0)
        self.assertEqual(
            connection.calls[0][0],
            "SET TRANSACTION ISOLATION LEVEL REPEATABLE READ",
        )
        self.assertEqual(connection.commits, 1)

    def test_backup_identity_reuse_with_changed_content_fails_closed(
        self,
    ) -> None:
        connection = ScriptedConnection(
            [
                [],
                *([[]] * len(HOSTED_TABLES)),
                [],
                [
                    {
                        "snapshot_sha256": "0" * 64,
                        "record_count": 0,
                        "created_at": AT,
                    }
                ],
            ]
        )
        with self.assertRaisesRegex(ProtocolError, "reused with changed"):
            create_hosted_backup(
                connection,
                backup_id="backup-reused",
                at=AT,
            )


if __name__ == "__main__":
    unittest.main()
