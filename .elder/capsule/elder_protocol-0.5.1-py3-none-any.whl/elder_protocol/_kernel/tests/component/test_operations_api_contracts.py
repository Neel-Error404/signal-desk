from __future__ import annotations

import copy
import unittest
from unittest.mock import Mock

from elder_protocol.errors import (
    InvalidEventCursorError,
    OperationsApiUnavailableError,
    OperationsReadUnavailableError,
    ProtocolError,
)
from elder_protocol.factory_operations.api_contracts import (
    OPERATIONS_API_BINDING_REGISTRY_SHA256,
    OPERATIONS_API_ROUTE_COUNT,
    OPERATIONS_API_ROUTE_REGISTRY_SHA256,
    OPERATIONS_API_RESPONSE_SCOPE_COUNT,
    canonical_content_sha256,
    canonical_json_sha256,
    load_json_bytes_strict,
    load_operations_api_contracts,
    resolve_operations_api_schema,
    validate_operations_api_auth_policy,
    validate_operations_api_document,
    validate_operations_api_error,
    validate_operations_api_health,
    validate_operations_api_mutation_request,
    validate_operations_api_readiness,
    validate_operations_api_response,
    validate_operations_api_runtime_record,
)
from elder_protocol.factory_operations.api_service import (
    OperationsApiService,
)
from elder_protocol.factory_operations.projections import ProjectionQueries
from elder_protocol.io import json_text
from tests._support import test_workspace
from tests.foundation import test_operations_api_design as design


class OperationsApiContractsComponentTests(unittest.TestCase):
    def test_loads_exact_digest_pinned_contract_registries(self) -> None:
        contracts = load_operations_api_contracts()

        self.assertEqual(
            contracts.route_registry["content_sha256"],
            OPERATIONS_API_ROUTE_REGISTRY_SHA256,
        )
        self.assertEqual(
            contracts.binding_registry["content_sha256"],
            OPERATIONS_API_BINDING_REGISTRY_SHA256,
        )
        self.assertEqual(
            len(contracts.routes_by_id),
            OPERATIONS_API_ROUTE_COUNT,
        )
        self.assertEqual(
            len(contracts.bindings_by_route_id),
            OPERATIONS_API_ROUTE_COUNT,
        )
        self.assertEqual(
            len(contracts.response_scopes_by_route_id),
            OPERATIONS_API_RESPONSE_SCOPE_COUNT,
        )
        self.assertEqual(
            set(contracts.routes_by_id),
            set(contracts.bindings_by_route_id),
        )

    def test_self_consistent_registry_redigestion_does_not_change_pins(
        self,
    ) -> None:
        with test_workspace("sf107-api-contract-registry-drift") as workspace:
            route_path = workspace / "routes.json"
            binding_path = workspace / "bindings.json"
            route_registry = copy.deepcopy(design._route_registry())
            binding_registry = copy.deepcopy(design._binding_registry())
            binding_registry["bindings"][0]["runtime_fence_required"] = True
            binding_registry["content_sha256"] = canonical_content_sha256(
                binding_registry
            )
            route_registry["binding_registry_sha256"] = binding_registry[
                "content_sha256"
            ]
            route_registry["content_sha256"] = canonical_content_sha256(
                route_registry
            )
            route_path.write_text(json_text(route_registry), encoding="utf-8")
            binding_path.write_text(
                json_text(binding_registry),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ProtocolError, "not canonical"):
                load_operations_api_contracts(
                    route_registry_path=route_path,
                    binding_registry_path=binding_path,
                )

    def test_strict_json_loader_rejects_ambiguous_or_non_object_json(
        self,
    ) -> None:
        self.assertEqual(
            load_json_bytes_strict(b'{"value":1}', label="fixture"),
            {"value": 1},
        )
        invalid_documents = (
            (b'{"value":1,"value":2}', "duplicate object key"),
            (b'{"nested":{"value":1,"value":2}}', "duplicate object key"),
            (b'{"value":NaN}', "non-finite"),
            (b'{"value":1} trailing', "invalid JSON"),
            (b'["not-an-object"]', "JSON object"),
            (b'{"value":"\xff"}', "valid UTF-8"),
        )
        for content, message in invalid_documents:
            with self.subTest(message=message):
                with self.assertRaisesRegex(ProtocolError, message):
                    load_json_bytes_strict(content, label="fixture")

    def test_catalog_resolution_is_qualified_and_bounded(self) -> None:
        bare = resolve_operations_api_schema(
            "run-binding-submission.schema.json"
        )
        factory = resolve_operations_api_schema(
            "factory/factory-command.schema.json"
        )
        protocol = resolve_operations_api_schema(
            "protocol/agent-run.schema.json"
        )

        self.assertEqual(bare.path.parent.name, "operations")
        self.assertEqual(factory.path.parent.name, "factory")
        self.assertEqual(protocol.path.parent.name, "protocol")
        for reference in (
            "../protocol/agent-run.schema.json",
            "factory/operations/run-binding-submission.schema.json",
            "unknown.schema.json",
            r"protocol\agent-run.schema.json",
        ):
            with self.subTest(reference=reference):
                with self.assertRaises(ProtocolError):
                    resolve_operations_api_schema(reference)

    def test_structural_validators_accept_accepted_design_fixtures(
        self,
    ) -> None:
        routes = design._route_registry()["routes"]
        policy = design._auth_policy(routes)
        request = design._mutation_request()
        response = design._response_fixture(
            "product-get",
            "projection-record",
        )
        readiness = design._readiness()
        health = design._health(readiness)
        runtime = design._runtime_record()
        error = {
            "version": "1.0.0",
            "request_id": "request-" + "1" * 32,
            "status": "error",
            "error": {
                "operation_kind": "read",
                "code": "not-found",
                "reason_code": "decision-source-unimplemented",
                "message": "Decisions are not implemented.",
                "retry": "never",
                "mutation_state": "not-applicable",
                "details": {},
            },
        }

        self.assertIs(
            validate_operations_api_auth_policy(policy),
            policy,
        )
        self.assertIs(
            validate_operations_api_mutation_request(request),
            request,
        )
        self.assertIs(validate_operations_api_response(response), response)
        self.assertIs(validate_operations_api_error(error), error)
        self.assertIs(validate_operations_api_runtime_record(runtime), runtime)
        self.assertIs(
            validate_operations_api_health(
                health,
                readiness=readiness,
                now=design.NOW,
            ),
            health,
        )
        self.assertIs(
            validate_operations_api_readiness(
                readiness,
                now=design.NOW,
            ),
            readiness,
        )

    def test_digest_and_secret_failures_are_rejected(self) -> None:
        request = design._mutation_request()
        request["payload_sha256"] = "f" * 64
        with self.assertRaisesRegex(ProtocolError, "payload_sha256"):
            validate_operations_api_mutation_request(request)

        response = design._response_fixture(
            "product-get",
            "projection-record",
        )
        response["data"] = {"authorization": "Bearer secret-value"}
        response["data_sha256"] = canonical_json_sha256(response["data"])
        with self.assertRaisesRegex(ProtocolError, "secret"):
            validate_operations_api_response(response)

        runtime = design._runtime_record()
        runtime["host_id"] = "changed-host"
        with self.assertRaisesRegex(ProtocolError, "content_sha256"):
            validate_operations_api_runtime_record(runtime)

        policy = design._auth_policy(design._route_registry()["routes"])
        policy["clients"][0]["identity_id"] = (
            "service:ghp_1234567890abcdef"
        )
        policy["content_sha256"] = canonical_content_sha256(policy)
        with self.assertRaisesRegex(ProtocolError, "secret"):
            validate_operations_api_auth_policy(policy)

    def test_generic_document_validation_uses_selected_catalog(self) -> None:
        command = {
            "version": "1.0.0",
            "command_id": "command-contract-fixture",
            "project_id": "example-agentic-product",
            "work_item_id": None,
            "run_id": None,
            "worker_session_id": None,
            "command_type": "factory.status",
            "mutability": "read",
            "idempotency_key": None,
            "authority_ref": "authority:human-owner",
            "correlation_id": "correlation-contract-fixture",
            "causation_id": None,
            "attempt": 1,
            "status": "pending",
            "submitted_at": "2026-08-11T12:00:00Z",
            "expires_at": None,
            "payload_mode": "inline",
            "redaction": {
                "classification": "internal",
                "redacted_fields": [],
            },
            "payload_sha256": canonical_json_sha256({}),
            "payload": {},
            "extensions": {},
        }
        self.assertIs(
            validate_operations_api_document(
                command,
                "factory/factory-command.schema.json",
                "Factory command",
            ),
            command,
        )
        with self.assertRaisesRegex(ProtocolError, "not present"):
            validate_operations_api_document(
                {},
                "missing.schema.json",
                "Missing contract",
            )

    def test_public_event_responses_enforce_route_scope_and_cursor_order(
        self,
    ) -> None:
        event = design._public_event()
        project_id = event["correlations"]["project_id"]
        page = {
            "version": "1.0.0",
            "project_id": project_id,
            "stream_id": event["cursor"]["stream_id"],
            "items": [copy.deepcopy(event)],
            "cursor": copy.deepcopy(event["cursor"]),
        }
        OperationsApiService._validate_public_event_response(
            route_id="events-list",
            data=page,
            arguments={"project_id": project_id},
        )
        OperationsApiService._validate_public_event_response(
            route_id="event-get",
            data=event,
            arguments={
                "project_id": project_id,
                "event_id": event["event_id"],
            },
        )

        wrong_project = copy.deepcopy(page)
        wrong_project["items"][0]["correlations"]["project_id"] = (
            "other-project"
        )
        with self.assertRaisesRegex(ProtocolError, "route scope"):
            OperationsApiService._validate_public_event_response(
                route_id="events-list",
                data=wrong_project,
                arguments={"project_id": project_id},
            )

        wrong_cursor = copy.deepcopy(page)
        wrong_cursor["cursor"]["sequence"] += 1
        with self.assertRaisesRegex(ProtocolError, "last item"):
            OperationsApiService._validate_public_event_response(
                route_id="events-list",
                data=wrong_cursor,
                arguments={"project_id": project_id},
            )

        with self.assertRaisesRegex(ProtocolError, "route scope"):
            OperationsApiService._validate_public_event_response(
                route_id="event-get",
                data=event,
                arguments={
                    "project_id": project_id,
                    "event_id": "event-other",
                },
            )

    def test_event_read_operational_failures_are_retryable_not_terminal(
        self,
    ) -> None:
        queries = object.__new__(ProjectionQueries)
        queries._integrity = Mock()
        queries._integrity.read_public_events.side_effect = ProtocolError(
            "Operations store operation failed during event read."
        )
        with self.assertRaises(OperationsReadUnavailableError):
            queries.read_public_events(project_id="product-one", limit=10)

        service = object.__new__(OperationsApiService)
        service._health = Mock()
        service._queries = queries
        with self.assertRaises(OperationsApiUnavailableError):
            service._invoke_read(
                {"id": "events-list"},
                {
                    "project_id": "product-one",
                    "cursor": None,
                    "limit": 10,
                    "wait_seconds": 0,
                },
            )

        queries._integrity.read_public_events.side_effect = (
            InvalidEventCursorError("Public event cursor is from the future.")
        )
        with self.assertRaises(InvalidEventCursorError):
            queries.read_public_events(project_id="product-one", limit=10)


if __name__ == "__main__":
    unittest.main()
