from __future__ import annotations

from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from elder_protocol.errors import OperationsReadUnavailableError, ProtocolError
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    OwnerInbox,
    WorkItemLedger,
)
from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations._common import canonical_json
from elder_protocol.factory_operations.owner_inbox import (
    _reduce_owner_inbox_snapshot,
)
from tests.foundation.test_owner_inbox_contract import work_item
from tests._sf300_support import (
    OBSERVED_AT,
    create_recovery_store,
    create_session_store,
)
from tests._support import test_workspace


def session_control(
    *,
    control_id: str,
    status: str,
    work_item_id: str,
    updated_at: str,
) -> dict:
    return {
        "control_id": control_id,
        "status": status,
        "command": {
            "project_id": "product-one",
            "work_item_id": work_item_id,
            "run_id": "run-owner-inbox",
            "worker_session_id": "worker-session-owner-inbox",
            "workspace_id": "workspace-owner-inbox",
        },
        "created_at": "2026-08-13T09:00:00+00:00",
        "updated_at": updated_at,
        "content_sha256": "b" * 64,
    }


def recovery_case(
    *,
    case_id: str,
    control_id: str,
    status: str,
    updated_at: str,
) -> dict:
    return {
        "case_id": case_id,
        "control_id": control_id,
        "status": status,
        "project_id": "product-one",
        "run_id": "run-owner-inbox",
        "worker_session_id": "worker-session-owner-inbox",
        "workspace_id": "workspace-owner-inbox",
        "uncertain_at": "2026-08-13T09:30:00+00:00",
        "updated_at": updated_at,
        "content_sha256": "c" * 64,
    }


def recovery_orphan(
    *,
    orphan_id: str = "worker-recovery-orphan-" + "d" * 24,
) -> dict:
    return {
        "orphan_id": orphan_id,
        "status": "owner-required",
        "project_id": None,
        "run_id": None,
        "worker_session_id": None,
        "workspace_id": None,
        "control_id": None,
        "observed_at": "2026-08-13T10:30:00+00:00",
        "content_sha256": "d" * 64,
    }


class OwnerInboxComponentTests(unittest.TestCase):
    def test_waiting_sources_coalesce_without_losing_evidence(self) -> None:
        item_id = "work-item-owner-review"
        result = _reduce_owner_inbox_snapshot(
            work_items=[
                work_item(
                    item_id=item_id,
                    status="waiting",
                    updated_at="2026-08-13T10:00:00+00:00",
                )
            ],
            session_controls=[
                session_control(
                    control_id="control-owner-wait",
                    status="waiting-owner",
                    work_item_id=item_id,
                    updated_at="2026-08-13T10:05:00+00:00",
                )
            ],
            recovery_cases=[],
            recovery_orphans=[],
            observed_at="2026-08-13T11:00:00+00:00",
        )
        self.assertEqual(result["item_count"], 1)
        attention = result["items"][0]
        self.assertEqual(attention["reason_family"], "owner-decision")
        self.assertEqual(attention["source_count"], 2)
        self.assertEqual(
            [item["source_type"] for item in attention["evidence"]],
            ["session-control", "work-item"],
        )
        self.assertEqual(attention["subject"]["run_id"], "run-owner-inbox")
        self.assertEqual(attention["age_seconds"], 3600)

    def test_exact_duplicate_source_is_deduplicated(self) -> None:
        record = work_item(
            item_id="work-item-owner-duplicate",
            status="waiting",
            updated_at="2026-08-13T10:00:00+00:00",
        )
        result = _reduce_owner_inbox_snapshot(
            work_items=[record, record],
            session_controls=[],
            recovery_cases=[],
            recovery_orphans=[],
            observed_at="2026-08-13T11:00:00+00:00",
        )
        self.assertEqual(result["item_count"], 1)
        self.assertEqual(result["items"][0]["source_count"], 1)
        self.assertEqual(result["source_counts"]["work-items"], 1)

    def test_uncertain_control_and_recovery_case_coalesce(self) -> None:
        control = session_control(
            control_id="control-owner-uncertain",
            status="uncertain",
            work_item_id="work-item-owner-uncertain",
            updated_at="2026-08-13T10:00:00+00:00",
        )
        result = _reduce_owner_inbox_snapshot(
            work_items=[],
            session_controls=[control],
            recovery_cases=[
                recovery_case(
                    case_id="worker-recovery-" + "e" * 24,
                    control_id=control["control_id"],
                    status="owner-required",
                    updated_at="2026-08-13T10:10:00+00:00",
                )
            ],
            recovery_orphans=[],
            observed_at="2026-08-13T11:00:00+00:00",
        )
        self.assertEqual(result["item_count"], 1)
        attention = result["items"][0]
        self.assertEqual(
            attention["reason_family"],
            "worker-effect-uncertain",
        )
        self.assertEqual(attention["severity"], "urgent")
        self.assertEqual(attention["source_count"], 2)

    def test_recovery_case_identity_must_match_current_control(self) -> None:
        control = session_control(
            control_id="control-owner-identity",
            status="uncertain",
            work_item_id="work-item-owner-identity",
            updated_at="2026-08-13T10:00:00+00:00",
        )
        case = recovery_case(
            case_id="worker-recovery-" + "f" * 24,
            control_id=control["control_id"],
            status="owner-required",
            updated_at="2026-08-13T10:10:00+00:00",
        )
        case["project_id"] = "different-product"
        with self.assertRaisesRegex(
            ProtocolError,
            "identity does not match session control: project_id",
        ):
            _reduce_owner_inbox_snapshot(
                work_items=[],
                session_controls=[control],
                recovery_cases=[case],
                recovery_orphans=[],
                observed_at="2026-08-13T11:00:00+00:00",
            )

    def test_global_orphan_remains_visible_and_filter_excludes_it(self) -> None:
        orphan = recovery_orphan()
        global_result = _reduce_owner_inbox_snapshot(
            work_items=[],
            session_controls=[],
            recovery_cases=[],
            recovery_orphans=[orphan],
            observed_at="2026-08-13T11:00:00+00:00",
        )
        self.assertEqual(global_result["item_count"], 1)
        self.assertIsNone(global_result["items"][0]["project_id"])

        filtered = _reduce_owner_inbox_snapshot(
            work_items=[],
            session_controls=[],
            recovery_cases=[],
            recovery_orphans=[orphan],
            observed_at="2026-08-13T11:00:00+00:00",
            project_filter="product-one",
        )
        self.assertEqual(filtered["item_count"], 0)
        self.assertEqual(
            filtered["source_counts"]["worker-recovery-orphans"],
            0,
        )

    def test_order_is_stable_across_source_order(self) -> None:
        old_failure = work_item(
            item_id="work-item-old-failure",
            status="failed",
            updated_at="2026-08-13T09:00:00+00:00",
        )
        new_failure = work_item(
            item_id="work-item-new-failure",
            status="failed",
            updated_at="2026-08-13T10:00:00+00:00",
        )
        forward = _reduce_owner_inbox_snapshot(
            work_items=[new_failure, old_failure],
            session_controls=[],
            recovery_cases=[],
            recovery_orphans=[],
            observed_at="2026-08-13T11:00:00+00:00",
        )
        reverse = _reduce_owner_inbox_snapshot(
            work_items=[old_failure, new_failure],
            session_controls=[],
            recovery_cases=[],
            recovery_orphans=[],
            observed_at="2026-08-13T11:00:00+00:00",
        )
        self.assertEqual(forward, reverse)
        self.assertEqual(
            forward["items"][0]["subject"]["work_item_id"],
            "work-item-old-failure",
        )

    def test_missing_required_store_fails_explicitly(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            inbox = OwnerInbox(
                operations_store=root / "operations.db",
                session_store=root / "session.db",
                recovery_store=root / "recovery.db",
            )
            with self.assertRaisesRegex(
                OperationsReadUnavailableError,
                "operations store is unavailable",
            ):
                inbox.snapshot(
                    observed_at="2026-08-13T11:00:00+00:00"
                )

    def test_unbound_session_actions_are_visible_but_unavailable(self) -> None:
        result = _reduce_owner_inbox_snapshot(
            work_items=[
                work_item(
                    status="waiting",
                    updated_at="2026-08-13T10:00:00+00:00",
                )
            ],
            session_controls=[],
            recovery_cases=[],
            recovery_orphans=[],
            observed_at="2026-08-13T11:00:00+00:00",
        )
        actions = {
            action["action_id"]: action
            for action in result["items"][0]["allowed_actions"]
        }
        self.assertTrue(actions["inspect-evidence"]["available"])
        self.assertFalse(actions["resume-session"]["available"])
        self.assertFalse(actions["cancel-session"]["available"])

    def test_session_index_drift_fails_closed(self) -> None:
        with test_workspace("sf300-session-index-drift") as workspace:
            session_store = create_session_store(
                workspace / "sessions.db"
            )
            with closing(sqlite3.connect(session_store)) as connection:
                connection.execute(
                    "UPDATE session_controls SET status = 'pending' "
                )
                connection.commit()

            inbox = OwnerInbox(
                operations_store=workspace / "unused-operations.db",
                session_store=session_store,
                recovery_store=workspace / "unused-recovery.db",
            )
            with self.assertRaisesRegex(
                OperationsReadUnavailableError,
                "source is invalid or unavailable",
            ) as raised:
                inbox._session_controls()
            self.assertIn(
                "indexed field changed: status",
                str(raised.exception.__cause__),
            )

    def test_repeated_cross_store_change_fails_closed(self) -> None:
        with test_workspace("sf300-cross-store-drift") as workspace:
            operations = workspace / "operations.db"
            FactoryOperationsBootstrap(operations).initialize()
            sessions = create_session_store(workspace / "sessions.db")
            recovery = create_recovery_store(workspace / "recovery.db")
            inbox = OwnerInbox(
                operations_store=operations,
                session_store=sessions,
                recovery_store=recovery,
            )
            read_sessions = inbox._session_controls

            def change_recovery_after_session_read() -> list[dict]:
                records = read_sessions()
                index = change_recovery_after_session_read.index
                identity = {
                    "kind": "missing-session-control",
                    "project_id": None,
                    "run_id": None,
                    "worker_session_id": None,
                    "workspace_id": None,
                    "tick_id": f"continuation-tick-{index:024x}",
                    "control_id": f"session-control-missing-{index}",
                    "status": "owner-required",
                    "reason": "continuation-session-control-missing",
                }
                body = {
                    "version": "1.0.0",
                    "orphan_id": (
                        "worker-recovery-orphan-"
                        + canonical_sha256(identity)[:24]
                    ),
                    **identity,
                    "observed_at": "2026-08-13T12:30:00+00:00",
                }
                orphan = {
                    **body,
                    "content_sha256": canonical_sha256(body),
                }
                with closing(sqlite3.connect(recovery)) as connection:
                    connection.execute(
                        """
                        INSERT INTO worker_recovery_orphans(
                            orphan_id, kind, status, record_json,
                            content_sha256, observed_at
                        ) VALUES(?, ?, ?, ?, ?, ?)
                        """,
                        (
                            orphan["orphan_id"],
                            orphan["kind"],
                            orphan["status"],
                            canonical_json(orphan),
                            orphan["content_sha256"],
                            orphan["observed_at"],
                        ),
                    )
                    connection.commit()
                change_recovery_after_session_read.index += 1
                return records

            change_recovery_after_session_read.index = 1
            inbox._session_controls = change_recovery_after_session_read
            with self.assertRaisesRegex(
                OperationsReadUnavailableError,
                "changed during three read attempts",
            ):
                inbox.snapshot(observed_at=OBSERVED_AT)

    def test_invalid_work_item_source_is_reported_unavailable(self) -> None:
        with test_workspace("sf300-invalid-work-item-source") as workspace:
            operations = workspace / "operations.db"
            FactoryOperationsBootstrap(operations).initialize()
            sessions = create_session_store(workspace / "sessions.db")
            recovery = create_recovery_store(workspace / "recovery.db")
            inbox = OwnerInbox(
                operations_store=operations,
                session_store=sessions,
                recovery_store=recovery,
            )
            with patch.object(
                WorkItemLedger,
                "list",
                side_effect=ProtocolError("corrupt work item"),
            ):
                with self.assertRaisesRegex(
                    OperationsReadUnavailableError,
                    "work-item store cannot be read",
                ):
                    inbox.snapshot(observed_at=OBSERVED_AT)


if __name__ == "__main__":
    unittest.main()
