from __future__ import annotations

import copy
import json
import sqlite3
import unittest
from pathlib import Path
from unittest.mock import patch

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    MappingCoordinationInspector,
    ProductFactoryRegistry,
    RunController,
    RuntimeCoordinationInspector,
    authorization_result_sha256,
    lifecycle_authorization_request_sha256,
    record_content_sha256,
    workspace_policy_authorization_request_sha256,
)
from elder_protocol.governance import (
    finalize_checkpoint,
    finalize_delegation,
    resolve_authority_bindings,
)
from elder_protocol.io import load_json
from elder_protocol.knowledge import KnowledgeStore
from elder_protocol.protocol import validate_protocol
from tests._support import tamper_sqlite_store, test_workspace
from tests.component import test_durable_dispatcher as durable_dispatcher_tests
from tests.component import (
    test_p4_5b_orchestration as orchestration_tests,
)


class FakeRepositoryInspector:
    def __init__(self, root: Path, revision: str):
        self.root = root.resolve()
        self.revision = revision
        self.workspace_exists = True

    def resolve_root(self, path: str | Path) -> Path:
        candidate = Path(path).resolve()
        if candidate != self.root:
            raise AssertionError(f"Unexpected repository root: {candidate}")
        return self.root

    def head(self, repository: str | Path) -> str:
        self.resolve_root(repository)
        return self.revision

    def commit_exists(self, repository: str | Path, revision: str) -> bool:
        self.resolve_root(repository)
        return revision == self.revision

    def observe_workspace(self, path: str | Path) -> dict:
        return {
            "path": str(Path(path).resolve()),
            "exists": self.workspace_exists,
            "is_directory": self.workspace_exists,
        }


class CommitDriftingRepositoryInspector(FakeRepositoryInspector):
    def __init__(self, root: Path, revision: str):
        super().__init__(root, revision)
        self.head_reads = 0

    def head(self, repository: str | Path) -> str:
        self.resolve_root(repository)
        self.head_reads += 1
        return self.revision if self.head_reads == 1 else "b" * 40


class CommitDriftingCoordinationInspector(MappingCoordinationInspector):
    def __init__(self, records: dict[str, dict]):
        super().__init__(records)
        self.lease_reads = 0

    def read_runtime_lease(self, record_id: str) -> dict:
        self.lease_reads += 1
        lease = super().read_runtime_lease(record_id)
        if self.lease_reads == 2:
            lease["status"] = "released"
            lease["released_at"] = "2026-08-11T01:04:00+00:00"
            lease["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in lease.items()
                    if key != "content_sha256"
                }
            )
        return lease


class RunControllerComponentTests(unittest.TestCase):
    maxDiff = None

    @staticmethod
    def _completed_dispatch(workspace: Path) -> tuple[dict, Path]:
        helper = durable_dispatcher_tests.DurableDispatcherComponentTests(
            methodName="runTest"
        )
        dispatcher, submission = helper._dispatcher(workspace)
        queued = dispatcher.submit(
            submission,
            at="2026-08-11T01:02:02+00:00",
        )
        dispatcher.claim_next(
            owner_id="dispatcher-one",
            at="2026-08-11T01:03:00+00:00",
            lease_seconds=60,
        )
        dispatcher.begin_execution(
            queued["dispatch_id"],
            owner_id="dispatcher-one",
            lease_generation=1,
            at="2026-08-11T01:03:01+00:00",
        )
        completed = dispatcher.record_response(
            queued["dispatch_id"],
            helper._response(
                submission["adapter_request"],
                disposition="accepted",
                responded_at="2026-08-11T01:03:02+00:00",
            ),
            owner_id="dispatcher-one",
            lease_generation=1,
            at="2026-08-11T01:03:02+00:00",
        )
        return completed, workspace / "operations.db"

    @staticmethod
    def _workspace_policy(product: dict, repository: Path) -> dict:
        source = load_json(ROOT / "factory" / "factory-contract.json")
        policy = {
            "version": "1.0.0",
            "id": "workspace-policy-product-one",
            "product_factory_id": product["product_factory"]["id"],
            "repository_root": str(repository.resolve()),
            "repository_binding_sha256": canonical_sha256(
                product["repository_binding"]
            ),
            "source_scope": "central-p3-policy-subsets",
            "source_repository": str(ROOT.resolve()),
            "source_path": "factory/factory-contract.json",
            "source_version": source["version"],
            "source_sha256": canonical_sha256(source),
            "git_policy": copy.deepcopy(source["git"]),
            "git_policy_sha256": canonical_sha256(source["git"]),
            "workspace_policy": copy.deepcopy(source["workspace"]),
            "workspace_policy_sha256": canonical_sha256(source["workspace"]),
            "authority": {
                "actor_identity_id": "founder",
                "role": "product-owner",
                "mode": "human-approval",
                "resource": "approval-decision",
                "action": "approve",
                "authority_ref": "authority:workspace-policy-product-one",
                "accountable_command_ref": (
                    "command:approve-workspace-policy-product-one"
                ),
                "request_sha256": "0" * 64,
                "decision": "allowed",
                "decision_ref": "decision:workspace-policy-product-one",
                "decided_at": "2026-08-11T01:03:10+00:00",
                "result_sha256": "0" * 64,
            },
            "content_sha256": "0" * 64,
        }
        policy["authority"]["request_sha256"] = (
            workspace_policy_authorization_request_sha256(policy)
        )
        policy["authority"]["result_sha256"] = authorization_result_sha256(
            policy["authority"]
        )
        policy["content_sha256"] = record_content_sha256(policy)
        return policy

    @staticmethod
    def _governance_chain(repository: Path, profile: dict) -> dict:
        fixture = load_json(
            ROOT / "tests" / "fixtures" / "p4_5a" / "fixture-a-low-risk.json"
        )
        parent = copy.deepcopy(fixture["parent_run"])
        parent.update(
            {
                "id": "product-one-parent-run",
                "project_id": "product-one",
                "work_item_id": "work-item-build-repair",
                "identity_id": "founder",
                "context_packet_id": "product-one-parent-context",
                "deadline": "2026-08-12T03:00:00+00:00",
                "started_at": "2026-08-11T01:03:11+00:00",
            }
        )
        delegation = copy.deepcopy(fixture["delegation"])
        delegation.update(
            {
                "delegation_id": "product-one-delegation",
                "project_id": "product-one",
                "work_item_id": "work-item-build-repair",
                "parent_run_id": parent["id"],
                "assigned_identity_id": (
                    "example-agentic-product-executor"
                ),
                "deadline": "2026-08-12T02:00:00+00:00",
                "expires_at": "2026-08-12T02:30:00+00:00",
            }
        )
        delegation = finalize_delegation(delegation)
        child = copy.deepcopy(fixture["child_run"])
        child.update(
            {
                "id": "product-one-child-run",
                "project_id": "product-one",
                "work_item_id": "work-item-build-repair",
                "identity_id": "example-agentic-product-executor",
                "parent_run_id": parent["id"],
                "delegation_id": delegation["delegation_id"],
                "context_packet_id": "product-one-delegated-context",
                "deadline": "2026-08-12T02:00:00+00:00",
                "started_at": "2026-08-11T01:03:12+00:00",
            }
        )
        protocol = validate_protocol()
        bindings = resolve_authority_bindings(
            profile,
            protocol["role-registry"],
            protocol["authority-matrix"],
        )
        source = repository / "src" / "component" / "runtime-source.md"
        source.parent.mkdir(parents=True, exist_ok=True)
        source.write_text("Bounded SF-105 runtime context.", encoding="utf-8")
        request = copy.deepcopy(fixture["context_request"])
        request.update(
            {
                "id": child["context_packet_id"],
                "project_id": "product-one",
                "work_item_id": "work-item-build-repair",
                "agent_identity_id": child["identity_id"],
                "assembled_by": (
                    "example-agentic-product-planning-agent"
                ),
                "delegation_id": delegation["delegation_id"],
                "repository_sources": [
                    {
                        "id": "runtime-source",
                        "location": "src/component/runtime-source.md",
                        "authority": "primary",
                        "required": True,
                    }
                ],
                "graph_limit": 0,
                "memory_limit": 0,
            }
        )
        packet = KnowledgeStore(
            repository / ".factory" / "unused-knowledge.db"
        ).assemble_context(
            request,
            base_dir=repository,
            delegation=delegation,
            parent_run=parent,
            authority_bindings=bindings,
            delegation_policy=protocol["delegation-policy"],
            profile=profile,
            role_registry=protocol["role-registry"],
            authority_matrix=protocol["authority-matrix"],
        )
        lease = {
            "version": "0.5.1",
            "id": "transition-command-queue-build-repair",
            "project_id": "product-one",
            "delegation_id": delegation["delegation_id"],
            "run_id": child["id"],
            "identity_id": child["identity_id"],
            "claimed_at": "2026-08-11T01:03:13+00:00",
            "expires_at": "2026-08-12T01:00:00+00:00",
            "released_at": None,
            "status": "active",
            "token_sha256": canonical_sha256("sf-105-lease-token"),
            "content_sha256": None,
        }
        lease["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in lease.items()
                if key != "content_sha256"
            }
        )
        return {
            "parent": parent,
            "delegation": delegation,
            "child": child,
            "context": packet,
            "bindings": bindings,
            "lease": lease,
        }

    def _controller_fixture(
        self,
        workspace: Path,
    ) -> tuple[RunController, dict, FakeRepositoryInspector]:
        dispatch, database = self._completed_dispatch(workspace)
        registry = ProductFactoryRegistry(database)
        product = registry.get("product-factory-product-one")
        repository = workspace / "product-one"
        profile = json.loads(
            (repository / ".elder" / "project-profile.json").read_text(
                encoding="utf-8"
            )
        )
        chain = self._governance_chain(repository, profile)
        revision = "a" * 40
        inspector = FakeRepositoryInspector(repository, revision)
        coordination = MappingCoordinationInspector(
            {
                "parent_runs": {
                    chain["parent"]["id"]: chain["parent"],
                },
                "delegations": {
                    chain["delegation"]["delegation_id"]: chain[
                        "delegation"
                    ],
                },
                "child_runs": {
                    chain["child"]["id"]: chain["child"],
                },
                "runtime_leases": {
                    chain["lease"]["id"]: chain["lease"],
                },
                "checkpoints": {},
            }
        )
        controller = RunController(
            database,
            repository_inspector=inspector,
            coordination_inspector=coordination,
        )
        controller.initialize()
        work = controller._ledger.get("work-item-build-repair")
        submission = {
            "version": "1.0.0",
            "dispatch_id": dispatch["dispatch_id"],
            "dispatch_sha256": dispatch["content_sha256"],
            "work_item": {
                "id": work["work_item"]["id"],
                "record_version": work["work_item"]["record_version"],
                "content_sha256": work["work_item"]["content_sha256"],
                "revision_id": work["current_revision"]["id"],
                "revision_entity_sha256": work["current_revision"][
                    "content_sha256"
                ],
                "revision_snapshot_sha256": work["current_revision"][
                    "payload"
                ]["snapshot_sha256"],
            },
            "product_factory": {
                "id": product["product_factory"]["id"],
                "profile_sha256": product["profile_binding"][
                    "content_sha256"
                ],
                "repository_root": str(repository.resolve()),
                "repository_binding_sha256": canonical_sha256(
                    product["repository_binding"]
                ),
                "worker_policy_sha256": canonical_sha256(
                    product["worker_policy"]
                ),
            },
            "workspace_policy": self._workspace_policy(product, repository),
            "context_packet": chain["context"],
            "parent_run": chain["parent"],
            "delegation": chain["delegation"],
            "child_run": chain["child"],
            "runtime_lease": chain["lease"],
            "authority_bindings": chain["bindings"],
            "source": {
                "repository_root": str(repository.resolve()),
                "revision": revision,
                "instruction_mode": "trusted-source-revision",
                "trusted_instruction_revision": revision,
            },
            "cleanup_policy": {
                "completed": "release",
                "cancelled": "release",
                "failed_or_lost": "state-dependent",
                "retain_evidence": True,
                "physical_delete": False,
            },
            "requested_at": "2026-08-11T01:04:00+00:00",
        }
        return controller, submission, inspector

    @staticmethod
    def _command(
        aggregate: dict,
        transition_ids: list[str],
        *,
        suffix: str,
        payload: dict,
        evidence_refs: dict,
        at: str,
    ) -> dict:
        mapping = {
            item["id"]: item
            for item in load_json(
                ROOT
                / "factory"
                / "operations"
                / "run-lifecycle-authority-mapping.json"
            )["transitions"]
            + load_json(
                ROOT
                / "factory"
                / "operations"
                / "run-lifecycle-authority-mapping.json"
            )["operations"]
        }
        command = {
            "version": "1.0.0",
            "command_id": f"run-command-{suffix}",
            "idempotency_key": f"sf-105:{suffix}",
            "operation": suffix,
            "run_id": aggregate["run"]["id"],
            "worker_session_id": aggregate["worker_session"]["id"],
            "workspace_id": aggregate["workspace"]["id"],
            "expected_versions": {
                "run": aggregate["run"]["record_version"],
                "worker_session": aggregate["worker_session"][
                    "record_version"
                ],
                "workspace": aggregate["workspace"]["record_version"],
            },
            "actor_identity_id": aggregate["initial_binding"]["created_by"],
            "session_generation": aggregate["worker_session"]["payload"][
                "session_generation"
            ],
            "authorizations": [],
            "evidence_refs": evidence_refs,
            "payload": payload,
            "reason": f"Apply SF-105 operation {suffix}.",
            "submitted_at": at,
            "payload_sha256": canonical_sha256(payload),
        }
        for transition_id in transition_ids:
            item = mapping[transition_id]
            authority = {
                "transition_id": transition_id,
                "role": item["role"],
                "mode": item["authority_mode"],
                "resource": item["resource"],
                "action": item["action"],
                "authority_ref": aggregate["initial_binding"][
                    "authority_ref"
                ],
                "accountable_command_ref": aggregate["initial_binding"][
                    "accountable_command_ref"
                ],
                "delegated_runtime_lease_ref": aggregate[
                    "initial_binding"
                ]["runtime_lease_ref"],
                "record_bindings": {
                    "run_sha256": aggregate["run"]["content_sha256"],
                    "worker_session_sha256": aggregate["worker_session"][
                        "content_sha256"
                    ],
                    "workspace_sha256": aggregate["workspace"][
                        "content_sha256"
                    ],
                },
                "request_sha256": "0" * 64,
                "decision": "allowed",
                "decision_ref": f"decision:{suffix}:{transition_id}",
                "decided_at": at,
                "result_sha256": "0" * 64,
            }
            authority["request_sha256"] = (
                lifecycle_authorization_request_sha256(command, authority)
            )
            authority["result_sha256"] = authorization_result_sha256(
                authority
            )
            command["authorizations"].append(authority)
        return command

    def _running_fixture(
        self,
        workspace: Path,
    ) -> tuple[RunController, dict, FakeRepositoryInspector]:
        controller, submission, inspector = self._controller_fixture(
            workspace
        )
        aggregate = controller.bind_start(
            submission,
            at="2026-08-11T01:04:01+00:00",
        )
        steps = (
            (
                ["workspace-provision"],
                "matrix-workspace-provision",
                {
                    "repository": aggregate["initial_binding"][
                        "repository_root"
                    ],
                    "base_revision": aggregate["initial_binding"][
                        "base_revision"
                    ],
                },
                {},
                "2026-08-11T01:05:00+00:00",
            ),
            (
                ["workspace-ready"],
                "matrix-workspace-ready",
                {
                    "path": aggregate["initial_binding"]["workspace_path"],
                    "isolation_mode": "planned-git-worktree",
                },
                {"workspace verification": "evidence:matrix-workspace"},
                "2026-08-11T01:06:00+00:00",
            ),
            (
                ["worker-session-start"],
                "matrix-session-start",
                {
                    "run_id": aggregate["run"]["id"],
                    "worker_adapter": aggregate["initial_binding"][
                        "worker_adapter_id"
                    ],
                },
                {},
                "2026-08-11T01:07:00+00:00",
            ),
            (
                ["worker-session-activate"],
                "matrix-session-activate",
                {"external_session_ref": "codex-thread:matrix"},
                {"worker acknowledgement": "evidence:matrix-ack"},
                "2026-08-11T01:08:00+00:00",
            ),
        )
        for transition_ids, suffix, payload, evidence, at in steps:
            result = controller.apply(
                self._command(
                    aggregate,
                    transition_ids,
                    suffix=suffix,
                    payload=payload,
                    evidence_refs=evidence,
                    at=at,
                ),
                at=at,
            )
            self.assertEqual(result["status"], "applied")
            aggregate = controller.get(aggregate["run"]["id"])
        prepare = self._command(
            aggregate,
            ["run-claim", "workspace-bind", "run-start"],
            suffix="matrix-prepare-start",
            payload={
                "authority_ref": aggregate["initial_binding"][
                    "authority_ref"
                ],
                "run_id": aggregate["run"]["id"],
                "worker_session_id": aggregate["worker_session"]["id"],
            },
            evidence_refs={
                "active lease": "lease:transition-command-queue-build-repair"
            },
            at="2026-08-11T01:09:00+00:00",
        )
        pending = controller.prepare_work_item_start(
            prepare,
            at="2026-08-11T01:09:00+00:00",
        )
        controller._transitions.apply(
            pending["result"]["transition_command"],
            at="2026-08-11T01:09:01+00:00",
        )
        controller.confirm_work_item_start(
            prepare["command_id"],
            at="2026-08-11T01:09:02+00:00",
        )
        return controller, controller.get(aggregate["run"]["id"]), inspector

    @staticmethod
    def _clone_controller(
        controller: RunController,
        target: Path,
    ) -> RunController:
        source = sqlite3.connect(controller.path)
        destination = sqlite3.connect(target)
        try:
            source.backup(destination)
            destination.commit()
        finally:
            destination.close()
            source.close()
        return RunController(
            target,
            repository_inspector=controller._repository,
            coordination_inspector=MappingCoordinationInspector(
                controller._coordination.records
            ),
        )

    def test_bind_start_replays_exactly_and_survives_restart(self) -> None:
        with test_workspace("sf-105-bind") as workspace:
            controller, submission, inspector = self._controller_fixture(
                workspace
            )
            bound = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            replay = controller.bind_start(
                submission,
                at="2026-08-11T01:04:02+00:00",
            )
            self.assertEqual(bound["run"]["status"], "queued")
            self.assertEqual(bound["worker_session"]["status"], "prepared")
            self.assertEqual(bound["workspace"]["status"], "requested")
            self.assertEqual(
                replay["initial_binding"],
                bound["initial_binding"],
            )
            self.assertEqual(
                [item["status"] for item in controller.histories(
                    bound["run"]["id"]
                )["run"]],
                ["prepared", "queued"],
            )

            reopened = RunController(
                workspace / "operations.db",
                repository_inspector=inspector,
                coordination_inspector=controller._coordination,
            )
            reopened.initialize()
            self.assertEqual(
                reopened.get(bound["run"]["id"]),
                controller.get(bound["run"]["id"]),
            )
            self.assertEqual(reopened.status()["counts"]["factory_runs"], 1)

            inspector.revision = "b" * 40
            drifted_replay = controller.bind_start(
                submission,
                at="2026-08-11T01:04:03+00:00",
            )
            self.assertEqual(
                drifted_replay["initial_binding"],
                bound["initial_binding"],
            )
            changed = copy.deepcopy(submission)
            changed["requested_at"] = "2026-08-11T01:04:01+00:00"
            with self.assertRaisesRegex(
                ProtocolError,
                "identifier collision",
            ):
                controller.bind_start(
                    changed,
                    at="2026-08-11T01:04:04+00:00",
                )

    def test_runtime_coordination_inspector_reads_canonical_p45_store(
        self,
    ) -> None:
        with test_workspace("sf-105-runtime-inspector") as workspace:
            helper = orchestration_tests.P45BOrchestrationComponentTests(
                methodName="runTest"
            )
            helper.setUp()
            runtime = helper._submitted_runtime(workspace)
            claim = helper._claim(runtime)
            runtime.record_checkpoint(
                helper.fixture["checkpoint"],
                lease_token=claim["lease_token"],
                **helper._runtime_inputs(),
            )
            inspector = RuntimeCoordinationInspector(
                runtime,
                helper.fixture["delegation"]["delegation_id"],
            )
            snapshot = runtime.snapshot(
                helper.fixture["delegation"]["delegation_id"]
            )
            self.assertEqual(
                inspector.read_parent_run(
                    helper.fixture["parent_run"]["id"]
                ),
                snapshot["parent_run"],
            )
            self.assertEqual(
                inspector.read_delegation(
                    helper.fixture["delegation"]["delegation_id"]
                ),
                snapshot["delegation"],
            )
            self.assertEqual(
                inspector.read_child_run(
                    helper.fixture["child_run"]["id"]
                ),
                snapshot["child_run"],
            )
            self.assertEqual(
                inspector.read_runtime_lease(snapshot["lease"]["id"]),
                snapshot["lease"],
            )
            self.assertEqual(
                inspector.read_checkpoint(
                    helper.fixture["checkpoint"]["id"]
                ),
                helper.fixture["checkpoint"],
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "bound delegation",
            ):
                inspector.read_child_run("wrong-child-run")

    def test_bind_start_rejects_repository_and_lease_drift(self) -> None:
        with test_workspace("sf-105-bind-drift") as workspace:
            controller, submission, inspector = self._controller_fixture(
                workspace
            )
            inspector.revision = "b" * 40
            with self.assertRaisesRegex(
                ProtocolError,
                "current repository HEAD",
            ):
                controller.bind_start(
                    submission,
                    at="2026-08-11T01:04:01+00:00",
                )

        with test_workspace("sf-105-lease-drift") as workspace:
            controller, submission, _ = self._controller_fixture(workspace)
            lease = controller._coordination.records["runtime_leases"][
                submission["runtime_lease"]["id"]
            ]
            lease["status"] = "released"
            lease["released_at"] = "2026-08-11T01:04:00+00:00"
            lease["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in lease.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "changed before commit",
            ):
                controller.bind_start(
                    submission,
                    at="2026-08-11T01:04:01+00:00",
                )

        with test_workspace("sf-105-instruction-drift") as workspace:
            controller, submission, _ = self._controller_fixture(workspace)
            submission["source"]["trusted_instruction_revision"] = "b" * 40
            with self.assertRaisesRegex(
                ProtocolError,
                "trusted-source-revision",
            ):
                controller.bind_start(
                    submission,
                    at="2026-08-11T01:04:01+00:00",
                )

        with test_workspace("sf-105-missing-coordinator") as workspace:
            controller, submission, inspector = self._controller_fixture(
                workspace
            )
            unbound = RunController(
                workspace / "operations.db",
                repository_inspector=inspector,
            )
            unbound.initialize()
            with self.assertRaisesRegex(
                ProtocolError,
                "CoordinationInspector",
            ):
                unbound.bind_start(
                    submission,
                    at="2026-08-11T01:04:01+00:00",
                )

    def test_bind_start_rechecks_repository_and_lease_at_commit(self) -> None:
        with test_workspace("sf-105-commit-race") as workspace:
            controller, submission, inspector = self._controller_fixture(
                workspace
            )
            repository_race = CommitDriftingRepositoryInspector(
                inspector.root,
                inspector.revision,
            )
            controller._repository = repository_race
            with self.assertRaisesRegex(
                ProtocolError,
                "changed before commit",
            ):
                controller.bind_start(
                    submission,
                    at="2026-08-11T01:04:01+00:00",
                )
            with controller._connection() as connection:
                self.assertEqual(
                    connection.execute(
                        "SELECT COUNT(*) FROM factory_runs"
                    ).fetchone()[0],
                    0,
                )

            controller._repository = inspector
            controller._coordination = CommitDriftingCoordinationInspector(
                controller._coordination.records
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "changed before commit",
            ):
                controller.bind_start(
                    submission,
                    at="2026-08-11T01:04:01+00:00",
                )
            with controller._connection() as connection:
                self.assertEqual(
                    connection.execute(
                        "SELECT COUNT(*) FROM factory_runs"
                    ).fetchone()[0],
                    0,
                )

    def test_binding_rejection_matrix_is_fail_closed(self) -> None:
        with test_workspace("sf-105-binding-matrix") as workspace:
            controller, submission, _ = self._controller_fixture(workspace)
            mutations = {
                "product factory": lambda item: item["product_factory"].update(
                    {"id": "product-factory-missing"}
                ),
                "profile": lambda item: item["product_factory"].update(
                    {"profile_sha256": "0" * 64}
                ),
                "worker policy": lambda item: item["product_factory"].update(
                    {"worker_policy_sha256": "0" * 64}
                ),
                "work item": lambda item: item["work_item"].update(
                    {"content_sha256": "0" * 64}
                ),
                "revision": lambda item: item["work_item"].update(
                    {"revision_entity_sha256": "0" * 64}
                ),
                "authority": lambda item: item["authority_bindings"][
                    "grants"
                ].clear(),
                "context": lambda item: item["context_packet"].update(
                    {"work_item_id": "work-item-other"}
                ),
                "parent run": lambda item: item["parent_run"].update(
                    {"identity_id": "identity-other"}
                ),
                "delegation": lambda item: item["delegation"].update(
                    {"assigned_identity_id": "identity-other"}
                ),
                "child run": lambda item: item["child_run"].update(
                    {"identity_id": "identity-other"}
                ),
                "lease": lambda item: item["runtime_lease"].update(
                    {"status": "released"}
                ),
            }
            for label, mutate in mutations.items():
                with self.subTest(label=label):
                    changed = copy.deepcopy(submission)
                    mutate(changed)
                    with self.assertRaises(ProtocolError):
                        controller.bind_start(
                            changed,
                            at="2026-08-11T01:04:01+00:00",
                        )
            with controller._connection() as connection:
                self.assertEqual(
                    connection.execute(
                        "SELECT COUNT(*) FROM factory_runs"
                    ).fetchone()[0],
                    0,
                )

    def test_workspace_and_session_lifecycle_is_durable(self) -> None:
        with test_workspace("sf-105-lifecycle") as workspace:
            controller, submission, _ = self._controller_fixture(workspace)
            aggregate = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            command = self._command(
                aggregate,
                ["workspace-provision"],
                suffix="workspace-provision",
                payload={
                    "repository": aggregate["initial_binding"][
                        "repository_root"
                    ],
                    "base_revision": aggregate["initial_binding"][
                        "base_revision"
                    ],
                },
                evidence_refs={},
                at="2026-08-11T01:05:00+00:00",
            )
            result = controller.apply(
                command,
                at="2026-08-11T01:05:00+00:00",
            )
            self.assertEqual(result["status"], "applied")
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(
                aggregate["workspace"]["status"],
                "provisioning",
            )

            ready = self._command(
                aggregate,
                ["workspace-ready"],
                suffix="workspace-ready",
                payload={
                    "path": aggregate["initial_binding"]["workspace_path"],
                    "isolation_mode": "planned-git-worktree",
                },
                evidence_refs={
                    "workspace verification": "evidence:workspace-ready"
                },
                at="2026-08-11T01:06:00+00:00",
            )
            self.assertEqual(
                controller.apply(
                    ready,
                    at="2026-08-11T01:06:00+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            start = self._command(
                aggregate,
                ["worker-session-start"],
                suffix="worker-session-start",
                payload={
                    "run_id": aggregate["run"]["id"],
                    "worker_adapter": aggregate["initial_binding"][
                        "worker_adapter_id"
                    ],
                },
                evidence_refs={},
                at="2026-08-11T01:07:00+00:00",
            )
            self.assertEqual(
                controller.apply(
                    start,
                    at="2026-08-11T01:07:00+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            null_generation = self._command(
                aggregate,
                ["worker-session-activate"],
                suffix="worker-session-null-generation",
                payload={"external_session_ref": "codex-thread:null-generation"},
                evidence_refs={
                    "worker acknowledgement": "evidence:null-generation"
                },
                at="2026-08-11T01:07:30+00:00",
            )
            null_generation["session_generation"] = None
            null_generation["authorizations"][0]["request_sha256"] = (
                lifecycle_authorization_request_sha256(
                    null_generation,
                    null_generation["authorizations"][0],
                )
            )
            null_generation["authorizations"][0]["result_sha256"] = (
                authorization_result_sha256(
                    null_generation["authorizations"][0]
                )
            )
            rejected_generation = controller.apply(
                null_generation,
                at="2026-08-11T01:07:30+00:00",
            )
            self.assertEqual(rejected_generation["status"], "rejected")
            self.assertIn(
                "non-null session generation",
                rejected_generation["result"]["reason"],
            )
            activate = self._command(
                aggregate,
                ["worker-session-activate"],
                suffix="worker-session-activate",
                payload={"external_session_ref": "codex-thread:opaque-one"},
                evidence_refs={
                    "worker acknowledgement": "evidence:worker-ack"
                },
                at="2026-08-11T01:08:00+00:00",
            )
            applied = controller.apply(
                activate,
                at="2026-08-11T01:08:00+00:00",
            )
            self.assertEqual(applied["status"], "applied")
            self.assertEqual(controller.apply(activate), applied)
            self.assertEqual(
                controller.get(aggregate["run"]["id"])[
                    "worker_session"
                ]["status"],
                "active",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            prepare = self._command(
                aggregate,
                ["run-claim", "workspace-bind", "run-start"],
                suffix="prepare-work-item-start",
                payload={
                    "authority_ref": aggregate["initial_binding"][
                        "authority_ref"
                    ],
                    "run_id": aggregate["run"]["id"],
                    "worker_session_id": aggregate["worker_session"]["id"],
                },
                evidence_refs={
                    "active lease": "lease:transition-command-queue-build-repair"
                },
                at="2026-08-11T01:09:00+00:00",
            )
            pending = controller.prepare_work_item_start(
                prepare,
                at="2026-08-11T01:09:00+00:00",
            )
            self.assertEqual(pending["status"], "pending-external")
            aggregate = controller.get(aggregate["run"]["id"])
            bypass = self._command(
                aggregate,
                ["run-start"],
                suffix="generic-run-start-bypass",
                payload={
                    "worker_session_id": aggregate["worker_session"]["id"],
                },
                evidence_refs={},
                at="2026-08-11T01:09:00+00:00",
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "reserved",
            ):
                controller.apply(
                    bypass,
                    at="2026-08-11T01:09:00+00:00",
                )
            transition_record = controller._transitions.apply(
                pending["result"]["transition_command"],
                at="2026-08-11T01:09:01+00:00",
            )
            self.assertTrue(transition_record["decision"]["accepted"])
            confirmed = controller.confirm_work_item_start(
                prepare["command_id"],
                at="2026-08-11T01:09:02+00:00",
            )
            self.assertEqual(confirmed["status"], "confirmed")
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(aggregate["run"]["status"], "running")
            self.assertEqual(aggregate["workspace"]["status"], "in-use")
            fail = self._command(
                aggregate,
                [
                    "run-fail",
                    "worker-session-fail",
                    "workspace-quarantine",
                ],
                suffix="terminal-failure",
                payload={},
                evidence_refs={
                    "failure evidence": "evidence:worker-failure",
                    "quarantine reason": "evidence:workspace-retained",
                },
                at="2026-08-11T01:10:00+00:00",
            )
            self.assertEqual(
                controller.apply(
                    fail,
                    at="2026-08-11T01:10:00+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(aggregate["run"]["status"], "failed")
            self.assertEqual(aggregate["worker_session"]["status"], "failed")
            self.assertEqual(
                aggregate["workspace"]["status"],
                "quarantined",
            )
            self.assertEqual(aggregate["cleanup_state"], "retained")
            child = controller._coordination.records["child_runs"][
                aggregate["initial_binding"]["elder_child_run_id"]
            ]
            child["status"] = "failed"
            child["completed_at"] = "2026-08-11T01:10:01+00:00"
            observation = {
                "version": "1.0.0",
                "run_id": aggregate["run"]["id"],
                "observation_version": 2,
                "elder_run_id": child["id"],
                "elder_status": child["status"],
                "cancellation_status": child["cancellation_status"],
                "elder_run_sha256": canonical_sha256(child),
                "source_ref": f"coordination-run:{child['id']}",
                "reconciliation_state": "current",
                "reason": "Canonical Elder child run observed failed.",
                "causation_command_id": fail["command_id"],
                "observed_at": "2026-08-11T01:10:01+00:00",
                "content_sha256": None,
            }
            observation["content_sha256"] = record_content_sha256(
                observation
            )
            controller.record_elder_observation(observation)
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(
                aggregate["elder_reconciliation_state"],
                "current",
            )

            release = self._command(
                aggregate,
                ["workspace-release"],
                suffix="workspace-release-after-failure",
                payload={},
                evidence_refs={
                    "retention decision": "decision:release-retained-workspace"
                },
                at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(
                controller.apply(
                    release,
                    at="2026-08-11T01:11:00+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(aggregate["cleanup_state"], "pending")
            released = self._command(
                aggregate,
                ["workspace-released"],
                suffix="workspace-release-confirmation",
                payload={},
                evidence_refs={
                    "release confirmation": "evidence:workspace-release"
                },
                at="2026-08-11T01:12:00+00:00",
            )
            self.assertEqual(
                controller.apply(
                    released,
                    at="2026-08-11T01:12:00+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(aggregate["workspace"]["status"], "released")
            self.assertEqual(aggregate["cleanup_state"], "complete")

    def test_illegal_transition_is_persisted_and_replayed(self) -> None:
        with test_workspace("sf-105-rejection") as workspace:
            controller, submission, _ = self._controller_fixture(workspace)
            aggregate = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            command = self._command(
                aggregate,
                ["workspace-ready"],
                suffix="illegal-workspace-ready",
                payload={
                    "path": aggregate["initial_binding"]["workspace_path"],
                    "isolation_mode": "planned-git-worktree",
                },
                evidence_refs={
                    "workspace verification": "evidence:workspace-ready"
                },
                at="2026-08-11T01:05:00+00:00",
            )
            rejected = controller.apply(
                command,
                at="2026-08-11T01:05:00+00:00",
            )
            self.assertEqual(rejected["status"], "rejected")
            self.assertIn(
                "Illegal workspace transition",
                rejected["result"]["reason"],
            )
            self.assertEqual(controller.apply(command), rejected)
            self.assertEqual(
                controller.get(aggregate["run"]["id"])["workspace"][
                    "status"
                ],
                "requested",
            )
            child = controller._coordination.records["child_runs"][
                aggregate["initial_binding"]["elder_child_run_id"]
            ]
            child["scope"] = [*child["scope"], "src/unauthorized"]
            provision = self._command(
                aggregate,
                ["workspace-provision"],
                suffix="child-lineage-drift",
                payload={
                    "repository": aggregate["initial_binding"][
                        "repository_root"
                    ],
                    "base_revision": aggregate["initial_binding"][
                        "base_revision"
                    ],
                },
                evidence_refs={},
                at="2026-08-11T01:06:00+00:00",
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "immutable authority",
            ):
                controller.apply(
                    provision,
                    at="2026-08-11T01:06:00+00:00",
                )

    def test_complete_canonical_lifecycle_transition_matrix(self) -> None:
        with test_workspace("sf-105-transition-matrix") as workspace:
            base, aggregate, _ = self._running_fixture(workspace)
            run_id = aggregate["run"]["id"]

            wait_pause = self._clone_controller(
                base,
                workspace / "wait-pause.db",
            )
            current = wait_pause.get(run_id)
            for transitions, suffix, payload, evidence, at in (
                (
                    ["run-wait", "worker-session-wait"],
                    "matrix-wait",
                    {"waiting_reason": "owner-decision"},
                    {"waiting reason": "decision:owner-input"},
                    "2026-08-11T01:10:00+00:00",
                ),
                (
                    ["run-start", "worker-session-activate"],
                    "matrix-resume-wait",
                    {
                        "worker_session_id": current["worker_session"]["id"],
                        "external_session_ref": "codex-thread:matrix",
                    },
                    {"worker acknowledgement": "evidence:resume-wait"},
                    "2026-08-11T01:11:00+00:00",
                ),
            ):
                result = wait_pause.apply(
                    self._command(
                        current,
                        transitions,
                        suffix=suffix,
                        payload=payload,
                        evidence_refs=evidence,
                        at=at,
                    ),
                    at=at,
                )
                self.assertEqual(result["status"], "applied", result)
                current = wait_pause.get(run_id)
            paused = wait_pause.apply(
                self._command(
                    current,
                    ["run-pause", "worker-session-pause"],
                    suffix="matrix-pause",
                    payload={},
                    evidence_refs={"pause reason": "decision:pause"},
                    at="2026-08-11T01:12:00+00:00",
                ),
                at="2026-08-11T01:12:00+00:00",
            )
            self.assertEqual(paused["status"], "applied")
            current = wait_pause.get(run_id)
            resumed = wait_pause.apply(
                self._command(
                    current,
                    ["run-start", "worker-session-activate"],
                    suffix="matrix-resume-pause",
                    payload={
                        "worker_session_id": current["worker_session"]["id"],
                        "external_session_ref": "codex-thread:matrix",
                    },
                    evidence_refs={
                        "worker acknowledgement": "evidence:resume-pause"
                    },
                    at="2026-08-11T01:13:00+00:00",
                ),
                at="2026-08-11T01:13:00+00:00",
            )
            self.assertEqual(resumed["status"], "applied")

            cancelled = self._clone_controller(
                base,
                workspace / "cancelled.db",
            )
            current = cancelled.get(run_id)
            result = cancelled.apply(
                self._command(
                    current,
                    ["run-cancel-request", "worker-session-cancel"],
                    suffix="matrix-cancel-request",
                    payload={},
                    evidence_refs={
                        "cancellation reason": "decision:cancel-run"
                    },
                    at="2026-08-11T01:10:00+00:00",
                ),
                at="2026-08-11T01:10:00+00:00",
            )
            self.assertEqual(result["status"], "applied")
            current = cancelled.get(run_id)
            result = cancelled.apply(
                self._command(
                    current,
                    ["run-cancelled", "worker-session-cancelled"],
                    suffix="matrix-cancel-confirm",
                    payload={},
                    evidence_refs={
                        "worker cancellation confirmation": (
                            "evidence:worker-cancelled"
                        )
                    },
                    at="2026-08-11T01:11:00+00:00",
                ),
                at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(result["status"], "applied")
            current = cancelled.get(run_id)
            for transition, suffix, evidence, at in (
                (
                    "workspace-release",
                    "matrix-cancel-release",
                    {"retention decision": "decision:release-cancelled"},
                    "2026-08-11T01:12:00+00:00",
                ),
                (
                    "workspace-released",
                    "matrix-cancel-released",
                    {"release confirmation": "evidence:released"},
                    "2026-08-11T01:13:00+00:00",
                ),
            ):
                result = cancelled.apply(
                    self._command(
                        current,
                        [transition],
                        suffix=suffix,
                        payload={},
                        evidence_refs=evidence,
                        at=at,
                    ),
                    at=at,
                )
                self.assertEqual(result["status"], "applied")
                current = cancelled.get(run_id)
            self.assertEqual(current["cleanup_state"], "complete")

            completed = self._clone_controller(
                base,
                workspace / "completed.db",
            )
            current = completed.get(run_id)
            checkpoint = finalize_checkpoint(
                {
                    "version": "0.5.1",
                    "id": "matrix-checkpoint",
                    "project_id": current["run"]["project_id"],
                    "delegation_id": current["initial_binding"][
                        "elder_delegation_id"
                    ],
                    "run_id": current["initial_binding"][
                        "elder_child_run_id"
                    ],
                    "sequence": 1,
                    "action_sequence": 1,
                    "status": "running",
                    "completed_scope": [],
                    "remaining_scope": ["src/component"],
                    "evidence_refs": [],
                    "budget_consumed": {
                        "token_limit": 10,
                        "cost_limit_usd": 0,
                        "tool_call_limit": 1,
                        "elapsed_seconds_limit": 10,
                    },
                    "previous_checkpoint_sha256": None,
                    "created_at": "2026-08-11T01:10:00+00:00",
                }
            )
            completed._coordination.records["checkpoints"][
                checkpoint["id"]
            ] = checkpoint
            worker_observation = {
                "id": "matrix-observation",
                "checkpoint_id": checkpoint["id"],
                "checkpoint_sha256": checkpoint["content_sha256"],
            }
            checkpoint_reference = {
                "version": "1.0.0",
                "id": "checkpoint-reference-matrix",
                "run_id": run_id,
                "worker_session_id": current["worker_session"]["id"],
                "elder_run_id": current["initial_binding"][
                    "elder_child_run_id"
                ],
                "elder_run_sha256": current["initial_binding"][
                    "elder_child_run_sha256"
                ],
                "project_id": current["run"]["project_id"],
                "delegation_id": current["initial_binding"][
                    "elder_delegation_id"
                ],
                "session_generation": 1,
                "checkpoint_id": checkpoint["id"],
                "checkpoint_sha256": checkpoint["content_sha256"],
                "adapter_cursor": "matrix-cursor",
                "observation_sequence": 1,
                "checkpoint_sequence": 1,
                "previous_checkpoint_sha256": None,
                "worker_observation_id": worker_observation["id"],
                "worker_observation_sha256": canonical_sha256(
                    worker_observation
                ),
                "recorded_at": "2026-08-11T01:10:00+00:00",
                "content_sha256": None,
            }
            checkpoint_reference["content_sha256"] = record_content_sha256(
                checkpoint_reference
            )
            evidence_bundle = {
                "version": "1.0.0",
                "id": "artifact-reference-matrix-evidence",
                "run_id": run_id,
                "artifact_sha256": "c" * 64,
                "artifact_type": "evidence-bundle",
                "provenance_ref": "evidence-bundle:matrix",
                "status": "verified",
                "target_locator": None,
                "session_generation": 1,
                "recorded_at": "2026-08-11T01:10:01+00:00",
                "content_sha256": None,
            }
            evidence_bundle["content_sha256"] = record_content_sha256(
                evidence_bundle
            )
            checkpoint_result = completed.record_checkpoint_reference(
                self._command(
                    current,
                    ["checkpoint-reference"],
                    suffix="matrix-checkpoint-reference",
                    payload={},
                    evidence_refs={},
                    at=checkpoint_reference["recorded_at"],
                ),
                checkpoint_reference,
                checkpoint=checkpoint,
                worker_observation=worker_observation,
                at=checkpoint_reference["recorded_at"],
            )
            self.assertEqual(checkpoint_result["status"], "applied")
            current = completed.get(run_id)
            artifact_result = completed.record_artifact_reference(
                self._command(
                    current,
                    ["artifact-reference"],
                    suffix="matrix-artifact-reference",
                    payload={},
                    evidence_refs={},
                    at=evidence_bundle["recorded_at"],
                ),
                evidence_bundle,
                at=evidence_bundle["recorded_at"],
            )
            self.assertEqual(artifact_result["status"], "applied")
            current = completed.get(run_id)
            result = completed.apply(
                self._command(
                    current,
                    ["run-validate", "worker-session-complete"],
                    suffix="matrix-validate",
                    payload={},
                    evidence_refs={
                        "checkpoint": "checkpoint-ref:matrix",
                        "evidence records": "evidence:matrix-records",
                        "final checkpoint": "checkpoint-ref:matrix-final",
                    },
                    at="2026-08-11T01:11:00+00:00",
                ),
                at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(result["status"], "applied")
            current = completed.get(run_id)
            result = completed.apply(
                self._command(
                    current,
                    ["run-complete"],
                    suffix="matrix-complete",
                    payload={},
                    evidence_refs={
                        "validated evidence bundle": (
                            "evidence-bundle:matrix"
                        )
                    },
                    at="2026-08-11T01:12:00+00:00",
                ),
                at="2026-08-11T01:12:00+00:00",
            )
            self.assertEqual(result["status"], "applied")
            completed_aggregate = completed.get(run_id)
            self.assertEqual(
                completed_aggregate["run"]["status"],
                "completed",
            )
            self.assertEqual(
                completed_aggregate["cleanup_state"],
                "pending",
            )
            self.assertEqual(completed.status()["pending_cleanup"], 1)

            lost = self._clone_controller(base, workspace / "lost.db")
            current = lost.get(run_id)
            result = lost.apply(
                self._command(
                    current,
                    ["run-lost", "worker-session-lost"],
                    suffix="matrix-lost",
                    payload={
                        "lease_ref": current["initial_binding"][
                            "runtime_lease_ref"
                        ]
                    },
                    evidence_refs={
                        "lease or worker loss evidence": "evidence:run-lost",
                        "lease loss evidence": "evidence:session-lost",
                    },
                    at="2026-08-11T01:10:00+00:00",
                ),
                at="2026-08-11T01:10:00+00:00",
            )
            self.assertEqual(result["status"], "applied")

            failed_workspace = self._clone_controller(
                base,
                workspace / "workspace-failed.db",
            )
            current = failed_workspace.get(run_id)
            result = failed_workspace.apply(
                self._command(
                    current,
                    ["workspace-fail"],
                    suffix="matrix-workspace-fail",
                    payload={},
                    evidence_refs={
                        "failure evidence": "evidence:workspace-failed"
                    },
                    at="2026-08-11T01:10:00+00:00",
                ),
                at="2026-08-11T01:10:00+00:00",
            )
            self.assertEqual(result["status"], "applied")
            current = failed_workspace.get(run_id)
            self.assertEqual(current["cleanup_state"], "not-required")
            result = failed_workspace.apply(
                self._command(
                    current,
                    ["run-fail", "worker-session-fail"],
                    suffix="matrix-fail-after-workspace",
                    payload={},
                    evidence_refs={
                        "failure evidence": "evidence:run-session-failed"
                    },
                    at="2026-08-11T01:11:00+00:00",
                ),
                at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(result["status"], "applied")
            self.assertEqual(
                failed_workspace.get(run_id)["cleanup_state"],
                "failed",
            )

    def test_checkpoint_artifact_detach_and_recovery_are_generation_bound(
        self,
    ) -> None:
        with test_workspace("sf-105-recovery") as workspace:
            controller, submission, _ = self._controller_fixture(workspace)
            aggregate = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            for suffix, transition_ids, payload, evidence, at in (
                (
                    "workspace-provision-recovery",
                    ["workspace-provision"],
                    {
                        "repository": aggregate["initial_binding"][
                            "repository_root"
                        ],
                        "base_revision": aggregate["initial_binding"][
                            "base_revision"
                        ],
                    },
                    {},
                    "2026-08-11T01:05:00+00:00",
                ),
            ):
                result = controller.apply(
                    self._command(
                        aggregate,
                        transition_ids,
                        suffix=suffix,
                        payload=payload,
                        evidence_refs=evidence,
                        at=at,
                    ),
                    at=at,
                )
                self.assertEqual(result["status"], "applied")
                aggregate = controller.get(aggregate["run"]["id"])
            for suffix, transition_ids, payload, evidence, at in (
                (
                    "workspace-ready-recovery",
                    ["workspace-ready"],
                    {
                        "path": aggregate["initial_binding"][
                            "workspace_path"
                        ],
                        "isolation_mode": "planned-git-worktree",
                    },
                    {
                        "workspace verification": (
                            "evidence:workspace-ready-recovery"
                        )
                    },
                    "2026-08-11T01:06:00+00:00",
                ),
                (
                    "worker-session-start-recovery",
                    ["worker-session-start"],
                    {
                        "run_id": aggregate["run"]["id"],
                        "worker_adapter": aggregate["initial_binding"][
                            "worker_adapter_id"
                        ],
                    },
                    {},
                    "2026-08-11T01:07:00+00:00",
                ),
            ):
                result = controller.apply(
                    self._command(
                        aggregate,
                        transition_ids,
                        suffix=suffix,
                        payload=payload,
                        evidence_refs=evidence,
                        at=at,
                    ),
                    at=at,
                )
                self.assertEqual(result["status"], "applied")
                aggregate = controller.get(aggregate["run"]["id"])
            activate = self._command(
                aggregate,
                ["worker-session-activate"],
                suffix="worker-session-activate-recovery",
                payload={"external_session_ref": "codex-thread:recovery-one"},
                evidence_refs={
                    "worker acknowledgement": "evidence:worker-ack-recovery"
                },
                at="2026-08-11T01:08:00+00:00",
            )
            self.assertEqual(
                controller.apply(
                    activate,
                    at="2026-08-11T01:08:00+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])

            checkpoint = finalize_checkpoint(
                {
                    "version": "0.5.1",
                    "id": "product-one-checkpoint-1",
                    "project_id": "product-one",
                    "delegation_id": aggregate["initial_binding"][
                        "elder_delegation_id"
                    ],
                    "run_id": aggregate["initial_binding"][
                        "elder_child_run_id"
                    ],
                    "sequence": 1,
                    "action_sequence": 1,
                    "status": "running",
                    "completed_scope": [],
                    "remaining_scope": ["src/component"],
                    "evidence_refs": [],
                    "budget_consumed": {
                        "token_limit": 10,
                        "cost_limit_usd": 0,
                        "tool_call_limit": 1,
                        "elapsed_seconds_limit": 10,
                    },
                    "previous_checkpoint_sha256": None,
                    "created_at": "2026-08-11T01:08:30+00:00",
                }
            )
            controller._coordination.records["checkpoints"][
                checkpoint["id"]
            ] = checkpoint
            worker_observation = {
                "id": "worker-checkpoint-observation-1",
                "checkpoint_id": checkpoint["id"],
                "checkpoint_sha256": checkpoint["content_sha256"],
            }
            checkpoint_reference = {
                "version": "1.0.0",
                "id": "checkpoint-reference-1",
                "run_id": aggregate["run"]["id"],
                "worker_session_id": aggregate["worker_session"]["id"],
                "elder_run_id": aggregate["initial_binding"][
                    "elder_child_run_id"
                ],
                "elder_run_sha256": aggregate["initial_binding"][
                    "elder_child_run_sha256"
                ],
                "project_id": "product-one",
                "delegation_id": aggregate["initial_binding"][
                    "elder_delegation_id"
                ],
                "session_generation": 1,
                "checkpoint_id": checkpoint["id"],
                "checkpoint_sha256": checkpoint["content_sha256"],
                "adapter_cursor": "cursor-0001",
                "observation_sequence": 1,
                "checkpoint_sequence": 1,
                "previous_checkpoint_sha256": None,
                "worker_observation_id": worker_observation["id"],
                "worker_observation_sha256": canonical_sha256(
                    worker_observation
                ),
                "recorded_at": "2026-08-11T01:08:31+00:00",
                "content_sha256": None,
            }
            checkpoint_reference["content_sha256"] = record_content_sha256(
                checkpoint_reference
            )
            checkpoint_command = self._command(
                aggregate,
                ["checkpoint-reference"],
                suffix="checkpoint-reference-1",
                payload={},
                evidence_refs={},
                at="2026-08-11T01:08:31+00:00",
            )
            checkpoint_result = controller.record_checkpoint_reference(
                checkpoint_command,
                checkpoint_reference,
                checkpoint=checkpoint,
                worker_observation=worker_observation,
                at="2026-08-11T01:08:31+00:00",
            )
            self.assertEqual(checkpoint_result["status"], "applied")
            changed_observation = copy.deepcopy(worker_observation)
            changed_observation["extra"] = "changed"
            with self.assertRaisesRegex(
                ProtocolError,
                "changed separately supplied",
            ):
                controller.record_checkpoint_reference(
                    checkpoint_command,
                    checkpoint_reference,
                    checkpoint=checkpoint,
                    worker_observation=changed_observation,
                    at="2026-08-11T01:08:31+00:00",
                )
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(
                aggregate["worker_session"]["payload"][
                    "checkpoint_cursor"
                ],
                "cursor-0001",
            )
            replay_version = aggregate["worker_session"]["record_version"]
            checkpoint_replay_command = self._command(
                aggregate,
                ["checkpoint-reference"],
                suffix="checkpoint-reference-1-replay",
                payload={},
                evidence_refs={},
                at="2026-08-11T01:08:31+00:00",
            )
            replay_result = controller.record_checkpoint_reference(
                checkpoint_replay_command,
                checkpoint_reference,
                checkpoint=checkpoint,
                worker_observation=worker_observation,
                at="2026-08-11T01:08:31+00:00",
            )
            self.assertEqual(replay_result["status"], "applied")
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(
                aggregate["worker_session"]["record_version"],
                replay_version,
            )

            artifact = {
                "version": "1.0.0",
                "id": "artifact-reference-1",
                "run_id": aggregate["run"]["id"],
                "artifact_sha256": "f" * 64,
                "artifact_type": "diff",
                "provenance_ref": "git-diff:product-one-diff-1",
                "status": "produced",
                "target_locator": None,
                "session_generation": 1,
                "recorded_at": "2026-08-11T01:08:32+00:00",
                "content_sha256": None,
            }
            artifact["content_sha256"] = record_content_sha256(artifact)
            artifact_command = self._command(
                aggregate,
                ["artifact-reference"],
                suffix="artifact-reference-1",
                payload={},
                evidence_refs={},
                at="2026-08-11T01:08:32+00:00",
            )
            self.assertEqual(
                controller.record_artifact_reference(
                    artifact_command,
                    artifact,
                    at="2026-08-11T01:08:32+00:00",
                )["status"],
                "applied",
            )
            changed_artifact = copy.deepcopy(artifact)
            changed_artifact["artifact_sha256"] = "e" * 64
            changed_artifact["content_sha256"] = record_content_sha256(
                changed_artifact
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "changed separately supplied",
            ):
                controller.record_artifact_reference(
                    artifact_command,
                    changed_artifact,
                    at="2026-08-11T01:08:32+00:00",
                )
            aggregate = controller.get(aggregate["run"]["id"])
            detach = self._command(
                aggregate,
                ["worker-session-detach"],
                suffix="worker-session-detach-1",
                payload={"checkpoint_cursor": "cursor-0001"},
                evidence_refs={
                    "checkpoint": "checkpoint-ref:checkpoint-reference-1"
                },
                at="2026-08-11T01:08:33+00:00",
            )
            self.assertEqual(
                controller.apply(
                    detach,
                    at="2026-08-11T01:08:33+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            recover = self._command(
                aggregate,
                ["worker-session-recover"],
                suffix="worker-session-recover-1",
                payload={
                    "external_session_ref": "codex-thread:recovery-one",
                    "lease_ref": aggregate["initial_binding"][
                        "runtime_lease_ref"
                    ],
                    "lease_token_sha256": aggregate["initial_binding"][
                        "runtime_lease_token_sha256"
                    ],
                    "session_generation": 2,
                    "recovery_attempt": 1,
                    "checkpoint_cursor": "cursor-0001",
                },
                evidence_refs={
                    "session lineage": "session-lineage:recovery-one",
                    "current lease proof": (
                        "lease-proof:transition-command-queue-build-repair"
                    ),
                    "checkpoint generation": (
                        "checkpoint-generation:checkpoint-reference-1"
                    ),
                },
                at="2026-08-11T01:08:34+00:00",
            )
            self.assertEqual(
                controller.apply(
                    recover,
                    at="2026-08-11T01:08:34+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            self.assertEqual(
                aggregate["worker_session"]["payload"][
                    "session_generation"
                ],
                2,
            )
            changed_ack = self._command(
                aggregate,
                ["worker-session-activate"],
                suffix="worker-session-recovery-changed-ref",
                payload={"external_session_ref": "codex-thread:changed"},
                evidence_refs={
                    "worker acknowledgement": "evidence:changed-recovery-ack"
                },
                at="2026-08-11T01:08:34+00:00",
            )
            rejected_ack = controller.apply(
                changed_ack,
                at="2026-08-11T01:08:34+00:00",
            )
            self.assertEqual(rejected_ack["status"], "rejected")
            self.assertIn(
                "changed the bound external session reference",
                rejected_ack["result"]["reason"],
            )
            stale_artifact = copy.deepcopy(artifact)
            stale_artifact["id"] = "artifact-reference-stale"
            stale_artifact["recorded_at"] = "2026-08-11T01:08:35+00:00"
            stale_artifact["content_sha256"] = record_content_sha256(
                stale_artifact
            )
            stale_command = self._command(
                aggregate,
                ["artifact-reference"],
                suffix="artifact-reference-stale",
                payload={},
                evidence_refs={},
                at="2026-08-11T01:08:35+00:00",
            )
            stale_command["session_generation"] = 1
            stale_command["authorizations"][0]["request_sha256"] = (
                lifecycle_authorization_request_sha256(
                    stale_command,
                    stale_command["authorizations"][0],
                )
            )
            stale_command["authorizations"][0]["result_sha256"] = (
                authorization_result_sha256(
                    stale_command["authorizations"][0]
                )
            )
            with self.assertRaisesRegex(ProtocolError, "stale"):
                controller.record_artifact_reference(
                    stale_command,
                    stale_artifact,
                    at="2026-08-11T01:08:35+00:00",
                )

    def test_backup_restore_rebuild_and_manifest_tamper(self) -> None:
        with test_workspace("sf-105-backup") as workspace:
            controller, submission, inspector = self._controller_fixture(
                workspace
            )
            aggregate = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            rebuilt = controller.rebuild_current()
            self.assertEqual(rebuilt["status"], "verified")
            self.assertEqual(rebuilt["run_count"], 1)

            backup = workspace / "backups" / "operations-sf-105.db"
            manifest = controller.backup(
                backup,
                at="2026-08-11T01:10:00+00:00",
            )
            self.assertEqual(manifest["integrity"], "ok")
            restored_path = workspace / "restored" / "operations.db"
            restored = RunController.restore(
                backup,
                restored_path,
                repository_inspector=inspector,
                coordination_inspector=controller._coordination,
            )
            self.assertEqual(
                restored.get(aggregate["run"]["id"]),
                controller.get(aggregate["run"]["id"]),
            )
            self.assertEqual(
                restored.rebuild_current()["current_state_sha256"],
                rebuilt["current_state_sha256"],
            )
            with controller._connection() as connection:
                with self.assertRaisesRegex(
                    sqlite3.IntegrityError,
                    "immutable",
                ):
                    connection.execute(
                        """
                        UPDATE factory_run_initial_bindings
                        SET created_at = created_at
                        WHERE run_id = ?
                        """,
                        (aggregate["run"]["id"],),
                    )

            tamper_sqlite_store(
                controller.path,
                """
                UPDATE factory_runs
                SET aggregate_json = ?
                WHERE id = ?
                """,
                ("{}", aggregate["run"]["id"]),
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "aggregate",
            ):
                controller.rebuild_current()

            manifest_path = backup.with_name(
                f"{backup.name}.manifest.json"
            )
            tampered = json.loads(
                manifest_path.read_text(encoding="utf-8")
            )
            tampered["backup_sha256"] = "0" * 64
            tampered["content_sha256"] = record_content_sha256(tampered)
            manifest_path.write_text(
                json.dumps(tampered, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ProtocolError, "digest"):
                RunController.restore(
                    backup,
                    workspace / "restored-tampered" / "operations.db",
                )
            wrong_schema = copy.deepcopy(manifest)
            wrong_schema["run_controller_schema_version"] = 999
            wrong_schema["content_sha256"] = record_content_sha256(
                wrong_schema
            )
            manifest_path.write_text(
                json.dumps(wrong_schema, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "run_controller_schema_version",
            ):
                RunController.restore(
                    backup,
                    workspace / "restored-wrong-schema" / "operations.db",
                )

    def test_rejected_composite_command_rolls_back_partial_entity_updates(
        self,
    ) -> None:
        with test_workspace("sf-105-savepoint") as workspace:
            controller, submission, _ = self._controller_fixture(workspace)
            aggregate = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            provision = self._command(
                aggregate,
                ["workspace-provision"],
                suffix="savepoint-workspace-provision",
                payload={
                    "repository": aggregate["initial_binding"][
                        "repository_root"
                    ],
                    "base_revision": aggregate["initial_binding"][
                        "base_revision"
                    ],
                },
                evidence_refs={},
                at="2026-08-11T01:05:00+00:00",
            )
            self.assertEqual(
                controller.apply(
                    provision,
                    at="2026-08-11T01:05:00+00:00",
                )["status"],
                "applied",
            )
            aggregate = controller.get(aggregate["run"]["id"])
            composite = self._command(
                aggregate,
                ["worker-session-start", "workspace-ready"],
                suffix="savepoint-composite",
                payload={
                    "run_id": aggregate["run"]["id"],
                    "worker_adapter": aggregate["initial_binding"][
                        "worker_adapter_id"
                    ],
                    "path": aggregate["initial_binding"]["workspace_path"],
                    "isolation_mode": "planned-git-worktree",
                },
                evidence_refs={
                    "workspace verification": (
                        "evidence:savepoint-workspace-ready"
                    )
                },
                at="2026-08-11T01:06:00+00:00",
            )
            original_history_insert = controller._history_insert

            def fail_workspace_history(*args, **kwargs):
                if kwargs.get("table") == "factory_workspace_history":
                    raise ProtocolError(
                        "Injected workspace history persistence failure."
                    )
                return original_history_insert(*args, **kwargs)

            with patch.object(
                controller,
                "_history_insert",
                side_effect=fail_workspace_history,
            ):
                rejected = controller.apply(
                    composite,
                    at="2026-08-11T01:06:00+00:00",
                )
            self.assertEqual(rejected["status"], "rejected")
            current = controller.get(aggregate["run"]["id"])
            self.assertEqual(
                current["worker_session"]["status"],
                "prepared",
            )
            self.assertEqual(
                current["workspace"]["status"],
                "provisioning",
            )


if __name__ == "__main__":
    unittest.main()
