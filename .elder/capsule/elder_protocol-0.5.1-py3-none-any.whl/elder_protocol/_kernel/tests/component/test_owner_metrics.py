from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    OwnerMetrics,
    ProjectionRuntime,
    WorkRoom,
    owner_metrics_content_sha256,
    validate_owner_metrics_snapshot,
)
from elder_protocol.factory_operations.owner_metrics import _duration_summary
from tests._sf203_support import StaticWorkspaceAuthority, running_fixture
from tests._support import test_workspace


class OwnerMetricsComponentTests(unittest.TestCase):
    def test_snapshot_is_definition_bound_and_truthful_about_missing_data(
        self,
    ) -> None:
        with test_workspace("sf305-metrics") as workspace:
            _, controller, aggregate, binding, _, session = running_fixture(
                workspace
            )
            ProjectionRuntime(controller.path).rebuild_all()
            WorkRoom(
                controller.path,
                session.path,
                workspace_authority=StaticWorkspaceAuthority(binding),
            )
            service = OwnerMetrics(controller.path, session.path)
            arguments = {
                "project_id": aggregate["run"]["project_id"],
                "observed_at": "2026-08-14T10:30:00+00:00",
            }

            first = service.snapshot(**arguments)
            second = service.snapshot(**arguments)

            self.assertEqual(first["content_sha256"], second["content_sha256"])
            self.assertEqual(first["delivery"]["work_item_count"], 1)
            self.assertEqual(first["outcomes"]["by_status"]["running"], 1)
            self.assertEqual(first["reliability"]["failure_count"], 0)
            self.assertEqual(first["control"]["status"], "complete")
            self.assertEqual(first["control"]["owner_intervention_count"], 0)
            self.assertEqual(first["test_quality"]["run_count"], 1)
            self.assertEqual(first["test_quality"]["coverage_ratio"], 0.0)
            self.assertEqual(first["cost"]["status"], "unavailable")
            self.assertIsNone(first["cost"]["value"])
            self.assertEqual(first["learning_impact"]["status"], "unavailable")

            tampered = copy.deepcopy(first)
            tampered["reliability"]["retry_count"] = 99
            with self.assertRaisesRegex(ProtocolError, "digest"):
                validate_owner_metrics_snapshot(tampered)

            contradictory = copy.deepcopy(first)
            contradictory["reliability"]["failure_count"] = 1
            contradictory["content_sha256"] = owner_metrics_content_sha256(
                contradictory
            )
            with self.assertRaisesRegex(ProtocolError, "failure count"):
                validate_owner_metrics_snapshot(contradictory)

    def test_duration_summary_uses_nearest_rank_and_reports_exclusions(
        self,
    ) -> None:
        summary = _duration_summary([10.0, 20.0, 30.0, 40.0], 1)
        self.assertEqual(summary["status"], "partial")
        self.assertEqual(summary["mean_seconds"], 25.0)
        self.assertEqual(summary["p50_seconds"], 20.0)
        self.assertEqual(summary["p95_seconds"], 40.0)
        self.assertEqual(summary["excluded_count"], 1)


if __name__ == "__main__":
    unittest.main()
