from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.governance import (
    build_delegation_fixture_graph,
    finalize_checkpoint,
    finalize_delegation,
    resolve_authority_bindings,
    resolve_obligations,
    validate_agent_run_chain,
    validate_bound_checkpoint,
    validate_delegation,
    validate_delegation_set,
)
from elder_protocol.io import load_json
from elder_protocol.profiles import resolve_capability_packs, validate_profile
from elder_protocol.protocol import validate_protocol
from elder_protocol.constants import ROOT


FIXTURES = ROOT / "tests" / "fixtures" / "p4_5a"


class P45AGovernanceComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.data = validate_protocol()

    def _fixture(self, name: str) -> dict:
        return load_json(FIXTURES / name)

    def _authority_kwargs(self, fixture: dict) -> dict:
        return {
            "profile": fixture["profile"],
            "role_registry": self.data["role-registry"],
            "authority_matrix": self.data["authority-matrix"],
        }

    def test_profiles_resolve_packs_obligations_and_authority(self) -> None:
        for name in [
            "fixture-a-low-risk.json",
            "fixture-b-high-risk.json",
        ]:
            fixture = self._fixture(name)
            profile = fixture["profile"]
            validate_profile(profile, self.data)
            packs = resolve_capability_packs(profile["capability_packs"], self.data)
            obligations = resolve_obligations(
                profile,
                self.data["capability-packs"]["packs"],
                packs,
            )
            bindings = resolve_authority_bindings(
                profile,
                self.data["role-registry"],
                self.data["authority-matrix"],
            )
            self.assertTrue(obligations["obligations"])
            self.assertTrue(bindings["grants"])
            self.assertEqual(
                {item["status"] for item in obligations["obligations"]},
                {"declared"},
            )

    def test_valid_delegation_chain_and_fixture_graph(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        profile = fixture["profile"]
        bindings = resolve_authority_bindings(
            profile,
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        validate_delegation(
            fixture["delegation"],
            fixture["parent_run"],
            bindings,
            self.data["delegation-policy"],
            **self._authority_kwargs(fixture),
        )
        validate_agent_run_chain(
            fixture["parent_run"],
            fixture["child_run"],
            fixture["delegation"],
            authority_bindings=bindings,
            policy=self.data["delegation-policy"],
            **self._authority_kwargs(fixture),
        )
        self.assertEqual(
            build_delegation_fixture_graph(
                fixture["parent_run"],
                fixture["delegation"],
                fixture["child_run"],
                fixture["checkpoint"],
                authority_bindings=bindings,
                policy=self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            ),
            fixture["expected_graph"],
        )

    def test_invalid_scope_and_aggregate_budget_fail_closed(self) -> None:
        fixture = self._fixture("fixture-b-high-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        with self.assertRaisesRegex(ProtocolError, "scope"):
            validate_delegation(
                fixture["invalid_delegation"],
                fixture["parent_run"],
                bindings,
                self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

        second = copy.deepcopy(fixture["delegation"])
        second["delegation_id"] = "fixture-b-high-risk-DEL-002"
        second["budget"] = {
            "token_limit": 12000,
            "cost_limit_usd": 12,
            "tool_call_limit": 60,
            "elapsed_seconds_limit": 4000,
        }
        second = finalize_delegation(second)
        with self.assertRaisesRegex(ProtocolError, "Aggregate child delegation budget"):
            validate_delegation_set(
                [fixture["delegation"], second],
                fixture["parent_run"],
                bindings,
                self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

    def test_parent_claimed_authority_must_match_project_authority(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        forged_parent = copy.deepcopy(fixture["parent_run"])
        forged_parent["identity_id"] = "fixture-a-low-risk-planning-agent"
        forged_parent["role"] = "planning-agent"
        with self.assertRaisesRegex(ProtocolError, "Parent agent run authority"):
            validate_delegation(
                fixture["delegation"],
                forged_parent,
                bindings,
                self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

    def test_child_run_cannot_exceed_delegated_contract(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        cases = {
            "authority": lambda run: run["authority_grants"][0]["actions"].append(
                "approve"
            ),
            "tool": lambda run: run["tool_grants"].append("production-deploy"),
            "token budget": lambda run: run["budget"].update({"token_limit": 99999}),
            "cost budget": lambda run: run["budget"].update({"cost_limit_usd": 999}),
            "tool budget": lambda run: run["budget"].update({"tool_call_limit": 999}),
            "elapsed budget": lambda run: run["budget"].update(
                {"elapsed_seconds_limit": 99999}
            ),
            "deadline": lambda run: run.update(
                {"deadline": "2026-08-07T16:00:00+05:30"}
            ),
            "started_at": lambda run: run.update(
                {"started_at": "2026-08-07T16:00:00+05:30"}
            ),
            "completed_at": lambda run: run.update(
                {
                    "completed_at": "2026-08-07T16:00:00+05:30",
                    "status": "complete",
                }
            ),
        }
        for expected, mutate in cases.items():
            with self.subTest(expected=expected):
                child_run = copy.deepcopy(fixture["child_run"])
                mutate(child_run)
                error_pattern = "budget" if expected.endswith("budget") else expected
                with self.assertRaisesRegex(ProtocolError, error_pattern):
                    validate_agent_run_chain(
                        fixture["parent_run"],
                        child_run,
                        fixture["delegation"],
                        authority_bindings=resolve_authority_bindings(
                            fixture["profile"],
                            self.data["role-registry"],
                            self.data["authority-matrix"],
                        ),
                        policy=self.data["delegation-policy"],
                        **self._authority_kwargs(fixture),
                    )

    def test_bound_checkpoint_rejects_project_scope_budget_and_time_drift(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        cases = {
            "project_id": lambda checkpoint: checkpoint.update(
                {"project_id": "unrelated-project"}
            ),
            "scope": lambda checkpoint: checkpoint.update(
                {"remaining_scope": ["src/other"]}
            ),
            "budget": lambda checkpoint: checkpoint["budget_consumed"].update(
                {"cost_limit_usd": 999}
            ),
            "deadline": lambda checkpoint: checkpoint.update(
                {"created_at": "2026-08-07T16:00:00+05:30"}
            ),
        }
        for expected, mutate in cases.items():
            with self.subTest(expected=expected):
                checkpoint = copy.deepcopy(fixture["checkpoint"])
                mutate(checkpoint)
                checkpoint = finalize_checkpoint(checkpoint)
                with self.assertRaisesRegex(ProtocolError, expected):
                    validate_bound_checkpoint(
                        checkpoint,
                        fixture["parent_run"],
                        fixture["delegation"],
                        fixture["child_run"],
                        authority_bindings=bindings,
                        policy=self.data["delegation-policy"],
                        **self._authority_kwargs(fixture),
                    )

        forged_delegation = copy.deepcopy(fixture["delegation"])
        forged_delegation["authority_grants"][0]["actions"].append("approve")
        forged_delegation = finalize_delegation(forged_delegation)
        with self.assertRaisesRegex(ProtocolError, "approve or promote"):
            validate_bound_checkpoint(
                fixture["checkpoint"],
                fixture["parent_run"],
                forged_delegation,
                fixture["child_run"],
                authority_bindings=bindings,
                policy=self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

        forged_child = copy.deepcopy(fixture["child_run"])
        forged_child["tool_grants"].append("production-deploy")
        with self.assertRaisesRegex(ProtocolError, "tool grants"):
            validate_bound_checkpoint(
                fixture["checkpoint"],
                fixture["parent_run"],
                fixture["delegation"],
                forged_child,
                authority_bindings=bindings,
                policy=self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

    def test_broad_scope_cannot_contain_forbidden_subtree(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        delegation = copy.deepcopy(fixture["delegation"])
        delegation["scope"] = ["src"]
        delegation["forbidden_scope"] = ["src/secrets"]
        delegation = finalize_delegation(delegation)
        with self.assertRaisesRegex(ProtocolError, "forbidden scope"):
            validate_delegation(
                delegation,
                fixture["parent_run"],
                bindings,
                self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

        sibling = copy.deepcopy(fixture["delegation"])
        sibling["scope"] = ["src/app"]
        sibling["forbidden_scope"] = ["src/secrets"]
        validate_delegation(
            finalize_delegation(sibling),
            fixture["parent_run"],
            bindings,
            self.data["delegation-policy"],
            **self._authority_kwargs(fixture),
        )

        unnormalized = copy.deepcopy(fixture["delegation"])
        unnormalized["scope"] = ["src/component/"]
        with self.assertRaisesRegex(ProtocolError, "normalized"):
            validate_delegation(
                finalize_delegation(unnormalized),
                fixture["parent_run"],
                bindings,
                self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

    def test_checkpoint_must_bind_to_delegation_and_child_run(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        for field, value in [
            ("delegation_id", "unrelated-delegation"),
            ("run_id", "unrelated-run"),
        ]:
            with self.subTest(field=field):
                checkpoint = copy.deepcopy(fixture["checkpoint"])
                checkpoint[field] = value
                checkpoint = finalize_checkpoint(checkpoint)
                with self.assertRaisesRegex(ProtocolError, field):
                    build_delegation_fixture_graph(
                        fixture["parent_run"],
                        fixture["delegation"],
                        fixture["child_run"],
                        checkpoint,
                        authority_bindings=resolve_authority_bindings(
                            fixture["profile"],
                            self.data["role-registry"],
                            self.data["authority-matrix"],
                        ),
                        policy=self.data["delegation-policy"],
                        **self._authority_kwargs(fixture),
                    )

    def test_forged_authority_bindings_fail_closed(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        forged = copy.deepcopy(bindings)
        forged["grants"].append(
            {
                "id": "planning-agent:implementation",
                "role": "planning-agent",
                "identity": "fixture-a-low-risk-planning-agent",
                "resource": "implementation",
                "actions": ["read", "propose", "modify", "execute"],
            }
        )
        with self.assertRaisesRegex(ProtocolError, "authoritative sources"):
            validate_delegation(
                fixture["delegation"],
                fixture["parent_run"],
                forged,
                self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

    def test_run_chain_rejects_digest_valid_policy_invalid_delegation(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        delegation = copy.deepcopy(fixture["delegation"])
        delegation["authority_grants"][0]["actions"].append("approve")
        delegation = finalize_delegation(delegation)
        child_run = copy.deepcopy(fixture["child_run"])
        child_run["authority_grants"][0]["actions"].append("approve")
        with self.assertRaisesRegex(ProtocolError, "approve or promote"):
            validate_agent_run_chain(
                fixture["parent_run"],
                child_run,
                delegation,
                authority_bindings=bindings,
                policy=self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )

    def test_valid_agent_parent_uses_only_resolved_authority(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        parent_run = copy.deepcopy(fixture["parent_run"])
        parent_run["identity_id"] = "fixture-a-low-risk-planning-agent"
        parent_run["role"] = "planning-agent"
        parent_run["scope"] = ["docs"]
        parent_run["authority_grants"] = [
            {"resource": "delegation", "actions": ["delegate"]},
            {"resource": "design-doc", "actions": ["read", "propose"]}
        ]
        parent_run["tool_grants"] = ["filesystem-read"]

        delegation = copy.deepcopy(fixture["delegation"])
        delegation["assigned_identity_id"] = "fixture-a-low-risk-evaluator"
        delegation["assigned_role"] = "evaluator"
        delegation["objective"] = (
            "Review the declared design contract within the bounded documentation scope."
        )
        delegation["scope"] = ["docs/component"]
        delegation["authority_ceiling"] = "propose-only"
        delegation["authority_grants"] = [
            {"resource": "design-doc", "actions": ["read", "propose"]}
        ]
        delegation["tool_grants"] = ["filesystem-read"]
        delegation = finalize_delegation(delegation)

        child_run = copy.deepcopy(fixture["child_run"])
        child_run["identity_id"] = "fixture-a-low-risk-evaluator"
        child_run["role"] = "evaluator"
        child_run["scope"] = ["docs/component"]
        child_run["authority_grants"] = [
            {"resource": "design-doc", "actions": ["read", "propose"]}
        ]
        child_run["tool_grants"] = ["filesystem-read"]

        validate_agent_run_chain(
            parent_run,
            child_run,
            delegation,
            authority_bindings=bindings,
            policy=self.data["delegation-policy"],
            **self._authority_kwargs(fixture),
        )

    def test_parent_run_must_claim_delegation_authority(self) -> None:
        fixture = self._fixture("fixture-a-low-risk.json")
        bindings = resolve_authority_bindings(
            fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )
        parent_run = copy.deepcopy(fixture["parent_run"])
        parent_run["authority_grants"] = [
            grant
            for grant in parent_run["authority_grants"]
            if grant["resource"] != "delegation"
        ]
        with self.assertRaisesRegex(ProtocolError, "explicitly claim delegation"):
            validate_delegation(
                fixture["delegation"],
                parent_run,
                bindings,
                self.data["delegation-policy"],
                **self._authority_kwargs(fixture),
            )


if __name__ == "__main__":
    unittest.main()
