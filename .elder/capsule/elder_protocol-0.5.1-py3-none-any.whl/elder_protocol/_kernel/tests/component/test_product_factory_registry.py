from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    ProductFactoryRegistry,
)
from elder_protocol.io import load_json
from tests._support import tamper_sqlite_store, test_workspace


class ProductFactoryRegistryComponentTests(unittest.TestCase):
    def _profile(self, project_id: str) -> dict:
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = project_id
        profile["name"] = project_id.replace("-", " ").title()
        return profile

    def _repository(
        self,
        workspace: Path,
        project_id: str,
        *,
        profile_status: str = "ratified",
        profile_path: str = ".elder/project-profile.json",
        with_git: bool = True,
    ) -> tuple[Path, Path, dict]:
        repository = workspace / project_id
        repository.mkdir()
        if with_git:
            (repository / ".git").mkdir()
        profile = self._profile(project_id)
        profile["profile_status"] = profile_status
        target = repository / Path(*profile_path.split("/"))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(profile, indent=2) + "\n",
            encoding="utf-8",
        )
        return repository, target, profile

    @staticmethod
    def _configuration(
        repository: Path,
        project_id: str,
        *,
        profile_path: str = ".elder/project-profile.json",
    ) -> dict:
        return {
            "version": "1.0.0",
            "project_id": project_id,
            "repository_root": str(repository.resolve()),
            "profile_path": profile_path,
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [
                {
                    "id": "owner-inbox",
                    "kind": "manual",
                    "reference": "manual:owner-inbox",
                    "enabled": True,
                }
            ],
        }

    def _registry(
        self,
        workspace: Path,
    ) -> ProductFactoryRegistry:
        database = workspace / "operations.db"
        FactoryOperationsBootstrap(database).initialize()
        return ProductFactoryRegistry(database)

    def test_initialize_register_and_restart_preserve_exact_bindings(self) -> None:
        with test_workspace("sf-100-register") as workspace:
            repository, _, profile = self._repository(
                workspace,
                "product-one",
            )
            registry = self._registry(workspace)
            status = registry.status()
            self.assertEqual(status["journal_mode"], "wal")
            self.assertTrue(status["foreign_keys"])
            self.assertEqual(status["integrity"], "ok")

            record = registry.register(
                self._configuration(repository, "product-one"),
                actor_identity_id="founder",
                at="2026-08-08T05:00:00+00:00",
            )
            entity = record["product_factory"]
            self.assertEqual(entity["id"], "product-factory-product-one")
            self.assertEqual(entity["status"], "draft")
            self.assertEqual(entity["record_version"], 1)
            self.assertEqual(entity["payload"]["name"], profile["name"])
            self.assertEqual(
                record["repository_binding"]["root"],
                str(repository.resolve()),
            )
            self.assertEqual(
                record["profile_binding"]["profile_path"],
                ".elder/project-profile.json",
            )

            reopened = ProductFactoryRegistry(workspace / "operations.db")
            persisted = reopened.get_by_project("product-one")
            self.assertEqual(persisted, record)
            self.assertEqual(reopened.status()["factory_count"], 1)
            self.assertEqual(reopened.status()["revision_count"], 1)

    def test_registration_fails_closed_on_profile_repository_and_actor_mismatch(
        self,
    ) -> None:
        with test_workspace("sf-100-bindings") as workspace:
            registry = self._registry(workspace)

            draft_repo, _, _ = self._repository(
                workspace,
                "draft-product",
                profile_status="draft",
            )
            with self.assertRaisesRegex(ProtocolError, "ratified project profile"):
                registry.register(
                    self._configuration(draft_repo, "draft-product"),
                    actor_identity_id="founder",
                )

            mismatch_repo, _, _ = self._repository(
                workspace,
                "profile-product",
            )
            mismatch = self._configuration(mismatch_repo, "other-product")
            with self.assertRaisesRegex(ProtocolError, "profile slug"):
                registry.register(mismatch, actor_identity_id="founder")

            non_git_repo, _, _ = self._repository(
                workspace,
                "non-git-product",
                with_git=False,
            )
            with self.assertRaisesRegex(ProtocolError, "not Git-bound"):
                registry.register(
                    self._configuration(non_git_repo, "non-git-product"),
                    actor_identity_id="founder",
                )

            unauthorized_repo, _, _ = self._repository(
                workspace,
                "unauthorized-product",
            )
            with self.assertRaisesRegex(ProtocolError, "requires actor"):
                registry.register(
                    self._configuration(
                        unauthorized_repo,
                        "unauthorized-product",
                    ),
                    actor_identity_id="example-agentic-product-executor",
                )

    def test_duplicate_project_and_repository_bindings_are_rejected(self) -> None:
        with test_workspace("sf-100-duplicates") as workspace:
            repository, _, _ = self._repository(workspace, "product-one")
            registry = self._registry(workspace)
            registry.register(
                self._configuration(repository, "product-one"),
                actor_identity_id="founder",
            )
            with self.assertRaisesRegex(ProtocolError, "already registered"):
                registry.register(
                    self._configuration(repository, "product-one"),
                    actor_identity_id="founder",
                )

            second_profile = self._profile("product-two")
            second_path = repository / ".elder" / "product-two.json"
            second_path.write_text(
                json.dumps(second_profile, indent=2) + "\n",
                encoding="utf-8",
            )
            duplicate_repository = self._configuration(
                repository,
                "product-two",
                profile_path=".elder/product-two.json",
            )
            with self.assertRaisesRegex(ProtocolError, "repository is already bound"):
                registry.register(
                    duplicate_repository,
                    actor_identity_id="founder",
                )

    def test_update_uses_optimistic_concurrency_and_immutable_history(self) -> None:
        with test_workspace("sf-100-update") as workspace:
            repository, profile_path, profile = self._repository(
                workspace,
                "product-one",
            )
            registry = self._registry(workspace)
            record = registry.register(
                self._configuration(repository, "product-one"),
                actor_identity_id="founder",
                at="2026-08-08T05:00:00+00:00",
            )

            profile["name"] = "Product One Updated"
            profile_path.write_text(
                json.dumps(profile, indent=2) + "\n",
                encoding="utf-8",
            )
            updated_configuration = self._configuration(
                repository,
                "product-one",
            )
            updated_configuration["integration_refs"].append(
                {
                    "id": "github-issues",
                    "kind": "github",
                    "reference": "github:product-one/issues",
                    "enabled": True,
                }
            )
            updated = registry.update(
                record["product_factory"]["id"],
                updated_configuration,
                expected_version=1,
                actor_identity_id="founder",
                reason="Bind the ratified profile revision.",
                at="2026-08-08T05:05:00+00:00",
            )
            self.assertEqual(updated["product_factory"]["record_version"], 2)
            self.assertEqual(
                updated["product_factory"]["payload"]["name"],
                "Product One Updated",
            )
            self.assertEqual(len(updated["integration_refs"]), 2)

            with self.assertRaisesRegex(ProtocolError, "version conflict"):
                registry.update(
                    record["product_factory"]["id"],
                    updated_configuration,
                    expected_version=1,
                    actor_identity_id="founder",
                    reason="Stale writer.",
                )

            history = registry.history(record["product_factory"]["id"])
            self.assertEqual(
                [item["operation"] for item in history],
                ["register", "update"],
            )
            self.assertEqual(
                [
                    item["snapshot"]["product_factory"]["record_version"]
                    for item in history
                ],
                [1, 2],
            )
            self.assertNotEqual(
                history[0]["content_sha256"],
                history[1]["content_sha256"],
            )

    def test_active_configuration_must_pause_and_archive_is_terminal(self) -> None:
        with test_workspace("sf-100-lifecycle") as workspace:
            repository, _, _ = self._repository(workspace, "product-one")
            registry = self._registry(workspace)
            factory_id = registry.register(
                self._configuration(repository, "product-one"),
                actor_identity_id="founder",
                at="2026-08-08T05:00:00+00:00",
            )["product_factory"]["id"]

            active = registry.activate(
                factory_id,
                expected_version=1,
                actor_identity_id="founder",
                at="2026-08-08T05:01:00+00:00",
            )
            self.assertEqual(active["product_factory"]["status"], "active")
            with self.assertRaisesRegex(ProtocolError, "must be paused"):
                registry.update(
                    factory_id,
                    self._configuration(repository, "product-one"),
                    expected_version=2,
                    actor_identity_id="founder",
                    reason="Attempt an unsafe live reconfiguration.",
                )

            paused = registry.pause(
                factory_id,
                expected_version=2,
                actor_identity_id="founder",
                reason="Pause before retirement.",
                at="2026-08-08T05:02:00+00:00",
            )
            self.assertEqual(paused["product_factory"]["status"], "paused")
            archived = registry.archive(
                factory_id,
                expected_version=3,
                actor_identity_id="founder",
                decision="Owner decision DEC-100 retires this product factory.",
                at="2026-08-08T05:03:00+00:00",
            )
            self.assertEqual(archived["product_factory"]["status"], "archived")
            self.assertEqual(
                archived["archived_at"],
                "2026-08-08T05:03:00+00:00",
            )
            self.assertEqual(registry.list(), [])
            self.assertEqual(len(registry.list(include_archived=True)), 1)

            with self.assertRaisesRegex(ProtocolError, "immutable"):
                registry.update(
                    factory_id,
                    self._configuration(repository, "product-one"),
                    expected_version=4,
                    actor_identity_id="founder",
                    reason="Archived state cannot change.",
                )
            with self.assertRaisesRegex(ProtocolError, "cannot activate"):
                registry.activate(
                    factory_id,
                    expected_version=4,
                    actor_identity_id="founder",
                )
            self.assertEqual(
                [item["operation"] for item in registry.history(factory_id)],
                ["register", "activate", "pause", "archive"],
            )

    def test_archive_requires_human_owner_and_activation_requires_current_profile(
        self,
    ) -> None:
        with test_workspace("sf-100-authority") as workspace:
            repository, profile_path, profile = self._repository(
                workspace,
                "product-one",
            )
            registry = self._registry(workspace)
            factory_id = registry.register(
                self._configuration(repository, "product-one"),
                actor_identity_id="technical-owner",
            )["product_factory"]["id"]

            with self.assertRaisesRegex(ProtocolError, "requires actor"):
                registry.archive(
                    factory_id,
                    expected_version=1,
                    actor_identity_id="technical-owner",
                    decision="Architecture ownership is not archive authority.",
                )

            profile["mission"] = (
                "This changed ratified profile has not been rebound to the registry."
            )
            profile_path.write_text(
                json.dumps(profile, indent=2) + "\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ProtocolError, "changed after binding"):
                registry.activate(
                    factory_id,
                    expected_version=1,
                    actor_identity_id="founder",
                )

    def test_secret_references_are_rejected_before_persistence(self) -> None:
        with test_workspace("sf-100-secrets") as workspace:
            repository, _, _ = self._repository(workspace, "product-one")
            registry = self._registry(workspace)
            configuration = self._configuration(repository, "product-one")
            configuration["integration_refs"][0]["reference"] = (
                "vault:factory-owner-token"
            )
            with self.assertRaisesRegex(ProtocolError, "secret reference scheme"):
                registry.register(
                    configuration,
                    actor_identity_id="founder",
                )
            self.assertEqual(registry.status()["factory_count"], 0)
            self.assertEqual(registry.status()["revision_count"], 0)

    def test_versions_reasons_and_revision_integrity_fail_closed(self) -> None:
        with test_workspace("sf-100-integrity") as workspace:
            repository, _, _ = self._repository(workspace, "product-one")
            registry = self._registry(workspace)
            factory_id = registry.register(
                self._configuration(repository, "product-one"),
                actor_identity_id="founder",
            )["product_factory"]["id"]

            with self.assertRaisesRegex(ProtocolError, "positive integer"):
                registry.activate(
                    factory_id,
                    expected_version=True,
                    actor_identity_id="founder",
                )
            with self.assertRaisesRegex(ProtocolError, "secret-like material"):
                registry.update(
                    factory_id,
                    self._configuration(repository, "product-one"),
                    expected_version=1,
                    actor_identity_id="founder",
                    reason="Bearer abcdefghijklmnop",
                )

            tamper_sqlite_store(
                workspace / "operations.db",
                """
                UPDATE product_factories
                SET updated_at = '2026-08-08T06:00:00+00:00'
                WHERE id = ?
                """,
                (factory_id,),
            )
            with self.assertRaisesRegex(ProtocolError, "row does not match"):
                registry.status()


if __name__ == "__main__":
    unittest.main()
