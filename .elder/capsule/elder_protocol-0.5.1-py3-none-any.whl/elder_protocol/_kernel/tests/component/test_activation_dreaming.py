from __future__ import annotations

import json
import unittest
from datetime import UTC, datetime, timedelta

from elder_protocol.activation import activate_session
from elder_protocol.autonomy import canonical_sha256
from elder_protocol.compiler import compile_project
from elder_protocol.constants import PROTOCOL_VERSION, ROOT
from elder_protocol.dreaming import (
    accept_dreaming_candidate,
    prepare_dreaming_workspace,
)
from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, sha256_file
from tests._support import test_workspace


class ActivationAndDreamingComponentTests(unittest.TestCase):
    def test_factory_kernel_activation_routes_existing_skill_files(self) -> None:
        packet = activate_session(ROOT, "Verify the Elder activation contract")

        self.assertEqual(packet["mode"], "factory-kernel")
        self.assertTrue(packet["routed_skills"])
        for routed_skill in packet["routed_skills"]:
            self.assertTrue(
                (ROOT / routed_skill["path"]).is_file(),
                routed_skill["path"],
            )

    def test_compiled_project_activates_with_native_codex_skills(self) -> None:
        with test_workspace("activation") as workspace:
            project = workspace / "project"
            compile_project(ROOT / "examples" / "minimal-project-profile.json", project)
            packet = activate_session(project, "Implement a bounded API change")

            self.assertEqual(packet["status"], "ready")
            self.assertEqual(packet["mode"], "generated-project")
            self.assertEqual(packet["boundaries"]["sandbox_mode"], "workspace-write")
            self.assertFalse(packet["boundaries"]["direct_tool_interception"])
            self.assertTrue(packet["dreaming"]["candidate_only"])
            skill_ids = {entry["id"] for entry in packet["routed_skills"]}
            self.assertIn("wayfinder", skill_ids)
            self.assertTrue(
                (project / ".codex" / "skills" / "repository-dreaming" / "SKILL.md").is_file()
            )

    def test_activation_rejects_modified_elder_owned_instructions(self) -> None:
        with test_workspace("activation-drift") as workspace:
            project = workspace / "project"
            compile_project(ROOT / "examples" / "minimal-project-profile.json", project)
            agents = project / "AGENTS.md"
            agents.write_text(agents.read_text(encoding="utf-8") + "\nunsafe drift\n", encoding="utf-8")

            with self.assertRaisesRegex(
                ProtocolError,
                "changed outside regeneration",
            ):
                activate_session(project, "Continue implementation")

    def test_dreaming_candidate_is_quarantined_and_validated(self) -> None:
        with test_workspace("dreaming") as workspace:
            project = workspace / "project"
            compile_project(ROOT / "examples" / "minimal-project-profile.json", project)
            activation = activate_session(project, "Review repeated test failures")
            activation_path = workspace / "activation.json"
            activation_path.write_text(json_text(activation), encoding="utf-8")
            evidence = workspace / "test-result.txt"
            evidence.write_text("The same parser assertion failed twice.\n", encoding="utf-8")
            dream_workspace = workspace / "dream"
            request = prepare_dreaming_workspace(
                project_root=project,
                activation_path=activation_path,
                evidence=[("test-result", evidence)],
                work_item_id="work-1",
                trigger="repeated-failure",
                workspace=dream_workspace,
            )
            artifact = dream_workspace / "artifacts" / "parser-memory.md"
            artifact.write_text(
                "Run the parser component test after changing CLI argument handling.\n",
                encoding="utf-8",
            )
            now = datetime.now(UTC)
            candidate = {
                "version": PROTOCOL_VERSION,
                "id": "candidate-luna-parser-memory",
                "project_id": request["project_id"],
                "kind": "memory",
                "target_ref": "repository:test-protocol",
                "artifact_path": "artifacts/parser-memory.md",
                "artifact_sha256": sha256_file(artifact),
                "hypothesis": (
                    "Running the parser component test after CLI changes will detect "
                    "argument-contract regressions earlier."
                ),
                "source_evidence": ["evidence-1"],
                "counterexamples": [],
                "created_by": "mem0-azure-luna-dreaming",
                "created_role": "learning-agent",
                "status": "candidate",
                "created_at": now.isoformat(),
                "expires_at": (now + timedelta(days=30)).isoformat(),
            }
            candidate["content_sha256"] = canonical_sha256(candidate)
            candidate_path = dream_workspace / "candidate.json"
            candidate_path.write_text(json_text(candidate), encoding="utf-8")
            output = dream_workspace / "accepted.json"

            accepted = accept_dreaming_candidate(
                workspace=dream_workspace,
                candidate_path=candidate_path,
                output=output,
            )

            self.assertEqual(accepted["status"], "candidate")
            self.assertTrue(output.is_file())
            self.assertNotIn(str(project), (dream_workspace / "PROMPT.md").read_text(encoding="utf-8"))

    def test_dreaming_candidate_cannot_reference_unbound_evidence(self) -> None:
        with test_workspace("dreaming-unbound") as workspace:
            project = workspace / "project"
            compile_project(ROOT / "examples" / "minimal-project-profile.json", project)
            activation = activate_session(project, "Review a user correction")
            activation_path = workspace / "activation.json"
            activation_path.write_text(json_text(activation), encoding="utf-8")
            evidence = workspace / "correction.txt"
            evidence.write_text("Use the project package manager.\n", encoding="utf-8")
            dream_workspace = workspace / "dream"
            request = prepare_dreaming_workspace(
                project_root=project,
                activation_path=activation_path,
                evidence=[("user-correction", evidence)],
                work_item_id="work-2",
                trigger="user-correction",
                workspace=dream_workspace,
            )
            artifact = dream_workspace / "artifacts" / "correction.md"
            artifact.write_text("Use the project package manager.\n", encoding="utf-8")
            now = datetime.now(UTC)
            candidate = {
                "version": PROTOCOL_VERSION,
                "id": "candidate-unbound",
                "project_id": request["project_id"],
                "kind": "memory",
                "target_ref": "repository:package-management",
                "artifact_path": "artifacts/correction.md",
                "artifact_sha256": sha256_file(artifact),
                "hypothesis": "Using the project package manager prevents environment drift.",
                "source_evidence": ["not-in-request"],
                "counterexamples": [],
                "created_by": "mem0-azure-luna-dreaming",
                "created_role": "learning-agent",
                "status": "candidate",
                "created_at": now.isoformat(),
                "expires_at": (now + timedelta(days=30)).isoformat(),
            }
            candidate["content_sha256"] = canonical_sha256(candidate)
            candidate_path = dream_workspace / "candidate.json"
            candidate_path.write_text(json.dumps(candidate), encoding="utf-8")

            with self.assertRaisesRegex(ProtocolError, "outside the request"):
                accept_dreaming_candidate(
                    workspace=dream_workspace,
                    candidate_path=candidate_path,
                    output=dream_workspace / "accepted.json",
                )


if __name__ == "__main__":
    unittest.main()
