from __future__ import annotations

import copy
import json
import sqlite3
import unittest
from pathlib import Path

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    ProductFactoryRegistry,
    WorkItemLedger,
    WorkItemTransitionEngine,
    transition_authorization_request_sha256,
    transition_authorization_result_sha256,
)
from elder_protocol.io import load_json
from tests._support import test_workspace


class WorkItemTransitionEngineComponentTests(unittest.TestCase):
    @staticmethod
    def _profile(project_id: str) -> dict:
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = project_id
        profile["name"] = project_id.replace("-", " ").title()
        return profile

    def _engine(
        self,
        workspace: Path,
        project_id: str = "product-one",
    ) -> tuple[WorkItemLedger, WorkItemTransitionEngine]:
        repository = workspace / project_id
        repository.mkdir()
        (repository / ".git").mkdir()
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(self._profile(project_id), indent=2) + "\n",
            encoding="utf-8",
        )
        database = workspace / "operations.db"
        FactoryOperationsBootstrap(database).initialize()
        registry = ProductFactoryRegistry(database)
        record = registry.register(
            {
                "version": "1.0.0",
                "project_id": project_id,
                "repository_root": str(repository.resolve()),
                "profile_path": ".elder/project-profile.json",
                "worker_policy": {
                    "adapter_id": "codex",
                    "max_concurrent_workers": 1,
                    "approval_policy": "on-request",
                    "sandbox_mode": "workspace-write",
                    "network_access": False,
                },
                "integration_refs": [
                    {
                        "id": "owner-inbox",
                        "kind": "manual",
                        "reference": "manual:owner-inbox",
                        "enabled": True,
                    }
                ],
            },
            actor_identity_id="founder",
            at="2026-08-08T09:00:00+00:00",
        )
        registry.activate(
            record["product_factory"]["id"],
            expected_version=1,
            actor_identity_id="founder",
            at="2026-08-08T09:01:00+00:00",
        )
        ledger = WorkItemLedger(database)
        ledger.initialize()
        ledger.create(
            self._specification(project_id=project_id),
            actor_identity_id="founder",
            change_reason="Owner accepted the bounded work item.",
            at="2026-08-08T09:05:00+00:00",
        )
        engine = WorkItemTransitionEngine(database)
        engine.initialize()
        return ledger, engine

    @staticmethod
    def _specification(
        *,
        project_id: str = "product-one",
    ) -> dict:
        return {
            "version": "1.0.0",
            "work_item_id": "work-item-build-repair",
            "project_id": project_id,
            "objective": "Repair the failing component build with durable evidence.",
            "scope": ["component build", "regression test"],
            "non_goals": ["production deployment"],
            "priority": "high",
            "owner_identity_id": "founder",
            "acceptance_criteria": [
                "The component build passes.",
                "A regression test proves the fix.",
            ],
            "outcome_ids": ["outcome:governed-workflow"],
            "change_class": "internal-code",
            "evidence_plan": [
                "foundation tests",
                "component tests",
                "independent evaluation",
            ],
            "authority_refs": ["profile:product-one/founder"],
            "dependencies": [],
            "source_links": [
                {
                    "kind": "manual",
                    "reference": "manual:owner-backlog/build-repair",
                    "content_sha256": None,
                }
            ],
        }

    @staticmethod
    def _command(
        *,
        command_id: str,
        trigger: str,
        expected_version: int,
        actor_identity_id: str,
        role: str,
        mode: str,
        resource: str,
        action: str,
        field_bindings: dict | None = None,
        evidence_refs: dict | None = None,
        lease_ref: str | None = None,
        decision: str = "allowed",
        submitted_at: str = "2026-08-08T10:01:00+00:00",
    ) -> dict:
        command = {
            "version": "1.0.0",
            "command_id": command_id,
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "trigger": trigger,
            "expected_version": expected_version,
            "actor_identity_id": actor_identity_id,
            "reason": f"Apply the governed {trigger} lifecycle decision.",
            "field_bindings": field_bindings or {},
            "evidence_refs": evidence_refs or {},
            "authority": {
                "role": role,
                "mode": mode,
                "resource": resource,
                "action": action,
                "authority_ref": f"authority:{command_id}",
                "accountable_command_ref": f"command:{command_id}",
                "delegated_runtime_lease_ref": lease_ref,
                "request_sha256": "0" * 64,
                "decision": decision,
                "decision_ref": f"decision:{command_id}",
                "decided_at": "2026-08-08T10:00:00+00:00",
                "result_sha256": "0" * 64,
            },
            "submitted_at": submitted_at,
        }
        command["authority"]["request_sha256"] = (
            transition_authorization_request_sha256(command)
        )
        command["authority"]["result_sha256"] = (
            transition_authorization_result_sha256(command["authority"])
        )
        return command

    def _submit_command(self) -> dict:
        return self._command(
            command_id="transition-command-submit-build-repair",
            trigger="submit",
            expected_version=1,
            actor_identity_id="founder",
            role="product-owner",
            mode="modify-only",
            resource="obligation",
            action="modify",
            field_bindings={
                "revision_id": "work-item-revision-build-repair-1",
                "evidence_plan": [
                    "foundation tests",
                    "component tests",
                    "independent evaluation",
                ],
            },
        )

    def test_full_lifecycle_is_atomic_durable_and_terminally_idempotent(
        self,
    ) -> None:
        with test_workspace("sf-103-lifecycle") as workspace:
            ledger, engine = self._engine(workspace)
            submit = engine.apply(
                self._submit_command(),
                at="2026-08-08T10:02:00+00:00",
            )
            self.assertTrue(submit["decision"]["accepted"])
            self.assertEqual(ledger.get("work-item-build-repair")["work_item"][
                "status"
            ], "ready")

            commands = [
                self._command(
                    command_id="transition-command-queue-build-repair",
                    trigger="queue",
                    expected_version=2,
                    actor_identity_id=(
                        "example-agentic-product-planning-agent"
                    ),
                    role="planning-agent",
                    mode="execute-bounded",
                    resource="context-packet",
                    action="execute",
                    field_bindings={
                        "revision_id": "work-item-revision-build-repair-1"
                    },
                    evidence_refs={
                        "validated work item revision": (
                            "evidence:revision-validation/build-repair"
                        )
                    },
                    lease_ref="lease:planning/build-repair",
                ),
                self._command(
                    command_id="transition-command-start-build-repair",
                    trigger="start",
                    expected_version=3,
                    actor_identity_id=(
                        "example-agentic-product-executor"
                    ),
                    role="executor",
                    mode="execute-bounded",
                    resource="implementation",
                    action="execute",
                    evidence_refs={
                        "active run reference": "run:build-repair-001"
                    },
                    lease_ref="lease:executor/build-repair",
                ),
                self._command(
                    command_id="transition-command-validate-build-repair",
                    trigger="request-validation",
                    expected_version=4,
                    actor_identity_id=(
                        "example-agentic-product-executor"
                    ),
                    role="executor",
                    mode="execute-bounded",
                    resource="implementation",
                    action="execute",
                    evidence_refs={
                        "run evidence bundle": "evidence:run/build-repair-001"
                    },
                    lease_ref="lease:executor/build-repair",
                ),
                self._command(
                    command_id="transition-command-complete-build-repair",
                    trigger="accept-outcome",
                    expected_version=5,
                    actor_identity_id="founder",
                    role="product-owner",
                    mode="human-approval",
                    resource="approval-decision",
                    action="approve",
                    evidence_refs={
                        "validated evidence": "evidence:validated/build-repair",
                        "outcome record": "outcome:build-repair",
                    },
                ),
            ]
            for index, command in enumerate(commands, start=3):
                result = engine.apply(
                    command,
                    at=f"2026-08-08T10:0{index}:00+00:00",
                )
                self.assertTrue(result["decision"]["accepted"])

            current = ledger.get("work-item-build-repair")
            self.assertEqual(current["work_item"]["status"], "completed")
            self.assertEqual(current["work_item"]["record_version"], 6)
            self.assertEqual(
                [item["operation"] for item in ledger.history(
                    "work-item-build-repair"
                )],
                [
                    "create",
                    "transition",
                    "transition",
                    "transition",
                    "transition",
                    "transition",
                ],
            )
            terminal = commands[-1]
            replay = engine.apply(
                terminal,
                at="2026-08-08T10:10:00+00:00",
            )
            self.assertEqual(
                replay,
                engine.get("transition-command-complete-build-repair"),
            )
            self.assertEqual(len(engine.terminal_hooks()), 1)
            self.assertEqual(
                engine.terminal_hooks()[0]["terminal_status"],
                "completed",
            )
            reentry = self._command(
                command_id="transition-command-cancel-completed-repair",
                trigger="cancel",
                expected_version=6,
                actor_identity_id="founder",
                role="product-owner",
                mode="human-approval",
                resource="approval-decision",
                action="approve",
                evidence_refs={
                    "cancellation decision": "decision:cancel-completed-repair"
                },
            )
            self.assertEqual(
                engine.apply(
                    reentry,
                    at="2026-08-08T10:11:00+00:00",
                )["decision"]["reason_code"],
                "terminal-state",
            )
            self.assertEqual(engine.status()["recorded_count"], 5)
            self.assertEqual(engine.status()["rejected_count"], 1)

            reopened = WorkItemTransitionEngine(workspace / "operations.db")
            self.assertEqual(reopened.status()["transition_count"], 6)
            self.assertEqual(len(reopened.terminal_hooks()), 1)

    def test_rejections_are_durable_and_do_not_mutate_work_item(self) -> None:
        with test_workspace("sf-103-rejections") as workspace:
            ledger, engine = self._engine(workspace)
            illegal = self._command(
                command_id="transition-command-illegal-start",
                trigger="start",
                expected_version=1,
                actor_identity_id="example-agentic-product-executor",
                role="executor",
                mode="execute-bounded",
                resource="implementation",
                action="execute",
                evidence_refs={
                    "active run reference": "run:illegal-start"
                },
                lease_ref="lease:executor/illegal-start",
            )
            result = engine.apply(
                illegal,
                at="2026-08-08T10:02:00+00:00",
            )
            self.assertEqual(
                result["decision"]["reason_code"],
                "illegal-transition",
            )
            self.assertEqual(
                ledger.get("work-item-build-repair")["work_item"][
                    "record_version"
                ],
                1,
            )
            self.assertEqual(
                [item["operation"] for item in ledger.history(
                    "work-item-build-repair"
                )],
                ["create"],
            )

            self.assertEqual(
                engine.apply(illegal, at="2026-08-08T10:03:00+00:00"),
                result,
            )
            collision = copy.deepcopy(illegal)
            collision["reason"] = "Use the same id for different content."
            collision["authority"]["request_sha256"] = (
                transition_authorization_request_sha256(collision)
            )
            collision["authority"]["result_sha256"] = (
                transition_authorization_result_sha256(
                    collision["authority"]
                )
            )
            with self.assertRaisesRegex(ProtocolError, "id collision"):
                engine.apply(collision, at="2026-08-08T10:04:00+00:00")

            stale = self._submit_command()
            stale["command_id"] = "transition-command-stale-submit"
            stale["expected_version"] = 2
            stale["authority"]["authority_ref"] = "authority:stale-submit"
            stale["authority"]["accountable_command_ref"] = (
                "command:stale-submit"
            )
            stale["authority"]["decision_ref"] = "decision:stale-submit"
            stale["authority"]["request_sha256"] = (
                transition_authorization_request_sha256(stale)
            )
            stale["authority"]["result_sha256"] = (
                transition_authorization_result_sha256(stale["authority"])
            )
            self.assertEqual(
                engine.apply(
                    stale,
                    at="2026-08-08T10:05:00+00:00",
                )["decision"]["reason_code"],
                "version-conflict",
            )
            self.assertEqual(engine.status()["rejected_count"], 2)

    def test_role_evidence_lease_and_governance_guards_fail_closed(
        self,
    ) -> None:
        with test_workspace("sf-103-guards") as workspace:
            _, engine = self._engine(workspace)
            unauthorized = self._command(
                command_id="transition-command-unauthorized-submit",
                trigger="submit",
                expected_version=1,
                actor_identity_id=(
                    "example-agentic-product-planning-agent"
                ),
                role="product-owner",
                mode="modify-only",
                resource="obligation",
                action="modify",
                field_bindings=self._submit_command()["field_bindings"],
                lease_ref="lease:planning/submit",
            )
            self.assertEqual(
                engine.apply(
                    unauthorized,
                    at="2026-08-08T10:02:00+00:00",
                )["decision"]["reason_code"],
                "unauthorized-role",
            )

            no_lease = self._command(
                command_id="transition-command-planning-no-lease",
                trigger="submit",
                expected_version=1,
                actor_identity_id=(
                    "example-agentic-product-planning-agent"
                ),
                role="planning-agent",
                mode="modify-only",
                resource="design-doc",
                action="modify",
                field_bindings=self._submit_command()["field_bindings"],
            )
            self.assertEqual(
                engine.apply(
                    no_lease,
                    at="2026-08-08T10:03:00+00:00",
                )["decision"]["reason_code"],
                "delegated-lease-required",
            )

            denied = self._submit_command()
            denied["command_id"] = "transition-command-denied-submit"
            denied["authority"]["authority_ref"] = "authority:denied-submit"
            denied["authority"]["accountable_command_ref"] = (
                "command:denied-submit"
            )
            denied["authority"]["decision"] = "denied"
            denied["authority"]["decision_ref"] = "decision:denied-submit"
            denied["authority"]["request_sha256"] = (
                transition_authorization_request_sha256(denied)
            )
            denied["authority"]["result_sha256"] = (
                transition_authorization_result_sha256(denied["authority"])
            )
            self.assertEqual(
                engine.apply(
                    denied,
                    at="2026-08-08T10:04:00+00:00",
                )["decision"]["reason_code"],
                "governance-denied",
            )

            bad_digest = self._submit_command()
            bad_digest["command_id"] = "transition-command-bad-digest"
            bad_digest["authority"]["authority_ref"] = "authority:bad-digest"
            bad_digest["authority"]["accountable_command_ref"] = (
                "command:bad-digest"
            )
            bad_digest["authority"]["decision_ref"] = "decision:bad-digest"
            bad_digest["authority"]["request_sha256"] = "0" * 64
            bad_digest["authority"]["result_sha256"] = (
                transition_authorization_result_sha256(
                    bad_digest["authority"]
                )
            )
            self.assertEqual(
                engine.apply(
                    bad_digest,
                    at="2026-08-08T10:05:00+00:00",
                )["decision"]["reason_code"],
                "governance-request-digest-mismatch",
            )
            self.assertEqual(engine.status()["rejected_count"], 4)

    def test_missing_evidence_and_terminal_reentry_are_rejected(self) -> None:
        with test_workspace("sf-103-evidence") as workspace:
            _, engine = self._engine(workspace)
            engine.apply(
                self._submit_command(),
                at="2026-08-08T10:02:00+00:00",
            )
            queue = self._command(
                command_id="transition-command-queue-no-evidence",
                trigger="queue",
                expected_version=2,
                actor_identity_id=(
                    "example-agentic-product-planning-agent"
                ),
                role="planning-agent",
                mode="execute-bounded",
                resource="context-packet",
                action="execute",
                field_bindings={
                    "revision_id": "work-item-revision-build-repair-1"
                },
                lease_ref="lease:planning/build-repair",
            )
            rejected = engine.apply(
                queue,
                at="2026-08-08T10:03:00+00:00",
            )
            self.assertEqual(
                rejected["decision"]["reason_code"],
                "missing-evidence",
            )

            connection = sqlite3.connect(workspace / "operations.db")
            try:
                with self.assertRaisesRegex(
                    sqlite3.IntegrityError,
                    "stage transitions are immutable",
                ):
                    connection.execute(
                        """
                        UPDATE stage_transitions
                        SET record_sha256 = ?
                        WHERE command_id = ?
                        """,
                        (
                            "0" * 64,
                            "transition-command-queue-no-evidence",
                        ),
                    )
            finally:
                connection.close()

    def test_sf102_history_table_is_migrated_without_losing_history(
        self,
    ) -> None:
        with test_workspace("sf-103-migration") as workspace:
            ledger, _ = self._engine(workspace)
            database = workspace / "operations.db"
            connection = sqlite3.connect(database)
            try:
                connection.execute("PRAGMA foreign_keys = OFF")
                for (trigger_name,) in connection.execute(
                    """
                    SELECT name
                    FROM sqlite_master
                    WHERE type = 'trigger'
                    ORDER BY name
                    """
                ).fetchall():
                    connection.execute(
                        f'DROP TRIGGER "{trigger_name}"'
                    )
                legacy_tables = connection.execute(
                    """
                    SELECT name
                    FROM sqlite_master
                    WHERE type = 'table'
                      AND (
                        name LIKE 'factory_journal_%'
                        OR name LIKE 'factory_public_%'
                        OR name LIKE 'factory_projection_%'
                        OR name = 'factory_operations_backup_history'
                      )
                    ORDER BY name DESC
                    """
                ).fetchall()
                for (table_name,) in legacy_tables:
                    connection.execute(f'DROP TABLE "{table_name}"')
                connection.executescript(
                    """
                    ALTER TABLE work_item_history
                        RENAME TO work_item_history_current;
                    CREATE TABLE work_item_history (
                        work_item_id TEXT NOT NULL REFERENCES work_items(id),
                        record_version INTEGER NOT NULL,
                        operation TEXT NOT NULL
                            CHECK(operation IN ('create','revise')),
                        changed_by TEXT NOT NULL,
                        change_reason TEXT NOT NULL,
                        snapshot_json TEXT NOT NULL,
                        content_sha256 TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        PRIMARY KEY(work_item_id, record_version)
                    );
                    INSERT INTO work_item_history
                    SELECT * FROM work_item_history_current;
                    DROP TABLE work_item_history_current;
                    """
                )
                connection.commit()
            finally:
                connection.close()
            FactoryOperationsBootstrap(database).initialize()
            reopened = WorkItemTransitionEngine(database)
            reopened.initialize()
            self.assertEqual(
                [item["operation"] for item in ledger.history(
                    "work-item-build-repair"
                )],
                ["create"],
            )
            result = reopened.apply(
                self._submit_command(),
                at="2026-08-08T10:02:00+00:00",
            )
            self.assertTrue(result["decision"]["accepted"])


if __name__ == "__main__":
    unittest.main()
