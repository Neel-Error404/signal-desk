from __future__ import annotations

import copy
import json
import random
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    learning_trajectory_content_sha256,
    normalize_learning_trajectory,
    validate_learning_trajectory,
)
from tests._sf500_support import (
    complete_sources,
    source_manifest,
    source_record,
)


class SF500LearningTrajectoryComponentTests(unittest.TestCase):
    def test_normalizes_all_categories_and_redacts_raw_or_secret_facts(self) -> None:
        sources = complete_sources()
        sources[0]["facts"].update(
            {
                "api_key": "sk-testvalue12345",
                "chat_messages": ["private chat message"],
                "details": {
                    "payload": ["raw prompt body with private user data"]
                },
                "messages": ["private user message"],
                "output_text": "raw output body",
                "prompt": "raw worker prompt",
                "prompt_text": "raw prompt variant",
                "prompts": ["second raw prompt"],
                "response_text": "raw response variant",
                "safe_summary": "bounded-action",
                "transcripts": ["raw transcript"],
            }
        )
        sources[0]["source_sha256"] = canonical_sha256(sources[0]["facts"])
        trajectory = normalize_learning_trajectory(source_manifest(sources))

        self.assertEqual(
            {event["category"] for event in trajectory["events"]},
            {
                "worker-action",
                "owner-correction",
                "test",
                "retrieval",
                "incident",
                "outcome",
            },
        )
        worker = next(
            event
            for event in trajectory["events"]
            if event["category"] == "worker-action"
        )
        self.assertEqual(worker["facts"]["input_tokens"], 1200)
        self.assertEqual(
            worker["facts"]["safe_summary"],
            "bounded-action",
        )
        self.assertNotIn("api_key", worker["facts"])
        self.assertNotIn("chat_messages", worker["facts"])
        self.assertEqual(worker["facts"]["details"], {"payload": []})
        self.assertNotIn("messages", worker["facts"])
        self.assertNotIn("output_text", worker["facts"])
        self.assertNotIn("prompt", worker["facts"])
        self.assertNotIn("prompt_text", worker["facts"])
        self.assertNotIn("prompts", worker["facts"])
        self.assertNotIn("response_text", worker["facts"])
        self.assertNotIn("transcripts", worker["facts"])
        self.assertEqual(
            {item["reason"] for item in trajectory["redactions"]},
            {"secret-field", "raw-content", "free-text"},
        )

    def test_missing_links_and_delayed_outcomes_remain_explicit(self) -> None:
        sources = [
            source
            for source in complete_sources()
            if source["category"] != "outcome"
        ]
        original = source_manifest(sources)
        before = copy.deepcopy(original)
        pending = normalize_learning_trajectory(original)
        self.assertEqual(pending["outcome"]["status"], "pending")
        self.assertEqual(pending["status"], "partial")
        self.assertTrue(
            any(
                link["reason_code"] == "delayed-outcome"
                for link in pending["missing_links"]
            )
        )
        self.assertEqual(original, before)

        attached = normalize_learning_trajectory(
            source_manifest(complete_sources())
        )
        self.assertEqual(attached["outcome"]["status"], "attached")
        self.assertEqual(len(attached["outcome"]["attached_event_ids"]), 1)

    def test_unexpected_outcome_reference_does_not_resolve_expected_outcome(
        self,
    ) -> None:
        sources = complete_sources()
        outcome = next(
            source for source in sources if source["category"] == "outcome"
        )
        outcome["facts"]["outcome_ref"] = "outcome:other-work"
        outcome["source_sha256"] = canonical_sha256(outcome["facts"])
        trajectory = normalize_learning_trajectory(source_manifest(sources))
        self.assertEqual(trajectory["outcome"]["status"], "pending")
        self.assertEqual(trajectory["outcome"]["resolved"], [])

    def test_optional_oversized_source_is_excluded_but_required_source_fails(
        self,
    ) -> None:
        oversized = source_record(
            "source-oversized",
            "worker-action",
            {"summary": "x" * 70000},
        )
        trajectory = normalize_learning_trajectory(
            source_manifest([oversized], expected_outcome_refs=[])
        )
        self.assertEqual(
            trajectory["exclusions"][0]["reason"],
            "source-byte-budget",
        )

        oversized["required"] = True
        with self.assertRaisesRegex(ProtocolError, "exceeds the source byte"):
            normalize_learning_trajectory(
                source_manifest([oversized], expected_outcome_refs=[])
            )

    def test_duplicate_source_is_coalesced_and_changed_identity_fails(self) -> None:
        source = complete_sources()[0]
        duplicate = normalize_learning_trajectory(
            source_manifest(
                [source, copy.deepcopy(source)],
                expected_outcome_refs=[],
            )
        )
        self.assertEqual(len(duplicate["events"]), 1)
        self.assertEqual(duplicate["exclusions"][0]["reason"], "duplicate")

        changed = copy.deepcopy(source)
        changed["facts"]["status"] = "failed"
        changed["source_sha256"] = canonical_sha256(changed["facts"])
        with self.assertRaisesRegex(ProtocolError, "identity collision"):
            normalize_learning_trajectory(
                source_manifest(
                    [source, changed],
                    expected_outcome_refs=[],
                )
            )

    def test_sampling_is_order_independent_and_preserves_all_anchors(self) -> None:
        sources = [
            source_record(
                f"source-worker-{index:03d}",
                "worker-action",
                {"sequence": index, "status": "completed"},
            )
            for index in range(20)
        ]
        sources.extend(
            [
                source_record(
                    "source-owner-anchor",
                    "owner-correction",
                    {"status": "accepted"},
                ),
                source_record(
                    "source-incident-anchor",
                    "incident",
                    {"status": "failed"},
                ),
            ]
        )
        first = normalize_learning_trajectory(
            source_manifest(sources, expected_outcome_refs=[]),
            maximum_events=6,
            maximum_bytes=32768,
        )
        shuffled = copy.deepcopy(sources)
        random.Random(17).shuffle(shuffled)
        second = normalize_learning_trajectory(
            source_manifest(shuffled, expected_outcome_refs=[]),
            maximum_events=6,
            maximum_bytes=32768,
        )
        self.assertEqual(first, second)
        selected_ids = {event["source"]["id"] for event in first["events"]}
        self.assertIn("source-owner-anchor", selected_ids)
        self.assertIn("source-incident-anchor", selected_ids)

    def test_changed_source_changes_snapshot_and_trajectory_digest(self) -> None:
        sources = complete_sources()
        first = normalize_learning_trajectory(source_manifest(sources))
        changed = copy.deepcopy(sources)
        changed[0]["facts"]["status"] = "failed"
        changed[0]["source_sha256"] = canonical_sha256(changed[0]["facts"])
        second = normalize_learning_trajectory(source_manifest(changed))
        self.assertNotEqual(
            first["source_snapshot_sha256"],
            second["source_snapshot_sha256"],
        )
        self.assertNotEqual(first["content_sha256"], second["content_sha256"])

    def test_source_reference_must_be_opaque_and_run_binding_is_exact(self) -> None:
        source = complete_sources()[0]
        source["source_ref"] = "manual:raw prompt with private user data"
        with self.assertRaises(ProtocolError):
            normalize_learning_trajectory(
                source_manifest([source], expected_outcome_refs=[])
            )

        source = complete_sources()[0]
        source["producer_id"] = "raw prompt body with private user data"
        with self.assertRaises(ProtocolError):
            normalize_learning_trajectory(
                source_manifest([source], expected_outcome_refs=[])
            )

        source = complete_sources()[0]
        source["run_id"] = None
        with self.assertRaisesRegex(ProtocolError, "changed run binding"):
            normalize_learning_trajectory(
                source_manifest([source], expected_outcome_refs=[])
            )

        manifest = source_manifest([complete_sources()[0]], expected_outcome_refs=[])
        manifest["run_id"] = None
        manifest["content_sha256"] = learning_trajectory_content_sha256(manifest)
        with self.assertRaisesRegex(ProtocolError, "changed run binding"):
            normalize_learning_trajectory(manifest)

    def test_outcomes_require_complete_expected_measurements(self) -> None:
        no_expectation = normalize_learning_trajectory(
            source_manifest(complete_sources(), expected_outcome_refs=[])
        )
        self.assertEqual(no_expectation["outcome"]["status"], "unavailable")
        self.assertEqual(no_expectation["outcome"]["resolved"], [])

        sources = complete_sources()
        partial = normalize_learning_trajectory(
            source_manifest(
                sources,
                expected_outcome_refs=[
                    "outcome:sf-500-delivery",
                    "outcome:held-out-quality",
                ],
            )
        )
        self.assertEqual(partial["outcome"]["status"], "pending")
        self.assertEqual(
            [
                link["expected_ref"]
                for link in partial["missing_links"]
                if link["reason_code"] == "delayed-outcome"
            ],
            ["outcome:held-out-quality"],
        )

        unknown = source_record(
            "source-outcome-unknown",
            "outcome",
            {
                "outcome_ref": "outcome:sf-500-delivery",
                "status": "unknown",
            },
        )
        unknown_plus_met = normalize_learning_trajectory(
            source_manifest(
                [*sources, unknown],
                expected_outcome_refs=["outcome:sf-500-delivery"],
            )
        )
        self.assertEqual(unknown_plus_met["outcome"]["status"], "pending")
        self.assertEqual(
            unknown_plus_met["outcome"]["attached_event_ids"],
            [],
        )

        missed = source_record(
            "source-outcome-missed",
            "outcome",
            {
                "outcome_ref": "outcome:sf-500-delivery",
                "status": "missed",
            },
        )
        contradictory = normalize_learning_trajectory(
            source_manifest(
                [*sources, missed],
                expected_outcome_refs=["outcome:sf-500-delivery"],
            )
        )
        self.assertEqual(
            contradictory["outcome"]["status"],
            "contradictory",
        )
        self.assertEqual(
            [
                link["reason_code"]
                for link in contradictory["missing_links"]
            ],
            ["contradictory-outcome"],
        )

    def test_public_validator_rejects_forged_bindings_times_and_anchors(self) -> None:
        trajectory = normalize_learning_trajectory(
            source_manifest(complete_sources())
        )

        def finalize(changed: dict, event_index: int = 0) -> dict:
            changed["events"][event_index]["content_sha256"] = (
                learning_trajectory_content_sha256(
                    changed["events"][event_index]
                )
            )
            changed["sampling"]["selected_bytes"] = sum(
                len(
                    json.dumps(
                        event,
                        sort_keys=True,
                        separators=(",", ":"),
                        ensure_ascii=True,
                        allow_nan=False,
                    ).encode("utf-8")
                )
                for event in changed["events"]
            )
            changed["content_sha256"] = learning_trajectory_content_sha256(
                changed
            )
            return changed

        changed_binding = copy.deepcopy(trajectory)
        changed_binding["events"][0]["bindings"]["project_id"] = "other-project"
        with self.assertRaisesRegex(ProtocolError, "changed binding"):
            validate_learning_trajectory(finalize(changed_binding))

        future = copy.deepcopy(trajectory)
        future["events"][-1]["recorded_at"] = "2026-08-14T22:00:00+00:00"
        with self.assertRaisesRegex(ProtocolError, "timestamps"):
            validate_learning_trajectory(
                finalize(future, len(future["events"]) - 1)
            )

        changed_anchor = copy.deepcopy(trajectory)
        owner_index = next(
            index
            for index, event in enumerate(changed_anchor["events"])
            if event["category"] == "owner-correction"
        )
        changed_anchor["events"][owner_index]["anchor"] = False
        with self.assertRaisesRegex(ProtocolError, "anchor is invalid"):
            validate_learning_trajectory(
                finalize(changed_anchor, owner_index)
            )

        changed_reference = copy.deepcopy(trajectory)
        changed_reference["events"][0]["source"]["source_ref"] = (
            "manual:raw prompt"
        )
        with self.assertRaises(ProtocolError):
            validate_learning_trajectory(finalize(changed_reference))

        changed_evidence = copy.deepcopy(trajectory)
        changed_evidence["events"][0]["evidence"][0]["id"] = (
            "evidence raw proof"
        )
        with self.assertRaises(ProtocolError):
            validate_learning_trajectory(finalize(changed_evidence))

        changed_producer = copy.deepcopy(trajectory)
        changed_producer["events"][0]["source"]["producer_id"] = (
            "raw prompt body with private user data"
        )
        with self.assertRaises(ProtocolError):
            validate_learning_trajectory(finalize(changed_producer))

    def test_timestamp_order_uses_absolute_instants(self) -> None:
        later = source_record(
            "source-time-later",
            "worker-action",
            {"sequence": "later"},
            occurred_at="2026-08-14T17:00:00+00:00",
            recorded_at="2026-08-14T17:01:00+00:00",
        )
        earlier = source_record(
            "source-time-earlier",
            "worker-action",
            {"sequence": "earlier"},
            occurred_at="2026-08-14T21:00:00+05:30",
            recorded_at="2026-08-14T21:01:00+05:30",
        )
        trajectory = normalize_learning_trajectory(
            source_manifest(
                [later, earlier],
                expected_outcome_refs=[],
            )
        )
        self.assertEqual(
            [event["source"]["id"] for event in trajectory["events"]],
            ["source-time-earlier", "source-time-later"],
        )

    def test_evidence_order_is_semantically_irrelevant(self) -> None:
        source = complete_sources()[0]
        source["evidence"].append(
            {
                "id": "evidence:secondary-proof",
                "sha256": canonical_sha256({"proof": "secondary"}),
            }
        )
        reversed_evidence = copy.deepcopy(source)
        reversed_evidence["evidence"].reverse()
        first = normalize_learning_trajectory(
            source_manifest([source], expected_outcome_refs=[])
        )
        second = normalize_learning_trajectory(
            source_manifest([reversed_evidence], expected_outcome_refs=[])
        )
        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main()
