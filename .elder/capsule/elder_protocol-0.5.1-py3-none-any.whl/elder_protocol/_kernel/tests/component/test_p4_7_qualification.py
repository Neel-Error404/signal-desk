from __future__ import annotations

import base64
import copy
import hashlib
import json
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from elder_protocol.errors import ProtocolError
from elder_protocol.qualification import (
    qualify_hosted_bundle,
    validate_qualification_policy,
)
from tests._support import test_workspace


def canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")


def content_digest(value: dict[str, Any]) -> str:
    payload = {key: item for key, item in value.items() if key != "content_sha256"}
    return hashlib.sha256(canonical_bytes(payload)).hexdigest()


def simple_maturity() -> dict[str, Any]:
    return {
        "version": "0.5.1",
        "current_assessment": {
            "level": "L1",
            "scope": "local reference",
            "evidence": ["local-evidence"],
            "blockers": ["hosted evidence absent"],
        },
        "levels": [
            {
                "id": level,
                "name": level,
                "claim": f"{level} claim",
                "required_capabilities": [f"{level.lower()}-capability"],
                "required_evidence": [f"{level.lower()}-evidence"],
                "prohibited_claims": [],
            }
            for level in ["L0", "L1", "L2", "L3", "L4", "L5"]
        ],
    }


def qualification_policy(
    public_key: Ed25519PrivateKey,
) -> dict[str, Any]:
    encoded_key = base64.b64encode(
        public_key.public_key().public_bytes_raw()
    ).decode("ascii")
    gates = []
    for level in ["L0", "L1", "L2", "L3", "L4", "L5"]:
        gates.extend(
            [
                {
                    "id": f"{level.lower()}-capability",
                    "level": level,
                    "requirement_kind": "capability",
                    "requirement": f"{level.lower()}-capability",
                    "evidence_types": ["hosted-check"],
                    "minimum_records": 1,
                    "maximum_age_days": 30,
                    "environments": ["production"],
                    "required_signer_roles": ["independent-verifier"],
                    "require_independent_verifier": True,
                },
                {
                    "id": f"{level.lower()}-evidence",
                    "level": level,
                    "requirement_kind": "evidence",
                    "requirement": f"{level.lower()}-evidence",
                    "evidence_types": ["hosted-check"],
                    "minimum_records": 1,
                    "maximum_age_days": 30,
                    "environments": ["production"],
                    "required_signer_roles": ["independent-verifier"],
                    "require_independent_verifier": True,
                },
            ]
        )
    return {
        "version": "0.5.1",
        "id": "test-hosted-qualification",
        "trust": {
            "algorithms": ["ed25519"],
            "require_signature": True,
            "anchors": [
                {
                    "id": "verifier-key-1",
                    "subject_identity": "fixture-independent-verifier",
                    "algorithm": "ed25519",
                    "public_key_base64": encoded_key,
                    "roles": ["independent-verifier"],
                    "providers": ["fixture-ci"],
                    "source_hosts": ["ci.example.test"],
                    "valid_from": "2026-01-01T00:00:00+00:00",
                    "valid_until": "2027-01-01T00:00:00+00:00",
                    "status": "active",
                }
            ],
        },
        "bundle": {
            "maximum_age_days": 30,
            "maximum_records": 500,
            "maximum_total_bytes": 10485760,
            "allowed_environments": ["production"],
            "require_https_source": True,
            "reject_symlinks": True,
        },
        "qualification": {
            "cumulative": True,
            "fail_on_contradiction": True,
            "fail_on_untrusted_record": True,
            "advisory_only": True,
            "can_mutate_maturity": False,
            "can_promote": False,
            "can_deploy": False,
        },
        "gates": gates,
    }


def signed_record(
    root: Path,
    private_key: Ed25519PrivateKey,
    *,
    gate_id: str,
    index: int,
    issued_at: datetime,
    expires_days: int = 20,
) -> dict[str, Any]:
    payload_path = Path("payloads") / f"{gate_id}.json"
    absolute_payload = root / payload_path
    absolute_payload.parent.mkdir(parents=True, exist_ok=True)
    absolute_payload.write_text(
        json.dumps({"gate": gate_id, "status": "passed"}, sort_keys=True),
        encoding="utf-8",
    )
    record = {
        "id": f"EVID-{index:03d}",
        "gate_id": gate_id,
        "evidence_type": "hosted-check",
        "provider": "fixture-ci",
        "project_id": "fixture-project",
        "environment": "production",
        "artifact_sha256": "a" * 64,
        "producer_identity": "fixture-builder",
        "source_uri": f"https://ci.example.test/evidence/{gate_id}",
        "payload_path": payload_path.as_posix(),
        "payload_sha256": hashlib.sha256(absolute_payload.read_bytes()).hexdigest(),
        "result": "passed",
        "issued_at": issued_at.isoformat(),
        "expires_at": (issued_at + timedelta(days=expires_days)).isoformat(),
    }
    statement = canonical_bytes(record)
    record["attestation"] = {
        "signer_id": "verifier-key-1",
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement)
        ).decode("ascii"),
    }
    record["content_sha256"] = content_digest(record)
    return record


def resign_record(
    record: dict[str, Any],
    private_key: Ed25519PrivateKey,
) -> None:
    statement = {
        key: value
        for key, value in record.items()
        if key not in {"attestation", "content_sha256"}
    }
    statement_bytes = canonical_bytes(statement)
    record["attestation"] = {
        "signer_id": "verifier-key-1",
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement_bytes).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement_bytes)
        ).decode("ascii"),
    }
    record["content_sha256"] = content_digest(record)


def write_bundle(
    root: Path,
    records: list[dict[str, Any]],
    private_key: Ed25519PrivateKey,
    *,
    issued_at: datetime,
    target_level: str = "L2",
    expires_days: int = 20,
) -> Path:
    bundle = {
        "version": "0.5.1",
        "bundle_id": "BUNDLE-001",
        "source_revision": "b" * 40,
        "project_id": "fixture-project",
        "environment": "production",
        "target_level": target_level,
        "artifact_sha256": "a" * 64,
        "provider": "fixture-ci",
        "producer_identity": "fixture-bundle-assembler",
        "source_uri": "https://ci.example.test/bundles/BUNDLE-001",
        "created_at": issued_at.isoformat(),
        "expires_at": (issued_at + timedelta(days=expires_days)).isoformat(),
        "records": records,
    }
    statement = canonical_bytes(bundle)
    bundle["attestation"] = {
        "signer_id": "verifier-key-1",
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement)
        ).decode("ascii"),
    }
    bundle["content_sha256"] = content_digest(bundle)
    manifest = root / "bundle.json"
    manifest.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
    return manifest


class HostedQualificationComponentTests(unittest.TestCase):
    def test_signed_cumulative_evidence_qualifies_l2_without_mutating_maturity(
        self,
    ) -> None:
        with test_workspace("p4-7-qualified") as workspace:
            private_key = Ed25519PrivateKey.generate()
            maturity = simple_maturity()
            original_maturity = copy.deepcopy(maturity)
            policy = qualification_policy(private_key)
            issued_at = datetime(2026, 8, 6, 8, 0, tzinfo=UTC)
            required_gates = [
                "l0-capability",
                "l0-evidence",
                "l1-capability",
                "l1-evidence",
                "l2-capability",
                "l2-evidence",
            ]
            records = [
                signed_record(
                    workspace,
                    private_key,
                    gate_id=gate_id,
                    index=index,
                    issued_at=issued_at,
                )
                for index, gate_id in enumerate(required_gates, start=1)
            ]
            manifest = write_bundle(
                workspace,
                records,
                private_key,
                issued_at=issued_at,
            )

            report = qualify_hosted_bundle(
                manifest,
                policy,
                maturity,
                at="2026-08-06T09:00:00+00:00",
            )

            self.assertTrue(report["qualified"])
            self.assertEqual(report["target_level"], "L2")
            self.assertEqual(report["achieved_level"], "L2")
            self.assertEqual(report["canonical_current_level"], "L1")
            self.assertTrue(report["advisory_only"])
            self.assertFalse(report["applies_maturity_mutation"])
            self.assertFalse(report["can_promote"])
            self.assertFalse(report["can_deploy"])
            self.assertEqual(maturity, original_maturity)
            self.assertEqual(len(report["gate_results"]), 12)
            self.assertEqual(len(report["content_sha256"]), 64)

    def test_forged_signature_and_mutated_or_deleted_payload_fail_closed(
        self,
    ) -> None:
        for mutation in ["signature", "payload", "delete"]:
            with self.subTest(mutation=mutation):
                with test_workspace(f"p4-7-{mutation}") as workspace:
                    private_key = Ed25519PrivateKey.generate()
                    issued_at = datetime(2026, 8, 6, 8, 0, tzinfo=UTC)
                    record = signed_record(
                        workspace,
                        private_key,
                        gate_id="l0-capability",
                        index=1,
                        issued_at=issued_at,
                    )
                    manifest = write_bundle(
                        workspace,
                        [record],
                        private_key,
                        issued_at=issued_at,
                        target_level="L0",
                    )
                    payload = workspace / record["payload_path"]
                    if mutation == "signature":
                        record["attestation"]["signature_base64"] = base64.b64encode(
                            b"x" * 64
                        ).decode("ascii")
                        record["content_sha256"] = content_digest(record)
                        manifest = write_bundle(
                            workspace,
                            [record],
                            private_key,
                            issued_at=issued_at,
                            target_level="L0",
                        )
                    elif mutation == "payload":
                        payload.write_text('{"mutated": true}', encoding="utf-8")
                    else:
                        payload.unlink()

                    with self.assertRaises(ProtocolError):
                        qualify_hosted_bundle(
                            manifest,
                            qualification_policy(private_key),
                            simple_maturity(),
                            at="2026-08-06T09:00:00+00:00",
                        )

    def test_bundle_attestation_rejects_record_deletion_and_target_tampering(
        self,
    ) -> None:
        for mutation in ["record-deletion", "target-level"]:
            with self.subTest(mutation=mutation):
                with test_workspace(f"p4-7-bundle-{mutation}") as workspace:
                    private_key = Ed25519PrivateKey.generate()
                    issued_at = datetime(2026, 8, 6, 8, 0, tzinfo=UTC)
                    records = [
                        signed_record(
                            workspace,
                            private_key,
                            gate_id=gate_id,
                            index=index,
                            issued_at=issued_at,
                        )
                        for index, gate_id in enumerate(
                            ["l0-capability", "l0-evidence"],
                            start=1,
                        )
                    ]
                    manifest = write_bundle(
                        workspace,
                        records,
                        private_key,
                        issued_at=issued_at,
                        target_level="L0",
                    )
                    bundle = json.loads(manifest.read_text(encoding="utf-8"))
                    if mutation == "record-deletion":
                        bundle["records"].pop()
                    else:
                        bundle["target_level"] = "L1"
                    bundle["content_sha256"] = content_digest(bundle)
                    manifest.write_text(json.dumps(bundle, indent=2), encoding="utf-8")

                    with self.assertRaisesRegex(
                        ProtocolError,
                        "signed statement digest|signature verification",
                    ):
                        qualify_hosted_bundle(
                            manifest,
                            qualification_policy(private_key),
                            simple_maturity(),
                            at="2026-08-06T09:00:00+00:00",
                        )

    def test_stale_contradictory_and_incomplete_evidence_do_not_qualify(
        self,
    ) -> None:
        with test_workspace("p4-7-negative-gates") as workspace:
            private_key = Ed25519PrivateKey.generate()
            issued_at = datetime(2026, 8, 6, 8, 0, tzinfo=UTC)
            policy = qualification_policy(private_key)
            records = [
                signed_record(
                    workspace,
                    private_key,
                    gate_id=gate_id,
                    index=index,
                    issued_at=issued_at,
                )
                for index, gate_id in enumerate(
                    [
                        "l0-capability",
                        "l0-evidence",
                        "l1-capability",
                        "l1-evidence",
                        "l2-capability",
                    ],
                    start=1,
                )
            ]
            manifest = write_bundle(
                workspace,
                records,
                private_key,
                issued_at=issued_at,
            )
            incomplete = qualify_hosted_bundle(
                manifest,
                policy,
                simple_maturity(),
                at="2026-08-06T09:00:00+00:00",
            )
            self.assertFalse(incomplete["qualified"])
            self.assertEqual(incomplete["achieved_level"], "L1")
            self.assertIn(
                "l2-evidence: insufficient-current-evidence",
                incomplete["blockers"],
            )

            contradiction = signed_record(
                workspace,
                private_key,
                gate_id="l2-capability",
                index=20,
                issued_at=issued_at,
            )
            contradiction["result"] = "failed"
            resign_record(contradiction, private_key)
            manifest = write_bundle(
                workspace,
                [*records, contradiction],
                private_key,
                issued_at=issued_at,
            )
            contradicted = qualify_hosted_bundle(
                manifest,
                policy,
                simple_maturity(),
                at="2026-08-06T09:00:00+00:00",
            )
            self.assertFalse(contradicted["qualified"])
            self.assertIn(
                "l2-capability: contradictory-or-revoked-evidence",
                contradicted["blockers"],
            )

            with self.assertRaisesRegex(ProtocolError, "stale"):
                stale_records = [
                    signed_record(
                        workspace,
                        private_key,
                        gate_id="l0-capability",
                        index=30,
                        issued_at=issued_at,
                        expires_days=90,
                    )
                ]
                stale_manifest = write_bundle(
                    workspace,
                    stale_records,
                    private_key,
                    issued_at=issued_at,
                    target_level="L0",
                    expires_days=90,
                )
                qualify_hosted_bundle(
                    stale_manifest,
                    policy,
                    simple_maturity(),
                    at="2026-09-20T09:00:00+00:00",
                )

    def test_policy_without_trust_anchors_cannot_accept_claimed_evidence(
        self,
    ) -> None:
        with test_workspace("p4-7-no-trust") as workspace:
            private_key = Ed25519PrivateKey.generate()
            issued_at = datetime(2026, 8, 6, 8, 0, tzinfo=UTC)
            policy = qualification_policy(private_key)
            policy["trust"]["anchors"] = []
            validate_qualification_policy(policy, simple_maturity())
            record = signed_record(
                workspace,
                private_key,
                gate_id="l0-capability",
                index=1,
                issued_at=issued_at,
            )
            manifest = write_bundle(
                workspace,
                [record],
                private_key,
                issued_at=issued_at,
                target_level="L0",
            )
            with self.assertRaisesRegex(ProtocolError, "active trust anchor"):
                qualify_hosted_bundle(
                    manifest,
                    policy,
                    simple_maturity(),
                    at="2026-08-06T09:00:00+00:00",
                )

    def test_future_dated_bundle_and_record_fail_closed(self) -> None:
        with test_workspace("p4-7-future") as workspace:
            private_key = Ed25519PrivateKey.generate()
            future = datetime(2026, 8, 6, 10, 0, tzinfo=UTC)
            records = [
                signed_record(
                    workspace,
                    private_key,
                    gate_id=gate_id,
                    index=index,
                    issued_at=future,
                )
                for index, gate_id in enumerate(
                    ["l0-capability", "l0-evidence"],
                    start=1,
                )
            ]
            future_bundle = write_bundle(
                workspace,
                records,
                private_key,
                issued_at=future,
                target_level="L0",
            )
            with self.assertRaisesRegex(ProtocolError, "future"):
                qualify_hosted_bundle(
                    future_bundle,
                    qualification_policy(private_key),
                    simple_maturity(),
                    at="2026-08-06T09:00:00+00:00",
                )

            current = datetime(2026, 8, 6, 8, 0, tzinfo=UTC)
            current_bundle = write_bundle(
                workspace,
                records,
                private_key,
                issued_at=current,
                target_level="L0",
            )
            with self.assertRaisesRegex(ProtocolError, "future"):
                qualify_hosted_bundle(
                    current_bundle,
                    qualification_policy(private_key),
                    simple_maturity(),
                    at="2026-08-06T09:00:00+00:00",
                )

    def test_trust_anchor_identity_validity_and_bundle_limits_fail_closed(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p4-7-anchor-and-limits") as workspace:
            private_key = Ed25519PrivateKey.generate()
            records = [
                signed_record(
                    workspace,
                    private_key,
                    gate_id=gate_id,
                    index=index,
                    issued_at=evaluated_at - timedelta(hours=1),
                )
                for index, gate_id in enumerate(
                    ["l0-capability", "l0-evidence"],
                    start=1,
                )
            ]
            manifest = write_bundle(
                workspace,
                records,
                private_key,
                issued_at=evaluated_at - timedelta(hours=1),
                target_level="L0",
            )
            base_policy = qualification_policy(private_key)

            expired_anchor = copy.deepcopy(base_policy)
            expired_anchor["trust"]["anchors"][0]["valid_until"] = (
                evaluated_at - timedelta(minutes=1)
            ).isoformat()
            with self.assertRaisesRegex(ProtocolError, "validity window"):
                qualify_hosted_bundle(
                    manifest,
                    expired_anchor,
                    simple_maturity(),
                    at=evaluated_at.isoformat(),
                )

            non_independent = copy.deepcopy(base_policy)
            non_independent["trust"]["anchors"][0][
                "subject_identity"
            ] = "fixture-bundle-assembler"
            with self.assertRaisesRegex(ProtocolError, "independent"):
                qualify_hosted_bundle(
                    manifest,
                    non_independent,
                    simple_maturity(),
                    at=evaluated_at.isoformat(),
                )

            record_limited = copy.deepcopy(base_policy)
            record_limited["bundle"]["maximum_records"] = 1
            with self.assertRaisesRegex(ProtocolError, "record-count"):
                qualify_hosted_bundle(
                    manifest,
                    record_limited,
                    simple_maturity(),
                    at=evaluated_at.isoformat(),
                )

            byte_limited = copy.deepcopy(base_policy)
            byte_limited["bundle"]["maximum_total_bytes"] = 1
            with self.assertRaisesRegex(ProtocolError, "byte-size"):
                qualify_hosted_bundle(
                    manifest,
                    byte_limited,
                    simple_maturity(),
                    at=evaluated_at.isoformat(),
                )


if __name__ == "__main__":
    unittest.main()
