from __future__ import annotations

import copy
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_contracts import validate_idempotent_replay
from elder_protocol.factory_workers import (
    SEND_COMMAND_TYPES,
    FakeWorkerAdapter,
    FakeWorkerCrash,
    WorkerCapabilityManifest,
    WorkerConformanceScenario,
)
from tests._support import test_workspace


class FakeWorkerAdapterComponentTests(unittest.TestCase):
    @staticmethod
    def _prepare_start(
        adapter: FakeWorkerAdapter,
        scenario: WorkerConformanceScenario,
        *,
        index_offset: int = 0,
    ) -> tuple[dict, dict]:
        prepare = scenario.request(
            "prepare",
            {
                "work_item": {
                    "id": scenario.work_item_id,
                    "project_id": scenario.project_id,
                },
                "authority": {
                    "authority_ref": scenario.authority_ref,
                },
                "context": {
                    "content_sha256": scenario.context_sha256,
                },
            },
            index=1 + index_offset,
        )
        prepared = adapter.execute(prepare)
        start = scenario.request(
            "start",
            {
                "prepared_run": copy.deepcopy(
                    prepared["result"]["prepared_run"]
                )
            },
            index=2 + index_offset,
        )
        started = adapter.execute(start)
        return prepared, started

    def test_prepare_and_start_preserve_factory_identity(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf200-prepare-start") as workspace:
            adapter = FakeWorkerAdapter(workspace / "worker.db")
            prepared, started = self._prepare_start(adapter, scenario)
            run = prepared["result"]["prepared_run"]
            session = started["result"]["worker_session"]
            self.assertEqual(run["run_id"], scenario.run_id)
            self.assertEqual(
                run["worker_session_id"],
                scenario.worker_session_id,
            )
            self.assertEqual(
                run["session_generation"],
                scenario.session_generation,
            )
            self.assertEqual(run["workspace_id"], scenario.workspace_id)
            self.assertEqual(run["authority_ref"], scenario.authority_ref)
            self.assertEqual(run["context_sha256"], scenario.context_sha256)
            self.assertEqual(
                session["worker_session_id"],
                scenario.worker_session_id,
            )
            self.assertNotEqual(
                session["external_session_ref"],
                scenario.worker_session_id,
            )

    def test_send_forms_duplicate_once_and_replay_drift_fails(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf200-send-replay") as workspace:
            adapter = FakeWorkerAdapter(workspace / "worker.db")
            self._prepare_start(adapter, scenario)
            authority_drift = scenario.request(
                "send",
                {"command": scenario.command("worker.prompt", index=30)},
                index=30,
            )
            authority_drift["payload"]["command"]["authority_ref"] = (
                "elder://authority/not-authorized"
            )
            authority_drift["payload_sha256"] = canonical_sha256(
                authority_drift["payload"]
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "authority_ref",
            ):
                adapter.execute(authority_drift)
            self.assertEqual(adapter.effect_count(authority_drift), 0)

            exchanges = []
            for index, command_type in enumerate(
                SEND_COMMAND_TYPES,
                start=3,
            ):
                request = scenario.request(
                    "send",
                    {
                        "command": scenario.command(
                            command_type,
                            index=index,
                        )
                    },
                    index=index,
                )
                response = adapter.execute(request)
                self.assertEqual(response["disposition"], "succeeded")
                exchanges.append((request, response))

            original, _ = exchanges[0]
            duplicate = copy.deepcopy(original)
            duplicate["request_id"] = "request-sf200-send-duplicate"
            response = adapter.execute(duplicate)
            self.assertEqual(response["disposition"], "duplicate")
            self.assertEqual(adapter.effect_count(original), 1)

            def change_envelope_and_command(
                field: str,
                value: str,
            ):
                def mutate(request: dict) -> None:
                    request[field] = value
                    command_field = (
                        "worker_session_id"
                        if field == "session_id"
                        else field
                    )
                    request["payload"]["command"][command_field] = value
                    request["payload"]["command"]["payload_sha256"] = (
                        canonical_sha256(
                            request["payload"]["command"]["payload"]
                        )
                    )
                    request["payload_sha256"] = canonical_sha256(
                        request["payload"]
                    )

                return mutate

            mutations = {
                "work_item_id": change_envelope_and_command(
                    "work_item_id",
                    "work-item-drift",
                ),
                "run_id": change_envelope_and_command(
                    "run_id",
                    "run-drift",
                ),
                "session_id": change_envelope_and_command(
                    "session_id",
                    "worker-session-drift",
                ),
                "correlation_id": change_envelope_and_command(
                    "correlation_id",
                    "correlation-drift",
                ),
                "causation_id": change_envelope_and_command(
                    "causation_id",
                    "cause-drift",
                ),
                "redaction": lambda request: request.update(
                    {
                        "redaction": {
                            "classification": "confidential",
                            "redacted_fields": [],
                        }
                    }
                ),
                "extensions": lambda request: request["extensions"].update(
                    {"elder.factory/session-generation": 2}
                ),
                "payload": lambda request: (
                    request["payload"]["command"]["payload"].update(
                        {"instruction": "Changed under the same key."}
                    ),
                    request["payload"]["command"].update(
                        {
                            "payload_sha256": canonical_sha256(
                                request["payload"]["command"]["payload"]
                            )
                        }
                    ),
                    request.update(
                        {
                            "payload_sha256": canonical_sha256(
                                request["payload"]
                            )
                        }
                    ),
                ),
            }
            for label, mutate in mutations.items():
                with self.subTest(field=label):
                    changed = copy.deepcopy(original)
                    changed["request_id"] = f"request-sf200-drift-{label}"
                    mutate(changed)
                    with self.assertRaises(ProtocolError):
                        validate_idempotent_replay(original, changed)

            payload_mode_drift = copy.deepcopy(original)
            payload_mode_drift["request_id"] = "request-sf200-drift-mode"
            payload_mode_drift["payload_mode"] = "digest-only"
            payload_mode_drift["payload"] = {}
            payload_mode_drift["payload_sha256"] = canonical_sha256({})
            with self.assertRaises(ProtocolError):
                validate_idempotent_replay(original, payload_mode_drift)

    def test_timeout_and_unsupported_capability_precede_effect(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf200-timeout-capability") as workspace:
            adapter = FakeWorkerAdapter(workspace / "timeout.db")
            self._prepare_start(adapter, scenario)
            request = scenario.request(
                "send",
                {"command": scenario.command("worker.prompt", index=3)},
                index=3,
            )
            adapter.arm_timeout_once("send")
            timeout = adapter.execute(request)
            self.assertEqual(timeout["disposition"], "timeout")
            self.assertEqual(timeout["mutation_state"], "not-applied")
            self.assertEqual(adapter.effect_count(request), 0)
            succeeded = adapter.execute(request)
            self.assertEqual(succeeded["disposition"], "succeeded")
            self.assertEqual(adapter.effect_count(request), 1)

            limited = FakeWorkerAdapter(
                workspace / "limited.db",
                manifest=WorkerCapabilityManifest(
                    adapter_id="limited-worker",
                    implementation_version="1.0.0",
                    supported_command_types=("worker.prompt",),
                ),
            )
            self._prepare_start(limited, scenario)
            unsupported = scenario.request(
                "send",
                {"command": scenario.command("worker.steer", index=4)},
                index=4,
            )
            rejected = limited.execute(unsupported)
            self.assertEqual(rejected["disposition"], "rejected")
            self.assertEqual(
                rejected["error"]["details"]["reason"],
                "unsupported-capability",
            )
            self.assertEqual(limited.effect_count(unsupported), 0)

    def test_observe_cursor_checkpoint_cancel_and_evidence(self) -> None:
        scenario = WorkerConformanceScenario(session_generation=2)
        with test_workspace("sf200-observe-evidence") as workspace:
            adapter = FakeWorkerAdapter(workspace / "worker.db")
            self._prepare_start(adapter, scenario)
            command = scenario.command("worker.prompt", index=3)
            send = scenario.request(
                "send",
                {"command": command},
                index=3,
            )
            adapter.execute(send)
            source, projection = scenario.event_pair(
                command,
                sequence=1,
                adapter_id=adapter.capabilities().adapter_id,
            )
            adapter.record_factory_projection(source, projection)
            adapter.record_factory_projection(source, projection)
            changed_source = copy.deepcopy(source)
            changed_source["actor"]["identity_id"] = "changed-factory-host"
            with self.assertRaisesRegex(
                ProtocolError,
                "event identity already exists with drift",
            ):
                adapter.record_factory_projection(
                    changed_source,
                    projection,
                )
            gap_command = scenario.command("worker.follow-up", index=4)
            gap_source, gap_projection = scenario.event_pair(
                gap_command,
                sequence=3,
                adapter_id=adapter.capabilities().adapter_id,
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "cursor order",
            ):
                adapter.record_factory_projection(
                    gap_source,
                    gap_projection,
                )
            foreign_source = copy.deepcopy(gap_source)
            foreign_projection = copy.deepcopy(gap_projection)
            foreign_source["cursor"]["stream_id"] = "worker-session:foreign:events"
            foreign_projection["cursor"]["stream_id"] = (
                "worker-session:foreign:events"
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "cursor stream",
            ):
                adapter.record_factory_projection(
                    foreign_source,
                    foreign_projection,
                )
            reused_source, reused_projection = scenario.event_pair(
                gap_command,
                sequence=2,
                adapter_id=adapter.capabilities().adapter_id,
            )
            reused_source["event_id"] = source["event_id"]
            reused_source["cursor"]["event_id"] = source["event_id"]
            reused_projection["source_event_id"] = source["event_id"]
            reused_projection["cursor"]["event_id"] = source["event_id"]
            with self.assertRaisesRegex(
                ProtocolError,
                "event identity already exists with drift",
            ):
                adapter.record_factory_projection(
                    reused_source,
                    reused_projection,
                )

            observe = scenario.request(
                "observe",
                {"cursor": scenario.cursor()},
                index=4,
                idempotency_key=None,
            )
            observed = adapter.execute(observe)
            self.assertEqual(len(observed["result"]["events"]), 1)
            self.assertFalse(
                observed["result"]["events"][0]["authoritative"]
            )
            self.assertEqual(
                observed["result"]["events"][0]["source_event_id"],
                source["event_id"],
            )

            stale_request = scenario.request(
                "observe",
                {"cursor": scenario.cursor(generation=1)},
                index=5,
                idempotency_key=None,
            )
            stale = adapter.execute(stale_request)
            self.assertEqual(stale["disposition"], "stale-cursor")
            self.assertEqual(stale["retry"], "refresh-cursor")
            self.assertEqual(stale["cursor"]["generation"], 2)

            future_cursor = scenario.cursor(
                sequence=2,
                event_id="canonical-event-sf200-2",
            )
            future_request = scenario.request(
                "observe",
                {"cursor": future_cursor},
                index=6,
                idempotency_key=None,
            )
            future = adapter.execute(future_request)
            self.assertEqual(future["disposition"], "rejected")
            self.assertEqual(future["error"]["code"], "invalid-request")
            self.assertEqual(future["mutation_state"], "not-applicable")

            session = {
                "worker_session_id": scenario.worker_session_id,
                "session_generation": scenario.session_generation,
            }
            checkpoint_request = scenario.request(
                "checkpoint",
                {"session": session},
                index=7,
            )
            checkpoint = adapter.execute(checkpoint_request)
            observed_checkpoint = checkpoint["result"]["checkpoint"]
            self.assertEqual(
                observed_checkpoint["worker_session_id"],
                scenario.worker_session_id,
            )
            self.assertEqual(
                observed_checkpoint["session_generation"],
                2,
            )
            self.assertEqual(
                observed_checkpoint["checkpoint_id"],
                scenario.checkpoint_id,
            )
            self.assertEqual(
                observed_checkpoint["content_sha256"],
                scenario.checkpoint_sha256,
            )
            self.assertNotEqual(
                observed_checkpoint["adapter_state_sha256"],
                observed_checkpoint["content_sha256"],
            )

            cancel_request = scenario.request(
                "cancel",
                {"session": session, "reason": "component completion"},
                index=8,
            )
            cancelled = adapter.execute(cancel_request)
            self.assertEqual(
                cancelled["result"]["cancellation_result"]["status"],
                "cancelled",
            )
            duplicate_cancel = copy.deepcopy(cancel_request)
            duplicate_cancel["request_id"] = "request-sf200-cancel-duplicate"
            self.assertEqual(
                adapter.execute(duplicate_cancel)["disposition"],
                "duplicate",
            )
            self.assertEqual(adapter.effect_count(cancel_request), 1)

            evidence_request = scenario.request(
                "collect-evidence",
                {"session": session},
                index=9,
                idempotency_key=None,
            )
            evidence = adapter.execute(evidence_request)["result"][
                "evidence_bundle"
            ]
            unsigned = {
                key: value
                for key, value in evidence.items()
                if key != "content_sha256"
            }
            self.assertEqual(
                evidence["content_sha256"],
                canonical_sha256(unsigned),
            )
            self.assertEqual(len(evidence["event_sha256s"]), 1)
            self.assertEqual(
                len(evidence["provider_observation_sha256s"]),
                1,
            )
            self.assertEqual(len(evidence["checkpoint_sha256s"]), 1)
            replayed_evidence = FakeWorkerAdapter(
                workspace / "worker.db"
            ).execute(evidence_request)["result"]["evidence_bundle"]
            self.assertEqual(replayed_evidence, evidence)

    def test_uncertain_effect_requires_recovery_without_second_effect(
        self,
    ) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf200-uncertain-recovery") as workspace:
            path = workspace / "worker.db"
            adapter = FakeWorkerAdapter(path)
            self._prepare_start(adapter, scenario)
            request = scenario.request(
                "send",
                {"command": scenario.command("worker.prompt", index=3)},
                index=3,
            )
            adapter.arm_crash("send", "after-effect-before-result")
            with self.assertRaises(FakeWorkerCrash):
                adapter.execute(request)

            reopened = FakeWorkerAdapter(path)
            duplicate = copy.deepcopy(request)
            duplicate["request_id"] = "request-sf200-send-uncertain"
            uncertain = reopened.execute(duplicate)
            self.assertEqual(uncertain["disposition"], "uncertain")
            self.assertEqual(uncertain["retry"], "reconcile")
            self.assertEqual(reopened.effect_count(request), 1)

            recover = scenario.request(
                "recover",
                {
                    "session": {
                        "worker_session_id": scenario.worker_session_id,
                        "session_generation": scenario.session_generation,
                    },
                    "cursor": scenario.cursor(),
                },
                index=4,
            )
            changed_cursor = copy.deepcopy(recover)
            changed_cursor["request_id"] = (
                "request-sf200-recover-generation-drift"
            )
            changed_cursor["payload"]["cursor"] = scenario.cursor(
                generation=2
            )
            changed_cursor["payload_sha256"] = canonical_sha256(
                changed_cursor["payload"]
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "exact factory session generation",
            ):
                reopened.execute(changed_cursor)
            recovered = reopened.execute(recover)
            reconciled = recovered["result"]["recovery_result"][
                "reconciled_effects"
            ]
            self.assertEqual(len(reconciled), 1)
            self.assertEqual(
                reconciled[0]["idempotency_key"],
                request["idempotency_key"],
            )
            final = reopened.execute(duplicate)
            self.assertEqual(final["disposition"], "duplicate")
            self.assertEqual(reopened.effect_count(request), 1)

    def test_recovery_covers_not_applied_and_exact_checkpoint_effects(
        self,
    ) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf200-complete-recovery") as workspace:
            path = workspace / "worker.db"
            adapter = FakeWorkerAdapter(path)
            self._prepare_start(adapter, scenario)
            send = scenario.request(
                "send",
                {"command": scenario.command("worker.prompt", index=3)},
                index=3,
            )
            adapter.arm_crash("send", "after-acceptance-before-effect")
            with self.assertRaises(FakeWorkerCrash):
                adapter.execute(send)

            reopened = FakeWorkerAdapter(path)
            recover = scenario.request(
                "recover",
                {
                    "session": {
                        "worker_session_id": scenario.worker_session_id,
                        "session_generation": scenario.session_generation,
                    },
                    "cursor": scenario.cursor(),
                },
                index=4,
            )
            reconciled = reopened.execute(recover)["result"][
                "recovery_result"
            ]["reconciled_effects"]
            self.assertEqual(len(reconciled), 1)
            self.assertEqual(reconciled[0]["outcome"], "not-applied")
            self.assertIsNone(reconciled[0]["response_sha256"])
            self.assertEqual(reopened.effect_count(send), 0)
            self.assertEqual(
                reopened.execute(send)["disposition"],
                "succeeded",
            )
            self.assertEqual(reopened.effect_count(send), 1)

            session = {
                "worker_session_id": scenario.worker_session_id,
                "session_generation": scenario.session_generation,
            }
            first_checkpoint = scenario.request(
                "checkpoint",
                {"session": session},
                index=5,
            )
            reopened.arm_crash(
                "checkpoint",
                "after-effect-before-result",
            )
            with self.assertRaises(FakeWorkerCrash):
                reopened.execute(first_checkpoint)

            second_checkpoint = scenario.request(
                "checkpoint",
                {"session": session},
                index=6,
            )
            second_checkpoint["extensions"][
                "elder.factory/checkpoint-id"
            ] = "elder-checkpoint-sf200-2"
            second_checkpoint["extensions"][
                "elder.factory/checkpoint-sha256"
            ] = "c" * 64
            second = reopened.execute(second_checkpoint)["result"][
                "checkpoint"
            ]
            self.assertEqual(
                second["checkpoint_id"],
                "elder-checkpoint-sf200-2",
            )

            checkpoint_recovery = scenario.request(
                "recover",
                {
                    "session": session,
                    "cursor": scenario.cursor(),
                },
                index=7,
            )
            self.assertEqual(
                len(
                    reopened.execute(checkpoint_recovery)["result"][
                        "recovery_result"
                    ]["reconciled_effects"]
                ),
                1,
            )
            duplicate = copy.deepcopy(first_checkpoint)
            duplicate["request_id"] = "request-sf200-checkpoint-recovered"
            recovered_checkpoint = reopened.execute(duplicate)["result"][
                "checkpoint"
            ]
            self.assertEqual(
                recovered_checkpoint["checkpoint_id"],
                scenario.checkpoint_id,
            )
            self.assertEqual(
                recovered_checkpoint["content_sha256"],
                scenario.checkpoint_sha256,
            )

    def test_generations_evidence_scope_and_terminal_cancel(self) -> None:
        first = WorkerConformanceScenario()
        second_session = WorkerConformanceScenario(
            work_item_id="work-item-sf200-b",
            run_id="run-sf200-b",
            worker_session_id="worker-session-sf200-b",
            workspace_id="workspace-sf200-b",
            correlation_id="correlation-sf200-b",
            causation_id="cause-sf200-b",
        )
        with test_workspace("sf200-generation-scope") as workspace:
            adapter = FakeWorkerAdapter(workspace / "worker.db")
            self._prepare_start(adapter, first)
            self._prepare_start(
                adapter,
                second_session,
                index_offset=20,
            )

            session = {
                "worker_session_id": first.worker_session_id,
                "session_generation": first.session_generation,
            }
            cancel = first.request(
                "cancel",
                {"session": session, "reason": "generation complete"},
                index=3,
            )
            self.assertEqual(
                adapter.execute(cancel)["result"]["cancellation_result"][
                    "status"
                ],
                "cancelled",
            )
            second_cancel = first.request(
                "cancel",
                {"session": session, "reason": "already cancelled"},
                index=4,
            )
            terminal = adapter.execute(second_cancel)
            self.assertEqual(terminal["disposition"], "rejected")
            self.assertEqual(
                terminal["error"]["details"]["reason"],
                "terminal-session",
            )
            self.assertEqual(adapter.effect_count(second_cancel), 0)

            evidence_request = first.request(
                "collect-evidence",
                {"session": session},
                index=5,
                idempotency_key=None,
            )
            evidence = adapter.execute(evidence_request)["result"][
                "evidence_bundle"
            ]
            self.assertEqual(len(evidence["request_receipts"]), 3)

            next_generation = WorkerConformanceScenario(
                session_generation=2,
            )
            prepared, started = self._prepare_start(
                adapter,
                next_generation,
                index_offset=40,
            )
            self.assertEqual(
                prepared["result"]["prepared_run"]["session_generation"],
                2,
            )
            self.assertEqual(
                started["result"]["worker_session"]["session_generation"],
                2,
            )
            observed = adapter.execute(
                next_generation.request(
                    "observe",
                    {"cursor": next_generation.cursor()},
                    index=43,
                    idempotency_key=None,
                )
            )
            self.assertEqual(
                observed["result"]["next_cursor"]["generation"],
                2,
            )
            self.assertEqual(
                observed["result"]["next_cursor"]["sequence"],
                0,
            )

    def test_recover_result_and_cancel_race_survive_crash(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf200-recover-cancel-race") as workspace:
            path = workspace / "worker.db"
            adapter = FakeWorkerAdapter(path)
            self._prepare_start(adapter, scenario)
            send = scenario.request(
                "send",
                {"command": scenario.command("worker.prompt", index=3)},
                index=3,
            )
            adapter.arm_crash("send", "after-effect-before-result")
            with self.assertRaises(FakeWorkerCrash):
                adapter.execute(send)

            session = {
                "worker_session_id": scenario.worker_session_id,
                "session_generation": scenario.session_generation,
            }
            first_recover = scenario.request(
                "recover",
                {"session": session, "cursor": scenario.cursor()},
                index=4,
            )
            restarted = FakeWorkerAdapter(path)
            restarted.arm_crash(
                "recover",
                "after-effect-before-result",
            )
            with self.assertRaises(FakeWorkerCrash):
                restarted.execute(first_recover)
            uncertain_recover = copy.deepcopy(first_recover)
            uncertain_recover["request_id"] = (
                "request-sf200-recover-uncertain"
            )
            self.assertEqual(
                restarted.execute(uncertain_recover)["disposition"],
                "uncertain",
            )

            second_recover = scenario.request(
                "recover",
                {"session": session, "cursor": scenario.cursor()},
                index=5,
            )
            second_result = restarted.execute(second_recover)["result"][
                "recovery_result"
            ]
            self.assertEqual(len(second_result["reconciled_effects"]), 1)
            self.assertEqual(
                second_result["reconciled_effects"][0]["operation"],
                "recover",
            )
            recovered_first = restarted.execute(uncertain_recover)["result"][
                "recovery_result"
            ]
            self.assertEqual(len(recovered_first["reconciled_effects"]), 1)
            self.assertEqual(
                recovered_first["reconciled_effects"][0]["operation"],
                "send",
            )

            cancel_a = scenario.request(
                "cancel",
                {"session": session, "reason": "cancel A"},
                index=6,
            )
            restarted.arm_crash(
                "cancel",
                "after-acceptance-before-effect",
            )
            with self.assertRaises(FakeWorkerCrash):
                restarted.execute(cancel_a)
            cancel_b = scenario.request(
                "cancel",
                {"session": session, "reason": "cancel B"},
                index=7,
            )
            self.assertEqual(
                restarted.execute(cancel_b)["disposition"],
                "succeeded",
            )
            self.assertEqual(
                restarted.execute(cancel_a)["disposition"],
                "rejected",
            )
            self.assertEqual(restarted.effect_count(cancel_a), 0)
            self.assertEqual(restarted.effect_count(cancel_b), 1)


if __name__ == "__main__":
    unittest.main()
