from __future__ import annotations

import copy
import unittest
from datetime import UTC, datetime, timedelta

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from elder_protocol.autonomy import (
    calculate_effective_autonomy,
    canonical_sha256,
    consume_qualification,
    trust_anchor_set_sha256,
    validate_autonomy_policy,
    validate_renewal,
    validate_revocation,
    validate_suspension,
)
from elder_protocol.constants import PROTOCOL_DIR, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from tests._support import test_workspace
from tests.component.test_p4_7_qualification import (
    qualification_policy,
    signed_record,
    simple_maturity,
    write_bundle,
)


def finalize(record: dict) -> dict:
    record["content_sha256"] = canonical_sha256(record)
    return record


def fixture_autonomy_policy(
    hosted_policy: dict,
    maturity: dict,
) -> dict:
    policy = copy.deepcopy(load_json(PROTOCOL_DIR / "autonomy-policy.json"))
    consumption = policy["qualification_consumption"]
    consumption["approved_policy_sha256"] = canonical_sha256(hosted_policy)
    consumption["approved_maturity_model_sha256"] = canonical_sha256(maturity)
    consumption["approved_trust_anchor_set_sha256"] = trust_anchor_set_sha256(
        hosted_policy
    )
    return policy


def certification(
    consumption: dict,
    *,
    issued_at: datetime,
    valid_days: int = 10,
) -> dict:
    return finalize(
        {
            "version": "0.5.1",
            "certification_id": "CERT-001",
            "project_id": "fixture-project",
            "environment": "production",
            "autonomy_class_id": "documentation-only-correction",
            "certification_level": "L2",
            "status": "active",
            "scope_paths": ["docs/user-guide.md"],
            "tool_bindings": [
                {
                    "id": "text-editor",
                    "digest_sha256": None,
                    "rule_ids": [],
                }
            ],
            "issued_by": "fixture-architecture-owner",
            "issuer_role": "architecture-owner",
            "evaluator_id": "fixture-independent-evaluator",
            "issued_at": issued_at.isoformat(),
            "valid_from": issued_at.isoformat(),
            "valid_until": (issued_at + timedelta(days=valid_days)).isoformat(),
            "qualification_consumption_sha256": consumption["content_sha256"],
            "incident_budget_id": "BUDGET-001",
            "evidence": ["evaluation:EVAL-001"],
        }
    )


def incident_budget(
    *,
    started_at: datetime,
    incident_count: int = 0,
) -> dict:
    return finalize(
        {
            "version": "0.5.1",
            "budget_id": "BUDGET-001",
            "certification_id": "CERT-001",
            "autonomy_class_id": "documentation-only-correction",
            "window_started_at": started_at.isoformat(),
            "window_ends_at": (started_at + timedelta(days=30)).isoformat(),
            "maximum_incidents": 0,
            "incident_count": incident_count,
            "maximum_rollbacks": 0,
            "rollback_count": 0,
            "exhausted": incident_count > 0,
            "evidence": [],
        }
    )


def suspension(*, effective_at: datetime) -> dict:
    return finalize(
        {
            "version": "0.5.1",
            "suspension_id": "SUSP-001",
            "certification_id": "CERT-001",
            "autonomy_class_id": "documentation-only-correction",
            "reason": "Incident threshold reached.",
            "trigger": "incident-budget-threshold",
            "effective_at": effective_at.isoformat(),
            "released_at": None,
            "recorded_by": "fixture-security-owner",
            "recorded_by_role": "security-owner",
            "evidence": ["incident:INC-001"],
        }
    )


def revocation(*, effective_at: datetime) -> dict:
    return finalize(
        {
            "version": "0.5.1",
            "revocation_id": "REVOKE-001",
            "certification_id": "CERT-001",
            "autonomy_class_id": "documentation-only-correction",
            "reason": "Certification evidence was invalidated.",
            "effective_at": effective_at.isoformat(),
            "recorded_by": "fixture-security-owner",
            "recorded_by_role": "security-owner",
            "evidence": ["qualification:CONTRADICTION-001"],
        }
    )


class P50AutonomyComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = load_json(PROTOCOL_DIR / "autonomy-classes.json")
        self.change_classes = load_json(PROTOCOL_DIR / "change-classes.json")

    def qualified_consumption(
        self,
        workspace,
        *,
        evaluated_at: datetime,
    ) -> tuple[dict, dict]:
        context = self.qualification_context(
            workspace,
            evaluated_at=evaluated_at,
        )
        return context["autonomy_policy"], context["consumption"]

    def qualification_context(
        self,
        workspace,
        *,
        evaluated_at: datetime,
    ) -> dict:
        private_key = Ed25519PrivateKey.generate()
        maturity = simple_maturity()
        hosted_policy = qualification_policy(private_key)
        required_gates = [
            "l0-capability",
            "l0-evidence",
            "l1-capability",
            "l1-evidence",
            "l2-capability",
            "l2-evidence",
        ]
        records = [
            signed_record(
                workspace,
                private_key,
                gate_id=gate_id,
                index=index,
                issued_at=evaluated_at - timedelta(hours=1),
            )
            for index, gate_id in enumerate(required_gates, start=1)
        ]
        manifest = write_bundle(
            workspace,
            records,
            private_key,
            issued_at=evaluated_at - timedelta(hours=1),
        )
        autonomy_policy = fixture_autonomy_policy(hosted_policy, maturity)
        checks = {
            name: {"checked_at": evaluated_at.isoformat(), "present": False}
            for name in ["contradiction", "suspension", "revocation"]
        }
        consumption = consume_qualification(
            manifest,
            hosted_policy,
            maturity,
            autonomy_policy,
            project_id="fixture-project",
            environment="production",
            artifact_sha256="a" * 64,
            requested_level="L2",
            state_checks=checks,
            at=evaluated_at.isoformat(),
        )
        return {
            "autonomy_policy": autonomy_policy,
            "consumption": consumption,
            "manifest": manifest,
            "qualification_policy": hosted_policy,
            "maturity_model": maturity,
            "state_checks": checks,
            "artifact_sha256": "a" * 64,
            "private_key": private_key,
        }

    def test_canonical_policy_and_five_initial_classes_validate(self) -> None:
        policy = load_json(PROTOCOL_DIR / "autonomy-policy.json")
        validate_autonomy_policy(
            policy,
            self.registry,
            self.change_classes,
            qualification_policy=load_json(
                PROTOCOL_DIR / "qualification-policy.json"
            ),
            maturity_model=load_json(
                PROTOCOL_DIR / "operational-maturity.json"
            ),
        )
        self.assertEqual(policy["mode"], "qualification-gated-supervised-pr")
        self.assertEqual(len(self.registry["classes"]), 5)
        self.assertTrue(all(
            item["maximum_autonomy"] == "L2"
            for item in self.registry["classes"]
        ))
        self.assertTrue(policy["authority"]["can_create_pr"])
        self.assertFalse(policy["authority"]["can_deploy"])

    def test_p4_7_is_reverified_and_bound_to_earliest_expiry(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-0-consumption") as workspace:
            policy, consumption = self.qualified_consumption(
                workspace,
                evaluated_at=evaluated_at,
            )

        self.assertTrue(consumption["qualified"])
        self.assertTrue(consumption["reverified"])
        self.assertEqual(consumption["requested_level"], "L2")
        self.assertEqual(consumption["achieved_level"], "L2")
        self.assertEqual(
            consumption["policy_sha256"],
            policy["qualification_consumption"]["approved_policy_sha256"],
        )
        self.assertGreater(
            datetime.fromisoformat(consumption["valid_until"]),
            evaluated_at,
        )

    def test_effective_autonomy_uses_minimum_and_only_marks_eligibility(
        self,
    ) -> None:
        scenario = load_json(
            ROOT / "tests" / "fixtures" / "p5_0" / "valid-effective-autonomy.json"
        )
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-0-effective") as workspace:
            policy, consumption = self.qualified_consumption(
                workspace,
                evaluated_at=evaluated_at,
            )
            report = calculate_effective_autonomy(
                policy,
                self.registry,
                self.change_classes,
                project_id=scenario["project_id"],
                project_autonomy_ceiling=scenario[
                    "project_autonomy_ceiling"
                ],
                autonomy_class_id=scenario["autonomy_class_id"],
                certification=certification(
                    consumption,
                    issued_at=evaluated_at - timedelta(minutes=5),
                ),
                qualification_consumption=consumption,
                incident_budget=incident_budget(
                    started_at=evaluated_at - timedelta(minutes=5)
                ),
                suspensions=[],
                revocations=[],
                at=evaluated_at.isoformat(),
            )

        self.assertEqual(
            report["effective_level"], scenario["expected_effective_level"]
        )
        self.assertEqual(report["blockers"], [])
        self.assertFalse(report["authority_activated"])
        self.assertTrue(report["authority_eligible"])
        self.assertFalse(report["contracts_only"])
        self.assertTrue(report["can_issue_runtime_lease"])
        self.assertTrue(report["can_create_pr"])
        self.assertFalse(report["can_merge"])
        self.assertFalse(report["can_deploy"])
        self.assertFalse(report["can_mutate_maturity"])
        self.assertFalse(report["can_auto_renew"])

    def test_suspension_and_incident_exhaustion_resolve_to_none(self) -> None:
        scenario = load_json(
            ROOT
            / "tests"
            / "fixtures"
            / "p5_0"
            / "suspended-effective-autonomy.json"
        )
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-0-hard-stops") as workspace:
            policy, consumption = self.qualified_consumption(
                workspace,
                evaluated_at=evaluated_at,
            )
            for blocker, suspensions, budget in [
                (
                    "suspended",
                    [suspension(effective_at=evaluated_at - timedelta(minutes=1))],
                    incident_budget(
                        started_at=evaluated_at - timedelta(minutes=5)
                    ),
                ),
                (
                    "incident-budget-exhausted",
                    [],
                    incident_budget(
                        started_at=evaluated_at - timedelta(minutes=5),
                        incident_count=1,
                    ),
                ),
            ]:
                with self.subTest(blocker=blocker):
                    report = calculate_effective_autonomy(
                        policy,
                        self.registry,
                        self.change_classes,
                        project_id=scenario["project_id"],
                        project_autonomy_ceiling=scenario[
                            "project_autonomy_ceiling"
                        ],
                        autonomy_class_id=scenario["autonomy_class_id"],
                        certification=certification(
                            consumption,
                            issued_at=evaluated_at - timedelta(minutes=5),
                        ),
                        qualification_consumption=consumption,
                        incident_budget=budget,
                        suspensions=suspensions,
                        revocations=[],
                        at=evaluated_at.isoformat(),
                    )
                    self.assertIsNone(report["effective_level"])
                    self.assertIn(blocker, report["blockers"])
                    self.assertFalse(report["authority_activated"])

    def test_expired_incident_budget_and_disallowed_lifecycle_roles_fail_closed(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-0-expired-budget") as workspace:
            policy, consumption = self.qualified_consumption(
                workspace,
                evaluated_at=evaluated_at,
            )
            expired_budget = incident_budget(
                started_at=evaluated_at - timedelta(days=31)
            )
            report = calculate_effective_autonomy(
                policy,
                self.registry,
                self.change_classes,
                project_id="fixture-project",
                project_autonomy_ceiling="L2",
                autonomy_class_id="documentation-only-correction",
                certification=certification(
                    consumption,
                    issued_at=evaluated_at - timedelta(minutes=5),
                ),
                qualification_consumption=consumption,
                incident_budget=expired_budget,
                suspensions=[],
                revocations=[],
                at=evaluated_at.isoformat(),
            )
        self.assertIsNone(report["effective_level"])
        self.assertIn("incident-budget-window-inactive", report["blockers"])

        invalid_suspension = suspension(effective_at=evaluated_at)
        invalid_suspension["recorded_by_role"] = "architecture-owner"
        invalid_suspension["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in invalid_suspension.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "not permitted"):
            validate_suspension(invalid_suspension, policy=policy)

        invalid_revocation = revocation(effective_at=evaluated_at)
        invalid_revocation["recorded_by_role"] = "architecture-owner"
        invalid_revocation["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in invalid_revocation.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "not permitted"):
            validate_revocation(invalid_revocation, policy=policy)

    def test_expiry_and_revocation_resolve_to_none(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-0-expiry-revocation") as workspace:
            policy, consumption = self.qualified_consumption(
                workspace,
                evaluated_at=evaluated_at,
            )
            base_certification = certification(
                consumption,
                issued_at=evaluated_at - timedelta(minutes=5),
            )
            base_budget = incident_budget(
                started_at=evaluated_at - timedelta(minutes=5)
            )

            expired_certification = copy.deepcopy(base_certification)
            expired_certification["valid_until"] = (
                evaluated_at - timedelta(minutes=1)
            ).isoformat()
            expired_certification["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in expired_certification.items()
                    if key != "content_sha256"
                }
            )
            expired_report = calculate_effective_autonomy(
                policy,
                self.registry,
                self.change_classes,
                project_id="fixture-project",
                project_autonomy_ceiling="L3",
                autonomy_class_id="documentation-only-correction",
                certification=expired_certification,
                qualification_consumption=consumption,
                incident_budget=base_budget,
                suspensions=[],
                revocations=[],
                at=evaluated_at.isoformat(),
            )
            self.assertIsNone(expired_report["effective_level"])
            self.assertIn("expired", expired_report["blockers"])

            expired_consumption = copy.deepcopy(consumption)
            expired_consumption["valid_until"] = (
                evaluated_at + timedelta(minutes=1)
            ).isoformat()
            expired_consumption["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in expired_consumption.items()
                    if key != "content_sha256"
                }
            )
            bound_certification = certification(
                expired_consumption,
                issued_at=evaluated_at - timedelta(minutes=5),
            )
            qualification_report = calculate_effective_autonomy(
                policy,
                self.registry,
                self.change_classes,
                project_id="fixture-project",
                project_autonomy_ceiling="L3",
                autonomy_class_id="documentation-only-correction",
                certification=bound_certification,
                qualification_consumption=expired_consumption,
                incident_budget=base_budget,
                suspensions=[],
                revocations=[],
                at=(evaluated_at + timedelta(minutes=2)).isoformat(),
            )
            self.assertIsNone(qualification_report["effective_level"])
            self.assertIn("invalid-qualification", qualification_report["blockers"])

            revoked_report = calculate_effective_autonomy(
                policy,
                self.registry,
                self.change_classes,
                project_id="fixture-project",
                project_autonomy_ceiling="L3",
                autonomy_class_id="documentation-only-correction",
                certification=base_certification,
                qualification_consumption=consumption,
                incident_budget=base_budget,
                suspensions=[],
                revocations=[
                    revocation(
                        effective_at=evaluated_at - timedelta(minutes=1)
                    )
                ],
                at=evaluated_at.isoformat(),
            )
            self.assertIsNone(revoked_report["effective_level"])
            self.assertIn("revoked", revoked_report["blockers"])

    def test_unapproved_policy_and_overbroad_class_fail_closed(self) -> None:
        policy = load_json(PROTOCOL_DIR / "autonomy-policy.json")
        policy["qualification_consumption"]["approved_policy_sha256"] = "f" * 64
        with self.assertRaisesRegex(ProtocolError, "canonical qualification"):
            validate_autonomy_policy(
                policy,
                self.registry,
                self.change_classes,
                qualification_policy=load_json(
                    PROTOCOL_DIR / "qualification-policy.json"
                ),
                maturity_model=load_json(
                    PROTOCOL_DIR / "operational-maturity.json"
                ),
            )

        registry = copy.deepcopy(self.registry)
        registry["classes"][0]["maximum_autonomy"] = "L3"
        with self.assertRaisesRegex(ProtocolError, "cannot exceed L2"):
            validate_autonomy_policy(
                load_json(PROTOCOL_DIR / "autonomy-policy.json"),
                registry,
                self.change_classes,
            )

        registry = copy.deepcopy(self.registry)
        registry["classes"][0]["scope"]["forbidden_path_globs"].remove(
            "**/ARCHITECTURE.md"
        )
        with self.assertRaisesRegex(ProtocolError, "architecture"):
            validate_autonomy_policy(
                load_json(PROTOCOL_DIR / "autonomy-policy.json"),
                registry,
                self.change_classes,
            )

    def test_certification_ttl_and_incident_budget_cannot_expand_class(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-0-class-bounds") as workspace:
            policy, consumption = self.qualified_consumption(
                workspace,
                evaluated_at=evaluated_at,
            )
            overlong_certification = certification(
                consumption,
                issued_at=evaluated_at,
                valid_days=31,
            )
            with self.assertRaisesRegex(ProtocolError, "class TTL"):
                calculate_effective_autonomy(
                    policy,
                    self.registry,
                    self.change_classes,
                    project_id="fixture-project",
                    project_autonomy_ceiling="L3",
                    autonomy_class_id="documentation-only-correction",
                    certification=overlong_certification,
                    qualification_consumption=consumption,
                    incident_budget=incident_budget(started_at=evaluated_at),
                    suspensions=[],
                    revocations=[],
                    at=evaluated_at.isoformat(),
                )

            expanded_budget = incident_budget(started_at=evaluated_at)
            expanded_budget["maximum_incidents"] = 1
            expanded_budget["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in expanded_budget.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "exactly match"):
                calculate_effective_autonomy(
                    policy,
                    self.registry,
                    self.change_classes,
                    project_id="fixture-project",
                    project_autonomy_ceiling="L3",
                    autonomy_class_id="documentation-only-correction",
                    certification=certification(
                        consumption,
                        issued_at=evaluated_at,
                    ),
                    qualification_consumption=consumption,
                    incident_budget=expanded_budget,
                    suspensions=[],
                    revocations=[],
                    at=evaluated_at.isoformat(),
                )

    def test_renewal_requires_human_governance_and_extends_expiry(self) -> None:
        previous = datetime(2026, 8, 20, 9, 0, tzinfo=UTC)
        record = finalize(
            {
                "version": "0.5.1",
                "renewal_id": "RENEW-001",
                "certification_id": "CERT-001",
                "autonomy_class_id": "documentation-only-correction",
                "decision": "renew",
                "previous_valid_until": previous.isoformat(),
                "new_valid_until": (previous + timedelta(days=29)).isoformat(),
                "decided_at": (previous - timedelta(days=1)).isoformat(),
                "decided_by": "fixture-human-owner",
                "decided_by_role": "human-owner",
                "independent_evaluation_sha256": "a" * 64,
                "incident_budget_sha256": "b" * 64,
                "evidence": ["review:REVIEW-001"],
            }
        )
        policy = load_json(PROTOCOL_DIR / "autonomy-policy.json")
        autonomy_class = self.registry["classes"][0]
        validate_renewal(
            record,
            policy=policy,
            autonomy_class=autonomy_class,
        )
        invalid = copy.deepcopy(record)
        invalid["decided_by_role"] = "executor"
        invalid["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in invalid.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "not permitted"):
            validate_renewal(
                invalid,
                policy=policy,
                autonomy_class=autonomy_class,
            )
        excessive = copy.deepcopy(record)
        excessive["new_valid_until"] = (
            previous + timedelta(days=365)
        ).isoformat()
        excessive["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in excessive.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "class TTL"):
            validate_renewal(
                excessive,
                policy=policy,
                autonomy_class=autonomy_class,
            )


if __name__ == "__main__":
    unittest.main()
