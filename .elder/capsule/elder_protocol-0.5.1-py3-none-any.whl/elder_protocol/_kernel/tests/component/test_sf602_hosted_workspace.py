from __future__ import annotations

import copy
import json
import unittest
from dataclasses import replace
from datetime import timedelta

from elder_protocol.errors import MutationConflictError, ProtocolError
from elder_protocol.factory_operations.hosted_identity import (
    BrokeredCredential,
    ExternalSecretBroker,
    WorkloadIdentityVerifier,
)
from elder_protocol.factory_operations.hosted_workspace import (
    HostedWorkspaceAuditLedger,
    HostedWorkspaceManager,
    validate_hosted_workspace_request,
    workspace_content_sha256,
)
from tests._sf601_support import (
    identity_policy,
    rsa_fixture,
    signed_token,
)
from tests._sf602_support import (
    NOW,
    FakeHostedWorkspaceProvider,
    issue_workspace_credential,
    workspace_policy,
    workspace_request,
)
from tests._support import test_workspace


def _redigest(document: dict) -> dict:
    document["content_sha256"] = workspace_content_sha256(
        {
            key: value
            for key, value in document.items()
            if key != "content_sha256"
        }
    )
    return document


class HostedWorkspaceComponentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.private_key, cls.jwks = rsa_fixture()

    def token(
        self,
        *,
        project_id: str = "project-one",
        workload_id: str = "worker-one",
    ) -> str:
        return signed_token(
            self.private_key,
            project_id=project_id,
            workload_id=workload_id,
            issued_at=NOW - timedelta(seconds=5),
            not_before=NOW - timedelta(seconds=5),
            expires_at=NOW + timedelta(minutes=5),
            jti=f"token-{project_id}-{workload_id}",
        )

    def verifier(self) -> WorkloadIdentityVerifier:
        return WorkloadIdentityVerifier(
            identity_policy(self.jwks),
            jwks_loader=lambda _issuer: copy.deepcopy(self.jwks),
            now=lambda: NOW,
        )

    def manager(
        self,
        root,
        provider: FakeHostedWorkspaceProvider | None = None,
    ) -> tuple[
        HostedWorkspaceManager,
        HostedWorkspaceAuditLedger,
        FakeHostedWorkspaceProvider,
        ExternalSecretBroker,
        BrokeredCredential,
    ]:
        provider = provider or FakeHostedWorkspaceProvider()
        audit = HostedWorkspaceAuditLedger(root / "workspace.db")
        verifier = self.verifier()
        broker, issued = issue_workspace_credential(
            root,
            verifier,
            self.token(),
        )
        return (
            HostedWorkspaceManager(
                policy=workspace_policy(),
                identity_verifier=verifier,
                providers={"workspace-provider-one": provider},
                credential_brokers={"broker-one": broker},
                audit=audit,
                now=lambda: NOW,
            ),
            audit,
            provider,
            broker,
            issued,
        )

    def create(self, manager: HostedWorkspaceManager, issued):
        return manager.create(
            workspace_request(brokered_credential=issued),
            self.token(),
            {"database-read": issued},
            request_id="request-create",
            at=NOW.isoformat(),
        )

    def test_create_is_exact_and_audit_is_credential_free(self) -> None:
        with test_workspace("sf602-create") as root:
            manager, audit, provider, _, issued = self.manager(root)
            handle = self.create(manager, issued)
            self.assertEqual(handle.state, "active")
            self.assertEqual(
                provider.create_calls[0]["injected_values"],
                {"database-read": issued.value},
            )
            audit_text = json.dumps(audit.events())
            self.assertNotIn(issued.value.decode("ascii"), audit_text)
            self.assertNotIn(issued.value.decode("ascii"), repr(handle))
            self.assertEqual(
                [event["event_type"] for event in audit.events()],
                [
                    "workspace.operation.requested",
                    "workspace.created",
                ],
            )

    def test_identity_and_credential_binding_fail_before_provider(self) -> None:
        with test_workspace("sf602-binding") as root:
            manager, _, provider, broker, issued = self.manager(root)
            with self.assertRaisesRegex(ProtocolError, "project does not match"):
                manager.create(
                    workspace_request(
                        project_id="project-two",
                        brokered_credential=issued,
                    ),
                    self.token(),
                    {"database-read": issued},
                    request_id="request-wrong-project",
                    at=NOW.isoformat(),
                )
            misbound = workspace_request(brokered_credential=issued)
            misbound["injection_slots"][0]["resource_id"] = "resource-other"
            _redigest(misbound)
            with self.assertRaisesRegex(ProtocolError, "misbound"):
                manager.create(
                    misbound,
                    self.token(),
                    {"database-read": issued},
                    request_id="request-wrong-credential",
                    at=NOW.isoformat(),
                )
            forged = replace(
                issued,
                workload_id="worker-two",
            )
            with self.assertRaisesRegex(ProtocolError, "not issued"):
                manager.create(
                    workspace_request(brokered_credential=issued),
                    self.token(),
                    {"database-read": forged},
                    request_id="request-forged-metadata",
                    at=NOW.isoformat(),
                )
            forged = replace(
                issued,
                value=b"forged-workspace-credential",
            )
            with self.assertRaisesRegex(ProtocolError, "not issued"):
                manager.create(
                    workspace_request(brokered_credential=issued),
                    self.token(),
                    {"database-read": forged},
                    request_id="request-forged-credential",
                    at=NOW.isoformat(),
                )
            restarted_broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={},
                audit=broker._audit,
                now=lambda: NOW,
            )
            restarted_manager = HostedWorkspaceManager(
                policy=workspace_policy(),
                identity_verifier=self.verifier(),
                providers={"workspace-provider-one": provider},
                credential_brokers={"broker-one": restarted_broker},
                audit=HostedWorkspaceAuditLedger(
                    root / "restarted-workspace.db"
                ),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "not issued"):
                restarted_manager.create(
                    workspace_request(brokered_credential=issued),
                    self.token(),
                    {"database-read": issued},
                    request_id="request-restarted-credential",
                    at=NOW.isoformat(),
                )
            with self.assertRaisesRegex(
                ProtocolError,
                "retention outlives",
            ):
                manager.create(
                    workspace_request(
                        retention_seconds=301,
                        brokered_credential=issued,
                    ),
                    self.token(),
                    {"database-read": issued},
                    request_id="request-short-credential",
                    at=NOW.isoformat(),
                )
            expired_at = NOW + timedelta(seconds=121)
            broker._now = lambda: expired_at
            manager._now = lambda: expired_at
            with self.assertRaisesRegex(ProtocolError, "not current"):
                manager.create(
                    workspace_request(
                        retention_seconds=1,
                        brokered_credential=issued,
                    ),
                    self.token(),
                    {"database-read": issued},
                    request_id="request-expired-credential",
                    at=expired_at.isoformat(),
                )
            broker._now = lambda: NOW
            manager._now = lambda: NOW
            with self.assertRaisesRegex(ProtocolError, "trusted workspace clock"):
                manager.create(
                    workspace_request(brokered_credential=issued),
                    self.token(),
                    {"database-read": issued},
                    request_id="request-spoofed-time",
                    at=(NOW - timedelta(seconds=1)).isoformat(),
                )
            self.assertEqual(provider.create_calls, [])

    def test_policy_expansion_fails_before_provider(self) -> None:
        policy = workspace_policy()
        cases = []

        tool = workspace_request()
        tool["tools"][0]["version"] = "untrusted"
        cases.append((_redigest(tool), "tool is not allowed"))

        egress = workspace_request()
        egress["network"]["allowed_egress"][0]["host"] = "evil.example.test"
        cases.append((_redigest(egress), "egress destination is not allowed"))

        budget = workspace_request()
        budget["resources"]["memory_bytes"] = 2 * 1024 * 1024 * 1024
        cases.append((_redigest(budget), "memory_bytes exceeds policy"))

        retention = workspace_request(retention_seconds=601)
        cases.append((retention, "retention exceeds"))

        for request, message in cases:
            with self.subTest(message=message):
                with self.assertRaisesRegex(ProtocolError, message):
                    validate_hosted_workspace_request(
                        request,
                        policy,
                        now=NOW,
                    )

    def test_valid_observation_records_egress_tools_and_resources(self) -> None:
        with test_workspace("sf602-observe") as root:
            manager, audit, _, _, issued = self.manager(root)
            self.create(manager, issued)
            result = manager.inspect(
                "workspace-sf602",
                self.token(),
                request_id="request-inspect",
                at=NOW.isoformat(),
            )
            self.assertEqual(result["state"], "active")
            self.assertEqual(result["reasons"], [])
            self.assertEqual(len(result["observation"]["egress"]), 1)
            self.assertEqual(
                audit.events()[-1]["event_type"],
                "workspace.observed",
            )

    def test_escape_attempt_quarantines_workspace(self) -> None:
        with test_workspace("sf602-escape") as root:
            provider = FakeHostedWorkspaceProvider()
            provider.violations = [
                {
                    "kind": "escape-attempt",
                    "observation_sha256": "sha256:" + "1" * 64,
                }
            ]
            manager, _, _, _, issued = self.manager(root, provider)
            self.create(manager, issued)
            result = manager.inspect(
                "workspace-sf602",
                self.token(),
                request_id="request-escape",
                at=NOW.isoformat(),
            )
            self.assertEqual(result["state"], "quarantined")
            self.assertIn("escape-attempt", result["reasons"])
            with self.assertRaisesRegex(
                MutationConflictError,
                "not active",
            ):
                manager.inspect(
                    "workspace-sf602",
                    self.token(),
                    request_id="request-after-escape",
                    at=NOW.isoformat(),
                )

    def test_unauthorized_egress_quarantines_workspace(self) -> None:
        with test_workspace("sf602-egress") as root:
            provider = FakeHostedWorkspaceProvider()
            provider.egress = [
                {
                    "protocol": "https",
                    "host": "exfil.example.test",
                    "port": 443,
                    "bytes_sent": 10,
                    "bytes_received": 0,
                    "connections": 1,
                }
            ]
            manager, _, _, _, issued = self.manager(root, provider)
            self.create(manager, issued)
            result = manager.inspect(
                "workspace-sf602",
                self.token(),
                request_id="request-egress",
                at=NOW.isoformat(),
            )
            self.assertEqual(result["state"], "quarantined")
            self.assertIn("unauthorized-egress", result["reasons"])

    def test_resource_exhaustion_quarantines_workspace(self) -> None:
        with test_workspace("sf602-resource") as root:
            provider = FakeHostedWorkspaceProvider()
            provider.resource_peaks = {
                "cpu_millis": 500,
                "memory_bytes": 512 * 1024 * 1024 + 1,
                "disk_bytes": 256 * 1024 * 1024,
                "pids": 12,
                "duration_seconds": 30,
            }
            manager, _, _, _, issued = self.manager(root, provider)
            self.create(manager, issued)
            result = manager.inspect(
                "workspace-sf602",
                self.token(),
                request_id="request-resource",
                at=NOW.isoformat(),
            )
            self.assertIn(
                "resource-memory_bytes-exhausted",
                result["reasons"],
            )

    def test_image_and_hostile_repository_drift_quarantine(self) -> None:
        cases = [
            ("image_digest", "sha256:" + "1" * 64, "image_digest-drift"),
            (
                "artifact_sha256",
                "sha256:" + "2" * 64,
                "artifact_sha256-drift",
            ),
            (
                "instruction_sha256",
                "sha256:" + "3" * 64,
                "instruction_sha256-drift",
            ),
        ]
        for field, value, reason in cases:
            with self.subTest(field=field):
                with test_workspace(f"sf602-drift-{field}") as root:
                    provider = FakeHostedWorkspaceProvider()
                    setattr(provider, field, value)
                    manager, _, _, _, issued = self.manager(root, provider)
                    self.create(manager, issued)
                    result = manager.inspect(
                        "workspace-sf602",
                        self.token(),
                        request_id=f"request-{field}",
                        at=NOW.isoformat(),
                    )
                    self.assertIn(reason, result["reasons"])

    def test_retention_expiry_quarantines_without_provider_use(self) -> None:
        with test_workspace("sf602-retention") as root:
            manager, _, provider, _, issued = self.manager(root)
            self.create(manager, issued)
            expired_at = NOW + timedelta(seconds=121)
            manager._now = lambda: expired_at
            result = manager.inspect(
                "workspace-sf602",
                self.token(),
                request_id="request-retention",
                at=expired_at.isoformat(),
            )
            self.assertEqual(result["state"], "quarantined")
            self.assertEqual(result["reasons"], ["retention-expired"])
            self.assertEqual(provider.inspect_calls, [])

    def test_expired_policy_and_regressed_clock_quarantine(self) -> None:
        cases = ("expired-policy", "regressed-clock")
        for case in cases:
            with self.subTest(case=case):
                with test_workspace(f"sf602-{case}") as root:
                    policy = workspace_policy()
                    if case == "expired-policy":
                        policy["expires_at"] = (
                            NOW + timedelta(seconds=1)
                        ).isoformat()
                        _redigest(policy)
                    provider = FakeHostedWorkspaceProvider(
                        policy_sha256=policy["content_sha256"]
                    )
                    audit = HostedWorkspaceAuditLedger(
                        root / "workspace.db"
                    )
                    verifier = self.verifier()
                    broker, issued = issue_workspace_credential(
                        root,
                        verifier,
                        self.token(),
                    )
                    manager = HostedWorkspaceManager(
                        policy=policy,
                        identity_verifier=verifier,
                        providers={
                            "workspace-provider-one": provider
                        },
                        credential_brokers={"broker-one": broker},
                        audit=audit,
                        now=lambda: NOW,
                    )
                    self.create(manager, issued)
                    observed_at = (
                        NOW + timedelta(seconds=2)
                        if case == "expired-policy"
                        else NOW - timedelta(seconds=1)
                    )
                    manager._now = lambda: observed_at
                    message = (
                        "not current"
                        if case == "expired-policy"
                        else "predates creation"
                    )
                    with self.assertRaisesRegex(ProtocolError, message):
                        manager.inspect(
                            "workspace-sf602",
                            self.token(),
                            request_id=f"request-{case}",
                            at=observed_at.isoformat(),
                        )
                    self.assertEqual(
                        manager.status("workspace-sf602")["state"],
                        "quarantined",
                    )
                    self.assertEqual(provider.inspect_calls, [])

    def test_policy_digest_drift_quarantines_before_provider(self) -> None:
        with test_workspace("sf602-policy-drift") as root:
            manager, audit, provider, broker, issued = self.manager(root)
            self.create(manager, issued)
            changed = workspace_policy()
            changed["providers"][0]["images"].append(
                "sha256:" + "f" * 64
            )
            _redigest(changed)
            restarted = HostedWorkspaceManager(
                policy=changed,
                identity_verifier=self.verifier(),
                providers={"workspace-provider-one": provider},
                credential_brokers={"broker-one": broker},
                audit=HostedWorkspaceAuditLedger(audit.path),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "changed after creation"):
                restarted.inspect(
                    "workspace-sf602",
                    self.token(),
                    request_id="request-policy-drift",
                    at=NOW.isoformat(),
                )
            self.assertEqual(
                restarted.status("workspace-sf602")["state"],
                "quarantined",
            )
            self.assertEqual(provider.inspect_calls, [])

    def test_provider_errors_cannot_expose_injected_bytes(self) -> None:
        for operation in ("create", "inspect", "destroy"):
            with self.subTest(operation=operation):
                with test_workspace(f"sf602-error-{operation}") as root:
                    provider = FakeHostedWorkspaceProvider()
                    manager, audit, _, _, issued = self.manager(
                        root,
                        provider,
                    )
                    leaking_value = issued.value.decode("ascii")
                    if operation != "create":
                        self.create(manager, issued)
                    setattr(
                        provider,
                        f"{operation}_error",
                        ProtocolError(leaking_value),
                    )
                    with self.assertRaises(ProtocolError) as raised:
                        if operation == "create":
                            manager.create(
                                workspace_request(
                                    brokered_credential=issued
                                ),
                                self.token(),
                                {"database-read": issued},
                                request_id="request-error-create",
                                at=NOW.isoformat(),
                            )
                        elif operation == "inspect":
                            manager.inspect(
                                "workspace-sf602",
                                self.token(),
                                request_id="request-error-inspect",
                                at=NOW.isoformat(),
                            )
                        else:
                            manager.destroy(
                                "workspace-sf602",
                                self.token(),
                                request_id="request-error-destroy",
                                at=NOW.isoformat(),
                            )
                    self.assertNotIn(
                        leaking_value,
                        str(raised.exception),
                    )
                    self.assertIsNone(raised.exception.__cause__)
                    self.assertIsNone(raised.exception.__context__)
                    self.assertNotIn(
                        leaking_value,
                        json.dumps(audit.events()),
                    )

    def test_missing_inspection_terminal_recovers_to_destroyable_quarantine(
        self,
    ) -> None:
        class FailingObservationAudit(HostedWorkspaceAuditLedger):
            fail_terminal = False

            def append(self, event_type, payload, **kwargs):
                if self.fail_terminal and event_type in {
                    "workspace.observed",
                    "workspace.quarantined",
                }:
                    raise ProtocolError(
                        "injected observation terminal failure"
                    )
                return super().append(event_type, payload, **kwargs)

        with test_workspace("sf602-inspection-recovery") as root:
            verifier = self.verifier()
            broker, issued = issue_workspace_credential(
                root,
                verifier,
                self.token(),
            )
            provider = FakeHostedWorkspaceProvider()
            audit_path = root / "workspace.db"
            audit = FailingObservationAudit(audit_path)
            manager = HostedWorkspaceManager(
                policy=workspace_policy(),
                identity_verifier=verifier,
                providers={"workspace-provider-one": provider},
                credential_brokers={"broker-one": broker},
                audit=audit,
                now=lambda: NOW,
            )
            self.create(manager, issued)
            audit.fail_terminal = True
            with self.assertRaisesRegex(ProtocolError, "terminal failure"):
                manager.inspect(
                    "workspace-sf602",
                    self.token(),
                    request_id="request-missing-inspection-terminal",
                    at=NOW.isoformat(),
                )

            restarted = HostedWorkspaceManager(
                policy=workspace_policy(),
                identity_verifier=verifier,
                providers={"workspace-provider-one": provider},
                credential_brokers={"broker-one": broker},
                audit=HostedWorkspaceAuditLedger(audit_path),
                now=lambda: NOW,
            )
            status = restarted.status("workspace-sf602")
            self.assertEqual(status["state"], "inspection-pending")
            with self.assertRaisesRegex(
                MutationConflictError,
                "still live",
            ):
                restarted.destroy(
                    "workspace-sf602",
                    self.token(),
                    request_id="request-destroy-live-inspection",
                    at=NOW.isoformat(),
                )
            recovered_at = NOW + timedelta(seconds=31)
            restarted._now = lambda: recovered_at
            status = restarted.status("workspace-sf602")
            self.assertEqual(status["state"], "quarantined")
            self.assertEqual(
                status["quarantine_reasons"],
                ["inspection-terminal-missing"],
            )
            destroyed = restarted.destroy(
                "workspace-sf602",
                self.token(),
                request_id="request-destroy-after-inspection-recovery",
                at=recovered_at.isoformat(),
            )
            self.assertEqual(destroyed["state"], "destroyed")

    def test_cleanup_failure_is_durable_and_retryable(self) -> None:
        with test_workspace("sf602-cleanup") as root:
            manager, _, provider, _, issued = self.manager(root)
            self.create(manager, issued)
            provider.cleanup_flags["storage_deleted"] = False
            with self.assertRaisesRegex(ProtocolError, "incomplete"):
                manager.destroy(
                    "workspace-sf602",
                    self.token(),
                    request_id="request-destroy-failed",
                    at=NOW.isoformat(),
                )
            self.assertEqual(
                manager.status("workspace-sf602")["state"],
                "cleanup-failed",
            )
            provider.cleanup_flags["storage_deleted"] = True
            result = manager.destroy(
                "workspace-sf602",
                self.token(),
                request_id="request-destroy-retry",
                at=NOW.isoformat(),
            )
            self.assertEqual(result["state"], "destroyed")

    def test_provider_outage_leaves_uncertainty_after_restart(self) -> None:
        with test_workspace("sf602-outage") as root:
            provider = FakeHostedWorkspaceProvider(create_unavailable=True)
            manager, audit, _, broker, issued = self.manager(root, provider)
            with self.assertRaisesRegex(ProtocolError, "unavailable"):
                manager.create(
                    workspace_request(brokered_credential=issued),
                    self.token(),
                    {"database-read": issued},
                    request_id="request-create-outage",
                    at=NOW.isoformat(),
                )
            restarted = HostedWorkspaceManager(
                policy=workspace_policy(),
                identity_verifier=self.verifier(),
                providers={"workspace-provider-one": provider},
                credential_brokers={"broker-one": broker},
                audit=HostedWorkspaceAuditLedger(audit.path),
                now=lambda: NOW,
            )
            self.assertEqual(
                restarted.status("workspace-sf602")["state"],
                "uncertain",
            )
            with self.assertRaisesRegex(
                MutationConflictError,
                "already used",
            ):
                restarted.create(
                    workspace_request(brokered_credential=issued),
                    self.token(),
                    {"database-read": issued},
                    request_id="request-create-new",
                    at=NOW.isoformat(),
                )
            self.assertEqual(len(provider.create_calls), 0)

    def test_provider_workspace_identity_cannot_be_reused(self) -> None:
        with test_workspace("sf602-provider-identity") as root:
            manager, _, provider, _, issued = self.manager(root)
            self.create(manager, issued)
            second = workspace_request(
                workspace_id="workspace-sf602-two",
                brokered_credential=issued,
            )
            with self.assertRaisesRegex(
                MutationConflictError,
                "already used",
            ):
                manager.create(
                    second,
                    self.token(),
                    {"database-read": issued},
                    request_id="request-create-second",
                    at=NOW.isoformat(),
                )
            self.assertEqual(len(provider.create_calls), 2)
            self.assertEqual(
                manager.status("workspace-sf602-two")["state"],
                "uncertain",
            )

    def test_inspection_outage_quarantines_but_allows_destruction(self) -> None:
        with test_workspace("sf602-inspect-outage") as root:
            provider = FakeHostedWorkspaceProvider(
                inspect_unavailable=True
            )
            manager, _, _, _, issued = self.manager(root, provider)
            self.create(manager, issued)
            with self.assertRaisesRegex(ProtocolError, "unavailable"):
                manager.inspect(
                    "workspace-sf602",
                    self.token(),
                    request_id="request-inspect-outage",
                    at=NOW.isoformat(),
                )
            self.assertEqual(
                manager.status("workspace-sf602")["state"],
                "quarantined",
            )
            result = manager.destroy(
                "workspace-sf602",
                self.token(),
                request_id="request-destroy-after-inspect-outage",
                at=NOW.isoformat(),
            )
            self.assertEqual(result["state"], "destroyed")

    def test_request_identity_cannot_replay_with_changed_time(self) -> None:
        with test_workspace("sf602-request-replay") as root:
            manager, _, provider, _, issued = self.manager(root)
            self.create(manager, issued)
            manager.inspect(
                "workspace-sf602",
                self.token(),
                request_id="request-reused",
                at=NOW.isoformat(),
            )
            later = NOW + timedelta(seconds=1)
            manager._now = lambda: later
            with self.assertRaisesRegex(
                MutationConflictError,
                "already used",
            ):
                manager.inspect(
                    "workspace-sf602",
                    self.token(),
                    request_id="request-reused",
                    at=later.isoformat(),
                )
            self.assertEqual(len(provider.inspect_calls), 1)

    def test_audit_tamper_is_detected(self) -> None:
        with test_workspace("sf602-tamper") as root:
            manager, audit, _, _, issued = self.manager(root)
            self.create(manager, issued)
            connection = audit._connection()
            try:
                connection.execute(
                    """
                    UPDATE hosted_workspace_events
                    SET event_id = ?
                    WHERE sequence = 2
                    """,
                    ("0" * 64,),
                )
                connection.commit()
            finally:
                connection.close()
            with self.assertRaisesRegex(ProtocolError, "event identity"):
                audit.events()


if __name__ == "__main__":
    unittest.main()
