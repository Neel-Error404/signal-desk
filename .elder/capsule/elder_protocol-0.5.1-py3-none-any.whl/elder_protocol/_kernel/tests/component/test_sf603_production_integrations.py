from __future__ import annotations

import sqlite3
import unittest
from datetime import timedelta

from elder_protocol.errors import MutationConflictError, ProtocolError
from elder_protocol.factory_operations.hosted_identity import BrokeredCredential
from elder_protocol.factory_operations.production_integrations import (
    ProductionIntegrationAuditLedger,
    ProductionIntegrationManager,
    integration_content_sha256,
)
from tests._sf601_support import signed_token
from tests._sf603_support import (
    NOW,
    external_record,
    integration_command,
    integration_environment,
    integration_policy,
    webhook_headers,
)
from tests._support import test_workspace


class ProductionIntegrationComponentTests(unittest.TestCase):
    def test_signed_webhook_is_accepted_once_and_survives_restart(self) -> None:
        with test_workspace("sf603-webhook") as root:
            env = integration_environment(root)
            body = b'{"issue":42,"state":"open"}'
            headers = webhook_headers(
                "github-main",
                env["credential"].value,
                body,
            )
            first = env["manager"].ingest_webhook(
                "github-main",
                headers,
                body,
                env["credential"],
                request_id="webhook-one",
                at=NOW.isoformat(),
            )
            second = env["manager"].ingest_webhook(
                "github-main",
                headers,
                body,
                env["credential"],
                request_id="webhook-two",
                at=NOW.isoformat(),
            )
            self.assertEqual(first, second)
            self.assertEqual(
                len(env["adapters"]["provider-github"].normalize_calls),
                1,
            )
            restarted = ProductionIntegrationManager(
                policy=env["policy"],
                identity_verifier=env["verifier"],
                adapters=env["adapters"],
                credential_brokers={"broker-one": env["broker"]},
                audit=ProductionIntegrationAuditLedger(env["audit_path"]),
                now=env["clock"],
            )
            self.assertEqual(restarted.status()["webhook_count"], 1)

    def test_forged_stale_and_changed_duplicate_webhooks_fail_closed(self) -> None:
        with test_workspace("sf603-webhook-reject") as root:
            env = integration_environment(root)
            body = b'{"issue":42}'
            forged = webhook_headers(
                "github-main",
                env["credential"].value,
                body,
            )
            forged["x-elder-signature"] = "sha256=" + "0" * 64
            with self.assertRaisesRegex(ProtocolError, "signature"):
                env["manager"].ingest_webhook(
                    "github-main",
                    forged,
                    body,
                    env["credential"],
                    request_id="forged",
                    at=NOW.isoformat(),
                )
            stale_time = NOW - timedelta(seconds=301)
            stale = webhook_headers(
                "github-main",
                env["credential"].value,
                body,
                timestamp=stale_time,
            )
            with self.assertRaisesRegex(ProtocolError, "stale"):
                env["manager"].ingest_webhook(
                    "github-main",
                    stale,
                    body,
                    env["credential"],
                    request_id="stale",
                    at=NOW.isoformat(),
                )
            accepted = webhook_headers(
                "github-main",
                env["credential"].value,
                body,
            )
            env["manager"].ingest_webhook(
                "github-main",
                accepted,
                body,
                env["credential"],
                request_id="accepted",
                at=NOW.isoformat(),
            )
            forged_duplicate = dict(accepted)
            forged_duplicate["x-elder-signature"] = "sha256=" + "0" * 64
            with self.assertRaisesRegex(ProtocolError, "signature"):
                env["manager"].ingest_webhook(
                    "github-main",
                    forged_duplicate,
                    body,
                    env["credential"],
                    request_id="forged-duplicate",
                    at=NOW.isoformat(),
                )
            changed_event_id = dict(accepted)
            changed_event_id["x-elder-event-id"] = "event-changed"
            with self.assertRaisesRegex(ProtocolError, "signature"):
                env["manager"].ingest_webhook(
                    "github-main",
                    changed_event_id,
                    body,
                    env["credential"],
                    request_id="changed-event-id",
                    at=NOW.isoformat(),
                )
            changed_body = b'{"issue":43}'
            changed = webhook_headers(
                "github-main",
                env["credential"].value,
                changed_body,
            )
            with self.assertRaisesRegex(
                MutationConflictError,
                "changed content",
            ):
                env["manager"].ingest_webhook(
                    "github-main",
                    changed,
                    changed_body,
                    env["credential"],
                    request_id="changed",
                    at=NOW.isoformat(),
                )

    def test_future_dated_webhook_is_rejected(self) -> None:
        with test_workspace("sf603-webhook-future") as root:
            env = integration_environment(root)
            body = b'{"issue":42}'
            headers = webhook_headers(
                "github-main",
                env["credential"].value,
                body,
                timestamp=NOW + timedelta(seconds=1),
            )
            with self.assertRaisesRegex(ProtocolError, "future"):
                env["manager"].ingest_webhook(
                    "github-main",
                    headers,
                    body,
                    env["credential"],
                    request_id="future-webhook",
                    at=NOW.isoformat(),
                )

    def test_webhook_adapter_exception_is_sanitized(self) -> None:
        with test_workspace("sf603-webhook-error") as root:
            env = integration_environment(root)
            adapter = env["adapters"]["provider-github"]
            adapter.execute_mode = "normalize-outage"
            body = b'{"issue":42}'
            headers = webhook_headers(
                "github-main",
                env["credential"].value,
                body,
            )
            with self.assertRaises(ProtocolError) as captured:
                env["manager"].ingest_webhook(
                    "github-main",
                    headers,
                    body,
                    env["credential"],
                    request_id="normalize-error",
                    at=NOW.isoformat(),
                )
            self.assertEqual(
                str(captured.exception),
                "Production integration adapter is unavailable.",
            )
            self.assertIsNone(captured.exception.__cause__)
            self.assertIsNone(captured.exception.__context__)

    def test_outbound_command_is_authenticated_and_provider_idempotent(self) -> None:
        with test_workspace("sf603-command") as root:
            env = integration_environment(root)
            command = integration_command()
            first = env["manager"].dispatch(
                command,
                env["token"],
                env["credential"],
                request_id="command-one",
                at=NOW.isoformat(),
            )
            second = env["manager"].dispatch(
                command,
                env["token"],
                env["credential"],
                request_id="command-two",
                at=NOW.isoformat(),
            )
            self.assertEqual(first, second)
            calls = env["adapters"]["provider-github"].execute_calls
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0]["idempotency_key"], "command-sf603")
            self.assertEqual(calls[0]["credential"], env["credential"].value)
            self.assertEqual(
                calls[0]["identity"]["workload_id"],
                "worker-one",
            )

    def test_completed_command_and_reconciliation_recheck_credential(self) -> None:
        with test_workspace("sf603-stale-duplicate") as root:
            env = integration_environment(root)
            command = integration_command(command_id="stale-duplicate")
            env["manager"].dispatch(
                command,
                env["token"],
                env["credential"],
                request_id="stale-command-one",
                at=env["clock"]().isoformat(),
            )
            env["manager"].reconcile(
                "github-main",
                env["token"],
                env["credential"],
                cursor=None,
                page_size=10,
                request_id="stale-page-one",
                at=env["clock"]().isoformat(),
            )
            env["clock"].advance(121)
            with self.assertRaisesRegex(ProtocolError, "not current"):
                env["manager"].dispatch(
                    command,
                    env["token"],
                    env["credential"],
                    request_id="stale-command-two",
                    at=env["clock"]().isoformat(),
                )
            with self.assertRaisesRegex(ProtocolError, "not current"):
                env["manager"].reconcile(
                    "github-main",
                    env["token"],
                    env["credential"],
                    cursor=None,
                    page_size=10,
                    request_id="stale-page-two",
                    at=env["clock"]().isoformat(),
                )

    def test_command_identity_drift_and_forged_credential_fail(self) -> None:
        with test_workspace("sf603-command-binding") as root:
            env = integration_environment(root)
            command = integration_command()
            env["manager"].dispatch(
                command,
                env["token"],
                env["credential"],
                request_id="command",
                at=NOW.isoformat(),
            )
            changed = integration_command(payload={"body": "changed"})
            with self.assertRaisesRegex(
                MutationConflictError,
                "drift",
            ):
                env["manager"].dispatch(
                    changed,
                    env["token"],
                    env["credential"],
                    request_id="changed-command",
                    at=NOW.isoformat(),
                )
            forged = BrokeredCredential(
                lease_id=env["credential"].lease_id,
                reference_id=env["credential"].reference_id,
                broker_id=env["credential"].broker_id,
                project_id=env["credential"].project_id,
                resource_id=env["credential"].resource_id,
                resource_version=env["credential"].resource_version,
                workload_id=env["credential"].workload_id,
                issued_at=env["credential"].issued_at,
                expires_at=env["credential"].expires_at,
                value=env["credential"].value,
            )
            with self.assertRaisesRegex(ProtocolError, "not issued"):
                env["manager"].dispatch(
                    integration_command(command_id="forged-command"),
                    env["token"],
                    forged,
                    request_id="forged-credential",
                    at=NOW.isoformat(),
                )

    def test_wrong_workload_identity_fails_before_provider_access(self) -> None:
        with test_workspace("sf603-wrong-identity") as root:
            env = integration_environment(root)
            wrong_token = signed_token(
                env["private_key"],
                subject="workload:project-two:service-two",
                project_id="project-two",
                workload_id="service-two",
                issued_at=NOW - timedelta(seconds=5),
                not_before=NOW - timedelta(seconds=5),
                expires_at=NOW + timedelta(minutes=5),
                jti="token-sf603-wrong-project",
            )
            command = integration_command(command_id="wrong-identity")
            with self.assertRaisesRegex(ProtocolError, "project"):
                env["manager"].dispatch(
                    command,
                    wrong_token,
                    env["credential"],
                    request_id="wrong-identity",
                    at=NOW.isoformat(),
                )
            self.assertEqual(
                len(env["adapters"]["provider-github"].execute_calls),
                0,
            )

    def test_rate_limit_blocks_provider_until_retry_time(self) -> None:
        with test_workspace("sf603-rate-limit") as root:
            env = integration_environment(root)
            adapter = env["adapters"]["provider-github"]
            adapter.execute_mode = "rate-limit"
            command = integration_command(command_id="rate-limited")
            limited = env["manager"].dispatch(
                command,
                env["token"],
                env["credential"],
                request_id="rate-one",
                at=env["clock"]().isoformat(),
            )
            self.assertEqual(limited["state"], "rate-limited")
            with self.assertRaisesRegex(ProtocolError, "rate-limited"):
                env["manager"].dispatch(
                    command,
                    env["token"],
                    env["credential"],
                    request_id="rate-two",
                    at=env["clock"]().isoformat(),
                )
            self.assertEqual(len(adapter.execute_calls), 1)
            env["clock"].advance(30)
            adapter.execute_mode = "success"
            succeeded = env["manager"].dispatch(
                command,
                env["token"],
                env["credential"],
                request_id="rate-three",
                at=env["clock"]().isoformat(),
            )
            self.assertEqual(succeeded["state"], "succeeded")
            self.assertEqual(len(adapter.execute_calls), 2)

    def test_provider_outage_dead_letters_and_explicit_replay_succeeds(self) -> None:
        with test_workspace("sf603-dead-letter") as root:
            env = integration_environment(root, maximum_attempts=2)
            adapter = env["adapters"]["provider-github"]
            adapter.execute_mode = "outage"
            command = integration_command(command_id="dead-letter")
            with self.assertRaisesRegex(ProtocolError, "unavailable"):
                env["manager"].dispatch(
                    command,
                    env["token"],
                    env["credential"],
                    request_id="attempt-one",
                    at=env["clock"]().isoformat(),
                )
            env["clock"].advance(10)
            with self.assertRaisesRegex(ProtocolError, "unavailable"):
                env["manager"].dispatch(
                    command,
                    env["token"],
                    env["credential"],
                    request_id="attempt-two",
                    at=env["clock"]().isoformat(),
                )
            self.assertEqual(env["manager"].status()["dead_letter_count"], 1)
            adapter.execute_mode = "success"
            replayed = env["manager"].replay_dead_letter(
                "github-main",
                "dead-letter",
                env["token"],
                env["credential"],
                request_id="owner-replay",
                at=env["clock"]().isoformat(),
            )
            duplicate = env["manager"].replay_dead_letter(
                "github-main",
                "dead-letter",
                env["token"],
                env["credential"],
                request_id="owner-replay",
                at=env["clock"]().isoformat(),
            )
            self.assertEqual(replayed, duplicate)
            self.assertEqual(replayed["state"], "succeeded")
            self.assertEqual(len(adapter.execute_calls), 3)

    def test_replay_authorizes_before_mutation_and_rechecks_on_duplicate(self) -> None:
        with test_workspace("sf603-replay-auth") as root:
            env = integration_environment(root, maximum_attempts=2)
            adapter = env["adapters"]["provider-github"]
            adapter.execute_mode = "outage"
            command = integration_command(command_id="replay-auth")
            for attempt in ("replay-auth-one", "replay-auth-two"):
                with self.assertRaisesRegex(ProtocolError, "unavailable"):
                    env["manager"].dispatch(
                        command,
                        env["token"],
                        env["credential"],
                        request_id=attempt,
                        at=env["clock"]().isoformat(),
                    )
                env["clock"].advance(10)
            with self.assertRaises(ProtocolError):
                env["manager"].replay_dead_letter(
                    "github-main",
                    "replay-auth",
                    "not-a-token",
                    env["credential"],
                    request_id="unauthorized-replay",
                    at=env["clock"]().isoformat(),
                )
            self.assertEqual(env["manager"].status()["dead_letter_count"], 1)
            adapter.execute_mode = "success"
            replayed = env["manager"].replay_dead_letter(
                "github-main",
                "replay-auth",
                env["token"],
                env["credential"],
                request_id="authorized-replay",
                at=env["clock"]().isoformat(),
            )
            self.assertEqual(replayed["state"], "succeeded")
            env["clock"].advance(101)
            with self.assertRaisesRegex(ProtocolError, "not current"):
                env["manager"].replay_dead_letter(
                    "github-main",
                    "replay-auth",
                    env["token"],
                    env["credential"],
                    request_id="authorized-replay",
                    at=env["clock"]().isoformat(),
                )

    def test_failed_replay_generation_can_retry_then_dedupe(self) -> None:
        with test_workspace("sf603-replay-retry") as root:
            env = integration_environment(root, maximum_attempts=2)
            adapter = env["adapters"]["provider-github"]
            adapter.execute_mode = "outage"
            command = integration_command(command_id="replay-retry")
            for attempt in ("initial-one", "initial-two"):
                with self.assertRaisesRegex(ProtocolError, "unavailable"):
                    env["manager"].dispatch(
                        command,
                        env["token"],
                        env["credential"],
                        request_id=attempt,
                        at=env["clock"]().isoformat(),
                    )
                env["clock"].advance(10)
            with self.assertRaisesRegex(ProtocolError, "unavailable"):
                env["manager"].replay_dead_letter(
                    "github-main",
                    "replay-retry",
                    env["token"],
                    env["credential"],
                    request_id="replay-generation-two",
                    at=env["clock"]().isoformat(),
                )
            env["clock"].advance(10)
            adapter.execute_mode = "success"
            replayed = env["manager"].replay_dead_letter(
                "github-main",
                "replay-retry",
                env["token"],
                env["credential"],
                request_id="replay-generation-two",
                at=env["clock"]().isoformat(),
            )
            duplicate = env["manager"].replay_dead_letter(
                "github-main",
                "replay-retry",
                env["token"],
                env["credential"],
                request_id="replay-generation-two",
                at=env["clock"]().isoformat(),
            )
            self.assertEqual(replayed, duplicate)
            self.assertEqual(replayed["state"], "succeeded")
            self.assertEqual(len(adapter.execute_calls), 4)

    def test_invalid_provider_response_counts_as_bounded_failure(self) -> None:
        with test_workspace("sf603-invalid-response") as root:
            env = integration_environment(root)
            adapter = env["adapters"]["provider-github"]
            adapter.execute_mode = "invalid"
            with self.assertRaisesRegex(ProtocolError, "fields"):
                env["manager"].dispatch(
                    integration_command(command_id="invalid-response"),
                    env["token"],
                    env["credential"],
                    request_id="invalid-response",
                    at=NOW.isoformat(),
                )
            status = env["manager"].status()
            self.assertEqual(status["command_count"], 1)
            self.assertEqual(status["dead_letter_count"], 0)

    def test_reconciliation_paginates_and_advances_cursor(self) -> None:
        with test_workspace("sf603-pagination") as root:
            env = integration_environment(root)
            adapter = env["adapters"]["provider-github"]
            adapter.pages = {
                None: (
                    [
                        external_record("issue-41"),
                        external_record("issue-42"),
                    ],
                    "cursor-two",
                ),
                "cursor-two": ([external_record("issue-43")], None),
            }
            first = env["manager"].reconcile(
                "github-main",
                env["token"],
                env["credential"],
                cursor=None,
                page_size=2,
                request_id="page-one",
                at=NOW.isoformat(),
            )
            second = env["manager"].reconcile(
                "github-main",
                env["token"],
                env["credential"],
                cursor="cursor-two",
                page_size=2,
                request_id="page-two",
                at=NOW.isoformat(),
            )
            self.assertEqual(first["next_cursor"], "cursor-two")
            self.assertIsNone(second["next_cursor"])
            self.assertEqual(env["manager"].status()["record_count"], 3)

    def test_reconciliation_detects_same_version_record_drift(self) -> None:
        with test_workspace("sf603-drift") as root:
            env = integration_environment(root)
            adapter = env["adapters"]["provider-github"]
            adapter.pages = {
                None: (
                    [
                        external_record(
                            digest="1" * 64,
                        )
                    ],
                    None,
                )
            }
            env["manager"].reconcile(
                "github-main",
                env["token"],
                env["credential"],
                cursor=None,
                page_size=10,
                request_id="drift-baseline",
                at=NOW.isoformat(),
            )
            adapter.pages = {
                None: (
                    [
                        external_record(
                            digest="2" * 64,
                        )
                    ],
                    None,
                )
            }
            drifted = env["manager"].reconcile(
                "github-main",
                env["token"],
                env["credential"],
                cursor=None,
                page_size=10,
                request_id="drift-observed",
                at=NOW.isoformat(),
            )
            self.assertEqual(drifted["state"], "drifted")
            self.assertEqual(env["manager"].status()["drift_count"], 1)

    def test_reconciliation_rejects_cursor_cycles(self) -> None:
        with test_workspace("sf603-cursor-cycle") as root:
            env = integration_environment(root)
            adapter = env["adapters"]["provider-github"]
            adapter.pages = {
                None: ([external_record("issue-41")], "cursor-a"),
                "cursor-a": ([external_record("issue-42")], "cursor-b"),
                "cursor-b": ([external_record("issue-43")], "cursor-a"),
            }
            env["manager"].reconcile(
                "github-main",
                env["token"],
                env["credential"],
                cursor=None,
                page_size=10,
                request_id="cycle-one",
                at=NOW.isoformat(),
            )
            env["manager"].reconcile(
                "github-main",
                env["token"],
                env["credential"],
                cursor="cursor-a",
                page_size=10,
                request_id="cycle-two",
                at=NOW.isoformat(),
            )
            with self.assertRaisesRegex(ProtocolError, "cycled"):
                env["manager"].reconcile(
                    "github-main",
                    env["token"],
                    env["credential"],
                    cursor="cursor-b",
                    page_size=10,
                    request_id="cycle-three",
                    at=NOW.isoformat(),
                )
            restarted = ProductionIntegrationManager(
                policy=env["policy"],
                identity_verifier=env["verifier"],
                adapters=env["adapters"],
                credential_brokers={"broker-one": env["broker"]},
                audit=ProductionIntegrationAuditLedger(env["audit_path"]),
                now=env["clock"],
            )
            self.assertEqual(restarted.status()["record_count"], 2)

    def test_reconciliation_outage_is_terminal_and_restart_safe(self) -> None:
        with test_workspace("sf603-reconcile-outage") as root:
            env = integration_environment(root)
            env["adapters"]["provider-github"].list_mode = "outage"
            with self.assertRaisesRegex(ProtocolError, "unavailable"):
                env["manager"].reconcile(
                    "github-main",
                    env["token"],
                    env["credential"],
                    cursor=None,
                    page_size=10,
                    request_id="reconcile-outage",
                    at=NOW.isoformat(),
                )
            restarted = ProductionIntegrationManager(
                policy=env["policy"],
                identity_verifier=env["verifier"],
                adapters=env["adapters"],
                credential_brokers={"broker-one": env["broker"]},
                audit=ProductionIntegrationAuditLedger(env["audit_path"]),
                now=env["clock"],
            )
            self.assertEqual(restarted.status()["record_count"], 0)

    def test_reconciliation_rejects_credential_before_intent(self) -> None:
        with test_workspace("sf603-reconcile-credential") as root:
            env = integration_environment(root)
            forged = BrokeredCredential(
                lease_id=env["credential"].lease_id,
                reference_id=env["credential"].reference_id,
                broker_id=env["credential"].broker_id,
                project_id=env["credential"].project_id,
                resource_id=env["credential"].resource_id,
                resource_version=env["credential"].resource_version,
                workload_id=env["credential"].workload_id,
                issued_at=env["credential"].issued_at,
                expires_at=env["credential"].expires_at,
                value=env["credential"].value,
            )
            with self.assertRaisesRegex(ProtocolError, "not issued"):
                env["manager"].reconcile(
                    "github-main",
                    env["token"],
                    forged,
                    cursor=None,
                    page_size=10,
                    request_id="reconcile-forged-object",
                    at=NOW.isoformat(),
                )
            restarted = ProductionIntegrationManager(
                policy=env["policy"],
                identity_verifier=env["verifier"],
                adapters=env["adapters"],
                credential_brokers={"broker-one": env["broker"]},
                audit=ProductionIntegrationAuditLedger(env["audit_path"]),
                now=env["clock"],
            )
            self.assertEqual(restarted.status()["record_count"], 0)

    def test_malformed_reconciliation_page_closes_operation(self) -> None:
        with test_workspace("sf603-reconcile-invalid") as root:
            env = integration_environment(root)
            env["adapters"]["provider-github"].list_mode = "invalid"
            with self.assertRaisesRegex(ProtocolError, "fields"):
                env["manager"].reconcile(
                    "github-main",
                    env["token"],
                    env["credential"],
                    cursor=None,
                    page_size=10,
                    request_id="reconcile-invalid",
                    at=NOW.isoformat(),
                )
            restarted = ProductionIntegrationManager(
                policy=env["policy"],
                identity_verifier=env["verifier"],
                adapters=env["adapters"],
                credential_brokers={"broker-one": env["broker"]},
                audit=ProductionIntegrationAuditLedger(env["audit_path"]),
                now=env["clock"],
            )
            self.assertEqual(restarted.status()["record_count"], 0)

    def test_audit_tamper_and_secret_persistence_are_rejected(self) -> None:
        with test_workspace("sf603-audit") as root:
            env = integration_environment(root)
            body = b"private webhook body that must not persist"
            headers = webhook_headers(
                "github-main",
                env["credential"].value,
                body,
            )
            env["manager"].ingest_webhook(
                "github-main",
                headers,
                body,
                env["credential"],
                request_id="audit-webhook",
                at=NOW.isoformat(),
            )
            env["manager"].dispatch(
                integration_command(command_id="audit-command"),
                env["token"],
                env["credential"],
                request_id="audit-command",
                at=NOW.isoformat(),
            )
            audit_bytes = env["audit_path"].read_bytes()
            self.assertNotIn(body, audit_bytes)
            self.assertNotIn(env["credential"].value, audit_bytes)
            self.assertNotIn(
                headers["x-elder-signature"].encode("utf-8"),
                audit_bytes,
            )
            connection = sqlite3.connect(env["audit_path"])
            try:
                connection.execute(
                    """
                    UPDATE production_integration_audit
                    SET payload_json = '{}'
                    WHERE sequence = 1
                    """
                )
                connection.commit()
            finally:
                connection.close()
            with self.assertRaisesRegex(ProtocolError, "digest|identity"):
                ProductionIntegrationAuditLedger(env["audit_path"])

    def test_audit_rejects_conflicting_policy_generation(self) -> None:
        with test_workspace("sf603-policy-binding") as root:
            env = integration_environment(root)
            copy_policy = integration_policy()
            changed = {
                **copy_policy,
                "integrations": [
                    {
                        **entry,
                        "provider_id": (
                            "provider-alt"
                            if entry["integration_id"] == "github-main"
                            else entry["provider_id"]
                        ),
                    }
                    for entry in copy_policy["integrations"]
                ],
            }
            changed["content_sha256"] = integration_content_sha256(
                {
                    key: value
                    for key, value in changed.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "different policy generation",
            ):
                ProductionIntegrationManager(
                    policy=changed,
                    identity_verifier=env["verifier"],
                    adapters=env["adapters"],
                    credential_brokers={"broker-one": env["broker"]},
                    audit=ProductionIntegrationAuditLedger(env["audit_path"]),
                    now=env["clock"],
                )


if __name__ == "__main__":
    unittest.main()
