from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.journal_store import JournalRecorder
from elder_protocol.factory_operations.operations_store import (
    operations_connection,
)
from elder_protocol.factory_operations.projections import ProjectionRuntime
from tests._sf106_oracle import (
    PROJECTIONS,
    ROOT,
    install_fixture_store,
    load_fixture,
    oracle_replay,
    read_projection_rows,
    read_public_events,
    validate_scenario_coverage,
    validate_fixture,
)


class SF106GoldenOracleComponentTests(unittest.TestCase):
    def test_manifest_rejects_provenance_and_digest_drift(self) -> None:
        fixture = load_fixture()
        manifest = fixture["manifest"]

        same_identity = copy.deepcopy(manifest)
        same_identity["independently_reviewed_by"] = same_identity["authored_by"]
        with self.assertRaises(ValueError):
            validate_fixture(manifest=same_identity)

        changed_digest = copy.deepcopy(manifest)
        changed_digest["files"]["journal-entries.json"]["sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            validate_fixture(manifest=changed_digest)

    def test_oracle_covers_every_source_projection_classification(self) -> None:
        fixture = load_fixture()
        replay = oracle_replay(fixture)
        oracle_source = (ROOT / "tests" / "_sf106_oracle.py").read_text(
            encoding="utf-8"
        )
        self.assertNotIn("factory_operations.projections", oracle_source)
        self.assertNotIn("ProjectionRuntime._reduce", oracle_source)
        self.assertNotIn("ProjectionQueries", oracle_source)
        self.assertEqual(len(fixture["manifest"]["source_family_ids"]), 19)
        self.assertEqual(
            {
                entry["source_record"]["source_registry_id"]
                for entry in replay["entries"]
            },
            set(fixture["manifest"]["source_family_ids"]),
        )
        self.assertEqual(
            len(replay["classifications"]),
            len(replay["entries"]) * len(PROJECTIONS),
        )
        covered = validate_scenario_coverage(fixture, replay["entries"])
        self.assertEqual(
            set(covered),
            set(fixture["manifest"]["scenario_labels"]),
        )

        source_registry = json.loads(
            (
                ROOT
                / "factory"
                / "operations"
                / "journal-source-registry.json"
            ).read_text(encoding="utf-8")
        )
        registered = {
            source["id"]: {
                "reducers": sorted(source["reducers"]),
                "no_ops": sorted(source["no_op_projections"]),
            }
            for source in source_registry["sources"]
        }
        declared = {
            source_id: {
                "reducers": sorted(value["reducers"]),
                "no_ops": sorted(value["no_ops"]),
            }
            for source_id, value in fixture["manifest"][
                "classification_matrix"
            ].items()
        }
        self.assertEqual(declared, registered)
        self.assertEqual(
            sum(
                item["classification"] == "reducer"
                for item in replay["classifications"]
            ),
            sum(
                len(declared[entry["source_record"]["source_registry_id"]]["reducers"])
                for entry in replay["entries"]
            ),
        )

    def test_production_projection_replay_matches_hand_authored_oracle(self) -> None:
        fixture = load_fixture()
        replay = oracle_replay(fixture)
        for projection_id in PROJECTIONS:
            self.assertEqual(
                fixture["expected"][projection_id],
                replay["projections"][projection_id],
            )
        self.assertEqual(
            fixture["expected"]["public-events"],
            {"events": replay["public_events"]},
        )

        with tempfile.TemporaryDirectory() as temporary:
            store = Path(temporary) / "sf106-golden.db"
            install_fixture_store(store, fixture, replay)
            runtime = ProjectionRuntime(store)
            runtime.initialize()
            generations: dict[str, int] = {}
            for projection_id in PROJECTIONS:
                report = runtime.rebuild_projection(
                    projection_id,
                    batch_size=7,
                )
                generations[projection_id] = report["generation"]
                self.assertEqual(report["status"], "active")
                expected = replay["projections"][projection_id]
                self.assertEqual(report["row_count"], expected["row_count"])
                self.assertEqual(
                    report["projection_sha256"],
                    expected["projection_sha256"],
                )
                self.assertEqual(
                    read_projection_rows(store, projection_id),
                    expected["rows"],
                )
            self.assertEqual(
                read_public_events(store),
                replay["public_events"],
            )
            for projection_id in PROJECTIONS:
                verified = runtime.verify_projection(
                    projection_id,
                    generations[projection_id],
                    require_current=True,
                )
                self.assertEqual(
                    verified["projection_sha256"],
                    replay["projections"][projection_id][
                        "projection_sha256"
                    ],
                )

    def test_public_mapping_uses_production_predicate_and_uniqueness(
        self,
    ) -> None:
        fixture = load_fixture()
        replay = oracle_replay(fixture)
        accepted = next(
            entry
            for entry in replay["entries"]
            if entry["source_record"]["source_registry_id"]
            == "signal-revisions"
        )
        internal = next(
            entry
            for entry in replay["entries"]
            if entry["source_record"]["source_registry_id"]
            == "product-factory-revisions"
        )
        with tempfile.TemporaryDirectory() as temporary:
            store = Path(temporary) / "sf106-public-mapping.db"
            install_fixture_store(store, fixture, replay)
            recorder = JournalRecorder()
            with operations_connection(
                store,
                isolation_level=None,
            ) as connection:
                connection.execute("BEGIN IMMEDIATE")
                self.assertFalse(
                    recorder._append_public_event_for_fact(
                        connection,
                        entry=internal,
                        fact={
                            "operation": internal["operation"],
                            "record": internal[
                                "projection_document"
                            ]["record"],
                        },
                    )
                )
                predicate_negative = copy.deepcopy(accepted)
                predicate_negative["operation"] = "receive"
                self.assertFalse(
                    recorder._append_public_event_for_fact(
                        connection,
                        entry=predicate_negative,
                        fact={
                            "operation": "receive",
                            "record": accepted[
                                "projection_document"
                            ]["record"],
                        },
                    )
                )
                with self.assertRaisesRegex(
                    ProtocolError,
                    "already emitted",
                ):
                    recorder._append_public_event_for_fact(
                        connection,
                        entry=accepted,
                        fact={
                            "operation": accepted["operation"],
                            "record": accepted[
                                "projection_document"
                            ]["record"],
                        },
                    )
                connection.rollback()

            disabled = JournalRecorder()
            disabled._public_mapping_by_id["signal-accepted"][
                "enabled"
            ] = False
            with operations_connection(
                store,
                isolation_level=None,
            ) as connection:
                connection.execute("BEGIN IMMEDIATE")
                self.assertFalse(
                    disabled._append_public_event_for_fact(
                        connection,
                        entry=accepted,
                        fact={
                            "operation": accepted["operation"],
                            "record": accepted[
                                "projection_document"
                            ]["record"],
                        },
                    )
                )
                connection.rollback()


if __name__ == "__main__":
    unittest.main()
