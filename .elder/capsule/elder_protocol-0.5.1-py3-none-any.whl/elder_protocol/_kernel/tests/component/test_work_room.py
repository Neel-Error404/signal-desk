from __future__ import annotations

import copy
import sqlite3
import unittest
from unittest.mock import patch

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import MutationConflictError, ProtocolError
from elder_protocol.factory_operations import (
    DurableSessionController,
    ProjectionRuntime,
    WorkRoom,
)
from elder_protocol.factory_operations._common import canonical_json
from tests._sf203_support import StaticWorkspaceAuthority, running_fixture
from tests._support import test_workspace


class WorkRoomComponentTests(unittest.TestCase):
    def test_note_replay_restart_and_steer_use_durable_sources(self) -> None:
        with test_workspace("sf302-work-room") as workspace:
            _, controller, aggregate, binding, _, session = running_fixture(
                workspace
            )
            authority = StaticWorkspaceAuthority(binding)
            room = WorkRoom(
                controller.path,
                session.path,
                workspace_authority=authority,
            )
            project_id = aggregate["run"]["project_id"]
            work_item_id = aggregate["initial_binding"]["work_item_id"]
            note_input = {
                "kind": "note",
                "run_id": aggregate["run"]["id"],
                "reason": "Record the owner's implementation boundary.",
                "payload": {"text": "Stay within SF-302 and do not enter approvals."},
            }
            accepted = room.submit_input(
                project_id=project_id,
                work_item_id=work_item_id,
                actor_identity_id="founder",
                idempotency_key="sf302-note-idempotency",
                input_record=note_input,
                observed_at="2026-08-11T01:09:00+00:00",
                runtime_fence={
                    "boot_id": "operations-api-boot-foundation",
                    "runtime_generation": 1,
                },
            )
            self.assertEqual(accepted["source"], "work-room-notes")
            self.assertEqual(
                room.submit_input(
                    project_id=project_id,
                    work_item_id=work_item_id,
                    actor_identity_id="founder",
                    idempotency_key="sf302-note-idempotency",
                    input_record=note_input,
                    observed_at="2026-08-11T01:09:00+00:00",
                    runtime_fence={
                        "boot_id": "operations-api-boot-foundation",
                        "runtime_generation": 1,
                    },
                ),
                accepted,
            )
            changed = copy.deepcopy(note_input)
            changed["payload"]["text"] = "Changed under the same identity."
            with self.assertRaisesRegex(MutationConflictError, "collision"):
                room.submit_input(
                    project_id=project_id,
                    work_item_id=work_item_id,
                    actor_identity_id="founder",
                    idempotency_key="sf302-note-idempotency",
                    input_record=changed,
                    observed_at="2026-08-11T01:09:00+00:00",
                    runtime_fence={
                        "boot_id": "operations-api-boot-foundation",
                        "runtime_generation": 1,
                    },
                )

            current_control = session.get("session-control-sf203-start-1")
            other_command = copy.deepcopy(current_control["command"])
            other_command["control_id"] = (
                "session-control-sf302-other-generation"
            )
            other_command["idempotency_key"] = (
                "sf302-other-generation-idempotency"
            )
            other_command["session_generation"] += 1
            other_command["workspace_binding_sha256"] = "f" * 64
            other = {
                "version": current_control["version"],
                "control_id": other_command["control_id"],
                "command": other_command,
                "status": "pending",
                "record_version": 1,
                "attempt_count": 0,
                "lease_generation": 0,
                "lease": None,
                "current_step": None,
                "external_effect_started": False,
                "result": None,
                "last_error": None,
                "waiting_reason": None,
                "continuation_of": None,
                "continued_by": None,
                "created_at": "2026-08-11T01:09:30+00:00",
                "updated_at": "2026-08-11T01:09:30+00:00",
                "completed_at": None,
            }
            other["content_sha256"] = canonical_sha256(other)
            connection = sqlite3.connect(session.path)
            try:
                connection.execute(
                    """
                    INSERT INTO session_controls(
                        control_id, project_id, run_id, worker_session_id,
                        session_generation, idempotency_key, operation,
                        status, record_version, attempt_count, lease_owner,
                        lease_generation, lease_expires_at, record_json,
                        content_sha256, created_at, updated_at, completed_at
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 0, NULL, ?, ?, ?, ?, NULL)
                    """,
                    (
                        other["control_id"],
                        other_command["project_id"],
                        other_command["run_id"],
                        other_command["worker_session_id"],
                        other_command["session_generation"],
                        other_command["idempotency_key"],
                        other_command["operation"],
                        other["status"],
                        other["record_version"],
                        other["attempt_count"],
                        canonical_json(other),
                        other["content_sha256"],
                        other["created_at"],
                        other["updated_at"],
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO session_control_history(
                        control_id, record_version, operation, snapshot_json,
                        content_sha256, created_at
                    ) VALUES(?, 1, 'submit', ?, ?, ?)
                    """,
                    (
                        other["control_id"],
                        canonical_json(other),
                        other["content_sha256"],
                        other["updated_at"],
                    ),
                )
                connection.commit()
            finally:
                connection.close()

            steer = room.submit_input(
                project_id=project_id,
                work_item_id=work_item_id,
                actor_identity_id="founder",
                idempotency_key="sf302-steer-idempotency",
                input_record={
                    "kind": "steer",
                    "run_id": aggregate["run"]["id"],
                    "reason": "Keep the implementation within the approved scope.",
                    "payload": {"instruction": "Finish SF-302 without approval logic."},
                },
                observed_at="2026-08-11T01:10:00+00:00",
                runtime_fence={
                    "boot_id": "operations-api-boot-foundation",
                    "runtime_generation": 1,
                },
            )
            self.assertEqual(steer["source"], "session-controls")
            self.assertEqual(steer["record"]["status"], "pending")
            self.assertEqual(
                steer["record"]["command"]["workspace_binding_sha256"],
                next(
                    record["command"]["workspace_binding_sha256"]
                    for record in [
                        session.get(
                            "session-control-sf203-start-1"
                        )
                    ]
                ),
            )

            ProjectionRuntime(controller.path).rebuild_all()
            reopened = WorkRoom(
                controller.path,
                session.path,
                workspace_authority=authority,
            )
            snapshot = reopened.snapshot(
                project_id=project_id,
                work_item_id=work_item_id,
                observed_at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(snapshot["selected_run_id"], aggregate["run"]["id"])
            self.assertEqual(snapshot["allowed_inputs"][0], "note")
            self.assertEqual(snapshot["allowed_inputs"][-1], "cancel")
            self.assertTrue(
                any(item["kind"] == "owner-note" for item in snapshot["activity"])
            )
            self.assertFalse(
                any(
                    item["record"].get("control_id")
                    == other["control_id"]
                    for item in snapshot["activity"]
                )
            )
            self.assertTrue(
                any(
                    item["kind"] == "owner-control"
                    and item["record"]["control_id"]
                    == steer["record"]["control_id"]
                    for item in snapshot["activity"]
                )
            )

    def test_missing_lineage_and_secret_input_fail_closed(self) -> None:
        with test_workspace("sf302-work-room-fail") as workspace:
            _, controller, aggregate, binding, _, session = running_fixture(
                workspace
            )
            room = WorkRoom(
                controller.path,
                session.path,
                workspace_authority=StaticWorkspaceAuthority(binding),
            )
            secret = {
                "kind": "note",
                "run_id": aggregate["run"]["id"],
                "reason": "Record owner context.",
                "payload": {"api_key": "sk-" + "a" * 32},
            }
            with self.assertRaisesRegex(ProtocolError, "secret"):
                room.submit_input(
                    project_id=aggregate["run"]["project_id"],
                    work_item_id=aggregate["initial_binding"]["work_item_id"],
                    actor_identity_id="founder",
                    idempotency_key="sf302-secret-idempotency",
                    input_record=secret,
                    observed_at="2026-08-11T01:09:00+00:00",
                    runtime_fence={
                        "boot_id": "operations-api-boot-foundation",
                        "runtime_generation": 1,
                    },
                )

    def test_closed_command_mapping_requires_an_exact_run(self) -> None:
        with test_workspace("sf302-work-room-command-map") as workspace:
            _, controller, aggregate, binding, _, session = running_fixture(
                workspace
            )
            room = WorkRoom(
                controller.path,
                session.path,
                workspace_authority=StaticWorkspaceAuthority(binding),
            )
            project_id = aggregate["run"]["project_id"]
            work_item_id = aggregate["initial_binding"]["work_item_id"]
            with self.assertRaisesRegex(MutationConflictError, "exact current"):
                room.submit_input(
                    project_id=project_id,
                    work_item_id=work_item_id,
                    actor_identity_id="founder",
                    idempotency_key="sf302-null-run-idempotency",
                    input_record={
                        "kind": "steer",
                        "run_id": None,
                        "reason": "Reject ambiguous command admission.",
                        "payload": {"instruction": "Do not select a run implicitly."},
                    },
                    observed_at="2026-08-11T01:10:00+00:00",
                    runtime_fence={
                        "boot_id": "operations-api-boot-foundation",
                        "runtime_generation": 1,
                    },
                )

            terminal = copy.deepcopy(aggregate)
            terminal["run"]["status"] = "completed"
            ProjectionRuntime(controller.path).rebuild_all()
            with patch.object(
                room,
                "_matching_runs",
                return_value=[terminal],
            ):
                snapshot = room.snapshot(
                    project_id=project_id,
                    work_item_id=work_item_id,
                    observed_at="2026-08-11T01:10:30+00:00",
                )
                self.assertEqual(snapshot["allowed_inputs"], ["note"])
                with self.assertRaisesRegex(
                    MutationConflictError,
                    "exact current",
                ):
                    room.submit_input(
                        project_id=project_id,
                        work_item_id=work_item_id,
                        actor_identity_id="founder",
                        idempotency_key=(
                            "sf302-terminal-run-idempotency"
                        ),
                        input_record={
                            "kind": "steer",
                            "run_id": aggregate["run"]["id"],
                            "reason": "Reject steering for terminal work.",
                            "payload": {
                                "instruction": (
                                    "Do not reopen a completed run."
                                )
                            },
                        },
                        observed_at="2026-08-11T01:10:30+00:00",
                        runtime_fence={
                            "boot_id": "operations-api-boot-foundation",
                            "runtime_generation": 1,
                        },
                    )

            class CapturingAdmission:
                workspace_binding_sha256 = canonical_sha256(binding)

                def __init__(self) -> None:
                    self.commands: list[dict] = []

                def submit(self, command: dict, *, at: str) -> dict:
                    self.commands.append(copy.deepcopy(command))
                    body = {
                        "version": "1.0.0",
                        "control_id": command["control_id"],
                        "command": copy.deepcopy(command),
                        "status": "pending",
                        "record_version": 1,
                        "attempt_count": 0,
                        "lease_generation": 0,
                        "lease": None,
                        "current_step": None,
                        "external_effect_started": False,
                        "result": None,
                        "last_error": None,
                        "waiting_reason": None,
                        "continuation_of": command["payload"].get(
                            "continuation_of"
                        ),
                        "continued_by": None,
                        "created_at": at,
                        "updated_at": at,
                        "completed_at": None,
                    }
                    return {
                        **body,
                        "content_sha256": canonical_sha256(body),
                    }

            admission = CapturingAdmission()
            command_payloads = {
                "steer": {"instruction": "Narrow the current implementation."},
                "follow-up": {
                    "instruction": "Continue with the bounded correction.",
                    "continuation_of": "session-control-sf203-wait-1",
                },
                "pause": {},
                "resume": {},
                "cancel": {},
            }
            with patch.object(
                DurableSessionController,
                "admission_for_existing_run",
                return_value=admission,
            ):
                for index, (kind, payload) in enumerate(
                    command_payloads.items(),
                    start=1,
                ):
                    result = room.submit_input(
                        project_id=project_id,
                        work_item_id=work_item_id,
                        actor_identity_id="founder",
                        idempotency_key=(
                            f"sf302-map-{kind}-{index}-idempotency"
                        ),
                        input_record={
                            "kind": kind,
                            "run_id": aggregate["run"]["id"],
                            "reason": f"Map the owner {kind} command exactly.",
                            "payload": payload,
                        },
                        observed_at=(
                            f"2026-08-11T01:{10 + index:02d}:00+00:00"
                        ),
                        runtime_fence={
                            "boot_id": "operations-api-boot-foundation",
                            "runtime_generation": 1,
                        },
                    )
                    self.assertEqual(result["input_kind"], kind)
                    self.assertEqual(result["record"]["command"]["operation"], kind)
                    self.assertEqual(result["record"]["command"]["payload"], payload)
            self.assertEqual(
                [item["operation"] for item in admission.commands],
                list(command_payloads),
            )


if __name__ == "__main__":
    unittest.main()
