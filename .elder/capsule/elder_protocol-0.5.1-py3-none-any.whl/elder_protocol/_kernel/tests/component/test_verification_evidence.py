from __future__ import annotations

import json
import unittest

from scripts.verification_evidence import LEVELS, _finalize, build_ladder_evidence
from tests._support import test_workspace


class VerificationEvidenceComponentTests(unittest.TestCase):
    def test_ladder_evidence_binds_exact_commit_and_run(self) -> None:
        with test_workspace("verification-evidence") as workspace:
            results = workspace / "results"
            results.mkdir()
            for index, level in enumerate(LEVELS, start=1):
                payload = _finalize(
                    {
                        "version": 1,
                        "kind": "test-level",
                        "level": level,
                        "status": "passed",
                        "start_dir": f"tests/{level.lower()}",
                        "tests_run": index,
                        "failures": 0,
                        "errors": 0,
                        "skipped": 0,
                        "started_at": "2026-08-06T00:00:00+00:00",
                        "finished_at": "2026-08-06T00:00:01+00:00",
                    }
                )
                (results / f"{level.lower()}.json").write_text(
                    json.dumps(payload),
                    encoding="utf-8",
                )
            output = workspace / "ladder.json"
            evidence = build_ladder_evidence(
                scope="protocol",
                results_dir=results,
                output=output,
                environment={
                    "GITHUB_REPOSITORY": "owner/repository",
                    "GITHUB_SHA": "a" * 40,
                    "GITHUB_REF": "refs/heads/main",
                    "GITHUB_WORKFLOW_REF": (
                        "owner/repository/.github/workflows/elder-ci.yml@refs/heads/main"
                    ),
                    "GITHUB_RUN_ID": "12345",
                    "GITHUB_RUN_ATTEMPT": "2",
                    "GITHUB_EVENT_NAME": "push",
                    "GITHUB_JOB": "protocol",
                    "RUNNER_OS": "Linux",
                },
            )
            self.assertEqual(evidence["commit_sha"], "a" * 40)
            self.assertEqual(evidence["run_id"], "12345")
            self.assertEqual(evidence["run_attempt"], "2")
            self.assertEqual(evidence["total_tests"], 15)
            self.assertTrue(output.is_file())

    def test_ladder_evidence_rejects_failed_level(self) -> None:
        with test_workspace("verification-evidence-failed") as workspace:
            results = workspace / "results"
            results.mkdir()
            for level in LEVELS:
                payload = _finalize(
                    {
                        "level": level,
                        "status": "failed" if level == "Workflow" else "passed",
                        "tests_run": 1,
                    }
                )
                (results / f"{level.lower()}.json").write_text(
                    json.dumps(payload),
                    encoding="utf-8",
                )
            with self.assertRaisesRegex(
                ValueError,
                "Workflow test evidence is not a passing result",
            ):
                build_ladder_evidence(
                    scope="protocol",
                    results_dir=results,
                    output=workspace / "ladder.json",
                    environment={},
                )

    def test_ladder_evidence_rejects_tampered_level_claim(self) -> None:
        with test_workspace("verification-evidence-tampered") as workspace:
            results = workspace / "results"
            results.mkdir()
            for level in LEVELS:
                payload = _finalize(
                    {
                        "level": level,
                        "status": "passed",
                        "tests_run": 1,
                    }
                )
                if level == "Integration":
                    payload["tests_run"] = 99
                (results / f"{level.lower()}.json").write_text(
                    json.dumps(payload),
                    encoding="utf-8",
                )
            with self.assertRaisesRegex(
                ValueError,
                "Integration test evidence content digest does not match",
            ):
                build_ladder_evidence(
                    scope="protocol",
                    results_dir=results,
                    output=workspace / "ladder.json",
                    environment={},
                )


if __name__ == "__main__":
    unittest.main()
