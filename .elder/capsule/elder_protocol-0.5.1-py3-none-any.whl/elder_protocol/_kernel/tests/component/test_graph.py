from __future__ import annotations

import copy
import unittest

from elder_protocol.compiler import resolve_skills
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.graph import (
    build_project_graph,
    build_protocol_graph,
    validate_graph,
)
from elder_protocol.io import load_json
from elder_protocol.profiles import resolve_capability_packs
from elder_protocol.protocol import validate_protocol


class GraphComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.data = validate_protocol()

    def test_protocol_graph_regeneration_matches_canonical_file(self) -> None:
        self.assertEqual(
            build_protocol_graph(self.data),
            self.data["protocol-graph"],
        )

    def test_graph_rejects_unknown_edge_endpoint(self) -> None:
        graph = copy.deepcopy(self.data["protocol-graph"])
        graph["edges"][0]["to"] = "missing:node"
        with self.assertRaisesRegex(ProtocolError, "unknown endpoint"):
            validate_graph(graph)

    def test_project_graph_contains_only_selected_capability_packs(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        resolved = resolve_capability_packs(profile["capability_packs"], self.data)
        skills = resolve_skills(profile, self.data, resolved)
        graph = build_project_graph(profile, self.data, skills, resolved)
        node_ids = {node["id"] for node in graph["nodes"]}

        self.assertIn("pack:agentic", node_ids)
        self.assertIn("pack:web-product", node_ids)
        self.assertNotIn("pack:learning", node_ids)
        self.assertNotIn("pack:regulated", node_ids)
        self.assertNotIn("schema:learning-candidate.schema.json", node_ids)


if __name__ == "__main__":
    unittest.main()
