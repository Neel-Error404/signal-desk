from __future__ import annotations

import copy
import unittest
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_contracts import (
    FACTORY_CONTRACT_VERSION,
    validate_adapter_request_data,
    validate_adapter_response_data,
    validate_idempotent_replay,
)


SHA256 = "a" * 64
TIME = "2026-08-07T12:00:00+00:00"


def _cursor(sequence: int, event_id: str) -> dict[str, Any]:
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "stream_id": "project-001-events",
        "generation": 1,
        "sequence": sequence,
        "event_id": event_id,
        "snapshot_sha256": SHA256,
        "issued_at": TIME,
    }


def _command(status: str = "pending") -> dict[str, Any]:
    payload = {"instruction": "Run the bounded verification."}
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "command_id": "command-001",
        "project_id": "project-001",
        "work_item_id": "work-item-001",
        "run_id": "run-001",
        "worker_session_id": "session-001",
        "command_type": "worker.verify",
        "mutability": "mutation",
        "idempotency_key": "command-project-001-run-001-verify",
        "authority_ref": "elder://authority/001",
        "correlation_id": "correlation-001",
        "causation_id": None,
        "attempt": 1,
        "status": status,
        "submitted_at": TIME,
        "expires_at": "2026-08-07T12:05:00+00:00",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _event() -> dict[str, Any]:
    payload = {
        "command_id": "command-001",
        "command_status": "accepted",
    }
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "event_id": "event-001",
        "event_type": "command.accepted",
        "record_kind": "live-projection",
        "authoritative": False,
        "source_event_id": "event-source-001",
        "occurred_at": TIME,
        "recorded_at": TIME,
        "cursor": _cursor(1, "event-source-001"),
        "correlations": {
            "product_id": None,
            "project_id": "project-001",
            "work_item_id": "work-item-001",
            "run_id": "run-001",
            "session_id": "session-001",
        },
        "actor": {"identity_id": "executor-001", "kind": "agent"},
        "source": {
            "plane": "factory-operations",
            "adapter_id": None,
            "source_ref": "journal:project-001:1",
        },
        "correlation_id": "correlation-001",
        "causation_id": "command-001",
        "idempotency_key": "command-project-001-run-001-verify",
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


def _request(
    *,
    request_id: str = "request-001",
    contract_id: str = "worker-adapter",
    operation: str = "send",
    mutability: str = "mutation",
    idempotency_key: str | None = "worker-send-project-001-command-001",
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if payload is None:
        payload = (
            {"cursor": _cursor(1, "event-001")}
            if operation == "observe"
            else {"command": _command()}
        )
    return {
        "version": FACTORY_CONTRACT_VERSION,
        "contract_id": contract_id,
        "operation": operation,
        "request_id": request_id,
        "project_id": "project-001",
        "work_item_id": "work-item-001",
        "run_id": "run-001",
        "session_id": "session-001",
        "submitted_at": TIME,
        "deadline_at": "2026-08-07T12:05:00+00:00",
        "correlation_id": "correlation-001",
        "causation_id": None,
        "mutability": mutability,
        "idempotency_key": idempotency_key,
        "payload_mode": "inline",
        "redaction": {
            "classification": "internal",
            "redacted_fields": [],
        },
        "payload_sha256": canonical_sha256(payload),
        "payload": payload,
        "extensions": {},
    }


class FakeWorkerAdapter:
    def __init__(self, mode: str) -> None:
        self.mode = mode
        self.durable_results: dict[str, dict[str, Any]] = {}
        self.side_effect_count = 0

    @staticmethod
    def _response(
        request: dict[str, Any],
        *,
        disposition: str,
        operation_completed: bool,
        mutation_state: str,
        retry: str,
        result: dict[str, Any] | None = None,
        error: dict[str, Any] | None = None,
        cursor: dict[str, Any] | None = None,
        original_response_sha256: str | None = None,
    ) -> dict[str, Any]:
        result = result or {}
        return {
            "version": FACTORY_CONTRACT_VERSION,
            "contract_id": request["contract_id"],
            "operation": request["operation"],
            "request_id": request["request_id"],
            "request_sha256": canonical_sha256(request),
            "project_id": request["project_id"],
            "responded_at": TIME,
            "disposition": disposition,
            "operation_completed": operation_completed,
            "mutation_state": mutation_state,
            "retry": retry,
            "source_of_truth": "adapter-observation",
            "result_mode": "inline",
            "redaction": {
                "classification": "internal",
                "redacted_fields": [],
            },
            "result_sha256": canonical_sha256(result) if result else None,
            "result": result,
            "error": error,
            "cursor": cursor,
            "original_response_sha256": original_response_sha256,
            "extensions": {},
        }

    def send(self, request: dict[str, Any]) -> dict[str, Any]:
        validate_adapter_request_data(request)
        key = request["idempotency_key"]
        if key in self.durable_results:
            original_entry = self.durable_results[key]
            original = original_entry["response"]
            validate_idempotent_replay(original_entry["request"], request)
            return self._response(
                request,
                disposition="duplicate",
                operation_completed=original["operation_completed"],
                mutation_state=original["mutation_state"],
                retry="never",
                result=copy.deepcopy(original["result"]),
                original_response_sha256=canonical_sha256(original),
            )

        if self.mode == "success":
            self.side_effect_count += 1
            response = self._response(
                request,
                disposition="succeeded",
                operation_completed=True,
                mutation_state="applied",
                retry="never",
                result={
                    "accepted_command": _command("accepted")
                },
            )
        elif self.mode == "rejection":
            response = self._response(
                request,
                disposition="rejected",
                operation_completed=False,
                mutation_state="not-started",
                retry="never",
                error={
                    "code": "invalid-request",
                    "message": "The command is not supported.",
                    "details": {},
                },
            )
        elif self.mode == "timeout":
            response = self._response(
                request,
                disposition="timeout",
                operation_completed=False,
                mutation_state="not-applied",
                retry="same-idempotency-key",
                error={
                    "code": "timeout",
                    "message": "Dispatch did not begin before the deadline.",
                    "details": {},
                },
            )
        elif self.mode == "uncertain":
            self.side_effect_count += 1
            response = self._response(
                request,
                disposition="uncertain",
                operation_completed=False,
                mutation_state="unknown",
                retry="reconcile",
                error={
                    "code": "uncertain-mutation",
                    "message": "Dispatch occurred but no durable result was observed.",
                    "details": {},
                },
            )
        else:
            raise AssertionError(f"Unsupported fake mode: {self.mode}")

        self.durable_results[key] = {
            "request": copy.deepcopy(request),
            "response": copy.deepcopy(response),
        }
        return response

    def observe(self, request: dict[str, Any]) -> dict[str, Any]:
        validate_adapter_request_data(request)
        return self._response(
            request,
            disposition="stale-cursor",
            operation_completed=False,
            mutation_state="not-applicable",
            retry="refresh-cursor",
            error={
                "code": "stale-cursor",
                "message": "The requested cursor predates retained events.",
                "details": {},
            },
            cursor=_cursor(10, "event-010"),
        )


class FactoryContractComponentTests(unittest.TestCase):
    def test_fake_adapter_success_and_duplicate_are_idempotent(self) -> None:
        adapter = FakeWorkerAdapter("success")
        first_request = _request()
        first = adapter.send(first_request)
        validate_adapter_response_data(first, request=first_request)
        self.assertEqual(first["disposition"], "succeeded")

        duplicate_request = _request(request_id="request-002")
        duplicate = adapter.send(duplicate_request)
        validate_adapter_response_data(
            duplicate,
            request=duplicate_request,
            original_request=first_request,
            original_response=first,
        )
        self.assertEqual(duplicate["disposition"], "duplicate")
        self.assertEqual(adapter.side_effect_count, 1)

        drifted_request = _request(request_id="request-003")
        changed_command = _command()
        changed_command["command_id"] = "command-002"
        drifted_request["payload"] = {"command": changed_command}
        drifted_request["payload_sha256"] = canonical_sha256(
            drifted_request["payload"]
        )
        with self.assertRaisesRegex(ProtocolError, "different payload"):
            adapter.send(drifted_request)

    def test_fake_adapter_rejection_is_terminal_and_not_retryable(self) -> None:
        adapter = FakeWorkerAdapter("rejection")
        request = _request()
        response = adapter.send(request)
        validate_adapter_response_data(response, request=request)
        self.assertEqual(response["disposition"], "rejected")
        self.assertEqual(response["retry"], "never")
        self.assertEqual(adapter.side_effect_count, 0)

    def test_fake_adapter_pre_dispatch_timeout_reuses_same_identity(self) -> None:
        adapter = FakeWorkerAdapter("timeout")
        request = _request()
        response = adapter.send(request)
        validate_adapter_response_data(response, request=request)
        self.assertEqual(response["disposition"], "timeout")
        self.assertEqual(response["mutation_state"], "not-applied")
        self.assertEqual(response["retry"], "same-idempotency-key")
        self.assertEqual(adapter.side_effect_count, 0)

    def test_fake_adapter_uncertain_mutation_requires_reconciliation(self) -> None:
        adapter = FakeWorkerAdapter("uncertain")
        request = _request()
        response = adapter.send(request)
        validate_adapter_response_data(response, request=request)
        self.assertEqual(response["disposition"], "uncertain")
        self.assertEqual(response["mutation_state"], "unknown")
        self.assertEqual(response["retry"], "reconcile")
        self.assertEqual(adapter.side_effect_count, 1)

    def test_fake_adapter_stale_cursor_returns_refresh_position(self) -> None:
        adapter = FakeWorkerAdapter("success")
        request = _request(
            operation="observe",
            mutability="read",
            idempotency_key=None,
        )
        response = adapter.observe(request)
        validate_adapter_response_data(response, request=request)
        self.assertEqual(response["disposition"], "stale-cursor")
        self.assertEqual(response["retry"], "refresh-cursor")
        self.assertEqual(response["cursor"]["sequence"], 10)

    def test_governance_and_integration_sources_are_contract_bound(self) -> None:
        governance_request = _request(
            contract_id="governance-adapter",
            operation="authorize",
            mutability="read",
            idempotency_key=None,
            payload={"action": {"resource": "factory", "action": "observe"}},
        )
        governance_response = FakeWorkerAdapter._response(
            governance_request,
            disposition="succeeded",
            operation_completed=True,
            mutation_state="not-applicable",
            retry="never",
            result={
                "authority_result": {
                    "decision": "allowed",
                    "authority_ref": "elder://authority/001",
                }
            },
        )
        governance_response["source_of_truth"] = "governance-record-reference"
        validate_adapter_response_data(
            governance_response,
            request=governance_request,
        )

        integration_request = _request(
            contract_id="integration-adapter",
            operation="publish-projection",
            mutability="mutation",
            idempotency_key="integration-project-001-event-001",
            payload={"event": _event()},
        )
        integration_response = FakeWorkerAdapter._response(
            integration_request,
            disposition="succeeded",
            operation_completed=True,
            mutation_state="applied",
            retry="never",
            result={"delivery_result": {"status": "delivered"}},
        )
        integration_response["source_of_truth"] = "projection-ack"
        validate_adapter_response_data(
            integration_response,
            request=integration_request,
        )


if __name__ == "__main__":
    unittest.main()
