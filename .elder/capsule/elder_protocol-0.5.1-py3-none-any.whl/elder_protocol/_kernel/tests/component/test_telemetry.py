from __future__ import annotations

import copy
import json
import unittest

from elder_protocol.constants import PROTOCOL_DIR
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.telemetry import (
    build_telemetry_report,
    ingest_evaluation_report,
    ingest_factory_trace,
    ingest_workbench_trace,
    load_telemetry_events,
    validate_telemetry_event,
    write_telemetry_events,
)
from tests._support import test_workspace


class TelemetryComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.contract = load_json(PROTOCOL_DIR / "telemetry-contract.json")

    def _workbench_trace(self, workspace) -> tuple[object, list[dict[str, object]]]:
        path = workspace / "workbench.jsonl"
        trace_id = "1" * 32
        root_span_id = "2" * 16
        records = [
            {
                "run_id": "run-1",
                "project_id": "elder-workbench",
                "trace_id": trace_id,
                "span_id": "3" * 16,
                "parent_span_id": root_span_id,
                "sequence": 1,
                "node_id": "wayfinder",
                "label": "Clarify outcomes",
                "status": "running",
                "recorded_at": "2026-08-05T00:00:00+00:00",
            },
            {
                "run_id": "run-1",
                "project_id": "elder-workbench",
                "trace_id": trace_id,
                "span_id": "3" * 16,
                "parent_span_id": root_span_id,
                "sequence": 1,
                "node_id": "wayfinder",
                "label": "Clarify outcomes",
                "status": "complete",
                "elapsed_ms": 12.5,
                "output_keys": ["objective"],
                "recorded_at": "2026-08-05T00:00:01+00:00",
            },
            {
                "run_id": "run-1",
                "project_id": "elder-workbench",
                "trace_id": trace_id,
                "span_id": "4" * 16,
                "parent_span_id": root_span_id,
                "sequence": 2,
                "node_id": "finalize",
                "label": "Assemble blueprint",
                "status": "complete",
                "elapsed_ms": 5.0,
                "output_keys": ["blueprint"],
                "recorded_at": "2026-08-05T00:00:02+00:00",
            },
        ]
        path.write_text(
            "\n".join(json.dumps(record, sort_keys=True) for record in records) + "\n",
            encoding="utf-8",
        )
        return path, records

    def test_workbench_adapter_preserves_native_context_and_reports_budgets(self) -> None:
        with test_workspace("telemetry-workbench") as workspace:
            path, _ = self._workbench_trace(workspace)
            events = ingest_workbench_trace(path, self.contract)
            self.assertEqual(len(events), 3)
            self.assertEqual(
                {event["trace"]["trace_id"] for event in events},
                {"1" * 32},
            )
            self.assertEqual(
                {event["scope"] for event in events},
                {"product", "model"},
            )
            report = build_telemetry_report(events, self.contract)
            self.assertEqual(report["verdict"], "pass")
            self.assertEqual(report["correlation_completeness"], 1.0)
            self.assertFalse(report["can_approve"])
            self.assertFalse(report["can_promote"])

    def test_factory_and_evaluation_adapters_cover_factory_cost_tool_and_outcome(self) -> None:
        with test_workspace("telemetry-adapters") as workspace:
            factory_path = workspace / "factory.jsonl"
            factory_path.write_text(
                json.dumps(
                    {
                        "recorded_at": "2026-08-05T00:00:00+00:00",
                        "event": "artifact-verified",
                        "artifact_sha256": "a" * 64,
                        "status": "passed",
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            evaluation_path = workspace / "evaluation.json"
            evaluation_path.write_text(
                json.dumps(
                    {
                        "evaluation_id": "evaluation-1",
                        "candidate_id": "candidate-1",
                        "dataset_id": "dataset-1",
                        "split": "holdout",
                        "evaluator_id": "independent-evaluator",
                        "executor_id": "executor",
                        "verdict": "pass",
                        "thresholds": {"minimum_pass_rate": 1.0},
                        "metrics": {
                            "pass_rate": 1.0,
                            "mean_score": 1.0,
                            "mean_latency_ms": 20.0,
                            "total_cost_usd": 0.25,
                            "total_tool_calls": 2,
                        },
                        "evaluated_at": "2026-08-05T00:00:01+00:00",
                    }
                ),
                encoding="utf-8",
            )
            factory_events = ingest_factory_trace(factory_path, self.contract)
            evaluation_events = ingest_evaluation_report(
                evaluation_path, self.contract
            )
            self.assertEqual({event["scope"] for event in factory_events}, {"factory"})
            self.assertEqual(
                {event["scope"] for event in evaluation_events},
                {"cost", "tool", "outcome"},
            )
            report = build_telemetry_report(
                factory_events + evaluation_events,
                self.contract,
            )
            self.assertEqual(report["cost"]["total_amount"], 0.25)
            self.assertEqual(report["outcomes"]["met"], 1)

    def test_sensitive_attributes_and_correlation_metric_dimensions_fail_closed(self) -> None:
        with test_workspace("telemetry-privacy") as workspace:
            path, _ = self._workbench_trace(workspace)
            event = ingest_workbench_trace(path, self.contract)[0]

            sensitive = copy.deepcopy(event)
            sensitive["attributes"]["api_key"] = "not-persisted"
            with self.assertRaisesRegex(ProtocolError, "sensitive"):
                validate_telemetry_event(sensitive, self.contract)

            high_cardinality = copy.deepcopy(event)
            high_cardinality["measurements"][0]["dimensions"]["trace_id"] = "1" * 32
            with self.assertRaisesRegex(ProtocolError, "forbidden dimensions"):
                validate_telemetry_event(high_cardinality, self.contract)

    def test_jsonl_round_trip_rejects_duplicate_event_ids(self) -> None:
        with test_workspace("telemetry-round-trip") as workspace:
            path, _ = self._workbench_trace(workspace)
            events = ingest_workbench_trace(path, self.contract)
            output = workspace / "events.jsonl"
            write_telemetry_events(output, events, self.contract)
            self.assertEqual(len(load_telemetry_events(output, self.contract)), 3)
            with self.assertRaisesRegex(ProtocolError, "Duplicate telemetry event id"):
                write_telemetry_events(
                    workspace / "duplicate.jsonl",
                    [events[0], events[0]],
                    self.contract,
                )

    def test_cardinality_overflow_fails_the_advisory_report(self) -> None:
        with test_workspace("telemetry-cardinality") as workspace:
            path, _ = self._workbench_trace(workspace)
            events = ingest_workbench_trace(path, self.contract)
            limited = copy.deepcopy(self.contract)
            limited["metric_policy"]["maximum_cardinality_per_metric"] = 1
            report = build_telemetry_report(events, limited)
            self.assertEqual(report["verdict"], "fail")
            self.assertTrue(report["metric_cardinality"]["overflow_metrics"])
            self.assertFalse(report["can_promote"])


if __name__ == "__main__":
    unittest.main()
