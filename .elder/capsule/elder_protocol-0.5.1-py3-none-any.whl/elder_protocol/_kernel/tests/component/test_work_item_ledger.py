from __future__ import annotations

import copy
import json
import sqlite3
import unittest
from pathlib import Path

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    ProductFactoryRegistry,
    WorkItemLedger,
)
from elder_protocol.io import load_json
from tests._support import tamper_sqlite_store, test_workspace


class WorkItemLedgerComponentTests(unittest.TestCase):
    @staticmethod
    def _profile(project_id: str) -> dict:
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = project_id
        profile["name"] = project_id.replace("-", " ").title()
        return profile

    def _ledger(
        self,
        workspace: Path,
        project_id: str = "product-one",
    ) -> WorkItemLedger:
        repository = workspace / project_id
        repository.mkdir()
        (repository / ".git").mkdir()
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(self._profile(project_id), indent=2) + "\n",
            encoding="utf-8",
        )
        database = workspace / "operations.db"
        FactoryOperationsBootstrap(database).initialize()
        registry = ProductFactoryRegistry(database)
        record = registry.register(
            {
                "version": "1.0.0",
                "project_id": project_id,
                "repository_root": str(repository.resolve()),
                "profile_path": ".elder/project-profile.json",
                "worker_policy": {
                    "adapter_id": "codex",
                    "max_concurrent_workers": 1,
                    "approval_policy": "on-request",
                    "sandbox_mode": "workspace-write",
                    "network_access": False,
                },
                "integration_refs": [
                    {
                        "id": "owner-inbox",
                        "kind": "manual",
                        "reference": "manual:owner-inbox",
                        "enabled": True,
                    }
                ],
            },
            actor_identity_id="founder",
            at="2026-08-08T09:00:00+00:00",
        )
        registry.activate(
            record["product_factory"]["id"],
            expected_version=1,
            actor_identity_id="founder",
            at="2026-08-08T09:01:00+00:00",
        )
        ledger = WorkItemLedger(database)
        ledger.initialize()
        return ledger

    @staticmethod
    def _specification(
        work_item_id: str = "work-item-build-repair",
        *,
        project_id: str = "product-one",
        source_reference: str | None = None,
    ) -> dict:
        return {
            "version": "1.0.0",
            "work_item_id": work_item_id,
            "project_id": project_id,
            "objective": "Repair the failing component build with durable evidence.",
            "scope": ["component build", "regression test"],
            "non_goals": ["production deployment"],
            "priority": "high",
            "owner_identity_id": "founder",
            "acceptance_criteria": [
                "The component build passes.",
                "A regression test proves the fix.",
            ],
            "outcome_ids": ["outcome:governed-workflow"],
            "change_class": "internal-code",
            "evidence_plan": [
                "foundation tests",
                "component tests",
                "independent evaluation",
            ],
            "authority_refs": ["profile:product-one/founder"],
            "dependencies": [],
            "source_links": [
                {
                    "kind": "manual",
                    "reference": source_reference
                    or f"manual:owner-backlog/{work_item_id}",
                    "content_sha256": None,
                }
            ],
        }

    def test_create_and_restart_preserve_canonical_backlog(self) -> None:
        with test_workspace("sf-102-create") as workspace:
            ledger = self._ledger(workspace)
            record = ledger.create(
                self._specification(),
                actor_identity_id="founder",
                change_reason="Owner accepted the initial bounded intent.",
                at="2026-08-08T09:05:00+00:00",
            )
            self.assertEqual(record["work_item"]["status"], "draft")
            self.assertEqual(record["work_item"]["payload"]["stage"], "draft")
            self.assertEqual(record["work_item"]["record_version"], 1)
            self.assertEqual(
                record["current_revision"]["payload"]["revision_number"],
                1,
            )

            reopened = WorkItemLedger(workspace / "operations.db")
            self.assertEqual(reopened.get("work-item-build-repair"), record)
            self.assertEqual(reopened.status()["work_item_count"], 1)
            self.assertEqual(reopened.status()["revision_count"], 1)
            self.assertEqual(reopened.status()["history_count"], 1)

    def test_revision_uses_optimistic_concurrency_and_immutable_history(self) -> None:
        with test_workspace("sf-102-revise") as workspace:
            ledger = self._ledger(workspace)
            original = self._specification()
            ledger.create(
                original,
                actor_identity_id="founder",
                change_reason="Initial intent.",
                at="2026-08-08T09:05:00+00:00",
            )
            revised = copy.deepcopy(original)
            revised["objective"] = (
                "Repair the failing component build and verify package behavior."
            )
            revised["scope"].append("wheel validation")
            record = ledger.update(
                revised,
                expected_version=1,
                actor_identity_id="example-agentic-product-planning-agent",
                change_reason="Add the package-level acceptance boundary.",
                at="2026-08-08T09:10:00+00:00",
            )
            self.assertEqual(record["work_item"]["record_version"], 2)
            self.assertEqual(
                record["current_revision"]["payload"]["revision_number"],
                2,
            )
            revisions = ledger.revisions("work-item-build-repair")
            self.assertEqual(
                [item["entity"]["status"] for item in revisions],
                ["superseded", "current"],
            )
            self.assertEqual(
                [item["operation"] for item in ledger.history(
                    "work-item-build-repair"
                )],
                ["create", "revise"],
            )
            replay = ledger.create(
                original,
                actor_identity_id="founder",
                change_reason="Replay the original create after revision.",
            )
            self.assertEqual(replay, record)

            with self.assertRaisesRegex(ProtocolError, "version conflict"):
                ledger.update(
                    revised,
                    expected_version=1,
                    actor_identity_id="founder",
                    change_reason="Stale writer.",
                )

    def test_exact_create_retry_is_idempotent_but_collisions_fail(self) -> None:
        with test_workspace("sf-102-idempotency") as workspace:
            ledger = self._ledger(workspace)
            specification = self._specification()
            first = ledger.create(
                specification,
                actor_identity_id="founder",
                change_reason="Initial intent.",
                at="2026-08-08T09:05:00+00:00",
            )
            retry = ledger.create(
                specification,
                actor_identity_id="founder",
                change_reason="Retry the accepted request.",
                at="2026-08-08T09:06:00+00:00",
            )
            self.assertEqual(retry, first)
            self.assertEqual(ledger.status()["history_count"], 1)

            collision = copy.deepcopy(specification)
            collision["objective"] = "A different objective under the same identity."
            with self.assertRaisesRegex(ProtocolError, "id collision"):
                ledger.create(
                    collision,
                    actor_identity_id="founder",
                    change_reason="Conflicting request.",
                )

    def test_actor_owner_evidence_and_signal_bypass_fail_closed(self) -> None:
        with test_workspace("sf-102-authority") as workspace:
            ledger = self._ledger(workspace)
            with self.assertRaisesRegex(ProtocolError, "requires actor"):
                ledger.create(
                    self._specification(),
                    actor_identity_id="example-agentic-product-executor",
                    change_reason="Executor cannot originate product intent.",
                )

            invalid_owner = self._specification()
            invalid_owner["owner_identity_id"] = "technical-owner"
            with self.assertRaisesRegex(ProtocolError, "not a bound product-owner"):
                ledger.create(
                    invalid_owner,
                    actor_identity_id="founder",
                    change_reason="Invalid owner.",
                )

            signal_bypass = self._specification()
            signal_bypass["source_links"] = [
                {
                    "kind": "signal",
                    "reference": "signal:signal-github-001",
                    "content_sha256": "a" * 64,
                }
            ]
            with self.assertRaisesRegex(ProtocolError, "create_from_signal"):
                ledger.create(
                    signal_bypass,
                    actor_identity_id="founder",
                    change_reason="Signal conversion must be atomic.",
                )
            self.assertEqual(ledger.status()["work_item_count"], 0)

    def test_dependencies_require_same_project_and_remain_acyclic(self) -> None:
        with test_workspace("sf-102-dependencies") as workspace:
            ledger = self._ledger(workspace)
            first = self._specification("work-item-foundation")
            ledger.create(
                first,
                actor_identity_id="founder",
                change_reason="Create the foundation item.",
            )
            second = self._specification("work-item-dependent")
            second["dependencies"] = [
                {
                    "work_item_id": "work-item-foundation",
                    "relationship": "depends-on",
                }
            ]
            ledger.create(
                second,
                actor_identity_id="founder",
                change_reason="Create a dependent item.",
            )

            cyclic = copy.deepcopy(first)
            cyclic["dependencies"] = [
                {
                    "work_item_id": "work-item-dependent",
                    "relationship": "depends-on",
                }
            ]
            with self.assertRaisesRegex(ProtocolError, "cycle"):
                ledger.update(
                    cyclic,
                    expected_version=1,
                    actor_identity_id="founder",
                    change_reason="This would create a dependency cycle.",
                )

            missing = self._specification("work-item-missing-dependency")
            missing["dependencies"] = [
                {
                    "work_item_id": "work-item-does-not-exist",
                    "relationship": "depends-on",
                }
            ]
            with self.assertRaisesRegex(ProtocolError, "does not exist"):
                ledger.create(
                    missing,
                    actor_identity_id="founder",
                    change_reason="Missing dependency.",
                )

    def test_queries_filter_by_operational_fields(self) -> None:
        with test_workspace("sf-102-queries") as workspace:
            ledger = self._ledger(workspace)
            high = self._specification("work-item-high")
            low = self._specification("work-item-low")
            low["priority"] = "low"
            ledger.create(
                low,
                actor_identity_id="founder",
                change_reason="Low priority item.",
            )
            ledger.create(
                high,
                actor_identity_id="founder",
                change_reason="High priority item.",
            )
            self.assertEqual(
                [
                    item["work_item"]["id"]
                    for item in ledger.list(project_id="product-one")
                ],
                ["work-item-high", "work-item-low"],
            )
            self.assertEqual(
                len(ledger.list(priority="low", status="draft")),
                1,
            )
            self.assertEqual(
                len(ledger.list(owner_identity_id="founder")),
                2,
            )

    def test_tampered_current_row_and_revision_intent_fail_closed(self) -> None:
        with test_workspace("sf-102-integrity") as workspace:
            ledger = self._ledger(workspace)
            ledger.create(
                self._specification(),
                actor_identity_id="founder",
                change_reason="Initial intent.",
            )
            tamper_sqlite_store(
                workspace / "operations.db",
                """
                UPDATE work_items SET priority = 'urgent'
                WHERE id = 'work-item-build-repair'
                """,
            )
            with self.assertRaisesRegex(ProtocolError, "does not match"):
                ledger.status()


if __name__ == "__main__":
    unittest.main()
