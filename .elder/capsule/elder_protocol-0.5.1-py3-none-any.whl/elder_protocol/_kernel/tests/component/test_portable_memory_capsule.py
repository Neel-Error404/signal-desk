from __future__ import annotations

import subprocess
import unittest
from pathlib import Path

from elder_protocol.activation import activate_session
from elder_protocol.build_memory import (
    close_build_memory_session,
    finalize_build_memory_ledger,
    write_build_memory_ledger,
)
from elder_protocol.capsule import (
    _bootstrap_script,
    _launcher_script,
    build_capsule_from_wheel,
    build_portable_capsule,
    install_capsule,
    verify_capsule,
    verify_installed_capsule,
)
from elder_protocol.cli import main
from elder_protocol.compiler import compile_project
from elder_protocol.constants import PORTABLE_MEMORY_ENV_PATH, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, load_json, write_text
from elder_protocol.knowledge import KnowledgeStore
from tests._support import test_workspace


def trusted_memory(memory_id: str = "memory-build-rule") -> dict:
    return {
        "version": "0.5.1",
        "id": memory_id,
        "namespace": "example-agentic-product",
        "kind": "procedural",
        "content": "Run component tests after changing shared CLI parsing.",
        "content_sha256": "0" * 64,
        "source_evidence": ["evidence:test-cli"],
        "confidence": "high",
        "owner": "example-agentic-product-learning-agent",
        "status": "trusted",
        "created_at": "2026-08-01T00:00:00+00:00",
        "review_at": "2099-01-01T00:00:00+00:00",
        "expires_at": "2099-01-01T00:00:00+00:00",
        "supersedes": None,
        "approval_id": "approval-build-rule",
        "approved_by": "founder",
        "approved_at": "2026-08-02T00:00:00+00:00",
    }


class FakeTrustedSemanticMemory:
    def __init__(self) -> None:
        self.synced: list[dict] = []

    def sync_trusted_memories(self, *, project_id: str, records: list[dict]):
        self.synced = records
        return {"indexed": len(records), "unchanged": 0, "removed": 0}

    def recall_trusted(self, *, project_id: str, query: str, limit: int):
        return [
            {
                "id": "mem0-index-id",
                "memory": self.synced[0]["content"],
                "metadata": {"elder_memory_id": self.synced[0]["id"]},
            }
        ]


class FakeCandidateSemanticMemory:
    def __init__(self) -> None:
        self.closed = False

    def remember_evidence(self, *, project_id: str, request_id: str, evidence: list[dict]):
        return [
            {
                "id": "mem0-candidate-id",
                "memory": "Preserve product-owned files when updating the Elder capsule.",
                "metadata": {
                    "project_id": project_id,
                    "request_id": request_id,
                },
            }
        ]

    def close(self) -> None:
        self.closed = True


class PortableMemoryAndCapsuleTests(unittest.TestCase):
    def test_public_capsule_builder_requires_a_clean_git_source(self) -> None:
        with test_workspace("portable-capsule-dirty-source") as workspace:
            source = workspace / "source"
            source.mkdir()
            subprocess.run(
                ["git", "init"],
                cwd=source,
                check=True,
                capture_output=True,
                text=True,
            )
            (source / "untracked.txt").write_text("dirty\n", encoding="utf-8")

            with self.assertRaisesRegex(
                ProtocolError,
                "requires a clean source tree",
            ):
                build_portable_capsule(
                    workspace / "capsule.zip",
                    source_root=source,
                )

    def test_compiler_seeds_portable_memory_outside_generated_ownership(self) -> None:
        with test_workspace("portable-memory-seed") as workspace:
            project = workspace / "project"
            compile_project(
                ROOT / "examples" / "minimal-project-profile.json",
                project,
            )
            ledger = load_json(project / ".elder" / "memory" / "trusted.json")
            ownership = load_json(project / ".elder" / "ownership.json")

            self.assertEqual(ledger["project_id"], "example-agentic-product")
            self.assertEqual(ledger["records"], [])
            self.assertNotIn(
                ".elder/memory/trusted.json",
                ownership["generated"],
            )

    def test_activation_loads_and_semantically_ranks_trusted_build_memory(self) -> None:
        with test_workspace("portable-memory-activation") as workspace:
            project = workspace / "project"
            compile_project(
                ROOT / "examples" / "minimal-project-profile.json",
                project,
            )
            record = trusted_memory()
            write_build_memory_ledger(
                project,
                "example-agentic-product",
                [record],
            )
            semantic = FakeTrustedSemanticMemory()

            packet = activate_session(
                project,
                "Change shared CLI parsing and verify component behavior",
                memory_live=True,
                semantic_memory=semantic,
            )

            self.assertTrue(packet["build_memory"]["required"])
            self.assertEqual(packet["build_memory"]["mode"], "mem0-semantic")
            self.assertEqual(packet["build_memory"]["count"], 1)
            self.assertEqual(
                packet["build_memory"]["records"][0]["id"],
                "memory-build-rule",
            )
            self.assertEqual(len(semantic.synced), 1)

    def test_activation_fails_when_portable_memory_ledger_is_missing(self) -> None:
        with test_workspace("portable-memory-missing") as workspace:
            project = workspace / "project"
            compile_project(
                ROOT / "examples" / "minimal-project-profile.json",
                project,
            )
            (project / ".elder" / "memory" / "trusted.json").unlink()

            with self.assertRaisesRegex(
                ProtocolError,
                "Required activation source does not exist",
            ):
                activate_session(project, "Continue governed product work")

    def test_memory_promotion_updates_portable_ledger(self) -> None:
        with test_workspace("portable-memory-promotion") as workspace:
            project = workspace / "project"
            compile_project(
                ROOT / "examples" / "minimal-project-profile.json",
                project,
            )
            store_path = project / ".elder" / "runtime" / "knowledge.db"
            store = KnowledgeStore(store_path)
            store.initialize()
            candidate = trusted_memory()
            candidate.update(
                {
                    "status": "candidate",
                    "approval_id": None,
                    "approved_by": None,
                    "approved_at": None,
                }
            )
            store.propose_memory(candidate, subject_role="learning-agent")
            approval = {
                "version": "0.5.1",
                "id": "approval-build-rule",
                "memory_id": candidate["id"],
                "action": "promote",
                "approved_by": "founder",
                "subject_role": "human-owner",
                "evidence": ["review:build-rule"],
                "approved_at": "2026-08-02T00:00:00+00:00",
            }
            approval_path = workspace / "approval.json"
            approval_path.write_text(json_text(approval), encoding="utf-8")

            exit_code = main(
                [
                    "memory",
                    "promote",
                    "--store",
                    str(store_path),
                    "--memory-id",
                    candidate["id"],
                    "--approval",
                    str(approval_path),
                ]
            )

            self.assertEqual(exit_code, 0)
            ledger = load_json(project / ".elder" / "memory" / "trusted.json")
            self.assertEqual(ledger["records"][0]["status"], "trusted")
            self.assertEqual(
                ledger,
                finalize_build_memory_ledger(
                    "example-agentic-product",
                    ledger["records"],
                ),
            )

    def test_session_close_binds_activation_and_proposes_candidate_memory(self) -> None:
        with test_workspace("portable-memory-close") as workspace:
            project = workspace / "project"
            compile_project(
                ROOT / "examples" / "minimal-project-profile.json",
                project,
            )
            activation_path = workspace / "activation.json"
            activation = activate_session(
                project,
                "Update the portable capsule safely",
            )
            write_text(activation_path, json_text(activation))
            evidence = workspace / "component-results.txt"
            evidence.write_text(
                "Capsule updates preserved product-owned files and passed component tests.\n",
                encoding="utf-8",
            )
            semantic = FakeCandidateSemanticMemory()

            report = close_build_memory_session(
                project_root=project,
                activation_path=activation_path,
                evidence=[("test-result", evidence)],
                semantic_memory=semantic,
            )

            self.assertEqual(report["status"], "candidate-memory-proposed")
            self.assertEqual(report["candidate_count"], 1)
            self.assertTrue(semantic.closed)
            store = KnowledgeStore(project / ".elder" / "runtime" / "knowledge.db")
            candidates = store.query_memory(
                "example-agentic-product",
                "preserve product owned files",
                statuses=["candidate"],
            )
            self.assertEqual(candidates["count"], 1)

    def test_capsule_build_install_verify_and_tamper_detection(self) -> None:
        with test_workspace("portable-capsule") as workspace:
            wheel = workspace / "elder_protocol-0.5.1-py3-none-any.whl"
            wheel.write_bytes(b"test-wheel")
            archive = workspace / "elder-capsule.zip"
            report = build_capsule_from_wheel(
                wheel,
                archive,
                source_commit="a" * 40,
            )

            manifest = verify_capsule(archive)
            self.assertEqual(report.sha256, report.sha256.lower())
            self.assertEqual(manifest["source_commit"], "a" * 40)

            project = workspace / "project"
            installed = install_capsule(archive, project)
            self.assertEqual(
                installed["protocol_version"],
                "0.5.1",
            )
            self.assertTrue((project / "elder.ps1").is_file())
            verify_installed_capsule(project)
            launcher = _launcher_script()
            bootstrap_end = launcher.index(
                '$Python = Join-Path $ProjectRoot ".elder\\runtime\\tooling\\Scripts\\python.exe"'
            )
            self.assertNotIn("$LASTEXITCODE", launcher[:bootstrap_end])
            bootstrap = _bootstrap_script(wheel.name)
            self.assertIn("$env:ELDER_BOOTSTRAP_PYTHON", bootstrap)
            self.assertIn("Get-Command python -All", bootstrap)
            self.assertIn(
                'Join-Path $env:LOCALAPPDATA "Programs\\Python"',
                bootstrap,
            )
            self.assertIn(
                "sys.exit(0 if sys.version_info >= (3, 11) else 3)",
                bootstrap,
            )
            self.assertNotIn("assert sys.version_info", bootstrap)
            self.assertIn("$ExplicitPythonRequested", bootstrap)
            self.assertIn(
                "ELDER_BOOTSTRAP_PYTHON does not identify a usable Python 3.11+",
                bootstrap,
            )
            self.assertIn(
                "Test-Path -LiteralPath $Candidate.Executable -PathType Leaf",
                bootstrap,
            )
            self.assertIn("$ProbeExitCode = $LASTEXITCODE", bootstrap)
            self.assertIn("} catch {\n            continue", bootstrap)
            self.assertIn(
                "& $BasePython @BasePythonArgs -m venv --clear $RuntimeRoot",
                bootstrap,
            )
            self.assertIn("No usable Python with the venv module was found", bootstrap)
            self.assertNotIn("\n    py -m venv", bootstrap)
            capsule_readme = (
                project / ".elder/capsule/README.md"
            ).read_text(encoding="utf-8")
            start_prompt = (
                project / ".elder/capsule/START_PROJECT_PROMPT.md"
            ).read_text(encoding="utf-8")
            self.assertIn(PORTABLE_MEMORY_ENV_PATH, capsule_readme)
            self.assertIn(
                f"--env-file {PORTABLE_MEMORY_ENV_PATH}",
                start_prompt,
            )
            self.assertNotIn("--env-file .env", start_prompt)
            self.assertNotIn("Create `.env` from", start_prompt)

            product_file = project / "src" / "product.py"
            product_file.parent.mkdir(parents=True)
            product_file.write_text("PRODUCT = True\n", encoding="utf-8")
            install_capsule(archive, project)
            self.assertEqual(
                product_file.read_text(encoding="utf-8"),
                "PRODUCT = True\n",
            )

            replacement_wheel = (
                workspace / "elder_protocol-0.5.1-1-py3-none-any.whl"
            )
            replacement_wheel.write_bytes(b"replacement-wheel")
            replacement_archive = workspace / "elder-capsule-replacement.zip"
            replacement = build_capsule_from_wheel(
                replacement_wheel,
                replacement_archive,
                source_commit="c" * 40,
            )
            install_capsule(replacement_archive, project)
            self.assertFalse((project / Path(manifest["wheel"])).exists())
            self.assertTrue(
                (
                    project
                    / ".elder"
                    / "capsule"
                    / replacement_wheel.name
                ).is_file()
            )
            self.assertEqual(
                product_file.read_text(encoding="utf-8"),
                "PRODUCT = True\n",
            )
            self.assertEqual(replacement.source_commit, "c" * 40)

            (project / "elder.ps1").write_text("tampered\n", encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "changed"):
                verify_installed_capsule(project)
            with self.assertRaisesRegex(ProtocolError, "changed"):
                install_capsule(archive, project)
            install_capsule(archive, project, force=True)
            verify_installed_capsule(project)
            self.assertEqual(
                product_file.read_text(encoding="utf-8"),
                "PRODUCT = True\n",
            )


if __name__ == "__main__":
    unittest.main()
