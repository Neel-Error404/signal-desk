from __future__ import annotations

import copy
import json
import shutil
import sqlite3
import unittest
from contextlib import closing
from datetime import UTC, datetime, timedelta

from elder_protocol.errors import MutationConflictError, ProtocolError
from elder_protocol.factory_operations.multi_product_boundary import (
    MultiProductBoundary,
    ProductScopedCache,
    multi_product_content_sha256,
    product_component_snapshot,
    verify_product_backup,
)
from tests._sf605_support import (
    OPERATOR_A,
    OWNER_A,
    OWNER_B,
    WORKER_A,
    build_boundary,
    build_policy,
)
from tests._support import test_workspace


class SF605MultiProductBoundaryComponentTests(unittest.TestCase):
    def test_cross_product_read_and_mutation_are_denied(self) -> None:
        with test_workspace("sf605-component-auth") as workspace:
            boundary = build_boundary(workspace)
            with self.assertRaisesRegex(ProtocolError, "authorization failed"):
                boundary.status(
                    principal=OWNER_A,
                    tenant_id="tenant-b",
                    product_id="product-b",
                )
            with self.assertRaisesRegex(ProtocolError, "authorization failed"):
                boundary.reserve_quota(
                    principal=OWNER_A,
                    tenant_id="tenant-b",
                    product_id="product-b",
                    resource="storage-bytes",
                    amount=1,
                    reservation_id="cross-product",
                )

    def test_storage_partitions_are_distinct_and_paths_are_contained(self) -> None:
        with test_workspace("sf605-component-storage") as workspace:
            boundary = build_boundary(workspace)
            first = boundary.partition(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            second = boundary.partition(
                principal=OWNER_B,
                tenant_id="tenant-b",
                product_id="product-b",
            )
            self.assertNotEqual(first, second)
            target = boundary.storage_path(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                relative_path="artifacts/result.json",
            )
            self.assertTrue(target.is_relative_to(first))
            with self.assertRaisesRegex(ProtocolError, "contained relative"):
                boundary.storage_path(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    relative_path="../product-b/result.json",
                )

    def test_partition_marker_prevents_alias_or_operator_reuse(self) -> None:
        with test_workspace("sf605-component-marker") as workspace:
            boundary = build_boundary(workspace)
            partition = boundary.partition(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            marker = partition / ".elder-product-boundary.json"
            document = json.loads(marker.read_text(encoding="utf-8"))
            document["scope"]["product_id"] = "product-b"
            marker.write_text(json.dumps(document), encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "marker"):
                boundary.partition(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )

    def test_quota_is_bounded_per_product_and_release_reopens_capacity(
        self,
    ) -> None:
        with test_workspace("sf605-component-quota") as workspace:
            boundary = build_boundary(
                workspace,
                policy=build_policy(storage_bytes=5),
            )
            reserved = boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=5,
                reservation_id="storage-a",
            )
            self.assertEqual(reserved["status"], "active")
            with self.assertRaisesRegex(ProtocolError, "would be exceeded"):
                boundary.reserve_quota(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    resource="storage-bytes",
                    amount=1,
                    reservation_id="storage-b",
                )
            boundary.release_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                reservation_id="storage-a",
            )
            boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="storage-b",
            )

    def test_reservation_identity_reuse_with_changed_content_fails(self) -> None:
        with test_workspace("sf605-component-reservation-id") as workspace:
            boundary = build_boundary(workspace)
            boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="same-id",
            )
            with self.assertRaises(MutationConflictError):
                boundary.reserve_quota(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    resource="storage-bytes",
                    amount=2,
                    reservation_id="same-id",
                )

    def test_exact_reservation_and_backup_identities_are_idempotent(self) -> None:
        with test_workspace("sf605-component-idempotency") as workspace:
            boundary = build_boundary(workspace)
            first = boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="same-reservation",
            )
            second = boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="same-reservation",
            )
            self.assertEqual(first, second)
            backup = boundary.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="same-backup",
                components={},
            )
            self.assertEqual(
                boundary.create_backup(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    backup_id="same-backup",
                    components={},
                ),
                backup,
            )

    def test_active_worker_capacity_cannot_be_reserved_generically(self) -> None:
        with test_workspace("sf605-component-worker-quota") as workspace:
            boundary = build_boundary(workspace)
            with self.assertRaisesRegex(ProtocolError, "binding"):
                boundary.reserve_quota(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    resource="active-workers",
                    amount=1,
                    reservation_id="not-allowed",
                )

    def test_worker_must_be_released_before_cross_product_reuse(self) -> None:
        with test_workspace("sf605-component-worker") as workspace:
            boundary = build_boundary(workspace)
            first = boundary.bind_worker(
                principal=WORKER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                worker_id="worker-shared",
                ttl_seconds=60,
            )
            with self.assertRaisesRegex(ProtocolError, "already bound"):
                boundary.bind_worker(
                    principal=OWNER_B,
                    tenant_id="tenant-b",
                    product_id="product-b",
                    worker_id="worker-shared",
                    ttl_seconds=60,
                )
            boundary.release_worker(principal=WORKER_A, binding=first)
            second = boundary.bind_worker(
                principal=OWNER_B,
                tenant_id="tenant-b",
                product_id="product-b",
                worker_id="worker-shared",
                ttl_seconds=60,
            )
            self.assertEqual(second["generation"], first["generation"] + 1)
            with self.assertRaisesRegex(ProtocolError, "not active"):
                boundary.validate_worker_binding(
                    first,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )

    def test_expired_worker_requires_recovery_and_can_be_rebound(self) -> None:
        with test_workspace("sf605-component-worker-expiry") as workspace:
            clock = [datetime(2026, 8, 15, 13, 0, tzinfo=UTC)]
            boundary = MultiProductBoundary(
                workspace / "multi-product.db",
                storage_root=workspace / "products",
                policy=build_policy(),
                now=lambda: clock[0],
            )
            first = boundary.bind_worker(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                worker_id="worker-expired",
                ttl_seconds=1,
            )
            clock[0] += timedelta(seconds=2)
            second = boundary.bind_worker(
                principal=OWNER_B,
                tenant_id="tenant-b",
                product_id="product-b",
                worker_id="worker-expired",
                ttl_seconds=60,
            )
            self.assertEqual(second["generation"], first["generation"] + 1)
            product_a = boundary.status(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            self.assertEqual(product_a["workers"]["recovery-required"], 1)

    def test_expired_worker_frees_capacity_for_a_different_worker(self) -> None:
        with test_workspace("sf605-component-worker-expired-capacity") as workspace:
            clock = [datetime(2026, 8, 15, 13, 0, tzinfo=UTC)]
            boundary = MultiProductBoundary(
                workspace / "multi-product.db",
                storage_root=workspace / "products",
                policy=build_policy(active_workers=1),
                now=lambda: clock[0],
            )
            boundary.bind_worker(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                worker_id="worker-old",
                ttl_seconds=1,
            )
            clock[0] += timedelta(seconds=2)
            before = boundary.status(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            self.assertEqual(before["workers"], {"expired": 1})
            boundary.bind_worker(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                worker_id="worker-new",
                ttl_seconds=60,
            )
            after = boundary.status(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            self.assertEqual(after["workers"]["active"], 1)
            self.assertEqual(after["workers"]["recovery-required"], 1)

    def test_forged_binding_scope_cannot_validate_release_or_read_cache(
        self,
    ) -> None:
        with test_workspace("sf605-component-binding-forgery") as workspace:
            boundary = build_boundary(workspace)
            cache = ProductScopedCache(boundary)
            binding = boundary.bind_worker(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                worker_id="worker-forged",
                ttl_seconds=60,
            )
            cache.set(binding, key="context", value={"value": "a"})
            forged = copy.deepcopy(binding)
            forged["tenant_id"] = "tenant-b"
            forged["product_id"] = "product-b"
            with self.assertRaisesRegex(ProtocolError, "issuance"):
                boundary.validate_worker_binding(
                    forged,
                    tenant_id="tenant-b",
                    product_id="product-b",
                )
            with self.assertRaisesRegex(ProtocolError, "issuance"):
                boundary.release_worker(
                    principal=OWNER_B,
                    binding=forged,
                )
            with self.assertRaisesRegex(ProtocolError, "issuance"):
                cache.get(forged, key="context")
            self.assertEqual(
                boundary.validate_worker_binding(
                    binding,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )["status"],
                "active",
            )

    def test_cache_does_not_leak_when_worker_is_reused(self) -> None:
        with test_workspace("sf605-component-cache") as workspace:
            boundary = build_boundary(workspace)
            cache = ProductScopedCache(boundary)
            first = boundary.bind_worker(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                worker_id="worker-cache",
                ttl_seconds=60,
            )
            cache.set(first, key="context", value={"value": "product-a"})
            self.assertEqual(
                cache.get(first, key="context"),
                {"value": "product-a"},
            )
            boundary.release_worker(principal=OWNER_A, binding=first)
            second = boundary.bind_worker(
                principal=OWNER_B,
                tenant_id="tenant-b",
                product_id="product-b",
                worker_id="worker-cache",
                ttl_seconds=60,
            )
            self.assertIsNone(cache.get(second, key="context"))
            with self.assertRaisesRegex(ProtocolError, "not active"):
                cache.get(first, key="context")

    def test_audit_export_contains_only_one_product_and_replays(self) -> None:
        with test_workspace("sf605-component-audit") as workspace:
            boundary = build_boundary(workspace)
            boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="a",
            )
            boundary.reserve_quota(
                principal=OWNER_B,
                tenant_id="tenant-b",
                product_id="product-b",
                resource="storage-bytes",
                amount=1,
                reservation_id="b",
            )
            exported = boundary.export_audit(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                export_id="export-a",
            )
            self.assertGreaterEqual(exported["record_count"], 2)
            self.assertTrue(
                all(
                    record["product_id"] == "product-a"
                    for record in exported["records"]
                )
            )
            self.assertNotIn("product-b", json.dumps(exported))

    def test_audit_mutation_and_truncation_are_detected(self) -> None:
        with test_workspace("sf605-component-audit-tamper") as workspace:
            boundary = build_boundary(workspace)
            boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="tamper",
            )
            with closing(sqlite3.connect(boundary.path)) as connection:
                with self.assertRaises(sqlite3.IntegrityError):
                    connection.execute(
                        "UPDATE multi_product_audit SET event_type = 'x'"
                    )
            with closing(sqlite3.connect(boundary.path)) as connection:
                connection.execute(
                    "DROP TRIGGER multi_product_audit_no_delete"
                )
                connection.execute(
                    "DELETE FROM multi_product_audit WHERE sequence = 1"
                )
                connection.commit()
            with self.assertRaisesRegex(ProtocolError, "integrity"):
                boundary.replay(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )

    def test_backup_binds_components_and_rejects_tampering(self) -> None:
        with test_workspace("sf605-component-backup") as workspace:
            boundary = build_boundary(workspace)
            manifest = boundary.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="backup-a",
                components={
                    "workspace": product_component_snapshot(
                        tenant_id="tenant-a",
                        product_id="product-a",
                        project_id="project-a",
                        payload={"workspace_id": "workspace-a"},
                    )
                },
            )
            verified = verify_product_backup(
                manifest,
                policy_sha256=boundary.policy_sha256,
                tenant_id="tenant-a",
                product_id="product-a",
                project_id="project-a",
                quotas=boundary.policy["products"][0]["quotas"],
            )
            self.assertEqual(verified, manifest)
            changed = copy.deepcopy(manifest)
            changed["components"]["workspace"]["payload"]["workspace_id"] = "x"
            with self.assertRaisesRegex(ProtocolError, "backup digest"):
                verify_product_backup(
                    changed,
                    policy_sha256=boundary.policy_sha256,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    project_id="project-a",
                    quotas=boundary.policy["products"][0]["quotas"],
                )

    def test_rehashed_forged_backup_state_is_rejected_before_restore(
        self,
    ) -> None:
        with test_workspace("sf605-component-forged-backup") as workspace:
            source = build_boundary(workspace / "source")
            source.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="source-quota",
            )
            manifest = source.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="forged-state",
                components={},
            )
            backup_path = (
                source.partition(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )
                / "backups"
                / "forged-state.json"
            )
            forged = copy.deepcopy(manifest)
            quota = forged["state"]["quota_reservations"][0]
            quota["amount"] = 1_000_000
            quota["content_sha256"] = multi_product_content_sha256(
                {
                    key: value
                    for key, value in quota.items()
                    if key != "content_sha256"
                }
            )
            forged["content_sha256"] = multi_product_content_sha256(
                {
                    key: value
                    for key, value in forged.items()
                    if key != "content_sha256"
                }
            )
            target = build_boundary(workspace / "target")
            backup_path.write_text(
                json.dumps(forged, sort_keys=True, separators=(",", ":")),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ProtocolError, "quota exceeds"):
                target.restore_backup(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    backup_path=backup_path,
                    source_store_path=source.path,
                )
            status = target.status(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            self.assertEqual(status["audit_record_count"], 0)
            self.assertEqual(status["workers"], {})

            broken_chain = copy.deepcopy(manifest)
            broken_chain["state"]["audit"][0]["previous_sha256"] = "f" * 64
            broken_chain["state"]["audit"][0][
                "event_sha256"
            ] = multi_product_content_sha256(
                {
                    key: value
                    for key, value in broken_chain["state"]["audit"][0].items()
                    if key != "event_sha256"
                }
            )
            broken_chain["content_sha256"] = multi_product_content_sha256(
                {
                    key: value
                    for key, value in broken_chain.items()
                    if key != "content_sha256"
                }
            )
            backup_path.write_text(
                json.dumps(
                    broken_chain,
                    sort_keys=True,
                    separators=(",", ":"),
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ProtocolError, "chain"):
                target.restore_backup(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    backup_path=backup_path,
                    source_store_path=source.path,
                )

            wrong_type = copy.deepcopy(manifest)
            wrong_type["state"]["audit"][0]["sequence"] = True
            wrong_type["content_sha256"] = multi_product_content_sha256(
                {
                    key: value
                    for key, value in wrong_type.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "positive integer"):
                verify_product_backup(
                    wrong_type,
                    policy_sha256=source.policy_sha256,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    project_id="project-a",
                    quotas=source.policy["products"][0]["quotas"],
                )

            empty_history = copy.deepcopy(manifest)
            empty_history["state"]["audit"] = []
            empty_history["content_sha256"] = multi_product_content_sha256(
                {
                    key: value
                    for key, value in empty_history.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "must not be empty"):
                verify_product_backup(
                    empty_history,
                    policy_sha256=source.policy_sha256,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    project_id="project-a",
                    quotas=source.policy["products"][0]["quotas"],
                )

            list_payload = copy.deepcopy(manifest)
            list_payload["state"]["audit"][0]["payload"] = []
            list_payload["content_sha256"] = multi_product_content_sha256(
                {
                    key: value
                    for key, value in list_payload.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "must be an object"):
                verify_product_backup(
                    list_payload,
                    policy_sha256=source.policy_sha256,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    project_id="project-a",
                    quotas=source.policy["products"][0]["quotas"],
                )

    def test_cross_product_component_is_rejected_before_backup(self) -> None:
        with test_workspace("sf605-component-backup-cross") as workspace:
            boundary = build_boundary(workspace)
            with self.assertRaisesRegex(ProtocolError, "crosses"):
                boundary.create_backup(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    backup_id="backup-a",
                    components={
                        "workspace": product_component_snapshot(
                            tenant_id="tenant-b",
                            product_id="product-b",
                            project_id="project-b",
                            payload={"workspace_id": "workspace-b"},
                        )
                    },
                )

    def test_restore_rejects_wrong_product_and_nonempty_target(self) -> None:
        with test_workspace("sf605-component-restore-errors") as workspace:
            source = build_boundary(workspace / "source")
            source.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="backup-a",
                components={},
            )
            backup_path = (
                source.partition(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )
                / "backups"
                / "backup-a.json"
            )
            target = build_boundary(workspace / "target")
            with self.assertRaisesRegex(ProtocolError, "partition"):
                target.restore_backup(
                    principal=OWNER_B,
                    tenant_id="tenant-b",
                    product_id="product-b",
                    backup_path=backup_path,
                    source_store_path=source.path,
                )
            target.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="existing",
            )
            with self.assertRaisesRegex(ProtocolError, "empty target"):
                target.restore_backup(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    backup_path=backup_path,
                    source_store_path=source.path,
                )

    def test_restore_marks_active_workers_recovery_required(self) -> None:
        with test_workspace("sf605-component-restore-worker") as workspace:
            source = build_boundary(workspace / "source")
            binding = source.bind_worker(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                worker_id="worker-recover",
                ttl_seconds=60,
            )
            source.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="backup-active-worker",
                components={},
            )
            backup_path = (
                source.partition(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )
                / "backups"
                / "backup-active-worker.json"
            )
            target = build_boundary(workspace / "target")
            result = target.restore_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_path=backup_path,
                source_store_path=source.path,
            )
            self.assertEqual(result["recovery_required_workers"], 1)
            with self.assertRaisesRegex(ProtocolError, "not active"):
                target.validate_worker_binding(
                    binding,
                    tenant_id="tenant-a",
                    product_id="product-a",
                )
            status = target.status(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            self.assertEqual(status["workers"]["recovery-required"], 1)

    def test_restart_replays_same_product_state(self) -> None:
        with test_workspace("sf605-component-restart") as workspace:
            policy = build_policy()
            boundary = build_boundary(workspace, policy=policy)
            boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=3,
                reservation_id="restart",
            )
            expected = boundary.status(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            restarted = MultiProductBoundary(
                boundary.path,
                storage_root=boundary.storage_root,
                policy=policy,
                now=boundary._now,
            )
            self.assertEqual(
                restarted.status(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                ),
                expected,
            )

    def test_operator_grant_is_product_scoped(self) -> None:
        with test_workspace("sf605-component-operator") as workspace:
            boundary = build_boundary(workspace)
            boundary.status(
                principal=OPERATOR_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            with self.assertRaisesRegex(ProtocolError, "authorization failed"):
                boundary.status(
                    principal=OPERATOR_A,
                    tenant_id="tenant-b",
                    product_id="product-b",
                )

    def test_same_event_identity_is_independent_per_product(self) -> None:
        with test_workspace("sf605-component-event-scope") as workspace:
            boundary = build_boundary(workspace)
            boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="shared-id",
            )
            boundary.reserve_quota(
                principal=OWNER_B,
                tenant_id="tenant-b",
                product_id="product-b",
                resource="storage-bytes",
                amount=1,
                reservation_id="shared-id",
            )
            first = boundary.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="shared-backup",
                components={},
            )
            second = boundary.create_backup(
                principal=OWNER_B,
                tenant_id="tenant-b",
                product_id="product-b",
                backup_id="shared-backup",
                components={},
            )
            self.assertNotEqual(
                first["content_sha256"],
                second["content_sha256"],
            )

    def test_audit_checkpoints_are_append_only(self) -> None:
        with test_workspace("sf605-component-checkpoint-immutable") as workspace:
            boundary = build_boundary(workspace)
            boundary.reserve_quota(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                resource="storage-bytes",
                amount=1,
                reservation_id="checkpoint",
            )
            with closing(sqlite3.connect(boundary.path)) as connection:
                with self.assertRaises(sqlite3.IntegrityError):
                    connection.execute(
                        """
                        UPDATE multi_product_audit_checkpoints
                        SET tip_sha256 = ?
                        """,
                        ("f" * 64,),
                    )
                connection.rollback()
                with self.assertRaises(sqlite3.IntegrityError):
                    connection.execute(
                        "DELETE FROM multi_product_audit_checkpoints"
                    )

    def test_backup_catalog_is_append_only(self) -> None:
        with test_workspace("sf605-component-catalog-immutable") as workspace:
            boundary = build_boundary(workspace)
            boundary.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="catalog",
                components={},
            )
            with closing(sqlite3.connect(boundary.path)) as connection:
                with self.assertRaises(sqlite3.IntegrityError):
                    connection.execute(
                        """
                        UPDATE multi_product_backup_catalog
                        SET manifest_sha256 = ?
                        """,
                        ("f" * 64,),
                    )
                connection.rollback()
                with self.assertRaises(sqlite3.IntegrityError):
                    connection.execute(
                        "DELETE FROM multi_product_backup_catalog"
                    )

    def test_registered_backup_rejects_copy_outside_source_storage_root(
        self,
    ) -> None:
        with test_workspace("sf605-component-backup-path-binding") as workspace:
            source = build_boundary(workspace / "source")
            source.create_backup(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
                backup_id="physical-source",
                components={},
            )
            source_partition = source.partition(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            copied_partition = workspace / "copied" / source_partition.name
            (copied_partition / "backups").mkdir(parents=True)
            shutil.copy2(
                source_partition / ".elder-product-boundary.json",
                copied_partition / ".elder-product-boundary.json",
            )
            copied_backup = copied_partition / "backups" / "physical-source.json"
            shutil.copy2(
                source_partition / "backups" / "physical-source.json",
                copied_backup,
            )
            target = build_boundary(workspace / "target")
            with self.assertRaisesRegex(ProtocolError, "trusted source store"):
                target.restore_backup(
                    principal=OWNER_A,
                    tenant_id="tenant-a",
                    product_id="product-a",
                    backup_path=copied_backup,
                    source_store_path=source.path,
                )
            status = target.status(
                principal=OWNER_A,
                tenant_id="tenant-a",
                product_id="product-a",
            )
            self.assertEqual(status["audit_record_count"], 0)


if __name__ == "__main__":
    unittest.main()
