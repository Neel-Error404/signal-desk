from __future__ import annotations

import copy
import json
import sqlite3
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    FactoryOperationsBootstrap,
    ProductFactoryRegistry,
    SignalIntake,
)
from elder_protocol.io import load_json
from tests._support import tamper_sqlite_store, test_workspace


class SignalIntakeComponentTests(unittest.TestCase):
    @staticmethod
    def _profile(project_id: str) -> dict:
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = project_id
        profile["name"] = project_id.replace("-", " ").title()
        return profile

    def _operations(
        self,
        workspace: Path,
        *,
        project_id: str = "product-one",
        active: bool = True,
    ) -> tuple[ProductFactoryRegistry, SignalIntake]:
        repository = workspace / project_id
        repository.mkdir()
        (repository / ".git").mkdir()
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(self._profile(project_id), indent=2) + "\n",
            encoding="utf-8",
        )
        database = workspace / "operations.db"
        FactoryOperationsBootstrap(database).initialize()
        registry = ProductFactoryRegistry(database)
        record = registry.register(
            {
                "version": "1.0.0",
                "project_id": project_id,
                "repository_root": str(repository.resolve()),
                "profile_path": ".elder/project-profile.json",
                "worker_policy": {
                    "adapter_id": "codex",
                    "max_concurrent_workers": 1,
                    "approval_policy": "on-request",
                    "sandbox_mode": "workspace-write",
                    "network_access": False,
                },
                "integration_refs": [
                    {
                        "id": "owner-inbox",
                        "kind": "manual",
                        "reference": "manual:owner-inbox",
                        "enabled": True,
                    },
                    {
                        "id": "github-issues",
                        "kind": "github",
                        "reference": "github:product-one/issues",
                        "enabled": True,
                    },
                    {
                        "id": "linear-issues",
                        "kind": "linear",
                        "reference": "linear:product-one/issues",
                        "enabled": False,
                    },
                ],
            },
            actor_identity_id="founder",
            at="2026-08-08T07:00:00+00:00",
        )
        if active:
            registry.activate(
                record["product_factory"]["id"],
                expected_version=1,
                actor_identity_id="founder",
                at="2026-08-08T07:01:00+00:00",
            )
        intake = SignalIntake(database)
        intake.initialize()
        return registry, intake

    @staticmethod
    def _envelope(
        *,
        signal_id: str = "signal-github-001",
        source: str = "github",
        integration_id: str = "github-issues",
        source_event_id: str = "github-event-001",
        source_sequence: int | None = 1,
        idempotency_key: str = "github-event-001-ingress",
        title: str = "Repair the failing build",
    ) -> dict:
        normalized = {
            "type": "bug-report",
            "title": title,
            "description": "The component build fails on the current revision.",
            "priority": "high",
            "labels": ["build", "regression"],
        }
        return {
            "version": "1.0.0",
            "signal_id": signal_id,
            "project_id": "product-one",
            "integration_id": integration_id,
            "source": source,
            "source_reference": f"{source}:product-one/{source_event_id}",
            "source_event_id": source_event_id,
            "source_sequence": source_sequence,
            "idempotency_key": idempotency_key,
            "occurred_at": "2026-08-08T08:00:00+00:00",
            "authentication": {
                "status": "verified",
                "method": "adapter-signature",
                "principal_ref": f"{source}:sender-001",
                "evidence_ref": f"evidence:{source}:{source_event_id}",
                "verified_at": "2026-08-08T08:00:01+00:00",
            },
            "normalized": normalized,
            "payload_sha256": canonical_sha256(normalized),
        }

    def test_accepted_signal_survives_restart_with_immutable_history(self) -> None:
        with test_workspace("sf-101-accepted") as workspace:
            _, intake = self._operations(workspace)
            record = intake.ingest(
                self._envelope(),
                actor_identity_id="example-agentic-product-intake-agent",
                received_at="2026-08-08T08:00:02+00:00",
            )
            self.assertEqual(record["signal"]["status"], "accepted")
            self.assertEqual(record["signal"]["record_version"], 2)
            self.assertFalse(record["disposition"]["quarantined"])

            reopened = SignalIntake(workspace / "operations.db")
            self.assertEqual(reopened.get("signal-github-001"), record)
            self.assertEqual(
                [item["operation"] for item in reopened.history("signal-github-001")],
                ["receive", "accept"],
            )
            status = reopened.status()
            self.assertEqual(status["signal_count"], 1)
            self.assertEqual(status["revision_count"], 2)
            self.assertEqual(status["status_counts"]["accepted"], 1)

    def test_exact_retry_is_idempotent_and_duplicate_is_reviewable(self) -> None:
        with test_workspace("sf-101-duplicate") as workspace:
            _, intake = self._operations(workspace)
            envelope = self._envelope()
            first = intake.ingest(
                envelope,
                actor_identity_id="example-agentic-product-intake-agent",
                received_at="2026-08-08T08:00:02+00:00",
            )
            retry = intake.ingest(
                envelope,
                actor_identity_id="example-agentic-product-intake-agent",
                received_at="2026-08-08T08:05:00+00:00",
            )
            self.assertEqual(retry, first)
            self.assertEqual(intake.status()["signal_count"], 1)

            duplicate = self._envelope(signal_id="signal-github-002")
            duplicate_record = intake.ingest(
                duplicate,
                actor_identity_id="example-agentic-product-intake-agent",
                received_at="2026-08-08T08:06:00+00:00",
            )
            self.assertEqual(duplicate_record["signal"]["status"], "duplicate")
            self.assertEqual(
                duplicate_record["disposition"]["duplicate_of"],
                "signal-github-001",
            )
            self.assertFalse(duplicate_record["disposition"]["quarantined"])

    def test_altered_replay_is_quarantined_without_changing_original(self) -> None:
        with test_workspace("sf-101-replay") as workspace:
            _, intake = self._operations(workspace)
            intake.ingest(
                self._envelope(),
                actor_identity_id="example-agentic-product-intake-agent",
                received_at="2026-08-08T08:00:02+00:00",
            )
            collision = self._envelope(
                signal_id="signal-github-002",
                title="Different content under the same identity",
            )
            record = intake.ingest(
                collision,
                actor_identity_id="example-agentic-product-intake-agent",
                received_at="2026-08-08T08:01:00+00:00",
            )
            self.assertEqual(record["signal"]["status"], "rejected")
            self.assertTrue(record["disposition"]["quarantined"])
            self.assertEqual(
                record["disposition"]["reason_code"],
                "idempotency-collision",
            )
            self.assertEqual(
                intake.get("signal-github-001")["signal"]["status"],
                "accepted",
            )

    def test_concurrent_duplicate_delivery_accepts_once(self) -> None:
        with test_workspace("sf-101-concurrent") as workspace:
            _, intake = self._operations(workspace)
            database = workspace / "operations.db"
            barrier = threading.Barrier(2)

            def submit(signal_id: str) -> dict:
                envelope = self._envelope(signal_id=signal_id)
                barrier.wait(timeout=5)
                return SignalIntake(database).ingest(
                    envelope,
                    actor_identity_id="example-agentic-product-intake-agent",
                    received_at="2026-08-08T08:00:02+00:00",
                )

            with ThreadPoolExecutor(max_workers=2) as executor:
                records = list(
                    executor.map(
                        submit,
                        ["signal-github-001", "signal-github-002"],
                    )
                )

            self.assertEqual(
                sorted(record["signal"]["status"] for record in records),
                ["accepted", "duplicate"],
            )
            self.assertEqual(intake.status()["signal_count"], 2)
            self.assertEqual(intake.status()["revision_count"], 4)

    def test_authentication_failure_is_recorded_but_actor_bypass_is_rejected(self) -> None:
        with test_workspace("sf-101-auth") as workspace:
            _, intake = self._operations(workspace)
            failed = self._envelope()
            failed["authentication"] = {
                "status": "failed",
                "method": "adapter-signature",
                "principal_ref": None,
                "evidence_ref": None,
                "verified_at": None,
            }
            record = intake.ingest(
                failed,
                actor_identity_id="example-agentic-product-intake-agent",
            )
            self.assertEqual(record["signal"]["status"], "rejected")
            self.assertEqual(
                record["disposition"]["reason_code"],
                "authentication-failed",
            )

            with self.assertRaisesRegex(ProtocolError, "requires actor"):
                intake.ingest(
                    self._envelope(signal_id="signal-github-002"),
                    actor_identity_id="example-agentic-product-executor",
                )
            self.assertEqual(intake.status()["signal_count"], 1)

    def test_out_of_order_and_disabled_integration_signals_are_quarantined(self) -> None:
        with test_workspace("sf-101-order") as workspace:
            _, intake = self._operations(workspace)
            intake.ingest(
                self._envelope(source_sequence=2),
                actor_identity_id="example-agentic-product-intake-agent",
            )
            stale = self._envelope(
                signal_id="signal-github-002",
                source_event_id="github-event-002",
                source_sequence=1,
                idempotency_key="github-event-002-ingress",
            )
            stale_record = intake.ingest(
                stale,
                actor_identity_id="example-agentic-product-intake-agent",
            )
            self.assertEqual(
                stale_record["disposition"]["reason_code"],
                "out-of-order",
            )

            disabled = self._envelope(
                signal_id="signal-linear-001",
                source="linear",
                integration_id="linear-issues",
                source_event_id="linear-event-001",
                source_sequence=1,
                idempotency_key="linear-event-001-ingress",
            )
            disabled_record = intake.ingest(
                disabled,
                actor_identity_id="example-agentic-product-intake-agent",
            )
            self.assertEqual(
                disabled_record["disposition"]["reason_code"],
                "disabled-integration",
            )
            self.assertEqual(intake.status()["quarantined_count"], 2)

    def test_manual_signal_requires_exact_product_owner_principal(self) -> None:
        with test_workspace("sf-101-manual") as workspace:
            _, intake = self._operations(workspace)
            envelope = self._envelope(
                signal_id="signal-manual-001",
                source="manual",
                integration_id="owner-inbox",
                source_event_id="owner-request-001",
                source_sequence=None,
                idempotency_key="owner-request-001",
            )
            envelope["authentication"] = {
                "status": "verified",
                "method": "profile-role-binding",
                "principal_ref": "founder",
                "evidence_ref": "profile:product-one:founder",
                "verified_at": "2026-08-08T08:00:01+00:00",
            }
            envelope["source_reference"] = "manual:owner-inbox/request-001"
            record = intake.ingest(
                envelope,
                actor_identity_id="founder",
            )
            self.assertEqual(record["signal"]["status"], "accepted")

            mismatch = copy.deepcopy(envelope)
            mismatch["signal_id"] = "signal-manual-002"
            mismatch["source_event_id"] = "owner-request-002"
            mismatch["idempotency_key"] = "owner-request-002"
            mismatch["source_reference"] = "manual:owner-inbox/request-002"
            mismatch["authentication"]["principal_ref"] = "technical-owner"
            mismatch_record = intake.ingest(
                mismatch,
                actor_identity_id="founder",
            )
            self.assertEqual(
                mismatch_record["disposition"]["reason_code"],
                "principal-mismatch",
            )

    def test_work_item_boundary_is_digest_bound_and_does_not_create_a_ledger(self) -> None:
        with test_workspace("sf-101-candidate") as workspace:
            _, intake = self._operations(workspace)
            accepted = intake.ingest(
                self._envelope(),
                actor_identity_id="example-agentic-product-intake-agent",
            )
            candidate = intake.work_item_candidate("signal-github-001")
            self.assertEqual(candidate["project_id"], "product-one")
            self.assertEqual(
                candidate["signal_content_sha256"],
                accepted["signal"]["content_sha256"],
            )
            digest_input = dict(candidate)
            digest = digest_input.pop("content_sha256")
            self.assertEqual(digest, canonical_sha256(digest_input))
            self.assertEqual(
                intake.status()["work_item_creation"],
                "candidate-only-until-sf-102",
            )

            connection = sqlite3.connect(workspace / "operations.db")
            work_item_count = connection.execute(
                """
                SELECT COUNT(*) FROM work_items
                """
            ).fetchone()[0]
            connection.close()
            self.assertEqual(work_item_count, 0)

    def test_inactive_factory_is_quarantined_and_profile_tampering_fails_closed(
        self,
    ) -> None:
        with test_workspace("sf-101-factory-state") as workspace:
            _, intake = self._operations(workspace, active=False)
            record = intake.ingest(
                self._envelope(),
                actor_identity_id="example-agentic-product-intake-agent",
            )
            self.assertEqual(
                record["disposition"]["reason_code"],
                "factory-inactive",
            )

        with test_workspace("sf-101-profile-tamper") as workspace:
            _, intake = self._operations(workspace)
            tamper_sqlite_store(
                workspace / "operations.db",
                """
                UPDATE product_factories
                SET profile_json = '{"tampered":true}'
                WHERE project_id = 'product-one'
                """,
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "does not match its bound artifacts|Project profile",
            ):
                intake.ingest(
                    self._envelope(),
                    actor_identity_id="example-agentic-product-intake-agent",
                )

    def test_malformed_secret_and_signal_id_collision_fail_before_side_effects(
        self,
    ) -> None:
        with test_workspace("sf-101-invalid") as workspace:
            _, intake = self._operations(workspace)
            invalid = self._envelope()
            invalid["normalized"]["description"] = (
                "Bearer abcdefghijklmnop must not persist."
            )
            invalid["payload_sha256"] = canonical_sha256(invalid["normalized"])
            with self.assertRaisesRegex(ProtocolError, "secret-like material"):
                intake.ingest(
                    invalid,
                    actor_identity_id="example-agentic-product-intake-agent",
                )
            self.assertEqual(intake.status()["signal_count"], 0)

            valid = self._envelope()
            intake.ingest(
                valid,
                actor_identity_id="example-agentic-product-intake-agent",
            )
            changed = copy.deepcopy(valid)
            changed["source_event_id"] = "github-event-changed"
            with self.assertRaisesRegex(ProtocolError, "Signal id collision"):
                intake.ingest(
                    changed,
                    actor_identity_id="example-agentic-product-intake-agent",
                )
            self.assertEqual(intake.status()["signal_count"], 1)


if __name__ == "__main__":
    unittest.main()
