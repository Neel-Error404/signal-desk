from __future__ import annotations

import copy
import sqlite3
import unittest
from unittest.mock import patch

from elder_protocol.errors import (
    MutationConflictError,
    MutationForbiddenError,
)
from elder_protocol.factory_operations.owner_decisions import OwnerDecisions
from tests._support import test_workspace
from tests.component import test_work_item_ledger as ledger_support


FENCE = {
    "boot_id": "operations-api-boot-" + "a" * 32,
    "runtime_generation": 1,
}


class OwnerDecisionsComponentTests(unittest.TestCase):
    @staticmethod
    def _fixture(workspace):
        helper = ledger_support.WorkItemLedgerComponentTests(
            methodName="runTest"
        )
        ledger = helper._ledger(workspace)
        ledger.create(
            helper._specification(),
            actor_identity_id="founder",
            change_reason="Create the bounded decision subject.",
            at="2026-08-14T01:00:00+00:00",
        )
        return helper, ledger, OwnerDecisions(ledger.path)

    @staticmethod
    def _request(
        ledger,
        *,
        request_id="decision-request-cancel-work",
        requested_at="2026-08-14T01:01:00+00:00",
        expires_at="2026-08-14T02:01:00+00:00",
    ):
        work = ledger.get("work-item-build-repair")["work_item"]
        return {
            "version": "1.0.0",
            "decision_request_id": request_id,
            "project_id": "product-one",
            "work_item_id": work["id"],
            "run_id": None,
            "kind": "approval",
            "subject_sha256": work["content_sha256"],
            "subject_version": work["record_version"],
            "required_role": "product-owner",
            "question": "Cancel this bounded work item?",
            "impact": "Approval moves the work item to cancelled.",
            "choices": [
                {
                    "choice_id": "approve-cancel",
                    "label": "Approve cancellation",
                    "decision": "approved",
                    "transition_trigger": "cancel",
                    "evidence_refs": {
                        "cancellation decision": "evidence:sf303-cancel"
                    },
                },
                {
                    "choice_id": "reject-cancel",
                    "label": "Continue work",
                    "decision": "rejected",
                    "transition_trigger": None,
                    "evidence_refs": {},
                },
            ],
            "requested_by_identity_id": "founder",
            "requested_at": requested_at,
            "expires_at": expires_at,
        }

    @staticmethod
    def _response(
        *,
        decision_id="decision-cancel-work",
        actor="founder",
        role="product-owner",
    ):
        return {
            "version": "1.0.0",
            "decision_id": decision_id,
            "choice_id": "approve-cancel",
            "reason": "Resolve the exact bounded owner decision.",
            "evidence_refs": ["evidence:sf303-owner-review"],
            "decided_by_identity_id": actor,
            "decided_as_role": role,
        }

    def test_decision_applies_once_and_survives_restart(self) -> None:
        with test_workspace("sf303-decision-lifecycle") as workspace:
            _, ledger, decisions = self._fixture(workspace)
            request = self._request(ledger)
            created = decisions.create_request(
                request=request,
                actor_identity_id="founder",
                at=request["requested_at"],
                runtime_fence=FENCE,
            )
            self.assertEqual(created["state"]["request"]["status"], "waiting")
            first = decisions.decide(
                project_id="product-one",
                decision_request_id=request["decision_request_id"],
                response=self._response(),
                actor_identity_id="founder",
                at="2026-08-14T01:02:00+00:00",
                runtime_fence=FENCE,
            )
            self.assertEqual(first["state"]["effect"]["status"], "applied")
            self.assertEqual(
                ledger.get("work-item-build-repair")["work_item"]["status"],
                "cancelled",
            )
            replay = decisions.decide(
                project_id="product-one",
                decision_request_id=request["decision_request_id"],
                response=self._response(),
                actor_identity_id="founder",
                at="2026-08-14T01:02:00+00:00",
                runtime_fence=FENCE,
            )
            self.assertEqual(replay, first)
            self.assertEqual(
                OwnerDecisions(ledger.path).state(
                    project_id="product-one",
                    decision_request_id=request["decision_request_id"],
                ),
                first["state"],
            )
            connection = sqlite3.connect(ledger.path)
            try:
                with self.assertRaisesRegex(sqlite3.IntegrityError, "immutable"):
                    connection.execute(
                        """
                        UPDATE owner_decisions SET decision = 'rejected'
                        WHERE decision_id = 'decision-cancel-work'
                        """
                    )
            finally:
                connection.close()

    def test_wrong_actor_expiry_and_stale_subject_fail_closed(self) -> None:
        with test_workspace("sf303-decision-fail-closed") as workspace:
            helper, ledger, decisions = self._fixture(workspace)
            request = self._request(ledger)
            decisions.create_request(
                request=request,
                actor_identity_id="founder",
                at=request["requested_at"],
                runtime_fence=FENCE,
            )
            with self.assertRaisesRegex(
                MutationForbiddenError,
                "exact accountable role",
            ):
                decisions.decide(
                    project_id="product-one",
                    decision_request_id=request["decision_request_id"],
                    response=self._response(
                        decision_id="decision-wrong-owner",
                        actor="technical-owner",
                    ),
                    actor_identity_id="technical-owner",
                    at="2026-08-14T01:02:00+00:00",
                    runtime_fence=FENCE,
                )
            revised = copy.deepcopy(helper._specification())
            revised["objective"] = "Change the exact subject after request."
            ledger.update(
                revised,
                expected_version=1,
                actor_identity_id="founder",
                change_reason="Invalidate the decision subject.",
                at="2026-08-14T01:03:00+00:00",
            )
            with self.assertRaisesRegex(
                MutationConflictError,
                "subject changed",
            ):
                decisions.decide(
                    project_id="product-one",
                    decision_request_id=request["decision_request_id"],
                    response=self._response(
                        decision_id="decision-stale-subject"
                    ),
                    actor_identity_id="founder",
                    at="2026-08-14T01:04:00+00:00",
                    runtime_fence=FENCE,
                )

        with test_workspace("sf303-decision-expired") as workspace:
            _, ledger, decisions = self._fixture(workspace)
            request = self._request(
                ledger,
                request_id="decision-request-expired-work",
                expires_at="2026-08-14T01:02:00+00:00",
            )
            decisions.create_request(
                request=request,
                actor_identity_id="founder",
                at=request["requested_at"],
                runtime_fence=FENCE,
            )
            with self.assertRaisesRegex(MutationConflictError, "expired"):
                decisions.decide(
                    project_id="product-one",
                    decision_request_id=request["decision_request_id"],
                    response=self._response(
                        decision_id="decision-expired-work"
                    ),
                    actor_identity_id="founder",
                    at=request["expires_at"],
                    runtime_fence=FENCE,
                )

    def test_pending_effect_reconciles_after_response_loss(self) -> None:
        with test_workspace("sf303-effect-reconcile") as workspace:
            _, ledger, decisions = self._fixture(workspace)
            request = self._request(
                ledger,
                request_id="decision-request-reconcile-work",
            )
            response = self._response(
                decision_id="decision-reconcile-work"
            )
            decisions.create_request(
                request=request,
                actor_identity_id="founder",
                at=request["requested_at"],
                runtime_fence=FENCE,
            )
            with patch.object(
                decisions._transitions,
                "apply",
                side_effect=RuntimeError("simulated response loss"),
            ):
                with self.assertRaisesRegex(RuntimeError, "response loss"):
                    decisions.decide(
                        project_id="product-one",
                        decision_request_id=request["decision_request_id"],
                        response=response,
                        actor_identity_id="founder",
                        at="2026-08-14T01:02:00+00:00",
                        runtime_fence=FENCE,
                    )
            persisted = decisions.state(
                project_id="product-one",
                decision_request_id=request["decision_request_id"],
            )
            self.assertEqual(persisted["request"]["status"], "resolved")
            self.assertEqual(persisted["effect"]["status"], "pending")
            recovered = OwnerDecisions(ledger.path).decide(
                project_id="product-one",
                decision_request_id=request["decision_request_id"],
                response=response,
                actor_identity_id="founder",
                at="2026-08-14T01:02:00+00:00",
                runtime_fence=FENCE,
            )
            self.assertEqual(recovered["state"]["effect"]["status"], "applied")
            self.assertEqual(
                ledger.get("work-item-build-repair")["work_item"]["status"],
                "cancelled",
            )


if __name__ == "__main__":
    unittest.main()
