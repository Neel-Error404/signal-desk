from __future__ import annotations

import base64
import copy
import hashlib
import json
import subprocess
import tempfile
import unittest
import zipfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.asymmetric.rsa import generate_private_key
from cryptography.hazmat.primitives.hashes import SHA256

from elder_protocol.constants import PROTOCOL_DIR, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.hosted_qualification import (
    ANCHOR_ID,
    ANCHOR_SUBJECT,
    EVIDENCE_JOB,
    REQUIRED_JOBS,
    REVIEWER_ANCHOR_ID,
    REVIEWER_SUBJECT,
    _qualification_anchor,
    _validate_canonical_inputs,
    _validate_external_reviewer_pin,
    _validate_provider_evidence,
    _trusted_sources,
    issue_github_l2_bundle,
    verify_github_oidc_token,
)
from elder_protocol.io import load_json
from elder_protocol.qualification import qualify_hosted_bundle


def base64url(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def signed_statement(
    statement: dict[str, Any],
    private_key: Ed25519PrivateKey,
    signer_id: str,
) -> dict[str, Any]:
    statement_bytes = json.dumps(
        statement,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    return {
        "statement": statement,
        "attestation": {
            "signer_id": signer_id,
            "algorithm": "ed25519",
            "signed_statement_sha256": hashlib.sha256(
                statement_bytes
            ).hexdigest(),
            "signature_base64": base64.b64encode(
                private_key.sign(statement_bytes)
            ).decode("ascii"),
        },
    }


def resign_value(
    value: dict[str, Any],
    private_key: Ed25519PrivateKey,
    signer_id: str,
) -> None:
    statement = {
        key: item
        for key, item in value.items()
        if key not in {"attestation", "content_sha256"}
    }
    statement_bytes = json.dumps(
        statement,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    value["attestation"] = {
        "signer_id": signer_id,
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement_bytes).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement_bytes)
        ).decode("ascii"),
    }
    digest_payload = {
        key: item for key, item in value.items() if key != "content_sha256"
    }
    value["content_sha256"] = hashlib.sha256(
        json.dumps(
            digest_payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
        ).encode("utf-8")
    ).hexdigest()


def github_token(
    *,
    repository: str,
    sha: str,
    issued_at: datetime,
) -> tuple[str, dict[str, Any]]:
    private_key = generate_private_key(public_exponent=65537, key_size=2048)
    public_numbers = private_key.public_key().public_numbers()
    key_id = "github-test-key"
    header = {"alg": "RS256", "kid": key_id, "typ": "JWT"}
    owner, repository_name = repository.split("/", maxsplit=1)
    claims = {
        "iss": "https://token.actions.githubusercontent.com",
        "sub": (
            f"repo:{owner}@5678/{repository_name}@1234:"
            "ref:refs/heads/main"
        ),
        "aud": "elder-protocol",
        "repository": repository,
        "repository_id": "1234",
        "repository_owner": "fixture-owner",
        "repository_owner_id": "5678",
        "repository_visibility": "private",
        "ref": "refs/heads/main",
        "sha": sha,
        "workflow_ref": (
            f"{repository}/.github/workflows/elder-ci.yml@refs/heads/main"
        ),
        "runner_environment": "github-hosted",
        "actor": "fixture-owner",
        "actor_id": "999",
        "event_name": "push",
        "run_id": "101",
        "run_number": "7",
        "run_attempt": "1",
        "iat": int(issued_at.timestamp()) - 5,
        "nbf": int(issued_at.timestamp()) - 5,
        "exp": int(issued_at.timestamp()) + 300,
    }
    encoded_header = base64url(
        json.dumps(header, separators=(",", ":")).encode("utf-8")
    )
    encoded_claims = base64url(
        json.dumps(claims, separators=(",", ":")).encode("utf-8")
    )
    signing_input = f"{encoded_header}.{encoded_claims}".encode("ascii")
    signature = private_key.sign(signing_input, PKCS1v15(), SHA256())
    token = f"{encoded_header}.{encoded_claims}.{base64url(signature)}"
    return token, {
        "keys": [
            {
                "kid": key_id,
                "kty": "RSA",
                "use": "sig",
                "alg": "RS256",
                "n": base64url(
                    public_numbers.n.to_bytes(
                        (public_numbers.n.bit_length() + 7) // 8,
                        "big",
                    )
                ),
                "e": base64url(
                    public_numbers.e.to_bytes(
                        (public_numbers.e.bit_length() + 7) // 8,
                        "big",
                    )
                ),
            }
        ]
    }


def provider_evidence(
    *,
    repository: str = "fixture-owner/elder-protocol",
    artifact_digest: str = "sha256:" + "b" * 64,
    artifact_size: int = 1024,
) -> dict[str, Any]:
    sha = "a" * 40
    run_id = 101
    jobs = [
        {
            "id": index,
            "name": name,
            "status": "completed",
            "conclusion": "success",
            "run_id": run_id,
            "head_sha": sha,
            "html_url": (
                f"https://github.com/{repository}/actions/runs/{run_id}/job/{index}"
            ),
            "runner_name": "GitHub Actions 1",
            "labels": ["ubuntu-latest"],
            "started_at": "2026-08-06T09:59:50Z",
            "completed_at": "2026-08-06T10:00:00Z",
        }
        for index, name in enumerate(
            sorted(REQUIRED_JOBS | {EVIDENCE_JOB}),
            start=1,
        )
    ]
    return {
        "run": {
            "id": run_id,
            "run_attempt": 1,
            "event": "push",
            "head_branch": "main",
            "head_sha": sha,
            "status": "completed",
            "conclusion": "success",
            "path": ".github/workflows/elder-ci.yml",
            "html_url": f"https://github.com/{repository}/actions/runs/101",
            "repository": {
                "id": 1234,
                "full_name": repository,
                "owner": {"id": 5678},
            },
        },
        "jobs": {"total_count": len(jobs), "jobs": jobs},
        "artifacts": {
            "total_count": 1,
            "artifacts": [
                {
                    "id": 88,
                    "name": "elder-hosted-evidence-input-101-1",
                    "expired": False,
                    "digest": artifact_digest,
                    "size_in_bytes": artifact_size,
                    "archive_download_url": (
                        f"https://api.github.com/repos/{repository}/actions/"
                        "artifacts/88/zip"
                    ),
                    "workflow_run": {
                        "id": run_id,
                        "head_sha": sha,
                    },
                }
            ]
        },
    }


class HostedQualificationComponentTests(unittest.TestCase):
    def test_oidc_signature_and_immutable_subject_are_verified(self) -> None:
        issued_at = datetime(2026, 8, 6, 10, 0, tzinfo=UTC)
        repository = "fixture-owner/elder-protocol"
        token, jwks = github_token(
            repository=repository,
            sha="a" * 40,
            issued_at=issued_at,
        )
        claims = verify_github_oidc_token(
            token,
            jwks=jwks,
            repository=repository,
            repository_id="1234",
            repository_owner_id="5678",
            sha="a" * 40,
            ref="refs/heads/main",
            workflow_ref=(
                f"{repository}/.github/workflows/elder-ci.yml@refs/heads/main"
            ),
            audience="elder-protocol",
            provider_window_start_epoch=int(issued_at.timestamp()) - 10,
            provider_event_epoch=int(issued_at.timestamp()),
        )
        self.assertEqual(
            claims["sub"],
            "repo:fixture-owner@5678/elder-protocol@1234:"
            "ref:refs/heads/main",
        )

        header, payload, signature = token.split(".")
        tampered = ("A" if signature[0] != "A" else "B") + signature[1:]
        with self.assertRaisesRegex(ProtocolError, "signature verification"):
            verify_github_oidc_token(
                f"{header}.{payload}.{tampered}",
                jwks=jwks,
                repository=repository,
                repository_id="1234",
                repository_owner_id="5678",
                sha="a" * 40,
                ref="refs/heads/main",
                workflow_ref=(
                    f"{repository}/.github/workflows/elder-ci.yml@refs/heads/main"
                ),
                audience="elder-protocol",
                provider_window_start_epoch=int(issued_at.timestamp()) - 10,
                provider_event_epoch=int(issued_at.timestamp()),
            )

    def test_oidc_token_must_be_fresh_for_the_provider_job(self) -> None:
        issued_at = datetime(2020, 1, 1, 10, 0, tzinfo=UTC)
        repository = "fixture-owner/elder-protocol"
        token, jwks = github_token(
            repository=repository,
            sha="a" * 40,
            issued_at=issued_at,
        )
        provider_event = datetime(2026, 8, 6, 10, 0, tzinfo=UTC)
        with self.assertRaisesRegex(
            ProtocolError,
            "valid at the provider event time|trusted provider job",
        ):
            verify_github_oidc_token(
                token,
                jwks=jwks,
                repository=repository,
                repository_id="1234",
                repository_owner_id="5678",
                sha="a" * 40,
                ref="refs/heads/main",
                workflow_ref=(
                    f"{repository}/.github/workflows/elder-ci.yml@refs/heads/main"
                ),
                audience="elder-protocol",
                provider_window_start_epoch=int(provider_event.timestamp()) - 10,
                provider_event_epoch=int(provider_event.timestamp()),
            )

    def test_provider_jobs_artifact_and_sha_are_exactly_bound(self) -> None:
        evidence = provider_evidence()
        verified = _validate_provider_evidence(
            evidence,
            repository="fixture-owner/elder-protocol",
            run_id="101",
            run_attempt="1",
        )
        self.assertEqual(len(verified["jobs"]), 4)
        self.assertEqual(verified["head_sha"], "a" * 40)

        for mutation in [
            "failed-job",
            "foreign-sha",
            "missing-artifact",
            "duplicate-job",
            "duplicate-job-id",
            "invalid-job-id",
            "foreign-job-url",
            "incomplete-jobs",
            "missing-digest",
            "invalid-artifact-id",
            "foreign-artifact-url",
        ]:
            with self.subTest(mutation=mutation):
                changed = copy.deepcopy(evidence)
                if mutation == "failed-job":
                    changed["jobs"]["jobs"][0]["conclusion"] = "failure"
                elif mutation == "foreign-sha":
                    changed["jobs"]["jobs"][0]["head_sha"] = "c" * 40
                elif mutation == "missing-artifact":
                    changed["artifacts"]["artifacts"] = []
                elif mutation == "duplicate-job":
                    changed["jobs"]["jobs"].append(
                        copy.deepcopy(changed["jobs"]["jobs"][0])
                    )
                    changed["jobs"]["total_count"] += 1
                elif mutation == "duplicate-job-id":
                    changed["jobs"]["jobs"][1]["id"] = changed["jobs"]["jobs"][0][
                        "id"
                    ]
                    changed["jobs"]["jobs"][1]["html_url"] = changed["jobs"]["jobs"][
                        0
                    ]["html_url"]
                elif mutation == "invalid-job-id":
                    changed["jobs"]["jobs"][0]["id"] = 0
                elif mutation == "foreign-job-url":
                    changed["jobs"]["jobs"][0]["html_url"] = (
                        "https://github.com/other/repo/actions/runs/101/job/1"
                    )
                elif mutation == "incomplete-jobs":
                    changed["jobs"]["total_count"] += 1
                elif mutation == "foreign-artifact-url":
                    changed["artifacts"]["artifacts"][0][
                        "archive_download_url"
                    ] = "https://api.github.com/repos/other/repo/actions/artifacts/88/zip"
                elif mutation == "invalid-artifact-id":
                    changed["artifacts"]["artifacts"][0]["id"] = (
                        "88/../../repos/other/actions/artifacts/1"
                    )
                    changed["artifacts"]["artifacts"][0][
                        "archive_download_url"
                    ] = (
                        "https://api.github.com/repos/fixture-owner/"
                        "elder-protocol/actions/artifacts/"
                        "88/../../repos/other/actions/artifacts/1/zip"
                    )
                else:
                    changed["artifacts"]["artifacts"][0]["digest"] = None
                with self.assertRaises(ProtocolError):
                    _validate_provider_evidence(
                        changed,
                        repository="fixture-owner/elder-protocol",
                        run_id="101",
                        run_attempt="1",
                    )

    def test_trusted_sources_are_read_from_the_claimed_git_revision(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            subprocess.run(["git", "init", "-q"], cwd=root, check=True)
            subprocess.run(
                ["git", "config", "user.name", "Elder Test"],
                cwd=root,
                check=True,
            )
            subprocess.run(
                ["git", "config", "user.email", "elder-test@example.invalid"],
                cwd=root,
                check=True,
            )
            source = root / "source.txt"
            source.write_bytes(b"committed source\n")
            subprocess.run(["git", "add", "source.txt"], cwd=root, check=True)
            subprocess.run(
                ["git", "commit", "-q", "-m", "fixture"],
                cwd=root,
                check=True,
            )
            sha = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=root,
                check=True,
                capture_output=True,
                text=True,
            ).stdout.strip()
            source.write_bytes(b"mutable working tree content\n")

            with patch("elder_protocol.hosted_qualification.ROOT", root):
                trusted = _trusted_sources(
                    "fixture-owner/elder-protocol",
                    sha,
                    ["source.txt"],
                )

            self.assertEqual(
                trusted[0]["sha256"],
                hashlib.sha256(b"committed source\n").hexdigest(),
            )
            self.assertNotEqual(
                trusted[0]["sha256"],
                hashlib.sha256(source.read_bytes()).hexdigest(),
            )

    def test_canonical_pins_and_operator_anchor_fail_closed(self) -> None:
        policy = load_json(PROTOCOL_DIR / "qualification-policy.json")
        maturity = load_json(PROTOCOL_DIR / "operational-maturity.json")
        _validate_canonical_inputs(policy, maturity)
        _validate_external_reviewer_pin(
            policy,
            policy["trust"]["anchors"][1]["public_key_base64"],
        )
        with self.assertRaisesRegex(ProtocolError, "out-of-band pin"):
            _validate_external_reviewer_pin(policy, "A" * 44)

        drifted = copy.deepcopy(policy)
        drifted["id"] = "caller-selected-policy"
        with self.assertRaisesRegex(ProtocolError, "digest"):
            _validate_canonical_inputs(drifted, maturity)

        key = Ed25519PrivateKey.generate()
        policy["trust"]["anchors"] = [
            {
                "id": ANCHOR_ID,
                "subject_identity": "foreign-verifier",
                "algorithm": "ed25519",
                "public_key_base64": base64.b64encode(
                    key.public_key().public_bytes_raw()
                ).decode("ascii"),
                "roles": ["accountable-operator", "independent-verifier"],
                "providers": ["elder-governance", "github-actions"],
                "source_hosts": ["github.com"],
                "valid_from": "2026-08-01T00:00:00+00:00",
                "valid_until": "2027-08-01T00:00:00+00:00",
                "status": "active",
            }
        ]
        with self.assertRaisesRegex(ProtocolError, "subject_identity"):
            _qualification_anchor(policy, key)
        self.assertNotEqual("foreign-verifier", ANCHOR_SUBJECT)

    def test_hosted_workflow_never_exposes_a_signing_secret(self) -> None:
        workflow = (ROOT / ".github/workflows/elder-ci.yml").read_text(
            encoding="utf-8"
        )
        self.assertNotIn("ELDER_QUALIFICATION_ED25519_PRIVATE_KEY", workflow)
        self.assertNotIn("secrets.", workflow)
        self.assertNotIn("issue-github-l2", workflow)
        self.assertIn(
            "github.event_name == 'push' && github.ref == 'refs/heads/main'",
            workflow,
        )
        self.assertIn("P4.8A / hosted-evidence-input", workflow)
        reproducible_job = workflow.split("  reproducible-artifact:", 1)[1].split(
            "  native-attestation:",
            1,
        )[0]
        self.assertNotIn("id-token: write", reproducible_job)
        self.assertNotIn("attestations: write", reproducible_job)
        self.assertNotIn("environment:", reproducible_job)
        self.assertIn("retention-days: 1", workflow)

    def test_operator_issuance_builds_a_signed_provider_bound_l2_bundle(self) -> None:
        repository = "Neel-Error404/elder-protocol"
        issued_at = datetime(2026, 8, 6, 10, 0, tzinfo=UTC)
        token, jwks = github_token(
            repository=repository,
            sha="a" * 40,
            issued_at=issued_at,
        )
        artifact_bytes = b"elder-workbench-artifact"
        artifact_sha256 = hashlib.sha256(artifact_bytes).hexdigest()
        report = {
            "build_id": "BUILD-1",
            "artifact_sha256": artifact_sha256,
            "source_tree_sha256": "c" * 64,
            "test_results": [
                {"level": level, "status": "passed", "returncode": 0}
                for level in [
                    "Foundation",
                    "Component",
                    "Integration",
                    "Workflow",
                    "Stress",
                ]
            ],
        }
        context = {
            "repository": repository,
            "repository_id": "1234",
            "repository_owner_id": "5678",
            "sha": "a" * 40,
            "ref": "refs/heads/main",
            "workflow_ref": (
                f"{repository}/.github/workflows/elder-ci.yml@refs/heads/main"
            ),
            "run_id": "101",
            "run_attempt": "1",
            "event_name": "push",
            "runner_environment": "github-hosted",
            "workflow_job": "hosted-evidence-input",
            "evidence_job_id": "4",
            "prerequisite_results": {
                name: "success" for name in sorted(REQUIRED_JOBS)
            },
        }
        private_key = Ed25519PrivateKey.generate()
        reviewer_key = Ed25519PrivateKey.generate()
        policy = load_json(PROTOCOL_DIR / "qualification-policy.json")
        policy["trust"]["anchors"][0]["public_key_base64"] = base64.b64encode(
            private_key.public_key().public_bytes_raw()
        ).decode("ascii")
        policy["trust"]["anchors"][1]["public_key_base64"] = base64.b64encode(
            reviewer_key.public_key().public_bytes_raw()
        ).decode("ascii")
        maturity = load_json(PROTOCOL_DIR / "operational-maturity.json")

        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            governance_path = root / "signed-governance.json"
            governance_binding = {
                "project_id": "elder-protocol",
                "environment": "production",
                "artifact_sha256": artifact_sha256,
                "commit_sha": "a" * 40,
                "source_uri": (
                    f"https://github.com/{repository}/actions/runs/101"
                ),
            }
            governance = {
                "version": "0.5.1",
                "project_id": "elder-protocol",
                "environment": "production",
                "human_decision": signed_statement(
                    {
                        **governance_binding,
                        "decision": "approved",
                        "decided_by": "Neel-Error404",
                        "decided_as_role": "accountable-operator",
                        "scope": [
                            "remote",
                            "protected-branch",
                            "ci",
                            "signed-provenance",
                            "external-identity",
                            "trust-anchors",
                            "l2-qualification",
                        ],
                    },
                    private_key,
                    ANCHOR_ID,
                ),
                "manual_replay": signed_statement(
                    {
                        **governance_binding,
                        "levels": [
                            {
                                "level": level,
                                "status": "passed",
                                "test_count": count,
                            }
                            for level, count in [
                                ("Foundation", 18),
                                ("Component", 120),
                                ("Integration", 26),
                                ("Workflow", 15),
                                ("Stress", 13),
                            ]
                        ],
                    },
                    private_key,
                    ANCHOR_ID,
                ),
                "independent_review": signed_statement(
                    {
                        **governance_binding,
                        "reviewer_id": REVIEWER_SUBJECT,
                        "remaining_findings": {
                            "critical": 0,
                            "high": 0,
                            "medium": 0,
                        },
                    },
                    reviewer_key,
                    REVIEWER_ANCHOR_ID,
                ),
            }
            governance_path.write_text(
                json.dumps(governance, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            archive_path = root / "provider-input.zip"
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("github-oidc.jwt", token)
                archive.writestr("github-context.json", json.dumps(context))
                archive.writestr("elder-workbench.zip", artifact_bytes)
                archive.writestr(
                    "primary-build-report.json",
                    json.dumps(report),
                )
                replay_report = copy.deepcopy(report)
                replay_report["build_id"] = "BUILD-2"
                archive.writestr(
                    "replay-build-report.json",
                    json.dumps(replay_report),
                )
            digest = "sha256:" + hashlib.sha256(
                archive_path.read_bytes()
            ).hexdigest()
            provider = provider_evidence(
                repository=repository,
                artifact_digest=digest,
                artifact_size=archive_path.stat().st_size,
            )

            def canonical_load(path: Path) -> dict[str, Any]:
                if path.name == "qualification-policy.json":
                    return copy.deepcopy(policy)
                if path.name == "operational-maturity.json":
                    return copy.deepcopy(maturity)
                return load_json(path)

            with (
                patch(
                    "elder_protocol.qualification."
                    "CANONICAL_OPERATOR_PUBLIC_KEY_BASE64",
                    policy["trust"]["anchors"][0]["public_key_base64"],
                ),
                patch(
                    "elder_protocol.qualification."
                    "CANONICAL_REVIEWER_PUBLIC_KEY_BASE64",
                    policy["trust"]["anchors"][1]["public_key_base64"],
                ),
                patch(
                    "elder_protocol.hosted_qualification."
                    "CANONICAL_REVIEWER_PUBLIC_KEY_BASE64",
                    policy["trust"]["anchors"][1]["public_key_base64"],
                ),
                patch(
                    "elder_protocol.hosted_qualification._validate_local_revision"
                ),
                patch(
                    "elder_protocol.hosted_qualification._validate_canonical_inputs"
                ),
                patch(
                    "elder_protocol.hosted_qualification._trusted_sources",
                    return_value=[
                        {
                            "path": "fixture",
                            "url": "https://github.com/example/fixture",
                            "sha256": "d" * 64,
                        }
                    ],
                ),
                patch(
                    "elder_protocol.hosted_qualification.load_json",
                    side_effect=canonical_load,
                ),
            ):
                summary = issue_github_l2_bundle(
                    output_dir=root / "qualified",
                    evidence_archive_path=archive_path,
                    governance_evidence_path=governance_path,
                    provider_evidence=provider,
                    private_key_base64=base64.b64encode(
                        private_key.private_bytes_raw()
                    ).decode("ascii"),
                    reviewer_public_key_base64=policy["trust"]["anchors"][1][
                        "public_key_base64"
                    ],
                    repository=repository,
                    run_id="101",
                    run_attempt="1",
                    jwks=jwks,
                    now=issued_at,
                )
                forged_governance = copy.deepcopy(governance)
                forged_governance["independent_review"]["statement"][
                    "remaining_findings"
                ]["high"] = 1
                governance_path.write_text(
                    json.dumps(forged_governance, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )
                with self.assertRaisesRegex(
                    ProtocolError,
                    "signed statement digest|signature verification",
                ):
                    issue_github_l2_bundle(
                        output_dir=root / "forged-governance",
                        evidence_archive_path=archive_path,
                        governance_evidence_path=governance_path,
                        provider_evidence=provider,
                        private_key_base64=base64.b64encode(
                            private_key.private_bytes_raw()
                        ).decode("ascii"),
                        reviewer_public_key_base64=policy["trust"]["anchors"][1][
                            "public_key_base64"
                        ],
                        repository=repository,
                        run_id="101",
                        run_attempt="1",
                        jwks=jwks,
                        now=issued_at,
                    )
                governance_path.write_text(
                    json.dumps(governance, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )

                stale_at = issued_at - timedelta(days=2)
                stale_token, stale_jwks = github_token(
                    repository=repository,
                    sha="a" * 40,
                    issued_at=stale_at,
                )
                stale_archive_path = root / "stale-provider-input.zip"
                with zipfile.ZipFile(stale_archive_path, "w") as archive:
                    archive.writestr("github-oidc.jwt", stale_token)
                    archive.writestr("github-context.json", json.dumps(context))
                    archive.writestr("elder-workbench.zip", artifact_bytes)
                    archive.writestr(
                        "primary-build-report.json",
                        json.dumps(report),
                    )
                    archive.writestr(
                        "replay-build-report.json",
                        json.dumps(replay_report),
                    )
                stale_provider = provider_evidence(
                    repository=repository,
                    artifact_digest="sha256:"
                    + hashlib.sha256(stale_archive_path.read_bytes()).hexdigest(),
                    artifact_size=stale_archive_path.stat().st_size,
                )
                for job in stale_provider["jobs"]["jobs"]:
                    if job["name"] == EVIDENCE_JOB:
                        job["started_at"] = (
                            stale_at - timedelta(seconds=10)
                        ).isoformat().replace("+00:00", "Z")
                        job["completed_at"] = stale_at.isoformat().replace(
                            "+00:00",
                            "Z",
                        )
                with self.assertRaisesRegex(
                    ProtocolError,
                    "freshness window",
                ):
                    issue_github_l2_bundle(
                        output_dir=root / "stale-provider",
                        evidence_archive_path=stale_archive_path,
                        governance_evidence_path=governance_path,
                        provider_evidence=stale_provider,
                        private_key_base64=base64.b64encode(
                            private_key.private_bytes_raw()
                        ).decode("ascii"),
                        reviewer_public_key_base64=policy["trust"]["anchors"][1][
                            "public_key_base64"
                        ],
                        repository=repository,
                        run_id="101",
                        run_attempt="1",
                        jwks=stale_jwks,
                        now=issued_at,
                    )

            self.assertTrue(summary["qualified"])
            self.assertEqual(summary["achieved_level"], "L2")
            bundle = json.loads((root / "qualified" / "bundle.json").read_text())
            self.assertEqual(len(bundle["records"]), 18)
            governance_payload = json.loads(
                (
                    root / "qualified" / "payloads" / "signed-governance-evidence.json"
                ).read_text()
            )
            self.assertEqual(
                governance_payload["manual_replay"],
                governance["manual_replay"],
            )

            forged_payload_path = (
                root / "qualified" / "payloads" / "signed-governance-evidence.json"
            )
            forged_payload = json.loads(forged_payload_path.read_text())
            forged_payload["independent_review"]["statement"][
                "remaining_findings"
            ]["high"] = 1
            forged_payload_path.write_text(
                json.dumps(forged_payload, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            forged_payload_sha256 = hashlib.sha256(
                forged_payload_path.read_bytes()
            ).hexdigest()
            forged_bundle_path = root / "qualified" / "bundle.json"
            forged_bundle = json.loads(forged_bundle_path.read_text())
            for record in forged_bundle["records"]:
                if record["payload_path"] == (
                    "payloads/signed-governance-evidence.json"
                ):
                    record["payload_sha256"] = forged_payload_sha256
                    resign_value(record, private_key, ANCHOR_ID)
            resign_value(forged_bundle, private_key, ANCHOR_ID)
            forged_bundle_path.write_text(
                json.dumps(forged_bundle, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            with (
                patch(
                    "elder_protocol.qualification."
                    "CANONICAL_OPERATOR_PUBLIC_KEY_BASE64",
                    policy["trust"]["anchors"][0]["public_key_base64"],
                ),
                patch(
                    "elder_protocol.qualification."
                    "CANONICAL_REVIEWER_PUBLIC_KEY_BASE64",
                    policy["trust"]["anchors"][1]["public_key_base64"],
                ),
            ):
                with self.assertRaisesRegex(
                    ProtocolError,
                    "signed statement digest|signature verification",
                ):
                    qualify_hosted_bundle(
                        forged_bundle_path,
                        policy,
                        maturity,
                        at=issued_at.isoformat(),
                    )

            archive_path.write_bytes(archive_path.read_bytes() + b"tampered")
            with patch(
                "elder_protocol.hosted_qualification._validate_local_revision"
            ):
                with self.assertRaisesRegex(
                    ProtocolError,
                    "archive does not match",
                ):
                    issue_github_l2_bundle(
                        output_dir=root / "rejected",
                        evidence_archive_path=archive_path,
                        governance_evidence_path=governance_path,
                        provider_evidence=provider,
                        private_key_base64=base64.b64encode(
                            private_key.private_bytes_raw()
                        ).decode("ascii"),
                        reviewer_public_key_base64=policy["trust"]["anchors"][1][
                            "public_key_base64"
                        ],
                        repository=repository,
                        run_id="101",
                        run_attempt="1",
                        jwks=jwks,
                        now=issued_at,
                    )


if __name__ == "__main__":
    unittest.main()
