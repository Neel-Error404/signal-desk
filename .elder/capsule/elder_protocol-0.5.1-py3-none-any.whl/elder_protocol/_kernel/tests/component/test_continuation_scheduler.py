from __future__ import annotations

import copy
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import (
    MutationConflictError,
    MutationForbiddenError,
    ProtocolError,
)
from elder_protocol.factory_operations import DurableContinuationScheduler
from tests._sf203_support import control_command
from tests._sf205_support import (
    changed_request,
    goal_request,
    reopen_scheduler,
    scheduler_fixture,
)
from tests._support import test_workspace


class DurableContinuationSchedulerComponentTests(unittest.TestCase):
    def test_goal_duplicate_collision_pause_resume_and_cancel(self) -> None:
        with test_workspace("sf205-goal-lifecycle") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                _,
                session,
                scheduler,
            ) = scheduler_fixture(workspace)
            request = goal_request(aggregate, binding)
            with self.assertRaisesRegex(
                MutationConflictError,
                "does not match",
            ):
                DurableContinuationScheduler(
                    workspace / "mismatched-continuation.db",
                    run_controller=controller,
                    session_controller=session,
                    workspace_binding_sha256="0" * 64,
                )
            created = scheduler.create_goal(request)
            self.assertEqual(created["status"], "active")
            self.assertEqual(scheduler.create_goal(request), created)
            with self.assertRaisesRegex(
                MutationConflictError,
                "collision",
            ):
                scheduler.create_goal(changed_request(request))

            paused = scheduler.pause(
                request["goal_id"],
                at="2026-08-11T01:08:40+00:00",
            )
            self.assertEqual(paused["status"], "paused")
            self.assertEqual(
                scheduler.get_schedule(request["schedule_id"])["status"],
                "paused",
            )
            resumed = scheduler.resume(
                request["goal_id"],
                at="2026-08-11T01:08:50+00:00",
            )
            self.assertEqual(resumed["status"], "active")
            self.assertEqual(
                scheduler.get_schedule(request["schedule_id"])[
                    "next_tick_at"
                ],
                "2026-08-11T01:09:50+00:00",
            )
            cancelled = scheduler.cancel(
                request["goal_id"],
                at="2026-08-11T01:08:55+00:00",
            )
            self.assertEqual(cancelled["status"], "cancelled")
            self.assertEqual(cancelled["stop_reason"], "goal-cancelled")
            self.assertEqual(
                scheduler.get_schedule(request["schedule_id"])["status"],
                "cancelled",
            )

    def test_due_tick_submits_once_and_token_budget_stops_after_result(
        self,
    ) -> None:
        with test_workspace("sf205-due-result") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
                scheduler,
            ) = scheduler_fixture(workspace)
            request = goal_request(
                aggregate,
                binding,
                token_limit=100,
            )
            scheduler.create_goal(request)
            submitted = scheduler.run_due(
                owner_id="scheduler-one",
                at="2026-08-11T01:09:00+00:00",
            )
            self.assertEqual(submitted["status"], "submitted")
            self.assertIsNone(
                scheduler.run_due(
                    owner_id="scheduler-two",
                    at="2026-08-11T01:09:01+00:00",
                )
            )
            control = session.execute_once(
                owner_id="session-controller",
                at="2026-08-11T01:09:02+00:00",
            )
            self.assertEqual(control["status"], "succeeded")
            completed = scheduler.record_result(
                submitted["tick_id"],
                tokens_used=100,
                elapsed_seconds_used=5,
                at="2026-08-11T01:09:03+00:00",
            )
            self.assertEqual(completed["status"], "succeeded")
            goal = scheduler.get_goal(request["goal_id"])
            self.assertEqual(goal["status"], "stopped")
            self.assertEqual(goal["stop_reason"], "token-budget-exhausted")
            self.assertEqual(goal["continuations_used"], 1)
            self.assertEqual(
                sum(
                    record["command"]["operation"] == "prompt"
                    for record in session.list(run_id=request["run_id"])
                ),
                1,
            )

            over_budget = goal_request(
                aggregate,
                binding,
                suffix="over-budget",
                created_at="2026-08-11T01:09:04+00:00",
                first_tick_at="2026-08-11T01:10:00+00:00",
                token_limit=100,
            )
            scheduler.create_goal(over_budget)
            submitted = scheduler.run_due(
                owner_id="scheduler-one",
                at="2026-08-11T01:10:00+00:00",
            )
            session.execute_once(
                owner_id="session-controller",
                at="2026-08-11T01:10:01+00:00",
            )
            exceeded = scheduler.record_result(
                submitted["tick_id"],
                tokens_used=101,
                elapsed_seconds_used=5,
                at="2026-08-11T01:10:02+00:00",
            )
            self.assertEqual(exceeded["status"], "uncertain")
            self.assertEqual(exceeded["reason"], "token-budget-exhausted")
            exceeded_goal = scheduler.get_goal(over_budget["goal_id"])
            self.assertEqual(exceeded_goal["status"], "uncertain")
            self.assertEqual(
                exceeded_goal["stop_reason"],
                "token-budget-exhausted",
            )

    def test_missed_tick_and_canonical_pause_skip_without_dispatch(
        self,
    ) -> None:
        with test_workspace("sf205-skips") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
                scheduler,
            ) = scheduler_fixture(workspace)
            missed_request = goal_request(
                aggregate,
                binding,
                suffix="missed",
                misfire_grace_seconds=5,
            )
            scheduler.create_goal(missed_request)
            missed = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-11T01:10:30+00:00",
            )
            self.assertEqual(missed["status"], "skipped")
            self.assertEqual(missed["reason"], "missed-tick-coalesced")
            self.assertEqual(
                scheduler.get_schedule(missed_request["schedule_id"])[
                    "next_tick_at"
                ],
                "2026-08-11T01:11:00+00:00",
            )
            scheduler.cancel(
                missed_request["goal_id"],
                at="2026-08-11T01:10:31+00:00",
            )

            pause = control_command(
                controller.get(aggregate["run"]["id"]),
                binding,
                "pause",
                index=500,
                requested_by="founder",
                at="2026-08-11T01:10:40+00:00",
            )
            session.submit(pause)
            self.assertEqual(
                session.execute_once(
                    owner_id="session-controller",
                    at=pause["submitted_at"],
                )["status"],
                "succeeded",
            )
            paused_aggregate = controller.get(aggregate["run"]["id"])
            paused_request = goal_request(
                paused_aggregate,
                binding,
                suffix="paused",
                created_at="2026-08-11T01:10:41+00:00",
                first_tick_at="2026-08-11T01:11:00+00:00",
            )
            scheduler.create_goal(paused_request)
            paused_tick = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(paused_tick["status"], "skipped")
            self.assertEqual(paused_tick["reason"], "work-paused")
            self.assertEqual(
                sum(
                    record["command"]["operation"] == "prompt"
                    for record in session.list(
                        run_id=paused_request["run_id"]
                    )
                ),
                0,
            )
            scheduler.cancel(
                paused_request["goal_id"],
                at="2026-08-11T01:11:01+00:00",
            )
            resume = control_command(
                controller.get(aggregate["run"]["id"]),
                binding,
                "resume",
                index=501,
                requested_by="founder",
                at="2026-08-11T01:11:02+00:00",
            )
            session.submit(resume)
            session.execute_once(
                owner_id="session-controller",
                at=resume["submitted_at"],
            )
            wait = control_command(
                controller.get(aggregate["run"]["id"]),
                binding,
                "wait",
                index=502,
                payload={"waiting_reason": "owner-decision"},
                requested_by="founder",
                at="2026-08-11T01:11:03+00:00",
            )
            session.submit(wait)
            self.assertEqual(
                session.execute_once(
                    owner_id="session-controller",
                    at=wait["submitted_at"],
                )["status"],
                "waiting-owner",
            )
            waiting_request = goal_request(
                controller.get(aggregate["run"]["id"]),
                binding,
                suffix="waiting",
                created_at="2026-08-11T01:11:04+00:00",
                first_tick_at="2026-08-11T01:12:00+00:00",
            )
            scheduler.create_goal(waiting_request)
            waiting_tick = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-11T01:12:00+00:00",
            )
            self.assertEqual(waiting_tick["status"], "skipped")
            self.assertEqual(waiting_tick["reason"], "work-waiting-owner")

    def test_deadline_authority_and_requested_budget_fail_closed(self) -> None:
        with test_workspace("sf205-limits") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                _,
                _,
                scheduler,
            ) = scheduler_fixture(workspace)
            expanded = goal_request(
                aggregate,
                binding,
                suffix="expanded",
                token_limit=9000,
            )
            with self.assertRaisesRegex(
                MutationForbiddenError,
                "expands Elder authority",
            ):
                scheduler.create_goal(expanded)
            expanded_continuations = goal_request(
                aggregate,
                binding,
                suffix="expanded-continuations",
                continuation_limit=41,
            )
            with self.assertRaisesRegex(
                MutationForbiddenError,
                "tool-call authority",
            ):
                scheduler.create_goal(expanded_continuations)

            deadline_request = goal_request(
                aggregate,
                binding,
                suffix="deadline",
                first_tick_at="2026-08-11T01:59:00+00:00",
            )
            scheduler.create_goal(deadline_request)
            stopped = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-11T02:00:00+00:00",
            )
            self.assertEqual(stopped["stop_reason"], "goal-deadline-expired")
            lease_id = aggregate["initial_binding"][
                "runtime_lease_ref"
            ].removeprefix("lease:")
            lease = controller._coordination.records["runtime_leases"][lease_id]
            lease["status"] = "released"
            lease["released_at"] = "2026-08-11T02:00:01+00:00"
            lease["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in lease.items()
                    if key != "content_sha256"
                }
            )
            inactive_authority = goal_request(
                aggregate,
                binding,
                suffix="inactive-authority",
                created_at="2026-08-11T02:00:02+00:00",
                first_tick_at="2026-08-11T02:01:00+00:00",
                deadline_at="2026-08-11T03:00:00+00:00",
            )
            with self.assertRaises(ProtocolError):
                scheduler.create_goal(inactive_authority)

        with test_workspace("sf205-authority-expiry") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                _,
                _,
                scheduler,
            ) = scheduler_fixture(workspace)
            authority_request = goal_request(
                aggregate,
                binding,
                suffix="authority",
                first_tick_at="2026-08-12T01:00:00+00:00",
                deadline_at="2026-08-12T01:30:00+00:00",
                elapsed_seconds_limit=3600,
            )
            scheduler.create_goal(authority_request)
            stopped = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-12T01:00:00+00:00",
            )
            self.assertEqual(stopped["stop_reason"], "authority-expired")

    def test_elapsed_and_continuation_budgets_stop_before_another_tick(
        self,
    ) -> None:
        with test_workspace("sf205-budget-kinds") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                _,
                session,
                scheduler,
            ) = scheduler_fixture(workspace)
            continuation_request = goal_request(
                aggregate,
                binding,
                suffix="continuation-budget",
                continuation_limit=1,
            )
            scheduler.create_goal(continuation_request)
            submitted = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-11T01:09:00+00:00",
            )
            session.execute_once(
                owner_id="session-controller",
                at="2026-08-11T01:09:01+00:00",
            )
            scheduler.record_result(
                submitted["tick_id"],
                tokens_used=10,
                elapsed_seconds_used=5,
                at="2026-08-11T01:09:02+00:00",
            )
            self.assertEqual(
                scheduler.get_goal(continuation_request["goal_id"])[
                    "stop_reason"
                ],
                "continuation-budget-exhausted",
            )

            elapsed_request = goal_request(
                aggregate,
                binding,
                suffix="elapsed-budget",
                created_at="2026-08-11T01:10:00+00:00",
                first_tick_at="2026-08-11T01:11:00+00:00",
                deadline_at="2026-08-11T03:00:00+00:00",
                elapsed_seconds_limit=30,
            )
            scheduler.create_goal(elapsed_request)
            stopped = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(
                stopped["stop_reason"],
                "elapsed-budget-exhausted",
            )

    def test_expired_claim_becomes_uncertain_and_is_not_replayed(self) -> None:
        def interrupt_after_submit(_: dict) -> None:
            raise SystemExit("simulated process loss")

        with test_workspace("sf205-uncertain") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
                scheduler,
            ) = scheduler_fixture(
                workspace,
                after_submit_hook=interrupt_after_submit,
            )
            request = goal_request(aggregate, binding)
            scheduler.create_goal(request)
            with self.assertRaises(SystemExit):
                scheduler.run_due(
                    owner_id="scheduler-one",
                    at="2026-08-11T01:09:00+00:00",
                )
            tick = scheduler.get_tick(
                "continuation-tick-"
                + canonical_sha256(
                    [request["schedule_id"], request["schedule"]["first_tick_at"]]
                )[:24]
            )
            self.assertEqual(tick["status"], "claimed")

            reopened = reopen_scheduler(
                workspace,
                controller=controller,
                session=session,
                binding=binding,
            )
            uncertain = reopened.run_due(
                owner_id="scheduler-two",
                at="2026-08-11T01:09:31+00:00",
            )
            self.assertEqual(uncertain["status"], "uncertain")
            self.assertEqual(
                reopened.get_goal(request["goal_id"])["stop_reason"],
                "uncertain-tick",
            )
            self.assertEqual(
                sum(
                    record["command"]["operation"] == "prompt"
                    for record in session.list(run_id=request["run_id"])
                ),
                1,
            )
            self.assertEqual(
                len(session.list(run_id=request["run_id"])),
                2,
            )

    def test_late_cancelled_result_preserves_terminal_goal(self) -> None:
        with test_workspace("sf205-terminal-result") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                _,
                session,
                scheduler,
            ) = scheduler_fixture(workspace)
            request = goal_request(aggregate, binding)
            scheduler.create_goal(request)
            submitted = scheduler.run_due(
                owner_id="scheduler",
                at="2026-08-11T01:09:00+00:00",
            )
            with self.assertRaisesRegex(
                MutationConflictError,
                "in-flight tick",
            ):
                scheduler.complete(
                    request["goal_id"],
                    at="2026-08-11T01:09:00.500000+00:00",
                )
            cancelled_goal = scheduler.cancel(
                request["goal_id"],
                at="2026-08-11T01:09:01+00:00",
            )
            cancel_control = control_command(
                controller.get(request["run_id"]),
                binding,
                "cancel",
                index=503,
                requested_by="founder",
                at="2026-08-11T01:09:02+00:00",
            )
            session.submit(cancel_control)
            self.assertEqual(
                session.get(submitted["session_control_id"])["status"],
                "cancelled",
            )
            result = scheduler.record_result(
                submitted["tick_id"],
                tokens_used=0,
                elapsed_seconds_used=0,
                at="2026-08-11T01:09:03+00:00",
            )
            self.assertEqual(result["status"], "rejected")
            self.assertEqual(
                scheduler.get_goal(request["goal_id"]),
                cancelled_goal,
            )

    def test_history_and_heartbeat_row_tampering_fails_closed(self) -> None:
        with test_workspace("sf205-integrity") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                _,
                _,
                scheduler,
            ) = scheduler_fixture(workspace)
            request = goal_request(aggregate, binding)
            scheduler.create_goal(request)
            with scheduler._connection() as connection:
                connection.execute(
                    "DROP TRIGGER continuation_goal_history_no_update"
                )
                connection.execute(
                    """
                    UPDATE continuation_goal_history SET operation = ?
                    WHERE goal_id = ? AND record_version = 1
                    """,
                    ("tampered-operation", request["goal_id"]),
                )
                connection.commit()
            with self.assertRaisesRegex(ProtocolError, "history"):
                scheduler.get_goal(request["goal_id"])
            with scheduler._connection() as connection:
                connection.execute(
                    """
                    UPDATE continuation_goal_history SET operation = ?
                    WHERE goal_id = ? AND record_version = 1
                    """,
                    ("create", request["goal_id"]),
                )
                connection.commit()
            scheduler.initialize()

            heartbeat = scheduler.list_heartbeats(request["goal_id"])[0]
            with scheduler._connection() as connection:
                connection.execute(
                    "DROP TRIGGER continuation_heartbeats_no_update"
                )
                connection.execute(
                    """
                    UPDATE continuation_heartbeats SET observed_at = ?
                    WHERE heartbeat_id = ?
                    """,
                    (
                        "2026-08-11T01:08:31+00:00",
                        heartbeat["heartbeat_id"],
                    ),
                )
                connection.commit()
            with self.assertRaisesRegex(ProtocolError, "heartbeat row"):
                scheduler.list_heartbeats(request["goal_id"])


if __name__ == "__main__":
    unittest.main()
