from __future__ import annotations

import copy
import json
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations._common import canonical_json
from elder_protocol.factory_operations.api_reconciliation import (
    OperationsApiReconciler,
    mutation_identity_source,
)
from elder_protocol.factory_operations.journal import (
    validate_mutation_coverage,
    validate_mutation_source_coverage,
    validate_source_registry,
)
from elder_protocol.factory_operations.run_controller import (
    derive_run_identities,
)
from tests._support import test_workspace
from tests.component import test_product_factory_registry as product_tests
from tests.component import test_run_controller as run_tests


class OperationsApiReconciliationComponentTests(unittest.TestCase):
    @staticmethod
    def _context(
        *,
        payload: dict,
        path: dict,
        project_id: str = "product-one",
        actor: str = "founder",
    ) -> tuple[dict, dict]:
        return (
            {
                "path": path,
                "body": {
                    "project_id": project_id,
                    "actor_identity_id": actor,
                    "payload": payload,
                },
            },
            {"identity_id": actor},
        )

    def test_identity_derivation_covers_all_sixteen_mutation_routes(
        self,
    ) -> None:
        configuration = {
            "version": "1.0.0",
            "project_id": "product-one",
            "repository_root": "C:\\repo\\product-one\\nested\\..",
            "profile_path": ".elder/project-profile.json",
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [],
        }
        specification = {
            "project_id": "product-one",
            "work_item_id": "work-item-one",
        }
        envelope = {
            "signal_id": "signal-one",
            "integration_id": "github-one",
            "idempotency_key": "signal-key-one",
        }
        transition = {"command_id": "transition-one", "payload": {}}
        dispatch_submission = {
            "command": {
                "command_id": "command-one",
                "project_id": "product-one",
            }
        }
        run_submission = {
            "dispatch_id": "dispatch-one",
            "dispatch_sha256": "1" * 64,
            "child_run": {"project_id": "product-one"},
            "work_item": {"revision_id": "revision-one"},
            "source": {
                "revision": "a" * 40,
                "repository_root": "C:\\repo\\product-one",
            },
        }
        lifecycle_command = {"command_id": "run-command-one"}
        checkpoint_reference = {
            "id": "checkpoint-reference-one",
            "checkpoint_sha256": "2" * 64,
        }
        artifact_reference = {
            "id": "artifact-reference-one",
            "content_sha256": "3" * 64,
        }
        cases = {
            "product-register": (
                {
                    "operation": "product-register",
                    "configuration": configuration,
                },
                {},
                {
                    "project_id",
                    "configuration_sha256",
                    "actor_identity_id",
                },
                "product-factory-product-one",
            ),
            "product-update": (
                {
                    "operation": "product-update",
                    "configuration": configuration,
                    "expected_version": 1,
                    "reason": "update",
                },
                {"factory_id": "product-factory-product-one"},
                {
                    "factory_id",
                    "expected_version",
                    "configuration_sha256",
                    "actor_identity_id",
                    "reason_sha256",
                },
                "product-factory-product-one",
            ),
            "product-activate": (
                {
                    "operation": "product-activate",
                    "expected_version": 1,
                },
                {"factory_id": "product-factory-product-one"},
                {
                    "factory_id",
                    "expected_version",
                    "actor_identity_id",
                },
                "product-factory-product-one",
            ),
            "product-pause": (
                {
                    "operation": "product-pause",
                    "expected_version": 2,
                    "reason": "pause",
                },
                {"factory_id": "product-factory-product-one"},
                {
                    "factory_id",
                    "expected_version",
                    "actor_identity_id",
                    "reason_sha256",
                },
                "product-factory-product-one",
            ),
            "product-archive": (
                {
                    "operation": "product-archive",
                    "expected_version": 3,
                    "decision": "archive",
                },
                {"factory_id": "product-factory-product-one"},
                {
                    "factory_id",
                    "expected_version",
                    "actor_identity_id",
                    "decision_sha256",
                },
                "product-factory-product-one",
            ),
            "signal-ingest": (
                {"operation": "signal-ingest", "envelope": envelope},
                {},
                {
                    "signal_id",
                    "integration_id",
                    "idempotency_key",
                    "request_sha256",
                },
                "signal-one",
            ),
            "work-item-create": (
                {
                    "operation": "work-item-create",
                    "specification": specification,
                    "change_reason": "create",
                },
                {},
                {
                    "work_item_id",
                    "specification_sha256",
                    "actor_identity_id",
                    "change_reason_sha256",
                },
                "work-item-one",
            ),
            "work-item-create-from-signal": (
                {
                    "operation": "work-item-create-from-signal",
                    "specification": specification,
                    "change_reason": "convert",
                },
                {"signal_id": "signal-one"},
                {
                    "signal_id",
                    "work_item_id",
                    "specification_sha256",
                    "actor_identity_id",
                },
                "work-item-one",
            ),
            "work-item-update": (
                {
                    "operation": "work-item-update",
                    "specification": specification,
                    "expected_version": 1,
                    "change_reason": "update",
                },
                {"work_item_id": "work-item-one"},
                {
                    "work_item_id",
                    "expected_version",
                    "specification_sha256",
                    "actor_identity_id",
                },
                "work-item-one",
            ),
            "transition-apply": (
                {
                    "operation": "transition-apply",
                    "command": transition,
                },
                {"work_item_id": "work-item-one"},
                {"command_id", "command_sha256"},
                "work-item-one",
            ),
            "dispatch-submit": (
                {
                    "operation": "dispatch-submit",
                    "submission": dispatch_submission,
                },
                {},
                {"dispatch_id", "command_id", "submission_sha256"},
                (
                    "dispatch-"
                    + canonical_sha256("command-one")[:32]
                ),
            ),
            "dispatch-cancel": (
                {
                    "operation": "dispatch-cancel",
                    "reason": "cancel",
                    "owner_id": None,
                    "lease_generation": None,
                },
                {"dispatch_id": "dispatch-one"},
                {
                    "dispatch_id",
                    "requested_by_identity_id",
                    "reason_sha256",
                },
                "dispatch-one",
            ),
            "run-bind-start": (
                {
                    "operation": "run-bind-start",
                    "submission": run_submission,
                },
                {},
                {
                    "dispatch_id",
                    "submission_sha256",
                    "binding_seed_sha256",
                },
                derive_run_identities(
                    dispatch_id=run_submission["dispatch_id"],
                    dispatch_sha256=run_submission["dispatch_sha256"],
                    project_id="product-one",
                    work_item_revision_id="revision-one",
                    source_revision="a" * 40,
                    repository_root="C:\\repo\\product-one",
                )["run_id"],
            ),
            "run-lifecycle-apply": (
                {
                    "operation": "run-lifecycle-apply",
                    "command": lifecycle_command,
                },
                {"run_id": "run-one"},
                {"command_id", "command_sha256"},
                "run-one",
            ),
            "run-checkpoint-reference": (
                {
                    "operation": "run-checkpoint-reference",
                    "command": lifecycle_command,
                    "reference": checkpoint_reference,
                },
                {"run_id": "run-one"},
                {
                    "command_id",
                    "reference_id",
                    "checkpoint_sha256",
                },
                "run-one",
            ),
            "run-artifact-reference": (
                {
                    "operation": "run-artifact-reference",
                    "command": lifecycle_command,
                    "reference": artifact_reference,
                },
                {"run_id": "run-one"},
                {
                    "command_id",
                    "reference_id",
                    "content_sha256",
                },
                "run-one",
            ),
        }
        self.assertEqual(len(cases), 16)
        for route_id, (payload, path, fields, subject) in cases.items():
            with self.subTest(route_id=route_id):
                context, auth = self._context(
                    payload=payload,
                    path=path,
                )
                identity, resolved_subject = mutation_identity_source(
                    route_id,
                    context=context,
                    auth=auth,
                )
                self.assertEqual(set(identity), fields)
                self.assertEqual(resolved_subject, subject)

    def test_source_coverage_enforces_order_and_write_site_cardinality(
        self,
    ) -> None:
        coverage = validate_mutation_coverage()
        source_registry = validate_source_registry()
        branches = {
            item["branch_id"]: item for item in coverage["branches"]
        }
        sources = {
            item["id"]: item for item in source_registry["sources"]
        }

        exact_branch = branches["work-item.create-from-signal"]
        validate_mutation_source_coverage(
            branch=exact_branch,
            actual_source_ids=list(exact_branch["source_ids"]),
            source_by_id=sources,
        )
        with self.assertRaisesRegex(
            ProtocolError,
            "append order|exact registered source sequence",
        ):
            validate_mutation_source_coverage(
                branch=exact_branch,
                actual_source_ids=list(reversed(exact_branch["source_ids"])),
                source_by_id=sources,
            )

        variable_branch = branches["run.lifecycle-apply"]
        required = sorted(
            [
                "run-lifecycle-commands",
                "run-lifecycle-results",
                "run-command-authorizations",
            ],
            key=lambda source_id: (
                sources[source_id]["append_order"],
                source_id,
            ),
        )
        validate_mutation_source_coverage(
            branch=variable_branch,
            actual_source_ids=required,
            source_by_id=sources,
        )
        with self.assertRaisesRegex(
            ProtocolError,
            "run-command-authorizations.*expected 1",
        ):
            validate_mutation_source_coverage(
                branch=variable_branch,
                actual_source_ids=[
                    source_id
                    for source_id in required
                    if source_id != "run-command-authorizations"
                ],
                source_by_id=sources,
            )

    def test_reconstructs_product_and_run_bind_from_immutable_batches(
        self,
    ) -> None:
        with test_workspace("sf107-api-reconcile-product") as workspace:
            helper = product_tests.ProductFactoryRegistryComponentTests(
                methodName="runTest"
            )
            repository, _, _ = helper._repository(
                workspace,
                "product-one",
            )
            registry = helper._registry(workspace)
            configuration = helper._configuration(
                repository,
                "product-one",
            )
            product = registry.register(
                configuration,
                actor_identity_id="founder",
                at="2026-08-12T00:10:00+00:00",
            )
            context, auth = self._context(
                payload={
                    "operation": "product-register",
                    "configuration": configuration,
                },
                path={},
            )
            reconstructed = OperationsApiReconciler(
                workspace / "operations.db"
            ).reconstruct(
                route_id="product-register",
                context=context,
                auth=auth,
            )
            self.assertEqual(reconstructed.record, product)
            self.assertEqual(
                reconstructed.primary_source["record_version"],
                1,
            )

            tampered_context = dict(reconstructed.journal_context)
            tampered_context["expected_result_versions_json"] = (
                canonical_json(
                    {"product-factory-product-one": 2}
                )
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "canonical coverage inputs",
            ):
                OperationsApiReconciler(
                    workspace / "operations.db"
                )._validate_batch(
                    context=tampered_context,
                    stored_identity={
                        "project_id": "product-one",
                        "configuration_sha256": canonical_sha256(
                            configuration
                        ),
                        "actor_identity_id": "founder",
                    },
                    entries=reconstructed.entries,
                )

            tampered_identity_context = dict(
                reconstructed.journal_context
            )
            mutation_identity = copy.deepcopy(
                json.loads(
                    tampered_identity_context["mutation_identity_json"]
                )
            )
            mutation_identity["project_id"] = "different-project"
            tampered_identity_context["mutation_identity_json"] = (
                canonical_json(mutation_identity)
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "canonical coverage inputs",
            ):
                OperationsApiReconciler(
                    workspace / "operations.db"
                )._validate_batch(
                    context=tampered_identity_context,
                    stored_identity={
                        "project_id": "product-one",
                        "configuration_sha256": canonical_sha256(
                            configuration
                        ),
                        "actor_identity_id": "founder",
                    },
                    entries=reconstructed.entries,
                )

        with test_workspace("sf107-api-reconcile-run-bind") as workspace:
            helper = run_tests.RunControllerComponentTests(
                methodName="runTest"
            )
            controller, submission, _ = helper._controller_fixture(
                workspace
            )
            service_result = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            expected = copy.deepcopy(service_result)
            expected.pop("command_result")
            context, auth = self._context(
                payload={
                    "operation": "run-bind-start",
                    "submission": submission,
                },
                path={},
                actor=submission["child_run"]["identity_id"],
            )
            reconstructed = OperationsApiReconciler(
                controller.path
            ).reconstruct(
                route_id="run-bind-start",
                context=context,
                auth=auth,
            )
            self.assertEqual(reconstructed.record, expected)


if __name__ == "__main__":
    unittest.main()
