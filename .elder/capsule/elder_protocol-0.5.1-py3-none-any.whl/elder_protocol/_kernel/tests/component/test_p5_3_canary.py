from __future__ import annotations

import base64
import copy
import hashlib
import inspect
import json
import unittest
from datetime import UTC, datetime, timedelta
from unittest.mock import Mock, patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

import elder_protocol.canary as canary_runtime
from elder_protocol.autonomy import (
    calculate_effective_autonomy,
    canonical_sha256,
    consume_qualification,
    validate_autonomy_class_registry,
)
from elder_protocol.autonomy_runtime import (
    match_autonomy_work_item,
    replay_certification,
    simulate_autonomy_work_item,
)
from elder_protocol.canary import (
    SQLiteCanaryExecutionStore,
    canonical_p5_3_readiness,
    create_canary_execution_packet,
    create_canary_rollback_packet,
    evaluate_canary_observation,
    execute_canary,
    execute_canary_rollback,
    issue_canary_lease,
    process_canary_observation,
    simulate_canary_plan,
    sweep_due_canary_deadlines,
)
from elder_protocol.constants import PROTOCOL_DIR
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from tests._support import test_workspace
from tests.component import test_p5_0_autonomy as p50
from tests.component import test_p5_1_p5_2_autonomy as p52
from tests.component.test_p4_7_qualification import (
    qualification_policy,
    signed_record,
    simple_maturity,
    write_bundle,
)


def finalize(record: dict) -> dict:
    record.pop("content_sha256", None)
    record["content_sha256"] = canonical_sha256(record)
    return record


def sign_statement(
    record: dict,
    private_key: Ed25519PrivateKey,
) -> dict:
    statement = json.dumps(
        record,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    record["attestation"] = {
        "signer_id": "verifier-key-1",
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement)
        ).decode("ascii"),
    }
    return finalize(record)


class RecordingCanaryProvider:
    def __init__(
        self,
        *,
        started_at: datetime,
        response_overrides: dict | None = None,
        rollback_overrides: dict | None = None,
    ) -> None:
        self.started_at = started_at
        self.response_overrides = response_overrides or {}
        self.rollback_overrides = rollback_overrides or {}
        self.packet: dict | None = None
        self.rollback_packet: dict | None = None

    def start_canary(self, packet: dict) -> dict:
        self.packet = packet
        response = {
            "authorized_packet_sha256": packet["content_sha256"],
            "provider": packet["provider"],
            "target": packet["target"],
            "environment": packet["environment"],
            "artifact_sha256": packet["artifact_sha256"],
            "rollback_artifact_sha256": packet["rollback_artifact_sha256"],
            "traffic_percent": packet["traffic"]["initial_percent"],
            "deployment_id": packet["deployment_id"],
            "url": packet["canary_url_prefix"] + packet["deployment_id"],
            "started_at": self.started_at.isoformat(),
            "status": "observing",
        }
        response.update(self.response_overrides)
        return response

    def rollback_canary(self, packet: dict) -> dict:
        self.rollback_packet = packet
        completed_at = datetime.fromisoformat(
            packet["requested_at"]
        ) + timedelta(minutes=1)
        response = {
            "authorized_rollback_sha256": packet["content_sha256"],
            "provider": packet["provider"],
            "target": packet["target"],
            "deployment_id": packet["deployment_id"],
            "artifact_sha256": packet["rollback_artifact_sha256"],
            "completed_at": completed_at.isoformat(),
            "status": "rolled-back",
        }
        response.update(self.rollback_overrides)
        return response


class P53CanaryComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.runtime_now = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        self._runtime_clock_patcher = patch(
            "elder_protocol.canary._utc_now",
            side_effect=lambda: self.runtime_now,
        )
        self._runtime_clock_patcher.start()
        self.addCleanup(self._runtime_clock_patcher.stop)
        self.change_classes = load_json(PROTOCOL_DIR / "change-classes.json")
        canary_class = copy.deepcopy(
            load_json(PROTOCOL_DIR / "autonomy-classes.json")["classes"][3]
        )
        canary_class.update(
            {
                "id": "fixture-canary-release",
                "maximum_autonomy": "L3",
                "allowed_consequences": ["pull-request", "canary"],
                "description": (
                    "Modify one certified service path and permit only a bounded "
                    "L3 canary consequence."
                ),
                "allowed_operations": ["modify"],
                "scope": {
                    "requires_path_allowlist": True,
                    "allowed_path_globs": ["src/service.py"],
                    "forbidden_path_globs": ["protocol/**", ".elder/**"],
                    "new_files_only": False,
                    "generated_files_only": False,
                    "existing_files_unchanged": False,
                    "generator_inputs_unchanged": True,
                    "production_code_unchanged": False,
                    "test_support_unchanged": True,
                },
                "controls": {
                    "requires_tool_allowlist": True,
                    "requires_pinned_tool_digest": False,
                    "requires_rule_allowlist": False,
                    "semantic_equivalence": "none",
                    "required_checks": [
                        "foundation tests",
                        "component tests",
                        "independent evaluation",
                    ],
                    "forbidden_effects": [
                        "merge",
                        "deployment",
                        "maturity-mutation",
                    ],
                },
            }
        )
        self.registry = {
            "version": "0.5.1",
            "id": "elder-project-autonomy-classes-v1",
            "classes": [canary_class],
        }
        self._authority_source: dict | None = None
        self._authority_source_patcher = patch(
            "elder_protocol.autonomy_runtime._load_canonical_autonomy_authority",
            side_effect=self._load_fixture_authority,
        )
        self._authority_source_patcher.start()
        self.addCleanup(self._authority_source_patcher.stop)
        self._execution_store: SQLiteCanaryExecutionStore | None = None
        self._execution_store_patcher = patch(
            "elder_protocol.canary._canonical_canary_execution_store",
            side_effect=self._load_execution_store,
        )
        self._execution_store_patcher.start()
        self.addCleanup(self._execution_store_patcher.stop)
        self._real_deadline_scheduler = (
            canary_runtime._schedule_canary_deadline
        )
        self._deadline_scheduler_patcher = patch(
            "elder_protocol.canary._schedule_canary_deadline"
        )
        self.deadline_scheduler = self._deadline_scheduler_patcher.start()
        self.addCleanup(self._deadline_scheduler_patcher.stop)

    def _load_execution_store(self) -> SQLiteCanaryExecutionStore:
        if self._execution_store is None:
            raise ProtocolError(
                "Fixture canonical canary execution store is not configured."
            )
        return self._execution_store

    def use_execution_store(
        self,
        workspace,
        name: str = "canary-executions.db",
    ) -> SQLiteCanaryExecutionStore:
        self._execution_store = SQLiteCanaryExecutionStore(workspace / name)
        return self._execution_store

    def sweep_at(
        self,
        provider: RecordingCanaryProvider,
        *,
        at: datetime,
    ) -> list[dict]:
        with patch.object(
            canary_runtime,
            "_utc_now",
            return_value=at,
        ):
            return sweep_due_canary_deadlines(provider)

    def _load_fixture_authority(self, project_id: str) -> tuple[dict, dict]:
        if self._authority_source is None:
            raise ProtocolError("Fixture canonical authority source is not configured.")
        matches = [
            project
            for project in self._authority_source["projects"]
            if project["project_id"] == project_id and project["status"] == "active"
        ]
        if len(matches) != 1:
            raise ProtocolError("Fixture project has no canonical authority source.")
        return self._authority_source, matches[0]

    def l3_context(self, workspace, *, evaluated_at: datetime) -> dict:
        private_key = Ed25519PrivateKey.generate()
        maturity = simple_maturity()
        hosted_policy = qualification_policy(private_key)
        required_gates = [
            f"{level}-{kind}"
            for level in ["l0", "l1", "l2", "l3"]
            for kind in ["capability", "evidence"]
        ]
        records = [
            signed_record(
                workspace,
                private_key,
                gate_id=gate_id,
                index=index,
                issued_at=evaluated_at - timedelta(hours=1),
            )
            for index, gate_id in enumerate(required_gates, start=1)
        ]
        manifest = write_bundle(
            workspace,
            records,
            private_key,
            issued_at=evaluated_at - timedelta(hours=1),
            target_level="L3",
        )
        policy = p50.fixture_autonomy_policy(hosted_policy, maturity)
        state_checks = {
            name: {"checked_at": evaluated_at.isoformat(), "present": False}
            for name in ["contradiction", "suspension", "revocation"]
        }
        consumption = consume_qualification(
            manifest,
            hosted_policy,
            maturity,
            policy,
            project_id="fixture-project",
            environment="production",
            artifact_sha256="a" * 64,
            requested_level="L3",
            state_checks=state_checks,
            at=evaluated_at.isoformat(),
        )
        return {
            "private_key": private_key,
            "maturity_model": maturity,
            "qualification_policy": hosted_policy,
            "policy": policy,
            "state_checks": state_checks,
            "manifest": manifest,
            "consumption": consumption,
            "artifact_sha256": "a" * 64,
        }

    def authority_chain(self, workspace, *, evaluated_at: datetime) -> dict:
        context = self.l3_context(workspace, evaluated_at=evaluated_at)
        certification = p50.certification(
            context["consumption"],
            issued_at=evaluated_at - timedelta(minutes=5),
        )
        certification["autonomy_class_id"] = "fixture-canary-release"
        certification["certification_level"] = "L3"
        certification["scope_paths"] = ["src/service.py"]
        finalize(certification)
        budget = p50.incident_budget(
            started_at=evaluated_at - timedelta(minutes=5)
        )
        budget["autonomy_class_id"] = "fixture-canary-release"
        finalize(budget)
        work_item = finalize(
            {
                "version": "0.5.1",
                "work_item_id": "canary-release-001",
                "project_id": "fixture-project",
                "parent_change_class": "internal-code",
                "autonomy_class_id": "fixture-canary-release",
                "objective": (
                    "Release the exact certified service revision through a "
                    "bounded production canary."
                ),
                "changes": [
                    {
                        "path": "src/service.py",
                        "operation": "modify",
                        "existed_before": True,
                        "generated": False,
                        "production_code": True,
                        "test_support": False,
                        "generator_input": False,
                        "fixture": False,
                        "snapshot": False,
                        "configuration": False,
                        "before_sha256": "1" * 64,
                        "after_sha256": "2" * 64,
                    }
                ],
                "tool": {
                    "id": "text-editor",
                    "digest_sha256": None,
                    "rule_ids": [],
                },
                "checks": [
                    {
                        "name": name,
                        "status": "passed",
                        "evidence": [f"evidence:{index}"],
                    }
                    for index, name in enumerate(
                        [
                            "foundation tests",
                            "component tests",
                            "independent evaluation",
                        ],
                        start=1,
                    )
                ],
                "observed_effects": [],
                "generator_inputs_unchanged": True,
                "semantic_equivalence": {
                    "mode": "none",
                    "status": "not-required",
                    "evidence": [],
                },
                "evidence_plan": [
                    "Verify the ordered test ladder and independent evaluation."
                ],
            }
        )
        match = match_autonomy_work_item(
            work_item,
            self.registry,
            certification=certification,
            policy=context["policy"],
        )
        simulation = simulate_autonomy_work_item(
            work_item,
            self.registry,
            certification=certification,
            policy=context["policy"],
        )
        effective = calculate_effective_autonomy(
            context["policy"],
            self.registry,
            self.change_classes,
            project_id=work_item["project_id"],
            project_autonomy_ceiling="L3",
            autonomy_class_id=work_item["autonomy_class_id"],
            certification=certification,
            qualification_consumption=context["consumption"],
            incident_budget=budget,
            suspensions=[],
            revocations=[],
            at=evaluated_at.isoformat(),
        )
        issued = p52.event(
            certification,
            sequence=1,
            event_type="issued",
            occurred_at=evaluated_at - timedelta(minutes=5),
            previous=None,
            payload={
                "certification_sha256": certification["content_sha256"],
                "initial_status": "candidate",
            },
        )
        activated = p52.event(
            certification,
            sequence=2,
            event_type="activated",
            occurred_at=evaluated_at - timedelta(minutes=4),
            previous=issued["content_sha256"],
            payload={
                "qualification_consumption_sha256": context["consumption"][
                    "content_sha256"
                ]
            },
        )
        events = [issued, activated]
        replay = replay_certification(
            certification,
            self.registry["classes"][0],
            events,
            policy=context["policy"],
            at=evaluated_at.isoformat(),
        )
        chain = {
            "context": context,
            "policy": context["policy"],
            "work_item": work_item,
            "certification": certification,
            "budget": budget,
            "match": match,
            "simulation": simulation,
            "effective": effective,
            "certification_events": events,
            "certification_replay": replay,
            "consumption": context["consumption"],
        }
        chain["authority_source"] = {
            "version": "0.5.1",
            "id": "elder-canonical-autonomy-authority-source-v1",
            "projects": [
                {
                    "project_id": work_item["project_id"],
                    "project_autonomy_ceiling": "L3",
                    "autonomy_policy_sha256": canonical_sha256(chain["policy"]),
                    "autonomy_classes_sha256": canonical_sha256(self.registry),
                    "change_classes_sha256": canonical_sha256(
                        self.change_classes
                    ),
                    "qualification_policy_sha256": canonical_sha256(
                        context["qualification_policy"]
                    ),
                    "maturity_model_sha256": canonical_sha256(
                        context["maturity_model"]
                    ),
                    "status": "active",
                }
            ],
        }
        self._authority_source = chain["authority_source"]
        chain["authority_evidence"] = p52.signed_authority_evidence(
            context["private_key"],
            chain=chain,
            registry=self.registry,
            change_classes=self.change_classes,
            evaluated_at=evaluated_at,
            project_autonomy_ceiling="L3",
        )
        chain["plan"] = finalize(
            {
                "version": "0.5.1",
                "plan_id": "CANARY-PLAN-001",
                "project_id": work_item["project_id"],
                "work_item_id": work_item["work_item_id"],
                "autonomy_class_id": work_item["autonomy_class_id"],
                "certification_id": certification["certification_id"],
                "qualification_consumption_sha256": context["consumption"][
                    "content_sha256"
                ],
                "artifact_sha256": context["artifact_sha256"],
                "rollback_artifact_sha256": "b" * 64,
                "environment": "production",
                "target": "apps/fixture-service",
                "traffic": {
                    "initial_percent": 2,
                    "maximum_percent": 10,
                    "step_percent": 2,
                },
                "timing": {
                    "observation_window_minutes": 5,
                    "maximum_duration_minutes": 30,
                },
                "health": {
                    "minimum_sample_count": 100,
                    "maximum_error_rate": 0.02,
                    "maximum_p95_latency_ms": 500,
                    "minimum_success_rate": 0.98,
                },
                "rollback": {
                    "automatic": True,
                    "maximum_minutes": 10,
                    "require_immutable_predecessor": True,
                },
                "evidence": ["plan-review:CANARY-PLAN-001"],
            }
        )
        chain["canary_simulation"] = simulate_canary_plan(
            chain["plan"], chain["policy"]
        )
        chain["canary_authority_evidence"] = self.canary_authority_evidence(
            chain,
            authority_evidence=chain["authority_evidence"],
            evaluated_at=evaluated_at,
        )
        return chain

    def canary_authority_evidence(
        self,
        chain: dict,
        *,
        authority_evidence: dict,
        evaluated_at: datetime,
    ) -> dict:
        plan = chain["plan"]
        return sign_statement(
            {
                "version": "0.5.1",
                "evidence_id": "CANARY-AUTHORITY-001",
                "authority_evidence_sha256": authority_evidence[
                    "content_sha256"
                ],
                "plan_sha256": plan["content_sha256"],
                "project_id": plan["project_id"],
                "autonomy_class_id": plan["autonomy_class_id"],
                "certification_id": plan["certification_id"],
                "target": plan["target"],
                "rollback_artifact_sha256": plan[
                    "rollback_artifact_sha256"
                ],
                "traffic": copy.deepcopy(plan["traffic"]),
                "timing": copy.deepcopy(plan["timing"]),
                "health": copy.deepcopy(plan["health"]),
                "rollback": copy.deepcopy(plan["rollback"]),
                "provider": "fixture-ci",
                "producer_identity": "fixture-autonomy-governance-service",
                "source_uri": (
                    "https://ci.example.test/governance/canary/001"
                ),
                "issued_at": evaluated_at.isoformat(),
                "expires_at": (
                    evaluated_at + timedelta(minutes=15)
                ).isoformat(),
            },
            chain["context"]["private_key"],
        )

    def provider_evidence(
        self,
        chain: dict,
        *,
        evaluated_at: datetime,
    ) -> dict:
        plan = chain["plan"]
        return sign_statement(
            {
                "version": "0.5.1",
                "evidence_id": "CANARY-PROVIDER-001",
                "plan_sha256": plan["content_sha256"],
                "project_id": plan["project_id"],
                "provider": "fixture-ci",
                "target": plan["target"],
                "deployment_id": "deploy-001",
                "canary_url_prefix": (
                    "https://deploy.example.test/apps/"
                    "fixture-service/canaries/"
                ),
                "environment": plan["environment"],
                "artifact_sha256": plan["artifact_sha256"],
                "rollback_artifact_sha256": plan[
                    "rollback_artifact_sha256"
                ],
                "traffic": copy.deepcopy(plan["traffic"]),
                "timing": copy.deepcopy(plan["timing"]),
                "health": copy.deepcopy(plan["health"]),
                "rollback": copy.deepcopy(plan["rollback"]),
                "controls": {
                    control: "verified"
                    for control in chain["policy"]["canary"][
                        "provider_evidence_required_controls"
                    ]
                },
                "producer_identity": "fixture-canary-provider-service",
                "source_uri": (
                    "https://ci.example.test/canary/provider/CANARY-PLAN-001"
                ),
                "issued_at": evaluated_at.isoformat(),
                "expires_at": (
                    evaluated_at + timedelta(minutes=15)
                ).isoformat(),
            },
            chain["context"]["private_key"],
        )

    def issue_lease(self, chain: dict, *, evaluated_at: datetime, **overrides) -> dict:
        context = chain["context"]
        arguments = {
            "plan": chain["plan"],
            "canary_simulation_report": chain["canary_simulation"],
            "work_item": chain["work_item"],
            "registry": self.registry,
            "change_classes": self.change_classes,
            "project_autonomy_ceiling": "L3",
            "certification": chain["certification"],
            "certification_events": chain["certification_events"],
            "certification_replay_report": chain["certification_replay"],
            "qualification_consumption": chain["consumption"],
            "incident_budget": chain["budget"],
            "suspensions": [],
            "revocations": [],
            "authority_evidence": chain["authority_evidence"],
            "canary_authority_evidence": chain[
                "canary_authority_evidence"
            ],
            "qualification_manifest_path": context["manifest"],
            "qualification_policy": context["qualification_policy"],
            "maturity_model": context["maturity_model"],
            "qualification_state_checks": context["state_checks"],
            "artifact_sha256": context["artifact_sha256"],
            "effective_autonomy_report": chain["effective"],
            "match_report": chain["match"],
            "simulation_report": chain["simulation"],
            "at": evaluated_at.isoformat(),
        }
        arguments.update(overrides)
        return issue_canary_lease(chain["policy"], **arguments)

    def execution_arguments(
        self,
        chain: dict,
        *,
        lease: dict,
        provider_evidence: dict,
        evaluated_at: datetime,
        current_chain: dict | None = None,
    ) -> dict:
        context = chain["context"]
        current = current_chain or chain
        current_context = current["context"]
        return {
            "policy": chain["policy"],
            "plan": chain["plan"],
            "lease": lease,
            "provider_evidence": provider_evidence,
            "canary_simulation_report": chain["canary_simulation"],
            "work_item": chain["work_item"],
            "registry": self.registry,
            "change_classes": self.change_classes,
            "project_autonomy_ceiling": "L3",
            "certification": chain["certification"],
            "certification_events": chain["certification_events"],
            "certification_replay_report": chain["certification_replay"],
            "qualification_consumption": chain["consumption"],
            "incident_budget": chain["budget"],
            "suspensions": [],
            "revocations": [],
            "authority_evidence": chain["authority_evidence"],
            "canary_authority_evidence": chain[
                "canary_authority_evidence"
            ],
            "qualification_manifest_path": context["manifest"],
            "qualification_policy": context["qualification_policy"],
            "maturity_model": context["maturity_model"],
            "lease_qualification_state_checks": context["state_checks"],
            "current_qualification_state_checks": current_context[
                "state_checks"
            ],
            "current_certification_events": current[
                "certification_events"
            ],
            "current_incident_budget": current["budget"],
            "current_suspensions": current.get("suspensions", []),
            "current_revocations": current.get("revocations", []),
            "current_authority_evidence": current["authority_evidence"],
            "current_canary_authority_evidence": current[
                "canary_authority_evidence"
            ],
            "artifact_sha256": context["artifact_sha256"],
            "effective_autonomy_report": chain["effective"],
            "match_report": chain["match"],
            "simulation_report": chain["simulation"],
            "at": evaluated_at.isoformat(),
        }

    def observation(
        self,
        chain: dict,
        *,
        packet: dict,
        response: dict,
        observed_at: datetime,
        metrics: dict | None = None,
        sample_count: int = 200,
    ) -> dict:
        return sign_statement(
            {
                "version": "0.5.1",
                "observation_id": "CANARY-OBS-001",
                "authorized_packet_sha256": packet["content_sha256"],
                "provider": packet["provider"],
                "target": packet["target"],
                "deployment_id": response["deployment_id"],
                "artifact_sha256": packet["artifact_sha256"],
                "observed_at": observed_at.isoformat(),
                "sample_count": sample_count,
                "metrics": metrics
                or {
                    "error_rate": 0.01,
                    "p95_latency_ms": 300,
                    "success_rate": 0.99,
                },
                "producer_identity": "fixture-telemetry-service",
                "source_uri": (
                    "https://ci.example.test/canary/observations/CANARY-OBS-001"
                ),
            },
            chain["context"]["private_key"],
        )

    def test_l3_canary_executes_and_observation_can_only_continue_or_rollback(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-positive") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            provider_evidence = self.provider_evidence(
                chain, evaluated_at=evaluated_at
            )
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=provider_evidence,
                qualification_policy=chain["context"]["qualification_policy"],
                execution_id="EXEC-CANARY-001",
                at=evaluated_at.isoformat(),
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            self.use_execution_store(workspace)
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=provider_evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            healthy_at = evaluated_at + timedelta(minutes=5)
            healthy = self.observation(
                chain,
                packet=packet,
                response=response,
                observed_at=healthy_at,
            )
            healthy_report = evaluate_canary_observation(
                healthy,
                packet=packet,
                response=response,
                policy=chain["policy"],
                qualification_policy=chain["context"]["qualification_policy"],
                at=healthy_at.isoformat(),
            )
            healthy_workflow = process_canary_observation(
                healthy,
                provider,
                packet=packet,
                response=response,
                policy=chain["policy"],
                qualification_policy=chain["context"]["qualification_policy"],
                at=healthy_at.isoformat(),
            )
            self.assertIsNone(provider.rollback_packet)
            failed_at = evaluated_at + timedelta(minutes=6)
            failed = self.observation(
                chain,
                packet=packet,
                response=response,
                observed_at=failed_at,
                metrics={
                    "error_rate": 0.20,
                    "p95_latency_ms": 900,
                    "success_rate": 0.80,
                },
            )
            failed_report = evaluate_canary_observation(
                failed,
                packet=packet,
                response=response,
                policy=chain["policy"],
                qualification_policy=chain["context"]["qualification_policy"],
                at=failed_at.isoformat(),
            )
            self.runtime_now = failed_at
            failed_workflow = process_canary_observation(
                failed,
                provider,
                packet=packet,
                response=response,
                policy=chain["policy"],
                qualification_policy=chain["context"]["qualification_policy"],
                at=failed_at.isoformat(),
            )
            replay_packet = create_canary_rollback_packet(
                failed,
                packet=packet,
                response=response,
                observation_report=failed_report,
                policy=chain["policy"],
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                at=failed_at.isoformat(),
            )
            replay_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "canonical runtime state",
            ):
                execute_canary_rollback(
                    replay_packet,
                    replay_provider,
                    observation=failed,
                    packet=packet,
                    response=response,
                    observation_report=failed_report,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=failed_at.isoformat(),
                )
            terminal_observation = self.observation(
                chain,
                packet=packet,
                response=response,
                observed_at=evaluated_at + timedelta(minutes=7),
            )
            terminal_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "canonical runtime state",
            ):
                process_canary_observation(
                    terminal_observation,
                    terminal_provider,
                    packet=packet,
                    response=response,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=(evaluated_at + timedelta(minutes=7)).isoformat(),
                )

        self.assertIsNotNone(provider.packet)
        self.assertEqual(response["status"], "observing")
        self.assertEqual(healthy_report["status"], "continue-observing")
        self.assertTrue(healthy_report["observation_window_complete"])
        self.assertFalse(healthy_report["can_promote"])
        self.assertFalse(healthy_report["can_full_rollout"])
        self.assertEqual(healthy_workflow["status"], "continue-observing")
        self.assertFalse(healthy_workflow["rollback_performed"])
        self.assertEqual(failed_report["status"], "rollback-required")
        self.assertTrue(failed_report["rollback_required"])
        self.assertEqual(
            failed_report["threshold_breaches"],
            ["error-rate", "p95-latency", "success-rate"],
        )
        self.assertEqual(failed_workflow["status"], "rolled-back")
        self.assertTrue(failed_workflow["rollback_performed"])
        self.assertIsNotNone(provider.rollback_packet)
        self.assertIsNone(replay_provider.rollback_packet)
        self.assertIsNone(terminal_provider.rollback_packet)
        self.assertFalse(failed_workflow["can_promote"])

    def test_l2_bundle_cannot_issue_canary_authority(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-l2-denied") as workspace:
            fixture = p52.P51P52AutonomyComponentTests()
            fixture.setUp()
            self.addCleanup(fixture.doCleanups)
            chain = fixture.authority_inputs(
                workspace, evaluated_at=evaluated_at
            )
            plan = finalize(
                {
                    "version": "0.5.1",
                    "plan_id": "L2-CANARY",
                    "project_id": chain["work_item"]["project_id"],
                    "work_item_id": chain["work_item"]["work_item_id"],
                    "autonomy_class_id": chain["work_item"]["autonomy_class_id"],
                    "certification_id": chain["certification"]["certification_id"],
                    "qualification_consumption_sha256": chain["consumption"][
                        "content_sha256"
                    ],
                    "artifact_sha256": chain["context"]["artifact_sha256"],
                    "rollback_artifact_sha256": "b" * 64,
                    "environment": "production",
                    "target": "fixture-service",
                    "traffic": {
                        "initial_percent": 2,
                        "maximum_percent": 10,
                        "step_percent": 2,
                    },
                    "timing": {
                        "observation_window_minutes": 5,
                        "maximum_duration_minutes": 30,
                    },
                    "health": {
                        "minimum_sample_count": 100,
                        "maximum_error_rate": 0.02,
                        "maximum_p95_latency_ms": 500,
                        "minimum_success_rate": 0.98,
                    },
                    "rollback": {
                        "automatic": True,
                        "maximum_minutes": 10,
                        "require_immutable_predecessor": True,
                    },
                    "evidence": ["synthetic"],
                }
            )
            with self.assertRaises(ProtocolError):
                issue_canary_lease(
                    chain["policy"],
                    plan=plan,
                    canary_simulation_report=simulate_canary_plan(
                        plan, chain["policy"]
                    ),
                    work_item=chain["work_item"],
                    registry=fixture.registry,
                    change_classes=fixture.change_classes,
                    project_autonomy_ceiling="L2",
                    certification=chain["certification"],
                    certification_events=chain["certification_events"],
                    certification_replay_report=chain["certification_replay"],
                    qualification_consumption=chain["consumption"],
                    incident_budget=chain["budget"],
                    suspensions=[],
                    revocations=[],
                    authority_evidence=chain["authority_evidence"],
                    canary_authority_evidence={},
                    qualification_manifest_path=chain["context"]["manifest"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    maturity_model=chain["context"]["maturity_model"],
                    qualification_state_checks=chain["context"]["state_checks"],
                    artifact_sha256=chain["context"]["artifact_sha256"],
                    effective_autonomy_report=chain["effective"],
                    match_report=chain["match"],
                    simulation_report=chain["simulation"],
                    at=evaluated_at.isoformat(),
                )

    def test_project_l3_registry_is_explicit_and_canary_scoped(self) -> None:
        validated = validate_autonomy_class_registry(
            self.registry,
            self.change_classes,
        )
        autonomy_class = validated["classes"][0]
        self.assertEqual(autonomy_class["maximum_autonomy"], "L3")
        self.assertEqual(
            autonomy_class["allowed_consequences"],
            ["pull-request", "canary"],
        )

        initial = copy.deepcopy(
            load_json(PROTOCOL_DIR / "autonomy-classes.json")
        )
        initial["classes"][0]["allowed_consequences"].append("canary")
        with self.assertRaises(ProtocolError):
            validate_autonomy_class_registry(initial, self.change_classes)
        self.assertNotIn(
            "execution_store",
            inspect.signature(execute_canary).parameters,
        )
        self.assertNotIn(
            "at",
            inspect.signature(sweep_due_canary_deadlines).parameters,
        )

    def test_canary_authority_is_bound_to_the_exact_plan(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-plan-authority") as workspace:
            chain = self.authority_chain(
                workspace,
                evaluated_at=evaluated_at,
            )
            changed_plan = copy.deepcopy(chain["plan"])
            changed_plan["target"] = "apps/other-service"
            finalize(changed_plan)
            with self.assertRaises(ProtocolError):
                self.issue_lease(
                    chain,
                    evaluated_at=evaluated_at,
                    plan=changed_plan,
                    canary_simulation_report=simulate_canary_plan(
                        changed_plan,
                        chain["policy"],
                    ),
                )

    def test_execution_packet_is_consumed_once(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-one-shot") as workspace:
            chain = self.authority_chain(
                workspace,
                evaluated_at=evaluated_at,
            )
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(
                chain,
                evaluated_at=evaluated_at,
            )
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-ONE-SHOT",
                at=evaluated_at.isoformat(),
            )
            store = self.use_execution_store(
                workspace,
                "one-shot-executions.db",
            )
            first_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            execute_canary(
                packet,
                first_provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            second_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "already been consumed",
            ):
                execute_canary(
                    packet,
                    second_provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=evaluated_at,
                    ),
                )
            second_packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-SECOND-PACKET",
                at=evaluated_at.isoformat(),
            )
            third_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "already been consumed",
            ):
                execute_canary(
                    second_packet,
                    third_provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=evaluated_at,
                    ),
                )

        self.assertIsNotNone(first_provider.packet)
        self.assertIsNone(second_provider.packet)
        self.assertIsNone(third_provider.packet)

    def test_claimed_start_is_recoverable_after_process_restart(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-start-recovery") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-START-RECOVERY",
                at=evaluated_at.isoformat(),
            )
            store_path = workspace / "start-recovery.db"
            store = self.use_execution_store(
                workspace,
                store_path.name,
            )
            store.claim(packet, at=evaluated_at.isoformat())

            self._execution_store = SQLiteCanaryExecutionStore(store_path)
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            results = self.sweep_at(
                provider,
                at=evaluated_at + timedelta(minutes=1),
            )

        self.assertEqual(len(results), 1)
        self.assertEqual(
            provider.rollback_packet["trigger"],
            "start-uncertain",
        )
        self.assertIsNone(provider.rollback_packet["response_sha256"])

    def test_stale_rollback_claim_is_reclaimed_after_process_restart(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-rollback-reclaim") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-ROLLBACK-RECLAIM",
                at=evaluated_at.isoformat(),
            )
            store_path = workspace / "rollback-reclaim.db"
            store = self.use_execution_store(
                workspace,
                store_path.name,
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            rollback_at = evaluated_at + timedelta(minutes=30)
            rollback_packet = canary_runtime.create_canary_deadline_rollback_packet(
                packet,
                response,
                at=rollback_at.isoformat(),
            )
            self.assertTrue(
                store.claim_rollback(
                    packet,
                    rollback_packet,
                    at=rollback_at.isoformat(),
                    require_deadline=True,
                )
            )

            self._execution_store = SQLiteCanaryExecutionStore(store_path)
            recovery_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            results = self.sweep_at(
                recovery_provider,
                at=rollback_at + timedelta(minutes=1),
            )

        self.assertEqual(len(results), 1)
        self.assertEqual(
            recovery_provider.rollback_packet["trigger"],
            "telemetry-deadline",
        )
        self.assertEqual(recovery_provider.rollback_packet, rollback_packet)
        self.assertEqual(
            recovery_provider.rollback_packet["content_sha256"],
            rollback_packet["content_sha256"],
        )

    def test_expired_rollback_claim_cannot_renew_authority(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-rollback-expiry") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-ROLLBACK-EXPIRY",
                at=evaluated_at.isoformat(),
            )
            store_path = workspace / "rollback-expiry.db"
            store = self.use_execution_store(
                workspace,
                store_path.name,
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            rollback_at = evaluated_at + timedelta(minutes=30)
            rollback_packet = canary_runtime.create_canary_deadline_rollback_packet(
                packet,
                response,
                at=rollback_at.isoformat(),
            )
            self.assertTrue(
                store.claim_rollback(
                    packet,
                    rollback_packet,
                    at=rollback_at.isoformat(),
                    require_deadline=True,
                )
            )
            second_packet = copy.deepcopy(packet)
            second_packet.update(
                {
                    "packet_id": "canary-packet-EXEC-CANARY-AFTER-EXPIRY",
                    "execution_id": "EXEC-CANARY-AFTER-EXPIRY",
                    "plan_id": "CANARY-PLAN-AFTER-EXPIRY",
                    "plan_sha256": "f" * 64,
                    "deployment_id": "deploy-after-expiry",
                }
            )
            finalize(second_packet)
            store.claim(
                second_packet,
                at=(rollback_at + timedelta(minutes=10)).isoformat(),
            )

            self._execution_store = SQLiteCanaryExecutionStore(store_path)
            recovery_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "expired before recovery",
            ):
                self.sweep_at(
                    recovery_provider,
                    at=rollback_at + timedelta(minutes=11),
                )
            expired_record = self._execution_store.get_record(packet)
            recovered_record = self._execution_store.get_record(second_packet)

        self.assertEqual(expired_record["status"], "rollback-expired")
        self.assertEqual(recovered_record["status"], "rolled-back")
        self.assertEqual(
            recovery_provider.rollback_packet["deployment_id"],
            second_packet["deployment_id"],
        )
        self.assertEqual(
            recovery_provider.rollback_packet["trigger"],
            "start-uncertain",
        )

    def test_watchdog_scheduler_failure_rolls_back_active_canary(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-watchdog-failure") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-WATCHDOG-FAILURE",
                at=evaluated_at.isoformat(),
            )
            store = self.use_execution_store(
                workspace,
                "watchdog-failure.db",
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            self.deadline_scheduler.side_effect = [
                None,
                RuntimeError("timer unavailable"),
            ]
            with self.assertRaisesRegex(
                ProtocolError,
                "canary was rolled back",
            ):
                execute_canary(
                    packet,
                    provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=evaluated_at,
                    ),
                )
            record = store.get_record(packet)

        self.assertEqual(record["status"], "rolled-back")
        self.assertEqual(
            provider.rollback_packet["trigger"],
            "watchdog-unavailable",
        )
        self.assertEqual(
            provider.rollback_packet["response_sha256"],
            record["response"]["content_sha256"],
        )

    def test_expired_rollback_fails_before_provider_invocation(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-preinvoke-expiry") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-PREINVOKE-EXPIRY",
                at=evaluated_at.isoformat(),
            )
            store = self.use_execution_store(
                workspace,
                "preinvoke-expiry.db",
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            observed_at = evaluated_at + timedelta(minutes=6)
            observation = self.observation(
                chain,
                packet=packet,
                response=response,
                observed_at=observed_at,
                metrics={
                    "error_rate": 0.20,
                    "p95_latency_ms": 900,
                    "success_rate": 0.80,
                },
            )
            report = evaluate_canary_observation(
                observation,
                packet=packet,
                response=response,
                policy=chain["policy"],
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                at=observed_at.isoformat(),
            )
            rollback_packet = create_canary_rollback_packet(
                observation,
                packet=packet,
                response=response,
                observation_report=report,
                policy=chain["policy"],
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                at=observed_at.isoformat(),
            )
            self.runtime_now = datetime.fromisoformat(
                rollback_packet["required_by"]
            ) + timedelta(seconds=1)
            rollback_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "expired before provider invocation",
            ):
                execute_canary_rollback(
                    rollback_packet,
                    rollback_provider,
                    observation=observation,
                    packet=packet,
                    response=response,
                    observation_report=report,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=observed_at.isoformat(),
                )
            record = store.get_record(packet)

        self.assertIsNone(rollback_provider.rollback_packet)
        self.assertEqual(record["status"], "observing")

    def test_observation_rollback_requires_persisted_response(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-response-state") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-RESPONSE-STATE",
                at=evaluated_at.isoformat(),
            )
            self.use_execution_store(workspace, "response-state.db")
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            substituted = copy.deepcopy(response)
            substituted["deployment_id"] = "deploy-substituted"
            substituted["url"] = (
                packet["canary_url_prefix"] + substituted["deployment_id"]
            )
            finalize(substituted)
            observed_at = evaluated_at + timedelta(minutes=5)
            observation = self.observation(
                chain,
                packet=packet,
                response=substituted,
                observed_at=observed_at,
                metrics={
                    "error_rate": 0.20,
                    "p95_latency_ms": 900,
                    "success_rate": 0.80,
                },
            )
            rollback_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "canonical runtime state",
            ):
                process_canary_observation(
                    observation,
                    rollback_provider,
                    packet=packet,
                    response=substituted,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=observed_at.isoformat(),
                )

        self.assertIsNone(rollback_provider.rollback_packet)

    def test_current_suspension_denies_execution_before_provider(self) -> None:
        issued_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        executed_at = issued_at + timedelta(minutes=1)
        with test_workspace("p5-3-current-governance") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=issued_at)
            lease = self.issue_lease(chain, evaluated_at=issued_at)
            evidence = self.provider_evidence(chain, evaluated_at=issued_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-SUSPENDED",
                at=issued_at.isoformat(),
            )
            suspension = p50.suspension(effective_at=executed_at)
            suspension["autonomy_class_id"] = "fixture-canary-release"
            finalize(suspension)
            current_context = {
                **chain["context"],
                "state_checks": {
                    name: {
                        "checked_at": executed_at.isoformat(),
                        "present": False,
                    }
                    for name in [
                        "contradiction",
                        "suspension",
                        "revocation",
                    ]
                },
            }
            current = {
                **chain,
                "context": current_context,
                "suspensions": [suspension],
                "revocations": [],
            }
            current["certification_replay"] = replay_certification(
                chain["certification"],
                self.registry["classes"][0],
                chain["certification_events"],
                policy=chain["policy"],
                at=executed_at.isoformat(),
            )
            current["effective"] = calculate_effective_autonomy(
                chain["policy"],
                self.registry,
                self.change_classes,
                project_id=chain["work_item"]["project_id"],
                project_autonomy_ceiling="L3",
                autonomy_class_id=chain["work_item"]["autonomy_class_id"],
                certification=chain["certification"],
                qualification_consumption=chain["consumption"],
                incident_budget=chain["budget"],
                suspensions=[suspension],
                revocations=[],
                at=executed_at.isoformat(),
            )
            current["authority_evidence"] = p52.signed_authority_evidence(
                chain["context"]["private_key"],
                chain=current,
                registry=self.registry,
                change_classes=self.change_classes,
                evaluated_at=executed_at,
                project_autonomy_ceiling="L3",
            )
            current["canary_authority_evidence"] = (
                self.canary_authority_evidence(
                    current,
                    authority_evidence=current["authority_evidence"],
                    evaluated_at=executed_at,
                )
            )
            provider = RecordingCanaryProvider(started_at=executed_at)
            self.use_execution_store(
                workspace,
                "suspended-executions.db",
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "current governance",
            ):
                execute_canary(
                    packet,
                    provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=executed_at,
                        current_chain=current,
                    ),
                )

        self.assertIsNone(provider.packet)

    def test_future_dated_governance_checks_deny_execution(self) -> None:
        issued_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        executed_at = issued_at + timedelta(minutes=1)
        with test_workspace("p5-3-future-governance") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=issued_at)
            lease = self.issue_lease(chain, evaluated_at=issued_at)
            evidence = self.provider_evidence(chain, evaluated_at=issued_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-FUTURE-GOVERNANCE",
                at=issued_at.isoformat(),
            )
            future_context = {
                **chain["context"],
                "state_checks": {
                    name: {
                        "checked_at": (
                            executed_at + timedelta(minutes=9)
                        ).isoformat(),
                        "present": False,
                    }
                    for name in [
                        "contradiction",
                        "suspension",
                        "revocation",
                    ]
                },
            }
            current = {
                **chain,
                "context": future_context,
                "suspensions": [],
                "revocations": [],
            }
            current["certification_replay"] = replay_certification(
                chain["certification"],
                self.registry["classes"][0],
                chain["certification_events"],
                policy=chain["policy"],
                at=executed_at.isoformat(),
            )
            current["effective"] = calculate_effective_autonomy(
                chain["policy"],
                self.registry,
                self.change_classes,
                project_id=chain["work_item"]["project_id"],
                project_autonomy_ceiling="L3",
                autonomy_class_id=chain["work_item"]["autonomy_class_id"],
                certification=chain["certification"],
                qualification_consumption=chain["consumption"],
                incident_budget=chain["budget"],
                suspensions=[],
                revocations=[],
                at=executed_at.isoformat(),
            )
            current["authority_evidence"] = p52.signed_authority_evidence(
                chain["context"]["private_key"],
                chain=current,
                registry=self.registry,
                change_classes=self.change_classes,
                evaluated_at=executed_at,
                project_autonomy_ceiling="L3",
            )
            current["canary_authority_evidence"] = (
                self.canary_authority_evidence(
                    current,
                    authority_evidence=current["authority_evidence"],
                    evaluated_at=executed_at,
                )
            )
            self.use_execution_store(
                workspace,
                "future-governance-executions.db",
            )
            provider = RecordingCanaryProvider(started_at=executed_at)
            with self.assertRaisesRegex(
                ProtocolError,
                "future-dated",
            ):
                execute_canary(
                    packet,
                    provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=executed_at,
                        current_chain=current,
                    ),
                )

        self.assertIsNone(provider.packet)

    def test_fabricated_packet_expired_lease_and_response_drift_fail_before_acceptance(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-packet-negative") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"]["qualification_policy"],
                execution_id="EXEC-CANARY-NEGATIVE",
                at=evaluated_at.isoformat(),
            )
            fabricated = copy.deepcopy(packet)
            fabricated["target"] = "other-service"
            finalize(fabricated)
            self.use_execution_store(
                workspace,
                "packet-negative-executions.db",
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            with self.assertRaises(ProtocolError):
                execute_canary(
                    fabricated,
                    provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=evaluated_at,
                    ),
                )
            self.assertIsNone(provider.packet)

            expired_at = datetime.fromisoformat(lease["expires_at"])
            expired_provider = RecordingCanaryProvider(started_at=expired_at)
            with self.assertRaises(ProtocolError):
                execute_canary(
                    packet,
                    expired_provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=expired_at,
                    ),
                )
            self.assertIsNone(expired_provider.packet)

            drift_provider = RecordingCanaryProvider(
                started_at=evaluated_at,
                response_overrides={"artifact_sha256": "c" * 64},
            )
            with self.assertRaises(ProtocolError):
                execute_canary(
                    packet,
                    drift_provider,
                    **self.execution_arguments(
                        chain,
                        lease=lease,
                        provider_evidence=evidence,
                        evaluated_at=evaluated_at,
                    ),
                )
            self.assertEqual(
                drift_provider.rollback_packet["trigger"],
                "start-uncertain",
            )

    def test_stale_or_forged_provider_evidence_and_foreign_observation_fail(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-signed-negative") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            stale = copy.deepcopy(evidence)
            stale["issued_at"] = (
                evaluated_at - timedelta(minutes=16)
            ).isoformat()
            stale["expires_at"] = (
                evaluated_at + timedelta(minutes=1)
            ).isoformat()
            sign_statement(stale, chain["context"]["private_key"])
            with self.assertRaises(ProtocolError):
                create_canary_execution_packet(
                    chain["policy"],
                    plan=chain["plan"],
                    lease=lease,
                    provider_evidence=stale,
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    execution_id="EXEC-CANARY-STALE",
                    at=evaluated_at.isoformat(),
                )

            forged = copy.deepcopy(evidence)
            forged["target"] = "other-service"
            finalize(forged)
            with self.assertRaises(ProtocolError):
                create_canary_execution_packet(
                    chain["policy"],
                    plan=chain["plan"],
                    lease=lease,
                    provider_evidence=forged,
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    execution_id="EXEC-CANARY-FORGED",
                    at=evaluated_at.isoformat(),
                )

            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"]["qualification_policy"],
                execution_id="EXEC-CANARY-OBSERVATION",
                at=evaluated_at.isoformat(),
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            self.use_execution_store(
                workspace,
                "observation-executions.db",
            )
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            observed_at = evaluated_at + timedelta(minutes=5)
            foreign = self.observation(
                chain,
                packet=packet,
                response=response,
                observed_at=observed_at,
            )
            foreign["deployment_id"] = "deploy-foreign"
            sign_statement(foreign, chain["context"]["private_key"])
            with self.assertRaises(ProtocolError):
                evaluate_canary_observation(
                    foreign,
                    packet=packet,
                    response=response,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=observed_at.isoformat(),
                )
            stale = self.observation(
                chain,
                packet=packet,
                response=response,
                observed_at=observed_at,
            )
            with self.assertRaises(ProtocolError):
                evaluate_canary_observation(
                    stale,
                    packet=packet,
                    response=response,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=(observed_at + timedelta(minutes=6)).isoformat(),
                )

    def test_plan_bounds_and_duration_breach_fail_closed(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-bounds") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            excessive = copy.deepcopy(chain["plan"])
            excessive["traffic"]["maximum_percent"] = 11
            finalize(excessive)
            report = simulate_canary_plan(excessive, chain["policy"])
            self.assertEqual(report["status"], "blocked")
            self.assertIn("traffic-exceeds-policy", report["blockers"])
            self.assertEqual(report["side_effects_performed"], [])

            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"]["qualification_policy"],
                execution_id="EXEC-CANARY-BOUNDS",
                at=evaluated_at.isoformat(),
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            self.use_execution_store(
                workspace,
                "bounds-executions.db",
            )
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            observed_at = evaluated_at + timedelta(minutes=27)
            evaluated_after_deadline = evaluated_at + timedelta(minutes=31)
            observation = self.observation(
                chain,
                packet=packet,
                response=response,
                observed_at=observed_at,
            )
            report = evaluate_canary_observation(
                observation,
                packet=packet,
                response=response,
                policy=chain["policy"],
                qualification_policy=chain["context"]["qualification_policy"],
                at=evaluated_after_deadline.isoformat(),
            )
            rollback_packet = create_canary_rollback_packet(
                observation,
                packet=packet,
                response=response,
                observation_report=report,
                policy=chain["policy"],
                qualification_policy=chain["context"]["qualification_policy"],
                at=evaluated_after_deadline.isoformat(),
            )
            fabricated_rollback = copy.deepcopy(rollback_packet)
            fabricated_rollback["target"] = "apps/other-service"
            finalize(fabricated_rollback)
            untouched_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaises(ProtocolError):
                execute_canary_rollback(
                    fabricated_rollback,
                    untouched_provider,
                    observation=observation,
                    packet=packet,
                    response=response,
                    observation_report=report,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=evaluated_after_deadline.isoformat(),
                )
            self.assertIsNone(untouched_provider.rollback_packet)
            rollback_drift_provider = RecordingCanaryProvider(
                started_at=evaluated_at,
                rollback_overrides={"artifact_sha256": "c" * 64},
            )
            self.runtime_now = evaluated_after_deadline
            with self.assertRaises(ProtocolError):
                process_canary_observation(
                    observation,
                    rollback_drift_provider,
                    packet=packet,
                    response=response,
                    policy=chain["policy"],
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    at=evaluated_after_deadline.isoformat(),
                )
            late_rollback_provider = RecordingCanaryProvider(
                started_at=evaluated_at,
                rollback_overrides={
                    "completed_at": (
                        evaluated_after_deadline + timedelta(minutes=11)
                    ).isoformat()
                },
            )
            with self.assertRaises(ProtocolError):
                self.sweep_at(
                    late_rollback_provider,
                    at=evaluated_after_deadline,
                )

        self.assertEqual(report["status"], "rollback-required")
        self.assertIn("maximum-duration", report["threshold_breaches"])
        self.assertEqual(report["observation_elapsed_minutes"], 27)
        self.assertEqual(report["elapsed_minutes"], 31)
        self.assertFalse(report["can_promote"])
        self.assertIsNotNone(rollback_drift_provider.rollback_packet)
        self.assertIsNotNone(late_rollback_provider.rollback_packet)

    def test_missing_telemetry_triggers_deadline_rollback(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        with test_workspace("p5-3-telemetry-deadline") as workspace:
            chain = self.authority_chain(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            evidence = self.provider_evidence(chain, evaluated_at=evaluated_at)
            packet = create_canary_execution_packet(
                chain["policy"],
                plan=chain["plan"],
                lease=lease,
                provider_evidence=evidence,
                qualification_policy=chain["context"][
                    "qualification_policy"
                ],
                execution_id="EXEC-CANARY-NO-TELEMETRY",
                at=evaluated_at.isoformat(),
            )
            provider = RecordingCanaryProvider(started_at=evaluated_at)
            store_path = workspace / "deadline-executions.db"
            self.use_execution_store(workspace, store_path.name)
            response = execute_canary(
                packet,
                provider,
                **self.execution_arguments(
                    chain,
                    lease=lease,
                    provider_evidence=evidence,
                    evaluated_at=evaluated_at,
                ),
            )
            rollback_at = evaluated_at + timedelta(minutes=30)
            future_rollback = (
                canary_runtime.create_canary_deadline_rollback_packet(
                    packet,
                    response,
                    at=rollback_at.isoformat(),
                )
            )
            early_provider = RecordingCanaryProvider(
                started_at=evaluated_at
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "not active on the runtime clock",
            ):
                canary_runtime.execute_canary_deadline_rollback(
                    future_rollback,
                    early_provider,
                    packet=packet,
                    response=response,
                    at=rollback_at.isoformat(),
                )
            self.assertEqual(
                self._execution_store.get_record(packet)["status"],
                "observing",
            )
            self._execution_store = SQLiteCanaryExecutionStore(store_path)
            results = self.sweep_at(
                provider,
                at=rollback_at,
            )
            result = results[0]

        self.assertEqual(self.deadline_scheduler.call_count, 2)
        self.assertIsNone(early_provider.rollback_packet)
        self.assertEqual(len(results), 1)
        self.assertEqual(result["status"], "rolled-back")
        self.assertTrue(result["rollback_performed"])
        self.assertIsNone(result["observation_report_sha256"])
        self.assertEqual(
            provider.rollback_packet["trigger"],
            "telemetry-deadline",
        )
        self.assertEqual(
            provider.rollback_packet["threshold_breaches"],
            ["telemetry-deadline"],
        )

    def test_deadline_scheduler_starts_daemon_timer(self) -> None:
        started_at = datetime(2026, 8, 6, 12, 0, tzinfo=UTC)
        provider = RecordingCanaryProvider(started_at=started_at)
        timer = Mock()
        with test_workspace("p5-3-deadline-scheduler") as workspace:
            packet = {
                "execution_id": "EXEC-SCHEDULE",
                "plan_sha256": "b" * 64,
                "start_response_timeout_minutes": 1,
                "rollback_claim_timeout_minutes": 1,
                "timing": {"maximum_duration_minutes": 30},
                "rollback": {"maximum_minutes": 10},
                "content_sha256": "a" * 64,
            }
            self.use_execution_store(workspace)
            self._execution_store.claim(
                packet,
                at=started_at.isoformat(),
            )
            with patch.object(
                canary_runtime.threading,
                "Timer",
                return_value=timer,
            ) as timer_factory:
                self._real_deadline_scheduler(
                    packet,
                    provider,
                )

        timer_factory.assert_called_once()
        self.assertTrue(timer.daemon)
        timer.start.assert_called_once_with()

    def test_canonical_readiness_remains_inactive_without_l3_evidence(self) -> None:
        policy = load_json(PROTOCOL_DIR / "autonomy-policy.json")
        report = canonical_p5_3_readiness(
            policy,
            qualification_policy=load_json(
                PROTOCOL_DIR / "qualification-policy.json"
            ),
            factory_status={
                "has_remote": True,
                "branch_protection": "unverified",
                "external_identity": "not-configured",
            },
            active_authority_source_present=False,
            active_certification_present=False,
            valid_l3_consumption_present=False,
            l3_capable_class_present=False,
            secret_broker_verified=False,
            central_telemetry_verified=False,
            rollback_verified=False,
        )
        self.assertFalse(report["ready"])
        self.assertFalse(report["can_execute_canary"])
        self.assertFalse(report["can_promote"])
        self.assertFalse(report["can_full_rollout"])
        self.assertIn(
            "no-valid-l3-qualification-consumption",
            report["blockers"],
        )
        self.assertIn("no-l3-capable-autonomy-class", report["blockers"])
        self.assertIn("secret-broker-not-verified", report["blockers"])
        self.assertIn("central-telemetry-not-verified", report["blockers"])
        self.assertIn("automatic-rollback-not-verified", report["blockers"])


if __name__ == "__main__":
    unittest.main()
