from __future__ import annotations

import json
import unittest

from elder_protocol.compiler import compile_project
from elder_protocol.constants import PORTABLE_MEMORY_ENV_PATH, ROOT
from elder_protocol.errors import ProtocolError
from tests._support import test_workspace


class CompilerComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.profile = ROOT / "examples" / "minimal-project-profile.json"

    def test_compile_writes_full_p1_contract(self) -> None:
        with test_workspace("compile") as workspace:
            output = workspace / "project"
            report = compile_project(self.profile, output)
            self.assertTrue(report.wrote)
            expected = [
                "AGENTS.md",
                "ARCHITECTURE.md",
                "docs/adr/0001-elder-foundation.md",
                "docs/TESTING.md",
                "docs/OWNERSHIP.md",
                "docs/GOLDEN_PATH.md",
                "docs/TRACE_CONTRACT.md",
                "docs/ASSURANCE.md",
                "docs/COMPONENT_CONTRACT.md",
                "docs/ARCHITECTURE_BOUNDARIES.md",
                "docs/TRANSCRIPT_REVIEW.md",
                "docs/EVALUATION.md",
                "docs/TELEMETRY.md",
                "docs/KNOWLEDGE_RUNTIME.md",
                "docs/BUILD_MEMORY.md",
                "docs/HOSTED_QUALIFICATION.md",
                "docs/BOUNDED_AUTONOMY.md",
                ".elder/project-profile.json",
                ".elder/project-contract.json",
                ".elder/capability-packs.json",
                ".elder/project-graph.json",
                ".elder/design-registry.json",
                ".elder/recommendation-ledger.json",
                ".elder/judgment-rubric.json",
                ".elder/operational-maturity.json",
                ".elder/transcript-review-policy.json",
                ".elder/evaluation-registry.json",
                ".elder/evaluation-dataset.json",
                ".elder/evaluator-contract.json",
                ".elder/telemetry-contract.json",
                ".elder/context-policy.json",
                ".elder/memory-policy.json",
                ".elder/memory/trusted.json",
                ".elder/learning-policy.json",
                ".elder/repository-dreaming-policy.json",
                ".elder/qualification-policy.json",
                ".elder/autonomy-policy.json",
                ".elder/autonomy-classes.json",
                ".elder/skills.json",
                ".elder/ownership.json",
                ".codex/config.toml",
                ".env.example",
                ".elder/runtime/.gitignore",
                ".codex/skills/repository-dreaming/SKILL.md",
                "docs/REPOSITORY_DREAMING.md",
            ]
            for relative in expected:
                self.assertTrue((output / relative).is_file(), relative)
            self.assertEqual(
                (output / ".elder/runtime/.gitignore").read_bytes(),
                b"*\n!.gitignore\n",
            )
            agents = (output / "AGENTS.md").read_text(encoding="utf-8")
            dreaming = (output / "docs/REPOSITORY_DREAMING.md").read_text(
                encoding="utf-8"
            )
            env_example = (output / ".env.example").read_text(encoding="utf-8")
            for generated in (agents, dreaming):
                self.assertIn(
                    f"--env-file {PORTABLE_MEMORY_ENV_PATH}",
                    generated,
                )
                self.assertNotIn("--env-file .env", generated)
            self.assertIn(PORTABLE_MEMORY_ENV_PATH, env_example)
            self.assertNotIn("ignored .env file", env_example)

    def test_regeneration_is_idempotent(self) -> None:
        with test_workspace("idempotent") as workspace:
            output = workspace / "project"
            compile_project(self.profile, output)
            second = compile_project(self.profile, output)
            self.assertEqual(second.changes, ())
            self.assertGreaterEqual(len(second.unchanged), 11)

    def test_equal_priority_skills_have_a_stable_lexical_order(self) -> None:
        with test_workspace("stable-skill-order") as workspace:
            output = workspace / "project"
            compile_project(self.profile, output)
            contract = json.loads(
                (output / ".elder" / "project-contract.json").read_text(
                    encoding="utf-8"
                )
            )
            skills = contract["skills"]
            self.assertLess(skills.index("grill-me"), skills.index("grill-with-docs"))

    def test_compile_connects_agents_packs_and_project_graph(self) -> None:
        with test_workspace("project-graph") as workspace:
            output = workspace / "project"
            compile_project(self.profile, output)
            contract = json.loads(
                (output / ".elder" / "project-contract.json").read_text(
                    encoding="utf-8"
                )
            )
            graph = json.loads(
                (output / ".elder" / "project-graph.json").read_text(
                    encoding="utf-8"
                )
            )
            agents = (output / "AGENTS.md").read_text(encoding="utf-8")
            node_ids = {node["id"] for node in graph["nodes"]}

            self.assertEqual(contract["meta_architecture_version"], "0.5.1")
            self.assertIn("pack:agentic", node_ids)
            self.assertIn("skill:skill-router", node_ids)
            self.assertIn("project:example-agentic-product", node_ids)
            self.assertIn("design-document:ADR-0001", node_ids)
            self.assertIn(
                "evaluation-dataset:example-agentic-product-project-assurance-v1",
                node_ids,
            )
            self.assertIn(".elder/project-graph.json", agents)
            self.assertIn(".elder/capability-packs.json", agents)
            self.assertIn("Factory And Product Boundary", agents)
            self.assertIn("Session Activation", agents)
            self.assertIn(".codex/skills/", agents)
            self.assertTrue(
                (output / ".codex" / "skills" / "repository-dreaming" / "SKILL.md").is_file()
            )

    def test_modified_generated_file_is_protected(self) -> None:
        with test_workspace("modified") as workspace:
            output = workspace / "project"
            compile_project(self.profile, output)
            (output / "AGENTS.md").write_text("project-owned edit\n", encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "Refusing to overwrite"):
                compile_project(self.profile, output)

    def test_dry_run_writes_nothing_and_produces_diff(self) -> None:
        with test_workspace("dry-run") as workspace:
            output = workspace / "project"
            report = compile_project(
                self.profile, output, dry_run=True, show_diff=True
            )
            self.assertFalse(output.exists())
            self.assertFalse(report.wrote)
            self.assertIn("AGENTS.md", report.diff)


if __name__ == "__main__":
    unittest.main()
