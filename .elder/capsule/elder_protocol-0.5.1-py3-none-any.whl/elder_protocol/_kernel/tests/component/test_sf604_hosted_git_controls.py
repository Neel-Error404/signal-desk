from __future__ import annotations

import copy
import json
import sqlite3
import unittest
from datetime import timedelta
from unittest.mock import patch

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.hosted_git_controls import (
    HostedGitReviewControls,
    hosted_git_content_sha256,
)
from tests._sf604_support import (
    NOW,
    TEST_ANCHORS,
    build_environment,
    delivery_variant,
    finalize,
    resign_governance,
    resign_provider_response,
    resign_provenance,
    resign_review,
    verify,
)
from tests._support import tamper_sqlite_store, test_workspace


class SF604HostedGitControlsComponentTests(unittest.TestCase):
    def test_exact_delivery_is_retained_idempotent_and_restart_safe(self) -> None:
        with test_workspace("sf604-component-happy") as workspace:
            environment = build_environment(workspace)
            first = verify(environment)
            second = verify(environment)
            self.assertEqual(first, second)
            self.assertEqual(first["status"], "verified")
            self.assertFalse(first["can_merge"])
            restarted = HostedGitReviewControls(
                environment["controls"].path,
                policy=environment["policy"],
                authority_resolver=environment["authority_resolver"],
                authority_decision_loader=environment[
                    "authority_decision_loader"
                ],
                evidence_completion_loader=environment[
                    "evidence_completion_loader"
                ],
                now=environment["clock"],
            )
            self.assertEqual(
                restarted.record(environment["packet"]["content_sha256"]),
                first,
            )
            replay = restarted.replay()
            self.assertEqual(replay["record_count"], 1)
            self.assertEqual(replay["tip_sha256"], first["content_sha256"])

    def test_protected_branch_bypass_fails_before_retention(self) -> None:
        with test_workspace("sf604-component-bypass") as workspace:
            environment = build_environment(workspace)
            packet = copy.deepcopy(environment["packet"])
            packet["base_branch"] = "unprotected"
            environment["packet"] = finalize(
                {
                    key: value
                    for key, value in packet.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "bypasses"):
                verify(environment)
            self.assertEqual(environment["controls"].replay()["record_count"], 0)

    def test_stale_governance_statement_fails(self) -> None:
        with test_workspace("sf604-component-stale") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(environment["governance"]["statement"])
            statement["observed_at"] = (
                NOW - timedelta(seconds=901)
            ).isoformat()
            environment["governance"] = resign_governance(
                environment,
                statement,
            )
            with self.assertRaisesRegex(ProtocolError, "stale"):
                verify(environment)

    def test_changed_commit_in_provenance_fails(self) -> None:
        with test_workspace("sf604-component-changed-commit") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(environment["provenance"]["statement"])
            statement["head_revision"] = "7" * 40
            statement["check_results"] = [
                {
                    **item,
                    "head_revision": "7" * 40,
                }
                for item in statement["check_results"]
            ]
            environment["provenance"] = resign_provenance(
                environment,
                statement,
            )
            with self.assertRaisesRegex(ProtocolError, "head_revision"):
                verify(environment)

    def test_untrusted_pull_request_url_fails(self) -> None:
        with test_workspace("sf604-component-url") as workspace:
            environment = build_environment(workspace)
            response = copy.deepcopy(
                environment["provider_response"]["statement"]
            )
            response["url"] = (
                "https://attacker.example/example/elder-product/pull/42"
            )
            environment["provider_response"] = resign_provider_response(
                environment,
                response,
            )
            with self.assertRaisesRegex(ProtocolError, "trusted prefix"):
                verify(environment)

    def test_signed_statement_source_must_use_trusted_provider_host(self) -> None:
        with test_workspace("sf604-component-source-host") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(environment["governance"]["statement"])
            statement["source_uri"] = (
                "https://attacker.example/"
                "example/elder-product/settings/rules/1"
            )
            environment["governance"] = resign_governance(
                environment,
                statement,
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "trusted repository HTTPS URI",
            ):
                verify(environment)

    def test_independent_review_binds_exact_returned_pull_request(self) -> None:
        with test_workspace("sf604-component-review-pr") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(
                environment["independent_review"]["statement"]
            )
            statement["pull_request_id"] = 43
            statement["pull_request_url"] = (
                "https://git.example.test/"
                "example/elder-product/pull/43"
            )
            environment["independent_review"] = resign_review(
                environment,
                statement,
            )
            with self.assertRaisesRegex(ProtocolError, "exact pull request"):
                verify(environment)

    def test_approving_reviewer_cannot_be_a_provider_identity(self) -> None:
        with test_workspace("sf604-component-reviewer-identity") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(
                environment["independent_review"]["statement"]
            )
            statement["reviewer_identity"] = (
                "provider:git.example.test:actions"
            )
            environment["independent_review"] = resign_review(
                environment,
                statement,
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "does not match the trusted signer",
            ):
                verify(environment)

    def test_review_cannot_predate_provenance_or_pull_request(self) -> None:
        with test_workspace("sf604-component-review-time") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(
                environment["independent_review"]["statement"]
            )
            statement["observed_at"] = (
                NOW - timedelta(seconds=1)
            ).isoformat()
            environment["independent_review"] = resign_review(
                environment,
                statement,
            )
            with self.assertRaisesRegex(ProtocolError, "chronological"):
                verify(environment)

    def test_missing_required_check_fails(self) -> None:
        with test_workspace("sf604-component-missing-check") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(environment["provenance"]["statement"])
            statement["check_results"].pop()
            environment["provenance"] = resign_provenance(
                environment,
                statement,
            )
            with self.assertRaisesRegex(ProtocolError, "missing"):
                verify(environment)

    def test_invalid_provider_signature_fails(self) -> None:
        with test_workspace("sf604-component-signature") as workspace:
            environment = build_environment(workspace)
            governance = copy.deepcopy(environment["governance"])
            signature = governance["attestation"]["signature_base64"]
            governance["attestation"]["signature_base64"] = (
                ("A" if signature[0] != "A" else "B") + signature[1:]
            )
            environment["governance"] = finalize(
                {
                    key: value
                    for key, value in governance.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "signature"):
                verify(environment)

    def test_unresolved_review_findings_fail(self) -> None:
        with test_workspace("sf604-component-findings") as workspace:
            environment = build_environment(workspace)
            statement = copy.deepcopy(
                environment["independent_review"]["statement"]
            )
            statement["remaining_findings"]["high"] = 1
            environment["independent_review"] = resign_review(
                environment,
                statement,
            )
            with self.assertRaisesRegex(ProtocolError, "unresolved"):
                verify(environment)

    def test_provider_response_cannot_merge_or_deploy(self) -> None:
        for field in ("merged", "deployed"):
            with self.subTest(field=field):
                with test_workspace(f"sf604-component-{field}") as workspace:
                    environment = build_environment(workspace)
                    response = copy.deepcopy(
                        environment["provider_response"]["statement"]
                    )
                    response[field] = True
                    environment["provider_response"] = (
                        resign_provider_response(environment, response)
                    )
                    with self.assertRaisesRegex(
                        ProtocolError,
                        "exceeds pull-request authority",
                    ):
                        verify(environment)

    def test_changed_duplicate_evidence_is_a_conflict(self) -> None:
        with test_workspace("sf604-component-duplicate") as workspace:
            environment = build_environment(workspace)
            verify(environment)
            review = copy.deepcopy(
                environment["independent_review"]["statement"]
            )
            review["review_artifact_sha256"] = "8" * 64
            environment["independent_review"] = resign_review(
                environment,
                review,
            )
            with self.assertRaisesRegex(ProtocolError, "different retained"):
                verify(environment)

    def test_tampered_record_and_evidence_fail_replay(self) -> None:
        for column in ("record_json", "evidence_json"):
            with self.subTest(column=column):
                with test_workspace(
                    f"sf604-component-tamper-{column}"
                ) as workspace:
                    environment = build_environment(workspace)
                    verify(environment)
                    connection = sqlite3.connect(
                        environment["controls"].path
                    )
                    try:
                        row = connection.execute(
                            f"SELECT {column} FROM hosted_git_control_records"
                        ).fetchone()
                        document = json.loads(row[0])
                        if column == "record_json":
                            document["status"] = "forged"
                        else:
                            document["artifact_sha256"] = "b" * 64
                    finally:
                        connection.close()
                    tamper_sqlite_store(
                        environment["controls"].path,
                        f"UPDATE hosted_git_control_records SET {column} = ?",
                        (json.dumps(document),),
                    )
                    with self.assertRaises(ProtocolError):
                        environment["controls"].replay()

    def test_duplicate_and_append_replay_full_chain_before_returning(
        self,
    ) -> None:
        with test_workspace("sf604-component-chain-before-write") as workspace:
            environment = build_environment(workspace)
            verify(environment)
            connection = sqlite3.connect(environment["controls"].path)
            try:
                row = connection.execute(
                    "SELECT record_json FROM hosted_git_control_records"
                ).fetchone()
                record = json.loads(row[0])
                record["pull_request_url"] = (
                    "https://git.example.test/"
                    "example/elder-product/pull/999"
                )
                record["content_sha256"] = hosted_git_content_sha256(
                    {
                        key: value
                        for key, value in record.items()
                        if key != "content_sha256"
                    }
                )
            finally:
                connection.close()
            tamper_sqlite_store(
                environment["controls"].path,
                """
                UPDATE hosted_git_control_records
                SET record_json = ?
                """,
                (json.dumps(record),),
            )
            with self.assertRaisesRegex(ProtocolError, "pull_request_url"):
                verify(environment)
            variant = delivery_variant(environment, 2)
            with self.assertRaisesRegex(ProtocolError, "pull_request_url"):
                variant["controls"].verify_delivery(
                    packet=variant["packet"],
                    governance=variant["governance"],
                    provenance=variant["provenance"],
                    independent_review=variant["independent_review"],
                    provider_response=variant["provider_response"],
                    supervised_delivery_record=variant[
                        "supervised_delivery_record"
                    ],
                    artifact_sha256=variant["artifact_sha256"],
                )

    def test_retention_expiry_is_owner_visible_and_not_silently_deleted(
        self,
    ) -> None:
        with test_workspace("sf604-component-retention") as workspace:
            environment = build_environment(workspace)
            verify(environment)
            environment["clock"].advance(86401)
            with self.assertRaisesRegex(ProtocolError, "expired"):
                environment["controls"].record(
                    environment["packet"]["content_sha256"]
                )
            with self.assertRaisesRegex(ProtocolError, "archival"):
                environment["controls"].purge_expired(
                    at=environment["clock"]().isoformat()
                )

    def test_store_rejects_policy_or_trust_generation_drift(self) -> None:
        with test_workspace("sf604-component-generation") as workspace:
            environment = build_environment(workspace)
            changed_policy = copy.deepcopy(environment["policy"])
            changed_policy["policy_id"] = "sf604-policy-two"
            changed_policy = finalize(
                {
                    key: value
                    for key, value in changed_policy.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "store binding"):
                HostedGitReviewControls(
                    environment["controls"].path,
                    policy=changed_policy,
                    authority_resolver=environment["authority_resolver"],
                    authority_decision_loader=environment[
                        "authority_decision_loader"
                    ],
                    evidence_completion_loader=environment[
                        "evidence_completion_loader"
                    ],
                    now=environment["clock"],
                )

    def test_long_lived_verifier_rechecks_anchor_validity(self) -> None:
        with test_workspace("sf604-component-anchor-expiry") as workspace:
            environment = build_environment(workspace)
            short_lived = copy.deepcopy(TEST_ANCHORS)
            for anchor in short_lived["anchors"]:
                anchor["valid_until"] = (
                    NOW + timedelta(seconds=1)
                ).isoformat()
            short_lived = finalize(
                {
                    key: value
                    for key, value in short_lived.items()
                    if key != "content_sha256"
                }
            )
            with patch(
                "elder_protocol.factory_operations.hosted_git_controls."
                "_canonical_hosted_git_trust_anchors",
                return_value=short_lived,
            ):
                controls = HostedGitReviewControls(
                    workspace / "short-lived.db",
                    policy=environment["policy"],
                    authority_resolver=environment["authority_resolver"],
                    authority_decision_loader=environment[
                        "authority_decision_loader"
                    ],
                    evidence_completion_loader=environment[
                        "evidence_completion_loader"
                    ],
                    now=environment["clock"],
                )
                environment["clock"].advance(2)
                environment["controls"] = controls
                with self.assertRaisesRegex(ProtocolError, "currently valid"):
                    verify(environment)

    def test_supervised_authority_and_source_tampering_fail(self) -> None:
        with test_workspace("sf604-component-authority-source") as workspace:
            environment = build_environment(workspace)
            decision = copy.deepcopy(environment["authority_decision"])
            decision["disposition"] = "rejected"
            environment["authority_decision"] = finalize(
                {
                    key: value
                    for key, value in decision.items()
                    if key != "content_sha256"
                }
            )
            environment["controls"] = HostedGitReviewControls(
                workspace / "tampered-authority.db",
                policy=environment["policy"],
                authority_resolver=environment["authority_resolver"],
                authority_decision_loader=(
                    lambda _request_id: environment["authority_decision"]
                ),
                evidence_completion_loader=environment[
                    "evidence_completion_loader"
                ],
                now=environment["clock"],
            )
            with self.assertRaisesRegex(ProtocolError, "authority decision"):
                verify(environment)

        with test_workspace("sf604-component-source-set") as workspace:
            environment = build_environment(workspace)
            sources = copy.deepcopy(environment["supervised_delivery_sources"])
            sources["project_autonomy_ceiling"] = "L1"
            environment["supervised_delivery_sources"] = sources
            environment["controls"] = HostedGitReviewControls(
                workspace / "tampered-sources.db",
                policy=environment["policy"],
                authority_resolver=lambda _delivery: {
                    "request": environment["supervised_delivery_request"],
                    "sources": environment["supervised_delivery_sources"],
                    "execution": environment[
                        "supervised_delivery_execution"
                    ],
                },
                authority_decision_loader=environment[
                    "authority_decision_loader"
                ],
                evidence_completion_loader=environment[
                    "evidence_completion_loader"
                ],
                now=environment["clock"],
            )
            with self.assertRaisesRegex(ProtocolError, "source or request"):
                verify(environment)


if __name__ == "__main__":
    unittest.main()
