from __future__ import annotations

import copy
import hashlib
import os
import socket
import unittest
import uuid
from datetime import UTC, datetime, timedelta
from unittest.mock import patch

from elder_protocol.errors import OperationsApiUnavailableError, ProtocolError
from elder_protocol.factory_operations.api_contracts import (
    canonical_content_sha256,
    load_operations_api_contracts,
)
from elder_protocol.factory_operations.api_health import (
    OperationsApiHealth,
)
from elder_protocol.factory_operations.api_idempotency import (
    ApiIdempotencyStore,
)
from elder_protocol.factory_operations.api_store import OperationsApiStore
from elder_protocol.factory_operations.bootstrap import (
    FactoryOperationsBootstrap,
)
from elder_protocol.factory_operations.projections import ProjectionRuntime
from elder_protocol.io import json_text
from tests._support import test_workspace


class OperationsApiHealthComponentTests(unittest.TestCase):
    @staticmethod
    def _auth_policy(workspace, contracts):
        now = datetime.now(UTC)
        token = "health-component-token-value-" + "x" * 32
        policy = {
            "version": "1.0.0",
            "policy_id": "operations-api-auth-health-component",
            "issued_at": (now - timedelta(minutes=1)).isoformat(),
            "expires_at": (now + timedelta(hours=1)).isoformat(),
            "clients": [
                {
                    "client_id": "health-component",
                    "kind": "operator",
                    "identity_id": "identity:health-component",
                    "enabled": True,
                    "bearer_token_sha256": hashlib.sha256(
                        token.encode("ascii")
                    ).hexdigest(),
                    "project_ids": ["product-one"],
                    "route_ids": [
                        "health-detail",
                        "readiness-detail",
                        "capabilities-get",
                    ],
                }
            ],
            "content_sha256": "",
        }
        policy["content_sha256"] = canonical_content_sha256(policy)
        target = workspace / "health-auth-policy.json"
        target.write_text(json_text(policy), encoding="utf-8")
        return target, policy

    def test_liveness_does_not_require_an_operations_store(self) -> None:
        with test_workspace("sf107-api-liveness") as workspace:
            health = OperationsApiHealth(
                store_path=workspace / "missing.db",
                boot_id="operations-api-boot-" + "1" * 32,
                runtime_generation=1,
            )
            document = health.live()
            self.assertEqual(document["status"], "alive")
            self.assertFalse((workspace / "missing.db").exists())

    def test_full_verification_and_runtime_loss_fail_closed(self) -> None:
        with test_workspace("sf107-api-health") as workspace:
            path = workspace / "operations.db"
            FactoryOperationsBootstrap(path).initialize()
            ProjectionRuntime(path).rebuild_all()
            contracts = load_operations_api_contracts()
            policy_path, policy = self._auth_policy(workspace, contracts)
            api_store = OperationsApiStore(path)
            api_store.initialize(
                route_registry_sha256=contracts.route_registry[
                    "content_sha256"
                ],
                binding_registry_sha256=contracts.binding_registry[
                    "content_sha256"
                ],
                auth_policy_sha256=policy["content_sha256"],
            )
            boot_id = f"operations-api-boot-{uuid.uuid4().hex}"
            claimed = api_store.claim_runtime(
                boot_id=boot_id,
                process_id=os.getpid(),
                host_id=socket.gethostname(),
                route_registry_sha256=contracts.route_registry[
                    "content_sha256"
                ],
                binding_registry_sha256=contracts.binding_registry[
                    "content_sha256"
                ],
                auth_policy_sha256=policy["content_sha256"],
            )
            ready_runtime = api_store.mark_ready(
                boot_id=boot_id,
                runtime_generation=claimed["runtime_generation"],
            )
            health = OperationsApiHealth(
                store_path=path,
                boot_id=boot_id,
                runtime_generation=ready_runtime["runtime_generation"],
                auth_policy_path=policy_path,
            )
            readiness = health.verify()
            self.assertTrue(readiness["ready"])
            self.assertTrue(readiness["mutation_ready"])
            self.assertEqual(readiness["status"], "degraded")
            self.assertEqual(
                readiness["degradations"],
                ["backup-unavailable"],
            )
            self.assertEqual(health.detail()["status"], "degraded")
            api_store.heartbeat(
                boot_id=boot_id,
                runtime_generation=ready_runtime["runtime_generation"],
            )
            health.require_event_wait_ready()

            verified_at = health._event_wait_verified_at_monotonic
            original_journal_verify = health._journal.verify
            changed_during_verify = copy.deepcopy(policy)
            changed_during_verify["expires_at"] = (
                datetime.now(UTC) + timedelta(hours=2)
            ).isoformat()
            changed_during_verify["content_sha256"] = (
                canonical_content_sha256(changed_during_verify)
            )

            def drift_policy_during_verify():
                result = original_journal_verify()
                policy_path.write_text(
                    json_text(changed_during_verify),
                    encoding="utf-8",
                )
                return result

            with patch.object(
                health._journal,
                "verify",
                side_effect=drift_policy_during_verify,
            ):
                with self.assertRaisesRegex(
                    OperationsApiUnavailableError,
                    "trust bindings changed",
                ):
                    health.require_event_wait_ready()
            self.assertEqual(
                health._event_wait_verified_at_monotonic,
                verified_at,
            )
            policy_path.write_text(json_text(policy), encoding="utf-8")
            api_store.heartbeat(
                boot_id=boot_id,
                runtime_generation=ready_runtime["runtime_generation"],
            )

            def drain_runtime_during_verify():
                result = original_journal_verify()
                api_store.begin_drain(
                    boot_id=boot_id,
                    runtime_generation=ready_runtime[
                        "runtime_generation"
                    ],
                )
                return result

            with patch.object(
                health._journal,
                "verify",
                side_effect=drain_runtime_during_verify,
            ):
                with self.assertRaisesRegex(
                    OperationsApiUnavailableError,
                    "runtime lease is unavailable",
                ):
                    health.require_event_wait_ready()
            self.assertEqual(
                health._event_wait_verified_at_monotonic,
                verified_at,
            )

            lost = health.readiness()
            self.assertFalse(lost["ready"])
            self.assertFalse(lost["mutation_ready"])
            self.assertIn("runtime-lease-lost", lost["blockers"])
            with self.assertRaisesRegex(
                OperationsApiUnavailableError,
                "runtime lease is unavailable",
            ):
                health.require_event_wait_ready()

            changed = copy.deepcopy(policy)
            changed["expires_at"] = (
                datetime.now(UTC) + timedelta(hours=2)
            ).isoformat()
            changed["content_sha256"] = canonical_content_sha256(changed)
            policy_path.write_text(json_text(changed), encoding="utf-8")
            drifted = health.verify()
            self.assertFalse(drifted["ready"])
            self.assertIn(
                "runtime-auth-policy-drift",
                drifted["blockers"],
            )

    def test_cached_readiness_refreshes_after_retryable_non_application(
        self,
    ) -> None:
        with test_workspace("sf107-health-retryable-refresh") as workspace:
            path = workspace / "operations.db"
            FactoryOperationsBootstrap(path).initialize()
            ProjectionRuntime(path).rebuild_all()
            contracts = load_operations_api_contracts()
            policy_path, policy = self._auth_policy(workspace, contracts)
            api_store = OperationsApiStore(path)
            api_store.initialize(
                route_registry_sha256=contracts.route_registry[
                    "content_sha256"
                ],
                binding_registry_sha256=contracts.binding_registry[
                    "content_sha256"
                ],
                auth_policy_sha256=policy["content_sha256"],
            )
            boot_id = f"operations-api-boot-{uuid.uuid4().hex}"
            claimed = api_store.claim_runtime(
                boot_id=boot_id,
                process_id=os.getpid(),
                host_id=socket.gethostname(),
                route_registry_sha256=contracts.route_registry[
                    "content_sha256"
                ],
                binding_registry_sha256=contracts.binding_registry[
                    "content_sha256"
                ],
                auth_policy_sha256=policy["content_sha256"],
            )
            runtime = api_store.mark_ready(
                boot_id=boot_id,
                runtime_generation=claimed["runtime_generation"],
            )
            health = OperationsApiHealth(
                store_path=path,
                boot_id=boot_id,
                runtime_generation=runtime["runtime_generation"],
                auth_policy_path=policy_path,
            )
            self.assertTrue(health.verify()["mutation_ready"])

            api_store.heartbeat(
                boot_id=boot_id,
                runtime_generation=runtime["runtime_generation"],
            )
            scope = {
                "route_id": "product-register",
                "client_id": "health-component",
                "project_id": "product-one",
                "idempotency_key": "health-retryable-001",
                "request_sha256": "a" * 64,
                "mutation_scope_sha256": "b" * 64,
                "boot_id": boot_id,
                "runtime_generation": runtime["runtime_generation"],
            }
            idempotency = ApiIdempotencyStore(path)
            idempotency.accept(**scope)
            idempotency.begin_execution(**scope)
            blocked = health.verify()
            self.assertTrue(blocked["ready"])
            self.assertFalse(blocked["mutation_ready"])

            api_store.heartbeat(
                boot_id=boot_id,
                runtime_generation=runtime["runtime_generation"],
            )
            idempotency.mark_retryable(
                **scope,
                response_status=500,
                response={
                    "version": "1.0.0",
                    "status": "error",
                    "error": {
                        "code": "internal-error",
                        "reason_code": "canonical-mutation-not-applied",
                    },
                },
                result_proof_sha256="c" * 64,
            )
            refreshed = health.readiness()
            self.assertTrue(refreshed["ready"])
            self.assertTrue(refreshed["mutation_ready"])
            self.assertEqual(
                OperationsApiStore(path).status()[
                    "idempotency_status_counts"
                ]["retryable"],
                1,
            )

    def test_cached_readiness_refreshes_after_journal_advance(self) -> None:
        with test_workspace("sf107-health-journal-refresh") as workspace:
            path = workspace / "operations.db"
            FactoryOperationsBootstrap(path).initialize()
            ProjectionRuntime(path).rebuild_all()
            contracts = load_operations_api_contracts()
            policy_path, policy = self._auth_policy(workspace, contracts)
            api_store = OperationsApiStore(path)
            api_store.initialize(
                route_registry_sha256=contracts.route_registry[
                    "content_sha256"
                ],
                binding_registry_sha256=contracts.binding_registry[
                    "content_sha256"
                ],
                auth_policy_sha256=policy["content_sha256"],
            )
            boot_id = f"operations-api-boot-{uuid.uuid4().hex}"
            claimed = api_store.claim_runtime(
                boot_id=boot_id,
                process_id=os.getpid(),
                host_id=socket.gethostname(),
                route_registry_sha256=contracts.route_registry[
                    "content_sha256"
                ],
                binding_registry_sha256=contracts.binding_registry[
                    "content_sha256"
                ],
                auth_policy_sha256=policy["content_sha256"],
            )
            runtime = api_store.mark_ready(
                boot_id=boot_id,
                runtime_generation=claimed["runtime_generation"],
            )
            health = OperationsApiHealth(
                store_path=path,
                boot_id=boot_id,
                runtime_generation=runtime["runtime_generation"],
                auth_policy_path=policy_path,
            )
            snapshot = health.verify()
            advanced_cursor = {
                **snapshot["journal"],
                "sequence": snapshot["journal"]["sequence"] + 1,
                "entry_id": "factory-event-journal-entry-" + "a" * 32,
                "entry_sha256": "b" * 64,
            }

            with (
                patch.object(
                    health._journal,
                    "current_cursor",
                    return_value=advanced_cursor,
                ),
                patch.object(health, "verify", wraps=health.verify) as verify,
            ):
                refreshed = health.readiness()

            verify.assert_called_once_with()
            self.assertTrue(refreshed["ready"])
            self.assertEqual(refreshed["journal"], snapshot["journal"])

    def test_readiness_revalidates_cached_snapshot_before_publication(
        self,
    ) -> None:
        with test_workspace("sf107-health-cached-tamper") as workspace:
            health = OperationsApiHealth(
                store_path=workspace / "missing.db",
                boot_id="operations-api-boot-" + "1" * 32,
                runtime_generation=1,
            )
            with health._lock:
                health._snapshot = copy.deepcopy(health._snapshot)
                health._snapshot["content_sha256"] = "0" * 64
            with self.assertRaisesRegex(
                ProtocolError,
                "content_sha256",
            ):
                health.readiness()


if __name__ == "__main__":
    unittest.main()
