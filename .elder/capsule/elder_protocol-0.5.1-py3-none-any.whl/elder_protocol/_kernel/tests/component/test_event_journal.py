from __future__ import annotations

import copy
import json
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path

from elder_protocol.constants import ROOT
from elder_protocol.errors import (
    CapabilityUnavailableError,
    InvalidProjectionTokenError,
    ProtocolError,
    StaleEventCursorError,
)
from elder_protocol.factory_operations._common import canonical_json
from elder_protocol.factory_operations.journal import (
    canonical_sha256,
    decode_page_token,
    encode_page_token,
    public_stream_snapshot_sha256,
)
from elder_protocol.factory_operations.journal_store import (
    JournalInitializer,
    JournalRecorder,
)
from elder_protocol.factory_operations.projections import (
    JournalIntegrity,
    ProjectionQueries,
    ProjectionRuntime,
)
from elder_protocol.factory_operations.operations_store import (
    operations_connection,
)
from elder_protocol.factory_operations.operations_backup import (
    OperationsBackupCoordinator,
)
from elder_protocol.factory_operations.product_registry import (
    ProductFactoryRegistry,
)
from elder_protocol.factory_operations.run_controller import (
    RunController,
    authorization_result_sha256,
    lifecycle_authorization_request_sha256,
    record_content_sha256,
)
from elder_protocol.factory_operations.signal_intake import SignalIntake
from elder_protocol.factory_operations.work_item_ledger import WorkItemLedger
from elder_protocol.factory_operations.transition_engine import (
    WorkItemTransitionEngine,
    transition_authorization_request_sha256,
    transition_authorization_result_sha256,
)
from elder_protocol.io import load_json
from elder_protocol.governance import finalize_checkpoint
from elder_protocol.errors import StaleProjectionTokenError
from tests._sf106_support import journaled_running_controller


class EventJournalComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.store = Path(self.temporary.name) / "operations.db"
        RunController(self.store).initialize()

    @staticmethod
    def _insert_product(
        connection: sqlite3.Connection,
        *,
        created_at: str = "2026-08-11T12:00:00+00:00",
        product_factory_id: str = "product-factory-one",
        project_id: str = "project-one",
    ) -> None:
        entity = {
            "id": product_factory_id,
            "project_id": project_id,
            "status": "draft",
            "record_version": 1,
        }
        snapshot = {
            "id": product_factory_id,
            "project_id": project_id,
            "status": "draft",
            "record_version": 1,
            "actor_identity_id": "product-owner-one",
        }
        connection.execute(
            """
            INSERT INTO product_factories(
                id, project_id, repository_root, profile_path,
                profile_sha256, profile_json, status, record_version,
                entity_json, worker_policy_json, integration_refs_json,
                archived_at, created_at, updated_at
            ) VALUES(
                ?, ?, ?, 'protocol/project-profile.json', ?, '{}', 'draft', 1,
                ?, '{}', '[]', NULL, ?, ?
            )
            """,
            (
                product_factory_id,
                project_id,
                f"D:/repo/{product_factory_id}",
                "1" * 64,
                canonical_json(entity),
                created_at,
                created_at,
            ),
        )
        connection.execute(
            """
            INSERT INTO product_factory_revisions(
                product_factory_id, record_version, operation, changed_by,
                reason, snapshot_json, profile_json, content_sha256,
                created_at
            ) VALUES(
                ?, 1, 'register', 'product-owner-one', NULL, ?, '{}', ?, ?
            )
            """,
            (
                product_factory_id,
                canonical_json(snapshot),
                canonical_sha256(snapshot),
                created_at,
            ),
        )

    @staticmethod
    def _transition_command(
        *,
        command_id: str,
        trigger: str,
        expected_version: int,
        actor_identity_id: str,
        role: str,
        mode: str,
        resource: str,
        action: str,
        field_bindings: dict | None = None,
        evidence_refs: dict | None = None,
        lease_ref: str | None = None,
        submitted_at: str,
    ) -> dict:
        command = {
            "version": "1.0.0",
            "command_id": command_id,
            "project_id": "transition-product",
            "work_item_id": "work-item-transition-one",
            "trigger": trigger,
            "expected_version": expected_version,
            "actor_identity_id": actor_identity_id,
            "reason": f"Apply governed transition {trigger}.",
            "field_bindings": field_bindings or {},
            "evidence_refs": evidence_refs or {},
            "authority": {
                "role": role,
                "mode": mode,
                "resource": resource,
                "action": action,
                "authority_ref": f"authority:{command_id}",
                "accountable_command_ref": f"command:{command_id}",
                "delegated_runtime_lease_ref": lease_ref,
                "request_sha256": "0" * 64,
                "decision": "allowed",
                "decision_ref": f"decision:{command_id}",
                "decided_at": submitted_at,
                "result_sha256": "0" * 64,
            },
            "submitted_at": submitted_at,
        }
        command["authority"]["request_sha256"] = (
            transition_authorization_request_sha256(command)
        )
        command["authority"]["result_sha256"] = (
            transition_authorization_result_sha256(command["authority"])
        )
        return command

    @staticmethod
    def _insert_product_revision(
        connection: sqlite3.Connection,
        *,
        record_version: int,
        created_at: str,
    ) -> None:
        entity = {
            "id": "product-factory-one",
            "project_id": "project-one",
            "status": "draft",
            "record_version": record_version,
        }
        snapshot = {
            **entity,
            "actor_identity_id": "product-owner-one",
        }
        connection.execute(
            """
            UPDATE product_factories
            SET record_version = ?, entity_json = ?, updated_at = ?
            WHERE id = 'product-factory-one'
            """,
            (record_version, canonical_json(entity), created_at),
        )
        connection.execute(
            """
            INSERT INTO product_factory_revisions(
                product_factory_id, record_version, operation, changed_by,
                reason, snapshot_json, profile_json, content_sha256,
                created_at
            ) VALUES(
                'product-factory-one', ?, 'update',
                'product-owner-one', 'Projection fixture revision.',
                ?, '{}', ?, ?
            )
            """,
            (
                record_version,
                canonical_json(snapshot),
                canonical_sha256(snapshot),
                created_at,
            ),
        )

    def test_empty_initialization_installs_ready_fail_closed_store(self) -> None:
        status = JournalInitializer(self.store).initialize()
        self.assertEqual(status["state"], "ready")
        self.assertEqual(status["sequence"], 0)
        self.assertIsNone(status["entry_id"])

        with operations_connection(self.store) as connection:
            trigger_count = connection.execute(
                """
                SELECT COUNT(*)
                FROM sqlite_master
                WHERE type = 'trigger'
                  AND name LIKE 'factory_journal_capture_%'
                """
            ).fetchone()[0]
            self.assertEqual(trigger_count, 19)

        with self.assertRaisesRegex(
            ProtocolError,
            "operation failed|active journal mutation",
        ):
            with operations_connection(
                self.store,
                isolation_level=None,
            ) as connection:
                connection.execute("BEGIN IMMEDIATE")
                self._insert_product(connection)

        with self.assertRaisesRegex(
            ProtocolError,
            "operation failed|not authorized",
        ):
            with operations_connection(
                self.store,
                isolation_level=None,
            ) as connection:
                connection.execute("BEGIN IMMEDIATE")
                connection.execute(
                    """
                    INSERT INTO factory_journal_pending_sources(
                        mutation_id, source_registry_id, primary_key_json,
                        source_identity_json, source_version, operation,
                        source_append_order, record_sha256, row_sha256
                    ) VALUES(
                        'mutation-forbidden', 'product-factory-revisions',
                        '{}', '{}', 1, 'register', 100, ?, ?
                    )
                    """,
                    ("1" * 64, "2" * 64),
                )

    def test_cutover_state_and_link_tables_are_fail_closed(self) -> None:
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            self.assertEqual(
                connection.execute(
                    """
                    SELECT value FROM metadata
                    WHERE key = 'journal_cutover_state'
                    """
                ).fetchone()[0],
                "legacy-backfill-pending",
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "requires a ready SF-106 journal",
            ):
                connection.execute("BEGIN IMMEDIATE")
                connection.execute(
                    "UPDATE product_factories SET status = status"
                )
                connection.commit()

        JournalInitializer(self.store).initialize()
        with operations_connection(self.store) as connection:
            self.assertEqual(
                connection.execute(
                    """
                    SELECT value FROM metadata
                    WHERE key = 'journal_cutover_state'
                    """
                ).fetchone()[0],
                "journal-required",
            )

        for table in (
            "work_item_dependencies",
            "work_item_source_links",
        ):
            with self.assertRaisesRegex(
                ProtocolError,
                "canonical write requires active journal mutation|"
                "observed a canonical write without a finalized journal",
            ):
                with operations_connection(
                    self.store,
                    isolation_level=None,
                ) as connection:
                    connection.execute("BEGIN IMMEDIATE")
                    connection.execute(
                        f"DELETE FROM {table} WHERE 1 = 0"
                    )
                    connection.commit()

    def test_trigger_body_tampering_fails_readiness_and_integrity(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        raw = sqlite3.connect(self.store)
        try:
            raw.executescript(
                """
                DROP TRIGGER
                    factory_journal_capture_product_factory_revisions;
                CREATE TRIGGER
                    factory_journal_capture_product_factory_revisions
                AFTER INSERT ON product_factory_revisions
                BEGIN
                    SELECT 1;
                END;
                """
            )
            raw.commit()
        finally:
            raw.close()
        with self.assertRaisesRegex(ProtocolError, "trigger SQL changed"):
            JournalIntegrity(self.store).verify()

    def test_preexisting_tampered_trigger_blocks_initial_readiness(
        self,
    ) -> None:
        raw = sqlite3.connect(self.store)
        try:
            raw.executescript(
                """
                CREATE TRIGGER
                    factory_journal_capture_product_factory_revisions
                AFTER INSERT ON product_factory_revisions
                BEGIN
                    SELECT 1;
                END;
                """
            )
            raw.commit()
        finally:
            raw.close()
        with self.assertRaisesRegex(ProtocolError, "trigger SQL changed"):
            JournalInitializer(self.store).initialize()

    def test_live_mutation_is_captured_and_committed_atomically(self) -> None:
        JournalInitializer(self.store).initialize()
        recorder = JournalRecorder()
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            connection.execute("BEGIN IMMEDIATE")
            context = recorder.begin_mutation(
                connection,
                coverage_branch_id="product.register",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "project_id": "project-one",
                    "configuration_sha256": "1" * 64,
                    "actor_identity_id": "product-owner-one",
                },
                pre_state=None,
                expected_result_versions={
                    "product-factory-one": 1,
                },
                source_actor={
                    "identity_id": "product-owner-one",
                    "kind": "human",
                },
            )
            self._insert_product(connection)
            result = recorder.append_pending_sources(
                connection,
                recorded_at="2026-08-11T12:00:01+00:00",
            )
            self.assertEqual(result.mutation_id, context.mutation_id)
            self.assertEqual(result.first_sequence, 1)
            self.assertEqual(result.last_sequence, 1)
            self.assertEqual(len(result.entries), 1)
            self.assertEqual(
                result.entries[0]["source_record"]["source_registry_id"],
                "product-factory-revisions",
            )
            connection.commit()

        status = JournalInitializer(self.store).status()
        self.assertEqual(status["sequence"], 1)
        self.assertEqual(
            status["entry_sha256"],
            result.entries[0]["entry_sha256"],
        )
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM product_factories"
                ).fetchone()[0],
                1,
            )
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM factory_journal_entries"
                ).fetchone()[0],
                1,
            )

    def test_commit_rejects_unfinished_mutation_and_rollback_clears_it(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        recorder = JournalRecorder()
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            connection.execute("BEGIN IMMEDIATE")
            recorder.begin_mutation(
                connection,
                coverage_branch_id="product.register",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "project_id": "project-one",
                    "configuration_sha256": "1" * 64,
                    "actor_identity_id": "product-owner-one",
                },
                pre_state=None,
                expected_result_versions={
                    "product-factory-one": 1,
                },
                source_actor={
                    "identity_id": "product-owner-one",
                    "kind": "human",
                },
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "active journal mutation context",
            ):
                connection.commit()
            connection.rollback()

        with operations_connection(self.store) as connection:
            self.assertEqual(
                connection.execute(
                    """
                    SELECT COUNT(*)
                    FROM factory_journal_mutation_contexts
                    """
                ).fetchone()[0],
                0,
            )

    def test_commit_rejects_unregistered_canonical_write_inventory(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        recorder = JournalRecorder()
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            connection.execute("BEGIN IMMEDIATE")
            recorder.begin_mutation(
                connection,
                coverage_branch_id="product.register",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "project_id": "project-one",
                    "configuration_sha256": "1" * 64,
                    "actor_identity_id": "product-owner-one",
                },
                pre_state=None,
                expected_result_versions={
                    "product-factory-one": 1,
                },
                source_actor={
                    "identity_id": "product-owner-one",
                    "kind": "human",
                },
            )
            connection.execute(
                """
                UPDATE work_items
                SET priority = priority
                WHERE id = 'missing-work-item'
                """
            )
            self._insert_product(connection)
            recorder.append_pending_sources(
                connection,
                recorded_at="2026-08-11T12:00:01+00:00",
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "outside registered mutation coverage",
            ):
                connection.commit()
            connection.rollback()
        with operations_connection(self.store) as connection:
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM product_factories"
                ).fetchone()[0],
                0,
            )
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM factory_journal_entries"
                ).fetchone()[0],
                0,
            )

    def test_existing_store_backfill_is_deterministic_and_idempotent(
        self,
    ) -> None:
        connection = sqlite3.connect(self.store)
        try:
            self._insert_product(connection)
            connection.commit()
        finally:
            connection.close()

        initializer = JournalInitializer(self.store)
        first = initializer.initialize()
        second = initializer.initialize()
        self.assertEqual(first, second)
        self.assertEqual(first["state"], "ready")
        self.assertEqual(first["sequence"], 1)

        with operations_connection(self.store) as connection:
            entry = connection.execute(
                """
                SELECT *
                FROM factory_journal_entries
                WHERE sequence = 1
                """
            ).fetchone()
            self.assertEqual(
                entry["coverage_branch_id"],
                "journal.backfill.snapshot",
            )
            self.assertTrue(entry["transaction_id"].startswith("backfill-"))
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM factory_journal_backfill"
                ).fetchone()[0],
                1,
            )

    def test_failed_backfill_records_failed_state_without_partial_entries(
        self,
    ) -> None:
        connection = sqlite3.connect(self.store)
        try:
            self._insert_product(connection, created_at="not-a-timestamp")
            connection.commit()
        finally:
            connection.close()

        with self.assertRaisesRegex(ProtocolError, "ISO-8601 timestamp"):
            JournalInitializer(self.store).initialize()
        with operations_connection(self.store) as connection:
            state = connection.execute(
                "SELECT * FROM factory_journal_state WHERE singleton = 1"
            ).fetchone()
            self.assertIsNotNone(state)
            self.assertEqual(state["state"], "failed")
            self.assertEqual(
                state["failure_code"],
                "journal-initialization-failed",
            )
            self.assertRegex(
                state["failure_detail_sha256"],
                r"^[a-f0-9]{64}$",
            )
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM factory_journal_entries"
                ).fetchone()[0],
                0,
            )

    def test_live_source_version_gap_rolls_back_source_and_journal(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        recorder = JournalRecorder()
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            connection.execute("BEGIN IMMEDIATE")
            recorder.begin_mutation(
                connection,
                coverage_branch_id="product.register",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "project_id": "project-one",
                    "configuration_sha256": "1" * 64,
                    "actor_identity_id": "product-owner-one",
                },
                pre_state=None,
                expected_result_versions={"product-factory-one": 1},
                source_actor={
                    "identity_id": "product-owner-one",
                    "kind": "human",
                },
            )
            self._insert_product(connection)
            recorder.append_pending_sources(connection)
            connection.commit()

        with self.assertRaisesRegex(ProtocolError, "version gap"):
            with operations_connection(
                self.store,
                isolation_level=None,
            ) as connection:
                connection.execute("BEGIN IMMEDIATE")
                recorder.begin_mutation(
                    connection,
                    coverage_branch_id="product.update",
                    project_id="project-one",
                    subject_id="product-factory-one",
                    identity_source={
                        "factory_id": "product-factory-one",
                        "expected_version": 1,
                        "configuration_sha256": "3" * 64,
                        "actor_identity_id": "product-owner-one",
                        "reason_sha256": canonical_sha256(
                            "Skip an invalid version."
                        ),
                    },
                    pre_state={
                        "record_version": 1,
                        "content_sha256": "1" * 64,
                    },
                    expected_result_versions={"product-factory-one": 3},
                    source_actor={
                        "identity_id": "product-owner-one",
                        "kind": "human",
                    },
                )
                self._insert_product_revision(
                    connection,
                    record_version=3,
                    created_at="2026-08-11T12:03:00+00:00",
                )
                recorder.append_pending_sources(connection)
                connection.commit()

        with operations_connection(self.store) as connection:
            self.assertEqual(
                connection.execute(
                    """
                    SELECT record_version
                    FROM product_factories
                    WHERE id = 'product-factory-one'
                    """
                ).fetchone()[0],
                1,
            )
            self.assertEqual(
                connection.execute(
                    """
                    SELECT COUNT(*)
                    FROM product_factory_revisions
                    WHERE product_factory_id = 'product-factory-one'
                    """
                ).fetchone()[0],
                1,
            )
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM factory_journal_entries"
                ).fetchone()[0],
                1,
            )

    def test_sf100_service_lifecycle_appends_one_fact_per_revision(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        repository = Path(self.temporary.name) / "product-one"
        repository.mkdir()
        (repository / ".git").mkdir()
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = "product-one"
        profile["name"] = "Product One"
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(profile, indent=2) + "\n",
            encoding="utf-8",
        )
        configuration = {
            "version": "1.0.0",
            "project_id": "product-one",
            "repository_root": str(repository.resolve()),
            "profile_path": ".elder/project-profile.json",
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [
                {
                    "id": "owner-inbox",
                    "kind": "manual",
                    "reference": "manual:owner-inbox",
                    "enabled": True,
                }
            ],
        }
        registry = ProductFactoryRegistry(self.store)
        factory_id = registry.register(
            configuration,
            actor_identity_id="founder",
            at="2026-08-11T12:10:00+00:00",
        )["product_factory"]["id"]
        registry.update(
            factory_id,
            configuration,
            expected_version=1,
            actor_identity_id="founder",
            reason="Rebind the verified configuration.",
            at="2026-08-11T12:11:00+00:00",
        )
        registry.activate(
            factory_id,
            expected_version=2,
            actor_identity_id="founder",
            at="2026-08-11T12:12:00+00:00",
        )
        registry.pause(
            factory_id,
            expected_version=3,
            actor_identity_id="founder",
            reason="Pause before retirement.",
            at="2026-08-11T12:13:00+00:00",
        )
        registry.archive(
            factory_id,
            expected_version=4,
            actor_identity_id="founder",
            decision="Owner decision retires this factory.",
            at="2026-08-11T12:14:00+00:00",
        )

        with operations_connection(self.store) as connection:
            rows = connection.execute(
                """
                SELECT coverage_branch_id, source_version, operation
                FROM factory_journal_entries
                ORDER BY sequence
                """
            ).fetchall()
        self.assertEqual(
            [row["coverage_branch_id"] for row in rows],
            [
                "product.register",
                "product.update",
                "product.activate",
                "product.pause",
                "product.archive",
            ],
        )
        self.assertEqual(
            [row["source_version"] for row in rows],
            [1, 2, 3, 4, 5],
        )
        self.assertEqual(
            [row["operation"] for row in rows],
            ["register", "update", "activate", "pause", "archive"],
        )

    def test_sf101_acceptance_appends_internal_facts_and_one_public_event(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        repository = Path(self.temporary.name) / "signal-product"
        repository.mkdir()
        (repository / ".git").mkdir()
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = "signal-product"
        profile["name"] = "Signal Product"
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(profile, indent=2) + "\n",
            encoding="utf-8",
        )
        configuration = {
            "version": "1.0.0",
            "project_id": "signal-product",
            "repository_root": str(repository.resolve()),
            "profile_path": ".elder/project-profile.json",
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [
                {
                    "id": "owner-inbox",
                    "kind": "manual",
                    "reference": "manual:owner-inbox",
                    "enabled": True,
                }
            ],
        }
        registry = ProductFactoryRegistry(self.store)
        factory_id = registry.register(
            configuration,
            actor_identity_id="founder",
            at="2026-08-11T13:00:00+00:00",
        )["product_factory"]["id"]
        registry.activate(
            factory_id,
            expected_version=1,
            actor_identity_id="founder",
            at="2026-08-11T13:01:00+00:00",
        )
        normalized = {
            "type": "work-request",
            "title": "Create the governed intake path",
            "description": "Exercise the accepted public event mapping.",
            "priority": "normal",
            "labels": ["sf-106"],
        }
        envelope = {
            "version": "1.0.0",
            "signal_id": "signal-manual-one",
            "project_id": "signal-product",
            "integration_id": "owner-inbox",
            "source": "manual",
            "source_reference": "manual:owner-inbox/request-one",
            "source_event_id": "owner-request-one",
            "source_sequence": None,
            "idempotency_key": "owner-request-one",
            "occurred_at": "2026-08-11T13:02:00+00:00",
            "authentication": {
                "status": "verified",
                "method": "profile-role-binding",
                "principal_ref": "founder",
                "evidence_ref": "profile:signal-product:founder",
                "verified_at": "2026-08-11T13:02:01+00:00",
            },
            "normalized": normalized,
            "payload_sha256": canonical_sha256(normalized),
        }
        intake = SignalIntake(self.store)
        accepted = intake.ingest(
            envelope,
            actor_identity_id="founder",
            received_at="2026-08-11T13:02:02+00:00",
        )
        self.assertEqual(accepted["signal"]["status"], "accepted")

        rejected_envelope = copy.deepcopy(envelope)
        rejected_envelope["signal_id"] = "signal-manual-two"
        rejected_envelope["source_event_id"] = "owner-request-two"
        rejected_envelope["source_reference"] = (
            "manual:owner-inbox/request-two"
        )
        rejected_envelope["idempotency_key"] = "owner-request-two"
        rejected_envelope["authentication"] = {
            "status": "failed",
            "method": "profile-role-binding",
            "principal_ref": None,
            "evidence_ref": None,
            "verified_at": None,
        }
        rejected = intake.ingest(
            rejected_envelope,
            actor_identity_id="founder",
            received_at="2026-08-11T13:03:00+00:00",
        )
        self.assertEqual(rejected["signal"]["status"], "rejected")

        with operations_connection(self.store) as connection:
            signal_entries = connection.execute(
                """
                SELECT sequence, operation
                FROM factory_journal_entries
                WHERE source_registry_id = 'signal-revisions'
                ORDER BY sequence
                """
            ).fetchall()
            public_events = connection.execute(
                """
                SELECT *
                FROM factory_public_events
                ORDER BY sequence
                """
            ).fetchall()
        self.assertEqual(
            [row["operation"] for row in signal_entries],
            ["receive", "accept", "receive", "reject"],
        )
        self.assertEqual(len(public_events), 1)
        event = json.loads(public_events[0]["event_json"])
        self.assertEqual(
            event["event_type"],
            "integration.signal.accepted",
        )
        self.assertEqual(
            event["payload"],
            {
                "signal_id": "signal-manual-one",
                "source_reference": "manual:owner-inbox/request-one",
            },
        )
        self.assertEqual(event["cursor"]["sequence"], 1)
        self.assertEqual(
            event["extensions"]["elder.local/journal-entry-id"],
            public_events[0]["internal_entry_id"],
        )
        reader = JournalIntegrity(self.store)
        first_page = reader.read_public_events(
            project_id="signal-product",
            limit=1,
        )
        self.assertEqual(len(first_page["events"]), 1)
        current_page = reader.read_public_events(
            project_id="signal-product",
            cursor=first_page["cursor"],
            limit=1,
        )
        self.assertEqual(current_page["events"], [])
        stale = copy.deepcopy(first_page["cursor"])
        stale["event_id"] = "event-" + "f" * 32
        with self.assertRaises(StaleEventCursorError) as stale_context:
            reader.read_public_events(
                project_id="signal-product",
                cursor=stale,
            )
        for field in (
            "stream_id",
            "generation",
            "sequence",
            "event_id",
            "snapshot_sha256",
        ):
            self.assertEqual(
                stale_context.exception.current_cursor[field],
                first_page["cursor"][field],
            )
        wrong_stream = copy.deepcopy(first_page["cursor"])
        wrong_stream["stream_id"] = "factory-public-events-other"
        with self.assertRaisesRegex(ProtocolError, "different stream"):
            reader.read_public_events(
                project_id="signal-product",
                cursor=wrong_stream,
            )
        future = copy.deepcopy(first_page["cursor"])
        future["sequence"] = 2
        future["event_id"] = "event-" + "f" * 32
        future["snapshot_sha256"] = public_stream_snapshot_sha256(
            stream_id=future["stream_id"],
            generation=future["generation"],
            sequence=2,
            event_id=future["event_id"],
            event_document_sha256="e" * 64,
        )
        with self.assertRaisesRegex(ProtocolError, "future"):
            reader.read_public_events(
                project_id="signal-product",
                cursor=future,
            )

    def test_sf102_signal_conversion_and_revision_are_transactional(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        repository = Path(self.temporary.name) / "ledger-product"
        repository.mkdir()
        (repository / ".git").mkdir()
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = "ledger-product"
        profile["name"] = "Ledger Product"
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(profile, indent=2) + "\n",
            encoding="utf-8",
        )
        configuration = {
            "version": "1.0.0",
            "project_id": "ledger-product",
            "repository_root": str(repository.resolve()),
            "profile_path": ".elder/project-profile.json",
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [
                {
                    "id": "owner-inbox",
                    "kind": "manual",
                    "reference": "manual:owner-inbox",
                    "enabled": True,
                }
            ],
        }
        registry = ProductFactoryRegistry(self.store)
        factory_id = registry.register(
            configuration,
            actor_identity_id="founder",
            at="2026-08-11T14:00:00+00:00",
        )["product_factory"]["id"]
        registry.activate(
            factory_id,
            expected_version=1,
            actor_identity_id="founder",
            at="2026-08-11T14:01:00+00:00",
        )
        normalized = {
            "type": "work-request",
            "title": "Create a durable work item",
            "description": "Exercise atomic signal conversion.",
            "priority": "high",
            "labels": ["sf-102"],
        }
        envelope = {
            "version": "1.0.0",
            "signal_id": "signal-ledger-one",
            "project_id": "ledger-product",
            "integration_id": "owner-inbox",
            "source": "manual",
            "source_reference": "manual:owner-inbox/ledger-one",
            "source_event_id": "owner-ledger-one",
            "source_sequence": None,
            "idempotency_key": "owner-ledger-one",
            "occurred_at": "2026-08-11T14:02:00+00:00",
            "authentication": {
                "status": "verified",
                "method": "profile-role-binding",
                "principal_ref": "founder",
                "evidence_ref": "profile:ledger-product:founder",
                "verified_at": "2026-08-11T14:02:01+00:00",
            },
            "normalized": normalized,
            "payload_sha256": canonical_sha256(normalized),
        }
        intake = SignalIntake(self.store)
        accepted = intake.ingest(
            envelope,
            actor_identity_id="founder",
            received_at="2026-08-11T14:02:02+00:00",
        )
        specification = {
            "version": "1.0.0",
            "work_item_id": "work-item-ledger-one",
            "project_id": "ledger-product",
            "objective": "Implement the durable ledger path.",
            "scope": ["journal integration", "component proof"],
            "non_goals": ["production deployment"],
            "priority": "high",
            "owner_identity_id": "founder",
            "acceptance_criteria": [
                "Signal conversion is atomic.",
                "Work-item history is journaled.",
            ],
            "outcome_ids": ["outcome:governed-workflow"],
            "change_class": "internal-code",
            "evidence_plan": [
                "foundation tests",
                "component tests",
                "independent evaluation",
            ],
            "authority_refs": ["profile:ledger-product/founder"],
            "dependencies": [],
            "source_links": [
                {
                    "kind": "signal",
                    "reference": "signal:signal-ledger-one",
                    "content_sha256": accepted["signal"]["content_sha256"],
                }
            ],
        }
        ledger = WorkItemLedger(self.store)
        created = ledger.create_from_signal(
            "signal-ledger-one",
            specification,
            actor_identity_id="founder",
            change_reason="Owner accepted the signal as bounded work.",
            at="2026-08-11T14:03:00+00:00",
        )
        self.assertEqual(created["work_item"]["record_version"], 1)
        revised = copy.deepcopy(specification)
        revised["objective"] = (
            "Implement and verify the durable ledger path."
        )
        ledger.update(
            revised,
            expected_version=1,
            actor_identity_id="founder",
            change_reason="Add explicit verification to the objective.",
            at="2026-08-11T14:04:00+00:00",
        )

        with operations_connection(self.store) as connection:
            rows = connection.execute(
                """
                SELECT transaction_id, transaction_fact_count,
                       source_registry_id, operation, coverage_branch_id
                FROM factory_journal_entries
                WHERE coverage_branch_id LIKE 'work-item.%'
                ORDER BY sequence
                """
            ).fetchall()
        self.assertEqual(len(rows), 3)
        composite = [
            row
            for row in rows
            if row["coverage_branch_id"]
            == "work-item.create-from-signal"
        ]
        self.assertEqual(len(composite), 2)
        self.assertEqual(
            {row["transaction_id"] for row in composite},
            {composite[0]["transaction_id"]},
        )
        self.assertEqual(
            {row["transaction_fact_count"] for row in composite},
            {2},
        )
        self.assertEqual(
            {row["source_registry_id"] for row in composite},
            {"signal-revisions", "work-item-history"},
        )
        self.assertEqual(
            rows[-1]["coverage_branch_id"],
            "work-item.update",
        )

    def test_sf103_rejected_nonterminal_and_terminal_batches_are_exact(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        repository = Path(self.temporary.name) / "transition-product"
        repository.mkdir()
        (repository / ".git").mkdir()
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = "transition-product"
        profile["name"] = "Transition Product"
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(profile, indent=2) + "\n",
            encoding="utf-8",
        )
        registry = ProductFactoryRegistry(self.store)
        configuration = {
            "version": "1.0.0",
            "project_id": "transition-product",
            "repository_root": str(repository.resolve()),
            "profile_path": ".elder/project-profile.json",
            "worker_policy": {
                "adapter_id": "codex",
                "max_concurrent_workers": 1,
                "approval_policy": "on-request",
                "sandbox_mode": "workspace-write",
                "network_access": False,
            },
            "integration_refs": [
                {
                    "id": "owner-inbox",
                    "kind": "manual",
                    "reference": "manual:owner-inbox",
                    "enabled": True,
                }
            ],
        }
        factory_id = registry.register(
            configuration,
            actor_identity_id="founder",
            at="2026-08-11T15:00:00+00:00",
        )["product_factory"]["id"]
        registry.activate(
            factory_id,
            expected_version=1,
            actor_identity_id="founder",
            at="2026-08-11T15:01:00+00:00",
        )
        specification = {
            "version": "1.0.0",
            "work_item_id": "work-item-transition-one",
            "project_id": "transition-product",
            "objective": "Exercise transition journal branches.",
            "scope": ["transition engine", "journal receipts"],
            "non_goals": ["runtime dispatch"],
            "priority": "normal",
            "owner_identity_id": "founder",
            "acceptance_criteria": [
                "Rejected transitions are durable.",
                "Terminal hooks are journaled.",
            ],
            "outcome_ids": ["outcome:governed-workflow"],
            "change_class": "internal-code",
            "evidence_plan": [
                "foundation tests",
                "component tests",
                "independent evaluation",
            ],
            "authority_refs": ["profile:transition-product/founder"],
            "dependencies": [],
            "source_links": [
                {
                    "kind": "manual",
                    "reference": "manual:owner-backlog/transition-one",
                    "content_sha256": None,
                }
            ],
        }
        ledger = WorkItemLedger(self.store)
        created = ledger.create(
            specification,
            actor_identity_id="founder",
            change_reason="Create the transition test item.",
            at="2026-08-11T15:02:00+00:00",
        )
        revision_id = created["current_revision"]["id"]
        engine = WorkItemTransitionEngine(self.store)
        rejected = self._transition_command(
            command_id="transition-command-illegal-start-one",
            trigger="start",
            expected_version=1,
            actor_identity_id="example-agentic-product-executor",
            role="executor",
            mode="execute-bounded",
            resource="implementation",
            action="execute",
            evidence_refs={"active run reference": "run:illegal-one"},
            lease_ref="lease:executor/illegal-one",
            submitted_at="2026-08-11T15:03:00+00:00",
        )
        self.assertFalse(
            engine.apply(
                rejected,
                at="2026-08-11T15:03:01+00:00",
            )["decision"]["accepted"]
        )
        submit = self._transition_command(
            command_id="transition-command-submit-one",
            trigger="submit",
            expected_version=1,
            actor_identity_id="founder",
            role="product-owner",
            mode="modify-only",
            resource="obligation",
            action="modify",
            field_bindings={
                "revision_id": revision_id,
                "evidence_plan": specification["evidence_plan"],
            },
            submitted_at="2026-08-11T15:04:00+00:00",
        )
        self.assertTrue(
            engine.apply(
                submit,
                at="2026-08-11T15:04:01+00:00",
            )["decision"]["accepted"]
        )
        cancel = self._transition_command(
            command_id="transition-command-cancel-one",
            trigger="cancel",
            expected_version=2,
            actor_identity_id="founder",
            role="product-owner",
            mode="human-approval",
            resource="approval-decision",
            action="approve",
            evidence_refs={
                "cancellation decision": "decision:cancel-transition-one"
            },
            submitted_at="2026-08-11T15:05:00+00:00",
        )
        self.assertTrue(
            engine.apply(
                cancel,
                at="2026-08-11T15:05:01+00:00",
            )["decision"]["accepted"]
        )

        with operations_connection(self.store) as connection:
            batches = connection.execute(
                """
                SELECT coverage_branch_id, transaction_id,
                       transaction_fact_count, COUNT(*) AS entry_count
                FROM factory_journal_entries
                WHERE coverage_branch_id LIKE 'transition.apply.%'
                GROUP BY coverage_branch_id, transaction_id,
                         transaction_fact_count
                ORDER BY MIN(sequence)
                """
            ).fetchall()
        self.assertEqual(
            [
                (
                    row["coverage_branch_id"],
                    row["transaction_fact_count"],
                    row["entry_count"],
                )
                for row in batches
            ],
            [
                ("transition.apply.rejected", 1, 1),
                ("transition.apply.recorded-nonterminal", 2, 2),
                ("transition.apply.recorded-terminal", 3, 3),
            ],
        )

    def test_sf104_dispatch_lifecycle_appends_registered_branches(
        self,
    ) -> None:
        from tests.component.test_durable_dispatcher import (
            DurableDispatcherComponentTests,
        )

        fixture = DurableDispatcherComponentTests(methodName="runTest")
        dispatcher, submission = fixture._dispatcher(
            Path(self.temporary.name)
        )
        JournalInitializer(self.store).initialize()
        submitted = dispatcher.submit(
            submission,
            at="2026-08-11T01:02:01+00:00",
        )
        claimed = dispatcher.claim_next(
            owner_id="worker-one",
            at="2026-08-11T01:02:02+00:00",
            lease_seconds=60,
        )
        self.assertIsNotNone(claimed)
        lease_generation = claimed["lease"]["generation"]
        renewed = dispatcher.renew(
            submitted["dispatch_id"],
            owner_id="worker-one",
            lease_generation=lease_generation,
            at="2026-08-11T01:02:10+00:00",
            lease_seconds=120,
        )
        self.assertEqual(
            renewed["lease"]["generation"],
            lease_generation,
        )
        started = dispatcher.begin_execution(
            submitted["dispatch_id"],
            owner_id="worker-one",
            lease_generation=lease_generation,
            at="2026-08-11T01:02:11+00:00",
        )
        response = fixture._response(
            started["adapter_request"],
            disposition="succeeded",
            responded_at="2026-08-11T01:02:12+00:00",
        )
        completed = dispatcher.record_response(
            submitted["dispatch_id"],
            response,
            owner_id="worker-one",
            lease_generation=lease_generation,
            at="2026-08-11T01:02:12+00:00",
        )
        self.assertEqual(completed["status"], "completed")

        with operations_connection(self.store) as connection:
            rows = connection.execute(
                """
                SELECT coverage_branch_id, transaction_fact_count,
                       source_registry_id
                FROM factory_journal_entries
                WHERE coverage_branch_id LIKE 'dispatch.%'
                ORDER BY sequence
                """
            ).fetchall()
        self.assertEqual(
            [row["coverage_branch_id"] for row in rows],
            [
                "dispatch.submit",
                "dispatch.claim",
                "dispatch.renew",
                "dispatch.begin-execution",
                "dispatch.response.completed",
            ],
        )
        self.assertEqual(
            {row["transaction_fact_count"] for row in rows},
            {1},
        )
        self.assertEqual(
            {row["source_registry_id"] for row in rows},
            {"dispatch-history"},
        )

    def test_sf105_run_operations_append_atomic_registered_batches(
        self,
    ) -> None:
        from tests.component.test_run_controller import (
            RunControllerComponentTests,
        )

        fixture = RunControllerComponentTests(methodName="runTest")
        workspace = Path(self.temporary.name) / "sf105-journal"
        workspace.mkdir()
        controller, submission, _ = fixture._controller_fixture(workspace)
        JournalInitializer(controller.path).initialize()

        aggregate = controller.bind_start(
            submission,
            at="2026-08-11T01:04:01+00:00",
        )
        with operations_connection(controller.path) as connection:
            bind_count = connection.execute(
                """
                SELECT COUNT(*)
                FROM factory_journal_entries
                WHERE coverage_branch_id = 'run.bind-start'
                """
            ).fetchone()[0]
        controller.bind_start(
            submission,
            at="2026-08-11T01:04:02+00:00",
        )
        with operations_connection(controller.path) as connection:
            self.assertEqual(
                connection.execute(
                    """
                    SELECT COUNT(*)
                    FROM factory_journal_entries
                    WHERE coverage_branch_id = 'run.bind-start'
                    """
                ).fetchone()[0],
                bind_count,
            )

        steps = (
            (
                ["workspace-provision"],
                "journal-workspace-provision",
                {
                    "repository": aggregate["initial_binding"][
                        "repository_root"
                    ],
                    "base_revision": aggregate["initial_binding"][
                        "base_revision"
                    ],
                },
                {},
                "2026-08-11T01:05:00+00:00",
            ),
            (
                ["workspace-ready"],
                "journal-workspace-ready",
                {
                    "path": aggregate["initial_binding"]["workspace_path"],
                    "isolation_mode": "planned-git-worktree",
                },
                {"workspace verification": "evidence:journal-workspace"},
                "2026-08-11T01:06:00+00:00",
            ),
            (
                ["worker-session-start"],
                "journal-session-start",
                {
                    "run_id": aggregate["run"]["id"],
                    "worker_adapter": aggregate["initial_binding"][
                        "worker_adapter_id"
                    ],
                },
                {},
                "2026-08-11T01:07:00+00:00",
            ),
            (
                ["worker-session-activate"],
                "journal-session-activate",
                {"external_session_ref": "codex-thread:journal"},
                {"worker acknowledgement": "evidence:journal-ack"},
                "2026-08-11T01:08:00+00:00",
            ),
        )
        for index, (
            transition_ids,
            suffix,
            payload,
            evidence,
            recorded_at,
        ) in enumerate(steps):
            if index == 1:
                rejected = fixture._command(
                    aggregate,
                    transition_ids,
                    suffix="journal-workspace-ready-rejected",
                    payload={
                        "path": "D:/wrong-workspace",
                        "isolation_mode": "planned-git-worktree",
                    },
                    evidence_refs=evidence,
                    at="2026-08-11T01:05:30+00:00",
                )
                self.assertEqual(
                    controller.apply(
                        rejected,
                        at="2026-08-11T01:05:30+00:00",
                    )["status"],
                    "rejected",
                )
            command = fixture._command(
                aggregate,
                transition_ids,
                suffix=suffix,
                payload=payload,
                evidence_refs=evidence,
                at=recorded_at,
            )
            result = controller.apply(command, at=recorded_at)
            self.assertEqual(result["status"], "applied")
            aggregate = controller.get(aggregate["run"]["id"])

        prepare = fixture._command(
            aggregate,
            ["run-claim", "workspace-bind", "run-start"],
            suffix="journal-prepare-start",
            payload={
                "authority_ref": aggregate["initial_binding"][
                    "authority_ref"
                ],
                "run_id": aggregate["run"]["id"],
                "worker_session_id": aggregate["worker_session"]["id"],
            },
            evidence_refs={
                "active lease": "lease:transition-command-queue-build-repair"
            },
            at="2026-08-11T01:09:00+00:00",
        )
        pending = controller.prepare_work_item_start(
            prepare,
            at="2026-08-11T01:09:00+00:00",
        )
        uncertain = controller.mark_work_item_start_uncertain(
            prepare["command_id"],
            at="2026-08-11T01:09:01+00:00",
        )
        self.assertEqual(uncertain["status"], "uncertain")
        controller._transitions.apply(
            pending["result"]["transition_command"],
            at="2026-08-11T01:09:02+00:00",
        )
        confirmed = controller.confirm_work_item_start(
            prepare["command_id"],
            at="2026-08-11T01:09:03+00:00",
        )
        self.assertEqual(confirmed["status"], "confirmed")
        aggregate = controller.get(aggregate["run"]["id"])

        child = controller._coordination.records["child_runs"][
            aggregate["initial_binding"]["elder_child_run_id"]
        ]
        observation = {
            "version": "1.0.0",
            "run_id": aggregate["run"]["id"],
            "observation_version": 2,
            "elder_run_id": child["id"],
            "elder_status": child["status"],
            "cancellation_status": child["cancellation_status"],
            "elder_run_sha256": canonical_sha256(child),
            "source_ref": f"coordination-run:{child['id']}",
            "reconciliation_state": "current",
            "reason": "Reconcile the active canonical child run.",
            "causation_command_id": prepare["command_id"],
            "observed_at": "2026-08-11T01:09:04+00:00",
            "content_sha256": None,
        }
        observation["content_sha256"] = record_content_sha256(observation)
        controller.record_elder_observation(observation)

        checkpoint = finalize_checkpoint(
            {
                "version": "0.5.1",
                "id": "journal-checkpoint-1",
                "project_id": "product-one",
                "delegation_id": aggregate["initial_binding"][
                    "elder_delegation_id"
                ],
                "run_id": aggregate["initial_binding"][
                    "elder_child_run_id"
                ],
                "sequence": 1,
                "action_sequence": 1,
                "status": "running",
                "completed_scope": [],
                "remaining_scope": ["src/component"],
                "evidence_refs": [],
                "budget_consumed": {
                    "token_limit": 10,
                    "cost_limit_usd": 0,
                    "tool_call_limit": 1,
                    "elapsed_seconds_limit": 10,
                },
                "previous_checkpoint_sha256": None,
                "created_at": "2026-08-11T01:09:05+00:00",
            }
        )
        controller._coordination.records["checkpoints"][
            checkpoint["id"]
        ] = checkpoint
        worker_observation = {
            "id": "journal-worker-observation-1",
            "checkpoint_id": checkpoint["id"],
            "checkpoint_sha256": checkpoint["content_sha256"],
        }
        checkpoint_reference = {
            "version": "1.0.0",
            "id": "journal-checkpoint-reference-1",
            "run_id": aggregate["run"]["id"],
            "worker_session_id": aggregate["worker_session"]["id"],
            "elder_run_id": aggregate["initial_binding"][
                "elder_child_run_id"
            ],
            "elder_run_sha256": aggregate["initial_binding"][
                "elder_child_run_sha256"
            ],
            "project_id": "product-one",
            "delegation_id": aggregate["initial_binding"][
                "elder_delegation_id"
            ],
            "session_generation": 1,
            "checkpoint_id": checkpoint["id"],
            "checkpoint_sha256": checkpoint["content_sha256"],
            "adapter_cursor": "cursor-journal-0001",
            "observation_sequence": 1,
            "checkpoint_sequence": 1,
            "previous_checkpoint_sha256": None,
            "worker_observation_id": worker_observation["id"],
            "worker_observation_sha256": canonical_sha256(
                worker_observation
            ),
            "recorded_at": "2026-08-11T01:09:06+00:00",
            "content_sha256": None,
        }
        checkpoint_reference["content_sha256"] = record_content_sha256(
            checkpoint_reference
        )
        checkpoint_command = fixture._command(
            aggregate,
            ["checkpoint-reference"],
            suffix="journal-checkpoint-reference",
            payload={},
            evidence_refs={},
            at="2026-08-11T01:09:06+00:00",
        )
        self.assertEqual(
            controller.record_checkpoint_reference(
                checkpoint_command,
                checkpoint_reference,
                checkpoint=checkpoint,
                worker_observation=worker_observation,
                at="2026-08-11T01:09:06+00:00",
            )["status"],
            "applied",
        )
        aggregate = controller.get(aggregate["run"]["id"])

        artifact = {
            "version": "1.0.0",
            "id": "journal-artifact-reference-1",
            "run_id": aggregate["run"]["id"],
            "artifact_sha256": "f" * 64,
            "artifact_type": "diff",
            "provenance_ref": "git-diff:journal-one",
            "status": "produced",
            "target_locator": None,
            "session_generation": 1,
            "recorded_at": "2026-08-11T01:09:07+00:00",
            "content_sha256": None,
        }
        artifact["content_sha256"] = record_content_sha256(artifact)
        artifact_command = fixture._command(
            aggregate,
            ["artifact-reference"],
            suffix="journal-artifact-reference",
            payload={},
            evidence_refs={},
            at="2026-08-11T01:09:07+00:00",
        )
        self.assertEqual(
            controller.record_artifact_reference(
                artifact_command,
                artifact,
                at="2026-08-11T01:09:07+00:00",
            )["status"],
            "applied",
        )

        with operations_connection(controller.path) as connection:
            branch_rows = connection.execute(
                """
                SELECT coverage_branch_id, transaction_id,
                       transaction_fact_count, COUNT(*) AS entry_count
                FROM factory_journal_entries
                WHERE coverage_branch_id LIKE 'run.%'
                GROUP BY coverage_branch_id, transaction_id,
                         transaction_fact_count
                ORDER BY MIN(sequence)
                """
            ).fetchall()
            sequence_before_replays = connection.execute(
                "SELECT MAX(sequence) FROM factory_journal_entries"
            ).fetchone()[0]
        observed_branches = [
            row["coverage_branch_id"] for row in branch_rows
        ]
        self.assertEqual(observed_branches.count("run.bind-start"), 1)
        self.assertEqual(observed_branches.count("run.lifecycle-apply"), 5)
        for expected_branch in (
            "run.work-item-start-prepare",
            "run.work-item-start-uncertain",
            "run.work-item-start-confirm",
            "run.elder-observation",
            "run.checkpoint-reference",
            "run.artifact-reference",
        ):
            self.assertEqual(observed_branches.count(expected_branch), 1)
        self.assertTrue(
            all(
                row["transaction_fact_count"] == row["entry_count"]
                for row in branch_rows
            )
        )

        controller.confirm_work_item_start(
            prepare["command_id"],
            at="2026-08-11T01:09:08+00:00",
        )
        controller.record_elder_observation(observation)
        controller.record_checkpoint_reference(
            checkpoint_command,
            checkpoint_reference,
            checkpoint=checkpoint,
            worker_observation=worker_observation,
            at="2026-08-11T01:09:06+00:00",
        )
        controller.record_artifact_reference(
            artifact_command,
            artifact,
            at="2026-08-11T01:09:07+00:00",
        )
        with operations_connection(controller.path) as connection:
            self.assertEqual(
                connection.execute(
                    "SELECT MAX(sequence) FROM factory_journal_entries"
                ).fetchone()[0],
                sequence_before_replays,
            )

    def test_projection_rebuild_query_and_stale_token_are_deterministic(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        recorder = JournalRecorder()
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            connection.execute("BEGIN IMMEDIATE")
            recorder.begin_mutation(
                connection,
                coverage_branch_id="product.register",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "project_id": "project-one",
                    "configuration_sha256": "1" * 64,
                    "actor_identity_id": "product-owner-one",
                },
                pre_state=None,
                expected_result_versions={"product-factory-one": 1},
                source_actor={
                    "identity_id": "product-owner-one",
                    "kind": "human",
                },
            )
            self._insert_product(connection)
            recorder.append_pending_sources(
                connection,
                recorded_at="2026-08-11T12:00:01+00:00",
            )
            connection.commit()
        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            connection.execute("BEGIN IMMEDIATE")
            recorder.begin_mutation(
                connection,
                coverage_branch_id="product.update",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "factory_id": "product-factory-one",
                    "expected_version": 1,
                    "configuration_sha256": "2" * 64,
                    "actor_identity_id": "product-owner-one",
                    "reason_sha256": canonical_sha256(
                        "Projection fixture revision."
                    ),
                },
                pre_state={
                    "record_version": 1,
                    "content_sha256": canonical_sha256(
                        {
                            "id": "product-factory-one",
                            "project_id": "project-one",
                            "status": "draft",
                            "record_version": 1,
                        }
                    ),
                },
                expected_result_versions={"product-factory-one": 2},
                source_actor={
                    "identity_id": "product-owner-one",
                    "kind": "human",
                },
            )
            self._insert_product_revision(
                connection,
                record_version=2,
                created_at="2026-08-11T12:02:00+00:00",
            )
            recorder.append_pending_sources(
                connection,
                recorded_at="2026-08-11T12:02:01+00:00",
            )
            connection.commit()

        integrity = JournalIntegrity(self.store).verify()
        self.assertEqual(integrity["entry_count"], 2)
        runtime = ProjectionRuntime(self.store)
        rebuilt = runtime.rebuild_all(batch_size=1)
        self.assertEqual(set(rebuilt), {
            "commands",
            "products",
            "runs",
            "signals",
            "timeline",
            "transitions",
            "work-items",
        })
        self.assertEqual(rebuilt["products"]["row_count"], 1)
        self.assertEqual(rebuilt["timeline"]["row_count"], 2)

        queries = ProjectionQueries(self.store)
        first_page = queries.timeline(
            project_id="project-one",
            limit=1,
        )
        self.assertEqual(len(first_page["items"]), 1)
        self.assertIsNotNone(first_page["continuation"])
        second_page = queries.timeline(
            project_id="project-one",
            limit=1,
            continuation=first_page["continuation"],
        )
        self.assertEqual(len(second_page["items"]), 1)
        self.assertNotEqual(
            first_page["items"][0]["subject_id"],
            second_page["items"][0]["subject_id"],
        )
        self.assertIsNone(second_page["continuation"])

        with operations_connection(
            self.store,
            isolation_level=None,
        ) as connection:
            connection.execute("BEGIN IMMEDIATE")
            recorder.begin_mutation(
                connection,
                coverage_branch_id="product.update",
                project_id="project-one",
                subject_id="product-factory-one",
                identity_source={
                    "factory_id": "product-factory-one",
                    "expected_version": 2,
                    "configuration_sha256": "3" * 64,
                    "actor_identity_id": "product-owner-one",
                    "reason_sha256": canonical_sha256(
                        "Projection fixture revision."
                    ),
                },
                pre_state={
                    "record_version": 2,
                    "content_sha256": canonical_sha256(
                        {
                            "id": "product-factory-one",
                            "project_id": "project-one",
                            "status": "draft",
                            "record_version": 2,
                        }
                    ),
                },
                expected_result_versions={"product-factory-one": 3},
                source_actor={
                    "identity_id": "product-owner-one",
                    "kind": "human",
                },
            )
            self._insert_product_revision(
                connection,
                created_at="2026-08-11T12:03:00+00:00",
                record_version=3,
            )
            recorder.append_pending_sources(
                connection,
                recorded_at="2026-08-11T12:03:01+00:00",
            )
            connection.commit()
        product_generation = rebuilt["products"]["generation"]
        timeline_generation = rebuilt["timeline"]["generation"]
        runtime.project_until_current(
            "products",
            product_generation,
            batch_size=1,
        )
        runtime.project_until_current(
            "timeline",
            timeline_generation,
            batch_size=1,
        )
        with self.assertRaises(StaleProjectionTokenError):
            queries.timeline(
                project_id="project-one",
                limit=1,
                continuation=first_page["continuation"],
            )

        active = runtime.verify_projection(
            "products",
            require_current=True,
        )
        replacement = runtime.rebuild_projection(
            "products",
            batch_size=1,
        )
        self.assertEqual(
            replacement["projection_sha256"],
            active["projection_sha256"],
        )
        self.assertEqual(replacement["row_count"], 1)
        cleanup = runtime.cleanup_superseded(
            "products",
            active["generation"],
        )
        self.assertEqual(cleanup["status"], "removed")
        self.assertEqual(
            cleanup["active_generation"],
            replacement["generation"],
        )

        backup_root = Path(self.temporary.name) / "operations-backups"
        backup = OperationsBackupCoordinator(self.store).create(
            backup_root,
            backup_id="operations-backup-projection-test",
            at="2026-08-11T12:04:00+00:00",
        )
        backup_directory = Path(backup["backup_directory"])
        verified_backup = OperationsBackupCoordinator.verify_backup(
            backup_directory
        )
        self.assertEqual(verified_backup["status"], "verified")
        restored_path = (
            Path(self.temporary.name) / "restored" / "operations.db"
        )
        restored = OperationsBackupCoordinator.restore(
            backup_directory,
            restored_path,
        )
        self.assertEqual(restored["status"], "restored")
        self.assertEqual(
            JournalIntegrity(restored_path).verify()["cursor"][
                "snapshot_sha256"
            ],
            JournalIntegrity(self.store).verify()["cursor"][
                "snapshot_sha256"
            ],
        )
        self.assertEqual(
            ProjectionQueries(restored_path).list_products(
                project_id="project-one"
            )["items"],
            ProjectionQueries(self.store).list_products(
                project_id="project-one"
            )["items"],
        )

        marker = backup_directory / "COMMITTED"
        marker.write_text("0" * 64 + "\n", encoding="ascii")
        with self.assertRaisesRegex(ProtocolError, "commit marker"):
            OperationsBackupCoordinator.verify_backup(backup_directory)

    def test_backup_metadata_and_interruption_paths_fail_closed(self) -> None:
        JournalInitializer(self.store).initialize()
        ProjectionRuntime(self.store).rebuild_all(batch_size=2)
        backup_root = Path(self.temporary.name) / "atomic-backups"

        for label in (
            "after-snapshot",
            "after-manifest",
            "after-committed-marker",
            "before-publish",
        ):
            backup_id = f"interrupted-{label}"

            def fail(point: str, *, expected: str = label) -> None:
                if point == expected:
                    raise RuntimeError(f"injected backup failure: {point}")

            with self.assertRaisesRegex(
                RuntimeError,
                f"injected backup failure: {label}",
            ):
                OperationsBackupCoordinator(
                    self.store,
                    fault_injector=fail,
                ).create(
                    backup_root,
                    backup_id=backup_id,
                    at="2026-08-11T12:05:00+00:00",
                )
            self.assertFalse((backup_root / backup_id).exists())
            temporary = backup_root / f"{backup_id}.tmp"
            self.assertTrue(temporary.is_dir())
            with self.assertRaisesRegex(
                ProtocolError,
                "published final directory",
            ):
                OperationsBackupCoordinator.verify_backup(temporary)
            shutil.rmtree(temporary)

        published = OperationsBackupCoordinator(self.store).create(
            backup_root,
            backup_id="verified-atomic-backup",
            at="2026-08-11T12:06:00+00:00",
        )
        published_directory = Path(published["backup_directory"])
        status = JournalInitializer(self.store).status()
        self.assertEqual(
            status["last_backup"]["backup_id"],
            "verified-atomic-backup",
        )
        self.assertGreater(status["last_backup"]["backup_bytes"], 0)

        for mutation in ("schema-version", "public-stream-tip"):
            tampered = backup_root / f"tampered-{mutation}"
            shutil.copytree(published_directory, tampered)
            manifest_path = tampered / "manifest.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if mutation == "schema-version":
                manifest["schema_version"] = 999
            else:
                manifest["public_stream_tips"] = [
                    {
                        "project_id": "forged-project",
                        "stream_id": "factory-public-events-forged-project",
                        "generation": 1,
                        "sequence": 1,
                        "event_id": "event-" + "1" * 32,
                        "event_document_sha256": "2" * 64,
                    }
                ]
            manifest["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in manifest.items()
                    if key != "content_sha256"
                }
            )
            manifest_path.write_text(
                json.dumps(manifest, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            (tampered / "COMMITTED").write_text(
                manifest["content_sha256"] + "\n",
                encoding="ascii",
            )
            with self.assertRaises(ProtocolError):
                OperationsBackupCoordinator.verify_backup(tampered)

        target = Path(self.temporary.name) / "restore-target.db"
        original = b"existing-target-must-survive"
        for label in ("after-copy", "after-verify", "before-replace"):
            target.write_bytes(original)

            def fail_restore(
                point: str,
                *,
                expected: str = label,
            ) -> None:
                if point == expected:
                    raise RuntimeError(
                        f"injected restore failure: {point}"
                    )

            with self.assertRaisesRegex(
                RuntimeError,
                f"injected restore failure: {label}",
            ):
                OperationsBackupCoordinator.restore(
                    published_directory,
                    target,
                    fault_injector=fail_restore,
                )
            self.assertEqual(target.read_bytes(), original)
            self.assertEqual(
                OperationsBackupCoordinator.verify_backup(
                    published_directory
                )["status"],
                "verified",
            )

    def test_all_query_contracts_and_tokens_are_sf107_ready(self) -> None:
        workspace = Path(self.temporary.name) / "query-contracts"
        workspace.mkdir()
        controller, aggregate, _ = journaled_running_controller(workspace)
        normalized = {
            "type": "work-request",
            "title": "Inspect the complete query contract",
            "description": "Provide an accepted signal with history.",
            "priority": "normal",
            "labels": ["sf-106"],
        }
        envelope = {
            "version": "1.0.0",
            "signal_id": "signal-query-contract",
            "project_id": "product-one",
            "integration_id": "owner-inbox",
            "source": "manual",
            "source_reference": "manual:owner-inbox/query-contract",
            "source_event_id": "owner-query-contract",
            "source_sequence": None,
            "idempotency_key": "owner-query-contract",
            "occurred_at": "2026-08-11T01:10:00+00:00",
            "authentication": {
                "status": "verified",
                "method": "profile-role-binding",
                "principal_ref": "founder",
                "evidence_ref": "profile:product-one:founder",
                "verified_at": "2026-08-11T01:10:01+00:00",
            },
            "normalized": normalized,
            "payload_sha256": canonical_sha256(normalized),
        }
        SignalIntake(controller.path).ingest(
            envelope,
            actor_identity_id="founder",
            received_at="2026-08-11T01:10:02+00:00",
        )
        runtime = ProjectionRuntime(controller.path)
        runtime.rebuild_all(batch_size=3)
        queries = ProjectionQueries(controller.path)

        products = queries.list_products(project_id="product-one")
        self.assertEqual(
            queries.get_product(
                project_id="product-one",
                factory_id=products["items"][0]["subject_id"],
            ),
            products["items"][0],
        )

        signals = queries.list_signals(
            project_id="product-one",
            status="accepted",
        )
        self.assertEqual(len(signals["items"]), 1)
        signal_id = signals["items"][0]["subject_id"]
        self.assertEqual(
            queries.get_signal(
                project_id="product-one",
                signal_id=signal_id,
            ),
            signals["items"][0],
        )
        signal_history = queries.signal_history(
            project_id="product-one",
            signal_id=signal_id,
            limit=1,
        )
        self.assertIsNotNone(signal_history["continuation"])
        signal_history_tail = queries.signal_history(
            project_id="product-one",
            signal_id=signal_id,
            limit=1,
            continuation=signal_history["continuation"],
        )
        self.assertEqual(len(signal_history_tail["items"]), 1)
        self.assertIsNone(signal_history_tail["continuation"])
        valid_signal_token = decode_page_token(
            signal_history["continuation"]
        )
        for invalid_sort_values in (
            valid_signal_token["last_sort_values"][:1],
            [*valid_signal_token["last_sort_values"], "extra"],
            [
                *valid_signal_token["last_sort_values"][:2],
                str(valid_signal_token["last_sort_values"][2]),
            ],
        ):
            invalid_token = copy.deepcopy(valid_signal_token)
            invalid_token["last_sort_values"] = invalid_sort_values
            with self.assertRaisesRegex(
                InvalidProjectionTokenError,
                "sort values do not match",
            ):
                queries.signal_history(
                    project_id="product-one",
                    signal_id=signal_id,
                    limit=1,
                    continuation=encode_page_token(invalid_token),
                )

        work_items = queries.list_work_items(project_id="product-one")
        work_item_id = work_items["items"][0]["subject_id"]
        self.assertEqual(
            queries.get_work_item(
                project_id="product-one",
                work_item_id=work_item_id,
            ),
            work_items["items"][0],
        )
        work_history = queries.work_item_history(
            project_id="product-one",
            work_item_id=work_item_id,
            limit=1,
        )
        self.assertIsNotNone(work_history["continuation"])
        work_history_tail = queries.work_item_history(
            project_id="product-one",
            work_item_id=work_item_id,
            limit=1,
            continuation=work_history["continuation"],
        )
        self.assertEqual(len(work_history_tail["items"]), 1)
        with self.assertRaises(InvalidProjectionTokenError):
            queries.work_item_history(
                project_id="product-one",
                work_item_id=work_item_id,
                limit=1,
                continuation=signal_history["continuation"],
            )

        transitions = queries.list_transitions(
            project_id="product-one",
            work_item_id=work_item_id,
            limit=1,
        )
        self.assertEqual(len(transitions["items"]), 1)
        self.assertIsNotNone(transitions["continuation"])
        transition_tail = queries.list_transitions(
            project_id="product-one",
            work_item_id=work_item_id,
            limit=1,
            continuation=transitions["continuation"],
        )
        self.assertGreaterEqual(len(transition_tail["items"]), 1)
        self.assertNotEqual(
            transitions["items"][0]["command_id"],
            transition_tail["items"][0]["command_id"],
        )
        transition_id = transitions["items"][0]["subject_id"]
        self.assertEqual(
            queries.get_transition(
                project_id="product-one",
                transition_id=transition_id,
            ),
            transitions["items"][0],
        )
        self.assertEqual(
            transitions["query"]["sort_id"],
            "transitions-ascending-v1",
        )

        commands = queries.list_commands(project_id="product-one")
        command_id = commands["items"][0]["subject_id"]
        self.assertEqual(
            queries.get_command(
                project_id="product-one",
                command_id=command_id,
            ),
            commands["items"][0],
        )
        command_history = queries.command_history(
            project_id="product-one",
            command_id=command_id,
            limit=1,
        )
        self.assertIsNotNone(command_history["continuation"])
        command_history_tail = queries.command_history(
            project_id="product-one",
            command_id=command_id,
            limit=1,
            continuation=command_history["continuation"],
        )
        self.assertGreaterEqual(len(command_history_tail["items"]), 1)

        runs = queries.list_runs(
            project_id="product-one",
            status="running",
        )
        run_id = runs["items"][0]["subject_id"]
        self.assertEqual(run_id, aggregate["run"]["id"])
        self.assertEqual(
            queries.get_run(project_id="product-one", run_id=run_id),
            runs["items"][0],
        )
        run_history = queries.run_history(
            project_id="product-one",
            run_id=run_id,
            limit=1,
        )
        self.assertIsNotNone(run_history["continuation"])
        run_history_tail = queries.run_history(
            project_id="product-one",
            run_id=run_id,
            limit=1,
            continuation=run_history["continuation"],
        )
        self.assertGreaterEqual(len(run_history_tail["items"]), 1)

        timeline = queries.timeline(
            project_id="product-one",
            subject_id=run_id,
            limit=1,
        )
        self.assertGreaterEqual(len(timeline["items"]), 1)
        public = queries.read_public_events(
            project_id="product-one",
            limit=10,
        )
        self.assertEqual(len(public["events"]), 1)
        event = public["events"][0]
        self.assertEqual(
            queries.get_public_event(
                project_id="product-one",
                event_id=event["event_id"],
            ),
            event,
        )
        current = queries.read_public_events(
            project_id="product-one",
            cursor=public["current"],
            limit=10,
        )
        self.assertEqual(current["events"], [])

        with self.assertRaises(CapabilityUnavailableError):
            queries.list_decisions(project_id="product-one")
        with self.assertRaises(CapabilityUnavailableError):
            queries.get_decision(
                project_id="product-one",
                decision_id="decision-one",
            )
        for invalid_limit in (0, 501):
            with self.assertRaisesRegex(ProtocolError, "between 1 and 500"):
                queries.list_products(
                    project_id="product-one",
                    limit=invalid_limit,
                )

        second = copy.deepcopy(envelope)
        second["signal_id"] = "signal-query-contract-two"
        second["source_event_id"] = "owner-query-contract-two"
        second["source_reference"] = (
            "manual:owner-inbox/query-contract-two"
        )
        second["idempotency_key"] = "owner-query-contract-two"
        SignalIntake(controller.path).ingest(
            second,
            actor_identity_id="founder",
            received_at="2026-08-11T01:11:02+00:00",
        )
        with self.assertRaises(StaleProjectionTokenError) as stale:
            queries.signal_history(
                project_id="product-one",
                signal_id=signal_id,
                limit=1,
                continuation=signal_history["continuation"],
            )
        self.assertEqual(stale.exception.projection_id, "signals")
        self.assertEqual(
            stale.exception.expected_generation,
            stale.exception.actual_generation,
        )
        self.assertEqual(
            stale.exception.expected_projection_sha256,
            stale.exception.actual_projection_sha256,
        )
        self.assertEqual(
            stale.exception.expected_journal_generation,
            stale.exception.actual_journal_generation,
        )
        self.assertGreater(
            stale.exception.expected_journal_sequence,
            stale.exception.actual_journal_sequence,
        )

    def test_every_list_query_paginates_without_duplicate_or_gap(
        self,
    ) -> None:
        JournalInitializer(self.store).initialize()
        runtime = ProjectionRuntime(self.store)
        runtime.rebuild_all(batch_size=2)
        queries = ProjectionQueries(self.store)
        projection_ids = (
            "products",
            "signals",
            "work-items",
            "transitions",
            "commands",
            "runs",
            "timeline",
        )
        active = {
            projection_id: queries._active(projection_id)
            for projection_id in projection_ids
        }
        project_id = "pagination-project"
        timestamp = "2026-08-11T11:00:00+00:00"
        records = {
            "products": [
                {
                    "project_id": project_id,
                    "subject_id": "product-a",
                    "status": "active",
                },
                {
                    "project_id": project_id,
                    "subject_id": "product-b",
                    "status": "active",
                },
            ],
            "signals": [
                {
                    "project_id": project_id,
                    "subject_id": "signal-a",
                    "received_at": timestamp,
                    "updated_at": timestamp,
                    "status": "accepted",
                },
                {
                    "project_id": project_id,
                    "subject_id": "signal-b",
                    "received_at": timestamp,
                    "updated_at": timestamp,
                    "status": "accepted",
                },
            ],
            "work-items": [
                {
                    "project_id": project_id,
                    "subject_id": "work-item-a",
                    "updated_at": timestamp,
                    "status": "ready",
                },
                {
                    "project_id": project_id,
                    "subject_id": "work-item-b",
                    "updated_at": timestamp,
                    "status": "ready",
                },
            ],
            "transitions": [
                {
                    "project_id": project_id,
                    "subject_id": "transition-b",
                    "command_id": "command-b",
                    "recorded_at": timestamp,
                    "updated_at": timestamp,
                    "parent_ids": {"work_item_id": "work-item-a"},
                },
                {
                    "project_id": project_id,
                    "subject_id": "transition-a",
                    "command_id": "command-a",
                    "recorded_at": timestamp,
                    "updated_at": timestamp,
                    "parent_ids": {"work_item_id": "work-item-a"},
                },
            ],
            "commands": [
                {
                    "project_id": project_id,
                    "subject_id": "command-a",
                    "updated_at": timestamp,
                    "status": "completed",
                },
                {
                    "project_id": project_id,
                    "subject_id": "command-b",
                    "updated_at": timestamp,
                    "status": "completed",
                },
            ],
            "runs": [
                {
                    "project_id": project_id,
                    "subject_id": "run-a",
                    "updated_at": timestamp,
                    "status": "running",
                },
                {
                    "project_id": project_id,
                    "subject_id": "run-b",
                    "updated_at": timestamp,
                    "status": "running",
                },
            ],
            "timeline": [
                {
                    "project_id": project_id,
                    "subject_id": "timeline-a",
                    "source_subject_id": "work-item-a",
                    "journal_sequence": 1,
                    "parent_ids": {},
                    "correlation_id": "correlation-a",
                },
                {
                    "project_id": project_id,
                    "subject_id": "timeline-b",
                    "source_subject_id": "work-item-b",
                    "journal_sequence": 2,
                    "parent_ids": {},
                    "correlation_id": "correlation-b",
                },
            ],
        }
        with operations_connection(self.store) as connection:
            for projection_id, projection_records in records.items():
                generation = active[projection_id]["generation"]
                for index, record in enumerate(projection_records, start=1):
                    connection.execute(
                        """
                        INSERT INTO factory_projection_rows(
                            projection_id, projection_generation,
                            project_id, subject_id, parent_ids_json,
                            source_subject_version,
                            last_journal_sequence, record_json,
                            content_sha256, updated_at
                        ) VALUES(?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
                        """,
                        (
                            projection_id,
                            generation,
                            project_id,
                            record["subject_id"],
                            canonical_json(record.get("parent_ids", {})),
                            index,
                            canonical_json(record),
                            str(index) * 64,
                            timestamp,
                        ),
                    )
            connection.commit()
        queries._active = lambda projection_id: active[projection_id]
        calls = {
            "products": lambda continuation: queries.list_products(
                project_id=project_id,
                status="active",
                limit=1,
                continuation=continuation,
            ),
            "signals": lambda continuation: queries.list_signals(
                project_id=project_id,
                status="accepted",
                limit=1,
                continuation=continuation,
            ),
            "work-items": lambda continuation: queries.list_work_items(
                project_id=project_id,
                status="ready",
                limit=1,
                continuation=continuation,
            ),
            "transitions": lambda continuation: queries.list_transitions(
                project_id=project_id,
                work_item_id="work-item-a",
                limit=1,
                continuation=continuation,
            ),
            "commands": lambda continuation: queries.list_commands(
                project_id=project_id,
                status="completed",
                limit=1,
                continuation=continuation,
            ),
            "runs": lambda continuation: queries.list_runs(
                project_id=project_id,
                status="running",
                limit=1,
                continuation=continuation,
            ),
            "timeline": lambda continuation: queries.timeline(
                project_id=project_id,
                limit=1,
                continuation=continuation,
            ),
        }
        expected_subjects = {
            "products": ["product-a", "product-b"],
            "signals": ["signal-a", "signal-b"],
            "work-items": ["work-item-a", "work-item-b"],
            "transitions": ["transition-a", "transition-b"],
            "commands": ["command-a", "command-b"],
            "runs": ["run-a", "run-b"],
            "timeline": ["timeline-a", "timeline-b"],
        }
        for projection_id, call in calls.items():
            first = call(None)
            self.assertIsNotNone(
                first["continuation"],
                projection_id,
            )
            second = call(first["continuation"])
            self.assertIsNone(second["continuation"], projection_id)
            self.assertEqual(
                [
                    first["items"][0]["subject_id"],
                    second["items"][0]["subject_id"],
                ],
                expected_subjects[projection_id],
                projection_id,
            )


if __name__ == "__main__":
    unittest.main()
