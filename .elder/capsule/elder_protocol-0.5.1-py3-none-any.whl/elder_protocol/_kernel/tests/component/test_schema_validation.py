from __future__ import annotations

import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.schema_validation import (
    validate_against_schema,
    validate_schema_catalog,
)


class SchemaValidationComponentTests(unittest.TestCase):
    def test_protocol_schema_catalog_is_valid(self) -> None:
        schemas = validate_schema_catalog()
        self.assertIn("project-profile.schema.json", schemas)
        self.assertIn("runtime-lease.schema.json", schemas)
        self.assertIn("canary-execution-packet.schema.json", schemas)

    def test_validation_reports_the_nested_instance_path(self) -> None:
        invalid_budget = {
            "version": "0.5.1",
            "id": "budget-test",
            "project_id": "project-test",
            "run_id": "run-test",
            "token_limit": -1,
            "cost_limit_usd": 0,
            "tool_call_limit": 0,
            "elapsed_seconds_limit": 0,
            "accounting": "parent-and-child-aggregate",
        }
        with self.assertRaisesRegex(
            ProtocolError,
            r"Budget does not match budget\.schema\.json at 'token_limit'",
        ):
            validate_against_schema(
                invalid_budget,
                "budget.schema.json",
                label="Budget",
            )

    def test_unknown_schema_fails_explicitly(self) -> None:
        with self.assertRaisesRegex(
            ProtocolError,
            "Unknown JSON Schema",
        ):
            validate_against_schema(
                {},
                "missing.schema.json",
                label="Missing",
            )


if __name__ == "__main__":
    unittest.main()
