from __future__ import annotations

import json
import unittest

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from elder_protocol.evaluation import review_transcript
from tests._support import test_workspace


def _write_jsonl(path, events: list[dict]) -> None:
    path.write_text(
        "".join(json.dumps(event, sort_keys=True) + "\n" for event in events),
        encoding="utf-8",
    )


class TranscriptEvaluationComponentTests(unittest.TestCase):
    def test_independent_reviewer_passes_complete_ordered_trace(self) -> None:
        with test_workspace("transcript-pass") as workspace:
            trace = workspace / "trace.jsonl"
            policy = workspace / "policy.json"
            _write_jsonl(
                trace,
                [
                    {
                        "run_id": "run-1",
                        "sequence": 1,
                        "node_id": "intake",
                        "status": "running",
                        "recorded_at": "2026-08-05T00:00:00+00:00",
                    },
                    {
                        "run_id": "run-1",
                        "sequence": 1,
                        "node_id": "intake",
                        "status": "complete",
                        "elapsed_ms": 1.2,
                        "recorded_at": "2026-08-05T00:00:01+00:00",
                    },
                ],
            )
            policy.write_text(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "id": "default-transcript-review",
                        "trace_format": "workflow-jsonl-v1",
                        "required_start_status": "running",
                        "terminal_statuses": ["complete", "failed"],
                        "maximum_failed_events": 0,
                        "require_monotonic_sequence": True,
                        "require_elapsed_ms": True,
                        "secret_name_patterns": ["TOKEN", "SECRET", "PASSWORD"],
                    }
                ),
                encoding="utf-8",
            )

            report = review_transcript(
                trace,
                policy,
                evaluator_id="independent-evaluator",
                executor_id="workbench-executor",
            )
            self.assertEqual(report["verdict"], "pass")
            self.assertEqual(report["findings"], [])
            self.assertEqual(report["authority"], "advisory-only")
            self.assertFalse(report["can_approve"])
            self.assertFalse(report["can_promote"])
            self.assertTrue(report["independent"])

    def test_reviewer_fails_incomplete_and_failed_trace(self) -> None:
        with test_workspace("transcript-fail") as workspace:
            trace = workspace / "trace.jsonl"
            policy = workspace / "policy.json"
            _write_jsonl(
                trace,
                [
                    {
                        "run_id": "run-2",
                        "sequence": 1,
                        "node_id": "intake",
                        "status": "running",
                        "recorded_at": "2026-08-05T00:00:00+00:00",
                    },
                    {
                        "run_id": "run-2",
                        "sequence": 1,
                        "node_id": "intake",
                        "status": "failed",
                        "elapsed_ms": 2.0,
                        "message": "validation failed",
                        "recorded_at": "2026-08-05T00:00:01+00:00",
                    },
                ],
            )
            policy.write_text(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "id": "default-transcript-review",
                        "trace_format": "workflow-jsonl-v1",
                        "required_start_status": "running",
                        "terminal_statuses": ["complete", "failed"],
                        "maximum_failed_events": 0,
                        "require_monotonic_sequence": True,
                        "require_elapsed_ms": True,
                        "secret_name_patterns": ["TOKEN", "SECRET", "PASSWORD"],
                    }
                ),
                encoding="utf-8",
            )

            report = review_transcript(
                trace,
                policy,
                evaluator_id="independent-evaluator",
                executor_id="workbench-executor",
            )
            self.assertEqual(report["verdict"], "fail")
            self.assertTrue(
                any(finding["category"] == "failed-events" for finding in report["findings"])
            )

    def test_reviewer_cannot_evaluate_its_own_execution(self) -> None:
        with test_workspace("transcript-separation") as workspace:
            trace = workspace / "trace.jsonl"
            policy = workspace / "policy.json"
            _write_jsonl(
                trace,
                [
                    {
                        "run_id": "run-3",
                        "sequence": 1,
                        "node_id": "intake",
                        "status": "running",
                        "recorded_at": "2026-08-05T00:00:00+00:00",
                    }
                ],
            )
            policy.write_text(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "id": "default-transcript-review",
                        "trace_format": "workflow-jsonl-v1",
                        "required_start_status": "running",
                        "terminal_statuses": ["complete", "failed"],
                        "maximum_failed_events": 0,
                        "require_monotonic_sequence": True,
                        "require_elapsed_ms": True,
                        "secret_name_patterns": ["TOKEN", "SECRET", "PASSWORD"],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ProtocolError, "independent"):
                review_transcript(
                    trace,
                    policy,
                    evaluator_id="same-agent",
                    executor_id="same-agent",
                )


if __name__ == "__main__":
    unittest.main()
