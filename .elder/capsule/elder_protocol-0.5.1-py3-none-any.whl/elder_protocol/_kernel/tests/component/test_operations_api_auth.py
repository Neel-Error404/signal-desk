from __future__ import annotations

import base64
import hashlib
import unittest
from datetime import UTC, datetime

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.api_auth import (
    OperationsApiAuthenticator,
    validate_operations_api_auth_policy,
)
from elder_protocol.factory_operations.api_contracts import (
    canonical_content_sha256,
    load_operations_api_contracts,
)
from elder_protocol.io import json_text
from tests._support import test_workspace


NOW = datetime(2026, 8, 11, 12, 0, tzinfo=UTC)


class OperationsApiAuthComponentTests(unittest.TestCase):
    def _policy(self, token: str) -> dict:
        policy = {
            "version": "1.0.0",
            "policy_id": "operations-api-auth-component",
            "issued_at": "2026-08-11T11:00:00+00:00",
            "expires_at": "2026-08-11T13:00:00+00:00",
            "clients": [
                {
                    "client_id": "local-operator",
                    "kind": "operator",
                    "identity_id": "identity:local-operator",
                    "enabled": True,
                    "bearer_token_sha256": hashlib.sha256(
                        token.encode("ascii")
                    ).hexdigest(),
                    "project_ids": ["example-agentic-product"],
                    "route_ids": ["capabilities-get"],
                }
            ],
            "content_sha256": "",
        }
        policy["content_sha256"] = canonical_content_sha256(policy)
        return policy

    def test_authenticates_exact_client_token_route_and_kind(self) -> None:
        token = base64.urlsafe_b64encode(b"x" * 32).decode("ascii").rstrip("=")
        contracts = load_operations_api_contracts()
        route = contracts.routes_by_id["capabilities-get"]
        with test_workspace("sf107-api-auth") as workspace:
            policy_path = workspace / "auth-policy.json"
            policy_path.write_text(
                json_text(self._policy(token)),
                encoding="utf-8",
            )
            authenticator = OperationsApiAuthenticator(
                policy_path=policy_path,
                store_path=workspace / "operations.db",
                routes=list(contracts.routes_by_id.values()),
                now=NOW,
            )
            result = authenticator.authenticate(
                route=route,
                client_id="local-operator",
                authorization=f"Bearer {token}",
                project_id=None,
            )
            self.assertEqual(result["kind"], "operator")
            self.assertEqual(result["identity_id"], "identity:local-operator")
            self.assertNotIn(token, policy_path.read_text(encoding="utf-8"))

            for authorization in (
                None,
                "Basic ignored",
                "Bearer changed",
            ):
                with self.subTest(authorization=authorization):
                    with self.assertRaisesRegex(
                        ProtocolError,
                        "authentication failed",
                    ):
                        authenticator.authenticate(
                            route=route,
                            client_id="local-operator",
                            authorization=authorization,
                            project_id=None,
                        )

    def test_policy_rejects_route_kind_mismatch_and_duplicate_identity(
        self,
    ) -> None:
        token = base64.urlsafe_b64encode(b"y" * 32).decode("ascii").rstrip("=")
        contracts = load_operations_api_contracts()
        routes = list(contracts.routes_by_id.values())
        policy = self._policy(token)
        policy["clients"][0]["kind"] = "integration-adapter"
        policy["clients"][0]["route_ids"] = ["product-register"]
        policy["content_sha256"] = canonical_content_sha256(policy)
        with self.assertRaisesRegex(ProtocolError, "not eligible"):
            validate_operations_api_auth_policy(policy, routes, now=NOW)

        duplicate = self._policy(token)
        second = dict(duplicate["clients"][0])
        second.update(
            {
                "client_id": "second-operator",
                "bearer_token_sha256": "f" * 64,
            }
        )
        duplicate["clients"].append(second)
        duplicate["content_sha256"] = canonical_content_sha256(duplicate)
        with self.assertRaisesRegex(ProtocolError, "identity_id"):
            validate_operations_api_auth_policy(duplicate, routes, now=NOW)

    def test_global_route_requires_an_explicit_non_project_grant(self) -> None:
        token = base64.urlsafe_b64encode(b"z" * 32).decode("ascii").rstrip("=")
        contracts = load_operations_api_contracts()
        routes = list(contracts.routes_by_id.values())
        route = contracts.routes_by_id["owner-inbox-get"]
        policy = self._policy(token)
        client = policy["clients"][0]
        client["kind"] = "owner-ui"
        client["route_ids"] = ["owner-inbox-get"]
        policy["content_sha256"] = canonical_content_sha256(policy)

        with test_workspace("sf300-global-owner-auth") as workspace:
            policy_path = workspace / "ungranted-auth-policy.json"
            policy_path.write_text(json_text(policy), encoding="utf-8")
            authenticator = OperationsApiAuthenticator(
                policy_path=policy_path,
                store_path=workspace / "operations.db",
                routes=routes,
                now=NOW,
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "authorization failed",
            ):
                authenticator.authenticate(
                    route=route,
                    client_id="local-operator",
                    authorization=f"Bearer {token}",
                    project_id=None,
                    require_global_scope=True,
                )

            client["global_route_ids"] = ["owner-inbox-get"]
            policy["content_sha256"] = canonical_content_sha256(policy)
            policy_path = workspace / "granted-auth-policy.json"
            policy_path.write_text(json_text(policy), encoding="utf-8")
            authenticator = OperationsApiAuthenticator(
                policy_path=policy_path,
                store_path=workspace / "operations.db",
                routes=routes,
                now=NOW,
            )
            result = authenticator.authenticate(
                route=route,
                client_id="local-operator",
                authorization=f"Bearer {token}",
                project_id=None,
                require_global_scope=True,
            )
            self.assertIsNone(result["project_id"])

        invalid = self._policy(token)
        invalid["clients"][0]["global_route_ids"] = ["products-list"]
        invalid["content_sha256"] = canonical_content_sha256(invalid)
        with self.assertRaisesRegex(
            ProtocolError,
            "must also be an exact route grant",
        ):
            validate_operations_api_auth_policy(invalid, routes, now=NOW)


if __name__ == "__main__":
    unittest.main()
