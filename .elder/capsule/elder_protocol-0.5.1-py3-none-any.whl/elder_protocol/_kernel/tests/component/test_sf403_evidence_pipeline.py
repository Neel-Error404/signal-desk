from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import ProtocolError
from tests._sf403_support import (
    build_environment,
    complete_pipeline,
    evaluation,
    evaluation_request,
    result,
)
from tests._support import tamper_sqlite_store, test_workspace


class SF403EvidencePipelineComponentTests(unittest.TestCase):
    def test_ordered_results_evaluation_and_completion_pass(self) -> None:
        with test_workspace("sf403-success") as workspace:
            environment = build_environment(workspace)
            completion = complete_pipeline(environment)
            view = environment["pipeline"].owner_view(
                environment["plan"]["id"]
            )
            self.assertEqual(view["condition"], "complete")
            self.assertFalse(view["attention_required"])
            self.assertTrue(
                completion["validated_evidence_ref"].startswith(
                    "evidence-pipeline:"
                )
            )

    def test_failed_lower_level_blocks_later_results_and_completion(self) -> None:
        with test_workspace("sf403-failed-lower") as workspace:
            environment = build_environment(workspace)
            environment["pipeline"].ingest_result(
                result(environment, "Foundation", verdict="fail")
            )
            with self.assertRaisesRegex(ProtocolError, "failed lower"):
                environment["pipeline"].ingest_result(
                    result(environment, "Component")
                )
            with self.assertRaisesRegex(ProtocolError, "every planned test"):
                evaluation_request(environment)
            with self.assertRaisesRegex(ProtocolError, "missing planned"):
                environment["pipeline"].complete(
                    environment["plan"]["id"],
                    outcome_record_ref="outcome:blocked",
                )
            self.assertEqual(
                environment["pipeline"].owner_view(
                    environment["plan"]["id"]
                )["condition"],
                "failed",
            )

    def test_stale_result_is_rejected(self) -> None:
        with test_workspace("sf403-stale") as workspace:
            environment = build_environment(workspace)
            stale = result(
                environment,
                "Foundation",
                recorded_at="2026-08-14T16:05:21+00:00",
            )
            with self.assertRaisesRegex(ProtocolError, "stale"):
                environment["pipeline"].ingest_result(stale)

    def test_changed_diff_and_artifact_block_proof(self) -> None:
        with test_workspace("sf403-changed-artifact") as workspace:
            environment = build_environment(workspace)
            foundation = result(environment, "Foundation")
            environment["foundation_artifact"].write_text(
                "Changed after result.\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ProtocolError, "artifact changed"):
                environment["pipeline"].ingest_result(foundation)

        with test_workspace("sf403-changed-diff") as workspace:
            environment = build_environment(workspace)
            environment["pipeline"].ingest_result(
                result(environment, "Foundation")
            )
            environment["pipeline"].ingest_result(
                result(environment, "Component")
            )
            request = evaluation_request(environment)
            environment["pipeline"].record_evaluation(
                evaluation(environment, request)
            )
            environment["change"].write_text(
                "def repaired_component() -> str:\n"
                "    return \"changed-after-tests\"\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ProtocolError, "diff changed"):
                environment["pipeline"].complete(
                    environment["plan"]["id"],
                    outcome_record_ref="outcome:changed",
                )

    def test_secret_trace_and_missing_or_nonindependent_evaluator_fail(
        self,
    ) -> None:
        with test_workspace("sf403-trace-redaction") as workspace:
            environment = build_environment(workspace)
            secret = result(
                environment,
                "Foundation",
                trace=[{"sequence": 1, "api_key": "not-allowed"}],
            )
            with self.assertRaisesRegex(ProtocolError, "secret"):
                environment["pipeline"].ingest_result(secret)

        with test_workspace("sf403-evaluator") as workspace:
            environment = build_environment(workspace)
            environment["pipeline"].ingest_result(
                result(environment, "Foundation")
            )
            environment["pipeline"].ingest_result(
                result(environment, "Component")
            )
            with self.assertRaisesRegex(ProtocolError, "independent evaluator"):
                environment["pipeline"].complete(
                    environment["plan"]["id"],
                    outcome_record_ref="outcome:no-evaluator",
                )
            with self.assertRaisesRegex(ProtocolError, "differ"):
                environment["pipeline"].request_evaluation(
                    environment["plan"]["id"],
                    evaluator_id=environment["child_run"]["identity_id"],
                    requested_by=environment["parent_run"]["identity_id"],
                )
            request = evaluation_request(environment)
            wrong = evaluation(environment, request)
            wrong["evaluator_id"] = environment["child_run"]["identity_id"]
            wrong["content_sha256"] = ""
            with self.assertRaises(ProtocolError):
                environment["pipeline"].record_evaluation(wrong)

    def test_tampered_completion_row_fails_closed(self) -> None:
        with test_workspace("sf403-completion-tamper") as workspace:
            environment = build_environment(workspace)
            complete_pipeline(environment)
            tamper_sqlite_store(
                environment["pipeline_path"],
                "UPDATE completions SET content_sha256 = ?",
                ("0" * 64,),
            )
            with self.assertRaisesRegex(ProtocolError, "row binding"):
                environment["pipeline"].owner_view(
                    environment["plan"]["id"]
                )


if __name__ == "__main__":
    unittest.main()
