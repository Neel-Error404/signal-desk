from __future__ import annotations

import json
import unittest

from elder_protocol.boundaries import (
    check_architecture_boundaries,
    enforce_architecture_boundaries,
)
from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.errors import ProtocolError
from tests._support import test_workspace


class ArchitectureBoundaryComponentTests(unittest.TestCase):
    def test_python_adapter_enforces_declared_dependency_direction(self) -> None:
        with test_workspace("architecture-boundaries") as workspace:
            package = workspace / "src" / "example"
            package.mkdir(parents=True)
            (package / "a.py").write_text(
                "from example.b import value\n",
                encoding="utf-8",
            )
            (package / "b.py").write_text("value = 1\n", encoding="utf-8")
            contract = workspace / "architecture-boundaries.json"
            contract.write_text(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "id": "example-python",
                        "adapter": "python-ast-imports",
                        "import_prefix": "example",
                        "unknown_module_policy": "deny",
                        "modules": [
                            {
                                "id": "a",
                                "path": "src/example/a.py",
                                "allowed_internal_dependencies": ["b"],
                            },
                            {
                                "id": "b",
                                "path": "src/example/b.py",
                                "allowed_internal_dependencies": [],
                            },
                        ],
                    }
                ),
                encoding="utf-8",
            )

            report = check_architecture_boundaries(contract, workspace)
            self.assertEqual(report["violations"], [])

            (package / "b.py").write_text(
                "from example.a import value\n",
                encoding="utf-8",
            )
            report = check_architecture_boundaries(contract, workspace)
            self.assertEqual(len(report["violations"]), 1)
            self.assertIn("forbidden internal imports", report["violations"][0])
            with self.assertRaisesRegex(ProtocolError, "Architecture boundary"):
                enforce_architecture_boundaries(contract, workspace)

    def test_unknown_python_module_is_rejected_when_policy_is_deny(self) -> None:
        with test_workspace("unknown-boundary-module") as workspace:
            package = workspace / "src" / "example"
            package.mkdir(parents=True)
            (package / "known.py").write_text("value = 1\n", encoding="utf-8")
            (package / "unknown.py").write_text("value = 2\n", encoding="utf-8")
            contract = workspace / "architecture-boundaries.json"
            contract.write_text(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "id": "example-python",
                        "adapter": "python-ast-imports",
                        "import_prefix": "example",
                        "unknown_module_policy": "deny",
                        "modules": [
                            {
                                "id": "known",
                                "path": "src/example/known.py",
                                "allowed_internal_dependencies": [],
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )

            report = check_architecture_boundaries(contract, workspace)
            self.assertTrue(
                any("has no declared dependency policy" in item for item in report["violations"])
            )


if __name__ == "__main__":
    unittest.main()
