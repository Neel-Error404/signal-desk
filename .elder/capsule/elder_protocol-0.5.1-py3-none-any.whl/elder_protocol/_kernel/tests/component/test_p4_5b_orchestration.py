from __future__ import annotations

import copy
import unittest
from pathlib import Path
from unittest.mock import patch

from elder_protocol.constants import PROTOCOL_DIR, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.governance import (
    finalize_checkpoint,
    finalize_delegation,
    resolve_authority_bindings,
)
from elder_protocol.io import load_json
from elder_protocol.knowledge import KnowledgeStore
from elder_protocol.orchestration import MultiAgentRuntime
from elder_protocol.protocol import validate_protocol
from tests._support import test_workspace


FIXTURE_PATH = ROOT / "tests" / "fixtures" / "p4_5a" / "fixture-a-low-risk.json"


class P45BOrchestrationComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.data = validate_protocol()
        self.fixture = load_json(FIXTURE_PATH)
        self.policy = load_json(PROTOCOL_DIR / "multi-agent-runtime-policy.json")
        self.bindings = resolve_authority_bindings(
            self.fixture["profile"],
            self.data["role-registry"],
            self.data["authority-matrix"],
        )

    def _runtime_inputs(self) -> dict:
        return {
            "delegation_policy": self.data["delegation-policy"],
            "role_registry": self.data["role-registry"],
            "authority_matrix": self.data["authority-matrix"],
        }

    def _packet(self, workspace: Path, fixture: dict | None = None) -> dict:
        fixture = fixture or self.fixture
        source = workspace / "src" / "component" / "runtime-source.md"
        source.parent.mkdir(parents=True, exist_ok=True)
        source.write_text("Bounded P4.5B runtime context.", encoding="utf-8")
        request = copy.deepcopy(fixture["context_request"])
        request["repository_sources"] = [
            {
                "id": "runtime-source",
                "location": "src/component/runtime-source.md",
                "authority": "primary",
                "required": True,
            }
        ]
        request["graph_limit"] = 0
        request["memory_limit"] = 0
        return KnowledgeStore(workspace / "unused-knowledge.db").assemble_context(
            request,
            base_dir=workspace,
            delegation=fixture["delegation"],
            parent_run=fixture["parent_run"],
            authority_bindings=self.bindings,
            delegation_policy=self.data["delegation-policy"],
            profile=fixture["profile"],
            role_registry=self.data["role-registry"],
            authority_matrix=self.data["authority-matrix"],
        )

    def _submitted_runtime(
        self,
        workspace: Path,
        fixture: dict | None = None,
    ) -> MultiAgentRuntime:
        fixture = fixture or self.fixture
        runtime = MultiAgentRuntime(workspace / "runtime.db", self.policy)
        runtime.initialize()
        runtime.submit(
            parent_run=fixture["parent_run"],
            delegation=fixture["delegation"],
            child_run=fixture["child_run"],
            context_packet=self._packet(workspace, fixture),
            context_base_dir=workspace,
            profile=fixture["profile"],
            authority_bindings=self.bindings,
            delegation_policy=self.data["delegation-policy"],
            role_registry=self.data["role-registry"],
            authority_matrix=self.data["authority-matrix"],
            submitted_at="2026-08-05T12:06:00+05:30",
        )
        return runtime

    @staticmethod
    def _action(sequence: int = 1) -> dict:
        return {
            "version": "0.5.1",
            "id": f"fixture-a-action-{sequence}",
            "project_id": "fixture-a-low-risk",
            "delegation_id": "fixture-a-low-risk-DEL-001",
            "run_id": "fixture-a-low-risk-child-run",
            "sequence": sequence,
            "resource": "implementation",
            "action": "modify",
            "tool": "filesystem-write",
            "status": "completed",
            "evidence_refs": [f"evidence:action-{sequence}"],
            "budget_consumed": {
                "token_limit": 100,
                "cost_limit_usd": 0.1,
                "tool_call_limit": 1,
                "elapsed_seconds_limit": 10,
            },
            "started_at": "2026-08-05T12:07:00+05:30",
            "completed_at": "2026-08-05T12:07:10+05:30",
        }

    def _claim(
        self,
        runtime: MultiAgentRuntime,
        *,
        at: str = "2026-08-05T12:06:30+05:30",
        lease_token: str = "test-lease-token-with-adequate-length",
    ) -> dict:
        return runtime.claim(
            project_id="fixture-a-low-risk",
            identity_id="fixture-a-low-risk-executor",
            lease_seconds=600,
            at=at,
            lease_token=lease_token,
        )

    def test_generated_lease_token_is_safe_as_a_cli_argument(self) -> None:
        with test_workspace("p4-5b-safe-token") as workspace:
            runtime = self._submitted_runtime(workspace)
            with patch(
                "elder_protocol.orchestration.secrets.token_urlsafe",
                return_value="-previously-ambiguous-token-payload",
            ):
                claim = runtime.claim(
                    project_id=self.fixture["profile"]["slug"],
                    identity_id=self.fixture["child_run"]["identity_id"],
                    lease_seconds=300,
                    at="2026-08-05T12:06:30+05:30",
                )
        self.assertEqual(
            claim["lease_token"],
            "elder_lease_-previously-ambiguous-token-payload",
        )
        self.assertFalse(claim["lease_token"].startswith("-"))

    def _without_operational_grant(self, resource: str) -> dict:
        fixture = copy.deepcopy(self.fixture)
        for key in ("parent_run", "delegation", "child_run"):
            fixture[key]["authority_grants"] = [
                grant
                for grant in fixture[key]["authority_grants"]
                if grant["resource"] != resource
            ]
        fixture["delegation"] = finalize_delegation(fixture["delegation"])
        return fixture

    def _with_delegation_actions(self, *actions: str) -> dict:
        fixture = copy.deepcopy(self.fixture)
        fixture["delegation"]["authority_ceiling"] = "delegate-bounded"
        for key in ("parent_run", "delegation", "child_run"):
            grant = next(
                (
                    item
                    for item in fixture[key]["authority_grants"]
                    if item["resource"] == "delegation"
                ),
                None,
            )
            if grant is None:
                grant = {"resource": "delegation", "actions": []}
                fixture[key]["authority_grants"].append(grant)
            grant["actions"] = sorted(set(grant["actions"]) | set(actions))
        fixture["delegation"] = finalize_delegation(fixture["delegation"])
        return fixture

    def _submit_nested(
        self,
        runtime: MultiAgentRuntime,
        workspace: Path,
        fixture: dict,
    ) -> dict:
        nested = copy.deepcopy(fixture)
        nested["parent_run"] = copy.deepcopy(fixture["child_run"])
        nested["delegation"]["delegation_id"] = "fixture-a-low-risk-DEL-002"
        nested["delegation"]["parent_run_id"] = fixture["child_run"]["id"]
        nested["delegation"]["deadline"] = "2026-08-06T15:30:00+05:30"
        nested["delegation"]["expires_at"] = "2026-08-06T16:00:00+05:30"
        nested["delegation"] = finalize_delegation(nested["delegation"])
        nested["child_run"]["id"] = "fixture-a-low-risk-grandchild-run"
        nested["child_run"]["parent_run_id"] = fixture["child_run"]["id"]
        nested["child_run"]["delegation_id"] = nested["delegation"]["delegation_id"]
        nested["child_run"]["context_packet_id"] = "fixture-a-grandchild-context"
        nested["child_run"]["started_at"] = "2026-08-05T12:07:00+05:30"
        nested["child_run"]["deadline"] = "2026-08-06T15:30:00+05:30"
        nested["context_request"]["id"] = "fixture-a-grandchild-context"
        nested["context_request"]["delegation_id"] = nested["delegation"][
            "delegation_id"
        ]
        runtime.submit(
            parent_run=nested["parent_run"],
            delegation=nested["delegation"],
            child_run=nested["child_run"],
            context_packet=self._packet(workspace, nested),
            context_base_dir=workspace,
            profile=nested["profile"],
            authority_bindings=self.bindings,
            delegation_policy=self.data["delegation-policy"],
            role_registry=self.data["role-registry"],
            authority_matrix=self.data["authority-matrix"],
            submitted_at="2026-08-05T12:08:00+05:30",
        )
        return nested

    def test_runtime_coordinates_action_message_checkpoint_and_replay(self) -> None:
        with test_workspace("p4-5b-runtime") as workspace:
            runtime = self._submitted_runtime(workspace)
            claim = self._claim(runtime)
            token = claim["lease_token"]
            runtime.record_action(
                self._action(),
                lease_token=token,
                **self._runtime_inputs(),
            )
            runtime.record_message(
                {
                    "version": "0.5.1",
                    "id": "fixture-a-message-1",
                    "project_id": "fixture-a-low-risk",
                    "delegation_id": "fixture-a-low-risk-DEL-001",
                    "parent_run_id": "fixture-a-low-risk-parent-run",
                    "child_run_id": "fixture-a-low-risk-child-run",
                    "from_identity": "fixture-a-low-risk-executor",
                    "to_identity": "fixture-a-low-risk-human",
                    "kind": "evidence",
                    "content": "The bounded component action completed.",
                    "evidence_refs": ["evidence:action-1"],
                    "sequence": 1,
                    "state_effect": "none",
                    "created_at": "2026-08-05T12:08:00+05:30",
                },
                lease_token=token,
                **self._runtime_inputs(),
            )
            checkpoint = copy.deepcopy(self.fixture["checkpoint"])
            checkpoint.update(
                {
                    "status": "completed",
                    "completed_scope": ["src/component"],
                    "remaining_scope": [],
                    "evidence_refs": ["evidence:action-1"],
                    "action_sequence": 1,
                    "budget_consumed": self._action()["budget_consumed"],
                    "created_at": "2026-08-05T12:10:00+05:30",
                }
            )
            checkpoint = finalize_checkpoint(checkpoint)
            snapshot = runtime.record_checkpoint(
                checkpoint,
                lease_token=token,
                **self._runtime_inputs(),
            )
            self.assertEqual(snapshot["delegation"]["status"], "completed")
            self.assertEqual(snapshot["child_run"]["status"], "complete")
            self.assertEqual(snapshot["counts"]["actions"], 1)
            self.assertEqual(snapshot["counts"]["messages"], 1)
            self.assertEqual(snapshot["counts"]["checkpoints"], 1)
            self.assertEqual(snapshot["lease"]["status"], "released")
            self.assertEqual(runtime.verify_replay(snapshot["delegation_id"])["status"], "passed")

    def test_claim_and_child_operations_require_exact_identity_and_lease(self) -> None:
        with test_workspace("p4-5b-lease") as workspace:
            runtime = self._submitted_runtime(workspace)
            with self.assertRaisesRegex(ProtocolError, "No claimable delegation"):
                self._claim(runtime, at="2026-08-05T12:05:30+05:30")
            with self.assertRaisesRegex(ProtocolError, "No claimable delegation"):
                runtime.claim(
                    project_id="fixture-a-low-risk",
                    identity_id="fixture-a-low-risk-evaluator",
                    lease_seconds=60,
                    at="2026-08-05T12:06:30+05:30",
                    lease_token="different-test-token-with-length",
                )
            claim = self._claim(runtime)
            with self.assertRaisesRegex(ProtocolError, "Lease token"):
                runtime.record_action(
                    self._action(),
                    lease_token="forged-token-with-adequate-length",
                    **self._runtime_inputs(),
                )
            with self.assertRaisesRegex(ProtocolError, "active lease"):
                runtime.record_message(
                    {
                        "version": "0.5.1",
                        "id": "fixture-a-message-no-lease",
                        "project_id": "fixture-a-low-risk",
                        "delegation_id": "fixture-a-low-risk-DEL-001",
                        "parent_run_id": "fixture-a-low-risk-parent-run",
                        "child_run_id": "fixture-a-low-risk-child-run",
                        "from_identity": "fixture-a-low-risk-executor",
                        "to_identity": "fixture-a-low-risk-human",
                        "kind": "status",
                        "content": "Status.",
                        "evidence_refs": [],
                        "sequence": 1,
                        "state_effect": "none",
                        "created_at": "2026-08-05T12:08:00+05:30",
                    },
                    lease_token=None,
                    **self._runtime_inputs(),
                )
            self.assertEqual(claim["lease"]["identity_id"], "fixture-a-low-risk-executor")

    def test_actions_fail_closed_on_authority_tool_budget_and_sequence(self) -> None:
        with test_workspace("p4-5b-actions") as workspace:
            runtime = self._submitted_runtime(workspace)
            token = self._claim(runtime)["lease_token"]
            cases = {
                "authority": lambda action: action.update({"action": "approve"}),
                "undelegated tool": lambda action: action.update(
                    {"tool": "production-deploy"}
                ),
                "budget": lambda action: action["budget_consumed"].update(
                    {"cost_limit_usd": 99}
                ),
                "sequence": lambda action: action.update({"sequence": 2}),
                "predates": lambda action: action.update(
                    {"started_at": "2026-08-05T12:05:30+05:30"}
                ),
            }
            for expected, mutate in cases.items():
                with self.subTest(expected=expected):
                    action = self._action()
                    mutate(action)
                    with self.assertRaisesRegex(ProtocolError, expected):
                        runtime.record_action(
                            action,
                            lease_token=token,
                            **self._runtime_inputs(),
                        )

    def test_messages_bind_chain_endpoints_and_contiguous_sequence(self) -> None:
        with test_workspace("p4-5b-messages") as workspace:
            runtime = self._submitted_runtime(workspace)
            token = self._claim(runtime)["lease_token"]
            base = {
                "version": "0.5.1",
                "id": "fixture-a-message-1",
                "project_id": "fixture-a-low-risk",
                "delegation_id": "fixture-a-low-risk-DEL-001",
                "parent_run_id": "fixture-a-low-risk-parent-run",
                "child_run_id": "fixture-a-low-risk-child-run",
                "from_identity": "fixture-a-low-risk-executor",
                "to_identity": "fixture-a-low-risk-human",
                "kind": "status",
                "content": "Bound status.",
                "evidence_refs": [],
                "sequence": 1,
                "state_effect": "none",
                "created_at": "2026-08-05T12:08:00+05:30",
            }
            forged = copy.deepcopy(base)
            forged["to_identity"] = "fixture-a-low-risk-evaluator"
            with self.assertRaisesRegex(ProtocolError, "parent and child identities"):
                runtime.record_message(
                    forged,
                    lease_token=token,
                    **self._runtime_inputs(),
                )
            skipped = copy.deepcopy(base)
            skipped["sequence"] = 2
            with self.assertRaisesRegex(ProtocolError, "sequence must be 1"):
                runtime.record_message(
                    skipped,
                    lease_token=token,
                    **self._runtime_inputs(),
                )
            runtime.record_message(
                base,
                lease_token=token,
                **self._runtime_inputs(),
            )
            duplicate = copy.deepcopy(base)
            duplicate["id"] = "fixture-a-message-duplicate"
            with self.assertRaisesRegex(ProtocolError, "sequence must be 2"):
                runtime.record_message(
                    duplicate,
                    lease_token=token,
                    **self._runtime_inputs(),
                )

    def test_checkpoint_chain_and_action_budget_are_enforced(self) -> None:
        with test_workspace("p4-5b-checkpoint") as workspace:
            runtime = self._submitted_runtime(workspace)
            token = self._claim(runtime)["lease_token"]
            runtime.record_action(
                self._action(),
                lease_token=token,
                **self._runtime_inputs(),
            )
            bad_budget = copy.deepcopy(self.fixture["checkpoint"])
            bad_budget["action_sequence"] = 1
            bad_budget["budget_consumed"]["token_limit"] = 99
            bad_budget = finalize_checkpoint(bad_budget)
            with self.assertRaisesRegex(ProtocolError, "journaled action budget"):
                runtime.record_checkpoint(
                    bad_budget,
                    lease_token=token,
                    **self._runtime_inputs(),
                )
            first = copy.deepcopy(self.fixture["checkpoint"])
            first["action_sequence"] = 1
            first["budget_consumed"] = self._action()["budget_consumed"]
            first = finalize_checkpoint(first)
            runtime.record_checkpoint(
                first,
                lease_token=token,
                **self._runtime_inputs(),
            )
            second = copy.deepcopy(first)
            second.update(
                {
                    "id": "fixture-a-low-risk-CP-002",
                    "sequence": 2,
                    "previous_checkpoint_sha256": "f" * 64,
                    "created_at": "2026-08-05T12:11:00+05:30",
                }
            )
            second = finalize_checkpoint(second)
            with self.assertRaisesRegex(ProtocolError, "chain tip"):
                runtime.record_checkpoint(
                    second,
                    lease_token=token,
                    **self._runtime_inputs(),
                )

    def test_checkpoint_action_coverage_must_match_the_action_journal(self) -> None:
        with test_workspace("p4-5b-checkpoint-action-coverage") as workspace:
            runtime = self._submitted_runtime(workspace)
            token = self._claim(runtime)["lease_token"]
            runtime.record_action(
                self._action(),
                lease_token=token,
                **self._runtime_inputs(),
            )
            checkpoint = copy.deepcopy(self.fixture["checkpoint"])
            checkpoint["budget_consumed"] = self._action()["budget_consumed"]
            checkpoint["action_sequence"] = 999
            checkpoint = finalize_checkpoint(checkpoint)
            with self.assertRaisesRegex(
                ProtocolError,
                "action_sequence must equal the journaled action count",
            ):
                runtime.record_checkpoint(
                    checkpoint,
                    lease_token=token,
                    **self._runtime_inputs(),
                )

    def test_runtime_operations_require_explicit_matching_run_authority(self) -> None:
        with test_workspace("p4-5b-message-authority") as workspace:
            fixture = self._without_operational_grant("message")
            runtime = self._submitted_runtime(workspace, fixture)
            token = self._claim(runtime)["lease_token"]
            with self.assertRaisesRegex(ProtocolError, "explicit 'message' authority"):
                runtime.record_message(
                    {
                        "version": "0.5.1",
                        "id": "fixture-a-message-without-authority",
                        "project_id": "fixture-a-low-risk",
                        "delegation_id": "fixture-a-low-risk-DEL-001",
                        "parent_run_id": "fixture-a-low-risk-parent-run",
                        "child_run_id": "fixture-a-low-risk-child-run",
                        "from_identity": "fixture-a-low-risk-executor",
                        "to_identity": "fixture-a-low-risk-human",
                        "kind": "status",
                        "content": "This message is not explicitly authorized.",
                        "evidence_refs": [],
                        "sequence": 1,
                        "state_effect": "none",
                        "created_at": "2026-08-05T12:08:00+05:30",
                    },
                    lease_token=token,
                    **self._runtime_inputs(),
                )

        with test_workspace("p4-5b-checkpoint-authority") as workspace:
            fixture = self._without_operational_grant("checkpoint")
            runtime = self._submitted_runtime(workspace, fixture)
            token = self._claim(runtime)["lease_token"]
            with self.assertRaisesRegex(ProtocolError, "explicit 'checkpoint' authority"):
                runtime.record_checkpoint(
                    fixture["checkpoint"],
                    lease_token=token,
                    **self._runtime_inputs(),
                )

        with test_workspace("p4-5b-cancel-authority") as workspace:
            runtime = self._submitted_runtime(workspace)
            token = self._claim(runtime)["lease_token"]
            with self.assertRaisesRegex(ProtocolError, "explicit 'cancel' authority"):
                runtime.cancel(
                    {
                        "version": "0.5.1",
                        "id": "fixture-a-child-cancel-without-authority",
                        "project_id": "fixture-a-low-risk",
                        "subject_type": "delegation",
                        "subject_id": "fixture-a-low-risk-DEL-001",
                        "requested_by": "fixture-a-low-risk-executor",
                        "reason": "The child cannot cancel without an explicit grant.",
                        "propagate_to_active_children": True,
                        "requested_at": "2026-08-05T12:09:00+05:30",
                        "status": "requested",
                    },
                    lease_token=token,
                )

        with test_workspace("p4-5b-escalate-authority") as workspace:
            runtime = self._submitted_runtime(workspace)
            token = self._claim(runtime)["lease_token"]
            with self.assertRaisesRegex(ProtocolError, "explicit 'escalate' authority"):
                runtime.escalate(
                    {
                        "version": "0.5.1",
                        "id": "fixture-a-escalation-without-authority",
                        "project_id": "fixture-a-low-risk",
                        "delegation_id": "fixture-a-low-risk-DEL-001",
                        "run_id": "fixture-a-low-risk-child-run",
                        "raised_by": "fixture-a-low-risk-executor",
                        "owner_role": "architecture-owner",
                        "reason": "The child cannot escalate without an explicit grant.",
                        "evidence_refs": ["evidence:authority-check"],
                        "raised_at": "2026-08-05T12:09:00+05:30",
                        "status": "open",
                    },
                    lease_token=token,
                )

    def test_explicit_child_cancel_and_escalation_grants_are_honored(self) -> None:
        with test_workspace("p4-5b-child-cancel") as workspace:
            fixture = self._with_delegation_actions("cancel")
            runtime = self._submitted_runtime(workspace, fixture)
            token = self._claim(runtime)["lease_token"]
            with self.assertRaisesRegex(ProtocolError, "ancestor or sibling"):
                runtime.cancel(
                    {
                        "version": "0.5.1",
                        "id": "fixture-a-child-cancel-parent",
                        "project_id": "fixture-a-low-risk",
                        "subject_type": "agent-run",
                        "subject_id": "fixture-a-low-risk-parent-run",
                        "requested_by": "fixture-a-low-risk-executor",
                        "reason": "A delegated child cannot cancel its parent run.",
                        "propagate_to_active_children": True,
                        "requested_at": "2026-08-05T12:08:00+05:30",
                        "status": "requested",
                    },
                    lease_token=token,
                )
            result = runtime.cancel(
                {
                    "version": "0.5.1",
                    "id": "fixture-a-child-cancel",
                    "project_id": "fixture-a-low-risk",
                    "subject_type": "delegation",
                    "subject_id": "fixture-a-low-risk-DEL-001",
                    "requested_by": "fixture-a-low-risk-executor",
                    "reason": "The explicitly authorized child terminated its delegation.",
                    "propagate_to_active_children": True,
                    "requested_at": "2026-08-05T12:09:00+05:30",
                    "status": "requested",
                },
                lease_token=token,
            )
            self.assertEqual(result["snapshot"]["delegation"]["status"], "cancelled")

        with test_workspace("p4-5b-child-escalate") as workspace:
            fixture = self._with_delegation_actions("escalate")
            runtime = self._submitted_runtime(workspace, fixture)
            token = self._claim(runtime)["lease_token"]
            snapshot = runtime.escalate(
                {
                    "version": "0.5.1",
                    "id": "fixture-a-child-escalation",
                    "project_id": "fixture-a-low-risk",
                    "delegation_id": "fixture-a-low-risk-DEL-001",
                    "run_id": "fixture-a-low-risk-child-run",
                    "raised_by": "fixture-a-low-risk-executor",
                    "owner_role": "architecture-owner",
                    "reason": "The explicitly authorized child requires owner judgment.",
                    "evidence_refs": ["evidence:blocked-work"],
                    "raised_at": "2026-08-05T12:09:00+05:30",
                    "status": "open",
                },
                lease_token=token,
            )
            self.assertEqual(snapshot["child_run"]["status"], "blocked")
            self.assertEqual(snapshot["counts"]["escalations"], 1)

    def test_cancellation_propagates_from_parent_run_and_replay_matches(self) -> None:
        with test_workspace("p4-5b-cancel") as workspace:
            runtime = self._submitted_runtime(workspace)
            self._claim(runtime)
            result = runtime.cancel(
                {
                    "version": "0.5.1",
                    "id": "fixture-a-cancel-1",
                    "project_id": "fixture-a-low-risk",
                    "subject_type": "agent-run",
                    "subject_id": "fixture-a-low-risk-parent-run",
                    "requested_by": "fixture-a-low-risk-human",
                    "reason": "The accountable owner terminated the bounded work.",
                    "propagate_to_active_children": True,
                    "requested_at": "2026-08-05T12:09:00+05:30",
                    "status": "requested",
                }
            )
            snapshot = runtime.snapshot("fixture-a-low-risk-DEL-001")
            self.assertIn(
                "fixture-a-low-risk-child-run",
                result["affected"]["run_ids"],
            )
            self.assertEqual(snapshot["delegation"]["status"], "cancelled")
            self.assertEqual(snapshot["child_run"]["status"], "cancelled")
            self.assertEqual(snapshot["lease"]["status"], "cancelled")
            self.assertEqual(
                runtime.verify_replay("fixture-a-low-risk-DEL-001")["status"],
                "passed",
            )

    def test_cancellation_without_a_lease_replays_with_no_lease(self) -> None:
        with test_workspace("p4-5b-cancel-without-lease") as workspace:
            runtime = self._submitted_runtime(workspace)
            result = runtime.cancel(
                {
                    "version": "0.5.1",
                    "id": "fixture-a-cancel-without-lease",
                    "project_id": "fixture-a-low-risk",
                    "subject_type": "delegation",
                    "subject_id": "fixture-a-low-risk-DEL-001",
                    "requested_by": "fixture-a-low-risk-human",
                    "reason": "The accountable owner cancelled before work was claimed.",
                    "propagate_to_active_children": True,
                    "requested_at": "2026-08-05T12:06:15+05:30",
                    "status": "requested",
                }
            )
            self.assertIsNone(result["snapshot"]["lease"])
            replay = runtime.verify_replay("fixture-a-low-risk-DEL-001")
            self.assertEqual(replay["status"], "passed")
            self.assertIsNone(replay["replayed_state"]["lease_status"])
            self.assertEqual(replay["lease_count"], 0)
            self.assertEqual(replay["cancellation_count"], 1)

    def test_direct_child_cancellation_closes_owning_delegation(self) -> None:
        with test_workspace("p4-5b-cancel-child") as workspace:
            runtime = self._submitted_runtime(workspace)
            self._claim(runtime)
            result = runtime.cancel(
                {
                    "version": "0.5.1",
                    "id": "fixture-a-cancel-child",
                    "project_id": "fixture-a-low-risk",
                    "subject_type": "agent-run",
                    "subject_id": "fixture-a-low-risk-child-run",
                    "requested_by": "fixture-a-low-risk-human",
                    "reason": "The accountable owner cancelled the delegated child run.",
                    "propagate_to_active_children": True,
                    "requested_at": "2026-08-05T12:09:00+05:30",
                    "status": "requested",
                }
            )
            self.assertIn(
                "fixture-a-low-risk-DEL-001",
                result["affected"]["delegation_ids"],
            )
            self.assertEqual(result["snapshot"]["delegation"]["status"], "cancelled")
            self.assertEqual(result["snapshot"]["child_run"]["status"], "cancelled")
            self.assertEqual(
                runtime.verify_replay("fixture-a-low-risk-DEL-001")["status"],
                "passed",
            )

    def test_terminal_delegated_work_cannot_be_cancelled(self) -> None:
        with test_workspace("p4-5b-cancel-terminal") as workspace:
            runtime = self._submitted_runtime(workspace)
            token = self._claim(runtime)["lease_token"]
            checkpoint = copy.deepcopy(self.fixture["checkpoint"])
            checkpoint.update(
                {
                    "status": "completed",
                    "completed_scope": ["src/component"],
                    "remaining_scope": [],
                    "evidence_refs": ["evidence:complete"],
                }
            )
            runtime.record_checkpoint(
                finalize_checkpoint(checkpoint),
                lease_token=token,
                **self._runtime_inputs(),
            )
            with self.assertRaisesRegex(ProtocolError, "terminal delegated work"):
                runtime.cancel(
                    {
                        "version": "0.5.1",
                        "id": "fixture-a-cancel-terminal",
                        "project_id": "fixture-a-low-risk",
                        "subject_type": "delegation",
                        "subject_id": "fixture-a-low-risk-DEL-001",
                        "requested_by": "fixture-a-low-risk-human",
                        "reason": "Completed work cannot be cancelled retroactively.",
                        "propagate_to_active_children": True,
                        "requested_at": "2026-08-05T12:11:00+05:30",
                        "status": "requested",
                    }
                )
            self.assertEqual(
                runtime.verify_replay("fixture-a-low-risk-DEL-001")["status"],
                "passed",
            )

    def test_parent_lifecycle_and_active_descendants_block_child_progress(self) -> None:
        with test_workspace("p4-5b-nested-lifecycle") as workspace:
            fixture = self._with_delegation_actions("delegate", "escalate")
            runtime = self._submitted_runtime(workspace, fixture)
            nested = self._submit_nested(runtime, workspace, fixture)
            first_token = self._claim(
                runtime, at="2026-08-05T12:08:30+05:30"
            )["lease_token"]
            second_token = self._claim(
                runtime,
                at="2026-08-05T12:08:30+05:30",
                lease_token="second-test-lease-token-with-adequate-length",
            )["lease_token"]

            completed = copy.deepcopy(fixture["checkpoint"])
            completed.update(
                {
                    "status": "completed",
                    "completed_scope": ["src/component"],
                    "remaining_scope": [],
                    "evidence_refs": ["evidence:parent-complete"],
                }
            )
            with self.assertRaisesRegex(ProtocolError, "active descendants"):
                runtime.record_checkpoint(
                    finalize_checkpoint(completed),
                    lease_token=first_token,
                    **self._runtime_inputs(),
                )

            runtime.escalate(
                {
                    "version": "0.5.1",
                    "id": "fixture-a-parent-escalation",
                    "project_id": "fixture-a-low-risk",
                    "delegation_id": "fixture-a-low-risk-DEL-001",
                    "run_id": "fixture-a-low-risk-child-run",
                    "raised_by": "fixture-a-low-risk-executor",
                    "owner_role": "architecture-owner",
                    "reason": "The parent run is blocked pending accountable judgment.",
                    "evidence_refs": ["evidence:blocked-parent"],
                    "raised_at": "2026-08-05T12:09:00+05:30",
                    "status": "open",
                },
                lease_token=first_token,
            )
            action = self._action()
            action.update(
                {
                    "id": "fixture-a-grandchild-action",
                    "delegation_id": nested["delegation"]["delegation_id"],
                    "run_id": nested["child_run"]["id"],
                    "started_at": "2026-08-05T12:08:40+05:30",
                    "completed_at": "2026-08-05T12:09:30+05:30",
                }
            )
            with self.assertRaisesRegex(ProtocolError, "Parent run.*not running"):
                runtime.record_action(
                    action,
                    lease_token=second_token,
                    **self._runtime_inputs(),
                )

    def test_expiry_sweep_aborts_unfinished_child(self) -> None:
        with test_workspace("p4-5b-expiry") as workspace:
            runtime = self._submitted_runtime(workspace)
            report = runtime.sweep(at="2026-08-07T18:00:00+05:30")
            snapshot = runtime.snapshot("fixture-a-low-risk-DEL-001")
            self.assertEqual(
                report["expired_delegations"],
                ["fixture-a-low-risk-DEL-001"],
            )
            self.assertEqual(snapshot["delegation"]["status"], "expired")
            self.assertEqual(snapshot["child_run"]["status"], "aborted")
            self.assertEqual(
                runtime.verify_replay("fixture-a-low-risk-DEL-001")["status"],
                "passed",
            )

    def test_expiry_sweep_honors_child_run_deadline(self) -> None:
        with test_workspace("p4-5b-child-deadline") as workspace:
            fixture = copy.deepcopy(self.fixture)
            fixture["child_run"]["deadline"] = "2026-08-05T12:08:00+05:30"
            runtime = self._submitted_runtime(workspace, fixture)
            report = runtime.sweep(at="2026-08-05T12:09:00+05:30")
            snapshot = runtime.snapshot("fixture-a-low-risk-DEL-001")
            self.assertEqual(
                report["expired_delegations"],
                ["fixture-a-low-risk-DEL-001"],
            )
            self.assertEqual(snapshot["delegation"]["status"], "expired")
            self.assertEqual(snapshot["child_run"]["status"], "aborted")

    def test_submit_rejects_unbound_context_and_aggregate_delegation_budget(self) -> None:
        with test_workspace("p4-5b-submit") as workspace:
            runtime = self._submitted_runtime(workspace)
            second = copy.deepcopy(self.fixture)
            second["delegation"]["delegation_id"] = "fixture-a-low-risk-DEL-002"
            second["delegation"]["budget"]["token_limit"] = 13000
            second["delegation"]["budget"]["cost_limit_usd"] = 13
            second["delegation"] = finalize_delegation(second["delegation"])
            second["child_run"]["id"] = "fixture-a-low-risk-child-run-2"
            second["child_run"]["delegation_id"] = "fixture-a-low-risk-DEL-002"
            second["child_run"]["context_packet_id"] = "fixture-a-context-2"
            second["child_run"]["budget"] = copy.deepcopy(second["delegation"]["budget"])
            second["context_request"]["id"] = "fixture-a-context-2"
            second["context_request"]["delegation_id"] = "fixture-a-low-risk-DEL-002"
            with self.assertRaisesRegex(ProtocolError, "Aggregate child delegation budget"):
                runtime.submit(
                    parent_run=second["parent_run"],
                    delegation=second["delegation"],
                    child_run=second["child_run"],
                    context_packet=self._packet(workspace, second),
                    context_base_dir=workspace,
                    profile=second["profile"],
                    authority_bindings=self.bindings,
                    delegation_policy=self.data["delegation-policy"],
                    role_registry=self.data["role-registry"],
                    authority_matrix=self.data["authority-matrix"],
                    submitted_at="2026-08-05T12:07:00+05:30",
                )


if __name__ == "__main__":
    unittest.main()
