from __future__ import annotations

import copy
import os
import unittest

from elder_protocol.errors import ProtocolError
from tests._sf401_support import (
    build_environment,
    run_chain,
    submission,
)
from tests._support import test_workspace


class SF401GovernedContextComponentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._workspace_context = test_workspace("sf401-component")
        cls.workspace = cls._workspace_context.__enter__()
        cls.environment = build_environment(cls.workspace)

    @classmethod
    def tearDownClass(cls) -> None:
        cls._workspace_context.__exit__(None, None, None)

    def test_assemble_derives_budget_persists_and_replays_exact_packet(self) -> None:
        selected = submission(self.environment)
        first = self.environment["service"].assemble(selected)
        second = self.environment["service"].assemble(copy.deepcopy(selected))

        self.assertEqual(first["packet"], second["packet"])
        self.assertEqual(first["binding"], second["binding"])
        self.assertEqual(first["packet"]["id"], "product-one-context-001")
        self.assertEqual(first["packet"]["token_budget"], 2000)
        self.assertLessEqual(
            first["packet"]["estimated_tokens"],
            first["packet"]["token_budget"],
        )
        self.assertIn(
            self.environment["work"]["work_item"]["payload"]["objective"],
            first["packet"]["query"],
        )
        self.assertEqual(
            self.environment["service"].repository.status()["packets"],
            1,
        )

    def test_empty_memory_and_budget_expansion_fail_closed(self) -> None:
        empty_chain = run_chain(
            packet_id="product-one-context-empty",
            child_run_id="product-one-child-run-empty",
        )
        with self.assertRaisesRegex(
            ProtocolError,
            "boundary rejected assembly",
        ):
            self.environment["service"].assemble(
                submission(
                    self.environment,
                    chain=empty_chain,
                    repository_sources=[],
                )
            )

        memory_chain = run_chain(
            packet_id="product-one-context-memory",
            child_run_id="product-one-child-run-memory",
        )
        with self.assertRaisesRegex(ProtocolError, "cannot retrieve memory"):
            self.environment["service"].assemble(
                submission(
                    self.environment,
                    chain=memory_chain,
                    memory_namespaces=["product-one"],
                )
            )

        budget_chain = run_chain(
            packet_id="product-one-context-budget",
            child_run_id="product-one-child-run-budget",
        )
        with self.assertRaisesRegex(ProtocolError, "exceeds.*ceiling"):
            self.environment["service"].assemble(
                submission(
                    self.environment,
                    chain=budget_chain,
                    requested_token_budget=8001,
                )
            )

        required_chain = run_chain(
            packet_id="product-one-context-required-budget",
            child_run_id="product-one-child-run-required-budget",
        )
        with self.assertRaisesRegex(
            ProtocolError,
            "boundary rejected assembly",
        ):
            self.environment["service"].assemble(
                submission(
                    self.environment,
                    chain=required_chain,
                    requested_token_budget=1,
                )
            )

    def test_stale_activation_and_changed_source_fail_before_use(self) -> None:
        source = self.environment["source"]
        original_stat = source.stat()
        os.utime(source, (1, 1))
        stale_chain = run_chain(
            packet_id="product-one-context-age-stale",
            child_run_id="product-one-child-run-age-stale",
        )
        try:
            with self.assertRaisesRegex(
                ProtocolError,
                "boundary rejected assembly",
            ):
                self.environment["service"].assemble(
                    submission(
                        self.environment,
                        chain=stale_chain,
                        repository_sources=[
                            {
                                "id": "runtime-source-age-stale",
                                "location": (
                                    "src/component/runtime-source.md"
                                ),
                                "authority": "primary",
                                "required": True,
                                "maximum_age_days": 1,
                            }
                        ],
                    )
                )
        finally:
            os.utime(
                source,
                ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns),
            )

        chain = run_chain(
            packet_id="product-one-context-stale",
            child_run_id="product-one-child-run-stale",
        )
        result = self.environment["service"].assemble(
            submission(self.environment, chain=chain)
        )
        digest = result["packet"]["content_sha256"]

        original_source = source.read_text(encoding="utf-8")
        source.write_text(original_source + "changed\n", encoding="utf-8")
        try:
            with self.assertRaisesRegex(
                ProtocolError,
                "boundary rejected assembly",
            ):
                self.environment["service"].assemble(
                    submission(self.environment, chain=chain)
                )
            with self.assertRaisesRegex(
                ProtocolError,
                "does not match the repository",
            ):
                self.environment["service"].verify_for_use(
                    result["packet"]["id"],
                    parent_run=chain["parent_run"],
                    delegation=chain["delegation"],
                    child_run=chain["child_run"],
                    authorized_packet_sha256=digest,
                )
        finally:
            source.write_text(original_source, encoding="utf-8")

        agents = self.environment["project"] / "AGENTS.md"
        original_agents = agents.read_text(encoding="utf-8")
        agents.write_text(original_agents + "\nstale\n", encoding="utf-8")
        try:
            with self.assertRaisesRegex(ProtocolError, "activation source is stale"):
                self.environment["service"].verify_for_use(
                    result["packet"]["id"],
                    parent_run=chain["parent_run"],
                    delegation=chain["delegation"],
                    child_run=chain["child_run"],
                    authorized_packet_sha256=digest,
                )
        finally:
            agents.write_text(original_agents, encoding="utf-8")

    def test_changed_authorized_digest_or_run_chain_is_rejected(self) -> None:
        chain = run_chain(
            packet_id="product-one-context-authorized",
            child_run_id="product-one-child-run-authorized",
        )
        result = self.environment["service"].assemble(
            submission(self.environment, chain=chain)
        )
        with self.assertRaisesRegex(ProtocolError, "changed after authorization"):
            self.environment["service"].verify_for_use(
                result["packet"]["id"],
                parent_run=chain["parent_run"],
                delegation=chain["delegation"],
                child_run=chain["child_run"],
                authorized_packet_sha256="a" * 64,
            )

        changed_child = copy.deepcopy(chain["child_run"])
        changed_child["model"] = "changed-model"
        with self.assertRaisesRegex(ProtocolError, "run chain changed"):
            self.environment["service"].verify_for_use(
                result["packet"]["id"],
                parent_run=chain["parent_run"],
                delegation=chain["delegation"],
                child_run=changed_child,
                authorized_packet_sha256=result["packet"]["content_sha256"],
            )


if __name__ == "__main__":
    unittest.main()
