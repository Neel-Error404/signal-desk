from __future__ import annotations

import copy
from datetime import datetime, timedelta
import unittest
from unittest.mock import patch

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.institutional_l2_qualification import (
    evaluate_institutional_l2,
    validate_institutional_l2_packet,
)
from elder_protocol.io import load_json
from tests._sf606_support import (
    HISTORICAL_BUNDLE,
    blocked_packet,
    canonical_inputs,
    changed_packet,
    compliant_packet,
)


AT = "2026-08-15T14:15:00+00:00"


class SF606InstitutionalL2ComponentTests(unittest.TestCase):
    def test_complete_caller_packet_remains_diagnostic_only(self) -> None:
        report = evaluate_institutional_l2(
            compliant_packet(),
            bundle_path=HISTORICAL_BUNDLE,
            at=AT,
        )
        self.assertFalse(report["qualified"])
        self.assertEqual(report["achieved_level"], "L1")
        self.assertFalse(report["ready_for_human_ratification"])
        self.assertEqual(report["qualification_mode"], "diagnostic-only")
        self.assertTrue(
            all(
                result["status"] == "passed"
                for result in report["metric_results"]
            )
        )
        self.assertIn(
            "institutional-qualification:"
            "provider-bound-evidence-not-implemented",
            report["blockers"],
        )
        self.assertFalse(report["grants_authority"])
        self.assertFalse(report["can_merge"])
        self.assertFalse(report["can_deploy"])

    def test_human_approval_field_cannot_promote_diagnostic_packet(self) -> None:
        report = evaluate_institutional_l2(
            compliant_packet(ratification_status="approved"),
            bundle_path=HISTORICAL_BUNDLE,
            at=AT,
        )
        self.assertFalse(report["qualified"])
        self.assertFalse(report["ready_for_human_ratification"])
        self.assertEqual(report["human_ratification_status"], "approved")

    def test_canonical_policy_and_maturity_must_match_approved_pins(
        self,
    ) -> None:
        cases = [
            (
                "qualification-policy.json",
                lambda value: value["trust"]["anchors"][0].__setitem__(
                    "valid_until",
                    "2035-01-01T00:00:00+00:00",
                ),
                "qualification policy is not pinned",
            ),
            (
                "operational-maturity.json",
                lambda value: value["current_assessment"].__setitem__(
                    "scope",
                    "Unapproved maturity scope.",
                ),
                "maturity model is not pinned",
            ),
        ]
        for filename, mutate, message in cases:
            with self.subTest(filename=filename):
                def load_changed(path):
                    value = load_json(path)
                    if path.name == filename:
                        mutate(value)
                    return value

                with patch(
                    "elder_protocol.factory_operations."
                    "institutional_l2_qualification.load_json",
                    side_effect=load_changed,
                ):
                    with self.assertRaisesRegex(ProtocolError, message):
                        evaluate_institutional_l2(
                            blocked_packet(),
                            bundle_path=HISTORICAL_BUNDLE,
                            at=AT,
                        )

    def test_unsigned_complete_packet_cannot_become_ratification_ready(
        self,
    ) -> None:
        report = evaluate_institutional_l2(
            compliant_packet(),
            bundle_path=HISTORICAL_BUNDLE,
            at=AT,
        )
        self.assertFalse(report["qualified"])
        self.assertFalse(report["ready_for_human_ratification"])
        self.assertEqual(
            report["institutional_attestation"]["status"],
            "missing",
        )
        self.assertIn(
            "institutional-packet:missing-independent-attestation",
            report["blockers"],
        )

    def test_current_packet_fails_every_unproved_institutional_layer(self) -> None:
        report = evaluate_institutional_l2(
            blocked_packet(),
            bundle_path=HISTORICAL_BUNDLE,
            at=AT,
        )
        self.assertFalse(report["qualified"])
        self.assertEqual(report["achieved_level"], "L1")
        self.assertFalse(report["ready_for_human_ratification"])
        self.assertIn(
            "hosted-bundle:wrong-source-revision",
            report["blockers"],
        )
        self.assertIn(
            "metric:real-hosted-work-items",
            report["blockers"],
        )
        self.assertIn(
            "control:protected-base-branch",
            report["blockers"],
        )
        self.assertIn(
            "exercise:backup-and-restore",
            report["blockers"],
        )
        self.assertIn(
            "dimension:owner-outcome-economics",
            report["blockers"],
        )

    def test_packet_digest_and_exact_revision_fail_closed(self) -> None:
        _, maturity = canonical_inputs()
        packet = blocked_packet()
        tampered = copy.deepcopy(packet)
        tampered["observed_until"] = "2026-08-16T14:15:00+00:00"
        with self.assertRaisesRegex(ProtocolError, "digest does not match"):
            validate_institutional_l2_packet(tampered, maturity)

        with self.assertRaisesRegex(
            ProtocolError,
            "not bound to the packet source revision",
        ):
            changed_packet(
                compliant_packet(),
                lambda value: value["work_items"][0].__setitem__(
                    "source_revision",
                    "f" * 40,
                ),
            )
            validate_institutional_l2_packet(
                changed_packet(
                    compliant_packet(),
                    lambda value: value["work_items"][0].__setitem__(
                        "source_revision",
                        "f" * 40,
                    ),
                ),
                maturity,
            )

    def test_active_contradiction_blocks_otherwise_complete_packet(self) -> None:
        packet = changed_packet(
            compliant_packet(),
            lambda value: value["contradictions"].append(
                {
                    "id": "active-provider-contradiction",
                    "status": "active",
                    "reason": "Provider state contradicts the claimed control.",
                    "evidence_ids": ["provider:contradiction"],
                }
            ),
        )
        report = evaluate_institutional_l2(
            packet,
            bundle_path=HISTORICAL_BUNDLE,
            at=AT,
        )
        self.assertFalse(report["qualified"])
        self.assertIn(
            "contradiction:active-provider-contradiction",
            report["blockers"],
        )

    def test_stale_observation_cannot_be_ratified(self) -> None:
        packet = changed_packet(
            compliant_packet(),
            lambda value: (
                value.__setitem__(
                    "observed_from",
                    "2026-06-15T14:15:00+00:00",
                ),
                value.__setitem__(
                    "observed_until",
                    "2026-07-15T14:15:00+00:00",
                ),
                [
                    item.__setitem__(
                        "observed_at",
                        (
                            datetime.fromisoformat(item["observed_at"])
                            - timedelta(days=31)
                        ).isoformat(),
                    )
                    for item in value["work_items"]
                ],
            ),
        )
        report = evaluate_institutional_l2(
            packet,
            bundle_path=HISTORICAL_BUNDLE,
            at=AT,
        )
        self.assertFalse(report["qualified"])
        self.assertFalse(report["observation_fresh"])
        self.assertIn(
            "institutional-packet:stale-observation",
            report["blockers"],
        )


if __name__ == "__main__":
    unittest.main()
