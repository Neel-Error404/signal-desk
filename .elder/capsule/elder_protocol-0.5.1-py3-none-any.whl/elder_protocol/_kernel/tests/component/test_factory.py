from __future__ import annotations

import json
import os
import subprocess
import unittest
from pathlib import Path

from elder_protocol.errors import ProtocolError
from elder_protocol.factory import (
    Factory,
    sanitized_environment,
)
from tests._support import test_workspace


def write_fixture_contract(root: Path) -> Path:
    project = root / "project"
    project.mkdir(parents=True)
    (project / "app.txt").write_text("version one\n", encoding="utf-8")
    (project / "smoke.py").write_text("print('smoke-ok')\n", encoding="utf-8")
    contract = {
        "version": "0.1.0",
        "project": {
            "id": "fixture",
            "path": "project",
            "source_paths": ["app.txt", "smoke.py"],
            "artifact_paths": ["app.txt", "smoke.py"],
            "exclude_globs": [],
            "test_ladder": [
                {
                    "level": level,
                    "command": [
                        "{python}",
                        "-c",
                        f"print('{level.lower()}-ok')",
                    ],
                }
                for level in [
                    "Foundation",
                    "Component",
                    "Integration",
                    "Workflow",
                    "Stress",
                ]
            ],
            "smoke_command": ["{python}", "smoke.py"],
        },
        "git": {
            "default_branch": "main",
            "work_branch_prefix": "work/",
            "branch_pattern": "^work/[a-z0-9][a-z0-9-]{2,63}$",
            "protected_branches": ["main"],
            "required_checks": ["P3 / protocol", "P3 / factory"],
        },
        "workspace": {
            "state_root": ".factory",
            "worktrees": "worktrees",
            "builds": "builds",
            "artifacts": "artifacts",
            "releases": "releases",
            "traces": "traces",
            "environments": "environments",
            "verifications": "verifications",
        },
        "identity": {
            "local_mode": "secretless",
            "ci_mode": "github-oidc",
            "allowed_environment": [
                "PATH",
                "SYSTEMROOT",
                "TEMP",
                "TMP",
                "PATHEXT",
                "COMSPEC",
                "WINDIR",
            ],
            "forbidden_name_patterns": [
                "TOKEN",
                "SECRET",
                "PASSWORD",
                "CREDENTIAL",
                "API_KEY",
            ],
            "external_broker": "required-for-remote",
        },
        "promotion": {
            "environments": ["candidate", "local-canary", "local-stable"],
            "transitions": {
                "candidate": ["local-canary"],
                "local-canary": ["local-stable"],
                "local-stable": [],
            },
            "approval_required": ["local-canary", "local-stable"],
            "health_evidence_required": ["local-canary", "local-stable"],
        },
    }
    contract_path = root / "factory" / "factory-contract.json"
    contract_path.parent.mkdir()
    contract_path.write_text(json.dumps(contract, indent=2), encoding="utf-8")
    return contract_path


def write_approval(
    path: Path,
    *,
    digest: str,
    environment: str,
    action: str = "promote",
) -> Path:
    path.write_text(
        json.dumps(
            {
                "type": "release-approval",
                "action": action,
                "artifact_sha256": digest,
                "environment": environment,
                "approved_by": "fixture-release-owner",
                "approved_at": "2026-08-05T00:00:00+00:00",
                "decision": "approved",
            }
        ),
        encoding="utf-8",
    )
    return path


class FactoryComponentTests(unittest.TestCase):
    def test_sanitized_environment_drops_secret_shaped_names(self) -> None:
        source = {
            "PATH": os.environ.get("PATH", ""),
            "SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
            "ELDER_TEST_TOKEN": "must-not-leak",
            "SERVICE_PASSWORD": "must-not-leak",
        }
        result = sanitized_environment(
            source,
            ["PATH", "SYSTEMROOT", "ELDER_TEST_TOKEN", "SERVICE_PASSWORD"],
            ["TOKEN", "PASSWORD"],
        )
        self.assertIn("PATH", result)
        self.assertNotIn("ELDER_TEST_TOKEN", result)
        self.assertNotIn("SERVICE_PASSWORD", result)

    def test_build_is_reproducible_and_promotion_is_approval_gated(self) -> None:
        with test_workspace("factory-component") as workspace:
            contract_path = write_fixture_contract(workspace)
            factory = Factory(contract_path)

            first = factory.build()
            second = factory.build()
            self.assertEqual(first.artifact_sha256, second.artifact_sha256)
            self.assertNotEqual(first.provenance_path, second.provenance_path)
            self.assertTrue(first.provenance_path.is_file())
            self.assertTrue(second.provenance_path.is_file())

            verification = factory.verify(first.artifact_sha256)
            self.assertEqual(verification["status"], "passed")

            with self.assertRaisesRegex(ProtocolError, "approval"):
                factory.promote(
                    first.artifact_sha256,
                    "local-canary",
                    approval_path=None,
                )

            approval = write_approval(
                workspace / "canary-approval.json",
                digest=first.artifact_sha256,
                environment="local-canary",
            )
            promoted = factory.promote(
                first.artifact_sha256,
                "local-canary",
                approval_path=approval,
            )
            self.assertEqual(promoted["artifact_sha256"], first.artifact_sha256)

    def test_git_worktree_lifecycle_is_isolated(self) -> None:
        with test_workspace("factory-worktree") as workspace:
            contract_path = write_fixture_contract(workspace)
            subprocess.run(["git", "init", "-b", "main"], cwd=workspace, check=True)
            subprocess.run(
                ["git", "config", "user.email", "factory@example.invalid"],
                cwd=workspace,
                check=True,
            )
            subprocess.run(
                ["git", "config", "user.name", "Factory Fixture"],
                cwd=workspace,
                check=True,
            )
            subprocess.run(["git", "add", "."], cwd=workspace, check=True)
            subprocess.run(
                ["git", "commit", "-m", "fixture baseline"],
                cwd=workspace,
                check=True,
                capture_output=True,
                text=True,
            )

            factory = Factory(contract_path)
            created = factory.create_worktree("p3-isolation")
            self.assertTrue(created.is_dir())
            self.assertNotEqual(created.resolve(), workspace.resolve())
            factory.remove_worktree("p3-isolation")
            self.assertFalse(created.exists())

    def test_environment_rolls_back_to_the_previous_verified_artifact(self) -> None:
        with test_workspace("factory-rollback") as workspace:
            contract_path = write_fixture_contract(workspace)
            factory = Factory(contract_path)

            first = factory.build()
            factory.verify(first.artifact_sha256)
            factory.promote(
                first.artifact_sha256,
                "local-canary",
                approval_path=write_approval(
                    workspace / "first-promotion.json",
                    digest=first.artifact_sha256,
                    environment="local-canary",
                ),
            )

            (workspace / "project" / "app.txt").write_text(
                "version two\n",
                encoding="utf-8",
            )
            second = factory.build()
            self.assertNotEqual(first.artifact_sha256, second.artifact_sha256)
            factory.verify(second.artifact_sha256)
            factory.promote(
                second.artifact_sha256,
                "local-canary",
                approval_path=write_approval(
                    workspace / "second-promotion.json",
                    digest=second.artifact_sha256,
                    environment="local-canary",
                ),
            )

            rolled_back = factory.rollback(
                "local-canary",
                approval_path=write_approval(
                    workspace / "rollback.json",
                    digest=first.artifact_sha256,
                    environment="local-canary",
                    action="rollback",
                ),
            )
            self.assertEqual(
                rolled_back["artifact_sha256"],
                first.artifact_sha256,
            )
            self.assertEqual(rolled_back["history"][-1]["action"], "rollback")


if __name__ == "__main__":
    unittest.main()
