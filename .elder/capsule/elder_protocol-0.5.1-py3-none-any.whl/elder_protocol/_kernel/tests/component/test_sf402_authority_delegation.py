from __future__ import annotations

import copy
import sqlite3
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.governance import finalize_delegation
from tests._sf402_support import (
    LEASE_TOKEN,
    build_environment,
    cancellation,
    restart_gate,
    start_submission,
)
from tests._support import test_workspace


class SF402AuthorityDelegationComponentTests(unittest.TestCase):
    def test_start_is_durable_replayable_and_never_persists_lease_token(
        self,
    ) -> None:
        with test_workspace("sf402-start") as workspace:
            environment = build_environment(workspace)
            request = start_submission(environment)
            started = environment["gate"].start(request)
            replayed = environment["gate"].start(request)

            self.assertEqual(started["decision"]["disposition"], "accepted")
            self.assertEqual(started["owner_view"]["condition"], "authorized")
            self.assertFalse(started["replayed"])
            self.assertTrue(replayed["replayed"])
            self.assertEqual(
                replayed["decision"]["content_sha256"],
                started["decision"]["content_sha256"],
            )
            self.assertEqual(
                started["runtime"]["lease"]["identity_id"],
                environment["delegation"]["assigned_identity_id"],
            )
            for path in (
                environment["decision_path"],
                environment["runtime_path"],
            ):
                self.assertNotIn(
                    LEASE_TOKEN.encode("utf-8"),
                    path.read_bytes(),
                )

    def test_scope_tool_budget_deadline_and_identity_expansion_are_rejected(
        self,
    ) -> None:
        mutations = {
            "scope": lambda delegation, child: (
                delegation.update({"scope": ["docs"]}),
                child.update({"scope": ["docs"]}),
            ),
            "tool": lambda delegation, child: (
                delegation.update(
                    {
                        "tool_grants": [
                            *delegation["tool_grants"],
                            "shell-execute",
                        ]
                    }
                ),
                child.update(
                    {
                        "tool_grants": [
                            *child["tool_grants"],
                            "shell-execute",
                        ]
                    }
                ),
            ),
            "budget": lambda delegation, child: (
                delegation["budget"].update({"token_limit": 25000}),
                child["budget"].update({"token_limit": 25000}),
            ),
            "deadline": lambda delegation, child: (
                delegation.update(
                    {
                        "deadline": "2026-08-16T16:00:00+00:00",
                        "expires_at": "2026-08-16T17:00:00+00:00",
                    }
                ),
                child.update(
                    {"deadline": "2026-08-16T16:00:00+00:00"}
                ),
            ),
            "identity": lambda delegation, child: (
                delegation.update({"assigned_identity_id": "founder"}),
                child.update({"identity_id": "founder"}),
            ),
        }
        for name, mutate in mutations.items():
            with self.subTest(name=name):
                with test_workspace(f"sf402-expansion-{name}") as workspace:
                    environment = build_environment(workspace)
                    delegation = copy.deepcopy(environment["delegation"])
                    child = copy.deepcopy(environment["child_run"])
                    mutate(delegation, child)
                    delegation = finalize_delegation(delegation)
                    request = start_submission(
                        environment,
                        request_id=f"sf402-reject-{name}",
                        delegation=delegation,
                        child_run=child,
                    )

                    with self.assertRaisesRegex(
                        ProtocolError,
                        "SF-402 start gate rejected",
                    ):
                        environment["gate"].start(request)

                    view = environment["gate"].owner_view(
                        environment["work"]["work_item"]["id"]
                    )
                    self.assertTrue(view["attention_required"])
                    self.assertEqual(
                        view["entries"][-1]["disposition"],
                        "rejected",
                    )
                    self.assertIn(
                        name,
                        view["entries"][-1]["reason_code"],
                    )

    def test_missing_assigned_child_lease_stops_execution_and_is_visible(
        self,
    ) -> None:
        with test_workspace("sf402-missing-lease") as workspace:
            environment = build_environment(workspace)
            request = start_submission(environment)
            started = environment["gate"].start(request)
            environment["gate"].runtime.release(
                run_id=environment["child_run"]["id"],
                lease_token=LEASE_TOKEN,
                at="2026-08-14T14:02:00+00:00",
            )

            with self.assertRaisesRegex(
                ProtocolError,
                "no active assigned-child lease",
            ):
                environment["gate"].verify_for_execution(
                    started["decision"]["request_id"],
                    lease_token=LEASE_TOKEN,
                    authorized_context_sha256=environment["context"]["packet"][
                        "content_sha256"
                    ],
                    at="2026-08-14T14:03:00+00:00",
                )

            view = environment["gate"].owner_view(
                environment["work"]["work_item"]["id"],
                at="2026-08-14T14:03:00+00:00",
            )
            self.assertTrue(view["attention_required"])
            self.assertEqual(
                view["entries"][-1]["condition"],
                "lease-released",
            )

    def test_expired_lease_and_stale_context_are_owner_visible(self) -> None:
        with test_workspace("sf402-expired-lease") as workspace:
            environment = build_environment(workspace)
            started = environment["gate"].start(
                start_submission(environment)
            )
            expired_view = environment["gate"].owner_view(
                environment["work"]["work_item"]["id"],
                at="2026-08-14T14:12:00+00:00",
            )
            self.assertTrue(expired_view["attention_required"])
            self.assertEqual(
                expired_view["entries"][-1]["condition"],
                "lease-expired",
            )
            with self.assertRaisesRegex(ProtocolError, "lease has expired"):
                environment["gate"].verify_for_execution(
                    started["decision"]["request_id"],
                    lease_token=LEASE_TOKEN,
                    authorized_context_sha256=environment["context"]["packet"][
                        "content_sha256"
                    ],
                    at="2026-08-14T14:12:00+00:00",
                )
            self.assertEqual(
                environment["gate"].runtime.snapshot(
                    environment["delegation"]["delegation_id"]
                )["lease"]["status"],
                "expired",
            )

        with test_workspace("sf402-stale-context") as workspace:
            environment = build_environment(workspace)
            environment["gate"].start(start_submission(environment))
            environment["source"].write_text(
                "SF-402 changed the authorized source after assembly.\n",
                encoding="utf-8",
            )
            stale_view = environment["gate"].owner_view(
                environment["work"]["work_item"]["id"],
                at="2026-08-14T14:05:00+00:00",
            )
            self.assertTrue(stale_view["attention_required"])
            self.assertEqual(
                stale_view["entries"][-1]["condition"],
                "blocked",
            )
            self.assertIn(
                "does not match the repository",
                stale_view["entries"][-1]["actionable_reason"].lower(),
            )

    def test_rejection_and_cancellation_survive_service_restart(self) -> None:
        with test_workspace("sf402-restart") as workspace:
            environment = build_environment(workspace)
            wrong_requester = start_submission(
                environment,
                request_id="sf402-wrong-requester",
                requested_by="example-agentic-product-planning-agent",
            )
            with self.assertRaises(ProtocolError):
                environment["gate"].start(wrong_requester)

            request = start_submission(
                environment,
                request_id="sf402-valid-after-rejection",
            )
            environment["gate"].start(request)
            restarted = restart_gate(environment)
            cancelled = restarted.cancel(cancellation(environment))
            restarted_again = restart_gate(environment)
            view = restarted_again.owner_view(
                environment["work"]["work_item"]["id"],
                at="2026-08-14T14:07:00+00:00",
            )

            self.assertEqual(
                cancelled["decision"]["reason_code"],
                "cancellation-propagated",
            )
            self.assertTrue(
                any(entry["disposition"] == "rejected" for entry in view["entries"])
            )
            self.assertEqual(view["entries"][-1]["condition"], "cancelled")
            self.assertNotIn(
                LEASE_TOKEN,
                environment["decision_path"].read_text(
                    encoding="utf-8",
                    errors="ignore",
                ),
            )
            connection = sqlite3.connect(environment["runtime_path"])
            try:
                lease_status = connection.execute(
                    "SELECT status FROM leases ORDER BY claimed_at DESC LIMIT 1"
                ).fetchone()[0]
            finally:
                connection.close()
            self.assertEqual(lease_status, "cancelled")


if __name__ == "__main__":
    unittest.main()
