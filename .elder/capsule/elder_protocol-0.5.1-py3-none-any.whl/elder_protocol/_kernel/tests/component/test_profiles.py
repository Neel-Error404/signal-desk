from __future__ import annotations

import unittest

from elder_protocol.constants import PROTOCOL_VERSION, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.intake import profile_from_answers
from elder_protocol.io import load_json
from elder_protocol.profiles import (
    migrate_profile,
    ratify_profile,
    resolve_capability_packs,
    validate_profile,
)
from elder_protocol.protocol import validate_protocol


class ProfileComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.data = validate_protocol()

    def test_draft_profile_requires_bound_human_owner_ratification(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["profile_status"] = "draft"
        ratified = ratify_profile(profile, self.data, "founder")
        self.assertEqual(ratified["profile_status"], "ratified")
        with self.assertRaisesRegex(ProtocolError, "bound human-owner"):
            ratify_profile(profile, self.data, "example-agentic-product-executor")

    def test_v01_profile_migrates_to_current_draft(self) -> None:
        old = {
            "protocol_version": "0.1.0",
            "name": "Old Profile",
            "slug": "old-profile",
            "mission": "Exercise the supported migration path.",
            "project_type": "software",
            "lifecycle": "prototype",
            "topology": "single-repo",
            "risk_tier": "low",
            "autonomy_ceiling": "L1",
            "capability_packs": ["core"],
            "languages": ["Python"],
            "deployment_targets": [],
            "human_owners": {
                "product": "owner",
                "architecture": "owner",
                "security": "owner",
                "release": "owner",
            },
        }
        migrated, notes = migrate_profile(old)
        validate_profile(migrated, self.data)
        self.assertEqual(migrated["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(migrated["profile_status"], "draft")
        self.assertTrue(notes)

    def test_v02_profile_migrates_for_graph_and_pack_review(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["protocol_version"] = "0.2.0"
        migrated, notes = migrate_profile(profile)
        validate_profile(migrated, self.data)
        self.assertEqual(migrated["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(migrated["profile_status"], "draft")
        self.assertTrue(any("project graph" in note for note in notes))

    def test_v04_profile_migrates_for_p4_1_contract_review(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["protocol_version"] = "0.4.0"
        migrated, notes = migrate_profile(profile)
        validate_profile(migrated, self.data)
        self.assertEqual(migrated["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(migrated["profile_status"], "draft")
        self.assertTrue(any("transcript evaluation" in note for note in notes))

    def test_v041_profile_migrates_for_p4_2_evaluation_review(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["protocol_version"] = "0.4.1"
        migrated, notes = migrate_profile(profile)
        validate_profile(migrated, self.data)
        self.assertEqual(migrated["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(migrated["profile_status"], "draft")
        self.assertTrue(any("evaluator calibration" in note for note in notes))

    def test_v043_profile_migrates_for_p4_4_knowledge_review(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["protocol_version"] = "0.4.3"
        migrated, notes = migrate_profile(profile)
        validate_profile(migrated, self.data)
        self.assertEqual(migrated["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(migrated["profile_status"], "draft")
        self.assertTrue(any("governed context" in note for note in notes))

    def test_v046_profile_migrates_for_p4_6_learning_review(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["protocol_version"] = "0.4.6"
        migrated, notes = migrate_profile(profile)
        validate_profile(migrated, self.data)
        self.assertEqual(migrated["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(migrated["profile_status"], "draft")
        self.assertTrue(any("quarantined learning" in note for note in notes))

    def test_v047_profile_migrates_for_p4_7_qualification_review(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["protocol_version"] = "0.4.7"
        migrated, notes = migrate_profile(profile)
        validate_profile(migrated, self.data)
        self.assertEqual(migrated["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(migrated["profile_status"], "draft")
        self.assertTrue(any("hosted production qualification" in note for note in notes))

    def test_intake_answers_create_valid_profile(self) -> None:
        answers = load_json(ROOT / "examples" / "intake-answers.json")
        profile = profile_from_answers(answers, self.data)
        validate_profile(profile, self.data)
        self.assertEqual(profile["slug"], "example-intake-product")

    def test_unknown_capability_pack_is_rejected(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["capability_packs"].append("unknown-pack")
        with self.assertRaisesRegex(ProtocolError, "Unknown capability packs"):
            validate_profile(profile, self.data)

    def test_conflicting_skill_overrides_are_rejected(self) -> None:
        profile = load_json(ROOT / "examples" / "minimal-project-profile.json")
        profile["skill_overrides"] = {
            "required": ["wayfinder"],
            "forbidden": ["wayfinder"],
        }
        with self.assertRaisesRegex(ProtocolError, "both required and forbidden"):
            validate_profile(profile, self.data)

    def test_capability_pack_dependencies_are_resolved(self) -> None:
        resolved = resolve_capability_packs(["learning"], self.data)
        self.assertEqual(
            resolved,
            [
                "core",
                "factory-operations",
                "assurance",
                "agentic",
                "learning",
            ],
        )

    def test_universal_factory_and_assurance_packs_are_always_selected(self) -> None:
        resolved = resolve_capability_packs(["core"], self.data)
        self.assertEqual(resolved, ["core", "factory-operations", "assurance"])


if __name__ == "__main__":
    unittest.main()
