from __future__ import annotations

import json
import unittest

from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.skills import (
    create_skill,
    route_skills,
    validate_skill_registry,
)
from tests._support import test_workspace


class SkillComponentTests(unittest.TestCase):
    def test_architecture_route_includes_dependencies(self) -> None:
        registry = validate_skill_registry(
            ROOT / "protocol" / "skill-registry.json", ROOT / "skills"
        )
        routed = route_skills(
            "Design architecture nodes edges and dependency boundaries",
            registry,
            {"core", "agentic"},
            limit=5,
        )
        ids = [entry["id"] for entry in routed]
        self.assertIn("wayfinder", ids)
        self.assertIn("architecture-governance", ids)
        self.assertLess(ids.index("wayfinder"), ids.index("architecture-governance"))

    def test_route_limit_does_not_drop_matched_skill_dependencies(self) -> None:
        registry = validate_skill_registry(
            ROOT / "protocol" / "skill-registry.json", ROOT / "skills"
        )
        routed = route_skills(
            "Design architecture nodes edges and dependency boundaries",
            registry,
            {"core", "agentic"},
            limit=1,
        )
        ids = [entry["id"] for entry in routed]
        self.assertIn("wayfinder", ids)
        self.assertIn("grill-with-docs", ids)
        self.assertIn("architecture-governance", ids)

    def test_skill_creator_writes_and_validates_skill(self) -> None:
        with test_workspace("skill-create") as workspace:
            skills_root = workspace / "skills"
            registry_path = workspace / "registry.json"
            registry_path.write_text(
                json.dumps({"version": "0.2.0", "skills": []}),
                encoding="utf-8",
            )
            target = create_skill(
                skills_root,
                registry_path,
                "release-check",
                "Use when validating a release package before governed promotion.",
                ["release", "validation"],
                ["release check"],
                [],
                ["core"],
                5,
            )
            self.assertTrue(target.is_file())
            registry = validate_skill_registry(registry_path, skills_root)
            self.assertEqual(registry["skills"][0]["id"], "release-check")

    def test_skill_creator_rejects_duplicate(self) -> None:
        with test_workspace("skill-duplicate") as workspace:
            skills_root = workspace / "skills"
            registry_path = workspace / "registry.json"
            registry_path.write_text(
                json.dumps({"version": "0.2.0", "skills": []}),
                encoding="utf-8",
            )
            arguments = (
                skills_root,
                registry_path,
                "release-check",
                "Use when validating a release package before governed promotion.",
                ["release"],
                ["release check"],
                [],
                ["core"],
                5,
            )
            create_skill(*arguments)
            with self.assertRaisesRegex(ProtocolError, "already exists"):
                create_skill(*arguments)


if __name__ == "__main__":
    unittest.main()
