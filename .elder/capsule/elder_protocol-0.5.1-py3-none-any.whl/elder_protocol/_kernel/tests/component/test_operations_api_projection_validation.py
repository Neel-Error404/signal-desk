from __future__ import annotations

import copy
import unittest
from unittest.mock import patch

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.api_contracts import (
    load_operations_api_contracts,
)
from elder_protocol.factory_operations.api_projection_validation import (
    OperationsApiProjectionValidator,
)
from elder_protocol.factory_operations.projections import (
    ProjectionQueries,
    ProjectionRuntime,
)
from tests._support import test_workspace
from tests.component import test_signal_intake as signal_intake_tests


class OperationsApiProjectionValidationComponentTests(unittest.TestCase):
    @staticmethod
    def _scope(route_id: str) -> dict:
        return load_operations_api_contracts().response_scopes_by_route_id[
            route_id
        ]

    def _fixture(self, workspace):
        helper = signal_intake_tests.SignalIntakeComponentTests(
            methodName="runTest"
        )
        registry, intake = helper._operations(workspace)
        intake.ingest(
            helper._envelope(),
            actor_identity_id="example-agentic-product-intake-agent",
            received_at="2026-08-08T08:00:02+00:00",
        )
        path = workspace / "operations.db"
        ProjectionRuntime(path).rebuild_all()
        return (
            registry,
            ProjectionQueries(path),
            OperationsApiProjectionValidator(path),
        )

    def test_exact_active_rows_pages_history_and_timeline_validate(
        self,
    ) -> None:
        with test_workspace("sf107-api-projection-validation") as workspace:
            _, queries, validator = self._fixture(workspace)

            record_arguments = {
                "project_id": "product-one",
                "signal_id": "signal-github-001",
            }
            record = queries.get_signal(**record_arguments)
            self.assertIs(
                validator.validate(
                    route_id="signal-get",
                    data=record,
                    arguments=record_arguments,
                    response_scope=self._scope("signal-get"),
                ),
                record,
            )

            page_arguments = {
                "project_id": "product-one",
                "status": "accepted",
                "limit": 1,
                "continuation": None,
            }
            page = queries.list_signals(**page_arguments)
            validator.validate(
                route_id="signals-list",
                data=page,
                arguments=page_arguments,
                response_scope=self._scope("signals-list"),
            )

            history_arguments = {
                "project_id": "product-one",
                "signal_id": "signal-github-001",
                "limit": 1,
                "continuation": None,
            }
            history = queries.signal_history(**history_arguments)
            self.assertIsNotNone(history["continuation"])
            validator.validate(
                route_id="signal-history",
                data=history,
                arguments=history_arguments,
                response_scope=self._scope("signal-history"),
            )
            continued_arguments = {
                **history_arguments,
                "continuation": history["continuation"],
            }
            continued = queries.signal_history(**continued_arguments)
            validator.validate(
                route_id="signal-history",
                data=continued,
                arguments=continued_arguments,
                response_scope=self._scope("signal-history"),
            )

            timeline_arguments = {
                "project_id": "product-one",
                "subject_id": "signal-github-001",
                "correlation_id": None,
                "limit": 10,
                "continuation": None,
            }
            timeline = queries.timeline(**timeline_arguments)
            validator.validate(
                route_id="timeline-list",
                data=timeline,
                arguments=timeline_arguments,
                response_scope=self._scope("timeline-list"),
            )

    def test_tampered_response_and_journal_movement_fail_closed(
        self,
    ) -> None:
        with test_workspace("sf107-api-projection-fail-closed") as workspace:
            registry, queries, validator = self._fixture(workspace)
            arguments = {
                "project_id": "product-one",
                "status": None,
                "limit": 100,
                "continuation": None,
            }
            page = queries.list_products(**arguments)
            tampered = copy.deepcopy(page)
            tampered["items"][0]["status"] = "archived"
            tampered["items"][0]["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in tampered["items"][0].items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "exact active stored"):
                validator.validate(
                    route_id="products-list",
                    data=tampered,
                    arguments=arguments,
                    response_scope=self._scope("products-list"),
                )

            product = registry.get_by_project("product-one")
            original_snapshot = validator._snapshot

            def move_tip_after_snapshot(*args, **kwargs):
                snapshot = original_snapshot(*args, **kwargs)
                registry.pause(
                    product["product_factory"]["id"],
                    expected_version=2,
                    actor_identity_id="founder",
                    reason="Exercise post-snapshot journal movement.",
                    at="2026-08-08T08:01:00+00:00",
                )
                return snapshot

            with self.assertRaisesRegex(ProtocolError, "not current"):
                with patch.object(
                    validator,
                    "_snapshot",
                    side_effect=move_tip_after_snapshot,
                ):
                    validator.validate(
                        route_id="products-list",
                        data=page,
                        arguments=arguments,
                        response_scope=self._scope("products-list"),
                    )


if __name__ == "__main__":
    unittest.main()
