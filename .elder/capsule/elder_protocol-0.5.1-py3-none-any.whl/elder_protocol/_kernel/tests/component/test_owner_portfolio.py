from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import (
    InvalidProjectionTokenError,
    ProtocolError,
    StaleProjectionTokenError,
)
from elder_protocol.factory_operations.owner_portfolio import (
    OwnerPortfolio,
)


def aggregate(
    item_id: str,
    *,
    status: str,
    priority: str = "normal",
    dependencies: list[dict] | None = None,
) -> dict:
    return {
        "work_item": {
            "id": item_id,
            "project_id": "product-one",
            "status": status,
            "record_version": 1,
            "updated_at": "2026-08-14T06:00:00+00:00",
            "content_sha256": "a" * 64,
            "payload": {
                "objective": f"Objective for {item_id}",
                "priority": priority,
                "owner_identity_id": "identity:owner",
            },
        },
        "dependencies": dependencies or [],
    }


class OwnerPortfolioComponentTests(unittest.TestCase):
    def test_dependency_state_resolves_current_target(self) -> None:
        target = aggregate("work-item-target", status="running")
        dependent = aggregate(
            "work-item-dependent",
            status="ready",
            dependencies=[
                {
                    "work_item_id": "work-item-target",
                    "relationship": "depends-on",
                }
            ],
        )
        work = {
            item["work_item"]["id"]: item
            for item in (target, dependent)
        }
        summary = OwnerPortfolio._work_summary(dependent, work)
        self.assertEqual(summary["dependency_state"], "blocked")
        self.assertTrue(summary["dependencies"][0]["blocking"])

        completed = copy.deepcopy(target)
        completed["work_item"]["status"] = "completed"
        work["work-item-target"] = completed
        summary = OwnerPortfolio._work_summary(dependent, work)
        self.assertEqual(summary["dependency_state"], "clear")
        self.assertFalse(summary["dependencies"][0]["blocking"])

    def test_failed_and_cancelled_dependencies_are_distinct(self) -> None:
        dependent = aggregate(
            "work-item-dependent",
            status="ready",
            dependencies=[
                {
                    "work_item_id": "work-item-failed",
                    "relationship": "depends-on",
                },
                {
                    "work_item_id": "work-item-cancelled",
                    "relationship": "depends-on",
                },
            ],
        )
        work = {
            "work-item-dependent": dependent,
            "work-item-failed": aggregate(
                "work-item-failed",
                status="failed",
            ),
            "work-item-cancelled": aggregate(
                "work-item-cancelled",
                status="cancelled",
            ),
        }
        summary = OwnerPortfolio._work_summary(dependent, work)
        self.assertEqual(summary["dependency_state"], "failed")
        self.assertEqual(summary["blocking_dependency_count"], 2)

    def test_filter_and_cursor_validation(self) -> None:
        projection = {
            "generation": 1,
            "projection_sha256": "a" * 64,
            "journal": {
                "generation": 1,
                "sequence": 1,
                "entry_id": "entry-one",
            },
        }
        items = [
            {"work_item_id": "work-item-one"},
            {"work_item_id": "work-item-two"},
        ]
        from elder_protocol.factory_operations.journal import encode_page_token

        token = encode_page_token(
            {
                "version": "1.0.0",
                "projection_id": "owner-portfolio",
                "projection_generation": 1,
                "projection_sha256": "a" * 64,
                "journal_generation": 1,
                "journal_sequence": 1,
                "journal_entry_id": "entry-one",
                "method_id": "owner-portfolio-snapshot",
                "filter_sha256": "b" * 64,
                "sort_id": "owner-portfolio-board-v1",
                "page_size": 1,
                "last_sort_values": ["work-item-one"],
            }
        )
        self.assertEqual(
            OwnerPortfolio._decode_continuation(
                token,
                projection=projection,
                filter_sha256="b" * 64,
                limit=1,
                work_items=items,
            ),
            1,
        )
        with self.assertRaises(InvalidProjectionTokenError):
            OwnerPortfolio._decode_continuation(
                token,
                projection=projection,
                filter_sha256="c" * 64,
                limit=1,
                work_items=items,
            )
        stale = copy.deepcopy(projection)
        stale["journal"]["sequence"] = 2
        with self.assertRaises(StaleProjectionTokenError):
            OwnerPortfolio._decode_continuation(
                token,
                projection=stale,
                filter_sha256="b" * 64,
                limit=1,
                work_items=items,
            )

    def test_invalid_filters_fail_explicitly_before_store_access(self) -> None:
        portfolio = OwnerPortfolio.__new__(OwnerPortfolio)
        with self.assertRaisesRegex(ProtocolError, "status filter"):
            portfolio.snapshot(
                observed_at="2026-08-14T06:00:00+00:00",
                project_ids=["product-one"],
                status="unknown",
            )


if __name__ == "__main__":
    unittest.main()
