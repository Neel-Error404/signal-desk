from __future__ import annotations

from datetime import timedelta
import unittest

from elder_protocol.errors import ProtocolError
from tests._gate_e_support import restart_stack
from tests._sf402_support import (
    build_environment as build_authority_environment,
    restart_gate,
    start_submission,
)
from tests._sf404_support import DELIVERY_AT, build_environment
from tests._support import test_workspace


class GateEQualificationComponentTests(unittest.TestCase):
    def _delivery_environment(self, workspace):
        environment = build_environment(workspace, prepare=False)
        self.addCleanup(environment["authority_patcher"].stop)
        return environment

    def test_required_fail_closed_matrix_is_owner_visible(self) -> None:
        with test_workspace("gate-e-expired-authority") as workspace:
            expired = self._delivery_environment(workspace)
            expired["clock"].value = DELIVERY_AT + timedelta(minutes=10)
            view = expired["delivery_service"].prepare_packet(
                expired["delivery_request"],
                expired["delivery_sources"],
                expired["execution"],
                title="Do not deliver under expired authority",
                body="The expired authority must stop delivery.",
            )
            self.assertEqual(view["status"], "blocked")
            self.assertTrue(view["attention_required"])
            self.assertIn("expired", view["actionable_reason"].lower())
            reason = view["actionable_reason"]
            restart_stack(expired)
            durable = expired["delivery_service"].owner_view(
                expired["delivery_request"]["request_id"]
            )
            self.assertEqual(durable["status"], "blocked")
            self.assertEqual(durable["actionable_reason"], reason)

        with test_workspace("gate-e-stale-context") as workspace:
            stale = self._delivery_environment(workspace)
            stale["source"].write_text(
                "Context changed after authorization.\n",
                encoding="utf-8",
            )
            view = stale["delivery_service"].prepare_packet(
                stale["delivery_request"],
                stale["delivery_sources"],
                stale["execution"],
                title="Do not deliver stale context",
                body="Changed context must stop delivery.",
            )
            self.assertEqual(view["status"], "blocked")
            self.assertTrue(view["attention_required"])
            self.assertIn(
                "source",
                view["actionable_reason"].lower(),
            )
            reason = view["actionable_reason"]
            restart_stack(stale)
            durable = stale["delivery_service"].owner_view(
                stale["delivery_request"]["request_id"]
            )
            self.assertEqual(durable["status"], "blocked")
            self.assertEqual(durable["actionable_reason"], reason)

        with test_workspace("gate-e-missing-evidence") as workspace:
            missing = self._delivery_environment(workspace)
            missing["foundation_artifact"].unlink()
            view = missing["delivery_service"].prepare_packet(
                missing["delivery_request"],
                missing["delivery_sources"],
                missing["execution"],
                title="Do not deliver missing evidence",
                body="Missing artifact evidence must stop delivery.",
            )
            self.assertEqual(view["status"], "blocked")
            self.assertTrue(view["attention_required"])
            self.assertIn(
                "artifact",
                view["actionable_reason"].lower(),
            )
            reason = view["actionable_reason"]
            restart_stack(missing)
            durable = missing["delivery_service"].owner_view(
                missing["delivery_request"]["request_id"]
            )
            self.assertEqual(durable["status"], "blocked")
            self.assertEqual(durable["actionable_reason"], reason)

        with test_workspace("gate-e-unauthorized-transition") as workspace:
            unauthorized = build_authority_environment(workspace)
            with self.assertRaisesRegex(
                ProtocolError,
                "requester identity",
            ):
                unauthorized["gate"].start(
                    start_submission(
                        unauthorized,
                        request_id="gate-e-unauthorized-start",
                        requested_by="unassigned-requester",
                    )
                )
            owner = unauthorized["gate"].owner_view(
                unauthorized["work"]["work_item"]["id"],
                at="2026-08-14T14:05:00+00:00",
            )
            entry = owner["entries"][-1]
            self.assertEqual(entry["disposition"], "rejected")
            self.assertEqual(entry["condition"], "blocked")
            self.assertTrue(entry["attention_required"])
            self.assertIn(
                "request",
                entry["actionable_reason"].lower(),
            )
            restarted = restart_gate(unauthorized)
            durable = restarted.owner_view(
                unauthorized["work"]["work_item"]["id"],
                at="2026-08-14T14:05:00+00:00",
            )["entries"][-1]
            self.assertEqual(durable, entry)


if __name__ == "__main__":
    unittest.main()
