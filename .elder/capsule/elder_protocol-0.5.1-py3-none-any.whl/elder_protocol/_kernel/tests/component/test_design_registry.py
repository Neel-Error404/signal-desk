from __future__ import annotations

import json
import unittest

from elder_protocol.constants import PROTOCOL_VERSION
from elder_protocol.design import validate_design_registry
from elder_protocol.errors import ProtocolError
from elder_protocol.io import sha256_file
from tests._support import test_workspace


class DesignRegistryComponentTests(unittest.TestCase):
    def test_registry_detects_stale_design_document_hash(self) -> None:
        with test_workspace("design-registry") as workspace:
            document = workspace / "docs" / "adr" / "0001-example.md"
            document.parent.mkdir(parents=True)
            document.write_text(
                "# ADR 0001: Example\n\n## Status\n\nAccepted.\n",
                encoding="utf-8",
            )
            registry = workspace / "protocol" / "design-registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "documents": [
                            {
                                "id": "ADR-0001",
                                "title": "Example",
                                "path": "docs/adr/0001-example.md",
                                "kind": "adr",
                                "status": "accepted",
                                "owners": ["architecture"],
                                "change_classes": ["constitution"],
                                "supersedes": [],
                                "notifies": ["architecture"],
                                "content_sha256": sha256_file(document),
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )

            report = validate_design_registry(registry, workspace)
            self.assertEqual(report["document_count"], 1)
            self.assertEqual(report["stale"], [])

            document.write_text("# ADR 0001: Changed\n", encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "content hash"):
                validate_design_registry(registry, workspace)

    def test_registry_rejects_unknown_superseded_document(self) -> None:
        with test_workspace("design-supersedes") as workspace:
            document = workspace / "design.md"
            document.write_text("# Design\n", encoding="utf-8")
            registry = workspace / "registry.json"
            registry.write_text(
                json.dumps(
                    {
                        "version": PROTOCOL_VERSION,
                        "documents": [
                            {
                                "id": "RFC-001",
                                "title": "Design",
                                "path": "design.md",
                                "kind": "rfc",
                                "status": "proposed",
                                "owners": ["architecture"],
                                "change_classes": ["internal-code"],
                                "supersedes": ["RFC-999"],
                                "notifies": ["product"],
                                "content_sha256": sha256_file(document),
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ProtocolError, "unknown document"):
                validate_design_registry(registry, workspace)


if __name__ == "__main__":
    unittest.main()
