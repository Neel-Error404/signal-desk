from __future__ import annotations

import json
import unittest

from elder_protocol.constants import PROTOCOL_DIR, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.eval_harness import (
    calibrate_judge,
    compare_evaluations,
    run_evaluation,
    validate_evaluation_registry,
)
from elder_protocol.io import json_text
from tests._support import test_workspace


class EvaluationHarnessComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.dataset = PROTOCOL_DIR / "evaluation-dataset.json"
        self.contract = PROTOCOL_DIR / "evaluator-contract.json"
        self.calibration_results = (
            ROOT / "examples" / "eval-calibration-judge-results.json"
        )

    def _calibration(self, workspace):
        report = calibrate_judge(
            self.dataset,
            self.calibration_results,
            self.contract,
        )
        path = workspace / "calibration.json"
        path.write_text(json_text(report), encoding="utf-8")
        return report, path

    def test_registry_and_calibrated_judge_are_valid(self) -> None:
        registry = validate_evaluation_registry(
            PROTOCOL_DIR / "evaluation-registry.json",
            ROOT,
        )
        self.assertEqual(registry["dataset_count"], 1)
        with test_workspace("judge-calibration") as workspace:
            report, _ = self._calibration(workspace)
            self.assertTrue(report["qualified"])
            self.assertEqual(report["metrics"]["accuracy"], 1.0)
            self.assertEqual(report["metrics"]["f1"], 1.0)
            self.assertFalse(report["can_approve"])

    def test_holdout_evaluation_requires_independence_and_calibration(self) -> None:
        with test_workspace("eval-separation") as workspace:
            _, calibration = self._calibration(workspace)
            with self.assertRaisesRegex(ProtocolError, "independent"):
                run_evaluation(
                    self.dataset,
                    ROOT / "examples" / "eval-candidate.json",
                    self.contract,
                    split="holdout",
                    evaluator_id="workbench-executor",
                    judge_results_path=(
                        ROOT / "examples" / "eval-candidate-judge-results.json"
                    ),
                    calibration_path=calibration,
                )
            with self.assertRaisesRegex(ProtocolError, "calibration"):
                run_evaluation(
                    self.dataset,
                    ROOT / "examples" / "eval-candidate.json",
                    self.contract,
                    split="holdout",
                    evaluator_id="independent-evaluator",
                    judge_results_path=(
                        ROOT / "examples" / "eval-candidate-judge-results.json"
                    ),
                )

    def test_candidate_passes_and_improves_over_baseline(self) -> None:
        with test_workspace("eval-compare") as workspace:
            _, calibration = self._calibration(workspace)
            baseline = run_evaluation(
                self.dataset,
                ROOT / "examples" / "eval-baseline-candidate.json",
                self.contract,
                split="holdout",
                evaluator_id="independent-evaluator",
                judge_results_path=(
                    ROOT / "examples" / "eval-baseline-judge-results.json"
                ),
                calibration_path=calibration,
            )
            candidate = run_evaluation(
                self.dataset,
                ROOT / "examples" / "eval-candidate.json",
                self.contract,
                split="holdout",
                evaluator_id="independent-evaluator",
                judge_results_path=(
                    ROOT / "examples" / "eval-candidate-judge-results.json"
                ),
                calibration_path=calibration,
            )
            self.assertEqual(baseline["verdict"], "fail")
            self.assertEqual(candidate["verdict"], "pass")
            baseline_path = workspace / "baseline.json"
            candidate_path = workspace / "candidate.json"
            baseline_path.write_text(json_text(baseline), encoding="utf-8")
            candidate_path.write_text(json_text(candidate), encoding="utf-8")
            comparison = compare_evaluations(
                baseline_path,
                candidate_path,
                self.contract,
            )
            self.assertEqual(comparison["verdict"], "candidate-better")
            self.assertEqual(comparison["metrics"]["wins"], 4)
            self.assertFalse(comparison["can_promote"])

    def test_comparison_rejects_elevated_report_authority(self) -> None:
        with test_workspace("eval-compare-authority") as workspace:
            _, calibration = self._calibration(workspace)
            baseline = run_evaluation(
                self.dataset,
                ROOT / "examples" / "eval-baseline-candidate.json",
                self.contract,
                split="holdout",
                evaluator_id="independent-evaluator",
                judge_results_path=(
                    ROOT / "examples" / "eval-baseline-judge-results.json"
                ),
                calibration_path=calibration,
            )
            candidate = run_evaluation(
                self.dataset,
                ROOT / "examples" / "eval-candidate.json",
                self.contract,
                split="holdout",
                evaluator_id="independent-evaluator",
                judge_results_path=(
                    ROOT / "examples" / "eval-candidate-judge-results.json"
                ),
                calibration_path=calibration,
            )
            baseline["can_promote"] = True
            baseline_path = workspace / "baseline.json"
            candidate_path = workspace / "candidate.json"
            baseline_path.write_text(json_text(baseline), encoding="utf-8")
            candidate_path.write_text(json_text(candidate), encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "advisory-only"):
                compare_evaluations(
                    baseline_path,
                    candidate_path,
                    self.contract,
                )

    def test_registry_detects_dataset_drift(self) -> None:
        with test_workspace("eval-registry-drift") as workspace:
            dataset = json.loads(self.dataset.read_text(encoding="utf-8"))
            dataset["title"] = "Changed without registry update"
            dataset_path = workspace / "dataset.json"
            dataset_path.write_text(json.dumps(dataset), encoding="utf-8")
            registry = {
                "version": dataset["version"],
                "datasets": [
                    {
                        "id": dataset["id"],
                        "path": "dataset.json",
                        "owner": "architecture",
                        "status": "active",
                        "content_sha256": "0" * 64,
                        "notifies": ["architecture"],
                    }
                ],
            }
            registry_path = workspace / "registry.json"
            registry_path.write_text(json.dumps(registry), encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "stale"):
                validate_evaluation_registry(registry_path, workspace)

    def test_holdout_rejects_calibration_bound_to_another_contract(self) -> None:
        with test_workspace("eval-contract-drift") as workspace:
            report, _ = self._calibration(workspace)
            report["contract_sha256"] = "0" * 64
            calibration_path = workspace / "calibration.json"
            calibration_path.write_text(json_text(report), encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "contract revision"):
                run_evaluation(
                    self.dataset,
                    ROOT / "examples" / "eval-candidate.json",
                    self.contract,
                    split="holdout",
                    evaluator_id="independent-evaluator",
                    judge_results_path=(
                        ROOT / "examples" / "eval-candidate-judge-results.json"
                    ),
                    calibration_path=calibration_path,
                )

    def test_holdout_rejects_tampered_calibration_authority_and_metrics(self) -> None:
        with test_workspace("eval-calibration-tamper") as workspace:
            report, _ = self._calibration(workspace)
            report["can_promote"] = True
            calibration_path = workspace / "authority.json"
            calibration_path.write_text(json_text(report), encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "advisory-only"):
                run_evaluation(
                    self.dataset,
                    ROOT / "examples" / "eval-candidate.json",
                    self.contract,
                    split="holdout",
                    evaluator_id="independent-evaluator",
                    judge_results_path=(
                        ROOT / "examples" / "eval-candidate-judge-results.json"
                    ),
                    calibration_path=calibration_path,
                )

            report, _ = self._calibration(workspace)
            report["metrics"]["f1"] = 0.0
            calibration_path = workspace / "metrics.json"
            calibration_path.write_text(json_text(report), encoding="utf-8")
            with self.assertRaisesRegex(ProtocolError, "inconsistent"):
                run_evaluation(
                    self.dataset,
                    ROOT / "examples" / "eval-candidate.json",
                    self.contract,
                    split="holdout",
                    evaluator_id="independent-evaluator",
                    judge_results_path=(
                        ROOT / "examples" / "eval-candidate-judge-results.json"
                    ),
                    calibration_path=calibration_path,
                )


if __name__ == "__main__":
    unittest.main()
