from __future__ import annotations

import copy
import hashlib
import unittest

from elder_protocol.constants import PROTOCOL_VERSION, ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from elder_protocol.learning import (
    LearningRuntime,
    finalize_learning_artifact,
)
from elder_protocol.protocol import validate_protocol
from tests._support import test_workspace


CREATED_AT = "2026-08-05T18:00:00+05:30"
EXPIRES_AT = "2026-08-12T18:00:00+05:30"


def digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def candidate_record(
    artifact_sha256: str,
    *,
    kind: str = "memory",
    candidate_id: str = "LC-001",
    project_id: str = "example-agentic-product",
    created_by: str = "example-agentic-product-learning-agent",
) -> dict:
    return finalize_learning_artifact(
        {
            "version": PROTOCOL_VERSION,
            "id": candidate_id,
            "project_id": project_id,
            "kind": kind,
            "target_ref": f"{kind}:elder-test-target",
            "artifact_path": "candidate.md",
            "artifact_sha256": artifact_sha256,
            "hypothesis": "The candidate improves the governed result without regressions.",
            "source_evidence": ["trace:baseline", "outcome:baseline"],
            "counterexamples": ["A result with lower quality or a critical regression."],
            "created_by": created_by,
            "created_role": "learning-agent",
            "status": "candidate",
            "created_at": CREATED_AT,
            "expires_at": EXPIRES_AT,
        }
    )


def observation_record(
    candidate_id: str,
    *,
    observation_id: str,
    mode: str,
    outcomes: tuple[str, str] = ("better", "equivalent"),
    critical: bool = False,
    executor_id: str = "example-agentic-product-learning-agent",
) -> dict:
    environment = "quarantine" if mode == "counterfactual-replay" else "shadow"
    cases = []
    for index, outcome in enumerate(outcomes, start=1):
        cases.append(
            {
                "id": f"{observation_id}-case-{index}",
                "input_sha256": digest(f"{mode}-input-{index}"),
                "baseline_output_sha256": digest(f"{mode}-baseline-{index}"),
                "candidate_output_sha256": digest(f"{mode}-candidate-{index}"),
                "outcome": outcome,
                "critical_regression": critical and index == 1,
                "metrics": {
                    "quality_delta": 0.2 if outcome == "better" else 0.0,
                    "cost_delta_usd": -0.01,
                    "latency_delta_ms": -5.0,
                    "tool_call_delta": -1,
                },
                "evidence": [f"evidence:{observation_id}:{index}"],
            }
        )
    return finalize_learning_artifact(
        {
            "version": PROTOCOL_VERSION,
            "id": observation_id,
            "candidate_id": candidate_id,
            "mode": mode,
            "executor_id": executor_id,
            "environment": environment,
            "side_effects": False,
            "cases": cases,
            "started_at": "2026-08-05T18:10:00+05:30",
            "completed_at": "2026-08-05T18:11:00+05:30",
        }
    )


def approval_record(
    candidate: dict,
    evaluation: dict,
    *,
    approval_id: str,
    role: str,
    approved_by: str,
    decision: str = "approve",
) -> dict:
    return finalize_learning_artifact(
        {
            "version": PROTOCOL_VERSION,
            "id": approval_id,
            "candidate_id": candidate["id"],
            "candidate_sha256": candidate["content_sha256"],
            "evaluation_id": evaluation["id"],
            "evaluation_sha256": evaluation["content_sha256"],
            "decision": decision,
            "approved_by": approved_by,
            "approver_role": role,
            "evidence": [f"review:{approval_id}"],
            "decided_at": "2026-08-05T18:30:00+05:30",
        }
    )


class P46LearningComponentTests(unittest.TestCase):
    def _runtime(self, workspace, *, kind: str = "memory"):
        artifact = workspace / "candidate.md"
        artifact.write_text("Candidate governed learning artifact.", encoding="utf-8")
        protocol = validate_protocol()
        runtime = LearningRuntime(
            workspace / "learning.db",
            load_json(ROOT / "protocol" / "learning-policy.json"),
            profile=load_json(ROOT / "examples" / "minimal-project-profile.json"),
            role_registry=protocol["role-registry"],
            authority_matrix=protocol["authority-matrix"],
        )
        runtime.initialize()
        candidate = candidate_record(
            hashlib.sha256(artifact.read_bytes()).hexdigest(),
            kind=kind,
        )
        runtime.propose(candidate, artifact_base=workspace)
        return runtime, candidate

    def _qualify(self, runtime: LearningRuntime, candidate_id: str) -> dict:
        runtime.observe(
            observation_record(
                candidate_id,
                observation_id="OBS-REPLAY",
                mode="counterfactual-replay",
            )
        )
        runtime.observe(
            observation_record(
                candidate_id,
                observation_id="OBS-SHADOW",
                mode="shadow",
            )
        )
        return runtime.evaluate(
            candidate_id,
            evaluator_id="example-agentic-product-evaluator",
            evaluation_id="EVAL-001",
            evaluated_at="2026-08-05T18:20:00+05:30",
        )

    def test_candidate_replay_shadow_approval_promotion_and_replay(self) -> None:
        with test_workspace("p4-6-lifecycle") as workspace:
            runtime, candidate = self._runtime(workspace)
            evaluation = self._qualify(runtime, candidate["id"])
            self.assertEqual(evaluation["verdict"], "qualified")

            current = runtime.snapshot(candidate["id"])["candidate"]
            approval = approval_record(
                current,
                evaluation,
                approval_id="APP-001",
                role="human-owner",
                approved_by="founder",
            )
            runtime.decide(approval)
            self.assertEqual(
                runtime.snapshot(candidate["id"])["candidate"]["status"],
                "approved",
            )

            packet = runtime.promote(
                candidate["id"],
                promoted_by="release-owner",
                promotion_id="PROM-001",
                created_at="2026-08-05T18:40:00+05:30",
            )
            self.assertEqual(packet["status"], "promoted")
            self.assertFalse(packet["applies_target_mutation"])
            replay = runtime.verify_replay(candidate["id"])
            self.assertEqual(replay["status"], "passed")
            self.assertEqual(replay["candidate_status"], "promoted")

            promoted = runtime.snapshot(candidate["id"])["candidate"]
            rollback = approval_record(
                promoted,
                evaluation,
                approval_id="APP-ROLLBACK",
                role="human-owner",
                approved_by="founder",
                decision="rollback",
            )
            runtime.decide(rollback)
            rollback_packet = runtime.rollback(
                candidate["id"],
                promoted_by="release-owner",
                promotion_id="ROLLBACK-001",
                created_at="2026-08-05T18:50:00+05:30",
            )
            self.assertEqual(rollback_packet["status"], "rolled-back")
            self.assertFalse(rollback_packet["applies_target_mutation"])
            self.assertEqual(
                runtime.verify_replay(candidate["id"])["candidate_status"],
                "rolled-back",
            )

    def test_side_effects_authority_forgery_and_artifact_drift_fail_closed(self) -> None:
        with test_workspace("p4-6-boundaries") as workspace:
            runtime, candidate = self._runtime(workspace)
            observation = observation_record(
                candidate["id"],
                observation_id="OBS-SIDE-EFFECT",
                mode="counterfactual-replay",
            )
            observation["side_effects"] = True
            observation = finalize_learning_artifact(observation)
            with self.assertRaisesRegex(ProtocolError, "side effects"):
                runtime.observe(observation)

            runtime.observe(
                observation_record(
                    candidate["id"],
                    observation_id="OBS-REPLAY",
                    mode="counterfactual-replay",
                )
            )
            with self.assertRaisesRegex(ProtocolError, "resolved project authority"):
                runtime.evaluate(
                    candidate["id"],
                    evaluator_id="example-agentic-product-learning-agent",
                )

        with test_workspace("p4-6-artifact-drift") as workspace:
            artifact = workspace / "candidate.md"
            artifact.write_text("Original.", encoding="utf-8")
            candidate = candidate_record(
                hashlib.sha256(artifact.read_bytes()).hexdigest()
            )
            artifact.write_text("Mutated.", encoding="utf-8")
            protocol = validate_protocol()
            runtime = LearningRuntime(
                workspace / "learning.db",
                load_json(ROOT / "protocol" / "learning-policy.json"),
                profile=load_json(ROOT / "examples" / "minimal-project-profile.json"),
                role_registry=protocol["role-registry"],
                authority_matrix=protocol["authority-matrix"],
            )
            runtime.initialize()
            with self.assertRaisesRegex(ProtocolError, "artifact_sha256"):
                runtime.propose(candidate, artifact_base=workspace)

    def test_missing_shadow_and_critical_regression_do_not_qualify(self) -> None:
        with test_workspace("p4-6-missing-shadow") as workspace:
            runtime, candidate = self._runtime(workspace)
            runtime.observe(
                observation_record(
                    candidate["id"],
                    observation_id="OBS-REPLAY",
                    mode="counterfactual-replay",
                )
            )
            evaluation = runtime.evaluate(
                candidate["id"],
                evaluator_id="example-agentic-product-evaluator",
                evaluation_id="EVAL-MISSING",
                evaluated_at="2026-08-05T18:20:00+05:30",
            )
            self.assertEqual(evaluation["verdict"], "needs-more-evidence")
            current = runtime.snapshot(candidate["id"])["candidate"]
            approval = approval_record(
                current,
                evaluation,
                approval_id="APP-MISSING",
                role="human-owner",
                approved_by="founder",
            )
            with self.assertRaisesRegex(ProtocolError, "qualified"):
                runtime.decide(approval)

        with test_workspace("p4-6-critical") as workspace:
            runtime, candidate = self._runtime(workspace)
            runtime.observe(
                observation_record(
                    candidate["id"],
                    observation_id="OBS-REPLAY",
                    mode="counterfactual-replay",
                )
            )
            runtime.observe(
                observation_record(
                    candidate["id"],
                    observation_id="OBS-SHADOW",
                    mode="shadow",
                    outcomes=("worse", "equivalent"),
                    critical=True,
                )
            )
            evaluation = runtime.evaluate(
                candidate["id"],
                evaluator_id="example-agentic-product-evaluator",
                evaluation_id="EVAL-CRITICAL",
                evaluated_at="2026-08-05T18:20:00+05:30",
            )
            self.assertEqual(evaluation["verdict"], "rejected")
            self.assertEqual(
                evaluation["metrics"]["critical_regression_count"],
                1,
            )

    def test_policy_candidate_requires_all_roles_and_separate_promoter(self) -> None:
        with test_workspace("p4-6-policy-approval") as workspace:
            runtime, candidate = self._runtime(workspace, kind="policy")
            evaluation = self._qualify(runtime, candidate["id"])
            current = runtime.snapshot(candidate["id"])["candidate"]
            forged = approval_record(
                current,
                evaluation,
                approval_id="APP-FORGED",
                role="human-owner",
                approved_by="forged-owner",
            )
            with self.assertRaisesRegex(ProtocolError, "resolved project authority"):
                runtime.decide(forged)
            first = approval_record(
                current,
                evaluation,
                approval_id="APP-HUMAN",
                role="human-owner",
                approved_by="founder",
            )
            runtime.decide(first)
            self.assertEqual(
                runtime.snapshot(candidate["id"])["candidate"]["status"],
                "shadow",
            )
            with self.assertRaisesRegex(ProtocolError, "approved"):
                runtime.promote(candidate["id"], promoted_by="release-owner")

            current = runtime.snapshot(candidate["id"])["candidate"]
            second = approval_record(
                current,
                evaluation,
                approval_id="APP-ARCH",
                role="architecture-owner",
                approved_by="technical-owner",
            )
            runtime.decide(second)
            with self.assertRaisesRegex(ProtocolError, "resolved project authority"):
                runtime.promote(
                    candidate["id"],
                    promoted_by="technical-owner",
                )
            packet = runtime.promote(
                candidate["id"],
                promoted_by="release-owner",
                promotion_id="PROM-POLICY",
                created_at="2026-08-05T18:40:00+05:30",
            )
            self.assertEqual(len(packet["approval_ids"]), 2)

    def test_store_and_candidate_bind_project_authority(self) -> None:
        with test_workspace("p4-6-project-authority") as workspace:
            runtime, candidate = self._runtime(workspace)
            protocol = validate_protocol()
            mismatched = LearningRuntime(
                runtime.path,
                load_json(ROOT / "protocol" / "learning-policy.json"),
                profile=load_json(
                    ROOT / "reference_projects" / "elder-workbench.profile.json"
                ),
                role_registry=protocol["role-registry"],
                authority_matrix=protocol["authority-matrix"],
            )
            with self.assertRaisesRegex(ProtocolError, "metadata"):
                mismatched.status()

            wrong_project = candidate_record(
                candidate["artifact_sha256"],
                candidate_id="LC-WRONG-PROJECT",
                project_id="other-project",
            )
            with self.assertRaisesRegex(ProtocolError, "project"):
                runtime.propose(wrong_project, artifact_base=workspace)

            forged_creator = candidate_record(
                candidate["artifact_sha256"],
                candidate_id="LC-FORGED-CREATOR",
                created_by="forged-owner",
            )
            with self.assertRaisesRegex(ProtocolError, "resolved project authority"):
                runtime.propose(forged_creator, artifact_base=workspace)


if __name__ == "__main__":
    unittest.main()
