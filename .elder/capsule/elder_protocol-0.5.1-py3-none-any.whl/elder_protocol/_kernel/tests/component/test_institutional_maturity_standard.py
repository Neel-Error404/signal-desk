from __future__ import annotations

import copy
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.protocol import (
    _validate_operational_maturity,
    protocol_data,
)


class InstitutionalMaturityStandardComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.maturity = protocol_data()["operational-maturity"]

    def test_changed_l2_threshold_fails_closed(self) -> None:
        changed = copy.deepcopy(self.maturity)
        metrics = changed["institutional_standard"]["benchmarks"]["L2"][
            "metrics"
        ]
        next(
            metric
            for metric in metrics
            if metric["id"] == "real-hosted-work-items"
        )["value"] = 19

        with self.assertRaisesRegex(
            ProtocolError,
            "metrics differ from the ratified standard",
        ):
            _validate_operational_maturity(changed)

    def test_weakened_l3_authority_boundary_fails_closed(self) -> None:
        changed = copy.deepcopy(self.maturity)
        prohibited = changed["institutional_standard"]["benchmarks"]["L3"][
            "prohibited_consequences"
        ]
        prohibited.remove("automatic-full-rollout")

        with self.assertRaisesRegex(
            ProtocolError,
            "weakens its authority boundary",
        ):
            _validate_operational_maturity(changed)

    def test_disabled_evidence_rule_fails_closed(self) -> None:
        changed = copy.deepcopy(self.maturity)
        changed["institutional_standard"]["evidence_rules"][
            "human_ratification"
        ] = False

        with self.assertRaisesRegex(
            ProtocolError,
            "evidence rule must remain enabled",
        ):
            _validate_operational_maturity(changed)

    def test_complete_standard_payload_is_version_pinned(self) -> None:
        mutations = {
            "l2-target-operating-model": lambda standard: standard[
                "benchmarks"
            ]["L2"].__setitem__(
                "target_operating_model",
                "Changed operating model.",
            ),
            "l2-required-control": lambda standard: standard["benchmarks"][
                "L2"
            ]["required_controls"].append("changed-control"),
            "l3-required-exercise": lambda standard: standard["benchmarks"][
                "L3"
            ]["required_exercises"].append("changed-exercise"),
            "dimension-question": lambda standard: standard["dimensions"][
                0
            ].__setitem__("question", "Changed question?"),
            "effective-date": lambda standard: standard.__setitem__(
                "effective_date",
                "2026-08-15",
            ),
        }
        for label, mutate in mutations.items():
            with self.subTest(label=label):
                changed = copy.deepcopy(self.maturity)
                standard = changed["institutional_standard"]
                mutate(standard)
                standard["content_sha256"] = canonical_sha256(
                    {
                        key: value
                        for key, value in standard.items()
                        if key != "content_sha256"
                    }
                )

                with self.assertRaisesRegex(
                    ProtocolError,
                    "payload differs from ratified version",
                ):
                    _validate_operational_maturity(changed)


if __name__ == "__main__":
    unittest.main()
