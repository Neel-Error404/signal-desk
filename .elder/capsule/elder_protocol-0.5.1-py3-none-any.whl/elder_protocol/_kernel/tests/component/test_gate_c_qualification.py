from __future__ import annotations

import copy
import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    finalize_gate_c_record,
    validate_gate_c_qualification_packet,
)
from tests.foundation.test_gate_c_qualification_contract import (
    qualification_packet,
)


class GateCQualificationComponentTests(unittest.TestCase):
    def _reject(self, packet: dict, message: str) -> None:
        with self.assertRaisesRegex(ProtocolError, message):
            validate_gate_c_qualification_packet(finalize_gate_c_record(packet))

    def test_passing_packet_requires_terminal_evidence_chain(self) -> None:
        packet = qualification_packet()
        packet["run"]["status"] = "failed"
        self._reject(packet, "completed run")

        packet = qualification_packet()
        packet["work_item"]["status"] = "cancelled"
        self._reject(packet, "completed work item")

        packet = qualification_packet()
        packet["evidence_bundle"]["status"] = "rejected"
        self._reject(packet, "verified worker evidence bundle")

    def test_passing_packet_rejects_failed_test_or_git_side_effect(self) -> None:
        packet = qualification_packet()
        packet["test"]["exit_code"] = 1
        self._reject(packet, "passing declared test")

        packet = qualification_packet()
        packet["git"]["staged"] = True
        self._reject(packet, "unstaged and uncommitted worker change")

        packet = qualification_packet()
        packet["git"]["committed"] = True
        self._reject(packet, "unstaged and uncommitted worker change")

    def test_passing_packet_rejects_recovery_or_orphan_debt(self) -> None:
        packet = qualification_packet()
        packet["recovery"]["open_case_count"] = 1
        self._reject(packet, "no open recovery case")

        packet = qualification_packet()
        packet["recovery"]["orphan_count"] = 1
        self._reject(packet, "no orphan finding")

    def test_failed_packet_retains_evidence_without_passing_claim(self) -> None:
        packet = qualification_packet(live_codex=False)
        packet["verdict"] = "fail"
        packet["test"]["exit_code"] = 1
        packet["worker"]["prompt_effect_count"] = 0
        validate_gate_c_qualification_packet(finalize_gate_c_record(packet))


if __name__ == "__main__":
    unittest.main()
