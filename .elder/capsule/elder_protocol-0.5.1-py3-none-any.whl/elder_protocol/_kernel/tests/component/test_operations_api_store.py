from __future__ import annotations

import sqlite3
import unittest
from datetime import datetime, timedelta, timezone

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.api_idempotency import (
    ApiIdempotencyStore,
)
from elder_protocol.factory_operations.api_store import (
    OperationsApiStore,
    validate_runtime_fence,
)
from elder_protocol.factory_operations.operations_store import (
    operations_connection,
)
from tests._support import tamper_sqlite_store, test_workspace


ROUTE_SHA256 = "1" * 64
BINDING_SHA256 = "2" * 64
AUTH_SHA256 = "3" * 64
REQUEST_SHA256 = "4" * 64
SCOPE_SHA256 = "5" * 64
RESULT_SHA256 = "6" * 64
BOOT_ONE = "operations-api-boot-" + "1" * 32
BOOT_TWO = "operations-api-boot-" + "2" * 32
BASE = datetime(2026, 8, 11, 12, 0, tzinfo=timezone.utc)


def _at(seconds: int) -> str:
    return (BASE + timedelta(seconds=seconds)).isoformat()


class OperationsApiStoreComponentTests(unittest.TestCase):
    def _stores(self, workspace):
        path = workspace / "operations.db"
        api = OperationsApiStore(path)
        api.initialize(
            route_registry_sha256=ROUTE_SHA256,
            binding_registry_sha256=BINDING_SHA256,
            auth_policy_sha256=AUTH_SHA256,
            at=_at(0),
        )
        idempotency = ApiIdempotencyStore(path)
        return api, idempotency

    @staticmethod
    def _claim_ready(
        api: OperationsApiStore,
        *,
        boot_id: str = BOOT_ONE,
        claim_second: int = 0,
        ready_second: int = 1,
    ) -> dict:
        claimed = api.claim_runtime(
            boot_id=boot_id,
            process_id=101,
            host_id="host-foundation",
            route_registry_sha256=ROUTE_SHA256,
            binding_registry_sha256=BINDING_SHA256,
            auth_policy_sha256=AUTH_SHA256,
            at=_at(claim_second),
        )
        return api.mark_ready(
            boot_id=boot_id,
            runtime_generation=claimed["runtime_generation"],
            at=_at(ready_second),
        )

    @staticmethod
    def _scope(key: str = "request-key-001") -> dict:
        return {
            "route_id": "product-update",
            "client_id": "owner-client",
            "project_id": "product-one",
            "idempotency_key": key,
            "request_sha256": REQUEST_SHA256,
            "mutation_scope_sha256": SCOPE_SHA256,
        }

    def test_initializes_non_journal_tables_and_reports_integrity(self) -> None:
        with test_workspace("sf-107-api-store-init") as workspace:
            api, idempotency = self._stores(workspace)
            status = api.status(at=_at(0))
            self.assertEqual(status["integrity"], "ok")
            self.assertFalse(status["runtime_present"])
            self.assertFalse(status["mutation_ready"])
            self.assertEqual(idempotency.status()["record_count"], 0)

            connection = sqlite3.connect(api.path)
            try:
                tables = {
                    row[0]
                    for row in connection.execute(
                        """
                        SELECT name FROM sqlite_master
                        WHERE type = 'table'
                          AND name LIKE 'factory_operations_api_%'
                        """
                    )
                }
                self.assertEqual(
                    tables,
                    {
                        "factory_operations_api_metadata",
                        "factory_operations_api_runtime",
                        "factory_operations_api_idempotency",
                    },
                )
                journal_sources = connection.execute(
                    """
                    SELECT COUNT(*) FROM sqlite_master
                    WHERE type = 'trigger'
                      AND name LIKE
                          'factory_journal_capture_factory_operations_api_%'
                    """
                ).fetchone()[0]
                self.assertEqual(journal_sources, 0)
            finally:
                connection.close()

    def test_runtime_lease_generation_and_shutdown_are_fail_closed(self) -> None:
        with test_workspace("sf-107-api-runtime") as workspace:
            api, _ = self._stores(workspace)
            ready = self._claim_ready(api)
            self.assertEqual(ready["status"], "ready")
            self.assertEqual(ready["runtime_generation"], 1)
            self.assertEqual(
                api.runtime_fence(),
                {
                    "boot_id": BOOT_ONE,
                    "runtime_generation": 1,
                },
            )
            with operations_connection(api.path) as connection:
                with self.assertRaisesRegex(
                    ProtocolError,
                    "active transaction",
                ):
                    validate_runtime_fence(
                        connection,
                        runtime_fence=api.runtime_fence(),
                        at=_at(1),
                    )
                connection.execute("BEGIN IMMEDIATE")
                validated = validate_runtime_fence(
                    connection,
                    runtime_fence=api.runtime_fence(),
                    at=_at(1),
                )
                self.assertEqual(validated["status"], "ready")
                connection.rollback()
            self.assertEqual(
                datetime.fromisoformat(ready["lease_expires_at"])
                - datetime.fromisoformat(ready["heartbeat_at"]),
                timedelta(seconds=5),
            )

            with self.assertRaisesRegex(ProtocolError, "another boot"):
                api.claim_runtime(
                    boot_id=BOOT_TWO,
                    process_id=202,
                    host_id="host-two",
                    route_registry_sha256=ROUTE_SHA256,
                    binding_registry_sha256=BINDING_SHA256,
                    auth_policy_sha256=AUTH_SHA256,
                    at=_at(2),
                )

            heartbeat = api.heartbeat(
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(2),
            )
            self.assertEqual(heartbeat["lease_expires_at"], _at(7))
            with self.assertRaisesRegex(ProtocolError, "predates|regress"):
                api.heartbeat(
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    at=_at(1),
                )
            with self.assertRaisesRegex(ProtocolError, "process or host"):
                api.claim_runtime(
                    boot_id=BOOT_ONE,
                    process_id=999,
                    host_id="host-foundation",
                    route_registry_sha256=ROUTE_SHA256,
                    binding_registry_sha256=BINDING_SHA256,
                    auth_policy_sha256=AUTH_SHA256,
                    at=_at(2),
                )
            draining = api.begin_drain(
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(3),
            )
            self.assertEqual(draining["status"], "draining")
            stopped = api.stop_runtime(
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(4),
            )
            self.assertEqual(stopped["status"], "stopped")
            self.assertEqual(stopped["lease_expires_at"], _at(4))

            second = api.claim_runtime(
                boot_id=BOOT_TWO,
                process_id=202,
                host_id="host-two",
                route_registry_sha256=ROUTE_SHA256,
                binding_registry_sha256=BINDING_SHA256,
                auth_policy_sha256=AUTH_SHA256,
                at=_at(5),
            )
            self.assertEqual(second["runtime_generation"], 2)
            with self.assertRaisesRegex(ProtocolError, "generation or boot"):
                api.heartbeat(
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    at=_at(5),
                )

    def test_completed_idempotency_replays_exact_stored_response(self) -> None:
        with test_workspace("sf-107-api-idempotency-complete") as workspace:
            api, idempotency = self._stores(workspace)
            ready = self._claim_ready(api)
            scope = self._scope()
            accepted = idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=ready["runtime_generation"],
                at=_at(1),
            )
            self.assertEqual(accepted["disposition"], "accepted")
            in_progress = idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(1),
            )
            self.assertEqual(in_progress["disposition"], "in-progress")
            self.assertEqual(in_progress["response_status"], 202)

            executing = idempotency.begin_execution(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(2),
            )
            self.assertEqual(executing["status"], "executing")
            response = {
                "version": "1.0.0",
                "status": "ok",
                "data": {"factory_id": "factory-one", "record_version": 2},
            }
            completed = idempotency.complete(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                response_status=200,
                response=response,
                result_proof_sha256=RESULT_SHA256,
                at=_at(3),
            )
            self.assertEqual(completed["record"]["status"], "completed")

            replay = idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(3),
            )
            self.assertEqual(replay["disposition"], "replay")
            self.assertEqual(replay["response_status"], 200)
            self.assertEqual(replay["response"], response)
            self.assertEqual(
                replay["response_body"],
                '{"data":{"factory_id":"factory-one","record_version":2},'
                '"status":"ok","version":"1.0.0"}',
            )
            self.assertTrue(replay["idempotent_replay"])

            tamper_sqlite_store(
                api.path,
                """
                UPDATE factory_operations_api_idempotency
                SET response_json = ?
                WHERE route_id = ? AND client_id = ?
                  AND project_id = ? AND idempotency_key = ?
                """,
                (
                    '{"data": {"factory_id": "factory-one", '
                    '"record_version": 2}, "status": "ok", '
                    '"version": "1.0.0"}',
                    scope["route_id"],
                    scope["client_id"],
                    scope["project_id"],
                    scope["idempotency_key"],
                ),
            )
            with self.assertRaisesRegex(ProtocolError, "canonical JSON"):
                idempotency.get(
                    route_id=scope["route_id"],
                    client_id=scope["client_id"],
                    project_id=scope["project_id"],
                    idempotency_key=scope["idempotency_key"],
                )

    def test_changed_key_and_unresolved_global_admission_are_blocked(self) -> None:
        with test_workspace("sf-107-api-idempotency-block") as workspace:
            api, idempotency = self._stores(workspace)
            self._claim_ready(api)
            scope = self._scope()
            idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(2),
            )
            changed = {**scope, "request_sha256": "7" * 64}
            with self.assertRaisesRegex(ProtocolError, "collision"):
                idempotency.accept(
                    **changed,
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    at=_at(2),
                )
            with self.assertRaisesRegex(ProtocolError, "blocked"):
                idempotency.accept(
                    **self._scope("request-key-002"),
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    at=_at(2),
                )
            with self.assertRaisesRegex(ProtocolError, "cannot regress"):
                idempotency.begin_execution(
                    **scope,
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    at=_at(1),
                )

    def test_retryable_non_application_reexecutes_only_exact_request(self) -> None:
        with test_workspace("sf-107-api-idempotency-retryable") as workspace:
            api, idempotency = self._stores(workspace)
            self._claim_ready(api)
            scope = self._scope()
            idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(1),
            )
            idempotency.begin_execution(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(2),
            )
            response = {
                "version": "1.0.0",
                "status": "error",
                "error": {
                    "code": "internal-error",
                    "reason_code": "canonical-mutation-not-applied",
                },
            }
            retryable = idempotency.mark_retryable(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                response_status=500,
                response=response,
                result_proof_sha256=RESULT_SHA256,
                at=_at(3),
            )
            self.assertEqual(retryable["status"], "retryable")
            status = api.status(at=_at(3))
            self.assertTrue(status["mutation_ready"])
            self.assertEqual(
                status["idempotency_status_counts"]["retryable"],
                1,
            )

            changed = {**scope, "request_sha256": "7" * 64}
            with self.assertRaisesRegex(ProtocolError, "collision"):
                idempotency.accept(
                    **changed,
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    at=_at(4),
                )

            api.heartbeat(
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(4),
            )
            accepted = idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(4),
            )
            self.assertEqual(accepted["disposition"], "accepted")
            self.assertEqual(accepted["record"]["attempt_count"], 2)
            self.assertIsNone(accepted["record"]["response_json"])
            idempotency.begin_execution(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(5),
            )
            completed = idempotency.complete(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                response_status=200,
                response={"version": "1.0.0", "status": "ok"},
                result_proof_sha256=RESULT_SHA256,
                at=_at(6),
            )
            self.assertEqual(completed["record"]["status"], "completed")
            self.assertEqual(
                api.status(at=_at(6))["idempotency_status_counts"],
                {
                    "accepted": 0,
                    "executing": 0,
                    "retryable": 0,
                    "completed": 1,
                    "reconcile-required": 0,
                },
            )

    def test_expiry_reconciles_stale_generation_and_rejects_completion(self) -> None:
        with test_workspace("sf-107-api-idempotency-reconcile") as workspace:
            api, idempotency = self._stores(workspace)
            self._claim_ready(api)
            scope = self._scope()
            idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(1),
            )
            idempotency.begin_execution(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(2),
            )

            api.expire_runtime(at=_at(7))
            stale = idempotency.get(
                route_id=scope["route_id"],
                client_id=scope["client_id"],
                project_id=scope["project_id"],
                idempotency_key=scope["idempotency_key"],
            )
            self.assertEqual(stale["status"], "reconcile-required")
            with self.assertRaisesRegex(ProtocolError, "status|expired"):
                idempotency.complete(
                    **scope,
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    response_status=200,
                    response={"status": "ok"},
                    result_proof_sha256=RESULT_SHA256,
                    at=_at(7),
                )

            second = self._claim_ready(
                api,
                boot_id=BOOT_TWO,
                claim_second=8,
                ready_second=9,
            )
            self.assertEqual(second["runtime_generation"], 2)
            reconciling = idempotency.begin_reconciliation(
                **scope,
                boot_id=BOOT_TWO,
                runtime_generation=2,
                at=_at(9),
            )
            self.assertEqual(reconciling["attempt_count"], 2)
            completed = idempotency.complete(
                **scope,
                boot_id=BOOT_TWO,
                runtime_generation=2,
                response_status=200,
                response={"status": "ok", "proven": True},
                result_proof_sha256=RESULT_SHA256,
                at=_at(10),
            )
            self.assertEqual(completed["record"]["status"], "completed")
            self.assertTrue(api.status(at=_at(10))["mutation_ready"])

    def test_secret_material_is_rejected_before_storage(self) -> None:
        with test_workspace("sf-107-api-idempotency-secret") as workspace:
            api, idempotency = self._stores(workspace)
            self._claim_ready(api)
            with self.assertRaisesRegex(ProtocolError, "secret"):
                idempotency.accept(
                    **self._scope("sk-secret-key-material"),
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    at=_at(1),
                )

            scope = self._scope()
            idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(1),
            )
            idempotency.begin_execution(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(2),
            )
            with self.assertRaisesRegex(ProtocolError, "secret"):
                idempotency.complete(
                    **scope,
                    boot_id=BOOT_ONE,
                    runtime_generation=1,
                    response_status=200,
                    response={"api_key": "ghp_1234567890abcdef"},
                    result_proof_sha256=RESULT_SHA256,
                    at=_at(3),
                )
            self.assertEqual(
                idempotency.get(
                    route_id=scope["route_id"],
                    client_id=scope["client_id"],
                    project_id=scope["project_id"],
                    idempotency_key=scope["idempotency_key"],
                )["status"],
                "executing",
            )

    def test_integrity_rejects_digest_tampering(self) -> None:
        with test_workspace("sf-107-api-store-tamper") as workspace:
            api, idempotency = self._stores(workspace)
            self._claim_ready(api)
            scope = self._scope()
            idempotency.accept(
                **scope,
                boot_id=BOOT_ONE,
                runtime_generation=1,
                at=_at(1),
            )
            tamper_sqlite_store(
                api.path,
                """
                UPDATE factory_operations_api_idempotency
                SET content_sha256 = ?
                WHERE route_id = ? AND client_id = ?
                  AND project_id = ? AND idempotency_key = ?
                """,
                (
                    "f" * 64,
                    scope["route_id"],
                    scope["client_id"],
                    scope["project_id"],
                    scope["idempotency_key"],
                ),
            )
            with self.assertRaisesRegex(ProtocolError, "digest"):
                idempotency.integrity()
            with self.assertRaisesRegex(ProtocolError, "digest"):
                api.integrity(at=_at(1))


if __name__ == "__main__":
    unittest.main()
