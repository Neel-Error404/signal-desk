from __future__ import annotations

import copy
import hashlib
import threading
import unittest
from dataclasses import replace
from datetime import timedelta

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations.hosted_identity import (
    ExternalSecretBroker,
    IdentitySecretAuditLedger,
    WorkloadIdentityVerifier,
    identity_content_sha256,
    validate_secret_reference,
    validate_workload_identity_policy,
)
from tests._sf601_support import (
    NOW,
    FakeSecretProvider,
    identity_policy,
    resource_reference,
    rsa_fixture,
    signed_token,
)
from tests._support import test_workspace


class HostedIdentityComponentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.private_key, cls.jwks = rsa_fixture()

    def verifier(self, policy=None) -> WorkloadIdentityVerifier:
        return WorkloadIdentityVerifier(
            policy or identity_policy(self.jwks),
            jwks_loader=lambda _issuer: copy.deepcopy(self.jwks),
            now=lambda: NOW,
        )

    def verified_identity(self) -> dict:
        return self.verifier().verify(signed_token(self.private_key))

    def token(self) -> str:
        return signed_token(self.private_key)

    def test_policy_digest_and_wildcard_scope_fail_closed(self) -> None:
        policy = identity_policy(self.jwks)
        self.assertEqual(
            validate_workload_identity_policy(policy, now=NOW),
            policy,
        )
        changed = copy.deepcopy(policy)
        changed["bindings"][0]["subject"] = "*"
        changed["content_sha256"] = identity_content_sha256(
            {
                key: value
                for key, value in changed.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "wildcards"):
            validate_workload_identity_policy(changed, now=NOW)

    def test_valid_identity_is_digest_only_and_exactly_bound(self) -> None:
        token = signed_token(self.private_key)
        identity = self.verifier().verify(token)
        self.assertEqual(identity["project_id"], "project-one")
        self.assertEqual(identity["workload_id"], "worker-one")
        self.assertEqual(
            identity["token_sha256"],
            hashlib.sha256(token.encode("utf-8")).hexdigest(),
        )
        self.assertNotIn(token, repr(identity))

    def test_wrong_subject_expiry_and_cross_product_fail_closed(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "subject is not bound"):
            self.verifier().verify(
                signed_token(
                    self.private_key,
                    subject="workload:project-one:unknown",
                )
            )
        with self.assertRaisesRegex(ProtocolError, "not current"):
            self.verifier().verify(
                signed_token(
                    self.private_key,
                    issued_at=NOW - timedelta(minutes=10),
                    not_before=NOW - timedelta(minutes=10),
                    expires_at=NOW - timedelta(minutes=1),
                )
            )
        with self.assertRaisesRegex(ProtocolError, "project_id.*misbound"):
            self.verifier().verify(
                signed_token(
                    self.private_key,
                    project_id="project-two",
                )
            )

    def test_revoked_token_and_changed_jwks_fail_closed(self) -> None:
        token = signed_token(self.private_key)
        policy = identity_policy(self.jwks)
        policy["revoked_token_sha256"] = [
            hashlib.sha256(token.encode("utf-8")).hexdigest()
        ]
        policy["content_sha256"] = identity_content_sha256(
            {
                key: value
                for key, value in policy.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "revoked"):
            self.verifier(policy).verify(token)

        changed_jwks = copy.deepcopy(self.jwks)
        changed_jwks["extra"] = True
        verifier = WorkloadIdentityVerifier(
            identity_policy(self.jwks),
            jwks_loader=lambda _issuer: changed_jwks,
            now=lambda: NOW,
        )
        with self.assertRaisesRegex(ProtocolError, "JWKS digest changed"):
            verifier.verify(token)

    def test_scoped_credential_is_short_lived_and_audit_is_secret_free(self) -> None:
        with test_workspace("sf601-issue") as workspace:
            provider = FakeSecretProvider()
            audit = IdentitySecretAuditLedger(workspace / "identity.db")
            verifier = self.verifier()
            broker = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={"broker-one": provider},
                audit=audit,
                now=lambda: NOW,
            )
            credential = broker.issue(
                resource_reference(),
                self.token(),
                request_id="request-issue-redaction",
                at=NOW.isoformat(),
            )
            self.assertEqual(credential.value, b"credential-1")
            self.assertNotIn("credential-1", repr(credential))
            event_text = repr(audit.events())
            self.assertNotIn("credential-1", event_text)
            self.assertIn("resource-database", event_text)

    def test_cross_product_version_ttl_and_broker_outage_fail_closed(self) -> None:
        with test_workspace("sf601-failures") as workspace:
            audit = IdentitySecretAuditLedger(workspace / "identity.db")
            verifier = self.verifier()
            broker = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={"broker-one": FakeSecretProvider()},
                audit=audit,
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "project boundary"):
                broker.issue(
                    resource_reference(project_id="project-two"),
                    self.token(),
                    request_id="request-cross-product",
                    at=NOW.isoformat(),
                )
            with self.assertRaisesRegex(ProtocolError, "outside the workload"):
                broker.issue(
                    resource_reference(version="v3"),
                    self.token(),
                    request_id="request-version-outside-grant",
                    at=NOW.isoformat(),
                )

            long_lived = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={
                    "broker-one": FakeSecretProvider(ttl_seconds=121)
                },
                audit=IdentitySecretAuditLedger(
                    workspace / "long-lived-identity.db"
                ),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "TTL exceeds"):
                long_lived.issue(
                    resource_reference(),
                    self.token(),
                    request_id="request-long-lived",
                    at=NOW.isoformat(),
                )

            fractional = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={
                    "broker-one": FakeSecretProvider(ttl_seconds=120.5)
                },
                audit=IdentitySecretAuditLedger(
                    workspace / "fractional-identity.db"
                ),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "TTL exceeds"):
                fractional.issue(
                    resource_reference(),
                    self.token(),
                    request_id="request-fractional-ttl",
                    at=NOW.isoformat(),
                )

            expired = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={
                    "broker-one": FakeSecretProvider(ttl_seconds=-1)
                },
                audit=IdentitySecretAuditLedger(
                    workspace / "expired-identity.db"
                ),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "predate expires_at"):
                expired.issue(
                    resource_reference(),
                    self.token(),
                    request_id="request-expired-provider",
                    at=NOW.isoformat(),
                )

            unavailable = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={
                    "broker-one": FakeSecretProvider(unavailable=True)
                },
                audit=IdentitySecretAuditLedger(
                    workspace / "outage-identity.db"
                ),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "unavailable"):
                unavailable.issue(
                    resource_reference(),
                    self.token(),
                    request_id="request-broker-outage",
                    at=NOW.isoformat(),
                )

    def test_provider_uri_reference_is_not_an_opaque_resource_id(self) -> None:
        changed = resource_reference()
        changed["resource_id"] = "vault:project-one/database"
        with self.assertRaisesRegex(ProtocolError, "reference scheme"):
            validate_secret_reference(changed)

    def test_rotation_revokes_old_lease_and_audits_new_version(self) -> None:
        with test_workspace("sf601-rotate") as workspace:
            provider = FakeSecretProvider()
            audit = IdentitySecretAuditLedger(workspace / "identity.db")
            verifier = self.verifier()
            broker = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={"broker-one": provider},
                audit=audit,
                now=lambda: NOW,
            )
            token = self.token()
            credential = broker.issue(
                resource_reference(),
                token,
                request_id="request-rotation-issue",
                at=NOW.isoformat(),
            )
            result = broker.rotate(
                resource_reference(),
                token,
                request_id="request-rotation",
                at=(NOW + timedelta(seconds=1)).isoformat(),
            )
            self.assertEqual(result["current_version"], "v2")
            self.assertEqual(result["revoked_lease_ids"], [credential.lease_id])
            self.assertEqual(provider.revoked, [credential.lease_id])
            self.assertEqual(
                [event["event_type"] for event in audit.events()],
                [
                    "broker.operation.requested",
                    "broker.credential.issued",
                    "broker.operation.requested",
                    "broker.resource.rotated",
                ],
            )

    def test_audit_rejects_secret_telemetry_and_detects_tamper(self) -> None:
        with test_workspace("sf601-audit") as workspace:
            audit = IdentitySecretAuditLedger(workspace / "identity.db")
            with self.assertRaisesRegex(ProtocolError, "forbidden secret"):
                audit.append(
                    "unsafe",
                    {"api_key": "not-persisted"},
                    at=NOW.isoformat(),
                )
            audit.append("safe", {"workload_id": "worker-one"}, at=NOW.isoformat())
            connection = audit._connection()
            try:
                connection.execute(
                    "UPDATE hosted_identity_audit SET payload_json = ?",
                    ('{"workload_id":"changed"}',),
                )
            finally:
                connection.close()
            with self.assertRaisesRegex(ProtocolError, "digest changed"):
                audit.events()

        with test_workspace("sf601-audit-identity") as workspace:
            audit = IdentitySecretAuditLedger(workspace / "identity.db")
            event = audit.append(
                "safe",
                {"workload_id": "worker-one"},
                at=NOW.isoformat(),
            )
            connection = audit._connection()
            try:
                connection.execute(
                    "UPDATE hosted_identity_audit SET event_id = ?",
                    ("identity-audit-forged",),
                )
            finally:
                connection.close()
            with self.assertRaisesRegex(ProtocolError, "identity changed"):
                audit.events()

            connection = audit._connection()
            try:
                connection.execute(
                    """
                    UPDATE hosted_identity_audit
                    SET event_id = ?, sequence = 2
                    """,
                    (event["event_id"],),
                )
            finally:
                connection.close()
            with self.assertRaisesRegex(ProtocolError, "sequence"):
                audit.events()

    def test_terminal_audit_failure_leaves_uncertain_intent(self) -> None:
        class FailingTerminalAudit(IdentitySecretAuditLedger):
            def append(self, event_type, payload, *, at=None):
                if event_type == "broker.credential.issued":
                    raise ProtocolError("injected terminal audit failure")
                return super().append(event_type, payload, at=at)

        with test_workspace("sf601-audit-failure") as workspace:
            path = workspace / "identity.db"
            provider = FakeSecretProvider()
            audit = FailingTerminalAudit(path)
            broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={"broker-one": provider},
                audit=audit,
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "terminal audit failure"):
                broker.issue(
                    resource_reference(),
                    self.token(),
                    request_id="request-terminal-audit-failure",
                    at=NOW.isoformat(),
                )
            self.assertEqual(len(provider.issued), 1)
            with self.assertRaisesRegex(ProtocolError, "uncertain"):
                IdentitySecretAuditLedger(path).active_leases()

    def test_request_identity_cannot_replay_with_changed_timestamp(self) -> None:
        with test_workspace("sf601-request-replay") as workspace:
            provider = FakeSecretProvider()
            broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={"broker-one": provider},
                audit=IdentitySecretAuditLedger(workspace / "identity.db"),
                now=lambda: NOW,
            )
            broker.issue(
                resource_reference(),
                self.token(),
                request_id="request-replay-boundary",
                at=NOW.isoformat(),
            )
            with self.assertRaisesRegex(ProtocolError, "already used"):
                broker.issue(
                    resource_reference(),
                    self.token(),
                    request_id="request-replay-boundary",
                    at=(NOW + timedelta(seconds=1)).isoformat(),
                )
            self.assertEqual(len(provider.issued), 1)

    def test_fractional_credential_cannot_outlive_workload_token(self) -> None:
        token = signed_token(
            self.private_key,
            expires_at=NOW + timedelta(seconds=60),
            jti="token-fractional-expiry",
        )
        with test_workspace("sf601-token-expiry") as workspace:
            broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={
                    "broker-one": FakeSecretProvider(ttl_seconds=60.5)
                },
                audit=IdentitySecretAuditLedger(workspace / "identity.db"),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "cannot outlive"):
                broker.issue(
                    resource_reference(),
                    token,
                    request_id="request-fractional-expiry",
                    at=NOW.isoformat(),
                )

    def test_rotation_atomically_revokes_other_workload_lease(self) -> None:
        policy = identity_policy(self.jwks)
        second = copy.deepcopy(policy["bindings"][0])
        second["binding_id"] = "binding-worker-two"
        second["subject"] = "workload:project-one:worker-two"
        second["workload_id"] = "worker-two"
        policy["bindings"].append(second)
        policy["content_sha256"] = identity_content_sha256(
            {
                key: value
                for key, value in policy.items()
                if key != "content_sha256"
            }
        )
        verifier = self.verifier(policy)
        first_token = self.token()
        second_token = signed_token(
            self.private_key,
            subject="workload:project-one:worker-two",
            workload_id="worker-two",
            jti="token-sf601-worker-two",
        )
        with test_workspace("sf601-multi-workload-rotate") as workspace:
            provider = FakeSecretProvider()
            audit = IdentitySecretAuditLedger(workspace / "identity.db")
            broker = ExternalSecretBroker(
                identity_verifier=verifier,
                providers={"broker-one": provider},
                audit=audit,
                now=lambda: NOW,
            )
            first = broker.issue(
                resource_reference(),
                first_token,
                request_id="request-worker-one",
                at=NOW.isoformat(),
            )
            second_credential = broker.issue(
                resource_reference(),
                second_token,
                request_id="request-worker-two",
                at=NOW.isoformat(),
            )
            result = broker.rotate(
                resource_reference(),
                first_token,
                request_id="request-multi-workload-rotation",
                at=(NOW + timedelta(seconds=1)).isoformat(),
            )
            self.assertEqual(
                result["revoked_lease_ids"],
                sorted([first.lease_id, second_credential.lease_id]),
            )
            self.assertEqual(
                IdentitySecretAuditLedger(
                    workspace / "identity.db"
                ).active_leases(),
                {},
            )

    def test_credential_provenance_requires_live_issuing_broker(self) -> None:
        with test_workspace("sf601-credential-provenance") as workspace:
            audit = IdentitySecretAuditLedger(workspace / "identity.db")
            broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={"broker-one": FakeSecretProvider()},
                audit=audit,
                now=lambda: NOW,
            )
            issued = broker.issue(
                resource_reference(),
                self.token(),
                request_id="request-provenance",
                at=NOW.isoformat(),
            )
            self.assertEqual(
                broker.verify_credential(issued),
                issued.metadata(),
            )
            with self.assertRaisesRegex(ProtocolError, "not issued"):
                broker.verify_credential(
                    replace(issued, value=b"forged-value")
                )

            restarted = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={"broker-one": FakeSecretProvider()},
                audit=IdentitySecretAuditLedger(workspace / "identity.db"),
                now=lambda: NOW,
            )
            with self.assertRaisesRegex(ProtocolError, "not issued"):
                restarted.verify_credential(issued)

    def test_provider_error_cannot_expose_secret_material(self) -> None:
        class LeakingProvider(FakeSecretProvider):
            def issue(self, reference, identity, *, at):
                raise ProtocolError("credential-provider-secret-value")

        with test_workspace("sf601-provider-error-redaction") as workspace:
            broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={"broker-one": LeakingProvider()},
                audit=IdentitySecretAuditLedger(workspace / "identity.db"),
                now=lambda: NOW,
            )
            with self.assertRaises(ProtocolError) as raised:
                broker.issue(
                    resource_reference(),
                    self.token(),
                    request_id="request-provider-error-redaction",
                    at=NOW.isoformat(),
                )
            self.assertEqual(
                str(raised.exception),
                "External secret broker is unavailable.",
            )
            self.assertIsNone(raised.exception.__cause__)
            self.assertIsNone(raised.exception.__context__)

    def test_credential_access_fences_concurrent_revocation(self) -> None:
        with test_workspace("sf601-credential-access-fence") as workspace:
            broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={"broker-one": FakeSecretProvider()},
                audit=IdentitySecretAuditLedger(workspace / "identity.db"),
                now=lambda: NOW,
            )
            token = self.token()
            issued = broker.issue(
                resource_reference(),
                token,
                request_id="request-access-fence-issue",
                at=NOW.isoformat(),
            )
            second_broker = ExternalSecretBroker(
                identity_verifier=self.verifier(),
                providers={"broker-one": FakeSecretProvider()},
                audit=IdentitySecretAuditLedger(workspace / "identity.db"),
                now=lambda: NOW,
            )
            started = threading.Event()
            finished = threading.Event()
            failures: list[Exception] = []

            def revoke() -> None:
                started.set()
                try:
                    second_broker.revoke(
                        issued.lease_id,
                        token,
                        request_id="request-access-fence-revoke",
                        at=(NOW + timedelta(seconds=1)).isoformat(),
                    )
                except Exception as exc:
                    failures.append(exc)
                finally:
                    finished.set()

            with broker.credential_access(issued):
                thread = threading.Thread(target=revoke)
                thread.start()
                self.assertTrue(started.wait(timeout=1))
                self.assertFalse(finished.wait(timeout=0.05))
            self.assertTrue(finished.wait(timeout=1))
            thread.join()
            self.assertEqual(failures, [])
            with self.assertRaisesRegex(
                ProtocolError,
                "state does not match|not issued",
            ):
                broker.verify_credential(issued)


if __name__ == "__main__":
    unittest.main()
