from __future__ import annotations

import copy
from contextlib import closing
import sqlite3
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import MutationConflictError, ProtocolError
from elder_protocol.factory_operations import DurableSessionController
from tests._sf203_support import (
    StaticWorkspaceAuthority,
    control_command,
    prepared_fixture,
    register_canonical_checkpoint,
    running_fixture,
    scenario_for,
)
from tests._support import test_workspace


class DurableSessionControllerComponentTests(unittest.TestCase):
    maxDiff = None

    def test_start_duplicate_and_restart_preserve_one_provider_effect(
        self,
    ) -> None:
        with test_workspace("sf203-start") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
            ) = prepared_fixture(workspace)
            command = control_command(
                aggregate,
                binding,
                "start",
                index=10,
            )
            accepted = session.submit(command)
            self.assertEqual(accepted["status"], "pending")
            self.assertEqual(session.submit(command), accepted)
            changed = copy.deepcopy(command)
            changed["reason"] = "Changed under the same identifier."
            with self.assertRaisesRegex(
                MutationConflictError,
                "collision",
            ):
                session.submit(changed)
            completed = session.execute_once(
                owner_id="controller-one",
                at=command["submitted_at"],
                lease_seconds=120,
            )
            self.assertIsNotNone(completed)
            self.assertEqual(completed["status"], "succeeded")
            current = controller.get(command["run_id"])
            self.assertEqual(current["worker_session"]["status"], "active")
            self.assertEqual(session.submit(command), completed)

            reopened = DurableSessionController(
                workspace / "sf203-session.db",
                run_controller=controller,
                adapter=adapter,
                workspace_authority=StaticWorkspaceAuthority(binding),
                workspace_binding=binding,
                workspace_binding_at="2026-08-11T01:07:30+00:00",
            )
            reopened.initialize()
            self.assertEqual(reopened.get(command["control_id"]), completed)
            self.assertEqual(reopened.execute_once(owner_id="controller-two"), None)
            with closing(sqlite3.connect(adapter.store_path)) as connection:
                self.assertEqual(
                    connection.execute(
                        """
                        SELECT COUNT(*) FROM receipts
                        WHERE operation = 'start' AND state = 'completed'
                        """
                    ).fetchone()[0],
                    1,
                )

    def test_incomplete_adapter_acceptance_does_not_activate_session(
        self,
    ) -> None:
        with test_workspace("sf203-accepted-not-complete") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
            ) = prepared_fixture(workspace)
            original_execute = adapter.execute

            def accept_start(request: dict) -> dict:
                response = original_execute(request)
                if request["operation"] == "start":
                    response["disposition"] = "accepted"
                    response["operation_completed"] = False
                    response["mutation_state"] = "not-started"
                return response

            adapter.execute = accept_start
            command = control_command(
                aggregate,
                binding,
                "start",
                index=11,
            )
            session.submit(command)
            result = session.execute_once(
                owner_id="controller",
                at=command["submitted_at"],
            )
            self.assertEqual(result["status"], "uncertain")
            self.assertEqual(
                controller.get(command["run_id"])["worker_session"]["status"],
                "starting",
            )

    def test_wait_follow_up_checkpoint_pause_resume_and_cancel(
        self,
    ) -> None:
        with test_workspace("sf203-controls") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                _,
                session,
            ) = running_fixture(workspace)
            wait = control_command(
                aggregate,
                binding,
                "wait",
                index=20,
                payload={"waiting_reason": "owner-decision"},
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(wait)
            waiting = session.execute_once(
                owner_id="controller",
                at=wait["submitted_at"],
            )
            self.assertEqual(waiting["status"], "waiting-owner")
            self.assertEqual(
                session.session_state(wait["worker_session_id"])[
                    "waiting_reason"
                ],
                "owner-decision",
            )
            aggregate = controller.get(wait["run_id"])
            follow_up = control_command(
                aggregate,
                binding,
                "follow-up",
                index=21,
                payload={
                    "instruction": "Continue with the owner's decision.",
                    "continuation_of": wait["control_id"],
                },
                requested_by="founder",
                at="2026-08-11T01:10:00+00:00",
            )
            session.submit(follow_up)
            continued = session.execute_once(
                owner_id="controller",
                at=follow_up["submitted_at"],
            )
            self.assertEqual(continued["status"], "succeeded")
            self.assertEqual(
                session.get(wait["control_id"])["continued_by"],
                follow_up["control_id"],
            )
            aggregate = controller.get(wait["run_id"])
            unbound_checkpoint = control_command(
                aggregate,
                binding,
                "checkpoint",
                index=220,
                payload={
                    "checkpoint_id": "checkpoint-not-canonical",
                    "checkpoint_sha256": "b" * 64,
                },
                at="2026-08-11T01:10:30+00:00",
            )
            with self.assertRaises(ProtocolError):
                session.submit(unbound_checkpoint)
            canonical_checkpoint = register_canonical_checkpoint(
                controller,
                aggregate,
                checkpoint_id="checkpoint-sf203-component",
                at="2026-08-11T01:10:30+00:00",
            )
            checkpoint = control_command(
                aggregate,
                binding,
                "checkpoint",
                index=22,
                payload={
                    "checkpoint_id": canonical_checkpoint["id"],
                    "checkpoint_sha256": canonical_checkpoint[
                        "content_sha256"
                    ],
                },
                at="2026-08-11T01:11:00+00:00",
            )
            session.submit(checkpoint)
            checkpointed = session.execute_once(
                owner_id="controller",
                at=checkpoint["submitted_at"],
            )
            self.assertEqual(checkpointed["status"], "succeeded")
            state = session.session_state(checkpoint["worker_session_id"])
            self.assertEqual(
                state["latest_checkpoint"]["checkpoint_id"],
                canonical_checkpoint["id"],
            )
            self.assertEqual(state["latest_cursor"]["sequence"], 0)
            original_execute = session.adapter.execute

            def jump_observe_cursor(request: dict) -> dict:
                response = original_execute(request)
                if request["operation"] == "observe":
                    next_cursor = response["result"]["next_cursor"]
                    next_cursor["sequence"] = 2
                    next_cursor["event_id"] = "canonical-event-sf203-gap"
                    next_cursor["snapshot_sha256"] = canonical_sha256(
                        {"sequence": 2}
                    )
                    response["result_sha256"] = canonical_sha256(
                        response["result"]
                    )
                return response

            session.adapter.execute = jump_observe_cursor
            skipped_canonical = register_canonical_checkpoint(
                controller,
                aggregate,
                checkpoint_id="checkpoint-sf203-skipped-cursor",
                at="2026-08-11T01:11:10+00:00",
            )
            skipped = control_command(
                aggregate,
                binding,
                "checkpoint",
                index=221,
                payload={
                    "checkpoint_id": skipped_canonical["id"],
                    "checkpoint_sha256": skipped_canonical[
                        "content_sha256"
                    ],
                },
                at="2026-08-11T01:11:20+00:00",
            )
            session.submit(skipped)
            self.assertEqual(
                session.execute_once(
                    owner_id="controller",
                    at=skipped["submitted_at"],
                )["status"],
                "uncertain",
            )
            self.assertEqual(
                session.session_state(skipped["worker_session_id"])[
                    "latest_cursor"
                ]["sequence"],
                0,
            )
            session.adapter.execute = original_execute

            aggregate = controller.get(wait["run_id"])
            pause = control_command(
                aggregate,
                binding,
                "pause",
                index=23,
                at="2026-08-11T01:12:00+00:00",
            )
            session.submit(pause)
            self.assertEqual(
                session.execute_once(
                    owner_id="controller",
                    at=pause["submitted_at"],
                )["status"],
                "succeeded",
            )
            aggregate = controller.get(wait["run_id"])
            resume = control_command(
                aggregate,
                binding,
                "resume",
                index=24,
                at="2026-08-11T01:13:00+00:00",
            )
            session.submit(resume)
            self.assertEqual(
                session.execute_once(
                    owner_id="controller",
                    at=resume["submitted_at"],
                )["status"],
                "succeeded",
            )
            aggregate = controller.get(wait["run_id"])
            second_wait = control_command(
                aggregate,
                binding,
                "wait",
                index=240,
                payload={"waiting_reason": "owner-cancel-decision"},
                at="2026-08-11T01:13:30+00:00",
            )
            session.submit(second_wait)
            self.assertEqual(
                session.execute_once(
                    owner_id="controller",
                    at=second_wait["submitted_at"],
                )["status"],
                "waiting-owner",
            )
            aggregate = controller.get(wait["run_id"])
            cancel = control_command(
                aggregate,
                binding,
                "cancel",
                index=25,
                requested_by="founder",
                at="2026-08-11T01:14:00+00:00",
                reason="Owner cancelled the bounded worker session.",
            )
            session.submit(cancel)
            cancelled = session.execute_once(
                owner_id="controller",
                at=cancel["submitted_at"],
            )
            self.assertEqual(cancelled["status"], "succeeded")
            aggregate = controller.get(wait["run_id"])
            self.assertEqual(aggregate["run"]["status"], "cancelled")
            self.assertEqual(
                aggregate["worker_session"]["status"],
                "cancelled",
            )
            self.assertEqual(
                session.get(second_wait["control_id"])["status"],
                "cancelled",
            )
            self.assertIsNone(
                session.session_state(cancel["worker_session_id"])[
                    "waiting_control_id"
                ]
            )

    def test_event_cursor_rejects_gap_generation_and_identity_drift(
        self,
    ) -> None:
        with test_workspace("sf203-events") as workspace:
            (
                _,
                _,
                aggregate,
                _,
                adapter,
                session,
            ) = running_fixture(workspace)
            scenario = scenario_for(
                aggregate,
                timestamp="2026-08-11T01:09:00+00:00",
            )
            worker_command = scenario.command("worker.prompt", index=30)
            source_one, projection_one = scenario.event_pair(
                worker_command,
                sequence=1,
                adapter_id=adapter.capabilities().adapter_id,
            )
            source_two, projection_two = scenario.event_pair(
                worker_command,
                sequence=2,
                adapter_id=adapter.capabilities().adapter_id,
            )
            with self.assertRaisesRegex(
                MutationConflictError,
                "cursor order",
            ):
                session.ingest_event(source_two, projection_two)
            self.assertEqual(
                session.ingest_event(source_one, projection_one),
                projection_one,
            )
            self.assertEqual(
                session.ingest_event(source_one, projection_one),
                projection_one,
            )
            wrong_source = copy.deepcopy(source_two)
            wrong_projection = copy.deepcopy(projection_two)
            for event in (wrong_source, wrong_projection):
                event["correlations"]["project_id"] = "other-project"
            with self.assertRaisesRegex(
                MutationConflictError,
                "current SF-105 aggregate",
            ):
                session.ingest_event(wrong_source, wrong_projection)
            drifted_source = copy.deepcopy(source_one)
            drifted = copy.deepcopy(projection_one)
            for event in (drifted_source, drifted):
                event["payload"]["worker_reference"] = (
                    "fake-provider://changed/reference"
                )
                event["payload_sha256"] = canonical_sha256(event["payload"])
            with self.assertRaisesRegex(
                MutationConflictError,
                "drift",
            ):
                session.ingest_event(drifted_source, drifted)
            future_source = copy.deepcopy(source_two)
            future_projection = copy.deepcopy(projection_two)
            future_source["cursor"]["generation"] = 2
            future_projection["cursor"]["generation"] = 2
            with self.assertRaisesRegex(
                MutationConflictError,
                "generation",
            ):
                session.ingest_event(future_source, future_projection)

    def test_restart_fences_interrupted_external_effect_and_requeues_local(
        self,
    ) -> None:
        with test_workspace("sf203-restart") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            prompt = control_command(
                aggregate,
                binding,
                "prompt",
                index=40,
                payload={"instruction": "Perform one bounded change."},
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(prompt)
            claimed = session.claim_next(
                owner_id="crashed-owner",
                at=prompt["submitted_at"],
                lease_seconds=1,
            )
            executing = session.begin_execution(
                prompt["control_id"],
                owner_id="crashed-owner",
                lease_generation=claimed["lease"]["generation"],
                at=prompt["submitted_at"],
            )
            session._mark_step(
                prompt["control_id"],
                owner_id="crashed-owner",
                lease_generation=executing["lease"]["generation"],
                step="adapter-send",
                external=True,
                at=prompt["submitted_at"],
            )
            reopened = DurableSessionController(
                workspace / "sf203-session.db",
                run_controller=session.run_controller,
                adapter=adapter,
                workspace_authority=StaticWorkspaceAuthority(binding),
                workspace_binding=binding,
                workspace_binding_at="2026-08-11T01:09:30+00:00",
            )
            report = reopened.recover_interrupted(
                at="2026-08-11T01:09:02+00:00"
            )
            self.assertEqual(report["uncertain"], 1)
            self.assertEqual(
                reopened.get(prompt["control_id"])["status"],
                "uncertain",
            )

        with test_workspace("sf203-local-restart") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            pause = control_command(
                aggregate,
                binding,
                "pause",
                index=41,
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(pause)
            claimed = session.claim_next(
                owner_id="crashed-owner",
                at=pause["submitted_at"],
                lease_seconds=1,
            )
            session.begin_execution(
                pause["control_id"],
                owner_id="crashed-owner",
                lease_generation=claimed["lease"]["generation"],
                at=pause["submitted_at"],
            )
            reopened = DurableSessionController(
                workspace / "sf203-session.db",
                run_controller=session.run_controller,
                adapter=adapter,
                workspace_authority=StaticWorkspaceAuthority(binding),
                workspace_binding=binding,
                workspace_binding_at="2026-08-11T01:09:30+00:00",
            )
            report = reopened.recover_interrupted(
                at="2026-08-11T01:09:02+00:00"
            )
            self.assertEqual(report["requeued"], 1)
            reclaimed = reopened.claim_next(
                owner_id="new-owner",
                at="2026-08-11T01:09:03+00:00",
            )
            self.assertEqual(reclaimed["lease_generation"], 2)

    def test_cancel_waits_for_executing_control_then_takes_priority(
        self,
    ) -> None:
        with test_workspace("sf203-cancel-race") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            prompt = control_command(
                aggregate,
                binding,
                "prompt",
                index=50,
                payload={"instruction": "Potentially active command."},
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(prompt)
            claimed = session.claim_next(
                owner_id="active-owner",
                at=prompt["submitted_at"],
                lease_seconds=2,
            )
            executing = session.begin_execution(
                prompt["control_id"],
                owner_id="active-owner",
                lease_generation=claimed["lease"]["generation"],
                at=prompt["submitted_at"],
            )
            session._mark_step(
                prompt["control_id"],
                owner_id="active-owner",
                lease_generation=executing["lease"]["generation"],
                step="adapter-send",
                external=True,
                at=prompt["submitted_at"],
            )
            cancel = control_command(
                aggregate,
                binding,
                "cancel",
                index=51,
                requested_by="founder",
                at="2026-08-11T01:09:01+00:00",
                reason="Cancel after resolving the active command boundary.",
            )
            session.submit(cancel)
            self.assertIsNone(
                session.claim_next(
                    owner_id="cancel-owner",
                    at=cancel["submitted_at"],
                )
            )
            session.recover_interrupted(at="2026-08-11T01:09:02+00:00")
            claimed_cancel = session.claim_next(
                owner_id="cancel-owner",
                at="2026-08-11T01:09:03+00:00",
            )
            self.assertEqual(
                claimed_cancel["control_id"],
                cancel["control_id"],
            )
            cancelled = session.execute_once(
                owner_id="other-owner",
                at="2026-08-11T01:09:04+00:00",
            )
            self.assertIsNone(cancelled)
            executing_cancel = session.begin_execution(
                cancel["control_id"],
                owner_id="cancel-owner",
                lease_generation=claimed_cancel["lease"]["generation"],
                at="2026-08-11T01:09:03+00:00",
            )
            status, result, waiting_reason = session._operation_result(
                executing_cancel,
                owner_id="cancel-owner",
                lease_generation=claimed_cancel["lease"]["generation"],
                at="2026-08-11T01:09:03+00:00",
            )
            final = session._finish(
                cancel["control_id"],
                owner_id="cancel-owner",
                lease_generation=claimed_cancel["lease"]["generation"],
                status=status,
                result=result,
                error=None,
                waiting_reason=waiting_reason,
                at="2026-08-11T01:09:03+00:00",
            )
            self.assertEqual(final["status"], "succeeded")
            self.assertEqual(
                controller.get(cancel["run_id"])["run"]["status"],
                "cancelled",
            )
            self.assertEqual(
                session.get(prompt["control_id"])["status"],
                "uncertain",
            )
            self.assertEqual(
                adapter.effect_count(
                    session._adapter_request(
                        prompt,
                        operation="send",
                        payload={
                            "command": session._worker_command(
                                prompt,
                                command_type="worker.prompt",
                                at=prompt["submitted_at"],
                            )
                        },
                        phase="send",
                        at=prompt["submitted_at"],
                    )
                ),
                0,
            )

    def test_proved_non_application_retries_exactly_and_deadline_stops(
        self,
    ) -> None:
        with test_workspace("sf203-safe-retry") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            prompt = control_command(
                aggregate,
                binding,
                "prompt",
                index=60,
                payload={"instruction": "Retry only if not applied."},
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(prompt)
            adapter.arm_timeout_once("send")
            retryable = session.execute_once(
                owner_id="retry-owner",
                at=prompt["submitted_at"],
            )
            self.assertEqual(retryable["status"], "pending")
            completed = session.execute_once(
                owner_id="retry-owner",
                at="2026-08-11T01:09:01+00:00",
            )
            self.assertEqual(completed["status"], "succeeded")
            self.assertEqual(completed["attempt_count"], 2)
            request = session._adapter_request(
                prompt,
                operation="send",
                payload={
                    "command": session._worker_command(
                        prompt,
                        command_type="worker.prompt",
                        at=prompt["submitted_at"],
                    )
                },
                phase="send",
                at=prompt["submitted_at"],
            )
            self.assertEqual(adapter.effect_count(request), 1)
            original_execute = adapter.execute

            def canonical_claim(request: dict) -> dict:
                response = original_execute(request)
                if request["operation"] == "send":
                    response["result"]["accepted_command"][
                        "canonical_work_item_write"
                    ] = {"status": "completed"}
                    response["result_sha256"] = canonical_sha256(
                        response["result"]
                    )
                return response

            adapter.execute = canonical_claim
            invalid_response = control_command(
                aggregate,
                binding,
                "steer",
                index=62,
                payload={"instruction": "Reject canonical worker claims."},
                at="2026-08-11T01:09:30+00:00",
            )
            session.submit(invalid_response)
            self.assertEqual(
                session.execute_once(
                    owner_id="retry-owner",
                    at=invalid_response["submitted_at"],
                )["status"],
                "uncertain",
            )
            adapter.execute = original_execute

            expired = control_command(
                aggregate,
                binding,
                "steer",
                index=61,
                payload={"instruction": "This control is already expired."},
                at="2026-08-11T01:10:00+00:00",
            )
            expired["deadline_at"] = "2026-08-11T01:10:01+00:00"
            session.submit(expired)
            self.assertIsNone(
                session.claim_next(
                    owner_id="late-owner",
                    at="2026-08-11T01:10:02+00:00",
                )
            )
            rejected = session.get(expired["control_id"])
            self.assertEqual(rejected["status"], "rejected")
            self.assertEqual(
                rejected["last_error"]["code"],
                "deadline-expired",
            )


if __name__ == "__main__":
    unittest.main()
