from __future__ import annotations

import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_workers import (
    PrimeDaemonRuntime,
    PrimeRuntimeConfig,
    PrimeWorkerAdapter,
    WorkerConformanceScenario,
)
from tests._prime_support import (
    DeterministicPrimeRuntime,
    RecordingPrimeCandidateSink,
)
from tests._support import test_workspace


class PrimeWorkerAdapterComponentTests(unittest.TestCase):
    @staticmethod
    def _adapter(workspace, *, runtime=None, sink=None):
        provider_workspace = workspace / "provider"
        provider_workspace.mkdir(exist_ok=True)
        runtime = runtime or DeterministicPrimeRuntime(workspace)
        return (
            PrimeWorkerAdapter(
                workspace / "worker.db",
                workspace_bindings={
                    "workspace-sf200": provider_workspace.resolve()
                },
                runtime=runtime,
                refinement_sink=sink,
            ),
            runtime,
        )

    @staticmethod
    def _start(adapter, scenario):
        prepared = adapter.execute(
            scenario.request(
                "prepare",
                {
                    "work_item": {
                        "id": scenario.work_item_id,
                        "project_id": scenario.project_id,
                    },
                    "authority": {
                        "authority_ref": scenario.authority_ref,
                    },
                    "context": {
                        "content_sha256": scenario.context_sha256,
                    },
                },
                index=1,
            )
        )
        return adapter.execute(
            scenario.request(
                "start",
                {
                    "prepared_run": copy.deepcopy(
                        prepared["result"]["prepared_run"]
                    )
                },
                index=2,
            )
        )

    def test_prime_session_is_opaque_and_survives_daemon_replacement(
        self,
    ) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf204-component-restart") as workspace:
            adapter, runtime = self._adapter(workspace)
            started = self._start(adapter, scenario)
            external_ref = started["result"]["worker_session"][
                "external_session_ref"
            ]
            self.assertTrue(external_ref.startswith("prime://session/"))
            runtime.restart_daemon()
            recovered = adapter.execute(
                scenario.request(
                    "recover",
                    {
                        "session": {
                            "worker_session_id": scenario.worker_session_id,
                            "session_generation": (
                                scenario.session_generation
                            ),
                        },
                        "cursor": scenario.cursor(),
                    },
                    index=3,
                )
            )
            self.assertEqual(recovered["disposition"], "succeeded")
            self.assertEqual(
                recovered["result"]["recovery_result"]["provider_status"][
                    "active_session_id"
                ],
                external_ref.removeprefix("prime://session/"),
            )
            self.assertEqual(
                runtime.state.daemon_generation,
                2,
            )

    def test_provider_session_lease_conflict_is_explicitly_rejected(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf204-component-lease") as workspace:
            adapter, runtime = self._adapter(workspace)
            self._start(adapter, scenario)
            runtime.state.journals.clear()
            conflict_request = scenario.request(
                "start",
                {
                    "prepared_run": {
                        "run_id": scenario.run_id,
                        "status": "prepared",
                        "work_item_id": scenario.work_item_id,
                        "worker_session_id": scenario.worker_session_id,
                        "session_generation": scenario.session_generation,
                        "workspace_id": scenario.workspace_id,
                        "context_sha256": scenario.context_sha256,
                        "authority_ref": scenario.authority_ref,
                    }
                },
                index=20,
            )
            conflict_request["idempotency_key"] = "prime-lease-conflict"
            response = adapter.execute(conflict_request)
            self.assertEqual(response["disposition"], "rejected")
            self.assertEqual(response["error"]["code"], "conflict")
            self.assertEqual(
                response["error"]["details"]["reason"],
                "session_already_active",
            )

    def test_refinement_proposal_is_redirected_to_candidate_sink(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf204-component-refinement") as workspace:
            sink = RecordingPrimeCandidateSink()
            adapter, runtime = self._adapter(workspace, sink=sink)
            self._start(adapter, scenario)
            runtime.next_refinement_proposals = [
                {
                    "kind": "memory",
                    "scope": "global",
                    "summary": "Remember one reusable test rule.",
                    "edits": [{"action": "create", "kind": "memory"}],
                }
            ]
            response = adapter.execute(
                scenario.request(
                    "send",
                    {
                        "command": scenario.command(
                            "worker.prompt",
                            index=3,
                        )
                    },
                    index=3,
                )
            )
            self.assertEqual(response["disposition"], "succeeded")
            self.assertEqual(len(sink.candidates), 1)
            self.assertFalse(sink.candidates[0]["direct_application"])

    def test_direct_refinement_application_fails_closed(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf204-component-refinement-block") as workspace:
            sink = RecordingPrimeCandidateSink()
            adapter, runtime = self._adapter(workspace, sink=sink)
            self._start(adapter, scenario)
            runtime.next_refinement_applications = [
                {
                    "scope": "global",
                    "appliedEdits": [
                        {"kind": "memory", "action": "create", "applied": True}
                    ],
                }
            ]
            response = adapter.execute(
                scenario.request(
                    "send",
                    {
                        "command": scenario.command(
                            "worker.prompt",
                            index=3,
                        )
                    },
                    index=3,
                )
            )
            self.assertEqual(response["disposition"], "uncertain")
            self.assertEqual(
                response["error"]["details"]["reason"],
                "direct-refinement-application-forbidden",
            )
            self.assertEqual(sink.candidates, [])

    def test_concrete_runtime_extracts_refinement_from_events_and_snapshot(
        self,
    ) -> None:
        result = {
            "id": "refine-1",
            "scope": "global",
            "appliedEdits": [
                {"kind": "memory", "action": "create", "applied": True}
            ],
        }
        applications = PrimeDaemonRuntime._refinement_applications(
            {
                "type": "event",
                "event": {
                    "type": "session_event",
                    "event": {
                        "type": "refine_complete",
                        "result": result,
                    },
                },
            },
            {
                "messages": [
                    {
                        "role": "custom",
                        "customType": "prime-agent.refinement",
                        "data": result,
                    }
                ]
            },
        )
        self.assertEqual(applications, [result])

    def test_concrete_runtime_disables_prime_auto_refine_before_create(
        self,
    ) -> None:
        with test_workspace("sf204-component-refinement-policy") as workspace:
            provider_workspace = workspace / "provider"
            provider_workspace.mkdir()
            agent_dir = workspace / "agent"
            runtime = PrimeDaemonRuntime(
                PrimeRuntimeConfig(
                    executable=("fake-prime-agent",),
                    agent_dir=agent_dir.resolve(),
                    socket_path="deterministic-prime-socket",
                    bash_path=Path(
                        r"C:\Program Files\Git\bin\bash.exe"
                    ),
                )
            )
            exchange = {
                "hello": {
                    "protocol": {
                        "name": "prime-agent.daemon",
                        "version": 7,
                    },
                    "schemaRevision": 13,
                    "appVersion": "0.7.0",
                    "socketPath": "deterministic-prime-socket",
                },
                "response": {
                    "id": "start-command",
                    "type": "response",
                    "success": True,
                    "data": {"activeSessionId": "prime-session"},
                },
                "events": [],
            }
            with patch.object(runtime, "_request", return_value=exchange) as call:
                runtime.start_session(
                    provider_workspace.resolve(),
                    session_path=(agent_dir / "session.jsonl").resolve(),
                    client_id="elder-client",
                    command_id="start-command",
                )
            settings = json.loads(
                (agent_dir / "settings.json").read_text(encoding="utf-8")
            )
            self.assertEqual(
                settings["autoRefine"],
                {"compact": False, "enabled": False},
            )
            command = call.call_args.args[0]
            self.assertFalse(command["config"]["serializedRefine"])
            self.assertTrue(command["config"]["noSkills"])

            project_settings = (
                provider_workspace / ".prime" / "agent" / "settings.json"
            )
            project_settings.parent.mkdir(parents=True)
            project_settings.write_text(
                '{"autoRefine":{"enabled":true}}',
                encoding="utf-8",
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "must not enable auto-refine",
            ):
                runtime.start_session(
                    provider_workspace.resolve(),
                    session_path=(agent_dir / "other.jsonl").resolve(),
                    client_id="elder-client",
                    command_id="conflicting-command",
                )

    def test_lost_command_response_replays_provider_journal_on_recover(
        self,
    ) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf204-component-journal") as workspace:
            adapter, runtime = self._adapter(workspace)
            self._start(adapter, scenario)
            runtime.fail_after_dispatch_once = True
            command = scenario.command("worker.prompt", index=3)
            first = adapter.execute(
                scenario.request(
                    "send",
                    {"command": command},
                    index=3,
                )
            )
            self.assertEqual(first["disposition"], "uncertain")
            recovered = adapter.execute(
                scenario.request(
                    "recover",
                    {
                        "session": {
                            "worker_session_id": scenario.worker_session_id,
                            "session_generation": (
                                scenario.session_generation
                            ),
                        },
                        "cursor": scenario.cursor(),
                    },
                    index=4,
                )
            )
            reconciled = recovered["result"]["recovery_result"][
                "reconciled_effects"
            ]
            self.assertEqual(len(reconciled), 1)
            self.assertEqual(reconciled[0]["outcome"], "succeeded")
            self.assertEqual(
                len(
                    [
                        call
                        for call in runtime.state.calls
                        if call["operation"] == "command"
                        and call["command_id"] == command["command_id"]
                    ]
                ),
                1,
            )
            self.assertEqual(
                len(
                    [
                        call
                        for call in runtime.state.calls
                        if call["operation"] == "journal-replay"
                        and call["command_id"] == command["command_id"]
                    ]
                ),
                1,
            )


if __name__ == "__main__":
    unittest.main()
