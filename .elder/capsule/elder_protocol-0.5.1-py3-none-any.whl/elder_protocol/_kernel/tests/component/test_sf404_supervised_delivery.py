from __future__ import annotations

import sqlite3
import unittest

from elder_protocol.errors import ProtocolError
from tests._sf404_support import (
    CountingSubmitter,
    build_environment,
)
from tests._support import test_workspace


class SF404SupervisedDeliveryComponentTests(unittest.TestCase):
    def _environment(self, workspace, **options):
        environment = build_environment(workspace, **options)
        self.addCleanup(environment["authority_patcher"].stop)
        return environment

    def test_ready_owner_submission_opens_exact_supervised_pr(self) -> None:
        with test_workspace("sf404-open") as workspace:
            environment = self._environment(workspace)
            self.assertEqual(environment["delivery_view"]["status"], "ready")
            original = environment["pipeline"].complete(
                environment["plan"]["id"],
                outcome_record_ref=environment["completion"][
                    "outcome_record_ref"
                ],
            )
            self.assertEqual(
                original["content_sha256"],
                environment["completion"]["content_sha256"],
            )
            submitter = CountingSubmitter()
            view = environment["delivery_service"].decide(
                environment["delivery_request"],
                environment["delivery_sources"],
                environment["execution"],
                submitter,
                actor_identity_id="founder",
                decision="submit",
                reason="Open the supervised pull request.",
            )
            self.assertEqual(view["status"], "open")
            self.assertEqual(submitter.calls, 1)
            self.assertFalse(view["can_merge"])
            self.assertFalse(view["can_deploy"])
            self.assertFalse(view["can_mutate_maturity"])

    def test_expired_qualification_and_inactive_certification_block(self) -> None:
        with test_workspace("sf404-expired-qualification") as workspace:
            expired = self._environment(
                workspace,
                expired_qualification=True,
                prepare=False,
            )
            self.assertEqual(
                expired["delivery_authorization"]["status"],
                "blocked",
            )
            self.assertIn(
                "expired",
                expired["delivery_authorization"][
                    "actionable_reason"
                ].lower(),
            )
        with test_workspace("sf404-inactive-certification") as workspace:
            inactive = self._environment(
                workspace,
                active_certification=False,
                prepare=False,
            )
            self.assertEqual(
                inactive["delivery_authorization"]["status"],
                "blocked",
            )
            self.assertIn(
                "active",
                inactive["delivery_authorization"][
                    "actionable_reason"
                ].lower(),
            )

    def test_unprotected_branch_blocks_packet(self) -> None:
        with test_workspace("sf404-unprotected") as workspace:
            environment = self._environment(
                workspace,
                protected_branch=False,
            )
            self.assertEqual(environment["delivery_view"]["status"], "blocked")
            self.assertIn(
                "control",
                environment["delivery_view"]["actionable_reason"].lower(),
            )

    def test_changed_diff_blocks_before_provider(self) -> None:
        with test_workspace("sf404-changed-diff") as workspace:
            environment = self._environment(workspace)
            environment["change"].write_text(
                "def repaired_component() -> str:\n"
                "    return \"changed-after-proof\"\n",
                encoding="utf-8",
            )
            submitter = CountingSubmitter()
            view = environment["delivery_service"].decide(
                environment["delivery_request"],
                environment["delivery_sources"],
                environment["execution"],
                submitter,
                actor_identity_id="founder",
                decision="submit",
                reason="Submit only if proof is still current.",
            )
            self.assertEqual(view["status"], "blocked")
            self.assertIn("diff changed", view["actionable_reason"].lower())
            self.assertEqual(submitter.calls, 0)

    def test_owner_rejection_and_wrong_owner_do_not_call_provider(self) -> None:
        with test_workspace("sf404-owner-reject") as workspace:
            environment = self._environment(workspace)
            submitter = CountingSubmitter()
            with self.assertRaisesRegex(ProtocolError, "product owner"):
                environment["delivery_service"].decide(
                    environment["delivery_request"],
                    environment["delivery_sources"],
                    environment["execution"],
                    submitter,
                    actor_identity_id="example-agentic-product-executor",
                    decision="submit",
                    reason="Unauthorized submission.",
                )
            view = environment["delivery_service"].decide(
                environment["delivery_request"],
                environment["delivery_sources"],
                environment["execution"],
                submitter,
                actor_identity_id="founder",
                decision="reject",
                reason="Hold the bounded change.",
            )
            self.assertEqual(view["status"], "rejected")
            self.assertEqual(submitter.calls, 0)

    def test_provider_and_url_mismatch_require_reconciliation(self) -> None:
        cases = [
            ("repository", {"repository": "attacker/project"}),
            (
                "url",
                {"url": "https://attacker.example/fixture/product-one/42"},
            ),
        ]
        for label, overrides in cases:
            with self.subTest(label=label):
                with test_workspace(f"sf404-provider-{label}") as workspace:
                    environment = self._environment(workspace)
                    submitter = CountingSubmitter(overrides)
                    view = environment["delivery_service"].decide(
                        environment["delivery_request"],
                        environment["delivery_sources"],
                        environment["execution"],
                        submitter,
                        actor_identity_id="founder",
                        decision="submit",
                        reason="Submit the exact packet.",
                    )
                    self.assertEqual(
                        view["status"],
                        "reconciliation-required",
                    )
                    self.assertEqual(submitter.calls, 1)
                    replay = environment["delivery_service"].decide(
                        environment["delivery_request"],
                        environment["delivery_sources"],
                        environment["execution"],
                        submitter,
                        actor_identity_id="founder",
                        decision="submit",
                        reason="Do not retry an uncertain call.",
                    )
                    self.assertEqual(
                        replay["status"],
                        "reconciliation-required",
                    )
                    self.assertEqual(submitter.calls, 1)

    def test_tampered_durable_row_fails_closed(self) -> None:
        with test_workspace("sf404-row-tamper") as workspace:
            environment = self._environment(workspace)
            connection = sqlite3.connect(
                environment["delivery_service"].repository.path
            )
            try:
                connection.execute(
                    """
                    UPDATE supervised_deliveries
                    SET status = 'open'
                    WHERE request_id = ?
                    """,
                    (environment["delivery_request"]["request_id"],),
                )
                connection.commit()
            finally:
                connection.close()
            with self.assertRaisesRegex(ProtocolError, "row binding"):
                environment["delivery_service"].owner_view(
                    environment["delivery_request"]["request_id"]
                )


if __name__ == "__main__":
    unittest.main()
