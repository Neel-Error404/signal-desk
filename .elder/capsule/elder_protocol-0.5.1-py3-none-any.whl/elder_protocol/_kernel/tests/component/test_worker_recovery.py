from __future__ import annotations

from contextlib import closing
import sqlite3
import unittest

from elder_protocol.factory_operations import WorkerRecoveryCoordinator
from tests._sf203_support import (
    control_command,
    prepared_fixture,
    register_canonical_checkpoint,
    running_fixture,
)
from tests._support import test_workspace


class _ContinuationDependency:
    def __init__(self, control_id: str) -> None:
        self.control_id = control_id

    def ticks_for_control(self, session_control_id: str) -> list[dict]:
        if session_control_id != self.control_id:
            return []
        return [{"tick_id": "continuation-tick-" + "e" * 24}]

    def reconcile_recovery_case(
        self,
        case: dict,
        *,
        at: str | None = None,
    ) -> list[dict]:
        return self.ticks_for_control(case["control_id"])

    def recovery_ticks(self) -> list[dict]:
        return []


class _OrphanContinuationDependency:
    def ticks_for_control(self, session_control_id: str) -> list[dict]:
        return []

    def reconcile_recovery_case(
        self,
        case: dict,
        *,
        at: str | None = None,
    ) -> list[dict]:
        return []

    def recovery_ticks(self) -> list[dict]:
        return [
            {
                "tick_id": "continuation-tick-" + "f" * 24,
                "session_control_id": "session-control-missing-sf206",
                "session_control_sha256": "a" * 64,
            }
        ]


class _RetainedWorkspace:
    def recover(
        self,
        run_id: str,
        *,
        at: str | None = None,
    ) -> dict:
        return {"status": "ready"}

    def inventory(self) -> list[dict]:
        return [
            {
                "run_id": "run-orphan-sf206",
                "workspace_id": "workspace-orphan-sf206",
                "physical_state": "retained",
                "manifest_sha256": "b" * 64,
                "manifest_path": "orphan-workspace.json",
            }
        ]


class WorkerRecoveryComponentTests(unittest.TestCase):
    @staticmethod
    def _receipt(
        adapter,
        operation: str,
        idempotency_key: str,
    ) -> sqlite3.Row:
        with closing(sqlite3.connect(adapter.store_path)) as connection:
            connection.row_factory = sqlite3.Row
            row = connection.execute(
                """
                SELECT * FROM receipts
                WHERE operation = ? AND idempotency_key = ?
                """,
                (operation, idempotency_key),
            ).fetchone()
            if row is None:
                raise AssertionError("Expected worker receipt does not exist.")
            return row

    def test_kill_before_effect_requeues_exact_control_once(self) -> None:
        with test_workspace("sf206-before-effect") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            command = control_command(
                aggregate,
                binding,
                "prompt",
                index=2061,
                payload={"instruction": "Continue bounded work."},
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(command)
            adapter.arm_crash("send", "after-acceptance-before-effect")
            uncertain = session.execute_once(
                owner_id="sf206-controller",
                at=command["submitted_at"],
            )
            self.assertEqual(uncertain["status"], "uncertain")

            recovery = WorkerRecoveryCoordinator(
                workspace / "sf206-recovery.db",
                session_controller=session,
                continuation_scheduler=_ContinuationDependency(
                    command["control_id"]
                ),
            )
            recovery.initialize()
            case = recovery.reconcile_control(
                command["control_id"],
                at="2026-08-11T01:10:00+00:00",
            )

            self.assertEqual(case["status"], "requeued")
            self.assertEqual(case["disposition"], "not-applied")
            self.assertEqual(
                case["dependent_tick_ids"],
                ["continuation-tick-" + "e" * 24],
            )
            self.assertEqual(
                session.get(command["control_id"])["status"],
                "pending",
            )
            adapter.arm_crash("send", "after-effect-before-result")
            uncertain_again = session.execute_once(
                owner_id="sf206-controller",
                at="2026-08-11T01:11:00+00:00",
            )
            self.assertEqual(uncertain_again["status"], "uncertain")
            second_case = recovery.reconcile_control(
                command["control_id"],
                at="2026-08-11T01:12:00+00:00",
            )
            self.assertEqual(second_case["status"], "succeeded")
            self.assertNotEqual(second_case["case_id"], case["case_id"])
            self.assertEqual(len(recovery.list()), 2)
            receipt = self._receipt(
                adapter,
                "send",
                f"sf203:{command['control_id']}:send",
            )
            self.assertEqual(receipt["effect_count"], 1)

    def test_kill_after_send_effect_converges_without_replay(self) -> None:
        with test_workspace("sf206-after-effect") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            command = control_command(
                aggregate,
                binding,
                "prompt",
                index=2062,
                payload={"instruction": "Apply one exact change."},
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(command)
            adapter.arm_crash("send", "after-effect-before-result")
            uncertain = session.execute_once(
                owner_id="sf206-controller",
                at=command["submitted_at"],
            )
            self.assertEqual(uncertain["status"], "uncertain")

            recovery = WorkerRecoveryCoordinator(
                workspace / "sf206-recovery.db",
                session_controller=session,
            )
            recovery.initialize()
            case = recovery.reconcile_control(
                command["control_id"],
                at="2026-08-11T01:10:00+00:00",
            )

            self.assertEqual(case["status"], "succeeded")
            self.assertEqual(case["disposition"], "succeeded")
            self.assertEqual(
                session.get(command["control_id"])["status"],
                "succeeded",
            )
            receipt = self._receipt(
                adapter,
                "send",
                f"sf203:{command['control_id']}:send",
            )
            self.assertEqual(receipt["effect_count"], 1)
            self.assertEqual(len(recovery.attempts(case["case_id"])), 2)
            self.assertEqual(
                recovery.reconcile_control(
                    command["control_id"],
                    at="2026-08-11T01:11:00+00:00",
                ),
                case,
            )

    def test_checkpoint_effect_without_payload_stays_owner_visible(self) -> None:
        with test_workspace("sf206-checkpoint") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            canonical = register_canonical_checkpoint(
                controller,
                aggregate,
                checkpoint_id="checkpoint-sf206",
                at="2026-08-11T01:09:00+00:00",
            )
            command = control_command(
                aggregate,
                binding,
                "checkpoint",
                index=2063,
                payload={
                    "checkpoint_id": canonical["id"],
                    "checkpoint_sha256": canonical["content_sha256"],
                },
                at="2026-08-11T01:10:00+00:00",
            )
            session.submit(command)
            adapter.arm_crash("checkpoint", "after-effect-before-result")
            uncertain = session.execute_once(
                owner_id="sf206-controller",
                at=command["submitted_at"],
            )
            self.assertEqual(uncertain["status"], "uncertain")

            recovery = WorkerRecoveryCoordinator(
                workspace / "sf206-recovery.db",
                session_controller=session,
            )
            recovery.initialize()
            case = recovery.reconcile_control(
                command["control_id"],
                at="2026-08-11T01:11:00+00:00",
            )

            self.assertEqual(case["status"], "owner-required")
            self.assertEqual(case["disposition"], "succeeded")
            self.assertEqual(
                case["reason"],
                "worker-reported-succeeded",
            )
            self.assertEqual(
                session.get(command["control_id"])["status"],
                "uncertain",
            )
            receipt = self._receipt(
                adapter,
                "checkpoint",
                f"sf203:{command['control_id']}:checkpoint",
            )
            self.assertEqual(receipt["effect_count"], 1)

    def test_cancel_effect_completes_existing_canonical_cancel(self) -> None:
        with test_workspace("sf206-cancel") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            command = control_command(
                aggregate,
                binding,
                "cancel",
                index=2064,
                at="2026-08-11T01:09:00+00:00",
            )
            session.submit(command)
            adapter.arm_crash("cancel", "after-effect-before-result")
            uncertain = session.execute_once(
                owner_id="sf206-controller",
                at=command["submitted_at"],
            )
            self.assertEqual(uncertain["status"], "uncertain")
            self.assertEqual(
                controller.get(command["run_id"])["run"]["status"],
                "cancelling",
            )

            recovery = WorkerRecoveryCoordinator(
                workspace / "sf206-recovery.db",
                session_controller=session,
            )
            recovery.initialize()
            case = recovery.reconcile_control(
                command["control_id"],
                at="2026-08-11T01:10:00+00:00",
            )

            self.assertEqual(case["status"], "succeeded")
            current = controller.get(command["run_id"])
            self.assertEqual(current["run"]["status"], "cancelled")
            self.assertEqual(
                current["worker_session"]["status"],
                "cancelled",
            )
            receipt = self._receipt(
                adapter,
                "cancel",
                f"sf203:{command['control_id']}:cancel",
            )
            self.assertEqual(receipt["effect_count"], 1)

    def test_start_effect_missing_external_reference_requires_owner(self) -> None:
        with test_workspace("sf206-start") as workspace:
            (
                _,
                controller,
                aggregate,
                binding,
                adapter,
                session,
            ) = prepared_fixture(workspace)
            command = control_command(
                aggregate,
                binding,
                "start",
                index=2065,
                at="2026-08-11T01:07:00+00:00",
            )
            session.submit(command)
            adapter.arm_crash("start", "after-effect-before-result")
            uncertain = session.execute_once(
                owner_id="sf206-controller",
                at=command["submitted_at"],
            )
            self.assertEqual(uncertain["status"], "uncertain")

            recovery = WorkerRecoveryCoordinator(
                workspace / "sf206-recovery.db",
                session_controller=session,
            )
            recovery.initialize()
            case = recovery.reconcile_control(
                command["control_id"],
                at="2026-08-11T01:08:00+00:00",
            )

            self.assertEqual(case["status"], "owner-required")
            self.assertEqual(case["disposition"], "succeeded")
            self.assertEqual(
                controller.get(command["run_id"])[
                    "worker_session"
                ]["status"],
                "starting",
            )

    def test_one_sweep_reuses_one_worker_recovery_observation(self) -> None:
        with test_workspace("sf206-one-session-recovery") as workspace:
            (
                _,
                _,
                aggregate,
                binding,
                adapter,
                session,
            ) = running_fixture(workspace)
            commands = [
                control_command(
                    aggregate,
                    binding,
                    "prompt",
                    index=2070 + index,
                    payload={"instruction": f"Apply exact change {index}."},
                    at=f"2026-08-11T01:{9 + index:02d}:00+00:00",
                )
                for index in range(2)
            ]
            for command in commands:
                session.submit(command)
                adapter.arm_crash("send", "after-effect-before-result")
                uncertain = session.execute_once(
                    owner_id="sf206-controller",
                    at=command["submitted_at"],
                )
                self.assertEqual(uncertain["status"], "uncertain")

            recovery = WorkerRecoveryCoordinator(
                workspace / "sf206-recovery.db",
                session_controller=session,
            )
            recovery.initialize()
            report = recovery.sweep(
                at="2026-08-11T01:12:00+00:00",
            )

            self.assertEqual(report["counts"]["succeeded"], 2)
            self.assertEqual(
                [case["status"] for case in recovery.list()],
                ["succeeded", "succeeded"],
            )
            with closing(sqlite3.connect(adapter.store_path)) as connection:
                self.assertEqual(
                    connection.execute(
                        """
                        SELECT COUNT(*) FROM receipts
                        WHERE operation = 'recover'
                        """
                    ).fetchone()[0],
                    1,
                )
                self.assertEqual(
                    connection.execute(
                        """
                        SELECT SUM(effect_count) FROM receipts
                        WHERE operation = 'send'
                          AND idempotency_key LIKE 'sf203:%:send'
                        """
                    ).fetchone()[0],
                    2,
                )

    def test_sweep_persists_missing_control_and_workspace_orphans(self) -> None:
        with test_workspace("sf206-orphan-discovery") as workspace:
            (
                _,
                _,
                _,
                _,
                _,
                session,
            ) = running_fixture(workspace)
            recovery = WorkerRecoveryCoordinator(
                workspace / "sf206-recovery.db",
                session_controller=session,
                workspace_manager=_RetainedWorkspace(),
                continuation_scheduler=_OrphanContinuationDependency(),
            )
            recovery.initialize()
            report = recovery.sweep(
                at="2026-08-11T01:12:00+00:00",
            )

            self.assertEqual(
                sorted(orphan["kind"] for orphan in report["orphans"]),
                ["missing-session-control", "workspace-drift"],
            )
            self.assertEqual(recovery.orphans(), report["orphans"])
            self.assertEqual(
                recovery.status()["orphan_counts"],
                {
                    "missing-session-control": 1,
                    "control-identity-drift": 0,
                    "workspace-drift": 1,
                },
            )


if __name__ == "__main__":
    unittest.main()
