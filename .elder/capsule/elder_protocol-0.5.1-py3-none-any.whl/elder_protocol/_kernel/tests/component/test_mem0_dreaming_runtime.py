from __future__ import annotations

import os
import unittest
from pathlib import Path
from unittest.mock import patch

from elder_protocol.activation import activate_session
from elder_protocol.compiler import compile_project
from elder_protocol.constants import ROOT
from elder_protocol.dreaming import (
    execute_dreaming,
    extract_memory_candidates,
    prepare_dreaming_workspace,
)
from elder_protocol.errors import ProtocolError
from elder_protocol.io import json_text, load_json
from elder_protocol.knowledge import KnowledgeStore
from elder_protocol.mem0_adapter import Mem0SemanticMemory
from elder_protocol.memory_config import load_memory_runtime_config
from tests._support import test_workspace


MEMORY_ENV = {
    "AZURE_OPENAI_API_KEY": "test-key",
    "ELDER_AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com",
    "ELDER_AZURE_OPENAI_V1_BASE_URL": (
        "https://example.openai.azure.com/openai/v1"
    ),
    "ELDER_AZURE_OPENAI_API_VERSION": "2024-10-21",
    "ELDER_MEMORY_EXTRACTION_DEPLOYMENT": "gpt-4.1",
    "ELDER_EMBEDDING_DEPLOYMENT": "text-embedding-ada-002",
    "ELDER_EMBEDDING_DIMENSIONS": "1536",
    "ELDER_DREAMING_ROUTINE_DEPLOYMENT": "gpt-5.6-luna",
    "ELDER_DREAMING_ROUTINE_REASONING": "medium",
    "ELDER_DREAMING_ESCALATION_DEPLOYMENT": "gpt-5.6-luna",
    "ELDER_DREAMING_ESCALATION_REASONING": "high",
}


class FakeSemanticMemory:
    def __init__(self) -> None:
        self.closed = False
        self.evidence: list[dict[str, str]] = []

    def remember_evidence(
        self,
        *,
        project_id: str,
        request_id: str,
        evidence: list[dict[str, str]],
    ) -> list[dict[str, str]]:
        self.evidence = evidence
        return [
            {
                "id": "mem0-1",
                "memory": "CLI changes require parser component tests.",
            }
        ]

    def recall(
        self,
        *,
        project_id: str,
        query: str,
        limit: int,
    ) -> list[dict[str, str]]:
        return [
            {
                "id": "mem0-1",
                "memory": "CLI changes require parser component tests.",
            }
        ]

    def close(self) -> None:
        self.closed = True


class FakeLunaProvider:
    def generate(
        self,
        *,
        request: dict,
        evidence: list[dict[str, str]],
        recalled_memories: list[dict],
        mode: str,
    ) -> tuple[dict, dict[str, str]]:
        return (
            {
                "kind": "memory",
                "target_ref": "repository:test-protocol",
                "hypothesis": (
                    "Running parser component tests after CLI changes detects "
                    "argument regressions earlier."
                ),
                "artifact_content": (
                    "Run parser component tests after modifying CLI arguments.\n"
                ),
                "counterexamples": [],
            },
            {"model": "gpt-5.6-luna", "reasoning": "medium"},
        )


class FakeMem0:
    def __init__(self) -> None:
        self.add_calls: list[dict] = []
        self.memories: list[dict] = []

    def add(self, messages, **kwargs):
        self.add_calls.append({"messages": messages, **kwargs})
        if kwargs.get("infer") is False:
            content = (
                messages
                if isinstance(messages, str)
                else messages[0]["content"]
            )
            item = {
                "id": f"trusted-{len(self.memories) + 1}",
                "memory": content,
                "agent_id": kwargs["agent_id"],
                "metadata": dict(kwargs.get("metadata", {})),
            }
            self.memories.append(item)
            return {"results": [item]}
        return {"results": [{"id": "mem0-1", "memory": "Durable fact"}]}

    def search(self, query, **kwargs):
        filters = kwargs.get("filters", {})
        if str(filters.get("agent_id", "")).startswith("elder-build:"):
            return {"results": list(self.memories)}
        return {
            "results": [
                {"id": "mem0-1", "memory": "Durable fact", "score": 0.9}
            ]
        }

    def get_all(self, **kwargs):
        filters = kwargs.get("filters", {})
        agent_id = filters.get("agent_id")
        return {
            "results": [
                item for item in self.memories if item.get("agent_id") == agent_id
            ]
        }

    def delete(self, memory_id):
        self.memories = [
            item for item in self.memories if item["id"] != memory_id
        ]


class Mem0DreamingRuntimeComponentTests(unittest.TestCase):
    def test_memory_configuration_requires_luna_for_both_routes(self) -> None:
        with test_workspace("memory-config") as workspace:
            with patch.dict(os.environ, MEMORY_ENV, clear=False):
                config = load_memory_runtime_config(
                    workspace,
                    env_file=workspace / "missing.env",
                )
            self.assertEqual(config.routine_deployment, "gpt-5.6-luna")
            self.assertEqual(config.escalation_reasoning, "high")
            self.assertNotIn("test-key", str(config.public_summary()))

            invalid = dict(MEMORY_ENV)
            invalid["ELDER_DREAMING_ROUTINE_DEPLOYMENT"] = "gpt-5.4-mini"
            with patch.dict(os.environ, invalid, clear=False):
                with self.assertRaisesRegex(ProtocolError, "requires gpt-5.6-luna"):
                    load_memory_runtime_config(
                        workspace,
                        env_file=workspace / "missing.env",
                    )

    def test_mem0_adapter_builds_local_qdrant_and_azure_configuration(self) -> None:
        captured: list[dict] = []
        fake = FakeMem0()

        def factory(config: dict):
            captured.append(config)
            return fake

        with test_workspace("mem0-config") as workspace:
            with patch.dict(os.environ, MEMORY_ENV, clear=False):
                config = load_memory_runtime_config(
                    workspace,
                    env_file=workspace / "missing.env",
                )
            adapter = Mem0SemanticMemory(
                config,
                workspace,
                memory_factory=factory,
            )
            extracted = adapter.remember_evidence(
                project_id="project",
                request_id="request",
                evidence=[
                    {
                        "id": "evidence-1",
                        "kind": "decision",
                        "content": "SQLite remains authoritative.",
                    }
                ],
            )
            recalled = adapter.recall(
                project_id="project",
                query="memory authority",
            )

            self.assertEqual(extracted[0]["memory"], "Durable fact")
            self.assertEqual(recalled[0]["score"], 0.9)
            self.assertEqual(
                captured[0]["llm"]["config"]["model"],
                "gpt-4.1",
            )
            self.assertEqual(
                captured[0]["embedder"]["config"]["embedding_dims"],
                1536,
            )
            self.assertTrue(
                Path(captured[0]["vector_store"]["config"]["path"]).is_absolute()
            )
            self.assertEqual(
                fake.add_calls[0]["agent_id"],
                "elder:project",
            )

    def test_mem0_adapter_indexes_and_recalls_only_trusted_build_memory(self) -> None:
        fake = FakeMem0()
        with test_workspace("mem0-trusted") as workspace:
            with patch.dict(os.environ, MEMORY_ENV, clear=False):
                config = load_memory_runtime_config(
                    workspace,
                    env_file=workspace / "missing.env",
                )
            adapter = Mem0SemanticMemory(
                config,
                workspace,
                memory_factory=lambda _: fake,
            )
            record = {
                "id": "memory-rule",
                "kind": "procedural",
                "content": "Run component tests after changing CLI parsing.",
                "content_sha256": "a" * 64,
            }
            first = adapter.sync_trusted_memories(
                project_id="project",
                records=[record],
            )
            second = adapter.sync_trusted_memories(
                project_id="project",
                records=[record],
            )
            recalled = adapter.recall_trusted(
                project_id="project",
                query="CLI parsing",
            )

            self.assertEqual(first["indexed"], 1)
            self.assertEqual(second["unchanged"], 1)
            self.assertEqual(
                recalled[0]["metadata"]["elder_memory_id"],
                "memory-rule",
            )
            self.assertFalse(fake.add_calls[0]["infer"])

    def test_execute_dreaming_emits_digest_bound_luna_candidate(self) -> None:
        with test_workspace("dreaming-execute") as workspace:
            project = workspace / "project"
            compile_project(ROOT / "examples" / "minimal-project-profile.json", project)
            activation = activate_session(project, "Review parser regressions")
            activation_path = workspace / "activation.json"
            activation_path.write_text(json_text(activation), encoding="utf-8")
            evidence = workspace / "test-result.txt"
            evidence.write_text("Parser failed after a CLI edit.\n", encoding="utf-8")
            dream_workspace = workspace / "dream"
            prepare_dreaming_workspace(
                project_root=project,
                activation_path=activation_path,
                evidence=[("test-result", evidence)],
                work_item_id="work-parser",
                trigger="repeated-failure",
                workspace=dream_workspace,
            )
            memory = FakeSemanticMemory()
            with patch.dict(os.environ, MEMORY_ENV, clear=False):
                execution = execute_dreaming(
                    project_root=project,
                    workspace=dream_workspace,
                    mode="routine",
                    env_file=workspace / "missing.env",
                    semantic_memory=memory,
                    provider=FakeLunaProvider(),
                )

            candidate = load_json(dream_workspace / "candidate.json")
            self.assertEqual(execution["dreaming_model"], "gpt-5.6-luna")
            self.assertEqual(execution["memory_provider"], "mem0-oss")
            self.assertEqual(candidate["created_by"], "mem0-azure-luna-dreaming")
            self.assertEqual(candidate["status"], "candidate")
            self.assertTrue(memory.closed)
            self.assertTrue(
                (dream_workspace / candidate["artifact_path"]).is_file()
            )

    def test_dreaming_rejects_oversized_evidence_before_provider_use(self) -> None:
        with test_workspace("dreaming-budget") as workspace:
            project = workspace / "project"
            compile_project(ROOT / "examples" / "minimal-project-profile.json", project)
            activation = activate_session(project, "Review bounded evidence")
            activation_path = workspace / "activation.json"
            activation_path.write_text(json_text(activation), encoding="utf-8")
            evidence = workspace / "oversized.txt"
            evidence.write_text("x" * 20_001, encoding="utf-8")

            with self.assertRaisesRegex(ProtocolError, "exceeds 20000 characters"):
                prepare_dreaming_workspace(
                    project_root=project,
                    activation_path=activation_path,
                    evidence=[("trace", evidence)],
                    work_item_id="work-budget",
                    trigger="explicit-user-request",
                    workspace=workspace / "dream",
                )

    def test_mem0_extraction_only_proposes_candidate_memory(self) -> None:
        with test_workspace("memory-extract") as workspace:
            store = KnowledgeStore(workspace / "knowledge.db")
            store.initialize()
            evidence = workspace / "decision.txt"
            evidence.write_text(
                "Elder SQLite remains the authority of record.\n",
                encoding="utf-8",
            )
            memory = FakeSemanticMemory()
            with patch.dict(os.environ, MEMORY_ENV, clear=False):
                report = extract_memory_candidates(
                    store=store,
                    project_root=workspace,
                    namespace="elder-protocol",
                    evidence=[("decision", evidence)],
                    env_file=workspace / "missing.env",
                    semantic_memory=memory,
                )

            self.assertEqual(report["count"], 1)
            record = report["proposed"][0]
            self.assertEqual(record["status"], "candidate")
            self.assertEqual(record["owner"], "mem0-azure-extractor")
            self.assertEqual(
                store.query_memory(
                    "elder-protocol",
                    "parser",
                    statuses=["candidate"],
                )["count"],
                1,
            )


if __name__ == "__main__":
    unittest.main()
