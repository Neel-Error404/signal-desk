from __future__ import annotations

import unittest

from elder_protocol.factory_operations import (
    AuditReplay,
    OwnerInbox,
    OwnerMetrics,
    OwnerPortfolio,
    WorkRoom,
)
from tests._gate_d_support import prepare_environment
from tests._support import test_workspace


class GateDQualificationComponentTests(unittest.TestCase):
    def test_waiting_run_composes_every_owner_read_model(self) -> None:
        with test_workspace("gate-d-component") as workspace:
            environment = prepare_environment(workspace)
            room_service = WorkRoom(
                environment["store_path"],
                environment["session_store_path"],
                workspace_authority=environment["workspace_authority"],
            )
            inbox = OwnerInbox(
                operations_store=environment["store_path"],
                session_store=environment["session_store_path"],
                recovery_store=environment["recovery_store_path"],
            ).snapshot(
                project_filter=environment["project_id"],
                observed_at="2026-08-14T12:00:00+00:00",
            )
            portfolio = OwnerPortfolio(
                environment["store_path"],
            ).snapshot(
                project_ids=[environment["project_id"]],
                project_filter=environment["project_id"],
                observed_at="2026-08-14T12:00:00+00:00",
                limit=100,
            )
            room = room_service.snapshot(
                project_id=environment["project_id"],
                work_item_id=environment["work_item_id"],
                observed_at="2026-08-14T12:00:00+00:00",
            )
            audit = AuditReplay(
                environment["store_path"],
                room_service,
            ).snapshot(
                project_id=environment["project_id"],
                work_item_id=environment["work_item_id"],
                observed_at="2026-08-14T12:00:00+00:00",
            )
            metrics = OwnerMetrics(
                environment["store_path"],
                environment["session_store_path"],
            ).snapshot(
                project_id=environment["project_id"],
                observed_at="2026-08-14T12:00:00+00:00",
            )

            self.assertGreaterEqual(inbox["item_count"], 1)
            self.assertTrue(
                any(
                    item["reason_family"] == "owner-decision"
                    for item in inbox["items"]
                )
            )
            self.assertEqual(portfolio["work_items"][0]["status"], "running")
            self.assertEqual(room["work_item"]["status"], "running")
            self.assertEqual(room["runs"][0]["status"], "waiting")
            self.assertIn("follow-up", room["allowed_inputs"])
            self.assertEqual(audit["replay"]["status"], "verified")
            self.assertEqual(metrics["outcomes"]["by_status"]["running"], 1)
            self.assertEqual(metrics["cost"]["status"], "unavailable")
            self.assertEqual(
                metrics["learning_impact"]["status"],
                "unavailable",
            )


if __name__ == "__main__":
    unittest.main()
