from __future__ import annotations

import base64
import copy
import hashlib
import json
import unittest
from datetime import UTC, datetime, timedelta
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from elder_protocol.autonomy import calculate_effective_autonomy, canonical_sha256
from elder_protocol.autonomy_runtime import (
    canonical_p5_2_readiness,
    create_supervised_pr_packet,
    issue_supervised_pr_lease,
    match_autonomy_work_item,
    replay_certification,
    simulate_autonomy_work_item,
    submit_supervised_pr,
)
from elder_protocol.constants import PROTOCOL_DIR
from elder_protocol.errors import ProtocolError
from elder_protocol.io import load_json
from tests._support import test_workspace
from tests.component import test_p5_0_autonomy as p50
from tests.component.test_p5_0_autonomy import (
    certification,
    incident_budget,
)


def finalize(record: dict) -> dict:
    record["content_sha256"] = canonical_sha256(record)
    return record


def signed_hosted_git_evidence(
    private_key: Ed25519PrivateKey,
    *,
    evaluated_at: datetime,
    git_object_format: str = "sha1",
    pull_request_url_prefix: str = (
        "https://git.example.test/fixture/project/pull/"
    ),
) -> dict:
    oid_length = 40 if git_object_format == "sha1" else 64
    evidence = {
        "version": "0.5.1",
        "evidence_id": "HOSTED-GIT-001",
        "project_id": "fixture-project",
        "provider": "fixture-ci",
        "repository": "fixture/project",
        "pull_request_url_prefix": pull_request_url_prefix,
        "git_object_format": git_object_format,
        "base_branch": "main",
        "head_branch": "work/docs-correction-001",
        "base_revision": "3" * oid_length,
        "head_revision": "4" * oid_length,
        "diff_sha256": "5" * 64,
        "workspace": "/isolated/worktrees/docs-correction-001",
        "changed_paths": ["docs/user-guide.md"],
        "changes": [
            {
                "path": "docs/user-guide.md",
                "operation": "modify",
                "before_sha256": "1" * 64,
                "after_sha256": "2" * 64,
            }
        ],
        "test_results": [
            {
                "level": level,
                "status": "passed",
                "command": ["py", "-m", "unittest", level],
                "evidence_sha256": str(index) * 64,
            }
            for index, level in enumerate(
                ["Foundation", "Component", "Integration", "Workflow", "Stress"],
                start=1,
            )
        ],
        "executor_id": "fixture-executor",
        "evaluator_id": "fixture-independent-evaluator",
        "independent_evaluation": {
            "status": "passed",
            "report_sha256": "6" * 64,
        },
        "controls": {
            "remote-present": "verified",
            "protected-base-branch": "verified",
            "required-checks": "verified",
            "signed-provenance": "verified",
            "external-identity": "verified",
            "isolated-workspace": "verified",
            "ordered-tests": "verified",
            "independent-evaluation": "verified",
        },
        "producer_identity": "fixture-hosted-git-service",
        "source_uri": "https://ci.example.test/repositories/fixture/project/pulls/42",
        "issued_at": evaluated_at.isoformat(),
        "expires_at": (evaluated_at + timedelta(minutes=20)).isoformat(),
    }
    statement = json.dumps(
        evidence,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    evidence["attestation"] = {
        "signer_id": "verifier-key-1",
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement)
        ).decode("ascii"),
    }
    return finalize(evidence)


def signed_authority_evidence(
    private_key: Ed25519PrivateKey,
    *,
    chain: dict,
    registry: dict,
    change_classes: dict,
    evaluated_at: datetime,
    project_autonomy_ceiling: str = "L2",
) -> dict:
    context = chain["context"]
    evidence = {
        "version": "0.5.1",
        "evidence_id": "AUTHORITY-EVIDENCE-001",
        "authority_source_id": chain["authority_source"]["id"],
        "authority_source_sha256": canonical_sha256(chain["authority_source"]),
        "project_id": chain["work_item"]["project_id"],
        "autonomy_class_id": chain["work_item"]["autonomy_class_id"],
        "certification_id": chain["certification"]["certification_id"],
        "provider": "fixture-ci",
        "producer_identity": "fixture-autonomy-governance-service",
        "source_uri": "https://ci.example.test/governance/authority/001",
        "issued_at": evaluated_at.isoformat(),
        "expires_at": (evaluated_at + timedelta(minutes=30)).isoformat(),
        "autonomy_policy_sha256": canonical_sha256(chain["policy"]),
        "autonomy_classes_sha256": canonical_sha256(registry),
        "change_classes_sha256": canonical_sha256(change_classes),
        "qualification_policy_sha256": canonical_sha256(
            context["qualification_policy"]
        ),
        "maturity_model_sha256": canonical_sha256(context["maturity_model"]),
        "project_autonomy_ceiling": project_autonomy_ceiling,
        "work_item_sha256": chain["work_item"]["content_sha256"],
        "certification_sha256": chain["certification"]["content_sha256"],
        "certification_event_sha256s": [
            event_record["content_sha256"]
            for event_record in chain["certification_events"]
        ],
        "certification_replay_sha256": chain["certification_replay"][
            "content_sha256"
        ],
        "qualification_consumption_sha256": chain["consumption"][
            "content_sha256"
        ],
        "incident_budget_sha256": chain["budget"]["content_sha256"],
        "suspension_sha256s": [
            record["content_sha256"]
            for record in chain.get("suspensions", [])
        ],
        "revocation_sha256s": [
            record["content_sha256"]
            for record in chain.get("revocations", [])
        ],
        "qualification_state_checks_sha256": canonical_sha256(
            context["state_checks"]
        ),
        "artifact_sha256": context["artifact_sha256"],
        "effective_autonomy_sha256": chain["effective"]["content_sha256"],
        "match_report_sha256": chain["match"]["content_sha256"],
        "simulation_report_sha256": chain["simulation"]["content_sha256"],
    }
    statement = json.dumps(
        evidence,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    evidence["attestation"] = {
        "signer_id": "verifier-key-1",
        "algorithm": "ed25519",
        "signed_statement_sha256": hashlib.sha256(statement).hexdigest(),
        "signature_base64": base64.b64encode(
            private_key.sign(statement)
        ).decode("ascii"),
    }
    return finalize(evidence)


def documentation_work_item(*, checks_passed: bool = True) -> dict:
    status = "passed" if checks_passed else "planned"
    evidence = ["simulation-evidence"] if checks_passed else []
    return finalize(
        {
            "version": "0.5.1",
            "work_item_id": "docs-correction-001",
            "project_id": "fixture-project",
            "parent_change_class": "documentation",
            "autonomy_class_id": "documentation-only-correction",
            "objective": "Correct a broken link in the user guide.",
            "changes": [
                {
                    "path": "docs/user-guide.md",
                    "operation": "modify",
                    "existed_before": True,
                    "generated": False,
                    "production_code": False,
                    "test_support": False,
                    "generator_input": False,
                    "fixture": False,
                    "snapshot": False,
                    "configuration": False,
                    "before_sha256": "1" * 64,
                    "after_sha256": "2" * 64,
                }
            ],
            "tool": {
                "id": "text-editor",
                "digest_sha256": None,
                "rule_ids": [],
            },
            "checks": [
                {"name": name, "status": status, "evidence": evidence}
                for name in [
                    "path classification",
                    "generated ownership check",
                    "link validation",
                    "reader review",
                ]
            ],
            "observed_effects": [],
            "generator_inputs_unchanged": True,
            "semantic_equivalence": {
                "mode": "none",
                "status": "not-required",
                "evidence": [],
            },
            "evidence_plan": ["Run link validation and independent reader review."],
        }
    )


def event(
    certification_record: dict,
    *,
    sequence: int,
    event_type: str,
    occurred_at: datetime,
    previous: str | None,
    payload: dict,
) -> dict:
    return finalize(
        {
            "version": "0.5.1",
            "event_id": f"EVENT-{sequence:03d}",
            "certification_id": certification_record["certification_id"],
            "autonomy_class_id": certification_record["autonomy_class_id"],
            "sequence": sequence,
            "event_type": event_type,
            "occurred_at": occurred_at.isoformat(),
            "actor_id": (
                "fixture-human-owner"
                if event_type in {"issued", "activated", "suspended"}
                else "fixture-executor"
            ),
            "actor_role": (
                "human-owner"
                if event_type in {"issued", "activated", "suspended"}
                else "executor"
            ),
            "payload": payload,
            "evidence": [f"evidence:{sequence}"],
            "previous_event_sha256": previous,
        }
    )


class RecordingSubmitter:
    def __init__(self, response_overrides: dict | None = None) -> None:
        self.packet: dict | None = None
        self.response_overrides = response_overrides or {}

    def submit(self, packet: dict) -> dict:
        self.packet = packet
        response = {
            field: packet[field]
            for field in [
                "provider",
                "repository",
                "git_object_format",
                "base_branch",
                "head_branch",
                "base_revision",
                "head_revision",
                "diff_sha256",
            ]
        }
        response.update(
            {
                "authorized_packet_sha256": packet["content_sha256"],
                "pull_request_id": "42",
                "url": "https://git.example.test/fixture/project/pull/42",
                "status": "open",
            }
        )
        response.update(self.response_overrides)
        return response


class P51P52AutonomyComponentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = load_json(PROTOCOL_DIR / "autonomy-classes.json")
        self.change_classes = load_json(PROTOCOL_DIR / "change-classes.json")
        self.fixture = p50.P50AutonomyComponentTests()
        self._authority_source: dict | None = None
        self._authority_source_patcher = patch(
            "elder_protocol.autonomy_runtime._load_canonical_autonomy_authority",
            side_effect=self._load_fixture_authority,
        )
        self._authority_source_patcher.start()
        self.addCleanup(self._authority_source_patcher.stop)

    def _load_fixture_authority(self, project_id: str) -> tuple[dict, dict]:
        if self._authority_source is None:
            raise ProtocolError("Fixture canonical authority source is not configured.")
        matches = [
            project
            for project in self._authority_source["projects"]
            if project["project_id"] == project_id and project["status"] == "active"
        ]
        if len(matches) != 1:
            raise ProtocolError("Fixture project has no canonical authority source.")
        return self._authority_source, matches[0]

    def qualified_records(
        self,
        workspace,
        *,
        evaluated_at: datetime,
    ) -> tuple[dict, dict, dict, dict, dict]:
        context = self.fixture.qualification_context(
            workspace,
            evaluated_at=evaluated_at,
        )
        policy = context["autonomy_policy"]
        consumption = context["consumption"]
        certification_record = certification(
            consumption,
            issued_at=evaluated_at - timedelta(minutes=5),
        )
        budget = incident_budget(
            started_at=evaluated_at - timedelta(minutes=5)
        )
        return policy, consumption, certification_record, budget, context

    def authority_inputs(self, workspace, *, evaluated_at: datetime) -> dict:
        policy, consumption, certification_record, budget, context = (
            self.qualified_records(workspace, evaluated_at=evaluated_at)
        )
        work_item = documentation_work_item()
        match = match_autonomy_work_item(
            work_item,
            self.registry,
            certification=certification_record,
            policy=policy,
        )
        simulation = simulate_autonomy_work_item(
            work_item,
            self.registry,
            certification=certification_record,
            policy=policy,
        )
        effective = calculate_effective_autonomy(
            policy,
            self.registry,
            self.change_classes,
            project_id=work_item["project_id"],
            project_autonomy_ceiling="L2",
            autonomy_class_id=work_item["autonomy_class_id"],
            certification=certification_record,
            qualification_consumption=consumption,
            incident_budget=budget,
            suspensions=[],
            revocations=[],
            at=evaluated_at.isoformat(),
        )
        issued = event(
            certification_record,
            sequence=1,
            event_type="issued",
            occurred_at=evaluated_at - timedelta(minutes=5),
            previous=None,
            payload={
                "certification_sha256": certification_record["content_sha256"],
                "initial_status": "candidate",
            },
        )
        activated = event(
            certification_record,
            sequence=2,
            event_type="activated",
            occurred_at=evaluated_at - timedelta(minutes=4),
            previous=issued["content_sha256"],
            payload={
                "qualification_consumption_sha256": consumption["content_sha256"]
            },
        )
        certification_events = [issued, activated]
        certification_replay = replay_certification(
            certification_record,
            self.registry["classes"][0],
            certification_events,
            policy=policy,
            at=evaluated_at.isoformat(),
        )
        chain = {
            "policy": policy,
            "consumption": consumption,
            "certification": certification_record,
            "budget": budget,
            "context": context,
            "work_item": work_item,
            "match": match,
            "simulation": simulation,
            "effective": effective,
            "certification_events": certification_events,
            "certification_replay": certification_replay,
        }
        chain["authority_source"] = {
            "version": "0.5.1",
            "id": "elder-canonical-autonomy-authority-source-v1",
            "projects": [
                {
                    "project_id": chain["work_item"]["project_id"],
                    "project_autonomy_ceiling": "L2",
                    "autonomy_policy_sha256": canonical_sha256(chain["policy"]),
                    "autonomy_classes_sha256": canonical_sha256(self.registry),
                    "change_classes_sha256": canonical_sha256(
                        self.change_classes
                    ),
                    "qualification_policy_sha256": canonical_sha256(
                        context["qualification_policy"]
                    ),
                    "maturity_model_sha256": canonical_sha256(
                        context["maturity_model"]
                    ),
                    "status": "active",
                }
            ],
        }
        self._authority_source = chain["authority_source"]
        chain["authority_evidence"] = signed_authority_evidence(
            context["private_key"],
            chain=chain,
            registry=self.registry,
            change_classes=self.change_classes,
            evaluated_at=evaluated_at,
        )
        return chain

    def issue_lease(
        self,
        chain: dict,
        *,
        evaluated_at: datetime,
        **overrides,
    ) -> dict:
        context = chain["context"]
        arguments = {
            "work_item": chain["work_item"],
            "registry": self.registry,
            "change_classes": self.change_classes,
            "project_autonomy_ceiling": "L2",
            "certification": chain["certification"],
            "certification_events": chain["certification_events"],
            "certification_replay_report": chain["certification_replay"],
            "qualification_consumption": chain["consumption"],
            "incident_budget": chain["budget"],
            "suspensions": [],
            "revocations": [],
            "authority_evidence": chain["authority_evidence"],
            "qualification_manifest_path": context["manifest"],
            "qualification_policy": context["qualification_policy"],
            "maturity_model": context["maturity_model"],
            "qualification_state_checks": context["state_checks"],
            "artifact_sha256": context["artifact_sha256"],
            "effective_autonomy_report": chain["effective"],
            "match_report": chain["match"],
            "simulation_report": chain["simulation"],
            "at": evaluated_at.isoformat(),
        }
        arguments.update(overrides)
        selected_policy = arguments.pop("policy", chain["policy"])
        return issue_supervised_pr_lease(selected_policy, **arguments)

    def supervised_execution(
        self,
        work_item: dict,
        lease: dict,
        *,
        context: dict,
        evaluated_at: datetime,
        git_object_format: str = "sha1",
        pull_request_url_prefix: str = (
            "https://git.example.test/fixture/project/pull/"
        ),
    ) -> dict:
        hosted_git_evidence = signed_hosted_git_evidence(
            context["private_key"],
            evaluated_at=evaluated_at,
            git_object_format=git_object_format,
            pull_request_url_prefix=pull_request_url_prefix,
        )
        return finalize(
            {
                "version": "0.5.1",
                "execution_id": "EXEC-001",
                "project_id": work_item["project_id"],
                "work_item_id": work_item["work_item_id"],
                "lease_sha256": lease["content_sha256"],
                "workspace": hosted_git_evidence["workspace"],
                "git_object_format": hosted_git_evidence["git_object_format"],
                "base_revision": hosted_git_evidence["base_revision"],
                "head_revision": hosted_git_evidence["head_revision"],
                "base_branch": hosted_git_evidence["base_branch"],
                "head_branch": hosted_git_evidence["head_branch"],
                "changed_paths": copy.deepcopy(
                    hosted_git_evidence["changed_paths"]
                ),
                "changes": copy.deepcopy(hosted_git_evidence["changes"]),
                "diff_sha256": hosted_git_evidence["diff_sha256"],
                "test_results": copy.deepcopy(hosted_git_evidence["test_results"]),
                "executor_id": hosted_git_evidence["executor_id"],
                "evaluator_id": hosted_git_evidence["evaluator_id"],
                "independent_evaluation": copy.deepcopy(
                    hosted_git_evidence["independent_evaluation"]
                ),
                "hosted_git_evidence": hosted_git_evidence,
                "evidence": ["tests:ordered", "evaluation:independent"],
            }
        )

    def submit_chain(
        self,
        chain: dict,
        lease: dict,
        execution: dict,
        packet: dict,
        submitter: RecordingSubmitter,
        *,
        at: datetime,
        current_state_checks: dict | None = None,
    ) -> dict:
        context = chain["context"]
        return submit_supervised_pr(
            packet,
            submitter,
            policy=chain["policy"],
            work_item=chain["work_item"],
            authority_lease=lease,
            execution=execution,
            registry=self.registry,
            change_classes=self.change_classes,
            project_autonomy_ceiling="L2",
            certification=chain["certification"],
            certification_events=chain["certification_events"],
            certification_replay_report=chain["certification_replay"],
            qualification_consumption=chain["consumption"],
            incident_budget=chain["budget"],
            suspensions=[],
            revocations=[],
            qualification_manifest_path=context["manifest"],
            qualification_policy=context["qualification_policy"],
            maturity_model=context["maturity_model"],
            lease_qualification_state_checks=context["state_checks"],
            current_qualification_state_checks=(
                current_state_checks or context["state_checks"]
            ),
            artifact_sha256=context["artifact_sha256"],
            effective_autonomy_report=chain["effective"],
            match_report=chain["match"],
            simulation_report=chain["simulation"],
            authority_evidence=chain["authority_evidence"],
            at=at.isoformat(),
        )

    def test_p5_1_matches_and_simulates_without_side_effects(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-1-simulation") as workspace:
            policy, _, certification_record, _, _ = self.qualified_records(
                workspace,
                evaluated_at=evaluated_at,
            )
            work_item = documentation_work_item()
            match = match_autonomy_work_item(
                work_item,
                self.registry,
                certification=certification_record,
                policy=policy,
            )
            simulation = simulate_autonomy_work_item(
                work_item,
                self.registry,
                certification=certification_record,
                policy=policy,
            )

        self.assertTrue(match["matched"])
        self.assertEqual(match["blockers"], [])
        self.assertTrue(match["simulation_only"])
        self.assertEqual(simulation["status"], "passed")
        self.assertEqual(simulation["side_effects_performed"], [])
        self.assertFalse(simulation["authority_activated"])
        self.assertFalse(simulation["can_create_pr"])

    def test_p5_1_rejects_forbidden_scope_and_incomplete_checks(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-1-rejection") as workspace:
            policy, _, certification_record, _, _ = self.qualified_records(
                workspace,
                evaluated_at=evaluated_at,
            )
            certification_record = copy.deepcopy(certification_record)
            certification_record["scope_paths"] = ["**/*.md"]
            certification_record["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in certification_record.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "wildcard"):
                simulate_autonomy_work_item(
                    documentation_work_item(),
                    self.registry,
                    certification=certification_record,
                    policy=policy,
                )
            certification_record["scope_paths"] = ["AGENTS.md"]
            certification_record["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in certification_record.items()
                    if key != "content_sha256"
                }
            )
            work_item = documentation_work_item(checks_passed=False)
            work_item["changes"][0]["path"] = "AGENTS.md"
            work_item["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in work_item.items()
                    if key != "content_sha256"
                }
            )
            simulation = simulate_autonomy_work_item(
                work_item,
                self.registry,
                certification=certification_record,
                policy=policy,
            )

        self.assertEqual(simulation["status"], "blocked")
        self.assertIn("forbidden-path:AGENTS.md", simulation["blockers"])
        self.assertIn(
            "check-not-passed:link validation",
            simulation["blockers"],
        )

    def test_p5_1_replay_accounts_incidents_and_requires_suspension(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-1-replay") as workspace:
            policy, _, certification_record, _, _ = self.qualified_records(
                workspace,
                evaluated_at=evaluated_at,
            )
        issued = event(
            certification_record,
            sequence=1,
            event_type="issued",
            occurred_at=evaluated_at - timedelta(minutes=5),
            previous=None,
            payload={
                "certification_sha256": certification_record["content_sha256"],
                "initial_status": "candidate",
            },
        )
        activated = event(
            certification_record,
            sequence=2,
            event_type="activated",
            occurred_at=evaluated_at - timedelta(minutes=4),
            previous=issued["content_sha256"],
            payload={"qualification_consumption_sha256": "a" * 64},
        )
        incident = event(
            certification_record,
            sequence=3,
            event_type="incident-recorded",
            occurred_at=evaluated_at - timedelta(minutes=1),
            previous=activated["content_sha256"],
            payload={"incident_id": "INC-001"},
        )
        autonomy_class = self.registry["classes"][0]
        report = replay_certification(
            certification_record,
            autonomy_class,
            [incident, issued, activated],
            policy=policy,
            at=evaluated_at.isoformat(),
        )

        self.assertEqual(report["derived_status"], "active")
        self.assertEqual(report["incident_count"], 1)
        self.assertTrue(report["incident_budget_exhausted"])
        self.assertTrue(report["suspension_required"])
        self.assertFalse(report["authority_activated"])

        tampered = copy.deepcopy(incident)
        tampered["previous_event_sha256"] = "f" * 64
        tampered["content_sha256"] = canonical_sha256(
            {
                key: value
                for key, value in tampered.items()
                if key != "content_sha256"
            }
        )
        with self.assertRaisesRegex(ProtocolError, "hash chain"):
            replay_certification(
                certification_record,
                autonomy_class,
                [issued, activated, tampered],
                policy=policy,
                at=evaluated_at.isoformat(),
            )

    def test_p5_1_rejects_future_certification_events(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-1-future-event") as workspace:
            policy, _, certification_record, _, _ = self.qualified_records(
                workspace,
                evaluated_at=evaluated_at,
            )
        issued = event(
            certification_record,
            sequence=1,
            event_type="issued",
            occurred_at=evaluated_at - timedelta(minutes=1),
            previous=None,
            payload={
                "certification_sha256": certification_record["content_sha256"],
                "initial_status": "candidate",
            },
        )
        future_activation = event(
            certification_record,
            sequence=2,
            event_type="activated",
            occurred_at=evaluated_at + timedelta(days=2),
            previous=issued["content_sha256"],
            payload={"qualification_consumption_sha256": "a" * 64},
        )
        with self.assertRaisesRegex(ProtocolError, "after its evaluation time"):
            replay_certification(
                certification_record,
                self.registry["classes"][0],
                [issued, future_activation],
                policy=policy,
                at=evaluated_at.isoformat(),
            )

    def test_p5_2_issues_bounded_lease_and_submits_supervised_pr(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-2-supervised-pr") as workspace:
            chain = self.authority_inputs(workspace, evaluated_at=evaluated_at)
            policy = chain["policy"]
            consumption = chain["consumption"]
            certification_record = chain["certification"]
            budget = chain["budget"]
            context = chain["context"]
            work_item = chain["work_item"]
            match = chain["match"]
            simulation = chain["simulation"]
            effective = chain["effective"]
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            execution = self.supervised_execution(
                work_item,
                lease,
                context=context,
                evaluated_at=evaluated_at,
            )
            packet = create_supervised_pr_packet(
                policy,
                work_item=work_item,
                authority_lease=lease,
                authority_evidence=chain["authority_evidence"],
                execution=execution,
                qualification_policy=context["qualification_policy"],
                registry=self.registry,
                change_classes=self.change_classes,
                maturity_model=context["maturity_model"],
                title="Correct user-guide link",
                body="Bounded documentation correction with ordered evidence.",
                at=evaluated_at.isoformat(),
            )
            submitter = RecordingSubmitter()
            response = submit_supervised_pr(
                packet,
                submitter,
                policy=policy,
                work_item=work_item,
                authority_lease=lease,
                execution=execution,
                registry=self.registry,
                change_classes=self.change_classes,
                project_autonomy_ceiling="L2",
                certification=certification_record,
                certification_events=chain["certification_events"],
                certification_replay_report=chain["certification_replay"],
                qualification_consumption=consumption,
                incident_budget=budget,
                suspensions=[],
                revocations=[],
                qualification_manifest_path=context["manifest"],
                qualification_policy=context["qualification_policy"],
                maturity_model=context["maturity_model"],
                lease_qualification_state_checks=context["state_checks"],
                current_qualification_state_checks=context["state_checks"],
                artifact_sha256=context["artifact_sha256"],
                effective_autonomy_report=effective,
                match_report=match,
                simulation_report=simulation,
                authority_evidence=chain["authority_evidence"],
                at=evaluated_at.isoformat(),
            )

        self.assertTrue(lease["can_create_pr"])
        self.assertFalse(lease["can_merge"])
        self.assertFalse(lease["can_deploy"])
        self.assertEqual(packet["status"], "ready")
        self.assertTrue(packet["requires_human_merge"])
        self.assertTrue(packet["requires_human_release"])
        self.assertEqual(response["status"], "open")
        self.assertEqual(submitter.packet["content_sha256"], packet["content_sha256"])
        for field in [
            "repository",
            "base_branch",
            "head_branch",
            "head_revision",
            "diff_sha256",
        ]:
            self.assertEqual(response[field], packet[field])

    def test_p5_2_accepts_sha256_git_provider_response(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-2-sha256-provider") as workspace:
            chain = self.authority_inputs(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            execution = self.supervised_execution(
                chain["work_item"],
                lease,
                context=chain["context"],
                evaluated_at=evaluated_at,
                git_object_format="sha256",
            )
            packet = create_supervised_pr_packet(
                chain["policy"],
                work_item=chain["work_item"],
                authority_lease=lease,
                authority_evidence=chain["authority_evidence"],
                execution=execution,
                qualification_policy=chain["context"]["qualification_policy"],
                registry=self.registry,
                change_classes=self.change_classes,
                maturity_model=chain["context"]["maturity_model"],
                title="Correct user-guide link",
                body="Bounded documentation correction with ordered evidence.",
                at=evaluated_at.isoformat(),
            )
            response = self.submit_chain(
                chain,
                lease,
                execution,
                packet,
                RecordingSubmitter(),
                at=evaluated_at,
            )

        self.assertEqual(response["git_object_format"], "sha256")
        self.assertEqual(len(response["base_revision"]), 64)
        self.assertEqual(len(response["head_revision"]), 64)
        self.assertEqual(
            response["url"],
            "https://git.example.test/fixture/project/pull/42",
        )

    def test_p5_2_rejects_untrusted_hosted_state_and_mismatched_pr_response(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-2-hosted-evidence") as workspace:
            chain = self.authority_inputs(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            execution = self.supervised_execution(
                chain["work_item"],
                lease,
                context=chain["context"],
                evaluated_at=evaluated_at,
            )

            forged_execution = copy.deepcopy(execution)
            forged_execution["hosted_git_evidence"]["repository"] = "attacker/project"
            forged_execution["hosted_git_evidence"][
                "pull_request_url_prefix"
            ] = "https://git.example.test/attacker/project/pull/"
            forged_execution["hosted_git_evidence"]["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in forged_execution["hosted_git_evidence"].items()
                    if key != "content_sha256"
                }
            )
            forged_execution["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in forged_execution.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "signed statement digest"):
                create_supervised_pr_packet(
                    chain["policy"],
                    work_item=chain["work_item"],
                    authority_lease=lease,
                    authority_evidence=chain["authority_evidence"],
                    execution=forged_execution,
                    qualification_policy=chain["context"]["qualification_policy"],
                    registry=self.registry,
                    change_classes=self.change_classes,
                    maturity_model=chain["context"]["maturity_model"],
                    title="Correct user-guide link",
                    body="Bounded documentation correction with ordered evidence.",
                    at=evaluated_at.isoformat(),
                )

            invalid_revision = copy.deepcopy(execution)
            invalid_revision["head_revision"] = "4" * 64
            invalid_revision["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in invalid_revision.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "full sha1 Git object id"):
                create_supervised_pr_packet(
                    chain["policy"],
                    work_item=chain["work_item"],
                    authority_lease=lease,
                    authority_evidence=chain["authority_evidence"],
                    execution=invalid_revision,
                    qualification_policy=chain["context"]["qualification_policy"],
                    registry=self.registry,
                    change_classes=self.change_classes,
                    maturity_model=chain["context"]["maturity_model"],
                    title="Correct user-guide link",
                    body="Bounded documentation correction with ordered evidence.",
                    at=evaluated_at.isoformat(),
                )

            malicious_prefix_execution = self.supervised_execution(
                chain["work_item"],
                lease,
                context=chain["context"],
                evaluated_at=evaluated_at,
                pull_request_url_prefix=(
                    "https://git.example.test/not-authorized/"
                    "fixture/project/pull/"
                ),
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "bound to the authorized repository",
            ):
                create_supervised_pr_packet(
                    chain["policy"],
                    work_item=chain["work_item"],
                    authority_lease=lease,
                    authority_evidence=chain["authority_evidence"],
                    execution=malicious_prefix_execution,
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    registry=self.registry,
                    change_classes=self.change_classes,
                    maturity_model=chain["context"]["maturity_model"],
                    title="Correct user-guide link",
                    body="Bounded documentation correction with ordered evidence.",
                    at=evaluated_at.isoformat(),
                )

            packet = create_supervised_pr_packet(
                chain["policy"],
                work_item=chain["work_item"],
                authority_lease=lease,
                authority_evidence=chain["authority_evidence"],
                execution=execution,
                qualification_policy=chain["context"]["qualification_policy"],
                registry=self.registry,
                change_classes=self.change_classes,
                maturity_model=chain["context"]["maturity_model"],
                title="Correct user-guide link",
                body="Bounded documentation correction with ordered evidence.",
                at=evaluated_at.isoformat(),
            )
            uri_submitter = RecordingSubmitter({"url": "not-a-uri"})
            with self.assertRaisesRegex(ProtocolError, "HTTPS URI"):
                self.submit_chain(
                    chain,
                    lease,
                    execution,
                    packet,
                    uri_submitter,
                    at=evaluated_at,
                )
            unrelated_uri_submitter = RecordingSubmitter(
                {
                    "url": (
                        "https://attacker.example/not-the-authorized-"
                        "repository/42"
                    )
                }
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "authorized repository URL",
            ):
                self.submit_chain(
                    chain,
                    lease,
                    execution,
                    packet,
                    unrelated_uri_submitter,
                    at=evaluated_at,
                )
            digest_submitter = RecordingSubmitter(
                {"authorized_packet_sha256": "0" * 64}
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "authorized packet digest",
            ):
                self.submit_chain(
                    chain,
                    lease,
                    execution,
                    packet,
                    digest_submitter,
                    at=evaluated_at,
                )
            for field, mismatch in [
                ("repository", "attacker/project"),
                ("head_branch", "work/other-change"),
                ("head_revision", "9" * 40),
                ("diff_sha256", "9" * 64),
            ]:
                with self.subTest(field=field):
                    submitter = RecordingSubmitter({field: mismatch})
                    with self.assertRaisesRegex(
                        ProtocolError,
                        f"response {field} does not match authorized packet",
                    ):
                        self.submit_chain(
                            chain,
                            lease,
                            execution,
                            packet,
                            submitter,
                            at=evaluated_at,
                        )

    def test_p5_2_rejects_forged_authority_evidence_and_structural_lease(
        self,
    ) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-2-authority-evidence") as workspace:
            chain = self.authority_inputs(workspace, evaluated_at=evaluated_at)
            forged_evidence = signed_authority_evidence(
                chain["context"]["private_key"],
                chain=chain,
                registry=self.registry,
                change_classes=self.change_classes,
                evaluated_at=evaluated_at,
                project_autonomy_ceiling="L5",
            )
            with self.assertRaisesRegex(ProtocolError, "canonical truth"):
                self.issue_lease(
                    chain,
                    evaluated_at=evaluated_at,
                    project_autonomy_ceiling="L5",
                    authority_evidence=forged_evidence,
                )
            caller_policy = copy.deepcopy(chain["policy"])
            caller_policy["supervised_pr"]["lease_ttl_minutes"] = 45
            caller_chain = {**chain, "policy": caller_policy}
            caller_evidence = signed_authority_evidence(
                chain["context"]["private_key"],
                chain=caller_chain,
                registry=self.registry,
                change_classes=self.change_classes,
                evaluated_at=evaluated_at,
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "Configured autonomy_policy_sha256 does not match canonical",
            ):
                self.issue_lease(
                    chain,
                    evaluated_at=evaluated_at,
                    policy=caller_policy,
                    authority_evidence=caller_evidence,
                )

            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            execution = self.supervised_execution(
                chain["work_item"],
                lease,
                context=chain["context"],
                evaluated_at=evaluated_at,
            )
            forged_lease = copy.deepcopy(lease)
            forged_lease["certification_id"] = "FABRICATED-CERT"
            forged_lease["certification_sha256"] = "9" * 64
            forged_lease["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in forged_lease.items()
                    if key != "content_sha256"
                }
            )
            forged_execution = copy.deepcopy(execution)
            forged_execution["lease_sha256"] = forged_lease["content_sha256"]
            forged_execution["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in forged_execution.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "authority-evidence-certification",
            ):
                create_supervised_pr_packet(
                    chain["policy"],
                    work_item=chain["work_item"],
                    authority_lease=forged_lease,
                    authority_evidence=chain["authority_evidence"],
                    execution=forged_execution,
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    registry=self.registry,
                    change_classes=self.change_classes,
                    maturity_model=chain["context"]["maturity_model"],
                    title="Correct user-guide link",
                    body="Bounded documentation correction with ordered evidence.",
                    at=evaluated_at.isoformat(),
                )
            extended_lease = copy.deepcopy(lease)
            extended_lease["expires_at"] = (
                evaluated_at + timedelta(hours=2)
            ).isoformat()
            extended_lease["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in extended_lease.items()
                    if key != "content_sha256"
                }
            )
            extended_execution = copy.deepcopy(execution)
            extended_execution["lease_sha256"] = extended_lease["content_sha256"]
            extended_execution["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in extended_execution.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "lease-exceeds"):
                create_supervised_pr_packet(
                    chain["policy"],
                    work_item=chain["work_item"],
                    authority_lease=extended_lease,
                    authority_evidence=chain["authority_evidence"],
                    execution=extended_execution,
                    qualification_policy=chain["context"][
                        "qualification_policy"
                    ],
                    registry=self.registry,
                    change_classes=self.change_classes,
                    maturity_model=chain["context"]["maturity_model"],
                    title="Correct user-guide link",
                    body="Bounded documentation correction with ordered evidence.",
                    at=evaluated_at.isoformat(),
                )

    def test_p5_2_rejects_fabricated_reports_and_foreign_qualification(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-2-fabricated-lease") as workspace:
            chain = self.authority_inputs(
                workspace,
                evaluated_at=evaluated_at,
            )
            fabricated_effective = copy.deepcopy(chain["effective"])
            fabricated_effective["project_id"] = "other-project"
            fabricated_effective["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in fabricated_effective.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "trusted-source recomputation"):
                self.issue_lease(
                    chain,
                    evaluated_at=evaluated_at,
                    effective_autonomy_report=fabricated_effective,
                )

            fabricated_replay = copy.deepcopy(chain["certification_replay"])
            fabricated_replay["event_count"] = 99
            fabricated_replay["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in fabricated_replay.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "trusted-source recomputation"):
                self.issue_lease(
                    chain,
                    evaluated_at=evaluated_at,
                    certification_replay_report=fabricated_replay,
                )

            foreign_consumption = copy.deepcopy(chain["consumption"])
            foreign_consumption["project_id"] = "other-project"
            foreign_consumption["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in foreign_consumption.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(ProtocolError, "signed-bundle re-verification"):
                self.issue_lease(
                    chain,
                    evaluated_at=evaluated_at,
                    qualification_consumption=foreign_consumption,
                )

    def test_p5_2_submission_rejects_fabricated_packet_before_provider(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-2-fabricated-packet") as workspace:
            chain = self.authority_inputs(
                workspace,
                evaluated_at=evaluated_at,
            )
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            execution = self.supervised_execution(
                chain["work_item"],
                lease,
                context=chain["context"],
                evaluated_at=evaluated_at,
            )
            packet = create_supervised_pr_packet(
                chain["policy"],
                work_item=chain["work_item"],
                authority_lease=lease,
                authority_evidence=chain["authority_evidence"],
                execution=execution,
                qualification_policy=chain["context"]["qualification_policy"],
                registry=self.registry,
                change_classes=self.change_classes,
                maturity_model=chain["context"]["maturity_model"],
                title="Correct user-guide link",
                body="Bounded documentation correction with ordered evidence.",
                at=evaluated_at.isoformat(),
            )
            fabricated = copy.deepcopy(packet)
            fabricated["certification_id"] = "FABRICATED-CERT"
            fabricated["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in fabricated.items()
                    if key != "content_sha256"
                }
            )
            submitter = RecordingSubmitter()
            context = chain["context"]
            with self.assertRaisesRegex(ProtocolError, "does not match"):
                submit_supervised_pr(
                    fabricated,
                    submitter,
                    policy=chain["policy"],
                    work_item=chain["work_item"],
                    authority_lease=lease,
                    execution=execution,
                    registry=self.registry,
                    change_classes=self.change_classes,
                    project_autonomy_ceiling="L2",
                    certification=chain["certification"],
                    certification_events=chain["certification_events"],
                    certification_replay_report=chain["certification_replay"],
                    qualification_consumption=chain["consumption"],
                    incident_budget=chain["budget"],
                    suspensions=[],
                    revocations=[],
                    qualification_manifest_path=context["manifest"],
                    qualification_policy=context["qualification_policy"],
                    maturity_model=context["maturity_model"],
                    lease_qualification_state_checks=context["state_checks"],
                    current_qualification_state_checks=context["state_checks"],
                    artifact_sha256=context["artifact_sha256"],
                    effective_autonomy_report=chain["effective"],
                    match_report=chain["match"],
                    simulation_report=chain["simulation"],
                    authority_evidence=chain["authority_evidence"],
                    at=evaluated_at.isoformat(),
                )
            self.assertIsNone(submitter.packet)

            with self.assertRaisesRegex(ProtocolError, "fields must be exactly"):
                submit_supervised_pr(
                    {"status": "ready", "can_create_pr": True},
                    submitter,
                    policy=chain["policy"],
                    work_item=chain["work_item"],
                    authority_lease=lease,
                    execution=execution,
                    registry=self.registry,
                    change_classes=self.change_classes,
                    project_autonomy_ceiling="L2",
                    certification=chain["certification"],
                    certification_events=chain["certification_events"],
                    certification_replay_report=chain["certification_replay"],
                    qualification_consumption=chain["consumption"],
                    incident_budget=chain["budget"],
                    suspensions=[],
                    revocations=[],
                    qualification_manifest_path=context["manifest"],
                    qualification_policy=context["qualification_policy"],
                    maturity_model=context["maturity_model"],
                    lease_qualification_state_checks=context["state_checks"],
                    current_qualification_state_checks=context["state_checks"],
                    artifact_sha256=context["artifact_sha256"],
                    effective_autonomy_report=chain["effective"],
                    match_report=chain["match"],
                    simulation_report=chain["simulation"],
                    authority_evidence=chain["authority_evidence"],
                    at=evaluated_at.isoformat(),
                )
            self.assertIsNone(submitter.packet)

    def test_p5_2_submission_rejects_expired_lease_and_execution_drift(self) -> None:
        evaluated_at = datetime(2026, 8, 6, 9, 0, tzinfo=UTC)
        with test_workspace("p5-2-expired-submission") as workspace:
            chain = self.authority_inputs(workspace, evaluated_at=evaluated_at)
            lease = self.issue_lease(chain, evaluated_at=evaluated_at)
            execution = self.supervised_execution(
                chain["work_item"],
                lease,
                context=chain["context"],
                evaluated_at=evaluated_at,
            )
            packet = create_supervised_pr_packet(
                chain["policy"],
                work_item=chain["work_item"],
                authority_lease=lease,
                authority_evidence=chain["authority_evidence"],
                execution=execution,
                qualification_policy=chain["context"]["qualification_policy"],
                registry=self.registry,
                change_classes=self.change_classes,
                maturity_model=chain["context"]["maturity_model"],
                title="Correct user-guide link",
                body="Bounded documentation correction with ordered evidence.",
                at=evaluated_at.isoformat(),
            )
            submitter = RecordingSubmitter()
            with self.assertRaisesRegex(ProtocolError, "lease is not active"):
                self.submit_chain(
                    chain,
                    lease,
                    execution,
                    packet,
                    submitter,
                    at=evaluated_at + timedelta(minutes=31),
                )
            self.assertIsNone(submitter.packet)

            drifted_execution = copy.deepcopy(execution)
            drifted_execution["changes"][0]["after_sha256"] = "9" * 64
            drifted_execution["content_sha256"] = canonical_sha256(
                {
                    key: value
                    for key, value in drifted_execution.items()
                    if key != "content_sha256"
                }
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "changes does not match trusted provider evidence",
            ):
                self.submit_chain(
                    chain,
                    lease,
                    drifted_execution,
                    packet,
                    submitter,
                    at=evaluated_at,
                )
            self.assertIsNone(submitter.packet)

            for field, mismatch in [
                ("workspace", "/shared/main-checkout"),
                (
                    "test_results",
                    [
                        {
                            **result,
                            "evidence_sha256": "9" * 64,
                        }
                        for result in execution["test_results"]
                    ],
                ),
                (
                    "independent_evaluation",
                    {"status": "passed", "report_sha256": "9" * 64},
                ),
            ]:
                with self.subTest(field=field):
                    drifted = copy.deepcopy(execution)
                    drifted[field] = mismatch
                    drifted["content_sha256"] = canonical_sha256(
                        {
                            key: value
                            for key, value in drifted.items()
                            if key != "content_sha256"
                        }
                    )
                    with self.assertRaisesRegex(
                        ProtocolError,
                        f"{field} does not match trusted provider evidence",
                    ):
                        self.submit_chain(
                            chain,
                            lease,
                            drifted,
                            packet,
                            submitter,
                            at=evaluated_at,
                        )

            blocked_state_checks = copy.deepcopy(
                chain["context"]["state_checks"]
            )
            blocked_state_checks["contradiction"] = {
                "checked_at": evaluated_at.isoformat(),
                "present": True,
            }
            with self.assertRaisesRegex(ProtocolError, "blocking record"):
                self.submit_chain(
                    chain,
                    lease,
                    execution,
                    packet,
                    submitter,
                    at=evaluated_at,
                    current_state_checks=blocked_state_checks,
                )
            self.assertIsNone(submitter.packet)

    def test_p5_2_canonical_activation_remains_fail_closed(self) -> None:
        policy = load_json(PROTOCOL_DIR / "autonomy-policy.json")
        qualification_policy = load_json(
            PROTOCOL_DIR / "qualification-policy.json"
        )
        report = canonical_p5_2_readiness(
            policy,
            qualification_policy=qualification_policy,
            factory_status={
                "has_remote": False,
                "branch_protection": "not-configured",
                "external_identity": "not-configured",
            },
            active_authority_source_present=False,
            active_certification_present=False,
            valid_l2_consumption_present=False,
        )
        self.assertFalse(report["ready"])
        self.assertFalse(report["can_create_pr"])
        self.assertIn(
            "no-active-canonical-authority-source",
            report["blockers"],
        )
        self.assertNotIn("no-external-trust-anchors", report["blockers"])
        self.assertIn(
            "no-valid-l2-qualification-consumption",
            report["blockers"],
        )
        self.assertIn("no-active-autonomy-certification", report["blockers"])
        self.assertFalse(report["can_merge"])
        self.assertFalse(report["can_deploy"])


if __name__ == "__main__":
    unittest.main()
