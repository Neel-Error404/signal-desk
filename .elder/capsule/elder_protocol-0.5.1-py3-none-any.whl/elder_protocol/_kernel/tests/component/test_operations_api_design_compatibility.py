from __future__ import annotations

import json
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations.operations_store import (
    operations_connection,
)
from tests._support import test_workspace
from tests.component import test_run_controller as run_controller_tests
from tests.foundation import test_operations_api_design as api_design


class OperationsApiDesignCompatibilityTests(unittest.TestCase):
    def test_real_run_bind_result_and_journal_pass_extraction_contract(
        self,
    ) -> None:
        with test_workspace("sf-107-run-bind-compatibility") as workspace:
            helper = run_controller_tests.RunControllerComponentTests(
                methodName="runTest"
            )
            controller, submission, _ = helper._controller_fixture(
                workspace
            )
            service_result = controller.bind_start(
                submission,
                at="2026-08-11T01:04:01+00:00",
            )
            record = api_design._extract_mutation_record(
                "run-bind-start",
                service_result,
            )

            with operations_connection(controller.path) as connection:
                context = connection.execute(
                    """
                    SELECT *
                    FROM factory_journal_mutation_contexts
                    WHERE coverage_branch_id = 'run.bind-start'
                      AND state = 'finalized'
                    ORDER BY finalized_at DESC
                    LIMIT 1
                    """
                ).fetchone()
                self.assertIsNotNone(context)
                rows = connection.execute(
                    """
                    SELECT entry_json
                    FROM factory_journal_entries
                    WHERE transaction_id = ?
                    ORDER BY transaction_position
                    """,
                    (context["mutation_id"],),
                ).fetchall()
            entries = tuple(json.loads(row["entry_json"]) for row in rows)
            self.assertTrue(entries)
            primary_entries = [
                entry
                for entry in entries
                if (
                    entry["source_record"]["source_registry_id"]
                    == "run-initial-bindings"
                    and entry["source_record"]["record_sha256"]
                    == record["initial_binding"]["content_sha256"]
                )
            ]
            self.assertEqual(len(primary_entries), 1)

            project_id = record["run"]["project_id"]
            run_id = record["run"]["id"]
            api_request_sha256 = canonical_sha256(
                {
                    "route_id": "run-bind-start",
                    "project_id": project_id,
                    "subject_id": run_id,
                }
            )
            evidence = {
                "api_request_sha256": api_request_sha256,
                "mutation_id": context["mutation_id"],
                "mutation_identity_sha256": context[
                    "mutation_identity_sha256"
                ],
                "coverage_branch_id": context["coverage_branch_id"],
                "generation": entries[0]["generation"],
                "canonical_project_id": project_id,
                "canonical_scope_subject_id": run_id,
                "primary_source": primary_entries[0]["source_record"],
                "entries": entries,
            }
            data = api_design._mutation_result_from_evidence(
                "run-bind-start",
                record,
                evidence,
            )
            response = {
                "version": "1.0.0",
                "request_id": "request-" + "1" * 32,
                "route_id": "run-bind-start",
                "status": "ok",
                "data_contract": "run-mutation-result",
                "data": data,
                "data_sha256": canonical_sha256(data),
            }
            binding = next(
                item
                for item in api_design._binding_registry()["bindings"]
                if item["route_id"] == "run-bind-start"
            )
            api_design._validate_response_semantics(
                response,
                "run-bind-start",
                binding,
                expected_project_id=project_id,
                expected_subject_id=run_id,
                expected_api_request_sha256=api_request_sha256,
                trusted_mutation_evidence=evidence,
            )


if __name__ == "__main__":
    unittest.main()
