from __future__ import annotations

import copy
import json
import unittest
from datetime import UTC, datetime, timedelta

from elder_protocol.errors import ProtocolError
from elder_protocol.knowledge import (
    KnowledgeStore,
    finalize_knowledge_graph,
    validate_context_packet,
)
from tests._support import test_workspace


def future(minutes: int) -> str:
    return (datetime.now(UTC) + timedelta(minutes=minutes)).isoformat()


def graph_snapshot() -> dict[str, object]:
    content_a = "Elder context assembly preserves source authority and provenance."
    content_b = "Trusted memory requires independent human approval."
    return finalize_knowledge_graph(
        {
            "version": "0.5.1",
            "ontology_version": "0.5.1",
            "graph_id": "component-graph",
            "generated_at": datetime.now(UTC).isoformat(),
            "source_sha256": "",
            "nodes": [
                {
                    "id": "policy:context",
                    "type": "context-policy",
                    "label": "Context policy",
                    "source": "protocol/context-policy.json",
                    "authority": "primary",
                    "status": "active",
                    "content": content_a,
                    "content_sha256": __import__("hashlib").sha256(
                        content_a.encode("utf-8")
                    ).hexdigest(),
                    "attributes": {"owner": "architecture"},
                },
                {
                    "id": "policy:memory",
                    "type": "memory-policy",
                    "label": "Memory policy",
                    "source": "protocol/memory-policy.json",
                    "authority": "primary",
                    "status": "active",
                    "content": content_b,
                    "content_sha256": __import__("hashlib").sha256(
                        content_b.encode("utf-8")
                    ).hexdigest(),
                    "attributes": {"owner": "architecture"},
                },
            ],
            "edges": [
                {
                    "id": "governs:context->memory",
                    "type": "governs-memory",
                    "from": "policy:context",
                    "to": "policy:memory",
                    "source": "docs/adr/0009-p4-4-governed-knowledge-runtime.md",
                    "authority": "primary",
                    "status": "active",
                    "evidence": [
                        "docs/adr/0009-p4-4-governed-knowledge-runtime.md"
                    ],
                    "attributes": {},
                }
            ],
        }
    )


class KnowledgeComponentTests(unittest.TestCase):
    def test_store_initialization_ingest_query_and_idempotency(self) -> None:
        with test_workspace("knowledge-store") as workspace:
            store = KnowledgeStore(workspace / "knowledge.db")
            status = store.initialize()
            self.assertEqual(status["integrity"], "ok")
            self.assertEqual(status["journal_mode"], "wal")
            self.assertTrue(status["foreign_keys"])

            first = store.ingest_graph(graph_snapshot())
            self.assertEqual(first["nodes"]["inserted"], 2)
            self.assertEqual(first["edges"]["inserted"], 1)
            second = store.ingest_graph(graph_snapshot())
            self.assertEqual(second["nodes"]["unchanged"], 2)
            self.assertEqual(second["edges"]["unchanged"], 1)

            result = store.query_graph("independent approval")
            self.assertEqual(result["count"], 1)
            self.assertEqual(result["nodes"][0]["id"], "policy:memory")
            neighborhood = store.query_graph("", node_id="policy:context")
            self.assertEqual(neighborhood["edges"][0]["to"], "policy:memory")

    def test_graph_digest_and_unknown_endpoints_fail_closed(self) -> None:
        with test_workspace("knowledge-invalid") as workspace:
            store = KnowledgeStore(workspace / "knowledge.db")
            store.initialize()
            invalid_digest = copy.deepcopy(graph_snapshot())
            invalid_digest["source_sha256"] = "0" * 64
            with self.assertRaisesRegex(ProtocolError, "source_sha256"):
                store.ingest_graph(invalid_digest)

            invalid_edge = copy.deepcopy(graph_snapshot())
            invalid_edge["edges"][0]["to"] = "missing"
            with self.assertRaisesRegex(ProtocolError, "unknown endpoint"):
                finalize_knowledge_graph(invalid_edge)

    def test_candidate_memory_requires_independent_human_promotion(self) -> None:
        with test_workspace("memory-lifecycle") as workspace:
            store = KnowledgeStore(workspace / "knowledge.db")
            store.initialize()
            record = store.propose_memory(
                {
                    "id": "memory-1",
                    "namespace": "project/elder",
                    "kind": "semantic",
                    "content": "P4.4 defaults to trusted memory retrieval.",
                    "source_evidence": ["test:memory-lifecycle"],
                    "confidence": "high",
                    "owner": "learning-agent-1",
                    "status": "candidate",
                    "created_at": datetime.now(UTC).isoformat(),
                    "review_at": future(120),
                    "expires_at": future(60),
                },
                subject_role="learning-agent",
            )
            self.assertEqual(record["status"], "candidate")
            self.assertEqual(
                store.query_memory("project/elder", "trusted")["count"],
                0,
            )

            approval = {
                "version": "0.5.1",
                "id": "approval-1",
                "memory_id": "memory-1",
                "action": "promote",
                "approved_by": "architecture-owner",
                "subject_role": "human-owner",
                "evidence": ["review:memory-1"],
                "approved_at": datetime.now(UTC).isoformat(),
            }
            self.assertEqual(
                store.transition_memory("memory-1", approval)["status"],
                "trusted",
            )
            result = store.query_memory("project/elder", "trusted")
            self.assertEqual(result["count"], 1)
            self.assertEqual(result["records"][0]["approved_by"], "architecture-owner")

            self_owned = dict(approval)
            self_owned["id"] = "approval-2"
            self_owned["approved_by"] = "learning-agent-1"
            with self.assertRaisesRegex(ProtocolError, "independent"):
                store.transition_memory("memory-1", self_owned)

    def test_context_assembly_is_budgeted_deduplicated_and_digest_bound(self) -> None:
        with test_workspace("context-assembly") as workspace:
            store = KnowledgeStore(workspace / "knowledge.db")
            store.initialize()
            store.ingest_graph(graph_snapshot())
            source = workspace / "required.md"
            source.write_text(
                "The required source defines independent human approval.",
                encoding="utf-8",
            )
            duplicate = workspace / "duplicate.md"
            duplicate.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
            request = {
                "id": "context-1",
                "work_item_id": "work-1",
                "query": "independent approval",
                "assembled_by": "planning-agent",
                "token_budget": 1000,
                "repository_sources": [
                    {
                        "id": "required",
                        "location": str(source),
                        "authority": "primary",
                        "required": True,
                    },
                    {
                        "id": "duplicate",
                        "location": str(duplicate),
                        "authority": "secondary",
                        "required": False,
                    },
                ],
                "memory_namespaces": [],
                "graph_limit": 10,
                "memory_limit": 0,
                "assumptions": ["The local store is the selected reference adapter."],
            }
            packet = store.assemble_context(request, base_dir=workspace)
            validate_context_packet(packet)
            self.assertLessEqual(packet["estimated_tokens"], packet["token_budget"])
            self.assertIn(
                {"source_id": "duplicate", "reason": "duplicate"},
                packet["exclusions"],
            )
            self.assertEqual(packet["status"], "assembled")

            persisted = workspace / "packet.json"
            persisted.write_text(json.dumps(packet), encoding="utf-8")
            tampered = json.loads(persisted.read_text(encoding="utf-8"))
            tampered["query"] = "changed"
            with self.assertRaisesRegex(ProtocolError, "content_sha256"):
                validate_context_packet(tampered)

    def test_required_unauthorized_or_over_budget_context_fails_closed(self) -> None:
        with test_workspace("context-fail-closed") as workspace:
            store = KnowledgeStore(workspace / "knowledge.db")
            store.initialize()
            source = workspace / "candidate.md"
            source.write_text("candidate data", encoding="utf-8")
            request = {
                "id": "context-2",
                "work_item_id": "work-2",
                "query": "candidate",
                "assembled_by": "planning-agent",
                "token_budget": 1,
                "repository_sources": [
                    {
                        "id": "candidate",
                        "location": str(source),
                        "authority": "candidate",
                        "required": True,
                    }
                ],
                "memory_namespaces": [],
            }
            with self.assertRaisesRegex(ProtocolError, "disallowed authority"):
                store.assemble_context(request, base_dir=workspace)

    def test_wholesale_graph_context_is_rejected(self) -> None:
        with test_workspace("context-no-wholesale-graph") as workspace:
            store = KnowledgeStore(workspace / "knowledge.db")
            store.initialize()
            store.ingest_graph(graph_snapshot())
            request = {
                "id": "context-wholesale-graph",
                "work_item_id": "work-wholesale-graph",
                "query": "*",
                "assembled_by": "planning-agent",
                "token_budget": 1000,
                "repository_sources": [],
                "memory_namespaces": [],
                "graph_limit": 20,
                "memory_limit": 0,
                "assumptions": [],
            }
            with self.assertRaisesRegex(ProtocolError, "Wholesale graph context"):
                store.assemble_context(request, base_dir=workspace)
            with self.assertRaisesRegex(ProtocolError, "Wholesale graph queries"):
                store.query_graph("")
            with self.assertRaisesRegex(ProtocolError, "Wholesale graph queries"):
                store.query_graph("*")
            request["query"] = "trusted memory"
            request["graph_limit"] = 21
            with self.assertRaisesRegex(ProtocolError, "Wholesale graph context"):
                store.assemble_context(request, base_dir=workspace)


if __name__ == "__main__":
    unittest.main()
