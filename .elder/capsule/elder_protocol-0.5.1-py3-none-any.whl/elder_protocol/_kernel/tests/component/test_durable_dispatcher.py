from __future__ import annotations

import copy
import json
import sqlite3
import unittest
from pathlib import Path

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import ROOT
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    DurableDispatcher,
    FactoryOperationsBootstrap,
    ProductFactoryRegistry,
    WorkItemLedger,
    WorkItemTransitionEngine,
    transition_authorization_request_sha256,
    transition_authorization_result_sha256,
)
from elder_protocol.io import load_json
from tests._support import tamper_sqlite_store, test_workspace


class DurableDispatcherComponentTests(unittest.TestCase):
    @staticmethod
    def _profile() -> dict:
        profile = copy.deepcopy(
            load_json(ROOT / "examples" / "minimal-project-profile.json")
        )
        profile["slug"] = "product-one"
        profile["name"] = "Product One"
        return profile

    @staticmethod
    def _specification() -> dict:
        return {
            "version": "1.0.0",
            "work_item_id": "work-item-build-repair",
            "project_id": "product-one",
            "objective": "Repair the failing component build with durable evidence.",
            "scope": ["component build", "regression test"],
            "non_goals": ["production deployment"],
            "priority": "high",
            "owner_identity_id": "founder",
            "acceptance_criteria": [
                "The component build passes.",
                "A regression test proves the fix.",
            ],
            "outcome_ids": ["outcome:governed-workflow"],
            "change_class": "internal-code",
            "evidence_plan": [
                "foundation tests",
                "component tests",
                "independent evaluation",
            ],
            "authority_refs": ["profile:product-one/founder"],
            "dependencies": [],
            "source_links": [
                {
                    "kind": "manual",
                    "reference": "manual:owner-backlog/build-repair",
                    "content_sha256": None,
                }
            ],
        }

    @staticmethod
    def _transition_command(
        *,
        command_id: str,
        trigger: str,
        expected_version: int,
        actor_identity_id: str,
        role: str,
        mode: str,
        resource: str,
        action: str,
        field_bindings: dict,
        evidence_refs: dict,
        submitted_at: str,
    ) -> dict:
        command = {
            "version": "1.0.0",
            "command_id": command_id,
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "trigger": trigger,
            "expected_version": expected_version,
            "actor_identity_id": actor_identity_id,
            "reason": f"Apply the governed {trigger} decision.",
            "field_bindings": field_bindings,
            "evidence_refs": evidence_refs,
            "authority": {
                "role": role,
                "mode": mode,
                "resource": resource,
                "action": action,
                "authority_ref": f"authority:{command_id}",
                "accountable_command_ref": f"command:{command_id}",
                "delegated_runtime_lease_ref": f"lease:{command_id}",
                "request_sha256": "0" * 64,
                "decision": "allowed",
                "decision_ref": f"decision:{command_id}",
                "decided_at": "2026-08-11T00:59:00+00:00",
                "result_sha256": "0" * 64,
            },
            "submitted_at": submitted_at,
        }
        command["authority"]["request_sha256"] = (
            transition_authorization_request_sha256(command)
        )
        command["authority"]["result_sha256"] = (
            transition_authorization_result_sha256(command["authority"])
        )
        return command

    def _dispatcher(
        self,
        workspace: Path,
        *,
        max_attempts: int = 5,
    ) -> tuple[DurableDispatcher, dict]:
        repository = workspace / "product-one"
        repository.mkdir()
        (repository / ".git").mkdir()
        profile_path = repository / ".elder" / "project-profile.json"
        profile_path.parent.mkdir()
        profile_path.write_text(
            json.dumps(self._profile(), indent=2) + "\n",
            encoding="utf-8",
        )
        database = workspace / "operations.db"
        FactoryOperationsBootstrap(database).initialize()
        registry = ProductFactoryRegistry(database)
        factory = registry.register(
            {
                "version": "1.0.0",
                "project_id": "product-one",
                "repository_root": str(repository.resolve()),
                "profile_path": ".elder/project-profile.json",
                "worker_policy": {
                    "adapter_id": "codex",
                    "max_concurrent_workers": 1,
                    "approval_policy": "on-request",
                    "sandbox_mode": "workspace-write",
                    "network_access": False,
                },
                "integration_refs": [
                    {
                        "id": "owner-inbox",
                        "kind": "manual",
                        "reference": "manual:owner-inbox",
                        "enabled": True,
                    }
                ],
            },
            actor_identity_id="founder",
            at="2026-08-11T00:50:00+00:00",
        )
        registry.activate(
            factory["product_factory"]["id"],
            expected_version=1,
            actor_identity_id="founder",
            at="2026-08-11T00:51:00+00:00",
        )
        ledger = WorkItemLedger(database)
        ledger.initialize()
        created = ledger.create(
            self._specification(),
            actor_identity_id="founder",
            change_reason="Accept bounded work.",
            at="2026-08-11T00:52:00+00:00",
        )
        transitions = WorkItemTransitionEngine(database)
        transitions.initialize()
        submit = self._transition_command(
            command_id="transition-command-submit-build-repair",
            trigger="submit",
            expected_version=1,
            actor_identity_id="example-agentic-product-planning-agent",
            role="planning-agent",
            mode="modify-only",
            resource="design-doc",
            action="modify",
            field_bindings={
                "revision_id": created["current_revision"]["id"],
                "evidence_plan": created["work_item"]["payload"][
                    "evidence_plan"
                ],
            },
            evidence_refs={},
            submitted_at="2026-08-11T01:00:00+00:00",
        )
        transitions.apply(submit, at="2026-08-11T01:00:01+00:00")
        ready = ledger.get("work-item-build-repair")
        queue = self._transition_command(
            command_id="transition-command-queue-build-repair",
            trigger="queue",
            expected_version=2,
            actor_identity_id="example-agentic-product-executor",
            role="executor",
            mode="execute-bounded",
            resource="context-packet",
            action="execute",
            field_bindings={
                "revision_id": ready["current_revision"]["id"],
            },
            evidence_refs={
                "validated work item revision": (
                    "evidence:validated-work-item-revision"
                )
            },
            submitted_at="2026-08-11T01:01:00+00:00",
        )
        queue_record = transitions.apply(
            queue,
            at="2026-08-11T01:01:01+00:00",
        )
        dispatcher = DurableDispatcher(database)
        dispatcher.initialize()
        submission = self._submission(
            queue_record,
            max_attempts=max_attempts,
        )
        return dispatcher, submission

    @staticmethod
    def _submission(
        queue_record: dict,
        *,
        max_attempts: int = 5,
    ) -> dict:
        command_payload = {
            "work_item_id": "work-item-build-repair",
            "operation": "start",
        }
        command = {
            "version": "1.0.0",
            "command_id": "command-start-build-repair",
            "project_id": "product-one",
            "work_item_id": "work-item-build-repair",
            "run_id": None,
            "worker_session_id": None,
            "command_type": "worker.start",
            "mutability": "mutation",
            "idempotency_key": "start-build-repair-001",
            "authority_ref": queue_record["transition"]["payload"][
                "authority_ref"
            ],
            "correlation_id": "work-item:work-item-build-repair",
            "causation_id": queue_record["transition"]["id"],
            "attempt": 1,
            "status": "accepted",
            "submitted_at": "2026-08-11T01:02:00+00:00",
            "expires_at": "2026-08-11T02:00:00+00:00",
            "payload_mode": "inline",
            "redaction": {
                "classification": "internal",
                "redacted_fields": [],
            },
            "payload_sha256": canonical_sha256(command_payload),
            "payload": command_payload,
            "extensions": {},
        }
        request_payload = {"command": command}
        request = {
            "version": "1.0.0",
            "contract_id": "worker-adapter",
            "operation": "send",
            "request_id": "request-start-build-repair",
            "project_id": command["project_id"],
            "work_item_id": command["work_item_id"],
            "run_id": command["run_id"],
            "session_id": command["worker_session_id"],
            "submitted_at": "2026-08-11T01:02:01+00:00",
            "deadline_at": "2026-08-11T01:30:00+00:00",
            "correlation_id": command["correlation_id"],
            "causation_id": command["causation_id"],
            "mutability": "mutation",
            "idempotency_key": command["idempotency_key"],
            "payload_mode": "inline",
            "redaction": {
                "classification": "internal",
                "redacted_fields": [],
            },
            "payload_sha256": canonical_sha256(request_payload),
            "payload": request_payload,
            "extensions": {},
        }
        return {
            "version": "1.0.0",
            "command": command,
            "adapter_request": request,
            "queue_transition_command_id": queue_record["command"][
                "command_id"
            ],
            "max_attempts": max_attempts,
            "available_at": "2026-08-11T01:02:01+00:00",
        }

    @staticmethod
    def _dispatch_variant(
        submission: dict,
        suffix: str,
        *,
        available_at: str,
        command_expires_at: str = "2026-08-11T04:00:00+00:00",
        request_deadline_at: str = "2026-08-11T03:30:00+00:00",
    ) -> dict:
        variant = copy.deepcopy(submission)
        command = variant["command"]
        command["command_id"] = f"command-start-build-repair-{suffix}"
        command["idempotency_key"] = f"start-build-repair-{suffix}"
        command["expires_at"] = command_expires_at
        request = variant["adapter_request"]
        request["request_id"] = f"request-start-build-repair-{suffix}"
        request["idempotency_key"] = command["idempotency_key"]
        request["deadline_at"] = request_deadline_at
        request["payload"]["command"] = copy.deepcopy(command)
        request["payload_sha256"] = canonical_sha256(request["payload"])
        variant["available_at"] = available_at
        return variant

    @staticmethod
    def _response(
        request: dict,
        *,
        disposition: str,
        responded_at: str,
        error_code: str | None = None,
    ) -> dict:
        if disposition in {"accepted", "succeeded"}:
            accepted_command = copy.deepcopy(request["payload"]["command"])
            accepted_command["status"] = (
                "delivered"
                if disposition == "accepted"
                else "succeeded"
            )
            result = {"accepted_command": accepted_command}
            result_sha256 = canonical_sha256(result)
            error = None
            mutation_state = (
                "not-started" if disposition == "accepted" else "applied"
            )
            completed = disposition == "succeeded"
            retry = "never"
        else:
            result = {}
            result_sha256 = None
            code = error_code or {
                "timeout": "provider-unavailable",
                "failed": "internal-error",
                "uncertain": "uncertain-mutation",
                "rejected": "invalid-request",
            }[disposition]
            error = {
                "code": code,
                "message": f"Adapter returned {code}.",
                "details": {},
            }
            mutation_state = (
                "unknown"
                if disposition == "uncertain"
                else "not-started"
                if disposition == "rejected"
                else "not-applied"
            )
            completed = False
            retry = (
                "reconcile"
                if disposition == "uncertain"
                else "never"
                if disposition == "rejected"
                else "same-idempotency-key"
            )
        return {
            "version": "1.0.0",
            "contract_id": request["contract_id"],
            "operation": request["operation"],
            "request_id": request["request_id"],
            "request_sha256": canonical_sha256(request),
            "project_id": request["project_id"],
            "responded_at": responded_at,
            "disposition": disposition,
            "operation_completed": completed,
            "mutation_state": mutation_state,
            "retry": retry,
            "source_of_truth": "adapter-observation",
            "result_mode": "inline",
            "redaction": {
                "classification": "internal",
                "redacted_fields": [],
            },
            "result_sha256": result_sha256,
            "result": result,
            "error": error,
            "cursor": None,
            "original_response_sha256": None,
            "extensions": {},
        }

    def test_submit_replay_collision_and_exact_queue_lineage(self) -> None:
        with test_workspace("sf-104-submit") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            first = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            replay = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:03+00:00",
            )
            self.assertEqual(first, replay)
            self.assertEqual(first["status"], "pending")
            self.assertEqual(first["record_version"], 1)

            changed = copy.deepcopy(submission)
            changed["max_attempts"] = 4
            with self.assertRaisesRegex(ProtocolError, "collision"):
                dispatcher.submit(
                    changed,
                    at="2026-08-11T01:02:04+00:00",
                )

        with test_workspace("sf-104-lineage") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            invalid = copy.deepcopy(submission)
            invalid["command"]["causation_id"] = "stage-transition-wrong"
            invalid["adapter_request"]["causation_id"] = (
                "stage-transition-wrong"
            )
            invalid["adapter_request"]["payload"]["command"][
                "causation_id"
            ] = "stage-transition-wrong"
            invalid["adapter_request"]["payload_sha256"] = canonical_sha256(
                invalid["adapter_request"]["payload"]
            )
            with self.assertRaisesRegex(ProtocolError, "exact accepted queue"):
                dispatcher.submit(
                    invalid,
                    at="2026-08-11T01:02:05+00:00",
                )

    def test_claim_renew_complete_and_restart_durability(self) -> None:
        with test_workspace("sf-104-complete") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            queued = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
                lease_seconds=30,
            )
            self.assertEqual(claimed["attempt_count"], 1)
            self.assertEqual(claimed["lease"]["generation"], 1)
            self.assertIsNone(
                dispatcher.claim_next(
                    owner_id="dispatcher-two",
                    at="2026-08-11T01:03:01+00:00",
                )
            )
            renewed = dispatcher.renew(
                queued["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=1,
                at="2026-08-11T01:03:10+00:00",
                lease_seconds=30,
            )
            self.assertEqual(
                renewed["lease"]["expires_at"],
                "2026-08-11T01:03:40+00:00",
            )
            dispatcher.begin_execution(
                queued["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=1,
                at="2026-08-11T01:03:11+00:00",
            )
            response = self._response(
                submission["adapter_request"],
                disposition="accepted",
                responded_at="2026-08-11T01:03:12+00:00",
            )
            completed = dispatcher.record_response(
                queued["dispatch_id"],
                response,
                owner_id="dispatcher-one",
                lease_generation=1,
                at="2026-08-11T01:03:12+00:00",
            )
            self.assertEqual(completed["status"], "completed")
            self.assertEqual(
                completed["current_command"]["status"],
                "delivered",
            )
            self.assertEqual(
                [item["operation"] for item in dispatcher.history(
                    queued["dispatch_id"]
                )],
                ["submit", "claim", "renew", "begin-execution", "complete-dispatch"],
            )

            reopened = DurableDispatcher(workspace / "operations.db")
            reopened.initialize()
            self.assertEqual(reopened.get(queued["dispatch_id"]), completed)
            self.assertEqual(
                reopened.status()["status_counts"]["completed"],
                1,
            )

    def test_safe_retry_exhaustion_creates_immutable_dead_letter(self) -> None:
        with test_workspace("sf-104-dead-letter") as workspace:
            dispatcher, submission = self._dispatcher(
                workspace,
                max_attempts=2,
            )
            queued = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            for attempt, second in ((1, 0), (2, 2)):
                claimed = dispatcher.claim_next(
                    owner_id="dispatcher-one",
                    at=f"2026-08-11T01:03:0{second}+00:00",
                    lease_seconds=30,
                )
                self.assertEqual(claimed["attempt_count"], attempt)
                dispatcher.begin_execution(
                    queued["dispatch_id"],
                    owner_id="dispatcher-one",
                    lease_generation=attempt,
                    at=f"2026-08-11T01:03:0{second}+00:00",
                )
                response = self._response(
                    submission["adapter_request"],
                    disposition="timeout",
                    responded_at=f"2026-08-11T01:03:0{second + 1}+00:00",
                )
                result = dispatcher.record_response(
                    queued["dispatch_id"],
                    response,
                    owner_id="dispatcher-one",
                    lease_generation=attempt,
                    at=f"2026-08-11T01:03:0{second + 1}+00:00",
                )
                if attempt == 1:
                    self.assertEqual(result["status"], "retry")
                    self.assertEqual(
                        result["available_at"],
                        "2026-08-11T01:03:02+00:00",
                    )
                else:
                    self.assertEqual(result["status"], "dead-letter")
                    self.assertEqual(
                        result["current_command"]["status"],
                        "failed",
                    )

            letters = dispatcher.dead_letters(project_id="product-one")
            self.assertEqual(len(letters), 1)
            self.assertEqual(
                letters[0]["final_dispatch_sha256"],
                result["content_sha256"],
            )
            connection = sqlite3.connect(workspace / "operations.db")
            try:
                with self.assertRaises(sqlite3.IntegrityError):
                    connection.execute(
                        "DELETE FROM dispatch_dead_letters"
                    )
            finally:
                connection.close()

    def test_uncertain_delivery_requires_reconciliation(self) -> None:
        with test_workspace("sf-104-uncertain") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            queued = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
                lease_seconds=30,
            )
            dispatcher.begin_execution(
                queued["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:01+00:00",
            )
            uncertain_response = self._response(
                submission["adapter_request"],
                disposition="uncertain",
                responded_at="2026-08-11T01:03:02+00:00",
            )
            uncertain = dispatcher.record_response(
                queued["dispatch_id"],
                uncertain_response,
                owner_id="dispatcher-one",
                lease_generation=1,
                at="2026-08-11T01:03:02+00:00",
            )
            self.assertEqual(uncertain["status"], "uncertain")
            self.assertIsNone(
                dispatcher.claim_next(
                    owner_id="dispatcher-two",
                    at="2026-08-11T01:03:03+00:00",
                )
            )

            reconciliation = dispatcher.claim_reconciliation(
                queued["dispatch_id"],
                owner_id="reconciler",
                at="2026-08-11T01:03:04+00:00",
            )
            self.assertEqual(reconciliation["lease"]["kind"], "reconcile")
            dispatcher.begin_execution(
                queued["dispatch_id"],
                owner_id="reconciler",
                lease_generation=2,
                at="2026-08-11T01:03:05+00:00",
            )
            observed = self._response(
                submission["adapter_request"],
                disposition="succeeded",
                responded_at="2026-08-11T01:03:06+00:00",
            )
            completed = dispatcher.record_response(
                queued["dispatch_id"],
                observed,
                owner_id="reconciler",
                lease_generation=2,
                at="2026-08-11T01:03:06+00:00",
            )
            self.assertEqual(completed["status"], "completed")
            self.assertEqual(
                completed["current_command"]["status"],
                "succeeded",
            )

    def test_duplicate_response_and_rejection_are_terminal(self) -> None:
        with test_workspace("sf-104-duplicate") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            accepted = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            first_claim = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=first_claim["lease"]["generation"],
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.record_response(
                accepted["dispatch_id"],
                self._response(
                    submission["adapter_request"],
                    disposition="timeout",
                    responded_at="2026-08-11T01:03:01+00:00",
                ),
                owner_id="dispatcher-one",
                lease_generation=first_claim["lease"]["generation"],
                at="2026-08-11T01:03:01+00:00",
            )
            second_claim = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:02+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=second_claim["lease"]["generation"],
                at="2026-08-11T01:03:02+00:00",
            )
            original = self._response(
                submission["adapter_request"],
                disposition="accepted",
                responded_at="2026-08-11T01:03:02+00:00",
            )
            duplicate = copy.deepcopy(original)
            duplicate["disposition"] = "duplicate"
            duplicate["responded_at"] = "2026-08-11T01:03:03+00:00"
            duplicate["original_response_sha256"] = canonical_sha256(
                original
            )
            completed = dispatcher.record_response(
                accepted["dispatch_id"],
                duplicate,
                original_response=original,
                owner_id="dispatcher-one",
                lease_generation=second_claim["lease"]["generation"],
                at="2026-08-11T01:03:03+00:00",
            )
            self.assertEqual(completed["status"], "completed")
            self.assertEqual(completed["last_response"], original)
            self.assertEqual(
                completed["current_command"]["status"],
                "delivered",
            )

        with test_workspace("sf-104-rejected") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            accepted = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:01+00:00",
            )
            rejected = dispatcher.record_response(
                accepted["dispatch_id"],
                self._response(
                    submission["adapter_request"],
                    disposition="rejected",
                    responded_at="2026-08-11T01:03:02+00:00",
                ),
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:02+00:00",
            )
            self.assertEqual(rejected["status"], "dead-letter")
            self.assertEqual(rejected["attempt_count"], 1)
            self.assertEqual(
                rejected["current_command"]["status"],
                "rejected",
            )

    def test_reconciliation_can_retry_or_exhaust_to_dead_letter(self) -> None:
        with test_workspace("sf-104-reconcile-retry") as workspace:
            dispatcher, submission = self._dispatcher(
                workspace,
                max_attempts=4,
            )
            accepted = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.record_response(
                accepted["dispatch_id"],
                self._response(
                    submission["adapter_request"],
                    disposition="uncertain",
                    responded_at="2026-08-11T01:03:01+00:00",
                ),
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:01+00:00",
            )
            reconciliation = dispatcher.claim_reconciliation(
                accepted["dispatch_id"],
                owner_id="reconciler",
                at="2026-08-11T01:03:02+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="reconciler",
                lease_generation=reconciliation["lease"]["generation"],
                at="2026-08-11T01:03:02+00:00",
            )
            retry = dispatcher.record_response(
                accepted["dispatch_id"],
                self._response(
                    submission["adapter_request"],
                    disposition="timeout",
                    responded_at="2026-08-11T01:03:03+00:00",
                ),
                owner_id="reconciler",
                lease_generation=reconciliation["lease"]["generation"],
                at="2026-08-11T01:03:03+00:00",
            )
            self.assertEqual(retry["status"], "retry")
            self.assertEqual(
                retry["available_at"],
                "2026-08-11T01:03:05+00:00",
            )
            self.assertIsNone(retry["reconciliation_ref"])

        with test_workspace("sf-104-reconcile-exhaust") as workspace:
            dispatcher, submission = self._dispatcher(
                workspace,
                max_attempts=2,
            )
            accepted = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.record_response(
                accepted["dispatch_id"],
                self._response(
                    submission["adapter_request"],
                    disposition="uncertain",
                    responded_at="2026-08-11T01:03:01+00:00",
                ),
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:01+00:00",
            )
            reconciliation = dispatcher.claim_reconciliation(
                accepted["dispatch_id"],
                owner_id="reconciler",
                at="2026-08-11T01:03:02+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="reconciler",
                lease_generation=reconciliation["lease"]["generation"],
                at="2026-08-11T01:03:02+00:00",
            )
            exhausted = dispatcher.record_response(
                accepted["dispatch_id"],
                self._response(
                    submission["adapter_request"],
                    disposition="uncertain",
                    responded_at="2026-08-11T01:03:03+00:00",
                ),
                owner_id="reconciler",
                lease_generation=reconciliation["lease"]["generation"],
                at="2026-08-11T01:03:03+00:00",
            )
            self.assertEqual(exhausted["status"], "dead-letter")
            self.assertEqual(
                exhausted["current_command"]["status"],
                "uncertain",
            )

    def test_expired_started_lease_fences_stale_owner(self) -> None:
        with test_workspace("sf-104-lease-loss") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            queued = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            dispatcher.claim_next(
                owner_id="first",
                at="2026-08-11T01:03:00+00:00",
                lease_seconds=2,
            )
            dispatcher.begin_execution(
                queued["dispatch_id"],
                owner_id="first",
                lease_generation=1,
                at="2026-08-11T01:03:01+00:00",
            )
            self.assertIsNone(
                dispatcher.claim_next(
                    owner_id="second",
                    at="2026-08-11T01:03:03+00:00",
                )
            )
            uncertain = dispatcher.get(queued["dispatch_id"])
            self.assertEqual(uncertain["status"], "uncertain")
            response = self._response(
                submission["adapter_request"],
                disposition="accepted",
                responded_at="2026-08-11T01:03:03+00:00",
            )
            with self.assertRaisesRegex(ProtocolError, "lease"):
                dispatcher.record_response(
                    queued["dispatch_id"],
                    response,
                    owner_id="first",
                    lease_generation=1,
                    at="2026-08-11T01:03:03+00:00",
                )

    def test_dispatch_once_callback_failure_is_secret_scrubbed_uncertainty(
        self,
    ) -> None:
        with test_workspace("sf-104-callback-failure") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )

            def fail_after_boundary(_: dict) -> dict:
                raise RuntimeError(
                    "api_key=do-not-store provider disconnected"
                )

            uncertain = dispatcher.dispatch_once(
                fail_after_boundary,
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
            )

            self.assertEqual(uncertain["status"], "uncertain")
            self.assertEqual(
                uncertain["current_command"]["status"],
                "uncertain",
            )
            self.assertNotIn(
                "do-not-store",
                uncertain["last_error"]["message"],
            )
            self.assertIn(
                "[redacted]",
                uncertain["last_error"]["message"],
            )
            self.assertEqual(
                dispatcher.history(uncertain["dispatch_id"])[-1][
                    "operation"
                ],
                "execution-response-lost",
            )

    def test_expired_request_dead_letters_without_provider_attempt(self) -> None:
        with test_workspace("sf-104-expired-request") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            accepted = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )

            self.assertIsNone(
                dispatcher.claim_next(
                    owner_id="dispatcher-one",
                    at="2026-08-11T01:30:00+00:00",
                )
            )
            expired = dispatcher.get(accepted["dispatch_id"])
            self.assertEqual(expired["status"], "dead-letter")
            self.assertEqual(expired["attempt_count"], 0)
            self.assertEqual(expired["lease_generation"], 0)
            self.assertEqual(
                dispatcher.history(accepted["dispatch_id"])[-1][
                    "operation"
                ],
                "request-deadline-expired-before-claim",
            )

    def test_claim_order_is_offset_aware_and_updates_are_monotonic(self) -> None:
        with test_workspace("sf-104-offset-order") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            later_utc = self._dispatch_variant(
                submission,
                "later-utc",
                available_at="2026-08-11T02:10:00+00:00",
            )
            earlier_offset = self._dispatch_variant(
                submission,
                "earlier-offset",
                available_at="2026-08-11T07:35:00+05:30",
            )
            dispatcher.submit(
                later_utc,
                at="2026-08-11T01:02:20+00:00",
            )
            dispatcher.submit(
                earlier_offset,
                at="2026-08-11T01:02:20+00:00",
            )

            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T02:20:00+00:00",
            )
            self.assertEqual(
                claimed["accepted_command"]["command_id"],
                "command-start-build-repair-earlier-offset",
            )
            with self.assertRaisesRegex(ProtocolError, "cannot predate"):
                dispatcher.begin_execution(
                    claimed["dispatch_id"],
                    owner_id="dispatcher-one",
                    lease_generation=claimed["lease"]["generation"],
                    at="2026-08-11T02:19:59+00:00",
                )

    def test_cancellation_shutdown_and_tamper_detection(self) -> None:
        with test_workspace("sf-104-cancel") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            queued = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
            )
            shutdown = dispatcher.shutdown_owner(
                "dispatcher-one",
                at="2026-08-11T01:03:01+00:00",
            )
            self.assertEqual(shutdown, {
                "released": 1,
                "uncertain": 0,
                "dead_lettered": 0,
            })
            retry = dispatcher.get(queued["dispatch_id"])
            self.assertEqual(retry["status"], "retry")
            cancelled = dispatcher.cancel(
                queued["dispatch_id"],
                requested_by_identity_id="founder",
                reason="Owner withdrew the queued start.",
                at="2026-08-11T01:03:02+00:00",
            )
            self.assertEqual(cancelled["status"], "cancelled")
            self.assertEqual(
                cancelled["current_command"]["status"],
                "cancelled",
            )

            tamper_sqlite_store(
                workspace / "operations.db",
                """
                UPDATE dispatch_commands
                SET content_sha256 = ?
                WHERE dispatch_id = ?
                """,
                ("0" * 64, queued["dispatch_id"]),
            )
            with self.assertRaisesRegex(ProtocolError, "row does not match"):
                dispatcher.get(queued["dispatch_id"])

        with test_workspace("sf-104-cancel-after-start") as workspace:
            dispatcher, submission = self._dispatcher(workspace)
            accepted = dispatcher.submit(
                submission,
                at="2026-08-11T01:02:02+00:00",
            )
            claimed = dispatcher.claim_next(
                owner_id="dispatcher-one",
                at="2026-08-11T01:03:00+00:00",
            )
            dispatcher.begin_execution(
                accepted["dispatch_id"],
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:01+00:00",
            )
            uncertain = dispatcher.cancel(
                accepted["dispatch_id"],
                requested_by_identity_id="founder",
                reason="Owner withdrew work after provider invocation began.",
                owner_id="dispatcher-one",
                lease_generation=claimed["lease"]["generation"],
                at="2026-08-11T01:03:02+00:00",
            )
            self.assertEqual(uncertain["status"], "uncertain")
            self.assertEqual(
                uncertain["cancellation"]["requested_by_identity_id"],
                "founder",
            )
            self.assertEqual(
                uncertain["current_command"]["status"],
                "uncertain",
            )


if __name__ == "__main__":
    unittest.main()
