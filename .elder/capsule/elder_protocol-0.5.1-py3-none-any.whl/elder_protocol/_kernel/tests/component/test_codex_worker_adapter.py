from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
import threading
import time
import unittest

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_workers import (
    CODEX_CLI_VERSION,
    CodexAppServerRuntime,
    CodexRuntimeConfig,
    CodexRuntimeError,
    CodexWorkerAdapter,
    WorkerConformanceScenario,
)
from tests._codex_support import DeterministicCodexRuntime
from tests._support import test_workspace


_FAKE_APP_SERVER = r"""
import json
import pathlib
import sys
import time

mode = sys.argv[1]
arguments = sys.argv[2:]
if "--version" in arguments:
    print("codex-cli 0.146.0" if mode == "wrong-version" else "codex-cli 0.146.1")
    raise SystemExit(0)

thread_id = "019ff999-1111-7111-8111-111111111111"

def send(document):
    sys.stdout.write(json.dumps(document, separators=(",", ":")) + "\n")
    sys.stdout.flush()

for line in sys.stdin:
    if mode == "malformed":
        print("{not-json", flush=True)
        time.sleep(1)
        continue
    message = json.loads(line)
    method = message.get("method")
    if method == "initialize":
        if mode == "secret-stderr-exit":
            print("OPENAI_API_KEY=sk-review-secret", file=sys.stderr, flush=True)
            raise SystemExit(7)
        if mode == "process-exit":
            raise SystemExit(8)
        if mode == "timeout":
            time.sleep(2)
            continue
        send({
            "id": message["id"],
            "result": {
                "userAgent": "fake/0.146.1",
                "codexHome": str(pathlib.Path.cwd()),
                "platformFamily": "windows",
                "platformOs": "windows",
            },
        })
    elif method == "initialized":
        continue
    elif method in {"thread/start", "thread/resume"}:
        if mode == "pending-only" and method == "thread/resume":
            send({
                "id": message["id"],
                "error": {
                    "code": -32000,
                    "message": "no rollout found",
                },
            })
            continue
        params = message["params"]
        current_thread = params.get("threadId", thread_id)
        network = mode == "policy-drift"
        send({
            "id": message["id"],
            "result": {
                "thread": {
                    "id": current_thread,
                    "path": str(pathlib.Path(params["cwd"]) / "rollout.jsonl"),
                    "status": {"type": "idle"},
                    "cliVersion": "0.146.1",
                    "turns": [],
                },
                "model": "fake-model",
                "modelProvider": "fake-provider",
                "cwd": params["cwd"],
                "runtimeWorkspaceRoots": params["runtimeWorkspaceRoots"],
                "approvalPolicy": params["approvalPolicy"],
                "approvalsReviewer": params["approvalsReviewer"],
                "sandbox": {
                    "type": "workspaceWrite",
                    "networkAccess": network,
                },
            },
        })
        if mode == "exit-after-start" and method == "thread/start":
            raise SystemExit(9)
    elif method == "turn/start":
        turn_id = "019ff999-2222-7222-8222-222222222222"
        send({
            "id": message["id"],
            "result": {
                "turn": {
                    "id": turn_id,
                    "items": [],
                    "status": "inProgress",
                    "error": None,
                }
            },
        })
        if mode == "interactive":
            send({
                "id": 91,
                "method": "Item/fileChange/requestApprovalRequest",
                "params": {},
            })
            continue
        send({
            "method": "item/completed",
            "params": {
                "threadId": message["params"]["threadId"],
                "turnId": turn_id,
                "item": {
                    "id": "item-1",
                    "type": "agentMessage",
                    "text": "done",
                },
            },
        })
        send({
            "method": "turn/completed",
            "params": {
                "threadId": message["params"]["threadId"],
                "turn": {
                    "id": turn_id,
                    "items": [],
                    "status": "completed",
                    "error": None,
                },
            },
        })
    elif method == "turn/interrupt":
        send({"id": message["id"], "result": {}})
"""


def _write_fake_server(workspace: Path) -> Path:
    script = workspace / "fake_codex.py"
    script.write_text(_FAKE_APP_SERVER, encoding="utf-8")
    return script


class CodexAppServerRuntimeComponentTests(unittest.TestCase):
    @staticmethod
    def _runtime(
        script: Path,
        mode: str,
        *,
        pending_timeout: float = 2,
    ) -> CodexAppServerRuntime:
        return CodexAppServerRuntime(
            CodexRuntimeConfig(
                executable=(sys.executable, str(script), mode),
                request_timeout_seconds=0.4,
                turn_timeout_seconds=2,
                pending_session_timeout_seconds=pending_timeout,
            )
        )

    def test_app_server_start_resume_and_turn_are_normalized(self) -> None:
        with test_workspace("sf201-component-runtime") as workspace:
            script = _write_fake_server(workspace)
            runtime = self._runtime(script, "normal")
            started = runtime.start_session(workspace)
            self.assertEqual(started["cli_version"], CODEX_CLI_VERSION)
            self.assertFalse(started["sandbox"]["network_access"])
            resumed = runtime.resume_session(
                started["thread_id"],
                workspace,
            )
            self.assertEqual(resumed["thread_id"], started["thread_id"])
            turn = runtime.run_turn(
                started["thread_id"],
                workspace,
                command_id="command-1",
                command_type="worker.prompt",
                prompt="bounded",
            )
            self.assertEqual(turn["turn_status"], "completed")
            self.assertEqual(
                turn["final_message_sha256"],
                canonical_sha256("done"),
            )

    def test_version_policy_protocol_and_interactive_drift_fail_closed(
        self,
    ) -> None:
        with test_workspace("sf201-component-fail-closed") as workspace:
            script = _write_fake_server(workspace)
            cases = (
                ("wrong-version", "version-mismatch"),
                ("policy-drift", "sandbox-policy-drift"),
                ("malformed", "malformed-json-rpc"),
                ("timeout", "protocol-timeout"),
                ("process-exit", "process-exited"),
            )
            for mode, reason in cases:
                with self.subTest(mode=mode):
                    runtime = self._runtime(script, mode)
                    with self.assertRaises(CodexRuntimeError) as caught:
                        runtime.start_session(workspace)
                    self.assertEqual(caught.exception.reason, reason)
            runtime = self._runtime(script, "interactive")
            started = runtime.start_session(workspace)
            with self.assertRaises(CodexRuntimeError) as caught:
                runtime.run_turn(
                    started["thread_id"],
                    workspace,
                    command_id="command-2",
                    command_type="worker.prompt",
                    prompt="bounded",
                )
            self.assertTrue(caught.exception.dispatched)
            self.assertIn("interactive-request", caught.exception.reason)

    def test_pending_process_liveness_lifetime_and_diagnostics_fail_closed(
        self,
    ) -> None:
        with test_workspace("sf201-component-pending") as workspace:
            script = _write_fake_server(workspace)

            exited = self._runtime(script, "exit-after-start")
            started = exited.start_session(workspace)
            time.sleep(0.1)
            with self.assertRaises(CodexRuntimeError) as caught:
                exited.resume_session(started["thread_id"], workspace)
            self.assertEqual(
                caught.exception.reason,
                "pending-process-exited",
            )

            expiring = self._runtime(
                script,
                "pending-only",
                pending_timeout=0.1,
            )
            started = expiring.start_session(workspace)
            time.sleep(0.3)
            with self.assertRaises(CodexRuntimeError) as caught:
                expiring.resume_session(started["thread_id"], workspace)
            self.assertEqual(caught.exception.reason, "json-rpc-error")
            expiring.close()

            secret = self._runtime(script, "secret-stderr-exit")
            with self.assertRaises(CodexRuntimeError) as caught:
                secret.start_session(workspace)
            self.assertNotIn("sk-review-secret", str(caught.exception))
            self.assertIsNotNone(caught.exception.diagnostic_sha256)

    def test_pending_resume_is_atomic_against_stale_expiry_callback(
        self,
    ) -> None:
        with test_workspace("sf201-component-pending-race") as workspace:
            script = _write_fake_server(workspace)
            runtime = self._runtime(
                script,
                "normal",
                pending_timeout=2,
            )
            started = runtime.start_session(workspace)
            thread_id = started["thread_id"]
            with runtime._pending_lock:
                pending = runtime._pending_clients[thread_id]
                stale_token = pending.expiration_token

            poll_entered = threading.Event()
            release_poll = threading.Event()
            original_poll = pending.client.poll

            def blocking_poll() -> int | None:
                poll_entered.set()
                if not release_poll.wait(timeout=2):
                    raise AssertionError("Pending poll was not released.")
                return original_poll()

            pending.client.poll = blocking_poll
            result: dict[str, object] = {}

            def resume() -> None:
                try:
                    result["value"] = runtime.resume_session(
                        thread_id,
                        workspace,
                    )
                except BaseException as exc:
                    result["error"] = exc

            resume_thread = threading.Thread(target=resume)
            resume_thread.start()
            self.assertTrue(poll_entered.wait(timeout=2))

            expiry_thread = threading.Thread(
                target=runtime._expire_pending,
                args=(thread_id, pending.client, stale_token),
            )
            expiry_thread.start()
            time.sleep(0.05)
            self.assertTrue(expiry_thread.is_alive())

            release_poll.set()
            resume_thread.join(timeout=2)
            expiry_thread.join(timeout=2)
            self.assertFalse(resume_thread.is_alive())
            self.assertFalse(expiry_thread.is_alive())
            self.assertNotIn("error", result)
            self.assertEqual(
                result["value"]["thread_id"],
                thread_id,
            )
            with runtime._pending_lock:
                renewed = runtime._pending_clients[thread_id]
                self.assertIs(renewed, pending)
                self.assertIsNot(
                    renewed.expiration_token,
                    stale_token,
                )
            runtime.close()


class CodexWorkerAdapterComponentTests(unittest.TestCase):
    @staticmethod
    def _prepare_start(
        adapter: CodexWorkerAdapter,
        scenario: WorkerConformanceScenario,
    ) -> None:
        prepared = adapter.execute(
            scenario.request(
                "prepare",
                {
                    "work_item": {
                        "id": scenario.work_item_id,
                        "project_id": scenario.project_id,
                    },
                    "authority": {
                        "authority_ref": scenario.authority_ref,
                    },
                    "context": {
                        "content_sha256": scenario.context_sha256,
                    },
                },
                index=1,
            )
        )
        adapter.execute(
            scenario.request(
                "start",
                {
                    "prepared_run": copy.deepcopy(
                        prepared["result"]["prepared_run"]
                    )
                },
                index=2,
            )
        )

    def test_command_translation_duplicate_and_evidence(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf201-component-adapter") as workspace:
            provider_workspace = workspace / "provider"
            provider_workspace.mkdir()
            runtime = DeterministicCodexRuntime()
            adapter = CodexWorkerAdapter(
                workspace / "worker.db",
                workspace_bindings={
                    scenario.workspace_id: provider_workspace
                },
                runtime=runtime,
            )
            self._prepare_start(adapter, scenario)
            request = scenario.request(
                "send",
                {"command": scenario.command("worker.steer", index=3)},
                index=3,
            )
            first = adapter.execute(request)
            duplicate = copy.deepcopy(request)
            duplicate["request_id"] = "request-sf201-duplicate"
            second = adapter.execute(duplicate)
            self.assertEqual(first["disposition"], "succeeded")
            self.assertEqual(second["disposition"], "duplicate")
            turns = [
                item for item in runtime.calls
                if item["operation"] == "turn"
            ]
            self.assertEqual(len(turns), 1)
            self.assertIn(
                "does not claim live same-turn steering",
                turns[0]["prompt"],
            )
            session = {
                "worker_session_id": scenario.worker_session_id,
                "session_generation": scenario.session_generation,
            }
            bundle = adapter.execute(
                scenario.request(
                    "collect-evidence",
                    {"session": session},
                    index=4,
                    idempotency_key=None,
                )
            )["result"]["evidence_bundle"]
            self.assertEqual(bundle["verdict"], "pass")
            self.assertEqual(
                bundle["provider"]["cli_version"],
                CODEX_CLI_VERSION,
            )

    def test_dispatched_failure_remains_uncertain_after_recovery(self) -> None:
        scenario = WorkerConformanceScenario()
        with test_workspace("sf201-component-uncertain") as workspace:
            provider_workspace = workspace / "provider"
            provider_workspace.mkdir()
            runtime = DeterministicCodexRuntime()
            adapter = CodexWorkerAdapter(
                workspace / "worker.db",
                workspace_bindings={
                    scenario.workspace_id: provider_workspace
                },
                runtime=runtime,
            )
            self._prepare_start(adapter, scenario)
            runtime.fail_next_turn = CodexRuntimeError(
                "response lost",
                reason="process-exited",
                dispatched=True,
            )
            request = scenario.request(
                "send",
                {"command": scenario.command("worker.prompt", index=3)},
                index=3,
            )
            self.assertEqual(
                adapter.execute(request)["disposition"],
                "uncertain",
            )
            duplicate = copy.deepcopy(request)
            duplicate["request_id"] = "request-sf201-uncertain-duplicate"
            self.assertEqual(
                adapter.execute(duplicate)["disposition"],
                "uncertain",
            )
            recovered = adapter.execute(
                scenario.request(
                    "recover",
                    {
                        "session": {
                            "worker_session_id": scenario.worker_session_id,
                            "session_generation": scenario.session_generation,
                        },
                        "cursor": scenario.cursor(),
                    },
                    index=4,
                )
            )
            outcomes = recovered["result"]["recovery_result"][
                "reconciled_effects"
            ]
            self.assertEqual(outcomes[0]["outcome"], "unknown")
            after = copy.deepcopy(request)
            after["request_id"] = "request-sf201-after-recovery"
            self.assertEqual(
                adapter.execute(after)["disposition"],
                "uncertain",
            )

    def test_failed_and_interrupted_turns_are_never_acknowledged(self) -> None:
        for status, reason in (
            ("failed", "turn-failed"),
            ("interrupted", "turn-interrupted"),
        ):
            with self.subTest(status=status):
                scenario = WorkerConformanceScenario(
                    worker_session_id=f"worker-session-{status}",
                    run_id=f"run-{status}",
                )
                with test_workspace(
                    f"sf201-component-terminal-{status}"
                ) as workspace:
                    provider_workspace = workspace / "provider"
                    provider_workspace.mkdir()
                    runtime = DeterministicCodexRuntime()
                    runtime.next_turn_status = status
                    runtime.next_turn_error = (
                        {"message": "OPENAI_API_KEY=sk-turn-secret"}
                        if status == "failed"
                        else None
                    )
                    adapter = CodexWorkerAdapter(
                        workspace / "worker.db",
                        workspace_bindings={
                            scenario.workspace_id: provider_workspace
                        },
                        runtime=runtime,
                    )
                    self._prepare_start(adapter, scenario)
                    response = adapter.execute(
                        scenario.request(
                            "send",
                            {
                                "command": scenario.command(
                                    "worker.prompt",
                                    index=3,
                                )
                            },
                            index=3,
                        )
                    )
                    self.assertEqual(response["disposition"], "uncertain")
                    self.assertFalse(response["operation_completed"])
                    self.assertEqual(
                        response["error"]["details"]["reason"],
                        reason,
                    )
                    self.assertNotIn(
                        "sk-turn-secret",
                        json.dumps(response, sort_keys=True),
                    )
                    if status == "failed":
                        self.assertIn(
                            "diagnostic_sha256",
                            response["error"]["details"],
                        )


if __name__ == "__main__":
    unittest.main()
