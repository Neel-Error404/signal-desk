from __future__ import annotations

import unittest

from elder_protocol.factory_operations import AuditReplay, ProjectionRuntime, WorkRoom
from tests._sf203_support import StaticWorkspaceAuthority, running_fixture
from tests._support import test_workspace


class AuditReplayComponentTests(unittest.TestCase):
    def test_snapshot_is_digest_bound_and_rebuild_stable(self) -> None:
        with test_workspace("sf304-audit") as workspace:
            _, controller, aggregate, binding, _, session = running_fixture(
                workspace
            )
            ProjectionRuntime(controller.path).rebuild_all()
            room = WorkRoom(
                controller.path,
                session.path,
                workspace_authority=StaticWorkspaceAuthority(binding),
            )
            audit = AuditReplay(controller.path, room)
            arguments = {
                "project_id": aggregate["run"]["project_id"],
                "work_item_id": aggregate["initial_binding"]["work_item_id"],
                "observed_at": "2026-08-14T09:00:00+00:00",
            }
            first = audit.snapshot(**arguments)
            self.assertEqual(first["replay"]["status"], "verified")
            self.assertGreater(first["replay"]["journal_entry_count"], 0)
            self.assertTrue(
                all(
                    item["actor"] is not None
                    for item in first["entries"]
                    if item["source_kind"] == "journal"
                )
            )
            self.assertTrue(
                any(
                    "authority-not-recorded" in item["limitations"]
                    for item in first["entries"]
                )
            )

            ProjectionRuntime(controller.path).rebuild_all()
            second = audit.snapshot(**arguments)
            self.assertEqual(
                first["replay"]["journal_entries_sha256"],
                second["replay"]["journal_entries_sha256"],
            )
            self.assertEqual(
                [
                    item["audit_entry_id"]
                    for item in first["entries"]
                    if item["source_kind"] == "journal"
                ],
                [
                    item["audit_entry_id"]
                    for item in second["entries"]
                    if item["source_kind"] == "journal"
                ],
            )


if __name__ == "__main__":
    unittest.main()
