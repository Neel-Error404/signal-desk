from __future__ import annotations

import unittest

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_workers import (
    FakeWorkerAdapter,
    WorkerAdapterConformanceRunner,
    WorkerCapabilityManifest,
)
from tests._support import test_workspace


class WorkerAdapterConformanceComponentTests(unittest.TestCase):
    def test_reusable_runner_covers_the_complete_fake_adapter(self) -> None:
        with test_workspace("sf200-conformance-runner") as workspace:
            adapter = FakeWorkerAdapter(workspace / "worker.db")
            report = WorkerAdapterConformanceRunner().run(adapter)
            self.assertEqual(report["status"], "pass")
            self.assertEqual(len(report["operations"]), 8)
            self.assertEqual(len(report["command_types"]), 3)
            self.assertEqual(
                report["checks"]["canonical-write-authority"],
                "none",
            )
            self.assertEqual(
                report["content_sha256"],
                __import__(
                    "elder_protocol.autonomy",
                    fromlist=["canonical_sha256"],
                ).canonical_sha256(
                    {
                        key: value
                        for key, value in report.items()
                        if key != "content_sha256"
                    }
                ),
            )

    def test_runner_rejects_partial_adapter_capability(self) -> None:
        with test_workspace("sf200-conformance-partial") as workspace:
            adapter = FakeWorkerAdapter(
                workspace / "worker.db",
                manifest=WorkerCapabilityManifest(
                    adapter_id="partial-worker",
                    implementation_version="1.0.0",
                    supported_operations=("prepare",),
                    supported_command_types=(),
                ),
            )
            with self.assertRaisesRegex(
                ProtocolError,
                "all eight worker operations",
            ):
                WorkerAdapterConformanceRunner().run(adapter)


if __name__ == "__main__":
    unittest.main()
