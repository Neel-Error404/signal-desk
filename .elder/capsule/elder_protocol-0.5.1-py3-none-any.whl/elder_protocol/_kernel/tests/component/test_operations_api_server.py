from __future__ import annotations

import base64
import hashlib
import http.client
import json
import re
import socket
import threading
import time
import unittest
from pathlib import Path

from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import FactoryOperationsBootstrap
from elder_protocol.factory_operations.api_contracts import (
    canonical_content_sha256,
)
from elder_protocol.factory_operations.api_server import OperationsApiRuntime
from elder_protocol.factory_operations.projections import ProjectionRuntime
from elder_protocol.io import json_text
from tests._support import test_workspace


class OperationsApiServerComponentTests(unittest.TestCase):
    class _RejectPrematurePermit:
        def __init__(self) -> None:
            self.acquire_calls = 0
            self.release_calls = 0

        def acquire(self, *, blocking: bool) -> bool:
            del blocking
            self.acquire_calls += 1
            raise AssertionError(
                "Long-poll capacity was acquired before request authorization."
            )

        def release(self) -> None:
            self.release_calls += 1

    @staticmethod
    def _auth_policy(path: Path, token: str) -> Path:
        policy = {
            "version": "1.0.0",
            "policy_id": "operations-api-auth-server-component",
            "issued_at": "2026-08-10T00:00:00+00:00",
            "expires_at": "2099-01-01T00:00:00+00:00",
            "clients": [
                {
                    "client_id": "local-operator",
                    "kind": "operator",
                    "identity_id": "identity:local-operator",
                    "enabled": True,
                    "bearer_token_sha256": hashlib.sha256(
                        token.encode("ascii")
                    ).hexdigest(),
                    "project_ids": ["example-agentic-product"],
                    "route_ids": [
                        "health-detail",
                        "readiness-detail",
                        "capabilities-get",
                        "projections-list",
                        "projection-get",
                        "journal-get",
                    ],
                }
            ],
            "content_sha256": "",
        }
        policy["content_sha256"] = canonical_content_sha256(policy)
        target = path / "auth-policy.json"
        target.write_text(json_text(policy), encoding="utf-8")
        return target

    @staticmethod
    def _request(
        runtime: OperationsApiRuntime,
        method: str,
        target: str,
        *,
        token: str | None = None,
    ) -> tuple[int, dict, dict[str, str]]:
        host, port = runtime.address
        connection = http.client.HTTPConnection(host, port, timeout=10)
        headers = {}
        if token is not None:
            headers = {
                "Authorization": f"Bearer {token}",
                "X-Elder-Client-Id": "local-operator",
            }
        connection.request(method, target, headers=headers)
        response = connection.getresponse()
        body = json.loads(response.read().decode("utf-8"))
        response_headers = {
            key.lower(): value for key, value in response.getheaders()
        }
        status = response.status
        connection.close()
        return status, body, response_headers

    @staticmethod
    def _request_bytes(
        runtime: OperationsApiRuntime,
        target: str,
    ) -> tuple[int, bytes, dict[str, str]]:
        host, port = runtime.address
        connection = http.client.HTTPConnection(host, port, timeout=10)
        connection.request("GET", target)
        response = connection.getresponse()
        body = response.read()
        headers = {
            key.lower(): value for key, value in response.getheaders()
        }
        status = response.status
        connection.close()
        return status, body, headers

    def test_real_loopback_server_enforces_transport_and_auth_contracts(
        self,
    ) -> None:
        token = base64.urlsafe_b64encode(b"s" * 32).decode(
            "ascii"
        ).rstrip("=")
        with test_workspace("sf107-api-server") as workspace:
            store = workspace / "operations.db"
            FactoryOperationsBootstrap(store).initialize()
            ProjectionRuntime(store).rebuild_all()
            policy_path = self._auth_policy(workspace, token)
            runtime = OperationsApiRuntime(
                store_path=store,
                auth_policy_path=policy_path,
                host="127.0.0.1",
                port=0,
            )
            thread = threading.Thread(
                target=runtime.serve_forever,
                name="sf107-component-http-server",
            )
            thread.start()
            try:
                status, body, headers = self._request(
                    runtime,
                    "GET",
                    "/health/live",
                )
                self.assertEqual(status, 200)
                self.assertEqual(body["status"], "alive")
                self.assertNotIn("data", body)
                self.assertEqual(headers["cache-control"], "no-store")
                self.assertEqual(
                    headers["x-content-type-options"],
                    "nosniff",
                )
                self.assertEqual(headers["x-frame-options"], "DENY")
                self.assertNotIn("access-control-allow-origin", headers)
                self.assertNotIn("set-cookie", headers)

                status, html, headers = self._request_bytes(
                    runtime,
                    "/control-room",
                )
                self.assertEqual(status, 200)
                self.assertIn(b"Elder Factory Control Room", html)
                self.assertEqual(
                    headers["content-type"],
                    "text/html; charset=utf-8",
                )
                self.assertIn(
                    "connect-src 'self'",
                    headers["content-security-policy"],
                )
                self.assertNotIn("set-cookie", headers)

                status, script, headers = self._request_bytes(
                    runtime,
                    "/control-room/app.js",
                )
                self.assertEqual(status, 200)
                self.assertIn(b"/v1/owner-portfolio", script)
                self.assertEqual(
                    headers["content-type"],
                    "text/javascript; charset=utf-8",
                )

                status, icon, headers = self._request_bytes(
                    runtime,
                    "/control-room/favicon.svg",
                )
                self.assertEqual(status, 200)
                self.assertIn(b"<svg", icon)
                self.assertEqual(
                    headers["content-type"],
                    "image/svg+xml",
                )

                status, body, _ = self._request(
                    runtime,
                    "GET",
                    "/health/ready",
                )
                self.assertEqual(status, 200)
                self.assertTrue(body["ready"])
                self.assertEqual(len(body["projections"]), 7)

                status, body, _ = self._request(
                    runtime,
                    "GET",
                    "/v1/capabilities",
                )
                self.assertEqual(status, 401)
                self.assertEqual(
                    body["error"]["reason_code"],
                    "authentication-failed",
                )

                status, body, _ = self._request(
                    runtime,
                    "GET",
                    "/v1/capabilities",
                    token=token,
                )
                self.assertEqual(status, 200)
                self.assertEqual(body["route_id"], "capabilities-get")
                self.assertEqual(
                    set(body["data"]["capabilities"]),
                    {"decisions", "events", "projections"},
                )

                status, body, _ = self._request(
                    runtime,
                    "GET",
                    "/v1/projections/products",
                    token=token,
                )
                self.assertEqual(status, 200)
                self.assertEqual(
                    body["data"]["projection"]["projection_id"],
                    "products",
                )

                status, body, _ = self._request(
                    runtime,
                    "GET",
                    "/v1/journal",
                    token=token,
                )
                self.assertEqual(status, 200)
                self.assertEqual(
                    body["data"]["integrity"]["status"],
                    "verified",
                )

                status, body, _ = self._request(
                    runtime,
                    "POST",
                    "/v1/capabilities",
                    token=token,
                )
                self.assertEqual(status, 405)
                self.assertEqual(
                    body["error"]["reason_code"],
                    "method-not-allowed",
                )
            finally:
                runtime.close()
                thread.join(timeout=15)
            self.assertFalse(thread.is_alive())
            self.assertEqual(
                runtime._api_store.runtime()["status"],
                "stopped",
            )

    def test_runtime_rejects_non_numeric_loopback_binding(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "numeric loopback"):
            OperationsApiRuntime(
                store_path=Path("ignored.db"),
                auth_policy_path=Path("ignored-policy.json"),
                host="localhost",
                port=0,
            )

    def test_long_poll_capacity_is_not_consumed_before_authorization(
        self,
    ) -> None:
        token = base64.urlsafe_b64encode(b"a" * 32).decode(
            "ascii"
        ).rstrip("=")
        with test_workspace("sf107-api-long-poll-admission") as workspace:
            store = workspace / "operations.db"
            FactoryOperationsBootstrap(store).initialize()
            ProjectionRuntime(store).rebuild_all()
            runtime = OperationsApiRuntime(
                store_path=store,
                auth_policy_path=self._auth_policy(workspace, token),
                host="127.0.0.1",
                port=0,
            )
            permit = self._RejectPrematurePermit()
            runtime.service._long_poll_slots = permit
            thread = threading.Thread(
                target=runtime.serve_forever,
                name="sf107-long-poll-admission-server",
            )
            thread.start()
            try:
                target = (
                    "/v1/projects/example-agentic-product/events"
                    "?limit=1&wait_seconds=30"
                )
                status, body, _ = self._request(runtime, "GET", target)
                self.assertEqual(status, 401)
                self.assertEqual(
                    body["error"]["reason_code"],
                    "authentication-failed",
                )

                status, body, _ = self._request(
                    runtime,
                    "GET",
                    target,
                    token=token,
                )
                self.assertEqual(status, 403)
                self.assertEqual(
                    body["error"]["reason_code"],
                    "authorization-failed",
                )

                status, body, _ = self._request(
                    runtime,
                    "GET",
                    (
                        "/v1/projects/example-agentic-product/events"
                        "?wait_seconds=invalid"
                    ),
                    token=token,
                )
                self.assertEqual(status, 400)
                self.assertEqual(
                    body["error"]["reason_code"],
                    "invalid-request",
                )
                self.assertEqual(permit.acquire_calls, 0)
                self.assertEqual(permit.release_calls, 0)
            finally:
                runtime.close()
                thread.join(timeout=15)
            self.assertFalse(thread.is_alive())

    def test_graceful_drain_waits_for_admitted_request_and_blocks_new_admission(
        self,
    ) -> None:
        token = base64.urlsafe_b64encode(b"d" * 32).decode(
            "ascii"
        ).rstrip("=")
        with test_workspace("sf107-api-graceful-drain") as workspace:
            store = workspace / "operations.db"
            FactoryOperationsBootstrap(store).initialize()
            ProjectionRuntime(store).rebuild_all()
            runtime = OperationsApiRuntime(
                store_path=store,
                auth_policy_path=self._auth_policy(workspace, token),
                host="127.0.0.1",
                port=0,
            )
            admitted = threading.Event()
            release = threading.Event()
            original_handle = runtime.service.handle

            def blocking_handle(**kwargs):
                if kwargs["target"] == "/health/live":
                    admitted.set()
                    if not release.wait(timeout=5):
                        raise AssertionError(
                            "Timed out waiting to release admitted request."
                        )
                return original_handle(**kwargs)

            runtime.service.handle = blocking_handle
            server_thread = threading.Thread(
                target=runtime.serve_forever,
                name="sf107-graceful-drain-server",
            )
            server_thread.start()
            request_result = {}

            def request_live() -> None:
                request_result["value"] = self._request(
                    runtime,
                    "GET",
                    "/health/live",
                )

            request_thread = threading.Thread(
                target=request_live,
                name="sf107-graceful-drain-request",
            )
            request_thread.start()
            self.assertTrue(admitted.wait(timeout=10))
            self.assertEqual(runtime.server.active_request_count, 1)

            close_thread = threading.Thread(
                target=runtime.close,
                name="sf107-graceful-drain-close",
            )
            close_thread.start()
            deadline = time.monotonic() + 5
            while runtime.server.accepting_requests and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertFalse(runtime.server.accepting_requests)
            self.assertTrue(close_thread.is_alive())

            server_socket, client_socket = socket.socketpair()
            try:
                runtime.server.process_request(
                    server_socket,
                    ("127.0.0.1", 1),
                )
                response = client_socket.recv(65536).decode("utf-8")
            finally:
                client_socket.close()
            self.assertIn("503 Service Unavailable", response)
            self.assertIn("service-draining", response)
            self.assertEqual(runtime.server.active_request_count, 1)

            release.set()
            request_thread.join(timeout=10)
            close_thread.join(timeout=15)
            server_thread.join(timeout=15)
            self.assertFalse(request_thread.is_alive())
            self.assertFalse(close_thread.is_alive())
            self.assertFalse(server_thread.is_alive())
            self.assertEqual(request_result["value"][0], 200)
            self.assertEqual(
                runtime._api_store.runtime()["status"],
                "stopped",
            )

    def test_graceful_drain_rejects_next_request_on_keep_alive_connection(
        self,
    ) -> None:
        token = base64.urlsafe_b64encode(b"k" * 32).decode(
            "ascii"
        ).rstrip("=")
        with test_workspace("sf107-api-keep-alive-drain") as workspace:
            store = workspace / "operations.db"
            FactoryOperationsBootstrap(store).initialize()
            ProjectionRuntime(store).rebuild_all()
            runtime = OperationsApiRuntime(
                store_path=store,
                auth_policy_path=self._auth_policy(workspace, token),
                host="127.0.0.1",
                port=0,
            )
            server_thread = threading.Thread(
                target=runtime.serve_forever,
                name="sf107-keep-alive-drain-server",
            )
            server_thread.start()
            connection = http.client.HTTPConnection(*runtime.address, timeout=10)
            try:
                connection.request("GET", "/health/live")
                first = connection.getresponse()
                first_body = json.loads(first.read().decode("utf-8"))
                self.assertEqual(first.status, 200)
                self.assertEqual(first_body["status"], "alive")
                self.assertEqual(runtime.server.active_request_count, 1)

                close_thread = threading.Thread(
                    target=runtime.close,
                    name="sf107-keep-alive-drain-close",
                )
                close_thread.start()
                deadline = time.monotonic() + 5
                while (
                    runtime.server.accepting_requests
                    and time.monotonic() < deadline
                ):
                    time.sleep(0.01)
                self.assertFalse(runtime.server.accepting_requests)
                self.assertTrue(close_thread.is_alive())

                connection.request("GET", "/health/live")
                second = connection.getresponse()
                second_body = json.loads(second.read().decode("utf-8"))
                self.assertEqual(second.status, 503)
                self.assertEqual(
                    second_body["error"]["reason_code"],
                    "service-draining",
                )
                self.assertEqual(second.getheader("Connection"), "close")

                close_thread.join(timeout=15)
                server_thread.join(timeout=15)
                self.assertFalse(close_thread.is_alive())
                self.assertFalse(server_thread.is_alive())
                self.assertEqual(
                    runtime._api_store.runtime()["status"],
                    "stopped",
                )
            finally:
                connection.close()
                runtime.close()
                server_thread.join(timeout=15)

    def test_all_registered_routes_resolve_to_the_exact_contract(self) -> None:
        token = base64.urlsafe_b64encode(b"r" * 32).decode(
            "ascii"
        ).rstrip("=")
        substitutions = {
            "projection_id": "products",
            "project_id": "example-agentic-product",
            "factory_id": "product-factory-example-agentic-product",
            "signal_id": "signal-github-001",
            "work_item_id": "work-item-build-repair",
            "transition_id": "transition-record-001",
            "command_id": "dispatch-command-001",
            "run_id": "factory-run-001",
            "event_id": "public-event-001",
            "decision_id": "decision-001",
            "dispatch_id": "dispatch-001",
        }
        with test_workspace("sf107-api-route-resolution") as workspace:
            store = workspace / "operations.db"
            FactoryOperationsBootstrap(store).initialize()
            ProjectionRuntime(store).rebuild_all()
            runtime = OperationsApiRuntime(
                store_path=store,
                auth_policy_path=self._auth_policy(workspace, token),
                host="127.0.0.1",
                port=0,
            )
            thread = threading.Thread(
                target=runtime.serve_forever,
                name="sf107-route-resolution-server",
            )
            thread.start()
            try:
                routes = runtime.service.contracts.route_registry["routes"]
                self.assertEqual(len(routes), 49)
                for expected in routes:
                    with self.subTest(route_id=expected["id"]):
                        target = re.sub(
                            r"\{([a-z0-9_]+)\}",
                            lambda match: substitutions[match.group(1)],
                            expected["path"],
                        )
                        resolved, path_values = (
                            runtime.service._resolve_route(
                                expected["method"],
                                target,
                            )
                        )
                        self.assertEqual(resolved, expected)
                        self.assertEqual(
                            path_values,
                            {
                                name: substitutions[name]
                                for name in re.findall(
                                    r"\{([a-z0-9_]+)\}",
                                    expected["path"],
                                )
                            },
                        )
                        with self.assertRaisesRegex(
                            ProtocolError,
                            "method-not-allowed",
                        ):
                            runtime.service._resolve_route(
                                "PATCH",
                                target,
                            )
            finally:
                runtime.close()
                thread.join(timeout=15)
            self.assertFalse(thread.is_alive())


if __name__ == "__main__":
    unittest.main()
