from __future__ import annotations

from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations import DurableSessionController
from elder_protocol.factory_workers import (
    FakeWorkerAdapter,
    WorkerConformanceScenario,
)
from elder_protocol.governance import finalize_checkpoint
from tests.component import test_run_controller as run_controller_tests


BASE_TIME = "2026-08-11T01:07:00+00:00"
DEADLINE = "2026-08-12T00:00:00+00:00"


class StaticWorkspaceAuthority:
    def __init__(self, binding: dict[str, Any]) -> None:
        self.binding = binding

    def validate_workspace_binding(
        self,
        binding: dict[str, Any],
        *,
        at: str | None = None,
    ) -> dict[str, Any]:
        if binding != self.binding:
            raise AssertionError("Test workspace authority binding changed.")
        return self.binding

    def current_workspace_binding(
        self,
        run_id: str,
        *,
        at: str | None = None,
    ) -> dict[str, Any]:
        del at
        if run_id != self.binding["run_id"]:
            raise AssertionError("Test workspace authority run changed.")
        return self.binding


def workspace_binding(aggregate: dict[str, Any]) -> dict[str, Any]:
    return {
        "run_id": aggregate["run"]["id"],
        "workspace_id": aggregate["workspace"]["id"],
        "path": aggregate["initial_binding"]["workspace_path"],
        "lease_owner": "sf203-local-worker",
        "lease_generation": 1,
        "sandbox": {
            "mode": "workspace-write",
            "approval_policy": "on-request",
            "network_access": False,
        },
        "sandbox_sha256": canonical_sha256(
            {
                "mode": "workspace-write",
                "approval_policy": "on-request",
                "network_access": False,
            }
        ),
        "inspection_sha256": "a" * 64,
    }


def control_command(
    aggregate: dict[str, Any],
    binding: dict[str, Any],
    operation: str,
    *,
    index: int,
    payload: dict[str, Any] | None = None,
    requested_by: str | None = None,
    at: str = BASE_TIME,
    reason: str | None = None,
) -> dict[str, Any]:
    payload = payload or {}
    return {
        "version": "1.0.0",
        "control_id": f"session-control-sf203-{operation.replace('-', '')}-{index}",
        "idempotency_key": f"sf203-{operation}-{index}-idempotency",
        "operation": operation,
        "project_id": aggregate["run"]["project_id"],
        "run_id": aggregate["run"]["id"],
        "worker_session_id": aggregate["worker_session"]["id"],
        "workspace_id": aggregate["workspace"]["id"],
        "workspace_binding_sha256": canonical_sha256(binding),
        "session_generation": aggregate["worker_session"]["payload"][
            "session_generation"
        ],
        "requested_by_identity_id": (
            requested_by or aggregate["initial_binding"]["created_by"]
        ),
        "submitted_at": at,
        "deadline_at": DEADLINE,
        "reason": reason or f"Apply SF-203 {operation} control.",
        "payload": payload,
        "payload_sha256": canonical_sha256(payload),
    }


def register_canonical_checkpoint(
    controller: Any,
    aggregate: dict[str, Any],
    *,
    checkpoint_id: str,
    at: str,
) -> dict[str, Any]:
    checkpoint = finalize_checkpoint(
        {
            "version": "0.5.1",
            "id": checkpoint_id,
            "project_id": aggregate["run"]["project_id"],
            "delegation_id": aggregate["initial_binding"][
                "elder_delegation_id"
            ],
            "run_id": aggregate["initial_binding"]["elder_child_run_id"],
            "sequence": 1,
            "action_sequence": 1,
            "status": "running",
            "completed_scope": [],
            "remaining_scope": ["sf-203-session-control"],
            "evidence_refs": [],
            "budget_consumed": {
                "token_limit": 10,
                "cost_limit_usd": 0,
                "tool_call_limit": 1,
                "elapsed_seconds_limit": 10,
            },
            "previous_checkpoint_sha256": None,
            "created_at": at,
        }
    )
    controller._coordination.records["checkpoints"][
        checkpoint["id"]
    ] = checkpoint
    return checkpoint


def prepared_fixture(
    workspace: Path,
) -> tuple[
    run_controller_tests.RunControllerComponentTests,
    Any,
    dict[str, Any],
    dict[str, Any],
    FakeWorkerAdapter,
    DurableSessionController,
]:
    helper = run_controller_tests.RunControllerComponentTests(
        methodName="runTest"
    )
    controller, submission, _ = helper._controller_fixture(workspace)
    aggregate = controller.bind_start(
        submission,
        at="2026-08-11T01:04:01+00:00",
    )
    provision = helper._command(
        aggregate,
        ["workspace-provision"],
        suffix="sf203-workspace-provision",
        payload={
            "repository": aggregate["initial_binding"]["repository_root"],
            "base_revision": aggregate["initial_binding"]["base_revision"],
        },
        evidence_refs={},
        at="2026-08-11T01:05:00+00:00",
    )
    assert controller.apply(
        provision,
        at="2026-08-11T01:05:00+00:00",
    )["status"] == "applied"
    aggregate = controller.get(aggregate["run"]["id"])
    ready = helper._command(
        aggregate,
        ["workspace-ready"],
        suffix="sf203-workspace-ready",
        payload={
            "path": aggregate["initial_binding"]["workspace_path"],
            "isolation_mode": aggregate["initial_binding"]["isolation_mode"],
        },
        evidence_refs={
            "workspace verification": "evidence:sf203-workspace-ready"
        },
        at="2026-08-11T01:06:00+00:00",
    )
    assert controller.apply(
        ready,
        at="2026-08-11T01:06:00+00:00",
    )["status"] == "applied"
    aggregate = controller.get(aggregate["run"]["id"])
    binding = workspace_binding(aggregate)
    adapter = FakeWorkerAdapter(
        workspace / "sf203-worker.db",
        timestamp="2026-08-11T01:07:00+00:00",
    )
    session = DurableSessionController(
        workspace / "sf203-session.db",
        run_controller=controller,
        adapter=adapter,
        workspace_authority=StaticWorkspaceAuthority(binding),
        workspace_binding=binding,
        workspace_binding_at=BASE_TIME,
    )
    session.initialize()
    return helper, controller, aggregate, binding, adapter, session


def running_fixture(
    workspace: Path,
) -> tuple[
    run_controller_tests.RunControllerComponentTests,
    Any,
    dict[str, Any],
    dict[str, Any],
    FakeWorkerAdapter,
    DurableSessionController,
]:
    helper, controller, aggregate, binding, adapter, session = prepared_fixture(
        workspace
    )
    start = control_command(
        aggregate,
        binding,
        "start",
        index=1,
        at="2026-08-11T01:07:00+00:00",
    )
    session.submit(start)
    started = session.execute_once(
        owner_id="sf203-controller",
        at="2026-08-11T01:07:00+00:00",
        lease_seconds=120,
    )
    assert started is not None and started["status"] == "succeeded", started
    aggregate = controller.get(aggregate["run"]["id"])
    prepare = helper._command(
        aggregate,
        ["run-claim", "workspace-bind", "run-start"],
        suffix="sf203-prepare-work-item-start",
        payload={
            "authority_ref": aggregate["initial_binding"]["authority_ref"],
            "run_id": aggregate["run"]["id"],
            "worker_session_id": aggregate["worker_session"]["id"],
        },
        evidence_refs={
            "active lease": aggregate["initial_binding"]["runtime_lease_ref"]
        },
        at="2026-08-11T01:08:00+00:00",
    )
    pending = controller.prepare_work_item_start(
        prepare,
        at="2026-08-11T01:08:00+00:00",
    )
    controller._transitions.apply(
        pending["result"]["transition_command"],
        at="2026-08-11T01:08:01+00:00",
    )
    controller.confirm_work_item_start(
        prepare["command_id"],
        at="2026-08-11T01:08:02+00:00",
    )
    return (
        helper,
        controller,
        controller.get(aggregate["run"]["id"]),
        binding,
        adapter,
        session,
    )


def scenario_for(
    aggregate: dict[str, Any],
    *,
    timestamp: str,
) -> WorkerConformanceScenario:
    return WorkerConformanceScenario(
        project_id=aggregate["run"]["project_id"],
        work_item_id=aggregate["run"]["payload"]["work_item_id"],
        run_id=aggregate["run"]["id"],
        worker_session_id=aggregate["worker_session"]["id"],
        session_generation=aggregate["worker_session"]["payload"][
            "session_generation"
        ],
        workspace_id=aggregate["workspace"]["id"],
        authority_ref=aggregate["initial_binding"]["authority_ref"],
        context_sha256=aggregate["initial_binding"]["context_packet_sha256"],
        correlation_id=aggregate["run"]["correlation_id"],
        causation_id="session-control-sf203-event",
        timestamp=timestamp,
        deadline=DEADLINE,
    )
