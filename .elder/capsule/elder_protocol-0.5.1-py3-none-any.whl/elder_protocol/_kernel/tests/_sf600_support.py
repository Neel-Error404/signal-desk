from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Iterator


@dataclass
class ScriptedCursor:
    rows: list[Any] = field(default_factory=list)
    description: list[tuple[str]] = field(default_factory=list)

    def fetchone(self) -> Any | None:
        return self.rows.pop(0) if self.rows else None

    def fetchall(self) -> list[Any]:
        rows = list(self.rows)
        self.rows.clear()
        return rows


class ScriptedConnection:
    def __init__(self, responses: list[list[Any]] | None = None):
        self.responses = list(responses or [])
        self.calls: list[tuple[str, tuple[Any, ...] | None]] = []
        self.closed = False
        self.commits = 0
        self.rollbacks = 0

    def execute(
        self,
        sql: str,
        parameters: tuple[Any, ...] | None = None,
    ) -> ScriptedCursor:
        normalized = " ".join(sql.split())
        self.calls.append((normalized, parameters))
        rows = self.responses.pop(0) if self.responses else []
        return ScriptedCursor(list(rows))

    @contextmanager
    def transaction(self) -> Iterator[None]:
        try:
            yield
            self.commits += 1
        except Exception:
            self.rollbacks += 1
            raise

    def commit(self) -> None:
        self.commits += 1

    def rollback(self) -> None:
        self.rollbacks += 1

    def close(self) -> None:
        self.closed = True


def message() -> dict[str, Any]:
    return {
        "message_id": "message-sf600",
        "topic": "factory.run",
        "message_key": "run-sf600",
        "payload": {
            "project_id": "elder-protocol",
            "work_item_id": "sf-600",
            "run_id": "run-sf600",
        },
        "available_at": "2026-08-14T21:45:00+00:00",
    }
