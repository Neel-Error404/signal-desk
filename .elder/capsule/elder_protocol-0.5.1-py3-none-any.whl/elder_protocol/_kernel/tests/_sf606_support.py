from __future__ import annotations

import copy
from pathlib import Path
from typing import Any
from datetime import UTC, datetime, timedelta

from elder_protocol.constants import PROTOCOL_DIR, ROOT
from elder_protocol.factory_operations.institutional_l2_qualification import (
    finalize_institutional_l2_packet,
)
from elder_protocol.io import load_json


HISTORICAL_REVISION = "d8c8eb3f5412bf1fe062a6cee55e35dd45e46589"
SF605_REVISION = "6962d34c1423f44e064c435f14a79320192f7da2"
HISTORICAL_BUNDLE = (
    ROOT
    / "docs"
    / "evidence"
    / "artifacts"
    / "p4-8a-run-31088377331"
    / "bundle.json"
)


def canonical_inputs() -> tuple[dict[str, Any], dict[str, Any]]:
    return (
        load_json(PROTOCOL_DIR / "qualification-policy.json"),
        load_json(PROTOCOL_DIR / "operational-maturity.json"),
    )


def _status(
    status: str,
    identifier: str,
    *,
    reason: str | None = None,
) -> dict[str, Any]:
    return {
        "status": status,
        "reason": reason or f"{identifier} fixture evidence.",
        "evidence_ids": (
            [f"evidence:{identifier}"] if status == "verified" else []
        ),
    }


def compliant_packet(
    *,
    ratification_status: str = "approved",
) -> dict[str, Any]:
    _, maturity = canonical_inputs()
    benchmark = maturity["institutional_standard"]["benchmarks"]["L2"]
    work_items = []
    start = datetime(2026, 7, 16, 14, 15, tzinfo=UTC)
    for index in range(1, 21):
        observed_at = start + timedelta(
            seconds=(30 * 86400 * (index - 1)) // 19
        )
        work_items.append(
            {
                "id": f"hosted-work-{index:02d}",
                "source_revision": HISTORICAL_REVISION,
                "observed_at": observed_at.isoformat(),
                "hosted": True,
                "authenticated": True,
                "bounded": True,
                "reviewable_pull_request": True,
                "pull_request_url": (
                    f"https://github.com/Neel-Error404/"
                    f"elder-protocol/pull/{index + 100}"
                ),
                "without_internal_inspection": True,
                "external_identity": True,
                "trace": True,
                "ordered_tests": True,
                "provenance": True,
                "authority_escapes": 0,
                "secret_exposures": 0,
                "evidence_ids": [f"evidence:work-{index:02d}"],
            }
        )
    dimensions = {
        dimension["id"]: {
            "level": "L2",
            **_status("verified", f"dimension-{dimension['id']}"),
        }
        for dimension in maturity["institutional_standard"]["dimensions"]
    }
    ratification = {
        "status": ratification_status,
        "reason": "Human owner ratification fixture.",
        "evidence_ids": (
            ["evidence:human-ratification"]
            if ratification_status == "approved"
            else []
        ),
    }
    return finalize_institutional_l2_packet(
        {
            "version": "1.0.0",
            "qualification_id": "sf606-compliant-fixture",
            "project_id": "elder-protocol",
            "repository": "Neel-Error404/elder-protocol",
            "source_revision": HISTORICAL_REVISION,
            "artifact_sha256": (
                "2aba1a7e3cb185a6161b709bd103dda7a2c258e54869f0217637080c1c045dae"
            ),
            "deployment_id": "fixture-deployment",
            "hosted_run_id": "31088377331",
            "bundle_id": "GHA-31088377331-1-L2",
            "bundle_sha256": (
                "8f9ee4f34e244e51ae3fe5d8428749ca6f0fca4443bbc6370effa314aa7ef5c0"
            ),
            "environment": "production",
            "observed_from": "2026-07-16T14:15:00+00:00",
            "observed_until": "2026-08-15T14:15:00+00:00",
            "work_items": work_items,
            "controls": {
                identifier: _status("verified", f"control-{identifier}")
                for identifier in benchmark["required_controls"]
            },
            "exercises": {
                identifier: _status("verified", f"exercise-{identifier}")
                for identifier in benchmark["required_exercises"]
            },
            "dimensions": dimensions,
            "independent_review": _status(
                "verified",
                "independent-review",
            ),
            "human_ratification": ratification,
            "contradictions": [],
            "attestation": None,
        }
    )


def blocked_packet() -> dict[str, Any]:
    _, maturity = canonical_inputs()
    benchmark = maturity["institutional_standard"]["benchmarks"]["L2"]
    dimensions = {
        dimension["id"]: {
            "level": "L1",
            "status": "blocked",
            "reason": (
                "No exact-revision hosted institutional history establishes "
                "this dimension at L2."
            ),
            "evidence_ids": [],
        }
        for dimension in maturity["institutional_standard"]["dimensions"]
    }
    return finalize_institutional_l2_packet(
        {
            "version": "1.0.0",
            "qualification_id": "sf606-2026-08-15",
            "project_id": "elder-protocol",
            "repository": "Neel-Error404/elder-protocol",
            "source_revision": SF605_REVISION,
            "artifact_sha256": None,
            "deployment_id": None,
            "hosted_run_id": None,
            "bundle_id": "GHA-31088377331-1-L2",
            "bundle_sha256": (
                "8f9ee4f34e244e51ae3fe5d8428749ca6f0fca4443bbc6370effa314aa7ef5c0"
            ),
            "environment": "production",
            "observed_from": "2026-08-15T14:15:00+00:00",
            "observed_until": "2026-08-15T14:15:00+00:00",
            "work_items": [],
            "controls": {
                identifier: {
                    "status": "blocked",
                    "reason": (
                        "Only inactive or historical evidence exists; no "
                        "verified exact-revision hosted control is active."
                    ),
                    "evidence_ids": [],
                }
                for identifier in benchmark["required_controls"]
            },
            "exercises": {
                identifier: {
                    "status": "blocked",
                    "reason": (
                        "The exercise has not been executed in the exact "
                        "hosted production qualification environment."
                    ),
                    "evidence_ids": [],
                }
                for identifier in benchmark["required_exercises"]
            },
            "dimensions": dimensions,
            "independent_review": {
                "status": "blocked",
                "reason": (
                    "No independent review covers a current signed bundle "
                    "and 30-day exact-revision hosted work history."
                ),
                "evidence_ids": [],
            },
            "human_ratification": {
                "status": "withheld",
                "reason": (
                    "The owner cannot ratify L2 until every mandatory "
                    "institutional prerequisite passes."
                ),
                "evidence_ids": [],
            },
            "contradictions": [
                {
                    "id": "branch-protection-plan-block",
                    "status": "active",
                    "reason": (
                        "GitHub returned HTTP 403 because branch protection "
                        "is unavailable for the current private-repository plan."
                    ),
                    "evidence_ids": ["github-api:branch-protection-2026-08-15"],
                },
                {
                    "id": "historical-bundle-wrong-revision",
                    "status": "active",
                    "reason": (
                        "The current signed L2 bundle is bound to "
                        f"{HISTORICAL_REVISION}, not {SF605_REVISION}."
                    ),
                    "evidence_ids": ["bundle:GHA-31088377331-1-L2"],
                },
                {
                    "id": "no-current-hosted-run",
                    "status": "active",
                    "reason": (
                        "No GitHub Actions run or hosted delivery exists for "
                        "the SF-605 revision."
                    ),
                    "evidence_ids": ["github-actions:list-2026-08-15"],
                },
            ],
            "attestation": None,
        }
    )
def changed_packet(
    packet: dict[str, Any],
    change: Any,
) -> dict[str, Any]:
    updated = copy.deepcopy(packet)
    change(updated)
    return finalize_institutional_l2_packet(updated)


def write_packet(path: Path, packet: dict[str, Any]) -> None:
    import json

    path.write_text(
        json.dumps(packet, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
