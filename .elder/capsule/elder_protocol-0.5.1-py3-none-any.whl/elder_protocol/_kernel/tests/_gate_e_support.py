from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.errors import ProtocolError
from elder_protocol.factory_operations import (
    AuthorityDelegationIntegration,
    EvidenceTestPipeline,
    GovernedContextAssembly,
    SupervisedDeliveryService,
)
from elder_protocol.factory_operations.elder_boundary import (
    ElderBoundaryService,
    build_elder_boundary_snapshot,
)
from elder_protocol.protocol import validate_protocol
from tests._sf400_support import CLOCK_AT as BOUNDARY_CLOCK_AT, request_for
from tests._sf401_support import CLOCK_AT as CONTEXT_CLOCK_AT
from tests._sf402_support import VIEWED_AT
from tests._sf403_support import PIPELINE_AT
from tests._sf404_support import CountingSubmitter, build_environment


def classify_work_item(environment: dict[str, Any]) -> dict[str, Any]:
    snapshot = build_elder_boundary_snapshot()
    change_classes = {
        item["id"]
        for item in validate_protocol()["change-classes"]["classes"]
    }

    def classify(
        payload: dict[str, Any],
        request: dict[str, Any],
    ) -> dict[str, Any]:
        work_item = payload["work_item"]
        if (
            work_item["id"] != request["work_item_id"]
            or work_item["project_id"] != request["project_id"]
        ):
            raise ProtocolError(
                "Gate E classification work item does not match its request."
            )
        selected = work_item["change_class"]
        if selected not in change_classes:
            raise ProtocolError(
                f"Gate E classification is unknown: {selected}"
            )
        return {"change_class": selected}

    service = ElderBoundaryService(
        snapshot=snapshot,
        handlers={"classify": classify},
        state_path=environment["project"].parent
        / "gate-e-classification-boundary.db",
        clock=lambda: BOUNDARY_CLOCK_AT,
    )
    service.initialize()
    payload = {
        "work_item": {
            "id": environment["work"]["work_item"]["id"],
            "project_id": environment["work"]["work_item"]["project_id"],
            "change_class": environment["work"]["change_class"],
        }
    }
    request = request_for(
        snapshot,
        "classify",
        request_id="gate-e-classify-work-item",
        payload=payload,
    )
    request.update(
        {
            "project_id": environment["work"]["work_item"]["project_id"],
            "work_item_id": environment["work"]["work_item"]["id"],
            "run_id": environment["parent_run"]["id"],
            "payload_sha256": canonical_sha256(payload),
        }
    )
    response = service.decide(request)
    if response["disposition"] != "succeeded":
        raise ProtocolError(
            "Gate E work-item classification did not succeed."
        )
    return response


def restart_stack(environment: dict[str, Any]) -> dict[str, Any]:
    context = GovernedContextAssembly(
        operations_path=environment["database"],
        knowledge_path=environment["knowledge_path"],
        context_path=environment["context_path"],
        boundary_state_path=environment["boundary_state_path"],
        project_root=environment["project"],
        activation=environment["activation"],
        clock=lambda: CONTEXT_CLOCK_AT,
    )
    context.initialize()
    authority = AuthorityDelegationIntegration(
        operations_path=environment["database"],
        context_service=context,
        runtime_path=environment["runtime_path"],
        decision_path=environment["decision_path"],
        project_root=environment["project"],
        clock=lambda: VIEWED_AT,
    )
    authority.initialize()
    evidence = EvidenceTestPipeline(
        operations_path=environment["database"],
        authority_gate=authority,
        pipeline_path=environment["pipeline_path"],
        repository_root=environment["project"],
        clock=lambda: PIPELINE_AT,
    )
    evidence.initialize()
    delivery = SupervisedDeliveryService(
        operations_path=environment["database"],
        authority_gate=authority,
        evidence_pipeline=evidence,
        delivery_path=environment["delivery_service"].repository.path,
        clock=environment["clock"],
    )
    delivery.initialize()
    environment.update(
        {
            "service": context,
            "gate": authority,
            "pipeline": evidence,
            "delivery_service": delivery,
        }
    )
    return environment


def owner_trace(environment: dict[str, Any]) -> dict[str, Any]:
    classification = classify_work_item(environment)
    context = environment["service"].verify_for_use(
        environment["context"]["packet"]["id"],
        parent_run=environment["parent_run"],
        delegation=environment["delegation"],
        child_run=environment["child_run"],
        authorized_packet_sha256=environment["context"]["packet"][
            "content_sha256"
        ],
    )
    work_item_id = environment["work"]["work_item"]["id"]
    authority = environment["gate"].owner_view(
        work_item_id,
        at=environment["clock"](),
    )
    evidence = environment["pipeline"].owner_view(
        environment["plan"]["id"]
    )
    delivery = environment["delivery_service"].owner_view(
        environment["delivery_request"]["request_id"]
    )
    latest_authority = authority["entries"][-1]
    trace = {
        "version": "1.0.0",
        "project_id": environment["work"]["work_item"]["project_id"],
        "work_item_id": work_item_id,
        "objective": environment["work"]["work_item"]["payload"]["objective"],
        "classification": {
            "change_class": classification["result"]["change_class"],
            "decision_sha256": canonical_sha256(classification),
        },
        "context": {
            "packet_id": context["packet"]["id"],
            "packet_sha256": context["packet"]["content_sha256"],
            "authorized": True,
        },
        "authority": {
            "request_id": latest_authority["request_id"],
            "condition": latest_authority["condition"],
            "attention_required": latest_authority["attention_required"],
            "decision_sha256": environment["authority"]["decision"][
                "content_sha256"
            ],
        },
        "evidence": {
            "plan_id": evidence["plan_id"],
            "condition": evidence["condition"],
            "attention_required": evidence["attention_required"],
            "completion_sha256": environment["completion"]["content_sha256"],
        },
        "delivery": {
            "request_id": delivery["request_id"],
            "status": delivery["status"],
            "attention_required": delivery["attention_required"],
            "actionable_reason": delivery["actionable_reason"],
            "packet_sha256": (
                delivery["packet"]["content_sha256"]
                if delivery["packet"] is not None
                else None
            ),
            "provider_response_sha256": (
                canonical_sha256(delivery["provider_response"])
                if delivery["provider_response"] is not None
                else None
            ),
            "can_merge": delivery["can_merge"],
            "can_deploy": delivery["can_deploy"],
            "can_mutate_maturity": delivery["can_mutate_maturity"],
        },
    }
    trace["content_sha256"] = canonical_sha256(trace)
    return trace


def qualify_owner_workflow(workspace: Path) -> dict[str, Any]:
    environment = build_environment(workspace, prepare=False)
    restart_stack(environment)
    authorized = owner_trace(environment)
    ready = environment["delivery_service"].prepare_packet(
        environment["delivery_request"],
        environment["delivery_sources"],
        environment["execution"],
        title="Normalize component formatting",
        body="Bounded formatting with human merge.",
    )
    restart_stack(environment)
    ready_after_restart = owner_trace(environment)
    submitter = CountingSubmitter()
    opened = environment["delivery_service"].decide(
        environment["delivery_request"],
        environment["delivery_sources"],
        environment["execution"],
        submitter,
        actor_identity_id="founder",
        decision="submit",
        reason="Open the exact supervised pull request.",
    )
    restart_stack(environment)
    durable = owner_trace(environment)
    return {
        "environment": environment,
        "authorized": authorized,
        "ready": copy.deepcopy(ready),
        "ready_after_restart": ready_after_restart,
        "opened": copy.deepcopy(opened),
        "durable": durable,
        "provider_calls": submitter.calls,
    }
