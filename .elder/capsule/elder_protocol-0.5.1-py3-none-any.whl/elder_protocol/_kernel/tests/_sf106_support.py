from __future__ import annotations

from pathlib import Path

from elder_protocol.factory_operations import JournalInitializer
from tests.component import test_run_controller as run_controller_tests


def journaled_running_controller(workspace: Path):
    helper = run_controller_tests.RunControllerComponentTests(
        methodName="runTest"
    )
    controller, submission, inspector = helper._controller_fixture(workspace)
    JournalInitializer(controller.path).initialize()
    aggregate = controller.bind_start(
        submission,
        at="2026-08-11T01:04:01+00:00",
    )
    steps = (
        (
            ["workspace-provision"],
            "sf106-workspace-provision",
            {
                "repository": aggregate["initial_binding"]["repository_root"],
                "base_revision": aggregate["initial_binding"]["base_revision"],
            },
            {},
            "2026-08-11T01:05:00+00:00",
        ),
        (
            ["workspace-ready"],
            "sf106-workspace-ready",
            {
                "path": aggregate["initial_binding"]["workspace_path"],
                "isolation_mode": "planned-git-worktree",
            },
            {"workspace verification": "evidence:sf106-workspace"},
            "2026-08-11T01:06:00+00:00",
        ),
        (
            ["worker-session-start"],
            "sf106-session-start",
            {
                "run_id": aggregate["run"]["id"],
                "worker_adapter": aggregate["initial_binding"][
                    "worker_adapter_id"
                ],
            },
            {},
            "2026-08-11T01:07:00+00:00",
        ),
        (
            ["worker-session-activate"],
            "sf106-session-activate",
            {"external_session_ref": "codex-thread:sf106"},
            {"worker acknowledgement": "evidence:sf106-ack"},
            "2026-08-11T01:08:00+00:00",
        ),
    )
    for transition_ids, suffix, payload, evidence, at in steps:
        result = controller.apply(
            helper._command(
                aggregate,
                transition_ids,
                suffix=suffix,
                payload=payload,
                evidence_refs=evidence,
                at=at,
            ),
            at=at,
        )
        if result["status"] != "applied":
            raise AssertionError(result)
        aggregate = controller.get(aggregate["run"]["id"])
    prepare = helper._command(
        aggregate,
        ["run-claim", "workspace-bind", "run-start"],
        suffix="sf106-prepare-start",
        payload={
            "authority_ref": aggregate["initial_binding"]["authority_ref"],
            "run_id": aggregate["run"]["id"],
            "worker_session_id": aggregate["worker_session"]["id"],
        },
        evidence_refs={
            "active lease": "lease:transition-command-queue-build-repair"
        },
        at="2026-08-11T01:09:00+00:00",
    )
    pending = controller.prepare_work_item_start(
        prepare,
        at="2026-08-11T01:09:00+00:00",
    )
    transition = controller._transitions.apply(
        pending["result"]["transition_command"],
        at="2026-08-11T01:09:01+00:00",
    )
    if not transition["decision"]["accepted"]:
        raise AssertionError(transition)
    confirmed = controller.confirm_work_item_start(
        prepare["command_id"],
        at="2026-08-11T01:09:02+00:00",
    )
    if confirmed["status"] != "confirmed":
        raise AssertionError(confirmed)
    return (
        controller,
        controller.get(aggregate["run"]["id"]),
        inspector,
    )
