from __future__ import annotations

from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.constants import PROTOCOL_VERSION, ROOT
from elder_protocol.governance import (
    resolve_authority_bindings,
    validate_delegation,
)
from elder_protocol.io import load_json
from elder_protocol.knowledge import KnowledgeStore
from elder_protocol.learning import (
    finalize_learning_artifact,
    validate_learning_candidate,
    validate_learning_promotion,
)
from elder_protocol.protocol import validate_protocol
from elder_protocol.qualification import validate_qualification_policy
from elder_protocol.schema_validation import validate_against_schema


def real_boundary_inputs(workspace: Path) -> dict[str, Any]:
    data = validate_protocol()
    fixture = load_json(
        ROOT / "tests" / "fixtures" / "p4_5a" / "fixture-a-low-risk.json"
    )
    bindings = resolve_authority_bindings(
        fixture["profile"],
        data["role-registry"],
        data["authority-matrix"],
    )
    source = workspace / "bounded-context.md"
    source.write_text(
        "SF-400 calls Elder through one digest-bound governance boundary.",
        encoding="utf-8",
    )
    knowledge = KnowledgeStore(
        workspace / "knowledge.db",
        context_policy=data["context-policy"],
        memory_policy=data["memory-policy"],
    )
    knowledge.initialize()

    context_request = {
        "id": "context-sf400-001",
        "work_item_id": fixture["parent_run"]["work_item_id"],
        "project_id": fixture["profile"]["slug"],
        "query": "SF-400 Elder governance boundary",
        "assembled_by": fixture["parent_run"]["identity_id"],
        "repository_sources": [
            {
                "id": "sf400-design",
                "location": str(source),
                "authority": "primary",
                "required": True,
                "maximum_age_days": 1,
            }
        ],
        "memory_namespaces": [],
        "graph_limit": 0,
        "memory_limit": 0,
        "assumptions": [],
    }
    evidence = {
        "id": "evidence-sf400-001",
        "claim": "Operations received a validated Elder decision.",
        "work_item_id": fixture["parent_run"]["work_item_id"],
        "level": "Integration",
        "artifacts": ["test:sf400-boundary-integration"],
        "verdict": "pass",
        "limitations": ["Local in-process boundary only."],
        "recorded_at": "2026-08-14T13:00:00+00:00",
    }
    candidate = finalize_learning_artifact(
        {
            "version": PROTOCOL_VERSION,
            "id": "candidate-sf400-001",
            "project_id": fixture["profile"]["slug"],
            "kind": "memory",
            "target_ref": "memory:sf400-boundary",
            "artifact_path": "candidate.md",
            "artifact_sha256": canonical_sha256("candidate"),
            "hypothesis": "The candidate improves future boundary diagnostics.",
            "source_evidence": ["evidence:sf400"],
            "counterexamples": ["A diagnostic that weakens a deterministic rejection."],
            "created_by": "fixture-a-low-risk-learning-agent",
            "created_role": "learning-agent",
            "status": "candidate",
            "created_at": "2026-08-14T13:00:00+00:00",
            "expires_at": "2026-08-21T13:00:00+00:00",
        }
    )
    promotion = finalize_learning_artifact(
        {
            "version": PROTOCOL_VERSION,
            "id": "promotion-sf400-001",
            "candidate_id": candidate["id"],
            "candidate_sha256": candidate["content_sha256"],
            "evaluation_id": "evaluation-sf400-001",
            "evaluation_sha256": canonical_sha256("evaluation"),
            "approval_ids": ["approval-sf400-001"],
            "approval_sha256s": [canonical_sha256("approval")],
            "promoted_by": "fixture-a-low-risk-release-owner",
            "promoter_role": "promoter",
            "target_ref": candidate["target_ref"],
            "artifact_sha256": candidate["artifact_sha256"],
            "status": "promoted",
            "applies_target_mutation": False,
            "created_at": "2026-08-14T13:15:00+00:00",
        }
    )

    def classify(payload, request):
        del request
        selected = payload["work_item"]["change_class"]
        by_id = {item["id"]: item for item in data["change-classes"]["classes"]}
        if selected not in by_id:
            raise ValueError(f"Unknown change class: {selected}")
        return {"change_class": by_id[selected]["id"]}

    def assemble_context(payload, request):
        context_input = dict(payload["context_request"])
        if context_input.pop("project_id") != request["project_id"]:
            raise ValueError("Context request project does not match its boundary request.")
        packet = knowledge.assemble_context(
            context_input,
            base_dir=workspace,
        )
        return {
            "context_packet": {
                "id": packet["id"],
                "content_sha256": packet["content_sha256"],
            }
        }

    def authorize(payload, request):
        del request
        action = payload["action"]
        matching = [
            grant
            for grant in bindings["grants"]
            if grant["identity"] == action["identity_id"]
            and grant["role"] == action["role"]
            and grant["resource"] == action["resource"]
            and action["action"] in grant["actions"]
        ]
        return {
            "authority_result": {
                "decision": "allowed" if len(matching) == 1 else "denied",
                "authority_ref": (
                    f"elder://authority/{bindings['project_id']}/"
                    f"{action['identity_id']}/{action['resource']}/{action['action']}"
                ),
            }
        }

    def validate_delegation_handler(payload, request):
        del request
        reference = payload["delegation"]
        if (
            reference["delegation_id"] != fixture["delegation"]["delegation_id"]
            or reference["content_sha256"]
            != fixture["delegation"]["content_sha256"]
        ):
            raise ValueError("Delegation reference does not match canonical Elder state.")
        validate_delegation(
            fixture["delegation"],
            fixture["parent_run"],
            bindings,
            data["delegation-policy"],
            profile=fixture["profile"],
            role_registry=data["role-registry"],
            authority_matrix=data["authority-matrix"],
        )
        return {"validation_result": {"valid": True}}

    def evaluate(payload, request):
        del request
        validated = validate_against_schema(
            payload["evidence"],
            "evidence-bundle.schema.json",
            label="SF-400 evidence",
        )
        return {"evaluation_result": {"verdict": validated["verdict"]}}

    def qualify(payload, request):
        del payload, request
        validate_qualification_policy(
            data["qualification-policy"],
            data["operational-maturity"],
        )
        return {"qualification_report": {"decision": "advisory-qualified"}}

    def propose_learning(payload, request):
        del request
        if payload["trajectory"]["run_id"] != fixture["parent_run"]["id"]:
            raise ValueError("Learning trajectory does not match the governed run.")
        validate_learning_candidate(candidate)
        return {
            "learning_candidate": {
                "candidate_id": candidate["id"],
                "content_sha256": candidate["content_sha256"],
            }
        }

    def promote(payload, request):
        del request
        validate_learning_promotion(payload["promotion_packet"])
        return {
            "governed_target_result": {
                "status": payload["promotion_packet"]["status"],
                "target_ref": payload["promotion_packet"]["target_ref"],
            }
        }

    return {
        "data": data,
        "fixture": fixture,
        "handlers": {
            "classify": classify,
            "assemble-context": assemble_context,
            "authorize": authorize,
            "validate-delegation": validate_delegation_handler,
            "evaluate": evaluate,
            "qualify": qualify,
            "propose-learning": propose_learning,
            "promote": promote,
        },
        "payloads": {
            "classify": {
                "work_item": {
                    "id": fixture["parent_run"]["work_item_id"],
                    "project_id": fixture["profile"]["slug"],
                    "change_class": "internal-code",
                }
            },
            "assemble-context": {"context_request": context_request},
            "authorize": {
                "action": {
                    "resource": "implementation",
                    "action": "modify",
                    "identity_id": "fixture-a-low-risk-executor",
                    "role": "executor",
                }
            },
            "validate-delegation": {
                "delegation": {
                    "delegation_id": fixture["delegation"]["delegation_id"],
                    "content_sha256": fixture["delegation"]["content_sha256"],
                }
            },
            "evaluate": {"evidence": evidence},
            "qualify": {"bundle": {"id": "bundle-sf400-001"}},
            "propose-learning": {
                "trajectory": {
                    "run_id": fixture["parent_run"]["id"],
                    "evidence_refs": [f"evidence:{evidence['id']}"],
                }
            },
            "promote": {"promotion_packet": promotion},
        },
    }
