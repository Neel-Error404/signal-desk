from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from elder_protocol.autonomy import canonical_sha256
from elder_protocol.factory_operations import DurableContinuationScheduler
from tests._sf203_support import running_fixture


CREATED_AT = "2026-08-11T01:08:30+00:00"
FIRST_TICK_AT = "2026-08-11T01:09:00+00:00"
DEADLINE_AT = "2026-08-11T02:00:00+00:00"


def goal_request(
    aggregate: dict[str, Any],
    binding: dict[str, Any],
    *,
    suffix: str = "primary",
    created_at: str = CREATED_AT,
    first_tick_at: str = FIRST_TICK_AT,
    deadline_at: str = DEADLINE_AT,
    token_limit: int = 1000,
    elapsed_seconds_limit: int = 1200,
    continuation_limit: int = 3,
    interval_seconds: int = 60,
    misfire_grace_seconds: int = 10,
) -> dict[str, Any]:
    return {
        "version": "1.0.0",
        "goal_id": f"continuation-goal-sf205-{suffix}",
        "schedule_id": f"continuation-schedule-sf205-{suffix}",
        "idempotency_key": f"sf205-{suffix}-goal-idempotency",
        "project_id": aggregate["run"]["project_id"],
        "run_id": aggregate["run"]["id"],
        "worker_session_id": aggregate["worker_session"]["id"],
        "workspace_id": aggregate["workspace"]["id"],
        "workspace_binding_sha256": canonical_sha256(binding),
        "session_generation": aggregate["worker_session"]["payload"][
            "session_generation"
        ],
        "requested_by_identity_id": aggregate["initial_binding"]["created_by"],
        "objective": (
            "Continue the bounded implementation until the declared evidence "
            "is complete."
        ),
        "created_at": created_at,
        "deadline_at": deadline_at,
        "schedule": {
            "first_tick_at": first_tick_at,
            "interval_seconds": interval_seconds,
            "misfire_grace_seconds": misfire_grace_seconds,
        },
        "budget": {
            "token_limit": token_limit,
            "elapsed_seconds_limit": elapsed_seconds_limit,
            "continuation_limit": continuation_limit,
        },
    }


def scheduler_fixture(
    workspace: Path,
    *,
    after_submit_hook: Any | None = None,
) -> tuple[Any, Any, dict[str, Any], dict[str, Any], Any, Any, Any]:
    (
        helper,
        controller,
        aggregate,
        binding,
        adapter,
        session,
    ) = running_fixture(workspace)
    scheduler = DurableContinuationScheduler(
        workspace / "sf205-continuation.db",
        run_controller=controller,
        session_controller=session,
        workspace_binding_sha256=canonical_sha256(binding),
        after_submit_hook=after_submit_hook,
    )
    scheduler.initialize()
    return (
        helper,
        controller,
        aggregate,
        binding,
        adapter,
        session,
        scheduler,
    )


def reopen_scheduler(
    workspace: Path,
    *,
    controller: Any,
    session: Any,
    binding: dict[str, Any],
) -> DurableContinuationScheduler:
    scheduler = DurableContinuationScheduler(
        workspace / "sf205-continuation.db",
        run_controller=controller,
        session_controller=session,
        workspace_binding_sha256=canonical_sha256(binding),
    )
    scheduler.initialize()
    return scheduler


def changed_request(request: dict[str, Any]) -> dict[str, Any]:
    changed = copy.deepcopy(request)
    changed["objective"] = (
        "Continue a different objective under the same durable identity."
    )
    return changed
