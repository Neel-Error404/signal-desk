from __future__ import annotations

import copy
import hashlib
import hmac
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from elder_protocol.factory_operations.hosted_identity import (
    ExternalSecretBroker,
    IdentitySecretAuditLedger,
    WorkloadIdentityVerifier,
)
from elder_protocol.factory_operations.production_integrations import (
    PRODUCTION_INTEGRATION_VERSION,
    ProductionIntegrationAuditLedger,
    ProductionIntegrationManager,
    integration_content_sha256,
)
from tests._sf601_support import (
    FakeSecretProvider,
    identity_policy,
    resource_reference,
    rsa_fixture,
    signed_token,
)


NOW = datetime(2026, 8, 14, 23, 55, tzinfo=UTC)
INTEGRATIONS = [
    ("chat-main", "chat", "provider-chat"),
    ("ci-main", "ci", "provider-ci"),
    ("github-main", "github", "provider-github"),
    ("issue-main", "issue-tracker", "provider-issue"),
    ("notify-main", "notification", "provider-notify"),
]


class MutableClock:
    def __init__(self, value: datetime = NOW):
        self.value = value

    def __call__(self) -> datetime:
        return self.value

    def advance(self, seconds: int) -> None:
        self.value += timedelta(seconds=seconds)


def integration_policy(
    *,
    now: datetime = NOW,
    maximum_attempts: int = 2,
) -> dict[str, Any]:
    entries = []
    for integration_id, kind, provider_id in INTEGRATIONS:
        entries.append(
            {
                "integration_id": integration_id,
                "provider_id": provider_id,
                "kind": kind,
                "project_id": "project-one",
                "workload_id": "worker-one",
                "source_id": f"source-{integration_id}",
                "inbound_auth": {
                    "broker_id": "broker-one",
                    "resource_id": "resource-database",
                    "allowed_versions": ["v1"],
                },
                "outbound_auth": {
                    "broker_id": "broker-one",
                    "resource_id": "resource-database",
                    "allowed_versions": ["v1"],
                },
                "allowed_actions": [
                    "comment",
                    "create",
                    "notify",
                    "trigger",
                    "update",
                ],
                "maximum_page_size": 50,
                "maximum_attempts": maximum_attempts,
                "retry_delay_seconds": 10,
                "webhook_max_age_seconds": 300,
                "maximum_webhook_bytes": 64 * 1024,
            }
        )
    body = {
        "version": PRODUCTION_INTEGRATION_VERSION,
        "policy_id": "sf603-policy",
        "integrations": entries,
        "issued_at": (now - timedelta(minutes=5)).isoformat(),
        "expires_at": (now + timedelta(days=1)).isoformat(),
    }
    return {**body, "content_sha256": integration_content_sha256(body)}


def integration_command(
    *,
    integration_id: str = "github-main",
    command_id: str = "command-sf603",
    action: str = "comment",
    target_id: str = "issue-42",
    expected_record_sha256: str | None = None,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body = {
        "version": PRODUCTION_INTEGRATION_VERSION,
        "integration_id": integration_id,
        "project_id": "project-one",
        "workload_id": "worker-one",
        "command_id": command_id,
        "action": action,
        "target_id": target_id,
        "expected_record_sha256": expected_record_sha256,
        "payload": payload or {"body": "Owner-approved update."},
    }
    return {**body, "content_sha256": integration_content_sha256(body)}


def external_record(
    external_id: str = "issue-42",
    *,
    version: int = 1,
    digest: str | None = None,
    deleted: bool = False,
    updated_at: datetime = NOW,
) -> dict[str, Any]:
    return {
        "external_id": external_id,
        "external_version": version,
        "external_record_sha256": digest
        or hashlib.sha256(
            f"{external_id}:{version}:{deleted}".encode("utf-8")
        ).hexdigest(),
        "updated_at": updated_at.isoformat(),
        "deleted": deleted,
    }


class FakeProductionIntegrationAdapter:
    def __init__(self, provider_id: str):
        self.provider_id = provider_id
        self.normalize_calls: list[dict[str, Any]] = []
        self.execute_calls: list[dict[str, Any]] = []
        self.list_calls: list[dict[str, Any]] = []
        self.execute_mode = "success"
        self.list_mode = "success"
        self.retry_seconds = 30
        self.pages: dict[str | None, tuple[list[dict[str, Any]], str | None]] = {
            None: ([external_record()], None)
        }

    def normalize_webhook(
        self,
        body: bytes,
        *,
        at: str,
    ) -> dict[str, Any]:
        if self.execute_mode == "normalize-outage":
            raise OSError("provider normalization secret=leak")
        self.normalize_calls.append({"body": body, "at": at})
        return {
            "event_type": "record.updated",
            "external_id": "issue-42",
            "external_version": 1,
            "external_record_sha256": hashlib.sha256(body).hexdigest(),
            "occurred_at": at,
        }

    def execute(
        self,
        command: dict[str, Any],
        identity: dict[str, Any],
        credential: bytes,
        *,
        idempotency_key: str,
        at: str,
    ) -> dict[str, Any]:
        self.execute_calls.append(
            {
                "command": copy.deepcopy(command),
                "identity": copy.deepcopy(identity),
                "credential": credential,
                "idempotency_key": idempotency_key,
                "at": at,
            }
        )
        if self.execute_mode == "outage":
            raise OSError("provider secret=leak")
        if self.execute_mode == "invalid":
            return {"status": "succeeded", "secret": "leak"}
        if self.execute_mode == "rate-limit":
            return {
                "status": "rate_limited",
                "provider_id": self.provider_id,
                "integration_id": command["integration_id"],
                "command_id": command["command_id"],
                "request_sha256": command["content_sha256"],
                "idempotency_key": idempotency_key,
                "observed_at": at,
                "retry_at": (
                    datetime.fromisoformat(at)
                    + timedelta(seconds=self.retry_seconds)
                ).isoformat(),
            }
        return {
            "status": "succeeded",
            "provider_id": self.provider_id,
            "integration_id": command["integration_id"],
            "command_id": command["command_id"],
            "request_sha256": command["content_sha256"],
            "idempotency_key": idempotency_key,
            "observed_at": at,
            "external_id": command["target_id"],
            "external_version": 1,
            "external_record_sha256": hashlib.sha256(
                command["content_sha256"].encode("ascii")
            ).hexdigest(),
        }

    def list_page(
        self,
        identity: dict[str, Any],
        credential: bytes,
        *,
        cursor: str | None,
        page_size: int,
        at: str,
    ) -> dict[str, Any]:
        self.list_calls.append(
            {
                "identity": copy.deepcopy(identity),
                "credential": credential,
                "cursor": cursor,
                "page_size": page_size,
                "at": at,
            }
        )
        if self.list_mode == "outage":
            raise OSError("provider secret=leak")
        if self.list_mode == "invalid":
            return {"status": "succeeded", "secret": "leak"}
        if self.list_mode == "rate-limit":
            return {
                "status": "rate_limited",
                "provider_id": self.provider_id,
                "integration_id": self._integration_id(),
                "cursor": cursor,
                "observed_at": at,
                "retry_at": (
                    datetime.fromisoformat(at)
                    + timedelta(seconds=self.retry_seconds)
                ).isoformat(),
            }
        records, next_cursor = self.pages.get(cursor, ([], None))
        return {
            "status": "succeeded",
            "provider_id": self.provider_id,
            "integration_id": self._integration_id(),
            "cursor": cursor,
            "next_cursor": next_cursor,
            "observed_at": at,
            "records": copy.deepcopy(records[:page_size]),
        }

    def _integration_id(self) -> str:
        for integration_id, _kind, provider_id in INTEGRATIONS:
            if provider_id == self.provider_id:
                return integration_id
        raise AssertionError("unknown provider")


def webhook_headers(
    integration_id: str,
    credential_value: bytes,
    body: bytes,
    *,
    event_id: str = "event-sf603",
    timestamp: datetime = NOW,
) -> dict[str, str]:
    timestamp_text = timestamp.isoformat()
    digest = hmac.new(
        credential_value,
        json.dumps(
            {
                "body_sha256": hashlib.sha256(body).hexdigest(),
                "source_event_id": event_id,
                "source_id": f"source-{integration_id}",
                "timestamp": timestamp_text,
            },
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
            allow_nan=False,
        ).encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return {
        "x-elder-source": f"source-{integration_id}",
        "x-elder-event-id": event_id,
        "x-elder-timestamp": timestamp_text,
        "x-elder-signature": f"sha256={digest}",
    }


def integration_environment(
    root: Path,
    *,
    clock: MutableClock | None = None,
    maximum_attempts: int = 2,
) -> dict[str, Any]:
    clock = clock or MutableClock()
    private_key, jwks = rsa_fixture()
    verifier = WorkloadIdentityVerifier(
        identity_policy(jwks),
        jwks_loader=lambda _issuer: copy.deepcopy(jwks),
        now=clock,
    )
    token = signed_token(
        private_key,
        issued_at=NOW - timedelta(seconds=5),
        not_before=NOW - timedelta(seconds=5),
        expires_at=NOW + timedelta(minutes=5),
        jti="token-sf603",
    )
    secret_provider = FakeSecretProvider(
        now=NOW,
        ttl_seconds=120,
    )
    broker = ExternalSecretBroker(
        identity_verifier=verifier,
        providers={"broker-one": secret_provider},
        audit=IdentitySecretAuditLedger(root / "identity.db"),
        now=clock,
    )
    credential = broker.issue(
        resource_reference(),
        token,
        request_id="request-sf603-broker-issue",
        at=clock().isoformat(),
    )
    adapters = {
        provider_id: FakeProductionIntegrationAdapter(provider_id)
        for _integration_id, _kind, provider_id in INTEGRATIONS
    }
    audit_path = root / "integration.db"
    manager = ProductionIntegrationManager(
        policy=integration_policy(
            now=NOW,
            maximum_attempts=maximum_attempts,
        ),
        identity_verifier=verifier,
        adapters=adapters,
        credential_brokers={"broker-one": broker},
        audit=ProductionIntegrationAuditLedger(audit_path),
        now=clock,
    )
    return {
        "adapters": adapters,
        "audit_path": audit_path,
        "broker": broker,
        "clock": clock,
        "credential": credential,
        "manager": manager,
        "policy": integration_policy(
            now=NOW,
            maximum_attempts=maximum_attempts,
        ),
        "private_key": private_key,
        "token": token,
        "verifier": verifier,
    }
