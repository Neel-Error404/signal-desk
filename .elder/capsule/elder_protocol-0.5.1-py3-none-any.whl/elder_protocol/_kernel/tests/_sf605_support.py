from __future__ import annotations

import copy
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from elder_protocol.factory_operations.multi_product_boundary import (
    MultiProductBoundary,
    finalize_multi_product_document,
    multi_product_content_sha256,
)


NOW = datetime(2026, 8, 15, 13, 0, tzinfo=UTC)

OWNER_A = {"principal_id": "owner-a", "kind": "human"}
OWNER_B = {"principal_id": "owner-b", "kind": "human"}
OPERATOR_A = {"principal_id": "operator-a", "kind": "operator"}
WORKER_A = {"principal_id": "worker-principal-a", "kind": "worker"}
WORKER_B = {"principal_id": "worker-principal-b", "kind": "worker"}


def _product(
    *,
    tenant_id: str,
    product_id: str,
    project_id: str,
    active_workers: int = 2,
    storage_bytes: int = 100,
    retained_evidence_bytes: int = 100,
) -> dict[str, Any]:
    return {
        "tenant_id": tenant_id,
        "product_id": product_id,
        "project_id": project_id,
        "partition_id": multi_product_content_sha256(
            {
                "tenant_id": tenant_id,
                "product_id": product_id,
                "project_id": project_id,
            }
        )[:32],
        "quotas": {
            "active-workers": active_workers,
            "retained-evidence-bytes": retained_evidence_bytes,
            "storage-bytes": storage_bytes,
        },
    }


def build_policy(
    *,
    active_workers: int = 2,
    storage_bytes: int = 100,
) -> dict[str, Any]:
    all_actions = [
        "audit-export",
        "backup",
        "quota",
        "read",
        "restore",
        "storage-write",
        "worker-bind",
    ]
    return finalize_multi_product_document(
        {
            "version": "1.0.0",
            "policy_id": "sf605-test-policy",
            "products": [
                _product(
                    tenant_id="tenant-a",
                    product_id="product-a",
                    project_id="project-a",
                    active_workers=active_workers,
                    storage_bytes=storage_bytes,
                ),
                _product(
                    tenant_id="tenant-b",
                    product_id="product-b",
                    project_id="project-b",
                    active_workers=active_workers,
                    storage_bytes=storage_bytes,
                ),
            ],
            "grants": [
                {
                    "principal_id": "operator-a",
                    "kind": "operator",
                    "tenant_id": "tenant-a",
                    "product_id": "product-a",
                    "actions": all_actions,
                },
                {
                    "principal_id": "owner-a",
                    "kind": "human",
                    "tenant_id": "tenant-a",
                    "product_id": "product-a",
                    "actions": all_actions,
                },
                {
                    "principal_id": "owner-b",
                    "kind": "human",
                    "tenant_id": "tenant-b",
                    "product_id": "product-b",
                    "actions": all_actions,
                },
                {
                    "principal_id": "worker-principal-a",
                    "kind": "worker",
                    "tenant_id": "tenant-a",
                    "product_id": "product-a",
                    "actions": [
                        "quota",
                        "read",
                        "storage-write",
                        "worker-bind",
                    ],
                },
                {
                    "principal_id": "worker-principal-b",
                    "kind": "worker",
                    "tenant_id": "tenant-b",
                    "product_id": "product-b",
                    "actions": [
                        "quota",
                        "read",
                        "storage-write",
                        "worker-bind",
                    ],
                },
            ],
            "issued_at": "2026-08-15T00:00:00+00:00",
            "expires_at": "2026-08-16T00:00:00+00:00",
        }
    )


def changed_policy(policy: dict[str, Any], change: Any) -> dict[str, Any]:
    updated = copy.deepcopy(policy)
    change(updated)
    updated.pop("content_sha256", None)
    return finalize_multi_product_document(updated)


def build_boundary(
    workspace: Path,
    *,
    policy: dict[str, Any] | None = None,
) -> MultiProductBoundary:
    return MultiProductBoundary(
        workspace / "multi-product.db",
        storage_root=workspace / "products",
        policy=policy or build_policy(),
        now=lambda: NOW,
    )

