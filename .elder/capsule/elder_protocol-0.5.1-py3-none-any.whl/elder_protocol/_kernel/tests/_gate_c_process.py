from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

from tests._gate_c_support import post_restart_phase, pre_restart_phase


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("before", "after"))
    parser.add_argument("--root", required=True)
    parser.add_argument(
        "--mode",
        choices=("deterministic", "live"),
        default="deterministic",
    )
    arguments = parser.parse_args()
    root = Path(arguments.root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    live_codex = arguments.mode == "live"
    if arguments.phase == "before":
        manifest = pre_restart_phase(root, live_codex=live_codex)
        print(
            "GATE_C_READY "
            + json.dumps(
                {
                    "manifest": str(root / "restart-manifest.json"),
                    "content_sha256": manifest["content_sha256"],
                },
                sort_keys=True,
            ),
            flush=True,
        )
        while True:
            time.sleep(60)
    packet = post_restart_phase(root, live_codex=live_codex)
    print(
        "GATE_C_COMPLETE "
        + json.dumps(
            {
                "packet": str(root / "gate-c-qualification.json"),
                "content_sha256": packet["content_sha256"],
                "verdict": packet["verdict"],
            },
            sort_keys=True,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
