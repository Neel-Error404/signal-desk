from __future__ import annotations

import base64
import copy
import json
import threading
from datetime import UTC, datetime, timedelta
from typing import Any

from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
from cryptography.hazmat.primitives.asymmetric.rsa import (
    RSAPrivateKey,
    generate_private_key,
)
from cryptography.hazmat.primitives.hashes import SHA256

from elder_protocol.factory_operations.hosted_identity import (
    HOSTED_IDENTITY_VERSION,
    identity_content_sha256,
)


NOW = datetime(2026, 8, 14, 22, 30, tzinfo=UTC)


def _b64(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def rsa_fixture() -> tuple[RSAPrivateKey, dict[str, Any]]:
    private_key = generate_private_key(public_exponent=65537, key_size=2048)
    numbers = private_key.public_key().public_numbers()
    jwks = {
        "keys": [
            {
                "kid": "sf601-key",
                "kty": "RSA",
                "use": "sig",
                "alg": "RS256",
                "n": _b64(
                    numbers.n.to_bytes(
                        (numbers.n.bit_length() + 7) // 8,
                        "big",
                    )
                ),
                "e": _b64(
                    numbers.e.to_bytes(
                        (numbers.e.bit_length() + 7) // 8,
                        "big",
                    )
                ),
            }
        ]
    }
    return private_key, jwks


def identity_policy(jwks: dict[str, Any]) -> dict[str, Any]:
    body = {
        "version": HOSTED_IDENTITY_VERSION,
        "policy_id": "sf601-policy",
        "issuers": [
            {
                "issuer": "https://identity.example.test",
                "audiences": ["elder-factory"],
                "jwks_sha256": identity_content_sha256(jwks),
                "maximum_token_ttl_seconds": 600,
                "clock_skew_seconds": 30,
            }
        ],
        "bindings": [
            {
                "binding_id": "binding-worker-one",
                "issuer": "https://identity.example.test",
                "subject": "workload:project-one:worker-one",
                "project_id": "project-one",
                "workload_id": "worker-one",
                "kind": "worker",
                "secret_grants": [
                    {
                        "broker_id": "broker-one",
                        "resource_id": "resource-database",
                        "allowed_versions": ["v1", "v2"],
                        "actions": ["read", "rotate", "revoke"],
                        "maximum_credential_ttl_seconds": 120,
                    }
                ],
            },
            {
                "binding_id": "binding-service-two",
                "issuer": "https://identity.example.test",
                "subject": "workload:project-two:service-two",
                "project_id": "project-two",
                "workload_id": "service-two",
                "kind": "service",
                "secret_grants": [],
            },
        ],
        "revoked_token_sha256": [],
        "issued_at": (NOW - timedelta(minutes=5)).isoformat(),
        "expires_at": (NOW + timedelta(days=1)).isoformat(),
    }
    return {**body, "content_sha256": identity_content_sha256(body)}


def signed_token(
    private_key: RSAPrivateKey,
    *,
    subject: str = "workload:project-one:worker-one",
    project_id: str = "project-one",
    workload_id: str = "worker-one",
    audience: str = "elder-factory",
    issued_at: datetime = NOW - timedelta(seconds=5),
    not_before: datetime = NOW - timedelta(seconds=5),
    expires_at: datetime = NOW + timedelta(minutes=5),
    jti: str = "token-sf601",
) -> str:
    header = {"alg": "RS256", "kid": "sf601-key", "typ": "JWT"}
    claims = {
        "iss": "https://identity.example.test",
        "sub": subject,
        "aud": audience,
        "project_id": project_id,
        "workload_id": workload_id,
        "jti": jti,
        "iat": int(issued_at.timestamp()),
        "nbf": int(not_before.timestamp()),
        "exp": int(expires_at.timestamp()),
    }
    encoded_header = _b64(
        json.dumps(
            header,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    )
    encoded_claims = _b64(
        json.dumps(
            claims,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    )
    signing_input = f"{encoded_header}.{encoded_claims}".encode("ascii")
    signature = private_key.sign(signing_input, PKCS1v15(), SHA256())
    return f"{encoded_header}.{encoded_claims}.{_b64(signature)}"


def resource_reference(
    *,
    project_id: str = "project-one",
    version: str = "v1",
) -> dict[str, Any]:
    return {
        "version": HOSTED_IDENTITY_VERSION,
        "reference_id": f"reference-database-{version}",
        "broker_id": "broker-one",
        "project_id": project_id,
        "resource_id": "resource-database",
        "resource_version": version,
    }


class FakeSecretProvider:
    def __init__(
        self,
        *,
        now: datetime = NOW,
        unavailable: bool = False,
        ttl_seconds: int = 60,
    ):
        self.now = now
        self.unavailable = unavailable
        self.ttl_seconds = ttl_seconds
        self.issued: list[dict[str, Any]] = []
        self.revoked: list[str] = []
        self.rotations: list[dict[str, Any]] = []
        self._lock = threading.Lock()

    def issue(
        self,
        reference: dict[str, Any],
        identity: dict[str, Any],
        *,
        at: str,
    ) -> dict[str, Any]:
        if self.unavailable:
            raise OSError("broker unavailable")
        with self._lock:
            lease_number = len(self.issued) + 1
            result = {
                "lease_id": f"lease-{lease_number}",
                "resource_version": reference["resource_version"],
                "issued_at": at,
                "expires_at": (
                    datetime.fromisoformat(at)
                    + timedelta(seconds=self.ttl_seconds)
                ).isoformat(),
                "value": f"credential-{lease_number}".encode("utf-8"),
            }
            self.issued.append(
                {
                    "reference": copy.deepcopy(reference),
                    "identity": copy.deepcopy(identity),
                    "result": copy.deepcopy(result),
                }
            )
            return result

    def rotate(
        self,
        reference: dict[str, Any],
        identity: dict[str, Any],
        *,
        lease_ids: list[str],
        at: str,
    ) -> dict[str, Any]:
        if self.unavailable:
            raise OSError("broker unavailable")
        current = "v2" if reference["resource_version"] == "v1" else "v3"
        result = {
            "previous_version": reference["resource_version"],
            "current_version": current,
            "rotation_id": f"rotation-{len(self.rotations) + 1}",
            "revoked_lease_ids": sorted(lease_ids),
        }
        self.rotations.append(copy.deepcopy(result))
        self.revoked.extend(sorted(lease_ids))
        return result

    def revoke(
        self,
        lease_id: str,
        identity: dict[str, Any],
        *,
        at: str,
    ) -> None:
        if self.unavailable:
            raise OSError("broker unavailable")
        with self._lock:
            self.revoked.append(lease_id)
